// ─────────────────────────────────────────────────────────────
//  Ambienti AsiaFood: development · staging · production.
//  Condiviso tra backend (APP_ENV) e frontend (VITE_APP_ENV).
// ─────────────────────────────────────────────────────────────
export type AppEnv = 'development' | 'staging' | 'production';
export const APP_ENVS: readonly AppEnv[] = ['development', 'staging', 'production'];

/**
 * Risolve l'ambiente: variabile esplicita (APP_ENV / VITE_APP_ENV) oppure, su Netlify, dal contesto di deploy
 * (production → production, deploy-preview/branch-deploy → staging). In mancanza di indicazioni: development.
 */
export function resolveAppEnv(explicit?: string | null, netlifyContext?: string | null): AppEnv {
  const e = (explicit ?? '').trim().toLowerCase();
  if ((APP_ENVS as readonly string[]).includes(e)) return e as AppEnv;
  const c = (netlifyContext ?? '').trim().toLowerCase();
  if (c === 'production') return 'production';
  if (c === 'deploy-preview' || c === 'branch-deploy') return 'staging';
  return 'development';
}
