// ─────────────────────────────────────────────────────────────
//  Interpretazione deterministica della richiesta (italiano).
//  È la base di tutto: funziona anche senza modello AI. Il modello
//  può solo completare i campi mancanti, con validazione server-side.
// ─────────────────────────────────────────────────────────────
import { resolveWhen } from './dates';
import { AI_INTENTS, type AiCatalog, type AiFilters, type AiIntent } from './types';

export const MAX_MESSAGE_LENGTH = 500;

export function normalize(s: string) {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[’`´]/g, "'")
    .replace(/[^a-z0-9€.,:'\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Input utente: niente caratteri di controllo, lunghezza limitata. */
export function sanitizeUserMessage(s: unknown): string {
  if (typeof s !== 'string') return '';
  return s
    // eslint-disable-next-line no-control-regex -- rimozione voluta dei caratteri di controllo
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, MAX_MESSAGE_LENGTH);
}

// Sinonimi → slug categoria (le categorie inesistenti nel catalogo vengono ignorate)
const CATEGORY_SYNONYMS: Record<string, string[]> = {
  sushi: ['sushi', 'nigiri', 'uramaki', 'sashimi', 'hosomaki', 'temaki'],
  giapponese: ['giapponese', 'giapponesi', 'japanese', 'cucina giapponese'],
  cinese: ['cinese', 'cinesi', 'dim sum', 'dimsum'],
  thai: ['thai', 'thailandese', 'tailandese', 'thailandesi'],
  coreano: ['coreano', 'coreana', 'coreani', 'korean', 'bbq coreano'],
  poke: ['poke', 'poké', 'pokè', 'pokè bowl', 'poke bowl'],
  ramen: ['ramen'],
  fusion: ['fusion'],
  'street-food': ['street food', 'streetfood', 'bao', 'baozi'],
  'all-you-can-eat': ['ayce', 'all you can eat', 'all-you-can-eat', 'allyoucaneat', 'formula illimitata', 'a volonta', 'giapponese illimitato'],
  'bubble-tea': ['bubble tea', 'bubbletea'],
  'asian-bakery': ['bakery', 'pasticceria asiatica', 'dolci asiatici'],
  'asian-grocery': ['alimentari asiatici', 'market asiatico', 'grocery'],
};

// Termini per la ricerca nei menu (radice → trova anche plurali e varianti)
const DISH_TERMS: [RegExp, string][] = [
  [/\bramen\b/, 'ramen'], [/\bpoke\b/, 'poke'], [/\bsalmon[ei]?\b/, 'salmon'], [/\btonno\b/, 'tonno'], [/\bavocado\b/, 'avocado'],
  [/\bgyoza\b/, 'gyoza'], [/\btempura\b/, 'tempura'], [/\budon\b/, 'udon'], [/\bsoba\b/, 'soba'], [/\bpad thai\b/, 'pad thai'],
  [/\bcurry\b/, 'curry'], [/\bbibimbap\b/, 'bibimbap'], [/\bbulgogi\b/, 'bulgogi'], [/\bkimchi\b/, 'kimchi'], [/\bdim sum\b/, 'dim sum'],
  [/\bravioli\b/, 'ravioli'], [/\bedamame\b/, 'edamame'], [/\bnigiri\b/, 'nigiri'], [/\buramaki\b/, 'uramaki'], [/\bsashimi\b/, 'sashimi'],
  [/\btemaki\b/, 'temaki'], [/\bonigiri\b/, 'onigiri'], [/\bkatsu\b/, 'katsu'], [/\bteriyaki\b/, 'teriyaki'], [/\bmochi\b/, 'mochi'],
  [/\btofu\b/, 'tofu'], [/\bgamber[oie]t?t?[oi]?\b/, 'gamber'], [/\bpollo\b/, 'pollo'], [/\bmanzo\b/, 'manzo'], [/\bmaiale\b/, 'maiale'],
  [/\banatra\b/, 'anatra'], [/\bnoodles?\b/, 'noodle'], [/\bspaghetti di riso\b/, 'spaghetti di riso'], [/\bbao\b/, 'bao'],
  [/\bdumplings?\b/, 'dumpling'], [/\binvoltin[io]\b/, 'involtin'], [/\bwonton\b/, 'wonton'], [/\bmiso\b/, 'miso'], [/\bmatcha\b/, 'matcha'],
  [/\bpolpo\b/, 'polpo'], [/\bgranchio\b/, 'granchio'], [/\briso\b/, 'riso'], [/\bzuppa\b/, 'zuppa'],
];

const SERVICE_WORDS: [RegExp, string][] = [
  [/\bparchegg/, 'parcheggio'], [/\bdehors\b|\ball'?aperto\b|\ball esterno\b|\btavoli fuori\b/, 'dehors'], [/\bwi-?fi\b/, 'wifi'],
  [/\baccessibil|\bdisabil|\bsedia a rotelle\b/, 'accessibile'], [/\bbambin|\bfamigli/, 'famiglie'], [/\bgrupp/, 'gruppi'],
  [/\bvista mare\b/, 'vista_mare'], [/\banimali\b|\bcane\b|\bpet\b/, 'pet_friendly'], [/\bpos\b|\bcarta di credito\b|\bbancomat\b/, 'pagamento_carta'],
];

const WORD_NUMBERS: Record<string, number> = { due: 2, tre: 3, quattro: 4, cinque: 5, sei: 6, sette: 7, otto: 8, nove: 9, dieci: 10, dodici: 12 };

export interface Parsed {
  intent: AiIntent;
  intents: AiIntent[];
  filters: AiFilters;
  /** Numero di segnali riconosciuti: se basso, il modello può aiutare a interpretare. */
  confidence: number;
  refinement: boolean;
  wants_map: boolean;
  wants_compare_previous: boolean;
  general_question: boolean;
  short_generic: boolean;
}

const num = (s: string) => Number(s.replace(',', '.'));

export function parseMessage(raw: string, catalog: AiCatalog, now: Date): Parsed {
  const text = ` ${normalize(raw)} `;
  const f: AiFilters = {};
  let signals = 0;

  // ─── Categorie e città dal catalogo reale ───
  const cats = new Set<string>();
  for (const c of catalog.categories) {
    const words = [normalize(c.name), c.slug.replace(/-/g, ' '), ...(CATEGORY_SYNONYMS[c.slug] ?? []).map(normalize)];
    if (words.some((w) => w.length > 2 && new RegExp(`\\b${w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`).test(text))) cats.add(c.slug);
  }
  if (cats.has('all-you-can-eat')) {
    cats.delete('all-you-can-eat');
    f.ayce = true;
    signals++;
  }
  if (cats.size) {
    f.categories = [...cats].slice(0, 4);
    signals++;
  }
  const cityHit = [...catalog.cities]
    .sort((a, b) => b.name.length - a.name.length)
    .find((c) => new RegExp(`\\b${normalize(c.name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`).test(text));
  if (cityHit) {
    f.city = cityHit.slug;
    signals++;
  }

  // ─── Piatti / ingredienti ───
  const terms = DISH_TERMS.filter(([re]) => re.test(text)).map(([, t]) => t);
  if (terms.length) {
    f.dish_terms = [...new Set(terms)].slice(0, 4);
    signals++;
  }

  // ─── Preferenze alimentari e allergie ───
  if (/\bvegetarian[oiae]?\b|\bveg\b/.test(text)) f.vegetarian = true;
  if (/\bvegan[oiae]?\b/.test(text)) f.vegan = true;
  if (/senza glutine|gluten ?free|\bceliac|\bceliachia\b|\bsenza grano\b/.test(text)) f.gluten_free = true;
  if (/\bpiccant|\bspicy\b|\bspeziat/.test(text)) f.spicy = true;
  if (/\ballergi|\bintolleran|\ballergic/.test(text)) f.allergy = true;
  if (f.vegetarian || f.vegan || f.gluten_free || f.spicy || f.allergy) signals++;

  // ─── Servizi ───
  const services = SERVICE_WORDS.filter(([re]) => re.test(text)).map(([, s]) => s);
  if (services.length) {
    f.services = services;
    signals++;
  }
  if (/\bconsegn|\ba domicilio\b|\bdelivery\b/.test(text)) {
    f.delivery = true;
    signals++;
  }
  if (/\bordin(are|o|a|iamo)\b|\bordine online\b|\bordinazion/.test(text) && !/\bordin[ae] (per|del) (prezzo|distanza)/.test(text)) {
    f.order_online = true;
    if (/\b(adesso|ora|subito|in questo momento)\b/.test(text)) f.order_now = true;
    signals++;
  }
  if (/\basporto\b|\bda portare via\b|\btake ?away\b/.test(text)) {
    f.takeaway = true;
    signals++;
  }

  // ─── Posizione ───
  if (/\bvicino( a me| casa|\b)|\bqui intorno\b|\bnei dintorni\b|\bnelle vicinanze\b|\bintorno a me\b|\bdove sono\b|\ba piedi\b|\bentro \d/.test(text)) {
    f.near_me = true;
    signals++;
  }
  const rad = /\bentro (\d+(?:[.,]\d+)?)\s*(km|chilometri|kilometri|m\b|metri)/.exec(text);
  if (rad) {
    f.near_me = true;
    const v = num(rad[1]!);
    f.radius_km = /^m|metri/.test(rad[2]!) ? Math.max(0.5, v / 1000) : Math.min(v, 100);
  }

  // ─── Persone e budget ───
  const party = /\b(?:siamo|in|per)\s+(\d{1,2}|due|tre|quattro|cinque|sei|sette|otto|nove|dieci|dodici)\s*(?:persone|pers\b|amici|adulti)?\b/.exec(text);
  if (party && !/\bper (le|l')\b/.test(party[0])) {
    const n = WORD_NUMBERS[party[1]!] ?? Number(party[1]);
    if (n >= 1 && n <= 30 && !/\b(alle|ore)\s*$/.test(text.slice(0, party.index + 1))) {
      f.party_size = n;
      signals++;
    }
  }
  const money = /(?:sotto|meno di|massimo|max|al massimo|fino a|non piu di|entro|budget(?: di)?|spendere(?: massimo| al massimo)?|con)\s*(?:i |gli |le )?(\d{1,4}(?:[.,]\d{1,2})?)\s*(?:€|euro|eur)(?![a-z])|(\d{1,4}(?:[.,]\d{1,2})?)\s*(?:€|euro|eur)(?![a-z])/.exec(text);
  if (money) {
    const v = num(money[1] ?? money[2]!);
    const perPerson = /(a testa|a persona|cadauno|ciascuno|pro capite)/.test(text);
    const isTotal = !perPerson && !!f.party_size && f.party_size > 1 && (/\b(totale|in tutto|spendere|budget|abbiamo|con)\b/.test(text) || v >= 40 * (f.party_size - 1));
    if (isTotal) {
      f.budget_total = v;
      f.max_price = Math.round((v / f.party_size!) * 100) / 100;
    } else if (/\b(almeno|da piu di|sopra)\b/.test(money[0])) {
      f.min_price = v;
    } else {
      f.max_price = v;
    }
    signals++;
  }

  // ─── Tempo ───
  if (/\b(aperto|aperti|aperta|aperte) (ora|adesso|in questo momento|subito)\b|\b(ora|adesso) (aperto|aperti)\b|\baperti ora\b|\bche sono aperti\b/.test(text)) {
    f.open_now = true;
    signals++;
  }
  const when = resolveWhen(text, now);
  if (when.date) {
    f.date = when.date;
    f.date_label = when.label;
    if (when.time) f.time = when.time;
    if (when.meal) f.meal = when.meal;
    if (when.window_from) {
      f.window_from = when.window_from;
      f.window_to = when.window_to;
    }
    signals++;
    if (!f.open_now) delete f.open_now;
  }

  // ─── Offerte, prenotazioni ───
  const offers = /\boffert|\bpromo|\bscont|\bcoupon|\bbuon[oi] scont|\bpromozion/.test(text);
  if (offers) {
    f.has_offers = true;
    signals++;
  }
  const booking = /\bprenot|\btavolo\b|\bposto per\b/.test(text) || (!!f.party_size && !!f.time);
  if (booking) {
    f.reservation = true;
    signals++;
  }

  // ─── Confronto ───
  const compareWords = /\bconfront|\bmeglio\b|\bdifferenza tra\b|\b vs\.? |\bparagon/.test(text);
  const wantsComparePrev = compareWords && /\b(primi due|primo e (il )?secondo|questi|quei due|i due)\b/.test(text);
  if (compareWords && !wantsComparePrev) {
    const tail = text.replace(/.*?\b(confronta(?:re)?|meglio|differenza tra|paragona(?:re)?)\b/, ' ');
    const parts = tail
      .replace(/\b(per (l')?ayce|per il sushi|per cena|per pranzo|\?)/g, ' ')
      .split(/\s(?:o|oppure|e|vs\.?|contro|con)\s|,/)
      .map((s) => s.replace(/\b(il|lo|la|i|gli|le|ristorante|locale|da|di)\b/g, ' ').replace(/[^a-z0-9' -]/g, ' ').replace(/\s+/g, ' ').trim())
      .filter((s) => s.length >= 3 && s.length <= 60)
      .slice(0, 3);
    if (parts.length >= 2) f.compare = parts;
  }

  // ─── Preferiti ───
  if (/\b(simil[ei]|come quell[io]|tipo quell[io])\b.*\b(salvat|preferit)/.test(text) || /\b(miei|mio) preferit/.test(text)) f.favorites_similar = true;

  const wantsMap = /\bmappa\b|\bsulla cartina\b/.test(text);
  const general = /\b(cos'?e|cosa e|che cos'?e|cosa sono|come si mangia|come si fa|che differenza c'?e|origine|significa)\b/.test(text) && !f.city && !f.near_me;

  // ─── Intento principale (priorità) ───
  const intents: AiIntent[] = [];
  if (f.compare || wantsComparePrev) intents.push('restaurant_comparison');
  if (f.reservation && (f.date || f.party_size || f.time)) intents.push('reservation_search');
  if (f.has_offers) intents.push('offer_search');
  if (general && !f.has_offers && !f.reservation) intents.push('general_food_question');
  if (f.dish_terms) intents.push('dish_search');
  if (f.vegetarian || f.vegan || f.gluten_free || f.allergy) intents.push('dietary_search');
  if (f.ayce) intents.push('ayce_search');
  if (f.near_me) intents.push('nearby_search');
  if (f.open_now) intents.push('open_now_search');
  if (f.max_price || f.min_price || f.party_size) intents.push('price_search');
  if (f.reservation && !intents.includes('reservation_search')) intents.push('reservation_search');
  intents.push('restaurant_search');
  const intent = intents[0]!;

  const words = normalize(raw).split(' ').filter(Boolean);
  const refinement =
    !f.categories && !f.dish_terms && !f.ayce && !f.compare && !f.favorites_similar && !general &&
    (words.length <= 7 || /^(e |ma |solo |anche |allora |invece |e se |meglio |ok |si |sì )/.test(normalize(raw)));
  const shortGeneric = words.length <= 3 && !!(f.categories || f.dish_terms || f.ayce) && !f.city && !f.near_me && !f.open_now && !f.date;

  return {
    intent: AI_INTENTS.includes(intent) ? intent : 'restaurant_search',
    intents,
    filters: f,
    confidence: signals,
    refinement,
    wants_map: wantsMap,
    wants_compare_previous: wantsComparePrev,
    general_question: general,
    short_generic: shortGeneric,
  };
}

/** Unisce la richiesta corrente al contesto della conversazione (es. "Massafra" dopo "Voglio sushi"). */
export function mergeWithContext(p: Parsed, prev: AiFilters | undefined | null): AiFilters {
  if (!prev) return p.filters;
  const keepLocation = { city: prev.city, near_me: prev.near_me, radius_km: prev.radius_km };
  if (p.refinement) {
    const merged: AiFilters = { ...stripVolatile(prev), ...p.filters };
    // "solo quelli aperti ora" sostituisce una data precedente e viceversa
    if (p.filters.open_now) {
      delete merged.date; delete merged.date_label; delete merged.time; delete merged.window_from; delete merged.window_to; delete merged.meal;
    }
    if (p.filters.date) delete merged.open_now;
    if (p.filters.city) delete merged.near_me;
    if (p.filters.near_me) delete merged.city;
    return merged;
  }
  const merged: AiFilters = { ...p.filters };
  if (!merged.city && !merged.near_me) {
    if (keepLocation.city) merged.city = keepLocation.city;
    else if (keepLocation.near_me) {
      merged.near_me = true;
      if (keepLocation.radius_km) merged.radius_km = keepLocation.radius_km;
    }
  }
  return merged;
}

function stripVolatile(f: AiFilters): AiFilters {
  const { compare: _c, favorites_similar: _f, ...rest } = f;
  return rest;
}
