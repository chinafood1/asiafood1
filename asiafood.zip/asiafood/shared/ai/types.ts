// ─────────────────────────────────────────────────────────────
//  AI Assistant — tipi condivisi (server, modalità DEMO, UI).
//  Nessuna dipendenza: questo modulo è usato sia dalle Netlify
//  Functions sia dal frontend.
// ─────────────────────────────────────────────────────────────

export const AI_INTENTS = [
  'restaurant_search',
  'dish_search',
  'nearby_search',
  'price_search',
  'open_now_search',
  'ayce_search',
  'offer_search',
  'reservation_search',
  'menu_question',
  'dietary_search',
  'restaurant_comparison',
  'general_food_question',
] as const;
export type AiIntent = (typeof AI_INTENTS)[number];

export type OpenStatus = 'open' | 'closed' | 'unknown';

/** Filtri strutturati (validati lato server). Mai coordinate: la posizione viaggia a parte. */
export interface AiFilters {
  city?: string;
  categories?: string[];
  dish_terms?: string[];
  text?: string;
  near_me?: boolean;
  radius_km?: number;
  max_price?: number;
  min_price?: number;
  party_size?: number;
  budget_total?: number;
  ayce?: boolean;
  delivery?: boolean;
  takeaway?: boolean;
  reservation?: boolean;
  open_now?: boolean;
  date?: string;
  date_label?: string;
  time?: string;
  meal?: 'lunch' | 'dinner';
  window_from?: string;
  window_to?: string;
  vegetarian?: boolean;
  vegan?: boolean;
  gluten_free?: boolean;
  spicy?: boolean;
  allergy?: boolean;
  has_offers?: boolean;
  services?: string[];
  compare?: string[];
  favorites_similar?: boolean;
  /** Fase 8: cerca ristoranti che accettano ordini online (l'assistente non paga e non ordina). */
  order_online?: boolean;
  order_now?: boolean;
  sort?: 'distance' | 'price' | 'relevance';
}

export interface AiCatalog {
  categories: { slug: string; name: string }[];
  cities: { slug: string; name: string }[];
}

export interface AiRestaurant {
  id: string;
  slug: string;
  name: string;
  city: string | null;
  city_slug: string | null;
  categories: string[];
  distance_km: number | null;
  price_per_person: number | null;
  average_price: number | null;
  price_range: number | null;
  is_all_you_can_eat: boolean;
  ayce_lunch_price: number | null;
  ayce_dinner_price: number | null;
  ayce_weekend_price: number | null;
  services: string[];
  has_delivery: boolean;
  has_takeaway: boolean;
  reservations_online: boolean;
  open_status: OpenStatus;
  has_hours: boolean;
  cover_url: string | null;
  latitude: number | null;
  longitude: number | null;
  phone: string | null;
  is_demo: boolean;
  offer: { id: string; title: string } | null;
  offers_count: number;
  /** Solo per le ricerche di prenotazione: orari realmente liberi (verificati). */
  available_slots?: string[];
  /** Fase 8: ordini online disponibili (solo informativo; il pagamento avviene sempre al checkout). */
  order_online?: { takeaway: boolean; delivery: boolean; order_now: boolean } | null;
}

export interface AiRestaurantResult {
  items: AiRestaurant[];
  total: number;
  excluded_no_price: number;
  unknown_hours: number;
}

export interface AiMenuItem {
  id: string;
  name: string;
  description: string | null;
  price: number | null;
  discount_price: number | null;
  allergens: string[] | null;
  is_vegetarian: boolean;
  is_vegan: boolean;
  is_gluten_free: boolean;
  is_spicy: boolean;
  menu_category: string | null;
  restaurant: { id: string; slug: string; name: string; city: string | null; distance_km: number | null };
}

export interface AiOffer {
  id: string;
  title: string;
  description: string | null;
  offer_type: string;
  discount_type: string | null;
  discount_value: number | null;
  minimum_spend: number | null;
  days_of_week: number[];
  start_time: string | null;
  end_time: string | null;
  ends_at: string | null;
  terms: string | null;
  restaurant: { id: string; slug: string; name: string; city: string | null; distance_km?: number | null };
}

export interface AiCoupon {
  id: string;
  title: string;
  discount_type: string | null;
  discount_value: number | null;
  minimum_spend: number | null;
  valid_until: string | null;
  restaurant: { id: string; slug: string; name: string; city: string | null };
}

export interface AiRestaurantDetail {
  id: string;
  slug: string;
  name: string;
  city: string | null;
  short_description: string | null;
  description: string | null;
  address: string | null;
  phone: string | null;
  average_price: number | null;
  price_range: number | null;
  is_all_you_can_eat: boolean;
  ayce_lunch_price: number | null;
  ayce_dinner_price: number | null;
  ayce_weekend_price: number | null;
  services: string[];
  has_delivery: boolean;
  has_takeaway: boolean;
  is_temporarily_closed: boolean;
  cover_url: string | null;
  latitude: number | null;
  longitude: number | null;
  categories: string[];
  open_status: OpenStatus;
  hours: { day: number; opens: string | null; closes: string | null; is_closed: boolean; label: string | null }[];
  closures: { date: string; from: string | null; to: string | null }[];
  menu_summary: { items: number; vegetarian: number; vegan: number; gluten_free: number; spicy: number };
  reservations_online: boolean;
  has_offers: boolean;
}

export interface RestaurantQuery {
  text?: string;
  city?: string;
  categories?: string[];
  ids?: string[];
  lat?: number;
  lng?: number;
  radius_km?: number;
  max_price?: number;
  min_price?: number;
  meal?: 'lunch' | 'dinner';
  ayce?: boolean;
  delivery?: boolean;
  takeaway?: boolean;
  reservation?: boolean;
  open_at?: string;
  window_date?: string;
  window_from?: string;
  window_to?: string;
  open_required?: boolean;
  vegetarian?: boolean;
  vegan?: boolean;
  gluten_free?: boolean;
  spicy?: boolean;
  has_offers?: boolean;
  services?: string[];
  sort?: 'distance' | 'price' | 'relevance';
  limit?: number;
}

export interface MenuQuery {
  terms?: string[];
  match?: 'all' | 'any';
  restaurant_id?: string;
  city?: string;
  categories?: string[];
  lat?: number;
  lng?: number;
  radius_km?: number;
  max_price?: number;
  vegetarian?: boolean;
  vegan?: boolean;
  gluten_free?: boolean;
  spicy?: boolean;
  limit?: number;
}

export interface OfferQuery {
  date?: string;
  city?: string;
  categories?: string[];
  restaurant_id?: string;
  lat?: number;
  lng?: number;
  radius_km?: number;
  limit?: number;
}

export interface Availability {
  ok: boolean;
  reason?: string | null;
  slots: { time: string; status: string }[];
}

/** Accesso ai dati: solo funzioni predefinite (mai SQL generato dal modello). */
export interface AiDataPort {
  catalog(): Promise<AiCatalog>;
  searchRestaurants(q: RestaurantQuery): Promise<AiRestaurantResult>;
  searchMenu(q: MenuQuery): Promise<AiMenuItem[]>;
  searchOffers(q: OfferQuery): Promise<{ offers: AiOffer[]; coupons: AiCoupon[]; date: string }>;
  restaurantDetail(ref: string): Promise<AiRestaurantDetail | null>;
  availability(restaurantId: string, date: string, partySize: number): Promise<Availability>;
  /** Fase 8: ristoranti con ordini online attivi (sola lettura). */
  orderable?(): Promise<{ restaurant_id: string; takeaway: boolean; delivery: boolean; order_now: boolean; payments_ready: boolean }[]>;
  /** Slot sponsorizzati (separati e dichiarati): ID dei ristoranti, mai passati al modello. */
  sponsoredIds?(placement: string, ctx: { city?: string; category?: string }): Promise<{ campaign_id: string; restaurant_id: string }[]>;
}

export interface LlmUsage {
  input_tokens: number;
  output_tokens: number;
}

/** Modello linguistico astratto: riceve istruzioni e messaggi, restituisce testo (JSON richiesto). */
export interface LlmPort {
  provider: string;
  model: string;
  complete(req: { system: string; messages: { role: 'user' | 'assistant'; content: string }[]; maxTokens: number; temperature: number }): Promise<{ text: string; usage: LlmUsage }>;
}

export interface AiUserContext {
  preferences?: { favorite_categories?: string[]; preferred_price_range?: number | null; dietary_preferences?: string[]; favorite_cities?: string[] } | null;
  favorite_ids?: string[];
  favorite_categories?: string[];
}

export interface AiSessionContext {
  prev_filters?: AiFilters & { last_ids?: string[]; last_intent?: AiIntent };
  history?: { role: 'user' | 'assistant'; content: string }[];
  restaurant_id?: string | null;
  location?: { lat: number; lng: number } | null;
  location_denied?: boolean;
  user?: AiUserContext | null;
}

export interface AiFollowUp {
  label: string;
  prompt: string;
}

export interface AiResponse {
  message: string;
  intent: AiIntent;
  filters: AiFilters;
  date_label?: string | null;
  restaurants: AiRestaurant[];
  menu_items: AiMenuItem[];
  offers: AiOffer[];
  coupons: AiCoupon[];
  sponsored: { campaign_id: string; restaurant: AiRestaurant }[];
  comparison?: AiRestaurantDetail[];
  follow_ups: AiFollowUp[];
  actions: { map_ids?: string[]; booking?: { date: string; time: string | null; party_size: number } | null };
  notices: string[];
  needs_location?: boolean;
  clarification?: boolean;
  meta: { source: 'llm' | 'template'; cached?: boolean; fallback_reason?: string | null; provider?: string | null };
}
