// Date relative in italiano → data concreta nel fuso della piattaforma (Europe/Rome).
// Deterministico: "stasera", "domani", "sabato", "questo weekend", "alle 21", "a pranzo".

export const PLATFORM_TZ = 'Europe/Rome';

export interface ResolvedWhen {
  date?: string; // YYYY-MM-DD
  label?: string; // "sabato 26 settembre"
  time?: string; // HH:MM
  meal?: 'lunch' | 'dinner';
  window_from?: string;
  window_to?: string;
}

const pad = (n: number) => String(n).padStart(2, '0');

/** Data (YYYY-MM-DD), giorno ISO (1–7) e minuti correnti nel fuso indicato. */
export function localParts(now: Date, tz = PLATFORM_TZ) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', weekday: 'short', hour12: false,
  }).formatToParts(now);
  const g = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
  const day = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].indexOf(g('weekday')) + 1;
  return { date: `${g('year')}-${g('month')}-${g('day')}`, isoDay: day, minutes: (Number(g('hour')) % 24) * 60 + Number(g('minute')) };
}

export function addDaysIso(date: string, days: number) {
  const d = new Date(`${date}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export const isoDayOf = (date: string) => ((new Date(`${date}T12:00:00Z`).getUTCDay() + 6) % 7) + 1;

export function dateLabel(date: string) {
  return new Date(`${date}T12:00:00Z`).toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC' });
}

const WEEKDAYS: [RegExp, number][] = [
  [/\blunedi\b/, 1], [/\bmartedi\b/, 2], [/\bmercoledi\b/, 3], [/\bgiovedi\b/, 4], [/\bvenerdi\b/, 5], [/\bsabato\b/, 6], [/\bdomenica\b/, 7],
];

/** `text` deve essere già normalizzato (minuscolo, senza accenti). */
export function resolveWhen(text: string, now: Date, tz = PLATFORM_TZ): ResolvedWhen {
  const { date: today, isoDay, minutes } = localParts(now, tz);
  const out: ResolvedWhen = {};
  let date: string | undefined;

  if (/\b(stasera|questa sera|stanotte|sta sera)\b/.test(text)) {
    date = today;
    out.meal = 'dinner';
  } else if (/\bdopodomani\b/.test(text)) date = addDaysIso(today, 2);
  else if (/\bdomani\b/.test(text)) date = addDaysIso(today, 1);
  else if (/\boggi\b/.test(text)) date = today;
  else if (/\b(questo|nel|per il|il) (weekend|week end|fine settimana)\b|\bweekend\b|\bfine settimana\b/.test(text)) {
    date = isoDay === 6 || isoDay === 7 ? today : addDaysIso(today, 6 - isoDay);
  } else {
    for (const [re, d] of WEEKDAYS) {
      if (re.test(text)) {
        date = addDaysIso(today, (d - isoDay + 7) % 7);
        break;
      }
    }
  }

  if (/\b(a pranzo|pranzo|mezzogiorno)\b/.test(text)) out.meal = 'lunch';
  else if (/\b(a cena|cena|sera)\b/.test(text)) out.meal = 'dinner';

  const t = /\b(?:alle|ore|verso le|per le)\s*(\d{1,2})(?:[:.](\d{2}))?\b/.exec(text);
  if (t) {
    let h = Number(t[1]);
    const m = Number(t[2] ?? 0);
    // "alle 9" di sera in un contesto di cena → 21
    if (h >= 1 && h <= 11 && (out.meal === 'dinner' || /\bdi sera\b/.test(text))) h += 12;
    if (h <= 23 && m <= 59) {
      out.time = `${pad(h)}:${pad(m - (m % 15))}`;
      out.meal ??= h < 16 ? 'lunch' : 'dinner';
      date ??= h * 60 + m > minutes ? today : addDaysIso(today, 1);
    }
  }

  if (out.meal && !date) date = today;
  if (date) {
    out.date = date;
    out.label = dateLabel(date);
  }
  if (out.time) {
    const [h, m] = out.time.split(':').map(Number) as [number, number];
    const start = h * 60 + m;
    out.window_from = `${pad(Math.floor(start / 60))}:${pad(start % 60)}`;
    const end = Math.min(start + 90, 23 * 60 + 59);
    out.window_to = `${pad(Math.floor(end / 60))}:${pad(end % 60)}`;
  } else if (out.meal === 'lunch') {
    out.window_from = '12:00';
    out.window_to = '15:00';
  } else if (out.meal === 'dinner') {
    out.window_from = '19:00';
    out.window_to = '23:00';
  }
  return out;
}
