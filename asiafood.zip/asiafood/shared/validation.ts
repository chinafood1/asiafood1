// ─────────────────────────────────────────────────────────────
//  Schemi di validazione centralizzati (Zod), condivisi tra frontend e backend.
//  Il database resta l'ultima barriera (CHECK, RLS, RPC): questi schemi danno errori
//  chiari prima dell'invio e respingono input malformati sul server.
// ─────────────────────────────────────────────────────────────
import { z } from 'zod';

const trimmed = (min: number, max: number, msg: string) => z.string().trim().min(min, msg).max(max, `Massimo ${max} caratteri`);
export const emailSchema = z.string().trim().toLowerCase().max(254).email('Email non valida');
export const phoneSchema = z.string().trim().regex(/^\+?[0-9 ().-]{6,20}$/, 'Numero di telefono non valido');
export const passwordSchema = z.string().min(8, 'Almeno 8 caratteri').max(72, 'Massimo 72 caratteri')
  .regex(/[A-Za-z]/, 'Serve almeno una lettera').regex(/[0-9]/, 'Serve almeno un numero');
export const uuidSchema = z.string().uuid('Identificativo non valido');
export const orderNumberSchema = z.string().trim().toUpperCase().regex(/^AF-[0-9]{6}-[A-Z0-9]{4}$/, 'Numero ordine non valido (es. AF-261004-AB12)');
export const slugSchema = z.string().regex(/^[a-z0-9-]{1,120}$/, 'Slug non valido');

// ─── Auth ───
export const loginSchema = z.object({ email: emailSchema, password: z.string().min(1, 'Inserisci la password').max(200) });
export const signupSchema = z.object({
  name: trimmed(2, 80, 'Inserisci il tuo nome'),
  email: emailSchema,
  password: passwordSchema,
  terms: z.literal(true, { errorMap: () => ({ message: 'Accetta i termini per continuare' }) }),
});
export const resetSchema = z.object({ email: emailSchema });

// ─── Supporto / contatto ───
export const SUPPORT_CATEGORIES = ['order', 'reservation', 'account', 'privacy', 'restaurant', 'business', 'billing', 'rider', 'bug', 'other', 'coupon', 'points', 'payments', 'claim', 'menu', 'subscription', 'ads'] as const;
export const supportSchema = z.object({
  category: z.enum(SUPPORT_CATEGORIES),
  subject: trimmed(3, 140, 'Inserisci un oggetto'),
  description: trimmed(10, 4000, 'Descrivi il problema (almeno 10 caratteri)'),
  email: emailSchema.optional().or(z.literal('')),
  name: z.string().trim().max(80).optional(),
  order_number: orderNumberSchema.optional().or(z.literal('')),
  order_token: z.string().max(200).optional(),
});

// ─── Prenotazioni / recensioni / coupon ───
export const reservationSchema = z.object({
  guest_name: trimmed(1, 60, 'Inserisci il nome'),
  guest_surname: trimmed(1, 60, 'Inserisci il cognome'),
  guest_email: emailSchema.optional().or(z.literal('')),
  guest_phone: phoneSchema,
  party_size: z.number().int().min(1, 'Almeno 1 persona').max(50, 'Per gruppi oltre 50 persone contatta il locale'),
  reservation_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data non valida'),
  reservation_time: z.string().regex(/^\d{2}:\d{2}$/, 'Orario non valido'),
  notes: z.string().trim().max(500).optional(),
});
export const reviewSchema = z.object({
  rating_overall: z.number().int().min(1).max(5),
  rating_food: z.number().int().min(1).max(5).optional(),
  rating_service: z.number().int().min(1).max(5).optional(),
  rating_value: z.number().int().min(1).max(5).optional(),
  rating_atmosphere: z.number().int().min(1).max(5).optional(),
  title: z.string().trim().max(120).optional(),
  content: trimmed(20, 3000, 'Racconta la tua esperienza (almeno 20 caratteri)'),
});
export const couponClaimSchema = z.object({ coupon_id: uuidSchema, email: emailSchema.optional() });

// ─── Ordini / pagamenti (il prezzo lo ricalcola SEMPRE il server) ───
export const orderItemSchema = z.object({
  menu_item_id: uuidSchema,
  variant_id: uuidSchema.nullish(),
  quantity: z.number().int().min(1).max(20),
  options: z.array(uuidSchema).max(30).optional(),
  addons: z.array(z.object({ id: uuidSchema, quantity: z.number().int().min(1).max(10) })).max(30).optional(),
  notes: z.string().max(200).optional(),
});
export const refundSchema = z.object({
  order_id: uuidSchema,
  amount: z.number().positive('Importo non valido').max(100000).optional(),
  reason: trimmed(3, 300, 'Indica il motivo del rimborso'),
});

// ─── AI / CRM / Rider ───
export const aiMessageSchema = z.object({ message: trimmed(1, 1000, 'Scrivi un messaggio'), session_id: z.string().max(80).optional() });
export const riderLocationSchema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  accuracy: z.number().min(0).max(10000).optional(),
  heading: z.number().min(0).max(360).nullish(),
  speed: z.number().min(0).max(100).nullish(),
  recorded_at: z.string().datetime().optional(),
});
export const riderActionSchema = z.object({
  job_id: uuidSchema,
  action: z.enum(['to_restaurant', 'arrived_restaurant', 'picked_up', 'to_customer', 'arrived_customer', 'delivered', 'not_ready', 'customer_unavailable', 'problem', 'cancel']),
  code: z.string().regex(/^[0-9]{4,6}$/).optional(),
});

/** Primo messaggio d'errore per campo (per i form). */
export function fieldErrors<T>(schema: z.ZodType<T>, value: unknown): { ok: true; data: T } | { ok: false; errors: Record<string, string> } {
  const r = schema.safeParse(value);
  if (r.success) return { ok: true, data: r.data };
  const errors: Record<string, string> = {};
  for (const i of r.error.issues) {
    const k = i.path.join('.') || '_';
    errors[k] ??= i.message;
  }
  return { ok: false, errors };
}
