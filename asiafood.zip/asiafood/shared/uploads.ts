// ─────────────────────────────────────────────────────────────
//  Sicurezza upload: dimensione, estensione, MIME dichiarato E firma reale del file (magic bytes).
//  Blocca eseguibili, SVG/HTML (script), archivi. Usato dal frontend prima dell'upload;
//  lo Storage Supabase applica comunque limiti di MIME e dimensione per bucket.
// ─────────────────────────────────────────────────────────────
export type UploadKind = 'image' | 'document' | 'proof';

export const UPLOAD_RULES: Record<UploadKind, { mimes: string[]; exts: string[]; maxMb: number }> = {
  image: { mimes: ['image/jpeg', 'image/png', 'image/webp', 'image/avif'], exts: ['jpg', 'jpeg', 'png', 'webp', 'avif'], maxMb: 5 },
  document: { mimes: ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'], exts: ['pdf', 'jpg', 'jpeg', 'png', 'webp'], maxMb: 10 },
  proof: { mimes: ['image/jpeg', 'image/png', 'image/webp'], exts: ['jpg', 'jpeg', 'png', 'webp'], maxMb: 5 },
};

const BLOCKED_EXT = /\.(exe|msi|bat|cmd|com|scr|js|mjs|vbs|ps1|sh|jar|apk|dmg|html?|svg|xml|php|py|zip|rar|7z|dll)$/i;

/** Tipo reale dai primi byte del file. */
export function sniffMime(bytes: Uint8Array): string | null {
  const b = (i: number) => bytes[i] ?? -1;
  if (b(0) === 0xff && b(1) === 0xd8 && b(2) === 0xff) return 'image/jpeg';
  if (b(0) === 0x89 && b(1) === 0x50 && b(2) === 0x4e && b(3) === 0x47) return 'image/png';
  if (b(0) === 0x52 && b(1) === 0x49 && b(2) === 0x46 && b(3) === 0x46 && b(8) === 0x57 && b(9) === 0x45 && b(10) === 0x42 && b(11) === 0x50) return 'image/webp';
  if (b(4) === 0x66 && b(5) === 0x74 && b(6) === 0x79 && b(7) === 0x70) {
    const brand = String.fromCharCode(b(8), b(9), b(10), b(11));
    if (/^(avif|avis|mif1)$/.test(brand)) return 'image/avif';
    if (/^(heic|heix|hevc|mif1)$/.test(brand)) return 'image/heic';
  }
  if (b(0) === 0x25 && b(1) === 0x50 && b(2) === 0x44 && b(3) === 0x46) return 'application/pdf';
  if (b(0) === 0x4d && b(1) === 0x5a) return 'application/x-msdownload';
  if (b(0) === 0x7f && b(1) === 0x45 && b(2) === 0x4c && b(3) === 0x46) return 'application/x-elf';
  if (b(0) === 0x50 && b(1) === 0x4b) return 'application/zip';
  const head = String.fromCharCode(...bytes.slice(0, 256)).toLowerCase();
  if (/<(svg|html|script|!doctype|\?xml)/.test(head)) return 'text/markup';
  return null;
}

export interface UploadCheck {
  ok: boolean;
  error?: string;
  /** MIME reale rilevato (da usare come content-type dell'upload). */
  mime?: string;
  ext?: string;
}

export function checkUpload(file: { name: string; type: string; size: number }, head: Uint8Array, kind: UploadKind, maxMbOverride?: number): UploadCheck {
  const rule = UPLOAD_RULES[kind];
  const maxMb = maxMbOverride ?? rule.maxMb;
  const name = file.name.normalize('NFC');
  const ext = (name.split('.').pop() ?? '').toLowerCase();
  if (file.size <= 0) return { ok: false, error: 'Il file è vuoto.' };
  if (file.size > maxMb * 1024 * 1024) return { ok: false, error: `Il file supera ${maxMb} MB.` };
  if (BLOCKED_EXT.test(name) || /\.(exe|js|html?|svg|php)\./i.test(name)) return { ok: false, error: 'Tipo di file non consentito.' };
  if (!rule.exts.includes(ext)) return { ok: false, error: `Formato non supportato. Usa: ${rule.exts.filter((e) => e !== 'jpeg').join(', ').toUpperCase()}.` };
  const real = sniffMime(head);
  if (!real || !rule.mimes.includes(real)) return { ok: false, error: 'Il contenuto del file non corrisponde a un formato consentito.' };
  if (file.type && file.type !== real && !(file.type === 'image/jpg' && real === 'image/jpeg')) {
    // estensione/MIME dichiarati diversi dal contenuto reale: si usa il tipo reale (mai quello dichiarato)
  }
  return { ok: true, mime: real, ext: real === 'application/pdf' ? 'pdf' : real.split('/')[1]!.replace('jpeg', 'jpg') };
}

/** Nome file sicuro per lo storage (niente path traversal, caratteri speciali o nomi originali con dati personali). */
export function safeStorageName(ext: string): string {
  const rnd = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return `${rnd}.${ext.replace(/[^a-z0-9]/g, '').slice(0, 5) || 'bin'}`;
}
