// Fase 12 · Assegnazione stabile della variante di un esperimento (hash FNV-1a di chiave + id locale).
export function pickVariant(key: string, variants: string[], id: string): string {
  let h = 0x811c9dc5;
  for (const ch of `${key}:${id}`) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return variants[h % variants.length] ?? variants[0] ?? 'control';
}
