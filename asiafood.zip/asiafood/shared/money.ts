// ─────────────────────────────────────────────────────────────
//  Denaro: calcoli in centesimi interi (mai somme di float in euro).
//  Gli importi ufficiali (ordini, commissioni, rimborsi) li calcola il database in numeric;
//  qui solo stime/visualizzazione e conversioni verso Stripe (centesimi).
// ─────────────────────────────────────────────────────────────
export const DEFAULT_CURRENCY = 'EUR';

/** Euro (numero o stringa numeric del DB) → centesimi interi, arrotondamento commerciale. */
export function toCents(amount: number | string | null | undefined): number {
  const n = typeof amount === 'string' ? Number(amount) : amount ?? 0;
  if (!Number.isFinite(n)) return 0;
  // correzione per rappresentazioni binarie (es. 1.005 → 100.49999…)
  return Math.round(Math.round(n * 1000) / 10);
}

export const fromCents = (cents: number) => Math.round(cents) / 100;

/** Somma di importi in euro calcolata in centesimi. */
export const sumMoney = (amounts: (number | string | null | undefined)[]) => fromCents(amounts.reduce<number>((s, a) => s + toCents(a), 0));

/** Prezzo unitario × quantità, in centesimi. */
export const lineTotal = (unit: number | string, qty: number) => fromCents(toCents(unit) * Math.max(0, Math.trunc(qty)));

/** Percentuale su un importo (es. commissione), arrotondata al centesimo. */
export const percentOf = (amount: number | string, percent: number) => fromCents(Math.round((toCents(amount) * percent) / 100));
