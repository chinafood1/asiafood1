// ─────────────────────────────────────────────────────────────
//  Fase 13 · Logica pura della Business Intelligence (condivisa da app, demo e test).
//  Regola d'oro: nessun insight senza dati. Ogni funzione restituisce null / "insufficient"
//  quando il campione non basta, invece di produrre un numero plausibile ma falso.
//  Le formule sono SPECCHIO delle funzioni SQL (growth_health_score, growth_market_score,
//  growth_channel, growth_search_demand_score): i test verificano che coincidano.
// ─────────────────────────────────────────────────────────────

// ─── Periodi e confronti ─────────────────────────────────────
export type RangeKey = 'today' | 'yesterday' | '7d' | '30d' | '90d' | 'custom';

/** Date (YYYY-MM-DD, Europe/Rome) per un intervallo. `today` è la data locale di riferimento. */
export function rangeDates(key: RangeKey, today: string, custom?: { from: string; to: string }): { from: string; to: string } {
  const add = (d: string, n: number) => {
    const t = new Date(`${d}T12:00:00Z`);
    t.setUTCDate(t.getUTCDate() + n);
    return t.toISOString().slice(0, 10);
  };
  switch (key) {
    case 'today': return { from: today, to: today };
    case 'yesterday': return { from: add(today, -1), to: add(today, -1) };
    case '7d': return { from: add(today, -6), to: today };
    case '30d': return { from: add(today, -29), to: today };
    case '90d': return { from: add(today, -89), to: today };
    default: return custom && custom.from <= custom.to ? custom : { from: add(today, -29), to: today };
  }
}

/**
 * Variazione % rispetto al periodo precedente — SOLO quando matematicamente valida:
 * periodo precedente completo (tutti i giorni aggregati) e valore precedente > 0.
 */
export function pctChange(current: number | null | undefined, previous: number | null | undefined, previousComplete = true): number | null {
  if (!previousComplete || current == null || previous == null || !Number.isFinite(current) || !Number.isFinite(previous) || previous <= 0) return null;
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

export const rate = (num: number, den: number, minSample = 1): number | null => (den >= minSample && den > 0 ? Math.round((num / den) * 1000) / 10 : null);

// ─── Funnel ───────────────────────────────────────────────────
export interface FunnelStage { key: string; label: string; value: number }
export interface FunnelStep extends FunnelStage { pctOfFirst: number | null; pctOfPrev: number | null }

/** Percentuali per fase + drop-off più grande (solo se la fase di partenza ha un campione sufficiente). */
export function funnelSteps(stages: FunnelStage[], minSample: number): { steps: FunnelStep[]; largestDrop: { from: string; to: string; lostPct: number } | null; sufficient: boolean } {
  const first = stages[0]?.value ?? 0;
  const steps = stages.map((s, i) => ({
    ...s,
    pctOfFirst: i === 0 ? (first > 0 ? 100 : null) : rate(s.value, first),
    pctOfPrev: i === 0 ? null : rate(s.value, stages[i - 1]!.value),
  }));
  const sufficient = first >= minSample;
  let largestDrop: { from: string; to: string; lostPct: number } | null = null;
  if (sufficient) {
    for (let i = 1; i < stages.length; i++) {
      const prev = stages[i - 1]!.value;
      if (prev < minSample) break; // oltre questa fase i numeri sono troppo piccoli per un confronto onesto
      const lost = Math.round((1 - stages[i]!.value / prev) * 1000) / 10;
      if (!largestDrop || lost > largestDrop.lostPct) largestDrop = { from: stages[i - 1]!.label, to: stages[i]!.label, lostPct: lost };
    }
  }
  return { steps, largestDrop, sufficient };
}

// ─── Health score ristorante (interno, NON qualità del locale) ─
export const HEALTH_WEIGHTS = {
  completeness: 20, recent_login: 15, menu_updated: 10, reservation_response: 10, order_acceptance: 10, offers: 10, customer_actions: 15, subscription: 10,
} as const;
export type HealthComponents = Partial<Record<keyof typeof HEALTH_WEIGHTS, number>>;
export type HealthStatus = 'healthy' | 'needs_attention' | 'at_risk' | 'unknown' | 'not_claimed';

/** Specchio di public.growth_health_score: componenti 0..1, quelli assenti esclusi e pesi rinormalizzati. */
export function healthScore(c: HealthComponents): { score: number | null; status: HealthStatus } {
  let sum = 0;
  let w = 0;
  for (const [k, weight] of Object.entries(HEALTH_WEIGHTS)) {
    const v = c[k as keyof HealthComponents];
    if (typeof v === 'number' && Number.isFinite(v)) {
      sum += Math.max(0, Math.min(1, v)) * weight;
      w += weight;
    }
  }
  if (!w) return { score: null, status: 'unknown' };
  const score = roundHalfAwayFromZero((sum * 100) / w);
  return { score, status: score >= 70 ? 'healthy' : score >= 40 ? 'needs_attention' : 'at_risk' };
}

/** round() di Postgres su numeric: metà lontano da zero (Math.round arrotonda -0.5 verso +∞). */
export function roundHalfAwayFromZero(x: number): number {
  return Math.sign(x) * Math.round(Math.abs(x) + 1e-9);
}

// ─── Market Opportunity Score (trasparente) ───────────────────
export const MARKET_SCORE_KEYS = ['search_demand', 'supply_gap', 'lead_availability', 'organic_interest', 'commercial_interest'] as const;
export type MarketScoreKey = (typeof MARKET_SCORE_KEYS)[number];
export type MarketWeights = Record<MarketScoreKey, number>;
export const DEFAULT_MARKET_WEIGHTS: MarketWeights = { search_demand: 30, supply_gap: 25, lead_availability: 20, organic_interest: 15, commercial_interest: 10 };

/** Specchio di public.growth_market_score: ogni componente normalizzato sul massimo tra i candidati × peso (pesi normalizzati a 100). */
export function marketScore(inputs: Partial<Record<MarketScoreKey, number>>, max: Partial<Record<MarketScoreKey, number>>, weights: Partial<MarketWeights>) {
  const totW = MARKET_SCORE_KEYS.reduce((s, k) => s + Math.max(0, weights[k] ?? 0), 0);
  const breakdown = {} as Record<MarketScoreKey, number>;
  if (!totW) return { score: 0, breakdown };
  let score = 0;
  for (const k of MARKET_SCORE_KEYS) {
    const w = (Math.max(0, weights[k] ?? 0) * 100) / totW;
    const m = max[k] ?? 0;
    const part = m > 0 ? (w * Math.max(0, inputs[k] ?? 0)) / m : 0;
    breakdown[k] = roundHalfAwayFromZero(part);
    score += part;
  }
  return { score: roundHalfAwayFromZero(score), breakdown };
}

export const MARKET_SCORE_LABELS: Record<MarketScoreKey, string> = {
  search_demand: 'domanda di ricerca', supply_gap: 'supply gap', lead_availability: 'lead disponibili', organic_interest: 'interesse organico', commercial_interest: 'interesse commerciale',
};

/** "+32 domanda di ricerca, +25 supply gap…" — nessuna black box. */
export function explainScore(breakdown: Partial<Record<MarketScoreKey, number>>): string {
  return MARKET_SCORE_KEYS.filter((k) => (breakdown[k] ?? 0) > 0).map((k) => `+${breakdown[k]} ${MARKET_SCORE_LABELS[k]}`).join(', ') || 'nessun segnale';
}

// ─── Canali di acquisizione ───────────────────────────────────
export const GROWTH_CHANNELS = ['organic_google', 'direct', 'instagram', 'facebook', 'tiktok', 'restaurant_qr', 'referral', 'creator', 'paid_social', 'partner', 'email', 'other_social', 'other'] as const;
export type GrowthChannel = (typeof GROWTH_CHANNELS)[number];
export const GROWTH_CHANNEL_LABELS: Record<GrowthChannel, string> = {
  organic_google: 'Google organico', direct: 'Diretto', instagram: 'Instagram', facebook: 'Facebook', tiktok: 'TikTok', restaurant_qr: 'QR ristorante',
  referral: 'Invito (referral)', creator: 'Creator', paid_social: 'Social a pagamento', partner: 'Partner', email: 'Email', other_social: 'Altri social', other: 'Altro',
};

/** Specchio di public.growth_channel. */
export function growthChannel(channel: string | null | undefined, utmSource: string | null | undefined): GrowthChannel {
  const src = utmSource ?? '';
  switch (channel) {
    case 'organic_search': return 'organic_google';
    case 'paid_social': return 'paid_social';
    case 'qr': case 'restaurant_referral': return 'restaurant_qr';
    case 'influencer': return 'creator';
    case 'referral': return 'referral';
    case 'partner': return 'partner';
    case 'email': return 'email';
    case 'direct': return 'direct';
    case 'social':
      if (/^(ig|instagram)/.test(src)) return 'instagram';
      if (/^(fb|facebook|meta)/.test(src)) return 'facebook';
      if (/^(tt|tiktok)/.test(src)) return 'tiktok';
      return 'other_social';
    default: return 'other';
  }
}

// ─── Ricerca ─────────────────────────────────────────────────
/** Specchio di public.growth_normalize_query: null se contiene dati personali probabili o non è una ricerca. */
export function normalizeQuery(p: string | null | undefined): string | null {
  if (!p) return null;
  if (/@/.test(p) || /[0-9][0-9 .-]{4,}[0-9]/.test(p) || /https?:\/\//i.test(p)) return null;
  const v = p.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9' ]/g, ' ').replace(/\s+/g, ' ').trim();
  if (v.length < 2 || v.length > 60 || v.split(' ').length > 6) return null;
  return v;
}

/** Specchio di public.growth_search_demand_score. */
export function searchDemandScore(searches: number, maxSearches: number, zeroShare: number | null, repeatShare: number | null, convGap: number | null): number {
  const vol = maxSearches > 0 ? Math.log(1 + Math.max(searches, 0)) / Math.log(1 + Math.max(maxSearches, 1)) : 0;
  return Math.min(100, roundHalfAwayFromZero(40 * vol + 30 * (zeroShare ?? 0) + 15 * (repeatShare ?? 0) + 15 * (convGap ?? 0)));
}

// ─── Esperimenti ──────────────────────────────────────────────
export interface VariantStats { variant: string; users: number; conversions: number }
export interface ExperimentVerdict {
  rows: (VariantStats & { rate: number | null; upliftPct: number | null; z: number | null })[];
  winner: string | null;
  reason: string;
}

/** Test z su due proporzioni contro il controllo (prima variante). Nessun vincitore con campione insufficiente o differenza non significativa. */
export function experimentVerdict(variants: VariantStats[], minSample: number): ExperimentVerdict {
  const control = variants[0];
  const rows = variants.map((v) => ({ ...v, rate: v.users > 0 ? v.conversions / v.users : null, upliftPct: null as number | null, z: null as number | null }));
  if (!control) return { rows, winner: null, reason: 'Nessuna variante.' };
  const pc = control.users > 0 ? control.conversions / control.users : 0;
  for (const r of rows.slice(1)) {
    if (r.users > 0 && control.users > 0) {
      const pv = r.conversions / r.users;
      r.upliftPct = pc > 0 ? Math.round(((pv - pc) / pc) * 1000) / 10 : null;
      const p = (r.conversions + control.conversions) / (r.users + control.users);
      const se = Math.sqrt(p * (1 - p) * (1 / r.users + 1 / control.users));
      r.z = se > 0 ? Math.round(((pv - pc) / se) * 100) / 100 : null;
    }
  }
  const small = variants.filter((v) => v.users < minSample);
  if (small.length) return { rows, winner: null, reason: `Campione insufficiente: servono almeno ${minSample} utenti per variante (${small.map((s) => `${s.variant}: ${s.users}`).join(', ')}).` };
  const sig = rows.slice(1).filter((r) => r.z != null && Math.abs(r.z) >= 1.96);
  if (!sig.length) return { rows, winner: null, reason: 'Nessuna differenza statisticamente significativa (|z| < 1,96): nessun vincitore.' };
  const best = [...sig].sort((a, b) => (b.z ?? 0) - (a.z ?? 0))[0]!;
  if ((best.z ?? 0) > 0) return { rows, winner: best.variant, reason: `«${best.variant}» converte meglio del controllo (z = ${best.z}).` };
  return { rows, winner: control.variant, reason: `Il controllo converte meglio delle varianti (z = ${best.z}).` };
}

/** Assegnazione pesata e stabile (FNV-1a). A pesi uguali è identica a pickVariant (Fase 12): nessun utente cambia variante. */
export function pickWeighted(key: string, variants: string[], weights: number[] | undefined, id: string): string {
  let h = 0x811c9dc5;
  for (const ch of `${key}:${id}`) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  if (!weights || weights.length !== variants.length || weights.some((w) => !(w > 0)) || weights.every((w) => w === weights[0])) return variants[h % variants.length] ?? variants[0] ?? 'control';
  const tot = weights.reduce((s, w) => s + w, 0);
  let x = h % tot;
  for (let i = 0; i < variants.length; i++) {
    if (x < weights[i]!) return variants[i]!;
    x -= weights[i]!;
  }
  return variants[variants.length - 1]!;
}

// ─── Forecast (scenari su ipotesi, MAI risultati) ─────────────
export interface ForecastAssumptions { restaurants_contacted: number; claim_rate: number; trial_rate: number; trial_to_paid: number; arpa_cents: number }
export const FORECAST_SCENARIOS = ['conservative', 'base', 'growth'] as const;
export type ForecastScenario = (typeof FORECAST_SCENARIOS)[number];
export const FORECAST_LABELS: Record<ForecastScenario, string> = { conservative: 'Conservativo', base: 'Base', growth: 'Crescita' };

export function forecast(a: ForecastAssumptions) {
  const clamp = (x: number) => Math.max(0, Math.min(1, x));
  const claimed = Math.max(0, a.restaurants_contacted) * clamp(a.claim_rate);
  const trials = claimed * clamp(a.trial_rate);
  const paying = Math.round(trials * clamp(a.trial_to_paid));
  return { claimed: Math.round(claimed), trials: Math.round(trials), paying, mrr_cents: paying * Math.max(0, a.arpa_cents), label: 'Scenario basato su ipotesi — non è una previsione né un risultato garantito.' };
}

// ─── Performance ristorante: insight e raccomandazioni deterministici ─
export interface PerfCounts { impressions: number; views: number; menu_views: number; calls: number; whatsapp: number; directions: number; bookings: number; orders: number; coupon_redemptions: number; revenue_cents: number; reviews: number; favorites: number }
export interface RestaurantPerformance {
  restaurant: { id: string; name: string; slug: string; plan: string; has_cover: boolean; has_reservation: boolean; accepts_orders: boolean };
  completion: { score: number; missing: string[]; has_menu: boolean; has_hours: boolean } | null;
  periods: Record<'7' | '30', { current: PerfCounts; previous: PerfCounts; previous_complete: boolean }>;
  menu: { items: number; with_image: number; top: { id: string; name: string; has_image: boolean; views: number; add_to_cart: number; ordered: number }[] };
  offers_active: number;
  best_offer: { title: string; redemptions: number; claims: number } | null;
  repeat_customers_90d: number;
  reviews: { count: number; avg: number | null };
  freshness: string | null;
}

export const PERF_LABELS: Record<keyof PerfCounts, string> = {
  impressions: 'apparizioni nelle ricerche', views: 'visualizzazioni della scheda', menu_views: 'visualizzazioni del menu', calls: 'chiamate', whatsapp: 'messaggi WhatsApp',
  directions: 'richieste di indicazioni', bookings: 'prenotazioni', orders: 'ordini', coupon_redemptions: 'coupon utilizzati', revenue_cents: 'incasso ordini', reviews: 'recensioni', favorites: 'aggiunte ai preferiti',
};

export interface Insight { key: string; tone: 'good' | 'warn' | 'info'; text: string }

/** Insight azionabili, solo da fatti del proprio locale. Soglie minime per evitare percentuali su numeri minuscoli. */
export function restaurantInsights(p: RestaurantPerformance, minBase = 10): Insight[] {
  const out: Insight[] = [];
  const w = p.periods['7'];
  if (w && w.previous_complete) {
    for (const k of ['views', 'bookings', 'orders', 'directions'] as const) {
      const ch = pctChange(w.current[k], w.previous[k]);
      if (ch != null && w.previous[k] >= minBase && Math.abs(ch) >= 10) {
        out.push({ key: `trend_${k}`, tone: ch > 0 ? 'good' : 'warn', text: `${PERF_LABELS[k][0]!.toUpperCase()}${PERF_LABELS[k].slice(1)}: ${ch > 0 ? '+' : ''}${ch}% rispetto ai 7 giorni precedenti.` });
      }
    }
  }
  if (p.menu.items > 0) {
    const noImg = Math.round(((p.menu.items - p.menu.with_image) / p.menu.items) * 100);
    if (noImg >= 50) out.push({ key: 'menu_no_images', tone: 'warn', text: `Il ${noImg}% dei piatti del menu non ha una foto.` });
  }
  if (p.offers_active === 0) out.push({ key: 'no_offers', tone: 'info', text: 'Non hai offerte o coupon attivi.' });
  const top = p.menu.top.find((t) => t.views >= minBase);
  if (top) out.push({ key: 'top_dish', tone: 'info', text: `Il piatto più visto negli ultimi 30 giorni è «${top.name}» (${top.views} visualizzazioni).` });
  const low = p.menu.top.find((t) => t.views >= minBase * 2 && p.restaurant.accepts_orders && t.ordered * 10 < t.views);
  if (low) out.push({ key: 'viewed_not_ordered', tone: 'warn', text: `«${low.name}» è visto spesso (${low.views}) ma ordinato poco (${low.ordered}): verifica foto, descrizione e prezzo.` });
  if (p.completion && p.completion.score < 80) out.push({ key: 'completion', tone: 'warn', text: `Il profilo è completo al ${p.completion.score}%.` });
  return out;
}

export interface Recommendation { key: string; title: string; why: string; section: string }

/** Raccomandazioni pratiche basate su ciò che manca (mai garanzie di risultato). */
export function restaurantRecommendations(p: RestaurantPerformance): Recommendation[] {
  const miss = new Set(p.completion?.missing ?? []);
  const out: Recommendation[] = [];
  if (!p.restaurant.has_cover || miss.has('cover')) out.push({ key: 'cover', title: 'Aggiungi una foto di copertina', why: 'È la prima cosa che i clienti vedono nei risultati.', section: 'foto' });
  if (miss.has('hours')) out.push({ key: 'hours', title: 'Completa gli orari', why: 'Senza orari il locale non compare come "aperto ora".', section: 'orari' });
  if (miss.has('menu')) out.push({ key: 'menu', title: 'Pubblica il menu', why: 'Il menu permette ai clienti di scegliere prima di chiamare.', section: 'menu' });
  if (!p.restaurant.has_reservation) out.push({ key: 'reservations', title: 'Attiva le prenotazioni', why: 'I clienti possono prenotare senza telefonare.', section: 'reservations' });
  if (p.offers_active === 0) out.push({ key: 'offer', title: 'Crea una prima offerta', why: 'Le condizioni le decidi tu; l\'offerta compare nella sezione Offerte.', section: 'offerte' });
  if (p.menu.items > 0 && p.menu.with_image / p.menu.items < 0.5) out.push({ key: 'dish_photos', title: 'Aggiungi foto ai piatti principali', why: 'Aiuta a capire il piatto a colpo d\'occhio.', section: 'menu' });
  if (miss.has('social')) out.push({ key: 'social', title: 'Collega Instagram o il sito', why: 'Dà ai clienti un modo in più per conoscerti.', section: 'profilo' });
  return out;
}

// ─── Copilot del ristoratore (risponde SOLO dai dati del proprio locale) ─
export type CopilotIntent = 'performance' | 'bookings' | 'orders' | 'top_dish' | 'best_offer' | 'views' | 'improve' | 'contacts' | 'reviews' | 'unknown';

export const COPILOT_SUGGESTIONS = [
  'Come sta andando il mio profilo?', 'Quante prenotazioni ho ricevuto?', 'Qual è il piatto più visto?', 'Quale offerta funziona meglio?', 'Cosa posso migliorare?',
];

export function copilotIntent(q: string): CopilotIntent {
  const s = q.toLowerCase();
  if (/(concorren|altri ristoranti|competitor|vicin[io] di)/.test(s)) return 'unknown';
  if (/prenotaz/.test(s)) return 'bookings';
  if (/ordin/.test(s)) return 'orders';
  if (/piatt|menu/.test(s)) return 'top_dish';
  if (/offert|coupon|promo/.test(s)) return 'best_offer';
  if (/visualizz|visit|vist[oa] la scheda|quante persone/.test(s)) return 'views';
  if (/miglior|consigl|cosa (posso|devo)|aument/.test(s)) return 'improve';
  if (/chiamat|telefon|whatsapp|indicazion|contatt/.test(s)) return 'contacts';
  if (/recension|stelle|valutaz/.test(s)) return 'reviews';
  if (/andando|andamento|profilo|performance|come va|statistic/.test(s)) return 'performance';
  return 'unknown';
}

const fmtN = (n: number) => n.toLocaleString('it-IT');
const trend = (cur: number, prev: number, complete: boolean) => {
  const ch = pctChange(cur, prev, complete);
  return ch == null ? '' : ` (${ch > 0 ? '+' : ''}${ch}% rispetto ai 30 giorni precedenti)`;
};

/** Risposta deterministica: ogni numero viene dal payload autorizzato. Mai confronti con altri locali. */
export function copilotAnswer(question: string, p: RestaurantPerformance): { intent: CopilotIntent; answer: string; sources: string[] } {
  const intent = copilotIntent(question);
  const m = p.periods['30'];
  const c = m.current;
  const pv = m.previous;
  const src = ['Statistiche AsiaFood del tuo locale (ultimi 30 giorni)'];
  switch (intent) {
    case 'performance': {
      const actions = c.calls + c.whatsapp + c.directions + c.bookings + c.orders + c.coupon_redemptions;
      return { intent, sources: src, answer: `Negli ultimi 30 giorni la scheda di ${p.restaurant.name} è stata vista ${fmtN(c.views)} volte${trend(c.views, pv.views, m.previous_complete)}, `
        + `con ${fmtN(actions)} azioni dei clienti (chiamate, WhatsApp, indicazioni, prenotazioni, ordini, coupon). `
        + (c.impressions ? `È comparsa ${fmtN(c.impressions)} volte nei risultati di ricerca. ` : '')
        + (p.completion ? `Il profilo è completo al ${p.completion.score}%.` : '') };
    }
    case 'bookings':
      return { intent, sources: src, answer: p.restaurant.has_reservation || c.bookings
        ? `Hai ricevuto ${fmtN(c.bookings)} richieste di prenotazione negli ultimi 30 giorni${trend(c.bookings, pv.bookings, m.previous_complete)}.`
        : 'Le prenotazioni online non sono attive: puoi attivarle dalla sezione Prenotazioni.' };
    case 'orders':
      return { intent, sources: src, answer: p.restaurant.accepts_orders || c.orders
        ? `Negli ultimi 30 giorni hai ricevuto ${fmtN(c.orders)} ordini pagati per un totale di ${(c.revenue_cents / 100).toLocaleString('it-IT', { style: 'currency', currency: 'EUR' })}.`
        : 'Gli ordini online non sono attivi per il tuo locale.' };
    case 'top_dish': {
      const top = p.menu.top[0];
      return { intent, sources: ['Visualizzazioni dei piatti (ultimi 30 giorni)'], answer: top && top.views > 0
        ? `Il piatto più visto è «${top.name}» con ${fmtN(top.views)} visualizzazioni${top.ordered ? ` e ${fmtN(top.ordered)} porzioni ordinate` : ''}.`
        : 'Non ci sono ancora abbastanza visualizzazioni dei piatti per indicare il più visto.' };
    }
    case 'best_offer':
      return { intent, sources: ['Coupon del tuo locale (ultimi 90 giorni)'], answer: p.best_offer && p.best_offer.claims > 0
        ? `L'offerta con più risultati è «${p.best_offer.title}»: ${fmtN(p.best_offer.claims)} richieste e ${fmtN(p.best_offer.redemptions)} utilizzi.`
        : p.offers_active ? 'Le tue offerte non hanno ancora abbastanza richieste per un confronto.' : 'Non hai offerte attive: puoi crearne una dalla sezione Offerte.' };
    case 'views':
      return { intent, sources: src, answer: `La scheda è stata vista ${fmtN(c.views)} volte negli ultimi 30 giorni${trend(c.views, pv.views, m.previous_complete)}; il menu ${fmtN(c.menu_views)} volte.` };
    case 'contacts':
      return { intent, sources: src, answer: `Ultimi 30 giorni: ${fmtN(c.calls)} chiamate, ${fmtN(c.whatsapp)} WhatsApp e ${fmtN(c.directions)} richieste di indicazioni.` };
    case 'reviews':
      return { intent, sources: ['Recensioni pubblicate'], answer: p.reviews.count
        ? `Hai ${fmtN(p.reviews.count)} recensioni pubblicate con una media di ${p.reviews.avg?.toLocaleString('it-IT')} su 5.` : 'Non hai ancora recensioni pubblicate.' };
    case 'improve': {
      const rec = restaurantRecommendations(p).slice(0, 3);
      return { intent, sources: ['Completezza del profilo e impostazioni del locale'], answer: rec.length
        ? `Ecco cosa puoi fare: ${rec.map((r) => r.title.toLowerCase()).join('; ')}. Sono suggerimenti pratici, non garanzie di risultato.`
        : 'Il profilo è completo: continua ad aggiornare menu e offerte.' };
    }
    default:
      return { intent: 'unknown', sources: [], answer: 'Posso rispondere solo su dati del tuo locale: visualizzazioni, prenotazioni, ordini, piatti, offerte, contatti, recensioni e suggerimenti. Non ho dati su altri ristoranti.' };
  }
}

// ─── Admin AI Analyst: instradamento a strumenti CONTROLLATI (niente SQL) ─
export type AnalystTool = 'overview' | 'search' | 'acquisition' | 'churn' | 'restaurants' | 'markets' | 'alerts' | 'revenue' | 'costs' | 'funnels' | 'retention' | 'automations' | 'today' | 'review';

export const ANALYST_QUESTIONS: { q: string; tool: AnalystTool }[] = [
  { q: 'Quanti utenti abbiamo?', tool: 'overview' }, { q: 'Quanti utenti tornano?', tool: 'retention' }, { q: 'Quanti ristoranti pagano?', tool: 'revenue' },
  { q: 'Qual è l\'MRR?', tool: 'revenue' }, { q: 'Quanti ordini e prenotazioni?', tool: 'overview' }, { q: 'Da quali canali arrivano gli utenti?', tool: 'acquisition' },
  { q: 'Dove perdiamo conversioni?', tool: 'funnels' }, { q: 'Quali ristoranti sono a rischio?', tool: 'restaurants' }, { q: 'Quali trial scadono?', tool: 'churn' },
  { q: 'Quali ricerche non trovano risultati?', tool: 'search' }, { q: 'Quali campagne funzionano?', tool: 'acquisition' }, { q: 'Quanto costa l\'AI?', tool: 'costs' },
  { q: 'Quali automazioni sono attive?', tool: 'automations' }, { q: 'Cosa fare oggi?', tool: 'today' }, { q: 'Come va Taranto rispetto agli obiettivi?', tool: 'review' },
  { q: 'Quali città hanno più opportunità?', tool: 'markets' },
];

export function analystRoute(q: string): AnalystTool | null {
  const s = q.toLowerCase();
  if (/(delete|drop|update|insert|select |;|--)/.test(s)) return null; // mai SQL
  if (/oggi|priorit|cosa fare/.test(s)) return 'today';
  if (/taranto.*(obiettiv|target)|obiettiv|target/.test(s)) return 'review';
  if (/città|mercat|espansion|prossim/.test(s)) return 'markets';
  if (/zero|senza risultat|ricerc|domanda/.test(s)) return 'search';
  if (/trial|prova|disdett|churn|cancell/.test(s)) return 'churn';
  if (/rischio|ristoranti.*(salute|health)|health/.test(s)) return 'restaurants';
  if (/mrr|ricav|pagan|arpa|ltv|fattur/.test(s)) return 'revenue';
  if (/canal|campagn|sorgent|utm|acquisiz|cac/.test(s)) return 'acquisition';
  if (/cost|spesa|margin/.test(s)) return 'costs';
  if (/automazion/.test(s)) return 'automations';
  if (/perd|funnel|conversion/.test(s)) return 'funnels';
  if (/torna|retention|ritorn|coort/.test(s)) return 'retention';
  if (/alert|anomal|problem/.test(s)) return 'alerts';
  if (/utent|ordin|prenotaz|visite|gmv/.test(s)) return 'overview';
  return null;
}

// ─── CSV (aggregati, senza PII) ───────────────────────────────
export function toCsv(rows: Record<string, unknown>[], columns: { key: string; label: string }[]): string {
  const esc = (v: unknown) => {
    if (v == null) return '';
    const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
    // Protezione da formula injection nei fogli di calcolo
    const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
    return /[",;\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
  };
  return [columns.map((c) => esc(c.label)).join(';'), ...rows.map((r) => columns.map((c) => esc(r[c.key])).join(';'))].join('\n');
}

// ─── Etichette ────────────────────────────────────────────────
export const CHURN_REASONS = ['too_expensive', 'not_enough_results', 'too_complicated', 'missing_feature', 'business_closed', 'seasonal', 'competitor', 'temporary_pause', 'other'] as const;
export type ChurnReason = (typeof CHURN_REASONS)[number];
export const CHURN_REASON_LABELS: Record<ChurnReason | 'unknown', string> = {
  too_expensive: 'Troppo costoso', not_enough_results: 'Risultati insufficienti', too_complicated: 'Troppo complicato', missing_feature: 'Manca una funzione',
  business_closed: 'Attività chiusa', seasonal: 'Stagionalità', competitor: 'Usa un altro servizio', temporary_pause: 'Pausa temporanea', other: 'Altro', unknown: 'Non indicato',
};
/** Specchio di public.growth_churn_reason (codici storici della Fase 12 mappati). */
export function churnReason(p: string | null | undefined): ChurnReason | 'unknown' {
  const map: Record<string, ChurnReason> = {
    too_expensive: 'too_expensive', not_enough_results: 'not_enough_results', too_complicated: 'too_complicated', no_time: 'too_complicated', missing_feature: 'missing_feature',
    missing_features: 'missing_feature', business_closed: 'business_closed', closing: 'business_closed', seasonal: 'seasonal', competitor: 'competitor', using_other: 'competitor',
    temporary_pause: 'temporary_pause',
  };
  if (!p) return 'unknown';
  return map[p] ?? 'other';
}
