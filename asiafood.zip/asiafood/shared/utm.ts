// ─────────────────────────────────────────────────────────────
//  Fase 12 · UTM e canali di acquisizione (condiviso: browser, script, test).
//  Nessun dato personale: solo parametri di campagna e canale.
// ─────────────────────────────────────────────────────────────
import type { Channel } from '../src/types/launch';

export interface UtmParams { source: string; medium: string; campaign: string; content?: string | null }

/** Normalizza un valore UTM: minuscolo, solo [a-z0-9_.-], max 60 caratteri. */
export const cleanUtmValue = (v: string | null | undefined) => (v ?? '').trim().toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_.-]/g, '').slice(0, 60);

/** Aggiunge i parametri UTM a un URL (sostituisce quelli esistenti). */
export function buildUtmUrl(base: string, p: UtmParams): string {
  const url = new URL(base, 'https://placeholder.invalid');
  for (const [k, v] of [['utm_source', p.source], ['utm_medium', p.medium], ['utm_campaign', p.campaign], ['utm_content', p.content ?? '']] as const) {
    const c = cleanUtmValue(v);
    if (c) url.searchParams.set(k, c); else url.searchParams.delete(k);
  }
  return url.origin === 'https://placeholder.invalid' ? `${url.pathname}${url.search}${url.hash}` : url.toString();
}

/** Preset per i materiali di lancio (offline, QR, social). */
export const UTM_PRESETS: Record<string, UtmParams & { label: string }> = {
  restaurant_qr: { label: 'QR del ristorante (table card)', source: 'restaurant_qr', medium: 'offline', campaign: 'taranto_launch' },
  flyer_customer: { label: 'Volantino clienti', source: 'flyer', medium: 'offline', campaign: 'taranto_launch' },
  flyer_restaurant: { label: 'Volantino ristoratori', source: 'flyer_b2b', medium: 'offline', campaign: 'founding_restaurants' },
  poster: { label: 'Poster', source: 'poster', medium: 'offline', campaign: 'taranto_launch' },
  hotel_qr: { label: 'QR partner (hotel/B&B)', source: 'partner_qr', medium: 'partner', campaign: 'taranto_launch' },
  instagram_bio: { label: 'Instagram bio', source: 'instagram', medium: 'social', campaign: 'taranto_launch' },
  tiktok_bio: { label: 'TikTok bio', source: 'tiktok', medium: 'social', campaign: 'taranto_launch' },
  facebook_post: { label: 'Post Facebook', source: 'facebook', medium: 'social', campaign: 'taranto_launch' },
  creator: { label: 'Creator (link personale)', source: 'creator', medium: 'influencer', campaign: 'taranto_launch' },
  newsletter: { label: 'Email utenti (opt-in)', source: 'newsletter', medium: 'email', campaign: 'taranto_launch' },
  whatsapp_b2b: { label: 'WhatsApp ristoratori', source: 'whatsapp', medium: 'outreach', campaign: 'founding_restaurants' },
};

const SEARCH = /(^|\.)(google|bing|duckduckgo|yahoo|ecosia|qwant|yandex|baidu)\./i;
const SOCIAL = /(^|\.)(facebook|fb|instagram|tiktok|t\.co|twitter|x|linkedin|pinterest|youtube|threads|reddit|telegram|whatsapp)\.(com|me|co|net|org|it)$/i;

/**
 * Classifica il canale di arrivo. Priorità: parametri espliciti (UTM, invito, QR) > referrer.
 * `ownHost` evita di contare la navigazione interna come referral.
 */
export function classifyChannel(input: { utm_source?: string | null; utm_medium?: string | null; path?: string | null; referrer?: string | null; ownHost?: string | null; hasInvite?: boolean }): Channel {
  const src = cleanUtmValue(input.utm_source);
  const med = cleanUtmValue(input.utm_medium);
  const path = input.path ?? '';
  if (/^\/r\//.test(path) || src === 'restaurant_qr' || src === 'partner_qr' || med === 'qr') return 'qr';
  if (/^\/invite\//.test(path) || input.hasInvite) return 'referral';
  if (med === 'restaurant_referral' || src === 'restaurant_referral') return 'restaurant_referral';
  if (['cpc', 'paid', 'paid_social', 'ads'].includes(med)) return 'paid_social';
  if (med === 'influencer' || src === 'creator') return 'influencer';
  if (med === 'email' || src === 'newsletter') return 'email';
  if (med === 'partner') return 'partner';
  if (med === 'offline' || med === 'outreach') return 'offline';
  if (med === 'social' || ['instagram', 'facebook', 'tiktok'].includes(src)) return 'social';
  if (src) return 'other';
  let host = '';
  try {
    host = input.referrer ? new URL(input.referrer).hostname : '';
  } catch {
    host = '';
  }
  if (!host || (input.ownHost && host === input.ownHost)) return 'direct';
  if (SEARCH.test(host)) return 'organic_search';
  if (SOCIAL.test(host) || /instagram|facebook|tiktok/.test(host)) return 'social';
  return 'other';
}
