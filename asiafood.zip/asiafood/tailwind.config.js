/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#FAF8F5',
        cream: '#F3EFE9',
        line: '#E9E4DC',
        ink: {
          DEFAULT: '#16161A',
          soft: '#2A2A30',
          muted: '#6B6B73',
          faint: '#727279',
        },
        coral: {
          50: '#FFF1EF',
          100: '#FFE0DC',
          200: '#FFC1B9',
          400: '#FF7A6E',
          DEFAULT: '#CF3A2F',
          600: '#B8322A',
          700: '#A82C24',
        },
        leaf: '#237A55',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque Variable"', '"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['"Inter Variable"', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        '4xl': '2rem',
      },
      boxShadow: {
        card: '0 1px 2px rgba(22,22,26,0.04), 0 8px 24px -12px rgba(22,22,26,0.18)',
        lift: '0 2px 4px rgba(22,22,26,0.05), 0 18px 40px -16px rgba(22,22,26,0.28)',
        bar: '0 -1px 0 rgba(22,22,26,0.06), 0 -12px 32px -18px rgba(22,22,26,0.25)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-400px 0' },
          '100%': { backgroundPosition: '400px 0' },
        },
        pop: {
          '0%': { transform: 'scale(1)' },
          '40%': { transform: 'scale(1.25)' },
          '100%': { transform: 'scale(1)' },
        },
      },
      animation: {
        'fade-up': 'fade-up .45s cubic-bezier(.2,.7,.2,1) both',
        shimmer: 'shimmer 1.4s linear infinite',
        pop: 'pop .35s ease-out',
      },
    },
  },
  plugins: [],
};
