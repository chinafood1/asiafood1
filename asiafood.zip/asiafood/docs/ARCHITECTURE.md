# Architettura

```
Browser (React 18 + Vite PWA)                         Netlify
 ├─ pagine pubbliche (SEO, mappa, ricerca)             ├─ CDN statico (dist/, _redirects 301, header CSP/HSTS)
 ├─ area cliente / ristoratore / Rider / Admin         └─ Functions (Node 20)  ← server/platform/http.ts
 ├─ DataSource: supabaseSource | demoSource               /api/orders/*  /api/billing/*  /api/ai/chat  /api/logistics/action
 │   (demo escluso dal bundle con Supabase)               /api/health  /api/ready  /api/support
 └─ service worker (asset + immagini pubbliche)           cron: system · orders · logistics · engagement · billing · ai
            │ anon key + JWT utente                               │ service role (solo server)
            ▼                                                     ▼
                    Supabase: Postgres (RLS su tutte le tabelle, RPC SECURITY DEFINER, trigger di protezione),
                    Auth, Storage (bucket pubblico + 3 privati), Realtime (tabelle *_realtime senza dati sensibili),
                    Edge Function send-emails
            │                                                     │
       Stripe (Billing, PaymentIntent, Connect) · Mapbox/Google Maps (facoltativi) · provider AI · Turnstile · Sentry (facoltativo)
```

## Principi
1. **Il database è l’autorità**: prezzi, commissioni, stati, permessi e limiti sono decisi da funzioni SQL e policy RLS; il frontend non è mai fidato.
2. **Stesso contratto, due sorgenti**: `src/services/types.ts` (`DataSource`) è implementato da `supabaseSource` (produzione) e `demoSource` (DEMO in localStorage, regole speculari). Nelle build con Supabase `vite.config.ts` sostituisce il modulo DEMO con uno stub: il bundle iniziale passa da ~681 KB a ~322 KB (~94 KB gzip).
3. **Backend sottile e testabile**: gli handler (`server/*/handlers.ts`) ricevono le dipendenze (store, Stripe, logger, clock) e sono testati con il database reale in PGlite e uno Stripe simulato.
4. **Degradazione controllata**: ogni integrazione esterna ha un fallback (AI → dati, mappe → LiteMap, email/push → code, Stripe → errore esplicito, mai “pagato” senza webhook).

## Moduli (fasi)
| Fase | Modulo | Dove |
|---|---|---|
| 1–3 | Catalogo, ricerca, SEO, mappe, rivendicazioni, import | `src/pages`, `src/lib/maps`, migrazioni 0001–0010 |
| 4 | Menu, prenotazioni, offerte/coupon, statistiche, piani | 0011–0012 |
| 5 | SaaS B2B Stripe Billing | `server/billing`, 0013–0014, `docs/STRIPE_SETUP.md` |
| 6 | Assistente AI (database-first) | `server/ai`, `shared/ai`, 0015–0016, `docs/AI_ASSISTANT.md` |
| 7 | Recensioni, AsiaPoints, inviti, notifiche, campagne | `server/engagement`, 0017, `docs/ENGAGEMENT.md` |
| 8 | Ordini online, Stripe Connect | `server/orders`, 0018–0019, `docs/ORDERS.md` |
| 9 | Logistica Rider | `server/logistics`, 0020–0021, `docs/LOGISTICS.md` |
| 11 | Hardening, privacy, monitoring, lancio | `server/platform`, `shared/{validation,uploads,money,platform}`, 0022, questo documento e gli altri in `docs/` |
| 12 | Go-to-market Taranto: Launch Control, CRM, Partner Fondatori, QR kit, attribuzione, feedback, marketing | `src/pages/admin/launch`, `src/services/launch{Supabase,Demo}.ts`, `shared/{utm,experiment}.ts`, 0023–0024, `docs/launch/` |
| 13 | Business Intelligence & Growth Automation: aggregati giornalieri, dashboard /admin/growth, alert, automazioni, esperimenti, mercati, performance e Copilot del ristoratore | `src/pages/admin/growth`, `src/components/growth`, `src/services/growth{Supabase,Demo}.ts`, `shared/growth.ts`, 0025–0027, `docs/growth/` |

## Piattaforma (Fase 11)
- `server/platform/env.ts` — ambienti (`isProduction/isStaging/isDevelopment`) e validazione Zod delle variabili (solo nomi nei report).
- `server/platform/logger.ts` — log JSON con livelli e redazione; `http.ts` — request id, errori standard `{ error: { code, message, requestId } }`, rate limit, manutenzione; `cron.ts` — lock + registro job; `errorTracker.ts` — log interno + Sentry facoltativo; `handlers.ts` — health, ready, support, system-cron.
- `src/context/RuntimeConfigContext.tsx` — impostazioni pubbliche a runtime (manutenzione, beta, flag, dati legali).
- `src/lib/{consent,monitoring,errors,uploads,safeRedirect}.ts`, `src/components/platform/*` (banner cookie, aggiornamento PWA, offline, manutenzione, error boundary, Turnstile).
- `src/i18n` — italiano predefinito, struttura per l’inglese.

## Frontend: prestazioni
Code splitting per area (Admin, dashboard ristoratore, Rider, ordini, assistente, pagine legali/privacy), mappa e assistente caricati on-demand nella scheda locale, libreria QR, Sentry e web-vitals caricati solo quando servono, font self-hosted con preload dei soli sottoinsiemi latini, immagini con dimensioni esplicite e lazy loading (componente `SmartImage`). Budget e misure: [`PERFORMANCE.md`](PERFORMANCE.md).

## Dati e fusi orari
Timestamp sempre `timestamptz` (UTC nel database); calcoli di calendario (orari di apertura, promemoria, periodi delle metriche) nel fuso del locale/`Europe/Rome`; importi in `numeric(10,2)` nel database e in centesimi interi verso Stripe; stime nel browser con `shared/money.ts` (centesimi).
