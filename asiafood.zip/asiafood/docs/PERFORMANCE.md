# Prestazioni

## Budget

| Risorsa | Budget | Stato attuale | Controllo |
|---|---|---|---|
| JS iniziale (script d’ingresso + modulepreload di `index.html`, non compresso) | ≤ 900 KB | **Build di produzione (Supabase): 728 KB / 211 KB gzip** = chunk principale 337 KB (99 KB gz, Fase 12 inclusa; le pagine di lancio sono chunk separati) + React 164 KB (54 KB gz) + Supabase 227 KB (59 KB gz). Build DEMO: 1.131 KB (include il database DEMO, non va mai in produzione) | `production-check` (WARN oltre budget) |
| Chunk di pagina | ≤ 150 KB ciascuno | Admin, dashboard, Rider, ordini, assistente, legali: caricati on-demand | ispezione `dist/assets` |
| Font | solo sottoinsiemi latini precaricati (2 file woff2) | Inter + Bricolage variabili, self-hosted | — |
| Immagini | `width/height` espliciti, lazy sotto la piega, `srcset` 400/800/1200 | `SmartImage` (Unsplash e Storage Supabase se `VITE_SUPABASE_IMAGE_TRANSFORM=true`) | — |
| Core Web Vitals (p75, dati reali) | LCP ≤ 2,5 s · INP ≤ 200 ms · CLS ≤ 0,1 | **da misurare in produzione** (web-vitals, solo con consenso “Statistiche”, `/admin/system → Web Vitals`) | — |

## Misure di laboratorio (non sono dati reali di campo)

Build DEMO servita da `vite preview`, Chromium headless, profilo mobile (viewport 390×844, CPU rallentata 4×, rete ≈ 9 Mbps / 60 ms RTT). Script: misura LCP/CLS con `PerformanceObserver`, INP da un tap sintetico.

| Pagina | LCP | CLS | INP (tap) |
|---|---|---|---|
| `/` | 1.216 ms | 0 | 208 ms (al limite) |
| `/restaurants` | 1.012 ms | 0 | 80 ms |
| `/ristorante/kaizen-sushi-lab-taranto` | 1.008 ms | 0 | — |
| `/sushi/taranto` | 932 ms | 0,024 | 88 ms |
| `/map` | 1.316 ms | 0,003 | 80 ms |

Un secondo run dopo le ultime modifiche ha dato valori coerenti (LCP 940–1.304 ms, CLS ≤ 0,024, INP home 192 ms).

Limiti: rete locale, dati DEMO in localStorage (niente latenza Supabase), un solo run per pagina. **Non sono una garanzia** sui dati di campo: servono i dati reali (RUM interno + Search Console → Core Web Vitals) dopo il lancio.

Correzioni fatte in Fase 11 in base alle misure: CLS su `/restaurants` (0,153 → 0: gli slot sponsorizzati sono caricati insieme ai risultati e mostrati dopo il 3° risultato), CLS su pagine categoria×città (footer visibile durante il caricamento → `main` con altezza minima e riga del conteggio riservata), font self-hosted con preload, mappa/assistente/QR/Sentry/web-vitals caricati on-demand.

Da migliorare: INP della home al limite (208 ms in laboratorio con CPU 4×) → candidati: rinviare il calcolo delle sezioni sotto la piega, `content-visibility:auto` sulle griglie.

## Database
- Indici aggiunti in 0022 per le chiavi esterne e le query critiche (ordini per locale/stato, job di consegna, notifiche, audit, errori, ticket, consensi).
- Paginazione server-side per liste Admin (audit, ticket, privacy) con limite massimo 100.
- `scripts/ops/explain-critical.sql`: `EXPLAIN (ANALYZE, BUFFERS)` delle query critiche — **solo su staging** con dati di volume realistico (transazione con `statement_timeout` 15 s; `EXPLAIN ANALYZE` esegue davvero le query: non lanciarlo in produzione).

## Test di carico (piano, solo staging)

`scripts/load/k6-staging.js` (k6): ricerca 100 utenti virtuali, assistente AI 50 (con modello simulato o quota dedicata), 100 clienti che seguono un ordine, 50 Rider che inviano posizioni. Soglie: p95 < 800 ms, errori < 1 %.

```bash
BASE_URL=https://<deploy-preview>.netlify.app k6 run scripts/load/k6-staging.js
```

Regole: **mai contro la produzione**; avvisare Supabase/Netlify se il carico supera i limiti del piano; disattivare le email reali su staging; il test Rider usa account di prova. **Non ancora eseguito** (richiede lo staging): risultati da annotare in `/admin/launch-checklist`.

## Caching
- Asset con hash: `Cache-Control: public, max-age=31536000, immutable`; `sw.js`: `no-cache`; `sitemap*.xml`: 1 ora; `index.html`: rivalidazione standard Netlify.
- Service worker: precache degli asset; immagini pubbliche `CacheFirst` (30 giorni, max 200); **mai** cache di `/api/*`, Supabase REST/Auth/Storage privato o URL firmati (`NetworkOnly`).
- Configurazione pubblica a runtime ricaricata ogni 5 minuti; ricerca e mappa con cache in memoria per la sessione.
