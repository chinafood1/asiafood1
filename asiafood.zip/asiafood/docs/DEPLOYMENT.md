# Deploy, ambienti e operazioni pianificate

## 1. Ambienti

| | development | staging | production |
|---|---|---|---|
| Dove | PC locale (`npm run dev`) | Netlify **deploy preview / branch deploy** | Netlify **production** (branch `main`) |
| `APP_ENV` / `VITE_APP_ENV` | development | staging (impostato da `netlify.toml`) | production (impostato da `netlify.toml`) |
| Supabase | nessuno (DEMO) o progetto dev | **progetto dedicato `asiafood-staging`** | **progetto dedicato `asiafood-prod`** |
| Stripe | test | **test** (chiavi live rifiutate da `validateEnv`) | test durante la beta → live dopo i controlli |
| Indicizzazione | — | `robots.txt` → `Disallow: /` (generato in build) | normale |
| Dati | DEMO | copia anonimizzata o dati di prova | reali (`show_demo_data=false`, `npm run clean-demo-data`) |

Helper: `isProduction()`, `isStaging()`, `isDevelopment()` in `server/platform/env.ts` (backend) e `resolveAppEnv()` in `shared/platform/environment.ts` (condiviso). **Mai lo stesso database per staging e produzione.**

### Variabili su Netlify
Site configuration → Environment variables: per ogni variabile scegliere **scope** (Builds / Functions) e **contesti** (Production vs Deploy previews/Branch deploys) con valori diversi. Obbligatorie in produzione (verificate all’avvio da Zod, report solo con i nomi):

- Functions: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `APP_URL` (https), `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_MODE`, `ORDER_TOKEN_SECRET` (≥ 32 caratteri).
- Build: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_SITE_URL`, `VITE_STRIPE_PUBLISHABLE_KEY`.
- Consigliate: `TURNSTILE_SECRET_KEY` + `VITE_TURNSTILE_SITE_KEY`, `HEALTH_CHECK_TOKEN`, `IP_HASH_SALT`, `VAPID_*`, `AI_PROVIDER`/`AI_API_KEY`, `SENTRY_DSN`/`VITE_SENTRY_DSN`.
Elenco completo e commentato: `.env.example`.

## 2. Pipeline

1. Pull request → **GitHub Actions** (`.github/workflows/ci.yml`): `npm ci` → lint → typecheck → `npm run test:all` (≈ 1.300 controlli) → build → `production-check` (bundle, segreti, SEO, PWA, header) → `npm audit --omit=dev --audit-level=high`.
2. Netlify crea il **deploy preview** (staging) collegato al progetto Supabase di staging.
3. Merge su `main` consentito solo con CI verde (GitHub → Settings → Branches → *Require status checks: ci*). Netlify pubblica la produzione solo dal branch `main`.
4. Prima del primo go-live e dopo modifiche importanti: `npm run production-check -- --env=production --online` (con le variabili di produzione nella shell) e revisione di `/admin/launch-checklist`.

## 3. Migrazioni del database

- Mai modifiche manuali in produzione: ogni cambiamento è un file in `supabase/migrations/` con prefisso data progressivo (`YYYYMMDDNNNNNN_nome.sql`).
- Ordine: `supabase link --project-ref <staging>` → `supabase db push` → test su staging → `supabase link --project-ref <prod>` → **backup** → `supabase db push`.
- Le migrazioni della Fase 11 sono **additive** (nuove tabelle/funzioni, vincoli `NOT VALID` poi validati, grant più restrittivi).
- Rollback: Postgres non ha rollback automatico delle migrazioni applicate. Strategia: (1) migrazione correttiva “in avanti” (preferita); (2) per incidenti gravi, restore da backup/PITR (vedi DISASTER_RECOVERY). Rollback della 0022: `drop` delle tabelle/funzioni nuove e ripristino dei grant precedenti — da evitare perché riapre le vulnerabilità V-01…V-05.
- I test PGlite (`npm run test:*`) eseguono **tutte** le migrazioni reali a ogni run.

## 4. Operazioni pianificate (inventario)

| Job | Dove | Frequenza | Cosa fa | Lock |
|---|---|---|---|---|
| `system-cron` | Netlify scheduled function | ogni 15 min | Controlli di sistema per la launch checklist (env, health DB, dominio HTTPS, sitemap/robots), **retention** (ogni 6 h), **cancellazioni account** scadute (anonimizzazione + eliminazione Auth), job rimessi in coda dall’Admin, **manutenzione di lancio** 1×/giorno (`launch_daily_maintenance`: obiettivi, follow-up partner a rischio, fine beneficio Partner Fondatori, retention CRM) | sì |
| `orders-cron` | Netlify | ogni 5 min | Ordini non pagati scaduti, timeout di accettazione con rimborso, rimborsi in coda, carrelli abbandonati | sì |
| `logistics-cron` | Netlify | ogni minuto | Offerte ai Rider scadute, dispatch, avvisi, retention GPS (24 h), anonimizzazione consegne vecchie | sì |
| `engagement-cron` | Netlify | ogni 15 min | Promemoria prenotazioni (24 h / 2 h), scadenza coupon, richieste di recensione, campagne programmate (kill switch `campaigns_enabled`), scadenza punti, invio push in coda | sì |
| `billing-cron` | Netlify | ogni ora | Fine tolleranza pagamenti, fine periodo piani cancellati, scadenza piani manuali, avvisi “la prova sta per terminare” (trial reminders) | sì |
| `ai-cron` | Netlify | giornaliero | Conversazioni AI scadute, cache, utilizzo oltre 13 mesi | sì |
| `send-emails` | Supabase Edge Function | ogni minuto (Supabase Cron / `pg_cron`+`pg_net`) | Svuota `email_outbox` (header `x-cron-secret` se `EMAIL_CRON_SECRET` è impostato) | presa in carico per riga |

Ogni esecuzione Netlify passa da `scheduledJob()` (`server/platform/cron.ts`): **lock condiviso** nel database (`job_locks`, con scadenza), registro in `background_jobs` (stato, tentativi, errore), errori in `system_error_log`. Due istanze concorrenti: una esegue, l’altra viene saltata (testato). Retry controllato da `/admin/system` → Job falliti → “Riprova”.

## 5. Dominio di produzione

1. Netlify → Domain management → aggiungi `asiafood.it` (o il dominio scelto) e `www`.
2. DNS presso il registrar: `A @ → 75.2.60.5` (load balancer Netlify) oppure nameserver Netlify; `CNAME www → <sito>.netlify.app`.
3. **HTTPS**: certificato Let’s Encrypt automatico; attiva “Force HTTPS”.
4. **Canonico**: scegli una forma (consigliato senza `www`) come *primary domain*: Netlify reindirizza l’altra con 301. Imposta `VITE_SITE_URL` e `APP_URL` sulla forma canonica (canonical, sitemap, link email).
5. HSTS è già attivo (1 anno). Dopo 1–2 settimane senza problemi: aggiungi `preload` all’header e registra il dominio su hstspreload.org.
6. Aggiorna: Stripe (webhook endpoint `https://<dominio>/api/billing/webhook`, redirect Connect), Supabase Auth (Site URL e Redirect URLs), token Mapbox (URL restrictions), Turnstile (domini), Google Search Console (verifica + invio `sitemap.xml`).

## 6. Email: deliverability

Il provider non è ancora scelto (Resend / Brevo / SendGrid supportati). **Non inventare record DNS**: vanno copiati dal pannello del provider scelto. Checklist:
- **SPF**: un solo record TXT sul dominio mittente che include il provider (`v=spf1 include:<provider> ~all`).
- **DKIM**: i record CNAME/TXT generati dal provider (selettori propri).
- **DMARC**: iniziare con `v=DMARC1; p=none; rua=mailto:dmarc@<dominio>`, poi `quarantine`/`reject` dopo 2–4 settimane di report puliti.
- Mittente su sottodominio dedicato (es. `mail.asiafood.it`), `EMAIL_FROM` coerente, test con mail-tester.com.

## 7. Monitoraggio esterno (uptime)

Configura un servizio esterno (es. Better Stack, UptimeRobot, Checkly — piani gratuiti sufficienti per la beta):

| Monitor | URL | Atteso | Frequenza |
|---|---|---|---|
| Homepage | `https://<dominio>/` | 200, contiene “AsiaFood” | 1–3 min |
| API health | `https://<dominio>/api/health` | 200 e `"status":"ok"` (503 se il DB non risponde) | 1 min |
| Readiness (privato) | `https://<dominio>/api/ready` con header `X-Health-Token` | 200 `"ready":true` | 5 min |
| Supabase | `https://<ref>.supabase.co/rest/v1/` (header `apikey`) + status.supabase.com | 200 | 5 min |
| Checkout | `POST https://<dominio>/api/orders/create` con corpo vuoto | **4xx** (endpoint vivo e validazione attiva; mai creare ordini veri) · 5xx = allarme | 5 min |
Avvisi via email/Telegram; non per ogni errore: usa 2 fallimenti consecutivi. Soglie interne (errori/10 min, webhook falliti, pagamenti falliti, errori AI, dispatch) sono in `platform_settings` (`alert_*`) e visibili in `/admin/system`.
