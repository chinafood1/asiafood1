# Definizioni delle metriche (Fase 13)

Tutte le date sono giorni di calendario **Europe/Rome**. `growth_min_sample` (default 30) è il campione minimo sotto il quale tassi, drop-off e confronti non vengono mostrati.

## Utenti
| Metrica | Definizione |
|---|---|
| Utenti attivi | Utenti registrati (non Admin) con almeno un giorno in `user_activity_days` nel periodo. |
| Nuovi utenti | Profili cliente creati nel periodo. |
| Visite | Righe `acquisition_visits` (una per sessione di navigazione, anche senza consenso, nessun identificativo). |
| Sessioni | ID di sessione distinti negli eventi, **solo con consenso "Statistiche"** (somma dei giorni). |
| Ritorno | Un utente torna se ha un giorno di attività successivo al giorno di registrazione. D1 = il giorno dopo; D7 = entro 7 giorni; D30 = entro 30. |
| Coorti | Righe = settimana di registrazione (lunedì); colonne 0–4 = utenti attivi in quella settimana (esclusa la giornata di registrazione). Celle vuote = settimana non conclusa. |

## Funnel
- **Consumer (per sessione con consenso)**: Visita → Ricerca → Scheda ristorante → Intenzione → Conversione.
  Intenzione = indicazioni, chiamata, WhatsApp, piatto aperto, prenotazione iniziata, carrello/checkout, offerta vista, preferito, coupon richiesto.
  Conversione = prenotazione inviata o ordine pagato (+ indicazioni/chiamate solo se `growth_directions_as_conversion = true`).
  Il segnale `conversion` inviato dal client serve SOLO ad attribuire la conversione alla sessione; i totali vengono dalle tabelle.
- **Ritorno** (fase finale, unità diversa): utenti registrati con una conversione che hanno attività entro `growth_return_window_days` (30).
- **B2B (cumulativo)**: censiti → lead → contattati → hanno risposto → rivendicati → prova → attivati → paganti → ancora paganti dopo 30 giorni. Velocità = media dei giorni tra le fasi con numerosità `n`.
- Il **drop-off maggiore** è indicato solo se la fase di partenza ha almeno `growth_min_sample` unità.

## Conversione del periodo (Command Center)
`conversioni = prenotazioni inviate + ordini pagati + coupon utilizzati` (+ indicazioni/chiamate se abilitato) · `tasso = conversioni / visite` (solo con ≥ campione minimo di visite).

## Ristoranti
- **Conversione** = (indicazioni + chiamate + WhatsApp + prenotazioni + ordini + coupon utilizzati) / visualizzazioni della scheda.
- **Clienti che tornano** = utenti con ≥ 2 prenotazioni/ordini nello stesso locale in 90 giorni.
- **Impression** = apparizioni del locale nei risultati di ricerca registrati (`search_events.result_ids`, primi 20).
- **Health score interno (0–100)** — *non è un giudizio sulla qualità del ristorante*. Componenti 0..1 con pesi:
  completezza 20 · accesso recente 15 (≤7 gg = 1, ≤30 = 0,5) · menu aggiornato 10 (≤60 gg = 1, ≤180 = 0,5) · prenotazioni gestite 10 · ordini accettati 10 · offerte/coupon attivi 10 · azioni clienti 30 gg 15 (≥10 = 1, ≥1 = 0,5) · abbonamento 10 (pagante 1, prova 0,75, free 0,5, disdetta programmata 0,25, insoluto 0).
  I componenti non applicabili (nessuna prenotazione/ordine) sono esclusi e i pesi rinormalizzati. Stato: ≥70 In salute, 40–69 Da seguire, <40 A rischio; pagamento non riuscito ⇒ A rischio. Solo per locali rivendicati.
- **Segnali di rischio**: prova in scadenza (7 gg), pagamento non riuscito, nessun accesso da 30 gg, profilo < 60%, zero azioni in 30 gg, prenotazioni senza risposta, ≥ 3 ordini rifiutati e ≥ 30%.

## Ricavi e churn
- **MRR** = somma dei canoni mensili degli abbonamenti Stripe attivi nell'ambiente in uso (annuali /12). **ARR** = MRR × 12. **ARPA** = MRR / ristoranti paganti.
- **Churn rate** = ristoranti paganti persi nel periodo / ristoranti paganti all'inizio del periodo (stessa base).
- **MRR nuovo/perso** da `paid_started_at` / `ended_at`. **Espansione/contrazione** solo confrontando fotografie MRR **osservate** (giorno prima dell'inizio e ultimo giorno); altrimenti "non disponibile".
- **LTV** = ARPA / churn mensile medio (90 giorni) solo con ≥ 3 mesi di storico, base ≥ campione minimo e almeno una disdetta; altrimenti "Dati insufficienti".
- Motivi di disdetta standard: too_expensive, not_enough_results, too_complicated, missing_feature, business_closed, seasonal, competitor, temporary_pause, other (codici della Fase 12 mappati: no_time→too_complicated, missing_features→missing_feature, closing→business_closed, using_other→competitor).
- Ricavi per fonte: fatture di abbonamento pagate, commissioni/servizio ordini, sponsorizzazioni (spesa registrata delle campagne attive, cumulativa e dichiarata come tale), altro.

## Acquisizione
Canali di business da canale tecnico + `utm_source`: Google organico, Diretto, Instagram, Facebook, TikTok, QR ristorante, Invito, Creator, Social a pagamento, Partner, Email, Altri social, Altro. **First touch** = primo canale noto del browser (salvato solo con consenso); **last touch** = canale della sessione di iscrizione. **CAC** = costo registrato del canale / iscrizioni attribuite, solo se il costo esiste e le iscrizioni ≥ `cac_min_conversions` (5).

## Ricerca e supply gap
- Una ricerca è "senza risultati" se Esplora mostra 0 locali o l'assistente AI non propone ristoranti.
- **Convertita** = seguita da una scheda ristorante nella stessa sessione (con consenso) entro 30 minuti.
- **Search demand score** = 40 × volume (log, relativo al massimo) + 30 × quota senza risultati + 15 × sessioni che ripetono + 15 × gap di conversione.
- **Supply gap** (combinazioni comune × categoria o termine con ≥ `growth_supply_gap_min_searches`): 40 × domanda (log) + 40 × quota senza risultati + 20 × offerta scarsa (0 locali = 20, < 3 = 10).

## Mercati
**Market Opportunity Score** (0–100): per ogni componente `peso_normalizzato × valore / massimo tra le candidate`; pesi admin (`growth_market_weights`, default 30/25/20/15/10). Componenti (90 giorni): domanda di ricerca (comune della provincia o nome della città nel testo), supply gap (ricerche senza risultati + domanda non servita se < 5 locali), lead disponibili (lead CRM + locali censiti), interesse organico (utenti con comune nella provincia), interesse commerciale (rivendicazioni + lead che hanno risposto). La scomposizione è sempre mostrata.

## Esperimenti
Tasso = conversioni / utenti assegnati; uplift relativo al controllo; test z su due proporzioni. Vincitore solo se ogni variante ha ≥ `growth_experiment_min_sample` (100) utenti e |z| ≥ 1,96.

## Costi
AI = token × tariffe configurate (stima); incasso = commissione reale degli ordini, stima solo se `growth_payment_fee_pct` è impostato; costi manuali ripartiti per giorni di sovrapposizione. Margine di contribuzione **approssimato** = ricavi piattaforma − costi variabili (AI, incasso, email, push, mappe).
