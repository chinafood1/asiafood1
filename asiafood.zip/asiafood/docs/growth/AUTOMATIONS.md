# Automazioni (Fase 13)

Tabelle: `automation_rules` (enabled, requires_approval, consent_required, config, interval, owner, last_run_at, next_run_at, failure_count, last_error), `automation_runs` (ogni esecuzione: schedule/manual/dry_run, esito, elementi, errore), `automation_items` (output deduplicato per regola: task creati, bozze da approvare, notifiche).

## Controlli
- **Kill switch** globale (`automation_kill_switch`): blocca esecuzioni pianificate e manuali.
- Ogni regola è disattivabile; **5 errori consecutivi ⇒ disattivazione automatica** + alert dopo 3.
- **Prova a vuoto**: conta i candidati senza scrivere nulla.
- Vincolo DB: `draft_user_message` ⇒ `requires_approval AND consent_required` (non modificabile).
- Approvazione: il consenso marketing viene **ricontrollato al momento dell'invio**; senza consenso l'elemento diventa `skipped`. L'invio è una notifica in-app (nessuna email/push massiva).
- Audit: modifiche regole, esecuzioni manuali, kill switch, invii approvati.

## Regole predefinite
| Regola | Azione | Default |
|---|---|---|
| Affinità categoria (≥ 3 preferiti Sushi) → offerte attive | bozza utente | disattiva |
| Carrello abbandonato (2–48 h) | bozza utente | disattiva |
| Prenotazione abbandonata | **non disponibile** (avvio tracciato senza utente) | non attivabile |
| Utenti dormienti (30–90 gg) + nuovi locali nel territorio | bozza utente | disattiva |
| Profilo ristorante < 60% | task CRM | attiva |
| Prova in scadenza (3 gg) | task CRM (+ notifica titolare opzionale) | attiva |
| Pagamento non riuscito | task CRM | attiva |
| Lead senza risposta (4 gg) | task CRM con bozza di follow-up (non inviata) | attiva |
| Demo completata | task CRM prossimo passo | attiva |
| Metà prova | task CRM | attiva |
| Win-back (terminati ≤ 90 gg) | task CRM (mai riattivazioni senza consenso) | attiva |

Le automazioni lavorano solo su locali reali (mai DEMO). Nessuna automazione contatta clienti o ristoratori, spende budget, cambia prezzi o lancia campagne.
