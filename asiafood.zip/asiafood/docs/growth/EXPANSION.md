# Espansione: prossimo mercato (Fase 13)

`/admin/expansion/next-market` confronta le città candidate (`growth_expansion_candidates`, default Bari, Lecce, Brindisi, Matera, Foggia): domanda, offerta, supply gap, lead, utenti organici, interesse commerciale, opportunità SEO (ricerche senza risultati), readiness e **Market Opportunity Score** scomposto (vedi METRICS.md). Nessuna città è scelta automaticamente.

## Start Research (mai "Launch automatically")
Crea (se manca) il mercato in stato **planned** per la provincia, la checklist del playbook e 5 task: Discovery, Research, lead CRM, analisi copertura, preparazione SEO. Discovery/Research Agent (Fase 10) **non sono implementati**: i task lo dichiarano e sono manuali. Idempotente. Se la provincia non è nei dati di riferimento (es. Matera, MT) l'operazione è rifiutata con un messaggio chiaro.

## Playbook
Fasi: Ricerca → Dati → Vendite → SEO → Partner → Utenti beta → Lancio; ogni attività è spuntabile.

## Readiness (criteri espliciti)
- **Dati**: ≥ 20 ristoranti attivi e ≥ 60% con profilo ≥ 60%.
- **Vendite**: ≥ 20 lead e ≥ 10 contattati.
- **SEO**: almeno un comune con ≥ 3 ristoranti (pagine indicizzabili).
- **Operatività**: almeno un'attività completata in Partner e Utenti beta.
- **Pronto al lancio**: tutti i precedenti + checklist "Lancio" completa. Il lancio resta una decisione umana.

## Knowledge loop
`growth_learnings` (categoria, evidenze, confidenza bassa/media/alta). Le evidenze di Taranto (canale di outreach con più risposte, prova→pagante, QR, sorgenti di iscrizione) sono calcolate ma non salvate: l'Admin decide cosa registrare. Nel playbook dei nuovi mercati gli apprendimenti compaiono come "da verificare, non da copiare".
