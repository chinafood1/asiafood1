# Tassonomia eventi canonica (Fase 13)

Gli eventi storici **non sono stati rinominati** (nessuna migrazione distruttiva). La tabella `growth_event_taxonomy` mappa i nomi storici sui 24 nomi canonici e indica la **fonte di verità**; la vista `growth_events` (solo backend) li unifica per le aggregazioni.

| Canonico | Fonte | Nomi storici / tabella |
|---|---|---|
| session_started | app_events | session_started (nuovo, una volta per sessione) |
| search_performed | search_events | search, near_me_search, map_area_search |
| restaurant_viewed | analytics_events | restaurant_view, view |
| menu_viewed | analytics_events | menu_view, click_menu, menu_item_view |
| favorite_added | domain | favorites (+ app event favorite_added per il funnel) |
| map_opened | app_events | map_open, map_view |
| directions_clicked | analytics_events | directions_click, click_directions |
| phone_clicked | analytics_events | phone_click, click_phone |
| whatsapp_clicked | analytics_events | whatsapp_click, click_whatsapp |
| offer_viewed | analytics_events | offer_view, coupon_reveal |
| coupon_claimed | domain | coupon_claims |
| coupon_redeemed | domain | coupon_claims.status = redeemed |
| reservation_started | analytics_events | reservation_start, click_reservation |
| reservation_completed | domain | reservations (richiesta inviata; visita avvenuta = status completed) |
| cart_created | domain | carts |
| add_to_cart | analytics_events | add_to_cart |
| checkout_started | analytics_events | checkout_started |
| payment_completed | domain | orders.payment_status = paid (webhook, mai il client) |
| order_completed | domain | orders.status = completed |
| review_created | domain | reviews |
| referral_shared | app_events | referral_shared (nuovo, nessun destinatario) |
| referral_qualified | domain | referrals.qualified_at |
| subscription_started | domain | billing_activity |
| subscription_cancelled | domain | billing_activity |

## Metadati standard
Aggiunti dal client a ogni evento: `device_type` (mobile/tablet/desktop), `utm_source`, `utm_campaign`, `channel` della sessione. Il `restaurant_id` è colonna; `city_id`/`market_id`/categoria sono derivati dal ristorante nelle aggregazioni. **Nessun dato personale**: i filtri server rimuovono chiavi come email, telefono, nome, testo, messaggio, query, coordinate.

## Ricerche (`search_events`)
Testo normalizzato (minuscole, senza accenti, ≤ 60 caratteri, ≤ 6 parole); **scartato** se contiene `@`, numeri lunghi (telefoni) o link. Slug di comune/categoria validati; `result_ids` solo ristoranti esistenti (max 20); sessione solo con consenso; nessun utente/IP/posizione. Conservazione grezza `growth_search_log_days` (90); gli aggregati giornalieri anonimi restano.
