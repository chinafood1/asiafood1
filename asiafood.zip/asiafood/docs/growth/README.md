# Growth — Business Intelligence & Growth Automation (Fase 13)

Obiettivo: rispondere in pochi minuti, **solo con dati reali**, alle domande operative di AsiaFood.
Dove i dati non bastano l'interfaccia mostra **"Dati insufficienti"** invece di un numero fragile.

## Dove si trova

| Domanda | Pagina |
|---|---|
| Quanti utenti abbiamo, quanti ristoranti pagano, MRR, ordini/prenotazioni, cosa fare oggi | `/admin/growth` (Command Center + brief "Oggi") |
| Dove perdiamo conversioni, quanti tornano, coorti, segmenti | `/admin/growth/funnels` |
| Quali ristoranti convertono meglio / rischiano di abbandonare | `/admin/growth/restaurants` |
| Churn, trial in scadenza, motivi di disdetta | `/admin/growth/churn` |
| MRR, ARR, ARPA, LTV (solo con storico), fonti di ricavo | `/admin/growth/revenue` |
| Canali, campagne UTM, first/last touch, CAC | `/admin/growth/acquisition` |
| Ricerche, zero risultati, supply gap (domanda senza offerta) | `/admin/growth/search` |
| Offerte, piatti, AI, referral, AsiaPoints, recensioni | `/admin/growth/engagement` |
| Feedback di prodotto e supporto | `/admin/growth/voice` |
| Mercati, readiness, città candidate | `/admin/growth/markets` · `/admin/expansion/next-market` |
| Taranto: target vs risultati | `/admin/growth/taranto-review` |
| Alert e anomalie | `/admin/growth/alerts` |
| Automazioni (kill switch, approvazioni, storico) | `/admin/growth/automations` |
| Esperimenti A/B con guardrail | `/admin/growth/experiments` |
| Report settimanale executive | `/admin/growth/reports` |
| Task da insight e knowledge base | `/admin/growth/tasks` |
| Costi e unit economics | `/admin/growth/costs` |
| Scenari (Conservativo / Base / Crescita) su ipotesi | `/admin/growth/forecast` |
| Domande in linguaggio naturale (strumenti controllati) | `/admin/growth/analyst` |
| Freschezza, backfill, soglie | `/admin/growth/data` |
| Ristoratore: risultati del proprio locale | `/dashboard/restaurants/:id/performance` |
| Ristoratore: Business Copilot | `/dashboard/restaurants/:id/copilot` |

## Architettura

- **Migrazioni** `0025_growth_core` (tassonomia, ricerche, aggregati, job), `0026_growth_intel` (dashboard), `0027_growth_ops` (mercati, alert, automazioni, esperimenti, report, costi, performance, RLS/grant).
- **Aggregati giornalieri** (`daily_platform_metrics`, `daily_market_metrics`, `daily_restaurant_metrics`, `daily_acquisition_metrics`, `daily_search_metrics`) calcolati da `growth_compute_day(day)`: idempotente (delete + insert del giorno). `growth_backfill(from, to)` (Admin/backend, max 400 giorni). `growth_computed_days` registra freschezza e se l'MRR è **osservato** (giorno recente) o **ricostruito** (backfill).
- **Realtime vs batch**: oggi viene ricalcolato al massimo ogni 5 minuti quando un Admin apre una dashboard (`growth_refresh_today`); `growth_hourly` (aggregato di oggi, alert, automazioni dovute) e `growth_daily` (ieri definitivo, giorni mancanti degli ultimi 7, pulizia ricerche grezze, report settimanale) girano da `system-cron` con gate di rate limit.
- **Logica pura condivisa** in `shared/growth.ts` (health score, market score, significatività esperimenti, funnel, forecast, insight, Copilot, instradamento Analyst, CSV). Le formule SQL equivalenti sono verificate per parità in `npm run test:growth`.
- **DEMO**: `src/services/growthDemo.ts` calcola gli stessi indicatori al volo dai dati del browser.

## Regole non negoziabili

- Nessun insight inventato: ogni numero viene da una tabella o da un evento; percentuali solo sopra `growth_min_sample`; confronti % solo se il periodo precedente è interamente aggregato e > 0.
- Nessuna esecuzione automatica di contatti commerciali, spesa, prezzi, campagne o lanci di mercato. "Start Research" ≠ "Launch".
- Messaggi agli utenti: **bozze** con approvazione umana e consenso marketing ricontrollato all'invio (vincolo nel DB).
- Esperimenti su prezzi pagati, consenso privacy, sicurezza o accessibilità critica: revisione di un **secondo** Admin prima dell'avvio. Nessun vincitore con campione insufficiente o differenza non significativa (|z| < 1,96).
- LTV, K-factor, CAC, costo per conversione assistita: mostrati solo con dati sufficienti; mai ROI dichiarati.
- Admin AI Analyst e Copilot: nessun SQL arbitrario; il Copilot vede solo il payload autorizzato del proprio locale (nessun dato sui concorrenti).
- Export CSV solo di aggregati, senza dati personali, con protezione da formula injection.

Vedi anche: [METRICS.md](./METRICS.md), [EVENTS.md](./EVENTS.md), [AUTOMATIONS.md](./AUTOMATIONS.md), [EXPANSION.md](./EXPANSION.md).
