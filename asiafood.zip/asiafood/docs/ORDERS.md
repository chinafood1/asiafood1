# Ordini online (Fase 8): takeaway e delivery

Marketplace di ordini per i ristoranti AsiaFood: carrello, checkout, pagamento Stripe, terminale del ristorante,
tracciamento in tempo reale, rimborsi, commissioni e dashboard Admin.

- Migration: `supabase/migrations/20261002000018_orders_enums.sql`, `20261002000019_orders.sql`
- Backend: `server/orders/*` + `netlify/functions/orders-*.mts`
- Test: `npm run test:orders` (151 scenari: veri handler, vere migration, Stripe simulato con firme webhook reali)

> **Stripe è in modalità TEST.** Il passaggio a LIVE non avviene mai automaticamente: serve `STRIPE_MODE=live`,
> chiavi `sk_live_…`, un nuovo endpoint webhook live e ristoranti con Stripe Connect LIVE completato.

---

## 1. Flusso del pagamento

```
Cliente            Browser                      /api/orders/create (server)              Stripe                 Webhook
───────            ───────                      ───────────────────────────              ──────                 ───────
carrello   ──►  POST items, tipo, indirizzo,
                coupon, contatti, idempotency
                                         ──►  order_quote_core: prezzi, sconti,
                                              consegna, commissione, totale (DB)
                                              order_create → AF-YYMMDD-XXXX
                                              status pending_payment
                                              PaymentIntent (idempotente)      ──►  pi_… (metadata: order_id,
                                                                                      restaurant_id, environment)
                ◄── client_secret, token ospite
Payment Element ── confirmPayment ─────────────────────────────────────────────►  payment_intent.succeeded ──►
                                                                                                     order_payment_event:
                                                                                                     amount check, paid,
                                                                                                     pending_restaurant,
                                                                                                     notifiche
```

- Il browser **non** decide mai prezzi, sconti, consegna, commissione, totale, stato del pagamento o proprietà del ristorante.
- L'ordine diventa "pagato" **solo** con il webhook `payment_intent.succeeded` (o con *Resync payment* dell'Admin, che legge Stripe dal server).
  Se l'importo incassato non coincide con il totale, l'ordine riceve il flag di rischio `amount_mismatch`.
- Nessun dato di carta tocca AsiaFood: il Payment Element invia i dati direttamente a Stripe.
- Metadata Stripe: solo `order_id`, `restaurant_id`, `environment`.
- Idempotenza: chiave per tentativo di checkout (`idempotency_key`) + chiave Stripe `asiafood-order-pi-<order_id>-<importo>`; gli eventi webhook
  sono deduplicati per `event.id`.
- Ordini non pagati: annullati dopo `order_unpaid_expiry_minutes` (30) dallo scheduler, che annulla anche il PaymentIntent.

### Modalità di incasso (`payment_mode`)
| Modalità | Quando | Come |
|---|---|---|
| `connect` | Il ristorante ha un account Stripe Connect Express con `charges_enabled` | *Destination charge*: `transfer_data.destination` = conto del ristorante, `application_fee_amount` = commissione + costo di servizio |
| `platform_test` | Solo in TEST e solo con `marketplace_platform_collection_test = true` | La piattaforma incassa l'ordine di prova (nessun trasferimento) |
| `demo` | Modalità DEMO senza Supabase | Pagamento simulato nel browser, nessun addebito |

Senza Connect attivo (e fuori dal caso `platform_test`) il ristorante **non** riceve ordini: "Ordini online in arrivo".

## 2. Webhook

Stesso endpoint della fatturazione: **`https://<dominio>/api/billing/webhook`** (`STRIPE_WEBHOOK_SECRET`).
Aggiungi a quell'endpoint gli eventi:

- `payment_intent.succeeded`, `payment_intent.payment_failed`, `payment_intent.canceled`, `payment_intent.processing`
- `charge.refunded`, `charge.refund.updated`
- `refund.created`, `refund.updated`, `refund.failed`
- `charge.dispute.created`
- `account.updated` (stato di Stripe Connect)

Gli eventi dei *Connected accounts* possono arrivare su un secondo endpoint: in quel caso imposta anche
`STRIPE_CONNECT_WEBHOOK_SECRET` (la firma viene provata con entrambi i segreti).

In locale: `stripe listen --forward-to localhost:8888/api/billing/webhook` con `netlify dev`.

**Recupero:** se un webhook non arriva, Admin → Ordini → dettaglio → **Resync pagamento** rilegge PaymentIntent e rimborsi da Stripe.
Lo scheduler `orders-cron` (ogni 5 minuti) scade gli ordini non pagati, gestisce il timeout di accettazione (`order_accept_timeout_minutes`, 20:
ordine annullato e rimborsato) ed elabora i rimborsi in coda.

## 3. Carte di prova (Stripe TEST)

| Carta | Esito |
|---|---|
| `4242 4242 4242 4242` | Pagamento riuscito |
| `4000 0025 0000 3155` | Richiede autenticazione 3D Secure |
| `4000 0000 0000 0002` | Rifiutata (`card_declined`) |
| `4000 0000 0000 9995` | Fondi insufficienti |
| `4000 0000 0000 0259` | Riuscito, poi contestazione (dispute) |

Qualsiasi data futura e CVC a 3 cifre. In DEMO le prime tre carte (4242…, 0002, 9995) sono simulate senza Stripe.

## 4. Stripe Connect (pagamenti ai ristoranti)

1. Stripe Dashboard → **Connect** → attiva Connect (modalità test) e scegli account **Express**.
2. Branding della piattaforma (nome, icona, colore) in Connect → Settings.
3. Il ristoratore apre `/dashboard/restaurants/:id/payouts` → **Configura pagamenti**: il server crea l'account Express
   (`accounts.create`) e un link di onboarding (`accountLinks.create`). Dati bancari e d'identità vengono inseriti **solo su Stripe**.
4. Al ritorno lo stato si aggiorna (webhook `account.updated` o **Aggiorna stato**). "Dashboard Stripe" apre il login link Express.

AsiaFood non raccoglie IBAN né documenti e non trasferisce denaro fuori da Stripe Connect.

## 5. Commissioni

- Base di calcolo: **subtotale − sconti + consegna** (il costo di servizio è separato).
- `platform_fee = base × percentuale + quota fissa` (globale in `platform_settings`, override per ristorante in `restaurant_commission_settings`).
- Snapshot sull'ordine (`commission_percent`, `commission_fixed`, `platform_fee`, `restaurant_gross`, `restaurant_net_estimated`):
  cambiare la commissione non modifica gli ordini esistenti.
- Costo di servizio al cliente: disattivato per default (`service_fee_enabled = false`, importo 0,99 €).
- Nessun calcolo fiscale: `tax_total` resta `null`; la ricevuta dell'ordine non è una fattura.

## 6. Rimborsi

- Totali o parziali, **mai oltre quanto pagato** (`amount_paid − amount_refunded`).
- Chi: Admin, owner/manager del ristorante (entro `order_restaurant_refund_days`, 14 giorni), automatici su rifiuto
  (`order_auto_refund_on_reject`), annullamento Admin e timeout di accettazione.
- Coda: riga `order_refunds` (`pending`) → il server chiama `stripe.refunds.create` (con `reverse_transfer` e `refund_application_fee` per Connect)
  → `charge.refunded` / `charge.refund.updated` aggiornano stato e importi. Ogni passaggio è in `order_events`.

**Test manuale:** paga con 4242, accetta dal terminale, poi *Rimborso* di 5 € → in Stripe compare il refund, l'ordine passa a
"Rimborsato in parte" e il cliente riceve la notifica.

## 7. Metriche (Admin → Marketplace)

- **GMV** = somma dei totali degli ordini con pagamento `paid` o `partially_refunded` e stato non in (`rejected`, `cancelled`, `refunded`, `pending_payment`).
  Mostrato anche al netto dei rimborsi.
- **AOV** = GMV / ordini validi.
- **Ricavi piattaforma** = (`platform_fee` + `service_fee`) × (1 − rimborsato/pagato) sugli ordini **completati**; quelli ancora in corso sono "in maturazione".
- **Tasso rimborsi** = importo rimborsato / importo pagato.
- **Funnel**: eventi e sessioni distinte (`menu_item_view` → `add_to_cart` → `cart_view` → `checkout_started` → `payment_started` → `payment_success`).
  Gli eventi `payment_*`, `order_*` e `abandoned_cart` sono scritti solo dal server.

## 8. Sicurezza

- Tabelle ordini senza accesso diretto dal client: letture tramite RPC `security definer` (`order_view`, `order_track`, `my_orders`,
  `restaurant_orders`, `admin_orders`), scritture tramite funzioni server-only.
- Ospiti: accesso a `/orders/AF-…` **solo** con numero + token (`?t=`), HMAC-SHA256 con `ORDER_TOKEN_SECRET`; nel DB solo `sha256(token)`.
  Tentativi falliti limitati (`order_track_failures`). Il numero d'ordine da solo non basta.
- Ristoranti: vedono nome, telefono e indirizzo solo per gli ordini attivi o delle ultime 24 ore; mai email o push endpoint.
- Staff: `orders.view` / `orders.manage` (terminale); `refund.request` solo owner/manager.
- Rate limit per utente/IP (hash), max 5 ordini non pagati per email, flag di rischio (`amount_mismatch`, `payment_failures`, `dispute`, più quelli calcolati alla creazione).
- Nessuna cancellazione fisica: stati `cancelled` / `refunded` e audit in `order_events`.

## 9. Configurazione manuale (checklist)

1. Applica le migration (`supabase db push`) e rigenera il seed se serve.
2. Netlify → variabili Functions: `STRIPE_SECRET_KEY` (sk_test_…), `STRIPE_WEBHOOK_SECRET`, `STRIPE_MODE=test`, `ORDER_TOKEN_SECRET`,
   `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `APP_URL`; facoltativi `STRIPE_CONNECT_WEBHOOK_SECRET`, `MAPBOX_GEOCODING_TOKEN`.
3. Frontend: `VITE_STRIPE_PUBLISHABLE_KEY` (pk_test_…).
4. Stripe: eventi webhook del punto 2, Connect Express attivo.
5. Supabase: Realtime attivo su `order_realtime` (la migration lo aggiunge alla publication), Edge Function `send-emails`
   con `ORDER_TOKEN_SECRET` uguale a quello di Netlify.
6. Admin → Marketplace: commissione, costo di servizio, eventualmente `marketplace_platform_collection_test` per i primi test.
7. Ristorante: *Impostazioni ordini* (tipi, minimi, zone, orari), *Pagamenti ordini* (Connect), menu con varianti/extra/scelte.

## 10. Fuori scope

Rete di rider e GPS, carrello multi-ristorante, portafoglio o cashback in denaro, dark kitchen, prezzi dinamici, fatturazione fiscale.
