# Disaster recovery e continuità del servizio

Obiettivi per la beta (da rivedere al lancio pubblico): **RPO** ≤ 24 h (backup giornaliero; ≤ pochi minuti con PITR), **RTO** ≤ 4 h per il ripristino del database, ≤ 30 min per il frontend.

## 1. Backup

| Livello | Come | Retention | Stato |
|---|---|---|---|
| Backup automatici Supabase | Dashboard → Database → Backups. Giornalieri sui piani **Pro** e superiori (7 giorni; 14 su Team, 30 su Enterprise). Il piano Free **non** ha backup scaricabili. | 7–30 giorni | **Da verificare sul progetto di produzione** (checklist `backup_enabled`, critico) |
| Point-in-Time Recovery | Add-on PITR (Pro+): ripristino a un minuto preciso | 7+ giorni | Consigliato prima del lancio pubblico |
| Export manuale (offsite) | `DATABASE_URL=… ./scripts/ops/backup-db.sh backups/` → `pg_dump` formato custom compresso + SHA-256; nessuna credenziale nello script | settimanale, conserva 4 settimane + 1 al mese | Da pianificare (es. prima di ogni migrazione) |
| Storage (foto, documenti) | Non incluso nei backup del database: sincronizza i bucket con `supabase storage` / rclone verso uno storage cifrato in UE | settimanale | Da configurare |
| Codice e configurazione | Git (GitHub) + `netlify.toml`; variabili d’ambiente documentate in `.env.example` (i **valori** in un password manager del team) | — | ✓ |

I dump contengono dati personali: cifrarli (age/gpg) prima di spostarli, accesso ristretto, cancellazione secondo retention. Mai committarli (`.gitignore`: `backups/`, `*.dump`).

## 2. Test di restore (obbligatorio)

Un backup non testato non è un backup. Almeno **una volta prima della beta** e poi **trimestralmente**:

1. Scarica l’ultimo backup (Dashboard → Backups → Download) oppure esegui `backup-db.sh` sulla produzione.
2. Ripristina su **staging**: `STAGING_DATABASE_URL=… PRODUCTION_PROJECT_REF=<ref prod> ./scripts/ops/restore-staging.sh backups/<file>.dump` (rifiuta l’URL di produzione e chiede conferma scritta).
3. Verifica: conteggi (`restaurants`, `orders`, `reviews`), login di un utente di test, apertura di una scheda, `npm run production-check -- --env=staging --online`, `/admin/system` senza errori.
4. Annota data, dimensione, **durata** e anomalie in `/admin/launch-checklist` → “Restore testato su staging”.
5. Per il restore con PITR: Dashboard → Database → Backups → Point in time → scegli il minuto → conferma (il progetto resta non disponibile durante l’operazione).

## 3. Scenari

| Scenario | Impatto | Degrado automatico | Azioni |
|---|---|---|---|
| **Database / Supabase non raggiungibile** | Nessun dato nuovo, login impossibile | `/api/health` → 503 `degraded`; il frontend mostra errori comprensibili; la PWA mostra i contenuti già in cache (asset e immagini) | 1) status.supabase.com; 2) manutenzione **non attivabile** (è nel DB): comunicare sui canali social; 3) se corruzione/errore umano: restore PITR su staging → verifica → restore produzione; 4) dopo il ripristino: `/admin/system` (job, webhook da rielaborare) |
| **Stripe non disponibile** | Nessun nuovo pagamento/abbonamento | Il backend risponde `STRIPE_UNAVAILABLE` → “Il pagamento non è disponibile in questo momento. Riprova tra poco.” **Nessun ordine viene considerato pagato senza webhook** | Kill switch “Nuovi ordini online” se il disservizio è lungo; al ritorno Stripe ritenta i webhook (idempotenza `stripe_events`); controllare webhook falliti in `/admin/system` e la sezione Stripe |
| **Mappe (Mapbox/Google) giù** | Mappa non disponibile | Mappa integrata leggera (LiteMap) senza provider; ricerca ed elenco funzionano | Nessuna azione urgente; eventualmente `VITE_MAPS_PROVIDER=none` e redeploy |
| **AI giù** | Assistente senza modello | Risposte deterministiche dai dati (fallback) e ricerca normale | Kill switch “Assistente AI” se gli errori superano la soglia; controllare quota/chiave del provider |
| **Email giù** | Conferme via email in ritardo | Le email restano in `email_outbox` (pending) e partono al ritorno del provider; notifiche in-app e ordini continuano | Controllare `/admin/system` → Email; cambiare provider (`EMAIL_PROVIDER`) se necessario |
| **Push giù** | Nessuna notifica push | Notifiche in-app e ordini continuano; push marcate “failed” senza blocchi | Verificare chiavi VAPID; kill switch campagne se serve |
| **Netlify giù** | Sito e API non raggiungibili | — | netlifystatus.com; in emergenza pubblicare `dist/` (build locale) su un altro hosting statico **solo** frontend in modalità manutenzione; le funzioni server richiedono Netlify (o porting) |
| **Deploy difettoso** | Errori dopo un rilascio | L’avviso “È disponibile un aggiornamento” evita versioni bloccate | Netlify → Deploys → **Publish** del deploy precedente (rollback istantaneo del frontend e delle funzioni); le migrazioni DB non si annullano: correzione in avanti |
| **Compromissione account/segreti** | — | — | SECURITY.md § 8 (rotazione chiavi, revoca sessioni, audit, notifica 72 h) |
| **Cancellazione accidentale di dati** | — | Trigger impediscono DELETE fisici su ristoranti con storico, profili, log di audit | PITR/restore su staging, estrazione dei soli dati persi, reimportazione controllata |

## 4. Modalità degradata — principi (verificati)
- AI offline → ricerca normale funziona (fallback deterministico, test `test:ai`).
- Mappa offline → elenco e ricerca funzionano.
- Push/email offline → l’ordine prosegue (code in uscita, test `test:engagement`).
- Stripe offline → **mai** ordine pagato senza conferma Stripe (`test:orders`), messaggio chiaro all’utente.
- Offline sul dispositivo → avviso; checkout e pagamenti bloccati; azioni critiche del Rider solo online (le sole azioni “sicure” vanno in coda).

## 5. Contatti e ruoli
Responsabile tecnico: [DA COMPLETARE] · Backup/rotazione chiavi: [DA COMPLETARE] · DPO/consulente privacy: [DA COMPLETARE] · Supporto Supabase/Stripe/Netlify: pannelli dei rispettivi account (credenziali nel password manager del team).
