# Formato di import dei ristoranti

Il file può essere caricato da **Admin → Importa** (`/admin/import`) oppure con lo script:

```bash
npm run import -- percorso/file.json                     # simulazione con report (non scrive)
npm run import -- percorso/file.csv --apply              # scrive (serve SUPABASE_SERVICE_ROLE_KEY)
npm run import -- file.json --apply --on-duplicate=merge  # decide cosa fare con i duplicati
npm run import -- file.json --offline                     # prova senza database (dati locali)
```

Opzioni dello script: `--apply`, `--offline`, `--on-duplicate=skip|merge|update|create` (default `skip`),
`--publish` (default: i nuovi locali restano in **bozza**), `--default-status=unverified|partially_verified|verified`,
`--report=report.json`.

Modelli pronti: [`public/templates/ristoranti-template.csv`](../public/templates/ristoranti-template.csv) ·
[`public/templates/ristoranti-template.json`](../public/templates/ristoranti-template.json) (scaricabili anche dalla pagina di import).

---

## Regole sui dati (vincolanti)

1. **Solo fonti pubbliche verificabili**: Google Business Profile / Google Maps, sito ufficiale, pagina Facebook o profilo Instagram ufficiali, directory pubbliche attendibili.
2. **Dato non verificabile = campo vuoto (`null`)**. Mai inserire valori “plausibili” (telefoni, orari, prezzi, indirizzi).
3. Ogni record dovrebbe avere `source_url` e `source_name`. Senza fonte il record resta `unverified`.
4. **Immagini**: `logo_url` / `cover_url` vengono importati **solo** se `image_rights_confirmed = true`, cioè se avete il diritto di usarle (fornite dal titolare o con licenza). Altrimenti vengono scartate e la scheda usa un segnaposto grafico.
5. **Testi**: non copiare descrizioni da Google o dai siti dei locali. Se serve, scrivere una breve descrizione originale basata su fatti (tipo di cucina, servizi).
6. Nessuno scraping: i dati si raccolgono manualmente o, in futuro, tramite le API ufficiali (Google Places), rispettandone i termini.

---

## Formati

**JSON**: un array di oggetti, oppure `{ "restaurants": [ … ] }`.
**CSV**: prima riga con le intestazioni. Separatore `,`, `;` o tabulazione (rilevato automaticamente), UTF-8, virgolette per i campi con separatori.
Nel CSV le liste (categorie, servizi) si separano con `|` (es. `Sushi|Japanese|All You Can Eat`).

Esempio JSON minimo:

```json
{
  "name": "…",
  "address": "…",
  "city": "Taranto",
  "province": "Taranto",
  "region": "Puglia",
  "latitude": null,
  "longitude": null,
  "phone": null,
  "whatsapp": null,
  "website": null,
  "instagram": null,
  "facebook": null,
  "categories": ["Sushi", "Japanese"],
  "is_all_you_can_eat": false,
  "source_name": "…",
  "source_url": "https://…",
  "last_verified_at": "2026-09-26"
}
```

---

## Campi

Le intestazioni sono accettate in inglese o in italiano (colonna “alias”). Colonne sconosciute vengono ignorate con un avviso.

| Campo | Alias | Obbl. | Formato / note |
|---|---|:-:|---|
| `name` | nome, insegna | ✔ | Max 120 caratteri |
| `city` | comune, citta | ✔ | Nome o slug di un comune **attivo** (es. `Martina Franca`, `san-giorgio-ionico`, `Taranto (TA)`). Comuni non gestiti → errore |
| `province` | provincia | | Solo controllo di coerenza (nome o sigla) |
| `region` | regione | | Informativo |
| `address` | indirizzo | | Via e numero civico |
| `postal_code` | cap | | 5 cifre |
| `latitude`, `longitude` | lat/lng | | Entrambe o nessuna; devono cadere in Italia; avviso se a più di 25 km dal comune |
| `phone` | telefono | | Normalizzato in `+39 …` |
| `whatsapp` | | | Normalizzato in sole cifre con prefisso (`39…`) |
| `email` | mail | | |
| `website` | sito, sito_web | | `https://` aggiunto se manca |
| `instagram`, `facebook`, `tiktok` | | | Handle (`@nome`) o URL |
| `categories` | categorie, cucina | | Lista. Accetta nomi IT/EN e sinonimi: Sushi, Japanese/Giapponese, Chinese/Cinese, Thai, Korean/Coreano, Poke, Ramen, Asian Fusion, Asian Street Food, All You Can Eat, Bubble Tea, Asian Bakery, Asian Grocery |
| `is_all_you_can_eat` | ayce | | `true/false`, `sì/no`, `1/0`. La categoria “All You Can Eat” lo imposta automaticamente |
| `ayce_lunch_price`, `ayce_dinner_price`, `ayce_weekend_price` | | | Numero (virgola o punto) |
| `average_price` | prezzo_medio | | Numero |
| `price_range` | fascia_prezzo | | 1–4 oppure `€`…`€€€€` |
| `has_delivery`, `has_takeaway`, `has_reservation` | delivery, asporto, prenotazione | | Booleani |
| `reservation_url` | | | URL |
| `services` | servizi | | Lista (es. `wifi|parcheggio|dehors`) |
| `short_description` | descrizione_breve | | Max 160 caratteri (troncata) |
| `description` | descrizione | | Testo originale |
| `source_name` | fonte | consigliato | Es. “Google Business Profile”, “Sito ufficiale” |
| `source_url` | url_fonte | consigliato | URL pubblico della fonte |
| `source_type` | tipo_fonte | | `google_business`, `official_website`, `facebook`, `instagram`, `directory`, `owner`, `admin`, `import`, `other` (dedotto dall’URL se assente) |
| `external_id` | id_esterno | | ID nella fonte (usato per la deduplicazione insieme a `source_name`) |
| `google_place_id` | place_id | | Univoco: blocca i duplicati. Predisposto per l’integrazione Google Places |
| `data_status` | stato_dati | | `verified`, `partially_verified`, `unverified`, `outdated` (anche in italiano). `claimed` non è importabile. `verified` richiede `source_url` e `last_verified_at`, altrimenti diventa `partially_verified` |
| `last_verified_at` | verificato_il | | ISO (`2026-09-26`) o `26/09/2026`. Mai nel futuro |
| `is_temporarily_closed`, `is_permanently_closed` | chiuso_temporaneamente, chiuso_definitivamente | | Booleani |
| `logo_url`, `cover_url` | logo, cover | | Importati solo con `image_rights_confirmed = true` |
| `image_rights_confirmed` | diritti_immagini | | Booleano |
| `notes` | note | | Note interne di verifica (non pubbliche) |

Orari e menu non si importano in questa versione: si inseriscono dall’editor (o dal titolare dopo la rivendicazione).

---

## Deduplicazione

Ogni riga viene confrontata con i ristoranti già presenti **negli stessi comuni** e con le righe precedenti del file.
Punteggio (0–100):

| Segnale | Punti |
|---|---|
| Stesso `google_place_id`, oppure stesso `external_id` + `source_name` | 100 (certo) |
| Stesso telefono o WhatsApp | +60 |
| Stesso sito (esclusi domini generici come facebook.com, instagram.com, google.com, tripadvisor…) | +50 |
| Stesso nome nello stesso comune (≥ 95%) | +55 |
| Nome molto simile (≥ 85%) nello stesso comune / in altro comune | +40 / +15 |
| Nome simile (≥ 70%) nello stesso comune | +25 |
| Indirizzo molto simile (≥ 80%) | +30 |
| Coordinate a meno di 50 m / 150 m | +30 / +15 |

≥ 100 **certo** · ≥ 80 **molto probabile** · ≥ 50 **possibile**. Esempio: nome + indirizzo molto simili = 70 → possibile duplicato.

Le righe con un possibile duplicato hanno come proposta **Ignora**: nulla viene creato automaticamente. L’Admin sceglie per ogni riga (o in blocco):

- **Ignora**: nessuna scrittura.
- **Aggiorna esistente**: i valori non vuoti del file sovrascrivono quelli della scheda; le categorie vengono sostituite.
- **Unisci**: completa solo i campi vuoti della scheda, aggiunge categorie e fonte, non sovrascrive nulla.
- **Crea comunque**: nuova scheda (slug reso univoco).

Protezioni: le schede **rivendicate** non vengono mai sovrascritte (“Aggiorna” diventa “Unisci”), lo stato `claimed` non viene mai toccato e **nessun locale viene eliminato** dall’import. Lo slug (URL SEO) di una scheda esistente non cambia.

Ogni import registra un lotto in `import_batches` (riepilogo ed errori) e la fonte in `restaurant_sources`.
