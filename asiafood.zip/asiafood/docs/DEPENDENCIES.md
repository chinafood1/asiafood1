# Dipendenze: audit di sicurezza e licenze

Aggiornato alla v0.1.0-beta. Ricontrollare a ogni rilascio (`npm audit --omit=dev`, eseguito anche in CI con soglia `high`).

## Runtime (finiscono nel bundle o nelle Functions)

| Pacchetto | Versione | Licenza | Dove | Note |
|---|---|---|---|---|
| react / react-dom | 18.3.1 | MIT | browser | |
| react-router-dom | 6.30.6 | MIT | browser | vedi advisory sotto |
| @supabase/supabase-js | 2.117.x | MIT | browser + server | |
| @stripe/stripe-js | 7.10.x | MIT | browser | caricato solo al pagamento |
| stripe | 22.6.x | MIT | Functions | chiave segreta solo lato server |
| web-push | 3.6.7 | **MPL-2.0** | Functions | copyleft debole a livello di file: nessun obbligo finché non si modificano i suoi file; non incluso nel bundle browser |
| zod | 3.25.x | MIT | browser + server | validazione |
| supercluster | 8.0.1 | ISC | browser | cluster mappa |
| lucide-react | 0.460.0 | ISC | browser | icone |
| qrcode-generator | 1.4.4 | MIT | browser (lazy) | |
| web-vitals | 4.2.x | Apache-2.0 | browser (lazy, solo con consenso) | |
| @sentry/browser | 8.55.x | MIT | browser (lazy, solo se `VITE_SENTRY_DSN`) | |
| @fontsource-variable/inter, bricolage-grotesque | 5.3.0 | **OFL-1.1** (font) · MIT (pacchetto) | browser | self-hosted, nessuna richiesta a Google |

Sviluppo (non distribuiti): vite, vite-plugin-pwa, typescript, eslint, tailwindcss, postcss, autoprefixer, tsx, @electric-sql/pglite (Apache-2.0), @netlify/functions — MIT/Apache/BSD.

Nessuna licenza incompatibile con un uso commerciale closed-source. Obblighi: mantenere gli avvisi di copyright/licenza (OFL per i font: non rivendere i font da soli; MPL per web-push: rendere disponibili eventuali modifiche ai suoi file).

## Vulnerabilità note (`npm audit --omit=dev`)

| Advisory | Gravità | Impatto su AsiaFood | Decisione |
|---|---|---|---|
| react-router ≤ 7.17 — open redirect con backslash in `<Link>`/`useNavigate` (GHSA-wrjc-x8rr-h8h6) | moderata | I redirect che dipendono da input esterno (`?next=`, URL Stripe) passano da `safeNext`/`safeAssign` (`src/lib/safeRedirect.ts`), che rifiutano backslash, caratteri di controllo, sequenze codificate e schemi; test in `test:unit` | **Mitigato**; aggiornamento a v7 (breaking) pianificato dopo la beta, con E2E completi |
| react-router — constructor injection in `deserializeErrors()` (SSR hydration) (GHSA-337j-9hxr-rhxg) | moderata | Non applicabile: l’app è una SPA senza SSR/hydration di React Router | Accettato, si risolve con l’upgrade v7 |
| esbuild (via vite 5, solo dev server) | moderata | Solo `npm run dev` in locale; non in produzione | Accettato; upgrade Vite pianificato |

Regola: niente `npm audit fix --force` senza test (può introdurre major breaking); aggiornamenti major in un branch dedicato con `test:all` + E2E.
