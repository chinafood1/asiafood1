# Eventi analytics e metriche di business

Analytics **first-party** (nessun servizio pubblicitario o di terze parti). Gli eventi finiscono in `analytics_events` (per locale) e `app_events` (mappa/geolocalizzazione) tramite RPC `track_event` / `track_app_event`, che:
- accettano dal browser **solo eventi di interazione**; conversioni, pagamenti, ordini, sponsorizzazioni e logistica sono registrati **solo dal server**;
- **scartano** dai metadata qualsiasi chiave che somigli a dati personali o posizioni (`lat`, `lng`, `address`, `email`, `phone`, `name`, `message`, `text`, `query`…) e limitano la dimensione (2 KB);
- ricevono l’ID di sessione (casuale, per scheda) **solo con il consenso “Statistiche”**; senza consenso restano conteggi anonimi aggregati (servono ai locali per le loro statistiche e agli sponsor per le impression).

Convenzione dei nomi: `snake_case`, oggetto + azione al passato o sostantivo (`restaurant_view`, `order_created`), niente dati variabili nel nome. Retention: 13 mesi (`retention_analytics_days`).

## Eventi

| Evento | Trigger | Origine | Proprietà (metadata) |
|---|---|---|---|
| `restaurant_view` | apertura scheda locale | browser | `source` (home, explore, map, ai, sponsored_*…) |
| `phone_click` · `whatsapp_click` · `website_click` · `instagram_click` · `social_click` · `directions_click` | tap sui contatti | browser | `source` |
| `menu_view` · `menu_item_view` | apertura menu / piatto | browser | — / `item_id` |
| `reservation_start` | “Prenota” | browser | `source` |
| `reservation_completed` | prenotazione creata | **server** | — |
| `offer_view` · `coupon_claim` · `coupon_redeem` | offerta vista / coupon riscattato / usato in cassa | browser / **server** / **server** | `coupon_id` |
| `map_view` · `map_marker_click` | mappa | browser | — |
| `sponsored_impression` · `sponsored_click` | slot sponsorizzato visibile ≥ 50% per 1 s / click | browser (deduplicato 30 min) → RPC dedicata | `placement`, `campaign_id` |
| `ai_chat_open` · `ai_message_sent` · `ai_result_click` · `ai_map_open` · `ai_reservation_click` · `ai_offer_click` · `ai_no_results` | assistente | browser/server | `intent` (mai il testo) |
| `add_to_cart` · `remove_from_cart` · `cart_view` · `checkout_started` · `address_added` · `coupon_applied` · `payment_started` · `reorder` | funnel ordini | browser | `restaurant_id` |
| `payment_success` · `payment_failed` · `order_created` · `order_accepted` · `order_completed` · `order_cancelled` · `abandoned_cart` | ordini/pagamenti | **server** (webhook/cron) | `order_id` interno |
| `rider_online` · `rider_offline` · `delivery_offer_sent/accepted/rejected` · `delivery_assignment_failed` · `rider_arrived_restaurant` · `order_picked_up` · `rider_arrived_customer` · `delivery_completed` · `delivery_failed` | logistica | **server** | `job_id` |
| `map_open` · `location_permission_requested/granted/denied` · `restaurant_marker_click` · `near_me_search` · `map_area_search` | `app_events` | browser | `source` (mai coordinate) |
| Web Vitals `LCP` · `INP` · `CLS` · `FCP` · `TTFB` | caricamento pagine | browser, **solo con consenso “Statistiche”** | valore, `rating`, pagina “modello” (`/ristorante/:slug`), `mobile/desktop` |
| `qr_scan` | apertura di un QR del kit (`/r/:slug/:tipo`) | **server** (`track_qr_scan`) | `kind` (profile, menu, review, booking, offer) |
| `search` · `landing_view` · `install_prompt_shown` · `install_accepted` · `experiment_exposure` · `qr_kit_download` · `feedback_opened` | Fase 12 (`app_events`) | browser | `source`; per gli esperimenti `experiment` e `variant` (solo con consenso) |
| Visita di atterraggio | prima pagina della sessione | browser → `record_visit` (tabella `acquisition_visits`) | canale, UTM, percorso (senza query string), codice promo — nessun identificativo |

## Tassonomia canonica (Fase 13)
Nomi canonici, fonti di verità e metadati standard: [docs/growth/EVENTS.md](growth/EVENTS.md). I nomi qui sotto restano validi (adattatore, nessuna rinomina).

## Politica PII (vincolante)
Mai inviare: email, telefono, indirizzo completo, nome e cognome, dati di carta, testo libero digitato dall’utente, coordinate precise. Nuovi eventi: aggiungerli all’enum (migrazione), a questa tabella e — se contengono metadata — verificare che il filtro di `track_event` li accetti senza dati personali.

## Metriche di business (definizioni)

| Metrica | Definizione | Fonte |
|---|---|---|
| **MRR** | Somma dei canoni mensili degli abbonamenti Stripe **attivi o in ritardo di pagamento** che danno accesso, nell’ambiente Stripe corrente (test/live separati); annuali ÷ 12; esclusi piani manuali/omaggio e prove gratuite | `admin_revenue_stats.mrr_cents` |
| **ARR** | MRR × 12 | `arr_cents` |
| **New MRR / Churned MRR** | MRR degli abbonamenti pagati iniziati / terminati nel mese corrente (fuso Europe/Rome) | `new_mrr_cents`, `churned_mrr_cents` |
| **Churn (clienti)** | Abbonamenti pagati terminati negli ultimi 30 giorni ÷ abbonamenti pagati attivi a inizio periodo | `cancelled_30d` / `paying_subscriptions` |
| **GMV** | Totale pagato dai clienti (incl. consegna e costo di servizio, prima delle commissioni) degli **ordini validi**: pagamento incassato e ordine non rifiutato/annullato/rimborsato per intero | `marketplace_stats.gmv` |
| **Ordini** | Numero di ordini validi nel periodo | `marketplace_stats` |
| **AOV** | GMV ÷ ordini validi | `aov` |
| **Platform revenue** | Commissione + costo di servizio degli ordini completati, al netto della quota rimborsata | `platform_revenue` |
| **Ristoranti attivi** | Locali pubblicati, **non demo**, non chiusi definitivamente | `restaurants_active` |
| **Ristoranti rivendicati** | Locali non demo con un titolare | `restaurants_claimed` |
| **Ristoranti paganti** | Account di fatturazione (o locali) con almeno un abbonamento Stripe attivo/past_due che dà accesso | `paying_customers` |
| **Conversione prova → pagamento** | Prove convertite ÷ prove concluse (scadute o convertite) | `trial_conversion_rate` |

Tutte le metriche escludono i locali DEMO (Fase 11) e distinguono l’ambiente Stripe test/live; i periodi sono calcolati nel fuso **Europe/Rome** (timestamp salvati in UTC).

## Metriche di lancio (Fase 12)
Definizioni di completezza, segmenti, attivazione, North Star (“Successful Food Connections”), funnel, coorti, obiettivi e CAC/LTV: [`docs/launch/METRICS.md`](launch/METRICS.md).
