# Checklist di produzione (azioni manuali)

La checklist “viva” è in **`/admin/launch-checklist`**: calcola lo stato dal database (`admin_launch_checklist()`), mostra i blocker e **non arriva mai al 100%** con controlli critici aperti. Le voci con fonte *system* sono aggiornate da `system-cron` ogni 15 minuti; le voci manuali le segna l’Admin (con nota, registrato nell’audit). Questo documento spiega **come** chiudere ciascuna voce. Nessuna di queste azioni viene eseguita automaticamente dal codice.

Legenda: 🔴 critico per la **beta privata** · 🟠 critico per la **produzione pubblica** · ⚪ consigliato. Tra parentesi la chiave in `/admin/launch-checklist`.

## A. Infrastruttura
- [ ] 🔴 Due progetti Supabase separati **`asiafood-staging`** e **`asiafood-prod`** (regione UE). Mai lo stesso database.
- [ ] 🔴 Migrazioni applicate a staging → test → produzione (`supabase db push`, DEPLOYMENT § 3). Verifica: `npm run test:all` verde sullo stesso commit.
- [ ] 🔴 Piano Supabase **Pro** (backup giornalieri) sulla produzione (`backup_enabled`). ⚪ PITR prima del lancio pubblico.
- [ ] 🔴 **Restore testato su staging** con `scripts/ops/restore-staging.sh`, annotando durata (`backup_restore_test`) — DISASTER_RECOVERY § 2.
- [ ] 🔴 Netlify: variabili per contesto (Production ≠ Deploy previews) come da `.env.example`; `npm run production-check -- --env=production --online` senza FAIL (`env_secrets`, `env_app_env`).
- [ ] 🔴 Segreti generati nuovi e casuali: `ORDER_TOKEN_SECRET`, `IP_HASH_SALT`, `HEALTH_CHECK_TOKEN` (`openssl rand -hex 32`), salvati nel password manager del team.
- [ ] 🔴 Scheduled functions attive su Netlify (`system-cron`, `orders-cron`, `logistics-cron`, `engagement-cron`, `billing-cron`, `ai-cron`) e `send-emails` su Supabase Cron: in `/admin/system → Job` compaiono esecuzioni recenti (`orders_cron`, `priv_retention_job`).
- [ ] 🟠 Dominio definitivo, HTTPS forzato, dominio canonico, `VITE_SITE_URL`/`APP_URL` aggiornati (`env_domain`) — DEPLOYMENT § 5. ⚪ HSTS preload dopo 2 settimane.
- [ ] ⚪ GitHub: branch protection su `main` con check `ci` obbligatorio.

## B. Sicurezza
- [ ] 🔴 Supabase Auth: conferma email attiva, password minima 8 caratteri, **CAPTCHA** (Bot and Abuse Protection → Turnstile) e rate limit di Auth (`sec_auth_captcha`).
- [ ] 🔴 Turnstile: `VITE_TURNSTILE_SITE_KEY` + `TURNSTILE_SECRET_KEY`, dominio autorizzato.
- [ ] 🔴 Primo Admin creato via SQL (unico modo); account Admin con password lunga e 2FA sull’email; nessun account demo Admin in produzione.
- [ ] 🔴 Header in produzione verificati (`curl -sI https://<dominio>/` → CSP, HSTS, X-Frame/`frame-ancestors`) (`sec_headers`); nessun errore CSP nella console su home, scheda locale, checkout, mappa.
- [ ] 🟠 Supabase Storage: bucket privati (`claim-documents`, `rider-documents`, `delivery-proofs`) non pubblici; nessuna policy aggiunta a mano.
- [ ] ⚪ Revisione periodica di `/admin/system → Sicurezza` (rate limit, flood GPS).

## C. Pagamenti (Stripe)
- [ ] 🔴 Beta: Stripe **test** oppure live con ordini limitati agli invitati; un solo endpoint webhook `https://<dominio>/api/billing/webhook` (fatturazione **e** ordini) con `STRIPE_WEBHOOK_SECRET` corretto e gli eventi elencati in `docs/STRIPE_SETUP.md` e `docs/ORDERS.md` (`env_stripe`, `pay_webhook`).
- [ ] 🟠 Account Stripe verificato (dati società, IBAN), Connect attivo, prezzi dei piani live creati (`business_pricing`), **un pagamento live reale e il suo rimborso** (`pay_live_test`).
- [ ] 🟠 Almeno un ristorante con onboarding Connect completato prima di attivare gli ordini online per quel locale.

## D. Privacy e legale
- [ ] 🔴 Revisione delle pagine legali da parte di un consulente (`legal_review`); poi Admin → nuova versione pubblicata di ciascun documento (`priv_documents`). Fino ad allora le pagine sono marcate bozza e `noindex`.
- [ ] 🔴 Dati societari reali nelle impostazioni `legal_company_name`, `legal_vat_number`, `legal_address`, `legal_pec`, `legal_email` (footer) (`legal_company`). **Non inventarli.**
- [ ] 🔴 `support_email` impostata (`support_contact`) e casella monitorata.
- [ ] 🟠 DPA/contratti di trattamento firmati con Supabase, Netlify, Stripe, provider email, provider AI, Sentry (se usato), Mapbox/Google (se usati) (`priv_dpa`); registro dei trattamenti; eventuale DPIA per la geolocalizzazione dei Rider.
- [ ] 🟠 Periodi di retention confermati dal consulente (`retention_*` in `platform_settings`).

## E. Dati (Taranto)
- [ ] 🔴 Locali reali importati con fonte tracciata, coordinate e categorie (`database`, `coordinates`, `categories`, `sources`, `data_taranto`) — `/admin/launch-checklist → Taranto`.
- [ ] 🔴 Dati DEMO nascosti (`show_demo_data=false`) e poi rimossi: `CLEAN_DEMO_DATA_ALLOWED=true npm run clean-demo-data` (dry-run) → verifica conteggi → `-- --confirm=DELETE-DEMO-DATA` digitando il ref del progetto (`data_demo_hidden`). **Backup prima.**
- [ ] 🔴 Report di consistenza senza errori critici (`data_consistency`) in `/admin/system → Dati`.
- [ ] 🟠 Zone di consegna configurate e Rider reali verificati prima di attivare la consegna AsiaFood (`delivery_zones`, `rider_real`).

## F. Email, push, AI
- [ ] 🔴 Provider email scelto, dominio mittente verificato con **SPF, DKIM, DMARC** copiati dal pannello del provider (`email_dns`), test su mail-tester.com, coda `email_outbox` che si svuota (`email_outbox`).
- [ ] ⚪ Chiavi VAPID per le push (`env_push`); provider AI con limiti di spesa (`env_ai`) — altrimenti restano i fallback.

## G. Monitoraggio
- [ ] 🔴 Monitor esterni su `/`, `/api/health`, `/api/ready` (con token), checkout 4xx (`mon_uptime`) — DEPLOYMENT § 7.
- [ ] 🟠 Sentry (`SENTRY_DSN`/`VITE_SENTRY_DSN`) o decisione documentata di usare solo il log interno (`env_error_tracking`).
- [ ] ⚪ Soglie di allarme `alert_*` riviste in `platform_settings`.

## H. SEO e qualità
- [ ] 🟠 Google Search Console: dominio verificato, `sitemap.xml` inviata (`seo_search_console`); robots di staging con `Disallow: /`.
- [ ] 🟠 Core Web Vitals reali (≥ 2 settimane di dati) entro soglia (`perf_web_vitals`).
- [ ] 🟠 Test di carico k6 **su staging** (PERFORMANCE.md) e QA manuale su dispositivi reali (QA.md).

## I. Lancio
- [ ] 🔴 Beta: `beta_mode=true`, `beta_invite_only=true`, inviti creati da `/admin/system` (token mostrato una sola volta).
- [ ] 🔴 Runbook letto dal team; referenti in DISASTER_RECOVERY § 5 compilati.
- [ ] 🟠 Produzione pubblica: `/admin/launch-checklist` = **READY_FOR_PRODUCTION** senza blocker; decisione di go-live scritta (chi, quando, piano di rollback).

## J. Go-to-market Taranto (Fase 12)
- [ ] 🔴 Importare i locali reali di Taranto e provincia con fonte (Admin → Importa, poi verifica) e raggiungere la copertura minima dei comuni prioritari (`/admin/launch/taranto/coverage`).
- [ ] 🔴 Decidere e impostare il programma Partner Fondatori (piano, giorni, limite) in Piano e obiettivi → Impostazioni; far validare il testo dell’offerta (niente rinnovo automatico).
- [ ] 🔴 CRM: “Crea lead dai ristoranti”, assegnare i First 50 allo staff.
- [ ] 🟠 Confermare con il consulente la base giuridica del contatto B2B, la retention dei lead e del feedback, l’informativa per creator/partner.
- [ ] 🟠 Aggiungere la verifica di Search Console (`VITE_GOOGLE_SITE_VERIFICATION` o record DNS) e inviare la sitemap (docs/launch/SEARCH_CONSOLE.md).
- [ ] 🟠 Stampare i materiali (volantini, table card) dai modelli e distribuire con UTM distinte per zona/partner.
- [ ] 🟠 Account social (Instagram, Facebook, TikTok) e press kit con dati societari reali e screenshot.
- [ ] ⚪ Giveaway: solo dopo la checklist legale (Marketing → Template e regole).
- [ ] ⚪ Registrare i costi di acquisizione per avere un CAC affidabile.

## K. Business Intelligence (Fase 13)
- [ ] 🔴 Applicare le migrazioni 0025–0027 ed eseguire il backfill iniziale (Growth → Dati) sull'intervallo da cui esistono dati reali.
- [ ] 🔴 Verificare che `system-cron` esegua `growth_hourly` e `growth_daily` (Sistema → Job) e che `show_demo_data` sia **false** in produzione (altrimenti i DEMO entrano nelle metriche).
- [ ] 🟠 Rivedere le soglie (campione minimo, alert, anomalie) e i pesi del Market Opportunity Score.
- [ ] 🟠 Decidere quali automazioni tenere attive; le bozze consumer restano spente finché non c'è un responsabile delle approvazioni.
- [ ] 🟠 Registrare i costi operativi reali (infrastruttura, email, push, mappe) per unit economics attendibili; impostare `growth_payment_fee_pct` solo se si accetta una stima.
- [ ] 🟠 Validare con il consulente privacy il trattamento delle ricerche normalizzate (90 gg) e degli esperimenti.
- [ ] ⚪ Aggiungere le province delle città candidate mancanti (es. Matera) prima di avviare la ricerca di mercato.
