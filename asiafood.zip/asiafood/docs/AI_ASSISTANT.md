# AI Food Assistant — configurazione

L'assistente risponde **solo con i dati della piattaforma**. Funziona anche senza modello (risposte deterministiche):
il modello linguistico è un miglioramento, non un requisito.

## 1. Database

Applica le migrazioni `20260930000015_ai_enums.sql` e `20260930000016_ai.sql` (nell'ordine). Creano:

- funzioni deterministiche: `restaurant_open_status`, `restaurant_open_in_window`, `restaurant_price_pp`;
- strumenti in sola lettura (solo `service_role`): `ai_catalog`, `ai_search_restaurants`, `ai_search_menu`,
  `ai_search_offers`, `ai_restaurant_detail`;
- tabelle: `ai_chat_sessions`, `ai_chat_messages`, `ai_user_preferences`, `ai_usage`, `ai_cache` (con RLS);
- impostazioni in `platform_settings` (`ai_*`), modificabili da **Admin → Assistente AI**.

Verifica locale: `npm run test:db` e `npm run test:ai`.

## 2. Variabili d'ambiente (Netlify → Environment variables, scope *Functions*)

| Variabile | Obbligatoria | Note |
|---|---|---|
| `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` | sì | già usate dalla fatturazione |
| `AI_PROVIDER` | no | `anthropic`, `openai`, `gemini`, `openai_compatible`, `none` |
| `AI_API_KEY` | con provider | **mai** con prefisso `VITE_`, mai nel browser, mai mostrata in Admin |
| `AI_MODEL` | no | vuoto = modello predefinito del provider |
| `AI_MAX_TOKENS`, `AI_TEMPERATURE` | no | valori predefiniti se Admin non li imposta |
| `AI_BASE_URL` | solo `openai_compatible` | endpoint `…/v1` |
| `AI_TIMEOUT_MS` | no | default 12000 |
| `AI_RATE_SALT` | consigliata | sale per l'hash dell'IP (rate limit) |

Provider e modello si possono anche scegliere da Admin (valgono sulle variabili). La chiave resta sempre e solo un secret.

## 3. Funzioni

- `POST /api/ai/chat` (`netlify/functions/ai-chat.mts`)
  - `{"action":"chat","session_id":"…","message":"…","restaurant_id":null,"location":{"lat":…,"lng":…}}`
  - `{"action":"history","session_id":"…"}` · `{"action":"delete","session_id":"…"}`
  - errori: `400` richiesta non valida · `401` token non valido · `403` conversazione di un altro utente ·
    `413` messaggio troppo lungo · `429` limite raggiunto · `503` assistente disattivato · `500` errore (mai stack trace).
- `ai-cron` (giornaliera): `ai_purge()`.

## 4. Flusso di una richiesta

1. Validazione (metodo, 8 KB, JSON, `session_id`), utente facoltativo dal JWT.
2. Configurazione (`ai_runtime_config`), sessione (`ai_session_open`: le sessioni di un utente sono solo sue), rate limit.
3. Cache (solo richieste generiche di ospiti, senza posizione/orari/disponibilità).
4. Orchestratore `shared/ai/engine.ts`: parser italiano → (modello solo se incerto, output validato) → strumenti →
   risposta deterministica → (modello facoltativo per il testo, **validato**: ID esistenti, € e km presenti nei dati).
5. Salvataggio del contesto (senza coordinate), utilizzo e costo in `ai_usage`.

## 5. Costi

`ai_cost_input_per_mtok` e `ai_cost_output_per_mtok` (USD per milione di token) servono solo alla stima mostrata in Admin:
aggiornali con i prezzi del provider scelto. Limiti: `ai_guest_limit_per_hour`, `ai_user_limit_per_hour`,
`ai_premium_limit_per_hour`, `ai_ip_limit_per_hour`.

## 6. Checklist privacy

- La posizione è arrotondata (~100 m) e usata solo per la richiesta corrente.
- `ai_chat_retention_days` = 0 → nessun messaggio salvato.
- Gli eventi analytics `ai_*` non contengono testo dei messaggi né coordinate (filtrati anche nel DB).
- Le preferenze sono facoltative, visibili ed eliminabili dal profilo.
