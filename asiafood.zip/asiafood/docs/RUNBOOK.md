# Runbook operativo

Strumenti: `/admin/system` (stato, errori con request id, webhook, job, flag e kill switch, privacy, audit, consistenza), `/admin/support`, `/admin/orders`, `/admin/dispatch`, `/admin/launch-checklist`, log Netlify (Functions → filtra per `request_id`), log Supabase, Stripe Dashboard → Events/Payments.

Ogni errore mostrato all’utente con codice 5xx contiene un **codice di riferimento** (primi 8 caratteri del `requestId`): cercalo in `/admin/system → Errori recenti` e nei log Netlify.

## Pagamento fallito / cliente addebitato ma ordine non confermato
1. Stripe Dashboard → Payments: cerca per email o importo; annota il `pi_…`.
2. `/admin/orders` → ordine (numero AF-…) → stato pagamento. Se Stripe dice “succeeded” e l’ordine no: `/admin/system` → Webhook falliti. Stripe ritenta automaticamente; puoi rispedire l’evento da Stripe → Events → *Resend*.
3. Azione “Risincronizza da Stripe” nella scheda ordine (`resync`) allinea stato e rimborsi.
4. Mai segnare un ordine come pagato a mano senza verifica su Stripe.

## Ordine bloccato (non accettato / non consegnato)
1. `/admin/orders` filtra per stato; timeline eventi.
2. Non accettato: il cron applica il timeout con rimborso automatico (`order_accept_timeout_minutes`); contattare il ristorante se ripetuto.
3. Consegna AsiaFood senza Rider: `/admin/dispatch` → assegnazione manuale o “rilancia ricerca”; dopo il ritiro nessuna riassegnazione automatica.
4. Se `/admin/system` mostra job `orders-cron` fallito o bloccato: “Riprova” e controlla i log.

## Problema con un Rider
- Nessuna posizione/aggiornamenti: avviso `rider_stale` in dispatch; telefonare al Rider (numero nella scheda Admin).
- Posizioni anomale/GPS flood: `/admin/system → Sicurezza`; **nessuna sospensione automatica**: valutazione umana.
- Incidente in consegna: il Rider usa “Ho un problema” (per emergenze 112). Consegna fallita → decidere rimborso/compenso (nessun compenso automatico).
- Sospensione: `/admin/riders` → Sospendi (audit), i job non ritirati tornano in assegnazione.

## Provider email giù
Le email restano in coda (`email_outbox`). Verifica stato del provider; se prolungato cambia `EMAIL_PROVIDER`/`EMAIL_API_KEY` nei secret della Edge Function e ridistribuisci. Le notifiche in-app continuano.

## AI giù o costi anomali
`/admin/system → AI` (errori/ora, fallback). Kill switch **Assistente AI** in Flag e kill switch; verifica quota/chiave; `/admin/ai` per limiti orari.

## Database giù
`/api/health` = 503. Controlla status.supabase.com e Dashboard → Reports. Se non è un disservizio del provider: vedi DISASTER_RECOVERY. Comunica con banner/social (la manutenzione è nel DB e non è attivabile se il DB non risponde).

## Rimborso
- Ristorante: dal terminale ordini entro `order_restaurant_refund_days`.
- Admin: `/admin/orders` → Rimborso (totale/parziale, motivo obbligatorio; audit `refund_requested`). Il rimborso reale è su Stripe; lo stato si aggiorna con il webhook `charge.refunded`.
- Non improvvisare importi: parziali solo con motivazione scritta.

## Richieste privacy
- Export: autonomo da `/settings/privacy`.
- Cancellazione **bloccata** (`owns_restaurant` / `rider_profile`): trasferire la proprietà (`/admin/restaurants` → membri) o chiudere il profilo Rider, poi `/admin/system → Privacy → Riprova`.
- Richieste via supporto (categoria Privacy, priorità alta): rispondere entro 30 giorni (art. 12 GDPR).

## Manutenzione programmata
1. Avvisa gli utenti (banner/campagna) e i ristoranti.
2. `/admin/system → Flag → Modalità manutenzione` ON (il pubblico vede “Stiamo effettuando un aggiornamento.”; nuovi ordini rifiutati dal backend; webhook e ordini in corso continuano; l’Admin lavora normalmente).
3. Deploy/migrazione → verifiche → OFF.

## Incidente di sicurezza
Vedi SECURITY.md § 8: identificare → contenere (kill switch, manutenzione, revoca sessioni, rotazione segreti) → investigare (audit log, request id) → ripristinare → documentare (notifica Garante entro 72 h se violazione di dati personali).

Rotazione rapida dei segreti:
| Segreto | Dove si rigenera | Dopo |
|---|---|---|
| Supabase JWT secret / service role | Dashboard → Settings → API | aggiornare Netlify (`SUPABASE_SERVICE_ROLE_KEY`, `VITE_SUPABASE_ANON_KEY`), redeploy; tutte le sessioni scadono |
| Stripe secret / webhook secret | Stripe → Developers | aggiornare Netlify, redeploy, verificare un webhook di prova |
| `ORDER_TOKEN_SECRET` | `openssl rand -hex 32` | aggiornare Netlify **e** secret Edge Function; i link ospite già inviati non funzionano più (i clienti registrati non sono toccati) |
| VAPID | `npx web-push generate-vapid-keys` | i dispositivi devono riattivare le push |
| AI / Mapbox / Turnstile | pannello del provider | aggiornare Netlify, redeploy |

## Growth e automazioni (Fase 13)
- **Fermare tutte le automazioni**: Admin → Growth → Automazioni → "Blocca tutte le automazioni" (kill switch). Singola regola: interruttore sulla riga.
- **Automazione in errore**: dopo 3 errori compare un alert, dopo 5 la regola si disattiva da sola; leggere l'errore nello storico, correggere la configurazione, riattivare (il contatore si azzera).
- **Messaggio approvato per errore**: è una notifica in-app già consegnata; non esiste invio email/push massivo dalle automazioni. Annotare un incidente.
- **Aggregati fermi / numeri incoerenti**: Growth → Dati → "Ricalcola aggregati" per l'intervallo (idempotente, max 400 giorni). Verificare il job `growth_daily` in Sistema → Job.
- **Alert rumorosi**: alzare le soglie in Growth → Dati (volume minimo, % di calo); mai disattivare gli alert critici di pagamento.
- **Esperimento su area sensibile avviato per errore**: Ferma subito (tutti tornano al controllo) e registrare la revisione mancante.

## Lancio Taranto (Fase 12)
- Routine: `/admin/launch/taranto/daily` (vendite) e `/today` (operations, SLA interni). Procedure complete: `docs/launch/`.
- **Revoca Partner Fondatore**: scheda lead → “Revoca adesione” con motivo (badge nascosto, piano promozionale revocato, audit). Mai revocare un abbonamento Stripe da qui.
- **Richiesta “non contattatemi”**: lead → “Può essere ricontattato” off (blocca ogni outreach). Se riguarda un utente: preferenze notifiche/consenso marketing.
- **Errore nei dati durante il lancio**: `/admin/launch/taranto/quality` o `/admin/reports`; se diffuso, aprire un incidente (`/today`) con gravità alta.
- **Contenuto pubblicato per errore** (es. sponsorizzato senza #adv su un social): rimuoverlo sul social, correggere lo stato nel calendario, annotare un incidente.
- **Esperimento anomalo**: Crescita → Esperimenti → Ferma (tutti tornano alla variante standard).
