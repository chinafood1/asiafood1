# Fase 7 · Fidelizzazione (recensioni, AsiaPoints, inviti, notifiche, campagne)

Migration: `supabase/migrations/20261001000017_engagement.sql`.
Test: `npm run test:engagement` (PGlite, 139 verifiche).

## Principi

- **Tutto ciò che "vale" è calcolato dal server**: punti, badge, recensione verificata, invito completato,
  invii delle campagne. Il browser chiama solo RPC `security definer` che controllano identità e regole.
- **I punti non sono denaro**: nessuna conversione, nessun prelievo, nessun valore in euro mostrato.
- **Nessun dato personale ai ristoratori**: solo numeri aggregati; mai email, telefoni o endpoint push.
- **Consenso**: le comunicazioni promozionali (campagne, nuove offerte, novità dei locali seguiti) sono disattivate di default.

## Recensioni

| Regola | Dove |
|---|---|
| Solo utenti registrati, niente anonime | `submit_review` (auth obbligatoria) |
| "Visita verificata" solo con prenotazione completata o coupon utilizzato (entro `review_verification_window_days`) | `review_verification_for` |
| Recensioni non verificate ammesse se `allow_unverified_reviews` = true | `platform_settings` |
| 1 recensione per utente/ristorante ogni `review_cooldown_days` (90) | `submit_review` |
| Titolare, manager e staff del locale non possono recensirlo | `is_restaurant_insider` |
| Modifica → `is_edited` + storico in `review_versions` | `update_review` |
| Voto medio sempre calcolato (`restaurant_rating`), mai scritto a mano | nessuna colonna rating sui ristoranti |
| Una risposta ufficiale per recensione; il ristoratore può segnalare ma non modificare/eliminare | `respond_to_review`, RLS |
| Voto "utile" una volta per utente | PK `review_votes(review_id,user_id)` |
| Nessuna rimozione automatica dopo una segnalazione; oltre `review_flag_threshold` segnalazioni → "segnalata" in coda | `report_review` |
| Filtri automatici (link, email, telefono, maiuscole) mettono in moderazione, non decidono | `review_content_flags` |
| Pubblicazione automatica configurabile (`auto_publish_verified_reviews`, `auto_publish_unverified_reviews`) | settings |

Admin: `/admin/reviews` (pubblica, nascondi, rifiuta, ripristina, segnalazioni). Ristoratore: sezione **Recensioni** del locale.
La richiesta di recensione dopo una visita completata viene inviata una sola volta (`review_request_delay_hours`).
Il QR `/r/:slug/review` usa la CTA neutra "Racconta la tua esperienza": vietato incentivare recensioni positive
(i punti per `verified_review` non dipendono dal voto).

## AsiaPoints

- Regole in `loyalty_rules` (Admin → AsiaPoints → Regole): punti, limite giornaliero e mensile.
- Idempotenza: indice unico su `user_id + event_key + source_type + source_id`.
- Livelli Explorer / Foodie / Insider / Master (sui punti totali guadagnati). `benefits_json` vuoto finché non esistono vantaggi reali.
- Premi (`rewards`) con riscatto atomico (`redeem_reward`): blocco della riga, verifica saldo/stock/limite per utente, consumo FIFO dei punti; il saldo non può diventare negativo (check constraint).
- Scadenza punti: `points_expire_after_months` (default nessuna).
- Rettifiche solo Admin (`admin_loyalty_adjust`) con motivazione e registro `admin_audit_logs`.

## Inviti

- Codice personale `XXXX-XXXX`, link `/invite/CODICE`. Il codice resta nel browser (localStorage, 30 giorni) e viene applicato dopo la registrazione.
- Stati: registered → qualified → rewarded (oppure invalid). Qualificato solo con **email verificata** + prima visita reale (prenotazione completata o coupon utilizzato) entro `referral_signup_window_days`.
- Autoinvito bloccato, massimo `referral_max_per_month` premi al mese per chi invita.
- B2B (`business_referrals`): il ristoratore invita un collega; lo staff approva e applica il premio manualmente. Nessun accredito automatico.

## Notifiche

- In-app: tabella `notifications` (RLS: ognuno vede solo le proprie), campanella con badge, `/notifications`, Realtime.
- Preferenze: `/settings/notifications` (`notification_preferences`). Transazionali attive, promozionali disattivate di default.
- Dispatcher unico `notify_user` → in-app + push (`push_outbox`) + email (`email_outbox`) secondo le preferenze, con deduplica (`notification_delivery_log.dedupe_key`).
- Promemoria prenotazione 24h e 2h prima (`reservation_reminder_hours`), mai per prenotazioni annullate, rifiutate o completate.
- Promemoria coupon in scadenza solo per coupon richiesti e non ancora usati.

### Push (Web Push VAPID)

1. `npx web-push generate-vapid-keys`
2. Su Netlify: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `PUSH_SUBJECT` (es. `mailto:info@tuodominio.it`).
3. La chiave pubblica è servita da `/api/push/public-key`; la privata non lascia mai le Functions.
4. `engagement-cron` (ogni 15 minuti) esegue `engagement_tick` e invia le push in coda; endpoint scaduti (404/410) vengono disattivati.

Il permesso non viene mai chiesto all'apertura: solo dopo un'azione (es. prenotazione) con "Attiva notifiche" / "Non ora".
Dopo un rifiuto non viene richiesto di nuovo. In modalità demo le push sono notifiche locali del browser.

## Campagne

- Ristoratore: `/dashboard/restaurants/:id/campaigns`, solo piani con `push_campaigns_enabled` (Premium, Top) e `monthly_campaign_limit` (2 / 8), max 1 al giorno.
  Destinatari: follower, chi ha usato coupon, clienti passati — sempre e solo con consenso. Vede solo numeri aggregati.
- Admin: `/admin/campaigns` con destinatari per comune, categoria preferita, livello, attivi, prenotazione imminente.
- Limite di frequenza per utente: `campaign_max_per_user_week`. Tetto destinatari: `campaign_max_recipients`.
- Metriche (`campaign_deliveries`): inviate, aperte (notifica letta), clic (`?cd=`), saltate, errori. "Consegnate" non viene mai stimato.

## Statistiche

`/admin/retention`: DAU/WAU/MAU da `user_activity_days`, utenti tornati, prenotazioni ripetute, coupon riutilizzati,
recensioni, inviti, punti, push. Le definizioni sono mostrate nella pagina.
Ristoratore: pannello "Fidelizzazione" nelle Statistiche (rating, follower, clienti che tornano, campagne) senza dati personali.

## Scheduler

`engagement_tick(now)` (idempotente): promemoria, coupon in scadenza, richieste di recensione, ricontrollo inviti,
invio campagne programmate, scadenza punti/premi, pulizia notifiche scadute. Admin → Campagne → "Esegui scheduler ora".
