# Stripe — configurazione (TEST MODE)

La prima messa in funzione avviene **solo in modalità test**. Nulla passa in live automaticamente:
il backend deduce l'ambiente dalla chiave (`sk_test_` / `sk_live_`) e, se `STRIPE_MODE` non coincide, rifiuta di partire.

## 0. Prerequisiti
- Migrazioni applicate fino a `20260929000014_billing.sql` (0013 e 0014 in esecuzioni **separate**).
- Sito su Netlify con le Functions attive (cartella `netlify/functions`, già in `netlify.toml`).

## 1. Chiavi API (Stripe → Developers → API keys, interruttore **Test mode** attivo)
| Variabile | Dove | Valore |
|---|---|---|
| `VITE_STRIPE_PUBLISHABLE_KEY` | Netlify (build) | `pk_test_…` |
| `STRIPE_SECRET_KEY` | Netlify (Functions) | `sk_test_…` — **mai** nel frontend |
| `STRIPE_MODE` | Netlify (Functions) | `test` |
| `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` | Netlify (Functions) | da Supabase → Project Settings → API |
| `APP_URL` | Netlify (Functions) | es. `https://asiafood.netlify.app` |

Dopo aver impostato le variabili, rideploya il sito.

## 2. Products e Prices
**Metodo consigliato (automatico):** Admin → **Piani** → *Crea/aggiorna prezzi su Stripe*.
Il backend crea per ogni piano a pagamento un Product (`AsiaFood Business/Premium/Top`) e due Price ricorrenti
(mensile e annuale, in EUR) con i prezzi del database, e salva gli ID nel DB (`stripe_product_id`,
`stripe_monthly_price_id`, `stripe_yearly_price_id`). È idempotente: rieseguirlo non duplica nulla.

**Metodo manuale:** Stripe → Product catalog → *Add product*:
| Product | Price mensile | Price annuale |
|---|---|---|
| AsiaFood Business | 29,90 € / mese | 299,00 € / anno |
| AsiaFood Premium | 59,90 € / mese | 599,00 € / anno |
| AsiaFood Top | 99,90 € / mese | 999,00 € / anno |

Copia i **Price ID** (`price_…`, pagina del prodotto → sezione Pricing → menu ⋯ → *Copy price ID*) e incollali in
Admin → Piani → card del piano → *Stripe*. I prezzi sono IVA esclusa.

> Cambiare un prezzo: modificalo in Admin → Piani, poi *Crea/aggiorna prezzi su Stripe*. I Price Stripe sono
> immutabili: ne viene creato uno nuovo; gli abbonati esistenti restano sul prezzo precedente.

## 3. Webhook
Stripe → Developers → **Webhooks** → *Add endpoint*
- **URL:** `https://<tuo-dominio>/api/billing/webhook`
- **Eventi:** `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`,
  `customer.subscription.deleted`, `customer.subscription.trial_will_end`, `customer.subscription.paused`,
  `customer.subscription.resumed`, `invoice.paid`, `invoice.payment_succeeded`, `invoice.payment_failed`,
  `invoice.payment_action_required`, `invoice.finalized`, `customer.updated`
- Fase 8 (ordini): aggiungi anche `payment_intent.succeeded`, `payment_intent.payment_failed`, `payment_intent.canceled`,
  `payment_intent.processing`, `charge.refunded`, `charge.refund.updated`, `refund.created`, `refund.updated`, `refund.failed`,
  `charge.dispute.created`, `account.updated` — vedi [ORDERS.md](ORDERS.md).
- Copia il **Signing secret** (`whsec_…`) in `STRIPE_WEBHOOK_SECRET` (Netlify, Functions) e rideploya.

In locale: `stripe listen --forward-to localhost:8888/api/billing/webhook` (con `netlify dev`) e usa il `whsec_` mostrato dalla CLI.

## 4. Customer Portal
Stripe → Settings → Billing → **Customer portal** → attiva: aggiornamento metodo di pagamento, fatture,
dati di fatturazione, cancellazione (consigliato: *at end of billing period*). Facoltativo: cambio piano
(aggiungi i tre prodotti). Salva. Per una configurazione dedicata imposta `STRIPE_PORTAL_CONFIGURATION_ID` (`bpc_…`).

## 5. IVA (Stripe Tax) — facoltativo
Stripe → Tax → attiva e registra la sede. Poi `STRIPE_TAX_ENABLED=true`: il checkout usa `automatic_tax`,
raccoglie indirizzo e Partita IVA. Con `false` il checkout funziona senza calcolo automatico (nessuna IVA "improvvisata").
La fatturazione elettronica SdI non è inclusa: i dati utili (P.IVA, CF, PEC, codice destinatario) sono salvati in `billing_accounts`.

## 6. Cron
`billing-cron` (Netlify Scheduled Function, ogni ora) ricalcola i piani (fine tolleranza, fine periodo, scadenze
manuali) e invia gli avvisi "la prova sta per terminare". Non serve configurazione aggiuntiva.

## 7. Prova end-to-end in test mode
1. Accedi come ristoratore (titolare di un locale) → **Piani** o *Fatturazione* del locale.
2. Scegli Business/Premium/Top → si apre Stripe Checkout.
3. Carte di test: `4242 4242 4242 4242` (ok), `4000 0025 0000 3155` (3D Secure), `4000 0000 0000 9995` (rifiutata),
   `4000 0000 0000 0341` (si salva ma fallisce all'addebito: utile per testare pagamenti falliti). Scadenza futura, CVC qualsiasi.
4. Torni su `/dashboard/billing/success`: la pagina conferma solo dopo che Stripe ha confermato (webhook o lettura server).
5. Verifica in Stripe → Developers → **Events / Webhooks** che le consegne abbiano risposta 200, e in
   Admin → **Stripe** il registro eventi (solo metadati, nessun payload salvato).
6. Per simulare il tempo: Stripe → Billing → **Test clocks** (fine prova, rinnovi, pagamenti falliti).

## 8. Go-live (quando deciso, mai automatico)
Ripeti i passi 1–4 con le chiavi live, `STRIPE_MODE=live`, nuovo webhook live e *Crea/aggiorna prezzi su Stripe*.
Gli abbonamenti test restano nel DB con `stripe_environment = 'test'` e **non** contano più per piani e MRR.
