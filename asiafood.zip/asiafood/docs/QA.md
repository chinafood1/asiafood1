# QA: test, accessibilità, browser, responsive

## Piramide dei test

| Livello | Cosa | Comando | Stato (v0.1.0-beta) |
|---|---|---|---|
| Unit | validazione Zod, upload (magic bytes), redirect sicuri, importi, scrubbing PII | `npm run test:unit` | 59 ✓ |
| Integrazione DB | tutte le migrazioni reali su Postgres (PGlite): RLS, RPC, trigger, regole di business | `test:db`, `test:hardening` | 367 ✓ · 157 ✓ |
| Integrazione backend | handler reali + DB reale + Stripe/AI/push simulati, webhook firmati | `test:platform`, `test:billing`, `test:engagement`, `test:ai`, `test:orders`, `test:logistics` | 49 · 85 · 142 · 139 · 151 · 152 ✓ |
| E2E (browser) | Playwright sulla build servita (`vite preview`), desktop e mobile | script Playwright usati in sviluppo (vedi sotto) | tutti verdi |
| Accessibilità automatica | axe-core, regole WCAG 2.1 A/AA | scansione Playwright + axe | 37 pagine (incl. Launch Control, kit QR/lancio, /taranto), 0 violazioni |
| CSP | la CSP di `netlify.toml` applicata alle pagine | smoke test | 10 pagine, 0 violazioni |
| Carico | k6 su staging | `scripts/load/k6-staging.js` | **da eseguire** su staging |

Totale automatico: **1.456 controlli** (Fase 12: `test:launch` 138, unit 76) (`npm run test:all`), eseguiti anche in CI.

### Scenari E2E coperti (A–I)
- **A. Cliente**: ricerca, scheda, mappa, preferiti, prenotazione, coupon, recensione, ordine con pagamento simulato, tracking, supporto, export e cancellazione account (suite p4a, p4b, p5, p7, p8, p11).
- **B. Ospite**: ordine con link firmato, ticket di supporto, banner cookie e preferenze (p8, p11).
- **C. Ristoratore**: rivendicazione, editor, menu, prenotazioni, offerte, piano e fatturazione, terminale ordini (flow2, p4a, p5, p8).
- **D. Rider**: candidatura, online/offline, offerta, stati, consegna, compensi (p9).
- **E. Admin**: approvazioni, ordini, dispatch, sistema, flag e manutenzione, supporto, launch checklist, audit (p5, p8, p9, p11).
- **F. Manutenzione**: pubblico bloccato, Admin operativo (p11).
- **G. Offline**: avviso offline e blocco checkout (p11).
- **H. Mappe**: LiteMap, cluster, geolocalizzazione negata, ricerca nell’area (map2–map4).
- **L. Lancio Taranto (p12, desktop e mobile, 71 controlli)**: attribuzione UTM/QR, landing /taranto, feedback, /press, /app, Launch Control, copertura, qualità dati, CRM e First 50, outreach, Partner Fondatore e badge, daily/partner/operations, crescita, calendario con vincoli #adv, piano, kit QR (download PNG) e kit di lancio, ambassador.
- **I. Stripe**: checkout, prova, upgrade/downgrade, pagamenti falliti, webhook idempotenti, Connect, rimborsi (test:billing, test:orders con Stripe simulato e firme reali). **Il pagamento live reale va fatto a mano** (PRODUCTION_CHECKLIST § C).

## Accessibilità
Scansione axe-core (WCAG 2.0/2.1 A e AA) su: home, elenco, scheda locale, categoria×città, mappa, offerte, cucina, accesso, supporto, pagine legali, privacy, 404, dashboard ristoratore, Admin (dashboard, sistema, supporto, launch checklist), account, ordini → **0 violazioni** dopo le correzioni della Fase 11:
- contrasto: token `ink-faint` (#9C9CA3 → #727279), `coral` (#FF5A4E → #CF3A2F per testo e pulsanti; il corallo originale resta nel logo e nei segnaposto della mappa), `leaf` (#2F9E6B → #237A55), testi su fondi chiari (chip) in `coral-700`, fallback delle immagini;
- piatti non disponibili: niente più opacità sul testo (solo sull’immagine) + etichetta leggibile;
- mappa statica dentro un link: segnaposto non più pulsanti annidati;
- grafici Admin con `role="img"` e `aria-label`; `<dl>` valide;
- già presenti: link “Salta al contenuto”, focus trap e ripristino del focus nei pannelli, `aria-live` per carrello/toast/assistente, etichette dei campi, errori dei moduli associati.

Limiti: axe rileva circa il 30–40 % dei problemi. **Da fare a mano prima della produzione**: navigazione completa solo tastiera, VoiceOver (iOS/macOS) e TalkBack (Android) sui flussi ordine e prenotazione, zoom 200 %, `prefers-reduced-motion`.

## Browser e dispositivi
Automatico: Chromium desktop (1280×800) e mobile (390×844, touch). **Da verificare a mano** (non disponibili nell’ambiente di sviluppo):

| Browser | Versioni | Punti critici |
|---|---|---|
| Safari iOS | 16.4+ | PWA installata, push (solo da app installata), geolocalizzazione, Stripe Payment Element, `100dvh` |
| Chrome Android | ultime 2 | installazione PWA, push, fotocamera per upload Rider |
| Safari macOS, Firefox, Edge | ultime 2 | checkout, mappa Mapbox, CSP |
| Samsung Internet | ultima | layout mobile |

## Responsive
Verificato automaticamente (assenza di overflow orizzontale, header, barra inferiore) a 390 (mobile), 820 (tablet), 1280 e 1440 px sulle pagine principali; 360 px e orientamento orizzontale da controllare a mano; il badge BETA è sovrapposto al logo per non far traboccare l’header su mobile.

## Fusi orari e importi
- Timestamp in UTC (`timestamptz`); orari di apertura, promemoria e periodi delle metriche in **Europe/Rome** (slot d’ordine e prenotazioni testati nel fuso di Roma in `test:orders`/`test:engagement`). **Da aggiungere**: test espliciti sui giorni del cambio d’ora (fine marzo / fine ottobre).
- Importi `numeric(10,2)` nel DB, centesimi interi verso Stripe, stime nel browser con `shared/money.ts` (test: `0,1 + 0,2 = 0,3`, arrotondamento 1,005 € → 101 cent).

## Lingua
Italiano predefinito; struttura `src/i18n` (it/en) pronta, traduzione inglese non completata (fuori scope beta).
