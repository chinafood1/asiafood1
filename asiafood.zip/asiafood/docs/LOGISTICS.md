# Logistica AsiaFood (Fase 9): Rider, dispatch e tracking

Prima versione del sistema di consegna proprietario. Si attiva **per ristorante**: l'Admin abilita i Rider AsiaFood
(`asiafood_delivery_enabled`) e il ristorante sceglie *Chi consegna → Rider AsiaFood* nelle impostazioni ordini.
Con `delivery_provider_type = restaurant` il flusso della Fase 8 resta identico; `external` è predisposto.

- Migration: `supabase/migrations/20261003000020_logistics_enums.sql`, `20261003000021_logistics.sql`
- Backend: `server/logistics/*`, `netlify/functions/logistics-action.mts` (`/api/logistics/action`), `logistics-cron.mts` (ogni minuto)
- App: `/rider/apply`, `/rider`, `/rider/delivery/:id`, `/rider/earnings`; Admin `/admin/riders`, `/admin/dispatch`, `/admin/logistics`, `/admin/logistics/settings`
- GPS separato dalla UI: `src/lib/rider/tracker.ts` (riusabile da una futura app React Native/Capacitor), coda offline `offlineQueue.ts`, navigazione/wake lock `device.ts`
- Test: `npm run test:logistics` (152 scenari su PGlite con le vere migration e i veri handler ordini/webhook)

## 1. Flusso

```
Cliente paga ──► Ristorante accetta ──► delivery_job (waiting_assignment)
                                           │ lg_dispatch(): raggi 3 → 5 → 8 → 10 km (configurabili, mai oltre il massimo)
                                           ▼
                           offerta al Rider migliore (offered, timeout 30 s)
                   rifiuta/scade ──► assignment rejected/expired ──► Rider successivo
                           accetta (transazione con lock sul job: un solo vincitore)
                                           ▼
 assigned → rider_to_restaurant → arrived_restaurant → picked_up (codice ritiro) → rider_to_customer
         → arrived_customer → delivered (conferma / OTP / foto)        ⇢ failed / cancelled
```

**Macchina a stati centrale** (`lg_transition_allowed`): ogni transizione è validata dal database; `delivered → picked_up`
e simili sono bloccate. **Sincronizzazione ordine** (`lg_sync_order`): ritiro → ordine `out_for_delivery`; consegna →
ordine `completed` (con AsiaPoints e notifiche della Fase 8). Il ristorante non può più impostare "in consegna/consegnato"
sugli ordini AsiaFood (trigger `orders_logistics_guard`).

**Ranking trasparente** (nessun dato personale): 1) capacità libera, 2) stesso ristorante (predisposto per multi-consegna),
3) distanza dal ristorante. Candidati: Rider approvato/attivo, online, "accetta ordini", non sospeso, posizione fresca
(< 3 min), zona compatibile, nessuna offerta aperta e nessun tentativo precedente sullo stesso job.

**Strategia**: `immediate` (dopo l'accettazione) o `before_ready` (X minuti prima dell'orario "pronto"). Il segnale
"Ordine pronto" del ristorante anticipa la ricerca se il job è ancora in attesa.

**Riassegnazione**: il Rider può rilasciare prima del ritiro (job torna in assegnazione, audit). Dopo il ritiro serve lo staff.
Sospensione Admin: i job non ritirati tornano in assegnazione.

## 2. Posizione, privacy e retention

| Chi | Cosa vede |
|---|---|
| Rider | Solo le proprie offerte e consegne; indirizzo completo del cliente solo **dopo** l'accettazione; mai il codice di consegna |
| Cliente | Nome + iniziale del Rider, veicolo, stato, ETA; posizione del Rider **solo dopo il ritiro** (e solo se aggiornata < 3 min) |
| Ristorante | Nome del Rider, arrivo stimato, codice di ritiro; niente coordinate |
| Admin | Mappa control center (non pubblica), timeline, tentativi, documenti con link firmato di 2 minuti |

- Posizione inviata **solo online** e dopo il consenso ("AsiaFood utilizza la tua posizione mentre sei online per assegnarti e
  gestire le consegne."). Indicatore "Posizione attiva". Offline = tracciamento spento e ultima posizione cancellata.
- Frequenza: ~15 s in consegna (alta precisione), ~60 s in attesa (bassa precisione), diradata se il Rider è fermo.
- Controlli anti-spoofing ragionevoli: timestamp vecchi scartati, precisione bassa segnalata, velocità/salti impossibili
  → posizione ignorata e avviso all'Admin. **Nessuna sospensione automatica.**
- Retention (impostazioni Admin): posizioni precise 24 h (`logistics_location_retention_hours`); consegne anonimizzate
  (coordinate, indirizzo, codici) dopo 365 giorni; documenti Rider conservati 730 giorni dopo la chiusura del profilo
  (cancellazione manuale dallo staff: nessuna cancellazione automatica di documenti con valore legale). Restano gli eventi
  logistici essenziali (`delivery_events`), senza percorso GPS.
- Storage privati: `rider-documents` e `delivery-proofs` (cartella = id utente; lettura solo proprietario e Admin).
  La foto di consegna ritrae solo il pacco/punto di consegna, mai persone.

## 3. ETA

Stima del database (distanza in linea d'aria × 1,35 / velocità media del mezzo), sempre mostrata come **intervallo**
("Consegna stimata 20–30 min", "Tempo stimato"). Ricalcolata all'assegnazione, al ritiro e quando il Rider si sposta di
oltre 250 m (non a ogni GPS). Con `MAPBOX_DIRECTIONS_TOKEN` il backend (`/api/logistics/action`, `eta_refresh`) usa i
percorsi reali su accettazione e ritiro; se il provider non risponde resta la stima.

## 4. Compensi

`rider_compensation_rules` (per città o generale): `max(minimo, base + €/km × distanza ristorante→cliente)`, con tetto sulla
quota distanza. Bonus meteo/picco **solo manuali**. Il Rider vede "Compenso stimato" nell'offerta e il compenso definitivo
dopo la consegna; il record `rider_earnings` nasce `pending`, l'Admin approva e **registra** il pagamento (nessun trasferimento
automatico, nessun wallet prelevabile). `rider_payout_accounts` predispone Stripe Connect / SEPA. Consegne annullate o fallite:
nessun compenso automatico, avviso all'Admin che decide (`admin_earning_create`, audit).

## 5. Avvisi dispatch (scheduler ogni minuto)

Nessun Rider disponibile · consegna senza Rider oltre N min · Rider senza aggiornamenti oltre 5 min (flag `rider_no_response`,
mai cancellazione automatica) · Rider fermo oltre 12 min (tolleranza GPS 50 m) · ordine oltre l'ETA massima + 15 min ·
consegna fallita · annullamento con Rider già in viaggio o dopo il ritiro · cliente non disponibile · posizione anomala.

## 6. Limiti del tracking web/PWA

- **iOS (Safari/PWA)**: la geolocalizzazione si ferma quando l'app va in background o lo schermo si blocca; niente
  background location per le PWA. Il Rider deve tenere l'app in primo piano durante la consegna (lo schermo resta acceso con la
  Screen Wake Lock API dove il browser la supporta).
- **Android (Chrome/PWA)**: il tracciamento continua per poco in background, poi il sistema può sospenderlo (risparmio energetico).
- Il server tollera i buchi: avvisi con soglie, nessuna azione automatica sul singolo dato.
- Per un tracking affidabile in background serve un'app nativa (React Native/Capacitor): la logica GPS è già separata dalla UI.
- Offline: le conferme "sicure" (partito, arrivato, ordine non pronto) restano in coda locale e vengono inviate al ritorno
  della rete; ritiro con codice, consegna e annullamenti richiedono sempre il server.

## 7. Configurazione

1. Applica le migration (`supabase db push`): tabelle, RLS, bucket privati, publication realtime `delivery_realtime`.
2. Netlify: nessuna nuova variabile obbligatoria; facoltativo `MAPBOX_DIRECTIONS_TOKEN` (solo server).
3. Scheduler: `logistics-cron` (ogni minuto) è incluso; senza Netlify pianifica `select public.logistics_tick()`.
4. Admin → Logistica: zone servite (Taranto e provincia già create), regole compensi, impostazioni; Admin → Ristoranti →
   Ordini online: abilita i Rider AsiaFood per il ristorante.
5. Rider: candidatura su `/rider/apply`, approvazione in `/admin/riders` (assegna il ruolo `rider`).

## 8. Non incluso in questa fase

Batching avanzato, dispatch ML, prezzi dinamici, payroll bancario automatico, pagamento in contanti, fleet management avanzato,
navigazione turn-by-turn, chat completa Rider–cliente (tabella `delivery_messages` predisposta), support center enterprise.
