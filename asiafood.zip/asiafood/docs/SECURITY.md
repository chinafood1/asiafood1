# Sicurezza — AsiaFood (Fase 11)

Questo documento descrive il modello di sicurezza, l’audit della Fase 11 (vulnerabilità trovate e corrette), i controlli attivi e la procedura per gli incidenti. Per la matrice di accesso di ogni tabella vedi [`RLS_MATRIX.md`](RLS_MATRIX.md) (generata dal database: `npm run docs:rls`).

## 1. Modello

| Livello | Protezione |
|---|---|
| Browser | Solo chiavi pubbliche (`VITE_*`: anon key Supabase, publishable key Stripe, token Mapbox pubblico, site key Turnstile). Nessuna decisione di sicurezza lato client. |
| Database (Supabase) | **RLS su tutte le 129 tabelle** (controllato dai test e dalla launch checklist). Scritture sensibili solo tramite funzioni `SECURITY DEFINER` con controlli di ruolo/proprietà. Trigger di protezione su campi amministrativi (ruolo, proprietario, piano, sponsor, slug). |
| Backend (Netlify Functions) | Service role e segreti solo qui. Ogni endpoint passa da `server/platform/http.ts`: validazione env (Zod), request id, rate limit condiviso, manutenzione, formato errori standard, log con redazione. |
| Pagamenti | Stripe: importi calcolati dal database, webhook con firma verificata e idempotenza (`stripe_events`), nessun dato di carta salvato. |

Ruoli: `customer`, `restaurant_owner` (+ membri `owner/manager/staff` per locale), `rider`, `admin`, backend (`service_role`). **Sales/CRM non esiste in questa versione**: nessuna tabella, endpoint o permesso (il kill switch `crm_agents_enabled` è predisposto e spento).

## 2. Audit Fase 11 — vulnerabilità trovate e correzioni

| ID | Gravità | Problema | Correzione (dove) | Test |
|---|---|---|---|---|
| V-01 | **Alta** | `marketplace_stats()` e `ai_admin_stats()` eseguibili **da utenti anonimi**: il controllo `auth.uid() is not null and not is_admin()` lasciava passare chi non ha login → GMV, ricavi piattaforma, uso AI leggibili da chiunque con la anon key. | GRANT minimi (0022 §21): tutte le funzioni Admin/“Admin o backend” revocate a `PUBLIC`/`anon`. | `test:hardening` §1 |
| V-02 | Media | `billing_trial_expiring`, `billing_refresh_plans`, `ai_purge` eseguibili da anonimi: i vecchi `revoke … from anon` non toglievano il grant di default a `PUBLIC`. Possibile invio di notifiche/elaborazioni da chiunque. | Revoca da `PUBLIC` + grant espliciti. | §1 |
| V-03 | **Alta** (latente) | `assert_service()` accettava anche il ruolo `anon` (verificava solo l’assenza di utente): qualsiasi grant sbagliato in futuro avrebbe esposto le funzioni “solo backend”. | Rifiuta `anon`/`authenticated`; test di regressione con **allowlist** delle funzioni SECURITY DEFINER eseguibili da anonimi. | §1 |
| V-04 | Media | `platform_settings` leggibile da chiunque (soglie anti-abuso, parametri interni, modalità test pagamenti); `billing_setting('…')` eseguibile da anonimi aggirava qualsiasi filtro. | Colonna `is_public` + policy su allowlist; getter revocati ai client; `public_runtime_config()` per il frontend. | §1 |
| V-05 | Media | **SSRF**: l’endpoint di una push subscription poteva essere qualsiasi host `https://…` → il cron di invio avrebbe fatto richieste verso host arbitrari (anche interni). | Allowlist dei servizi push (FCM, Mozilla, Apple, Windows) nel trigger `push_subscriptions_guard`; iscrizioni esistenti non conformi disattivate. | `test:engagement` (SSRF) |
| V-06 | Media | Open redirect: `?next=/\evil.com` e varianti codificate superavano il controllo (bypass noto di React Router, GHSA-wrjc-x8rr-h8h6); URL di reindirizzamento dal backend usati senza allowlist. | `src/lib/safeRedirect.ts` (`safeNext`, `safeAssign` con host Stripe consentiti). | `test:unit` (9 casi) |
| V-07 | Media | Upload: solo controlli su estensione/MIME dichiarati; nome originale del file nel percorso dei documenti privati (dati personali); coordinate GPS EXIF nelle foto pubbliche. | `shared/uploads.ts` (firma reale del file, blocco SVG/HTML/eseguibili/doppie estensioni) + `src/lib/uploads.ts` (nome casuale, ridimensionamento e ricodifica WebP che rimuove EXIF). | `test:unit` |
| V-08 | Media | Segnalazioni anonime, messaggi di claim, voti, richieste di modifica, issue ordini senza limite per IP/utente. | Rate limit condiviso nel DB (`rate_limits`, trigger `rate_limit_trigger`, IP solo come hash salato). | §7 |
| V-09 | Bassa | L’Admin poteva cancellare fisicamente un ristorante con abbonamenti/prenotazioni (cascade) o un profilo; i log di audit erano cancellabili. | Trigger `restaurants_no_hard_delete`, `profiles_no_admin_delete`, `*_no_delete` su audit/eventi (solo la retention di sistema può cancellare). | §3 |
| V-10 | Bassa | Nessuna CSP/HSTS; Google Fonts caricati da terzi (IP degli utenti a Google senza consenso). | Header in `netlify.toml`; font self-hosted (`@fontsource-variable`). | `production-check`, smoke CSP |
| V-11 | Bassa | Statistiche con ID di sessione anche senza consenso. | `analyticsSessionId()` solo con consenso “Statistiche”; senza consenso restano conteggi anonimi aggregati. | E2E p11 |
| V-12 | Bassa | In produzione il segreto dei link ospite poteva essere derivato dalla service role key. | `ORDER_TOKEN_SECRET` obbligatorio in production (`server/orders/runtime.ts`, `validateEnv`). | `test:platform` |
| V-13 | Bassa | Errori in formati diversi, senza request id; 4 logger duplicati senza redazione. | `server/platform/http.ts` + `logger.ts` (redazione JWT, chiavi Stripe, email, telefoni, URL firmati). | `test:platform` §2–3 |
| V-14 | Info | `react-router` < 7.18: advisory moderati (open redirect con backslash — mitigato da V-06; SSR non usato). | Aggiornamento a v7 pianificato (breaking change, richiede test completi). | — |
| V-15 | Info | `esbuild` (dev server Vite) advisory moderato. | Solo sviluppo locale, non in produzione. | — |

Verificati senza problemi: **XSS** (nessun `dangerouslySetInnerHTML`, JSON-LD via `textContent`, testi utente sempre come testo), **SQL injection** (query parametrizzate supabase-js, `escapeLike` per `ilike`, `format(%I/%L)` nelle funzioni), **CSRF** (API con Bearer token, nessun cookie di sessione), **JWT** (verificato dal server con `auth.getUser`), **webhook spoofing** (firma Stripe + idempotenza), **mass assignment** (trigger `protect_*`), **privilege escalation** (ruolo/blocco protetti; test: un utente non diventa Admin né Rider), **IDOR** (test cross-tenant su ordini, prenotazioni, coupon, billing, analytics, clienti, Rider, posizioni).

## 3. Accesso server-side

Ogni endpoint sensibile: 1) autenticazione (`verifyUser` → JWT validato da Supabase), 2) ruolo, 3) proprietà (il database verifica `can_manage_restaurant`, `order_access`, `lg_rider_of`…), 4) validazione input (Zod in `shared/validation.ts` + CHECK nel DB), 5) nessun ID fidato dal client (prezzi, commissioni, destinatari ricalcolati). Le pagine `/admin/*` sono protette **anche** lato database: ogni RPC Admin verifica `is_admin()` e le tabelle hanno policy RLS; la protezione dell’interfaccia (`RequireRole`) è solo UX.

## 4. Rate limiting e anti-abuso

| Dove | Limite | Chiave |
|---|---|---|
| Recensioni | 6/ora (+ 5/giorno esistente) | utente |
| Coupon | 20/ora | utente o IP |
| Prenotazioni | 10/ora | utente o IP |
| Claim | 5/giorno · messaggi 30/ora | utente |
| Segnalazioni locali | 10/ora | IP (anonimi) · utente |
| Voti/segnalazioni recensioni | 120/ora · 20/ora | utente |
| Supporto | 8/ora utente · 5/ora IP ospite · API 10/ora IP | |
| Consensi | 30/ora | utente/IP |
| Export dati | 3/giorno | utente |
| GPS Rider | > 40 posizioni/min scartate (nessuna sospensione) | Rider |
| Ordini | limiti esistenti per cliente/IP (Fase 8) | |
| AI | limiti esistenti ospite/utente/IP (Fase 6) | |
| API Netlify | checkout 20/10 min, portal 20/10 min, azioni billing 30/10 min, ordini 60/min, logistica 120/min, health 120/min | hash IP |
| Login, registrazione, reset password | **Supabase Auth** (rate limit nativi + CAPTCHA Turnstile da attivare in dashboard) | IP |

Anti-bot: Cloudflare Turnstile sul modulo di supporto per ospiti (verifica server in `server/platform/turnstile.ts`); per registrazione/login/reset va attivato in Supabase → Authentication → Bot and Abuse Protection (stessa site key). Le RPC chiamate direttamente dal browser (recensioni, coupon, claim) richiedono login e sono limitate nel database.

## 5. Header e CSP

Configurati in `netlify.toml`: `Content-Security-Policy` (solo Supabase, Stripe, Mapbox/Google Maps facoltativi, Turnstile, Sentry facoltativo; nessun `unsafe-eval`; `unsafe-inline` solo per gli stili), `Strict-Transport-Security` (1 anno + sottodomini; `preload` dopo la verifica del dominio), `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy` (geolocalizzazione e fotocamera solo same-origin, pagamenti solo Stripe), `frame-ancestors 'none'` + `X-Frame-Options: DENY`, `Cross-Origin-Opener-Policy`. Smoke test: 10 pagine principali senza violazioni CSP. **Per aggiungere un provider** (es. un nuovo servizio email con widget) aggiorna la CSP e rilancia lo smoke test.

## 6. Segreti

- Solo server: `SUPABASE_SERVICE_ROLE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_CONNECT_WEBHOOK_SECRET`, `AI_API_KEY`, `VAPID_PRIVATE_KEY`, `ORDER_TOKEN_SECRET`, `TURNSTILE_SECRET_KEY`, `MAPBOX_*_TOKEN` server, `HEALTH_CHECK_TOKEN`, `IP_HASH_SALT`, `SENTRY_AUTH_TOKEN`; chiavi del provider email solo nei secret della Edge Function.
- `validateEnv` rifiuta segreti con prefisso `VITE_` (finirebbero nel bundle) e chiavi Stripe LIVE fuori da production.
- `npm run production-check` analizza il bundle (pattern + valori reali delle variabili server) → **0 segreti trovati**.
- `.gitignore`: `.env*` (tranne `.env.example`), chiavi `*.pem/*.key`, credenziali JSON, backup/dump.
- Rotazione: vedi RUNBOOK → “Incidente di sicurezza”.

## 7. Upload

| Bucket | Accesso | Limite | Tipi |
|---|---|---|---|
| `restaurant-media` | pubblico in lettura, scrittura solo gestori | 5 MB (config `upload_max_image_mb`) | JPEG/PNG/WebP/AVIF (ricodificate in WebP ≤ 2000 px, senza EXIF) |
| `claim-documents` | privato (utente + Admin), link firmati 2 min | 10 MB | PDF/JPEG/PNG/WebP |
| `rider-documents` | privato (Rider + Admin), link firmati 2 min | 10 MB | PDF/JPEG/PNG/WebP |
| `delivery-proofs` | privato | 5 MB | JPEG/PNG/WebP (ricodificate) |

Nel database si salvano **percorsi**, mai URL firmati. I nomi dei file sono casuali.

## 8. Incidenti di sicurezza (procedura)

1. **Identificare** — fonte (alert /admin/system, Sentry, segnalazione), perimetro, dati coinvolti; aprire un registro con orari UTC.
2. **Contenere** — kill switch in /admin/system (ordini, AI, dispatch, campagne), modalità manutenzione, revoca sessioni (Supabase → Auth → utenti), rotazione dei segreti coinvolti (Supabase JWT secret/service key, Stripe, VAPID, AI, `ORDER_TOKEN_SECRET`), blocco degli account sospetti (`is_blocked`).
3. **Investigare** — `admin_audit_logs`, `security_audit_logs`, log Netlify (request id), log Supabase (API/Auth/Postgres), Stripe Dashboard → Events.
4. **Ripristinare** — correggere, testare su staging, deploy, riaprire gradualmente i moduli; restore dati solo con la procedura DR.
5. **Documentare** — cronologia, causa, dati coinvolti, misure. **Violazione di dati personali**: valutare con il DPO/consulente la notifica al Garante **entro 72 ore** (art. 33 GDPR) e agli interessati se il rischio è elevato (art. 34).
