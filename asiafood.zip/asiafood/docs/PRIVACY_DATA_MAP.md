# Mappa dei dati personali (GDPR) — AsiaFood

> Documento di lavoro per il registro dei trattamenti (art. 30 GDPR). **Da revisionare con il consulente privacy/DPO**: basi giuridiche e tempi di conservazione con obblighi di legge vanno confermati.

Tutti i dati risiedono nel progetto **Supabase** (Postgres + Storage) della regione scelta alla creazione (consigliata UE — `eu-central-1` Francoforte). Il backend gira su **Netlify Functions**. I tempi di retention sono impostazioni modificabili dall’Admin (`platform_settings`, prefisso `retention_*`) ed eseguiti dal job `retention_cleanup` (cron di sistema, ogni 6 ore).

| Dato | Dove (tabella/bucket) | Perché | Chi accede | Retention |
|---|---|---|---|---|
| Account: nome, email, telefono, avatar | `auth.users`, `profiles` | Accesso, contatto | Utente; Admin | Fino alla cancellazione account (+ 7 giorni di sicurezza), poi anonimizzato ed eliminato |
| Preferiti, follow | `favorites` | Funzione preferiti | Utente | Eliminati con l’account |
| Prenotazioni: nome, telefono, email, note | `reservations` | Gestione prenotazione | Utente; ristorante interessato; Admin | Storico conservato per il ristorante; alla cancellazione account: dati personali rimossi |
| Ordini: nome, email, telefono, indirizzo, note, righe, importi | `orders`, `order_items`, `order_events` | Contratto, consegna, contabilità | Cliente; ristorante; Rider (solo dopo accettazione: indirizzo e contatto necessari); Admin | Contabilità: conservazione per il periodo di legge [DA CONFERMARE, di norma 10 anni]; alla cancellazione account i dati personali vengono sostituiti (“Cliente eliminato”); ordini mai pagati: dati personali rimossi dopo 90 giorni |
| Indirizzi salvati | `customer_addresses` | Consegne future | Utente | Eliminati con l’account |
| Pagamenti | Stripe (PAN/CVC **mai** in AsiaFood); `orders.stripe_*`, `subscriptions`, `billing_invoices` | Incasso, fatture | Admin; titolare (propri abbonamenti) | Come contabilità |
| Recensioni, voti, segnalazioni | `reviews`, `review_votes`, `review_reports` | Contenuti della piattaforma | Pubblico (recensioni pubblicate, nome visualizzato); Admin | Eliminate con l’account |
| AsiaPoints, premi, inviti | `loyalty_*`, `reward_redemptions`, `referral*` | Programma fedeltà | Utente; Admin | Eliminati con l’account |
| Notifiche e preferenze | `notifications`, `notification_preferences` | Comunicazioni | Utente | Notifiche scadute: 30 giorni dopo la scadenza; eliminate con l’account |
| Dispositivi push | `push_subscriptions` (endpoint + chiavi del browser) | Notifiche push | Solo backend | Disattivati: eliminati dopo 180 giorni; eliminati con l’account |
| Conversazioni assistente AI | `ai_chat_sessions`, `ai_chat_messages`; testo inviato al provider AI | Rispondere alle domande | Utente (sessione); backend | **7 giorni**; il provider AI tratta i messaggi secondo il DPA [DA VERIFICARE: nessun addestramento] |
| Preferenze AI | `ai_user_preferences` | Personalizzazione | Utente | Fino a modifica/cancellazione account |
| Consensi cookie/marketing | `user_consents` (utente o ID anonimo casuale) | Prova del consenso (art. 7) | Utente; Admin | Conservati come prova anche dopo la cancellazione (scollegati dall’utente) [DA CONFERMARE: es. 5 anni] |
| Richieste di export/cancellazione | `data_export_requests`, `account_deletion_requests` | Diritti dell’interessato | Utente; Admin (email mascherata) | Export: stato per 7 giorni (il file non è salvato sul server); cancellazioni: registro conservato |
| Ticket di supporto: email, nome, testo | `support_tickets` | Assistenza | Utente; Admin | Contatti rimossi 730 giorni dopo la chiusura |
| Rivendicazioni locale: nome, telefono, email, P.IVA, documenti | `restaurant_claims`, bucket privato `claim-documents` | Verifica titolarità | Richiedente; Admin (link 2 min) | [DA DEFINIRE]; eliminate con l’account del richiedente |
| Rider: anagrafica, telefono, veicolo | `rider_profiles` | Collaborazione consegne | Rider; Admin | Per la durata del rapporto + [DA DEFINIRE] |
| Documenti Rider | bucket privato `rider-documents`, `rider_documents` | Verifica idoneità | Rider; Admin (link 2 min) | 730 giorni dopo la chiusura; cancellazione manuale (obblighi legali) |
| Posizione GPS Rider | `rider_locations`, `rider_availability` | Dispatch e tracking consegna | Rider; Admin; cliente (solo dopo il ritiro, approssimata) | **24 ore**; posizione cancellata quando il Rider va offline |
| Foto prova di consegna (pacco, mai persone) | bucket privato `delivery-proofs` | Prova di consegna | Admin | [DA DEFINIRE, es. 90 giorni] |
| Compensi Rider | `rider_earnings` | Pagamenti | Rider; Admin | Come contabilità |
| Statistiche (eventi) | `analytics_events`, `app_events` (ID sessione solo con consenso “Statistiche”) | Statistiche per locali e piattaforma | Titolare (aggregati del proprio locale); Admin | 13 mesi (eventi app: 90 giorni) |
| Web Vitals | `web_vitals` (metrica, pagina “modello”, tipo di dispositivo; nessun ID) | Prestazioni | Admin | 90 giorni |
| Log errori | `system_error_log` (messaggi ripuliti da email/telefoni/token; IP come hash) | Stabilità | Admin | 90 giorni |
| Log di audit e sicurezza | `admin_audit_logs`, `security_audit_logs` (IP come hash salato, user agent sintetico) | Sicurezza, responsabilità | Admin | Sicurezza: 365 giorni; audit Admin: [DA DEFINIRE] |
| Contatori rate limit | `rate_limits` (hash IP o ID utente) | Anti-abuso | Solo backend | 48 ore |
| Dati tecnici del browser | `localStorage`: sessione, carrello, consenso, preferenze; `sessionStorage`: ID sessione (solo con consenso), posizione approssimata | Funzionamento | Solo il dispositivo | Fino alla cancellazione dal browser |

## Fase 12 · Go-to-market (nuovi trattamenti)

| Dati | Dove | Finalità / base giuridica | Chi accede | Conservazione |
|---|---|---|---|---|
| Lead commerciali B2B (nome attività, referente con consenso, email/telefono **di lavoro**, social, note, strumenti usati solo se pubblici/dichiarati) | `crm_leads`, `crm_activities`, `crm_tasks` | Contatto commerciale verso attività (legittimo interesse B2B, da confermare con il consulente); opposizione sempre rispettata (“Non ricontattare”) | Solo Admin | Lead persi/non interessati/da non contattare: contatti rimossi dopo `crm_lost_retention_days` (730 gg) |
| Creator, partner locali, stampa (contatti pubblici o forniti) | `crm_leads` (kind creator/partner/press) | Pubbliche relazioni e partnership | Solo Admin | Come sopra |
| Visite di atterraggio (canale, UTM, percorso senza query string, codice promo) | `acquisition_visits` | Statistiche aggregate di acquisizione (nessun identificativo) | Solo Admin | `retention_analytics_days` (13 mesi) |
| Canale d’iscrizione dell’utente | `user_acquisition` | Attribuzione — **solo con consenso “Statistiche”** | Admin, l’utente stesso | Fino alla cancellazione dell’account |
| Scansioni QR (solo tipo di QR e locale) | `analytics_events` (`qr_scan`) | Statistiche per il ristorante | Admin, ristoratore (aggregati) | Retention analytics |
| Feedback, NPS, motivo di disdetta (facoltativi) | `product_feedback` | Miglioramento del servizio | Admin; l’autore | Da definire con il consulente (proposta: 24 mesi) |
| Candidatura Ambassador (motivazione, codice invito) | `ambassadors` | Programma volontario | Admin, l’utente | Fino alla chiusura del programma o alla cancellazione |
| Badge Founding Foodie (data) | `profiles.founding_foodie_at` | Riconoscimento senza valore economico | Utente, Admin | Fino alla cancellazione |
| Partner Fondatori (numero, date, note) | `founding_partners` | Programma commerciale (dati dell’attività) | Admin; ristoratore del locale | Durata del rapporto + obblighi contabili |
| Contenuti marketing, incidenti, costi, obiettivi, esperimenti | tabelle omonime | Operazioni interne (nessun dato di clienti; UGC solo con permesso) | Solo Admin | Finché utili |

Esperimenti A/B: identificativo locale casuale (`af_exp_id`) nel browser per mantenere la stessa variante; l’esposizione viene registrata solo con consenso “Statistiche”. Attribuzione della sessione in `sessionStorage` (`af_touch`), mai inviata con identificativi.

## Fase 13 · Business Intelligence (nuovi trattamenti)

| Dati | Dove | Finalità / base giuridica | Chi accede | Conservazione |
|---|---|---|---|---|
| Ricerche: testo normalizzato (scartato se contiene email, numeri lunghi o link), comune/categoria, numero e id dei risultati, sessione **solo con consenso** | `search_events` | Statistiche di domanda e supply gap (nessun utente, IP o posizione) | Solo Admin | `growth_search_log_days` (90 gg); poi solo aggregati anonimi |
| Aggregati giornalieri (conteggi) | `daily_*_metrics` | Dashboard e report | Admin; il ristoratore solo le righe del proprio locale | Finché utili (anonimi) |
| Filtri strutturati delle richieste AI (comune, categoria, termine di piatto — mai il messaggio) | `ai_usage.search_*`, `search_events` (source ai) | Domanda non servita | Solo Admin | Come `ai_usage` |
| Assegnazione esperimenti (id locale casuale, utente se loggato) e conversione sulla metrica primaria — **solo con consenso "Statistiche"** | `experiment_assignments` | Misurare varianti | Solo Admin | Scollegate dall'utente all'anonimizzazione dell'account |
| Bozze di messaggi generate dalle automazioni (destinatario solo con consenso marketing) | `automation_items` | Comunicazioni promozionali **approvate da un Admin** | Solo Admin (il contatto del destinatario non è mostrato) | Eliminate all'anonimizzazione dell'account |
| First touch del browser (canale/UTM della prima visita) — **solo con consenso "Statistiche"** | `localStorage` `af_first_touch`, poi `user_acquisition` | Attribuzione dell'iscrizione (modello first/last touch) | Admin, l'utente | Fino alla cancellazione dell'account |
| Metadati standard degli eventi (tipo di dispositivo, UTM della sessione) | `analytics_events.metadata`, `app_events.metadata` | Statistiche | Admin; ristoratore (aggregati) | Retention analytics |

Export CSV: solo aggregati, nessun dato personale. Le dashboard del ristoratore mostrano esclusivamente i dati del proprio locale.

## Fornitori (responsabili del trattamento — verificare DPA)

Supabase (database, auth, storage), Netlify (hosting, funzioni, log), Stripe (pagamenti, Connect), provider AI configurato (`AI_PROVIDER`), provider email (Edge Function `send-emails`), Mapbox (mappe/geocoding, se attivo), Cloudflare (Turnstile, se attivo), Sentry (se attivo), servizi push del browser (Google/Mozilla/Apple/Microsoft: ricevono solo il contenuto della notifica).

## Diritti dell’interessato — come vengono soddisfatti

| Diritto | Strumento |
|---|---|
| Accesso / portabilità | `/settings/privacy` → “Scarica i miei dati” (JSON generato nel browser, RPC `privacy_export`) |
| Cancellazione | `/settings/privacy` → “Elimina account” (password, 7 giorni annullabili, anonimizzazione + eliminazione Auth dal cron) |
| Revoca consenso | Banner/“Preferenze cookie”, `/settings/privacy`, preferenze notifiche |
| Rettifica | Profilo; per dati degli ordini: supporto |
| Opposizione/limitazione e altre richieste | `/support` (categoria “Privacy e dati”, priorità alta) |
