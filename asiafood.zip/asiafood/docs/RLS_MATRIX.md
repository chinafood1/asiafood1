# Matrice RLS (generata)

Generata da `scripts/generate-rls-matrix.ts` sulle migrazioni attuali (2026-09-28). Non modificare a mano: `npm run docs:rls`.

Legenda: **✓** tutte le righe · **own** solo righe proprie (auth.uid) · **pub** solo contenuti pubblicati/attivi · **mgr** solo locali gestiti (titolare/staff) · **rider** solo dati propri del Rider · **cond** condizione specifica · **rpc** nessun accesso diretto (solo funzioni con controlli) · **—** negato.
SALES: il ruolo Sales/CRM non esiste in questa versione (nessun accesso). SERVICE ROLE: bypassa RLS (solo backend, mai nel browser).

| Tabella | RLS | Op | PUBLIC (anon) | AUTH USER | RESTAURANT OWNER | RIDER | SALES | ADMIN | SERVICE ROLE |
|---|---|---|---|---|---|---|---|---|---|
| `account_deletion_requests` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `achievements` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `acquisition_codes` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `acquisition_costs` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `acquisition_visits` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `admin_audit_logs` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `ai_cache` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `ai_chat_messages` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `ai_chat_sessions` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
| `ai_usage` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `ai_user_preferences` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | DELETE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
| `allergens` | on | SELECT | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `ambassadors` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `analytics_events` | on | SELECT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `app_events` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `automation_items` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `automation_rules` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `automation_runs` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `background_jobs` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `beta_invites` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `billing_accounts` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `billing_activity` | on | SELECT | rpc | — | mgr | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `billing_invoices` | on | SELECT | rpc | own | own+mgr | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `billing_promotion_redemptions` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `billing_promotions` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `billing_requests` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `billing_trials` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `business_referrals` | on | SELECT | rpc | own | own+mgr | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `campaign_deliveries` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `campaigns` | on | SELECT | rpc | — | mgr | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `cart_item_addons` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `cart_items` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `carts` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `categories` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `cities` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `coupon_claims` | on | SELECT | rpc | own | own+mgr | own | — | own+mgr | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `coupon_redemptions` | on | SELECT | rpc | own | own+mgr | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `coupons` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `crm_activities` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `crm_leads` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `crm_tasks` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `customer_addresses` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | DELETE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
| `daily_acquisition_metrics` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `daily_market_metrics` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `daily_platform_metrics` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `daily_restaurant_metrics` | on | SELECT | rpc | — | mgr | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `daily_search_metrics` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `data_export_requests` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `delivery_assignments` | on | SELECT | rpc | own | own | own+rider | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `delivery_events` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `delivery_issues` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `delivery_jobs` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `delivery_messages` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `delivery_ratings` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `delivery_realtime` | on | SELECT | rpc | own | own+mgr | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `delivery_service_zones` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `delivery_zones` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `email_outbox` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `expansion_candidates` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `experiment_assignments` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `experiment_variants` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `experiments` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `favorites` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | DELETE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
| `founding_partners` | on | SELECT | rpc | — | mgr | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `growth_alerts` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `growth_computed_days` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `growth_event_taxonomy` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `growth_goals` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `growth_learnings` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `growth_reports` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `growth_tasks` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `import_batches` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `job_locks` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `launch_checks` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `launch_incidents` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `launch_plan_items` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `legal_document_versions` | on | SELECT | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | DELETE | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
| `logistics_alerts` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `loyalty_accounts` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `loyalty_levels` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `loyalty_rules` | on | SELECT | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `loyalty_transactions` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `market_cities` | on | SELECT | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `market_playbook_items` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `marketing_content` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `markets` | on | SELECT | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `menu_categories` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `menu_item_addons` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `menu_item_variants` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `menu_items` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `menu_option_groups` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `menu_options` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `menus` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `notification_delivery_log` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `notification_preferences` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | DELETE | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
| `notifications` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
| `offers` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `operating_costs` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_events` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_issues` | on | SELECT | rpc | own | own+mgr | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_item_options` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_items` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_rate_limits` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_realtime` | on | SELECT | rpc | own | own+mgr | own | — | own+mgr | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_refunds` | on | SELECT | rpc | — | mgr | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_secrets` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `order_track_failures` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `orders` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `plan_features` | on | SELECT | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `plan_upgrade_requests` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | own | own+mgr | own | — | own+mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `platform_settings` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `product_feedback` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `profiles` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `provinces` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `push_outbox` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `push_subscriptions` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | rpc | own | own | own | — | own | ✓ (bypass RLS) |
| `rate_limits` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `referral_codes` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `referrals` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `regions` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `reservation_settings` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `reservation_slots` | on | SELECT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `reservations` | on | SELECT | rpc | own | own+mgr | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `restaurant_categories` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `restaurant_change_requests` | on | SELECT | rpc | own | own+mgr | own | — | own+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | own | own+mgr | own | — | own+mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `restaurant_claim_messages` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `restaurant_claims` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `restaurant_closures` | on | SELECT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `restaurant_commission_settings` | on | SELECT | rpc | — | mgr | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | DELETE | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
| `restaurant_hours` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `restaurant_images` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `restaurant_launch_progress` | on | SELECT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `restaurant_members` | on | SELECT | rpc | own | own+mgr | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `restaurant_order_settings` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
| `restaurant_payout_accounts` | on | SELECT | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `restaurant_reports` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | pub | pub+own | pub+own | pub+own | — | pub+own | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `restaurant_slug_history` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `restaurant_sources` | on | SELECT | pub | pub | pub+mgr | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `restaurants` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | mgr | — | — | mgr | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `review_reports` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `review_responses` | on | SELECT | pub | pub | pub+mgr | pub | — | pub+mgr | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `review_versions` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `review_votes` | on | SELECT | rpc | own | own | own | — | own | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `reviews` | on | SELECT | pub | pub+own | pub+own | pub+own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `reward_redemptions` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `rewards` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `rider_availability` | on | SELECT | rpc | own | own | own+rider | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `rider_compensation_rules` | on | SELECT | rpc | — | — | rider | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `rider_documents` | on | SELECT | rpc | own | own | own+rider | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `rider_earnings` | on | SELECT | rpc | own | own | own+rider | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `rider_locations` | on | SELECT | rpc | own | own | own+rider | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `rider_payout_accounts` | on | SELECT | rpc | own | own | own+rider | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `rider_profiles` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `search_events` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `security_audit_logs` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `sponsored_campaigns` | on | SELECT | rpc | — | mgr | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `stripe_events` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `subscription_plans` | on | SELECT | pub | pub | pub | pub | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | UPDATE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | DELETE | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
| `subscriptions` | on | SELECT | rpc | own | own+mgr | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `support_tickets` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `system_error_log` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `system_secrets` | on | SELECT | rpc | rpc | rpc | rpc | — | rpc | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `user_achievements` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `user_acquisition` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `user_activity_days` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `user_consents` | on | SELECT | rpc | own | own | own | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |
| `web_vitals` | on | SELECT | rpc | — | — | — | — | ✓ | ✓ (bypass RLS) |
|  |  | INSERT | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | UPDATE | — | — | — | — | — | — | ✓ (bypass RLS) |
|  |  | DELETE | — | — | — | — | — | — | ✓ (bypass RLS) |

Tabelle: 167 · senza RLS: 0. Le policy complete (nome, espressione) sono nelle migrazioni; i test concreti di accesso sono in `scripts/test-hardening.ts` e `scripts/test-rls.mjs`.
