# Sales Playbook · Taranto

> Strumenti: `/admin/launch/taranto/first50`, `/crm`, `/daily`. I testi personalizzati (nome del locale, link della scheda con UTM, posti Fondatori rimasti) si generano nella scheda lead → **Outreach**. Nessun invio automatico: si copia o si apre WhatsApp/email e l’invio lo fa una persona.

## 1. Proposta di valore
AsiaFood **non è solo delivery**: è la piattaforma verticale della cucina asiatica di Taranto e provincia.
- **Scoperta**: ricerca, mappa, categorie (sushi, giapponese, cinese, poke, ramen, AYCE), assistente AI che risponde solo con i dati presenti.
- **Profilo**: scheda verificata con menu, orari, foto, servizi e prezzi gestiti dal ristoratore.
- **Menu digitale + QR** per tavoli e banco.
- **Prenotazioni** e **ordini** (facoltativi).
- **Offerte e coupon** con condizioni decise dal ristoratore.
- **Fidelizzazione**: AsiaPoints, inviti, recensioni verificate.
- **Visibilità locale** e **statistiche reali** (visite, chiamate, indicazioni, prenotazioni, scansioni QR).

## 2. Segmentazione (priorità commerciale interna)
Punteggio calcolato dai dati (non un giudizio sul locale): AYCE (+20), asporto/consegna (+10), menu presente (+10), presenza social (+10), più sedi (+15), zona ad alta domanda (Taranto +15, Massafra/Martina/Grottaglie +10, altri prioritari +5), prenotazioni (+5), completezza (fino a +10), visite ultime 30 gg (fino a +10).
- **A** ≥ 50 → alta priorità · **B** ≥ 30 → buona opportunità · **C** → da contattare più avanti.
- L’Admin può forzare il segmento nel lead ("override interno").

## 3. First 50
Lista in `/first50`: prima A, poi B, poi C; a parità, punteggio e completezza. Esclusi: paganti, chiusi, persi/non interessati, chi ha chiesto di non essere ricontattato. Campi: attività, comune, contatti pubblici, stato rivendicazione, stato lead, assegnato, prossima azione, ultimo contatto, piano potenziale. N configurabile (`launch_first_n`).

## 4. Offerta di lancio: “Partner Fondatore AsiaFood Taranto”
- Per chi **rivendica** il profilo e aderisce: profilo verificato, onboarding assistito, menu digitale, statistiche, offerte, coupon, prenotazioni (se il piano le include) e **N giorni di piano gratuito** (default Premium 30 giorni; configurabile: piano, giorni, limite 20/30/50).
- Alla scadenza il piano **scade senza addebiti**: per continuare serve un abbonamento scelto dal ristoratore.
- Badge “Partner Fondatore” **solo** sulle schede degli aderenti reali; revocabile con motivo (audit).
- Attivazione solo dall’Admin (scheda lead → Partner Fondatore), mai automatica.

## 5. Script
### Telefonata (struttura, non copione)
1. **Presentazione** (10 s): “Buongiorno, sono [nome] di AsiaFood. Parlo con il titolare o con chi gestisce la comunicazione?”
2. **Motivo**: “Stiamo lanciando AsiaFood, una piattaforma dedicata esclusivamente alla cucina asiatica a Taranto e provincia.”
3. **Profilo già presente — SOLO se vero**: “Abbiamo già predisposto la vostra presenza sulla piattaforma e stiamo selezionando i primi ristoranti partner della zona.”
4. **Vantaggio**: menu, orari, offerte e prenotazione in un tocco; statistiche di chi guarda, chiama o chiede indicazioni.
5. **Demo**: 5 minuti ora al telefono o di persona con un tablet.
6. **Rivendicazione**: gratuita, link via WhatsApp/email.
7. **Prova**: offerta Partner Fondatore se ci sono posti.
8. **Esito nel CRM** (interessato / richiamare / non interessato / non ricontattare).

### WhatsApp (breve, una sola CTA)
> Ciao! Sono [nome] di AsiaFood, la piattaforma dedicata alla cucina asiatica a Taranto e provincia.
> [Locale] è già presente su AsiaFood con una scheda base: potete rivendicarla gratis e gestire voi menu, orari, foto e offerte.
> **Ti mando il link della vostra scheda?**

(Se la scheda non esiste: “Stiamo selezionando i primi ristoranti partner della zona… Ti mando due righe su come funziona?”)

### Email
Oggetto: `[Locale] su AsiaFood · [Comune]` — corpo: presentazione, link alla scheda (se esiste), rivendicazione gratuita, offerta Fondatori (se disponibile), CTA demo, firma. Generata nella scheda lead.

### Instagram DM
Breve, tono informale, una domanda finale (“Vi mandiamo il link?”).

### Visita di persona (2–3 minuti)
Nei momenti tranquilli, mai durante il servizio. Materiali: smartphone/tablet con la scheda e la mappa, QR del ristorante (table card), volantino “Porta il tuo ristorante su AsiaFood” con QR → `/per-ristoratori`, prezzi (`/business/pricing`). Se interessati: rivendicazione dal loro telefono, poi prima offerta scelta da loro.

## 6. Obiezioni (senza denigrare nessuno)
| Obiezione | Risposta |
|---|---|
| “Uso già Just Eat.” | Continuate pure: AsiaFood non sostituisce il delivery. È una vetrina solo per la cucina asiatica (menu, prenotazioni, offerte, indicazioni) e porta clienti anche in sala e all’asporto. |
| “Uso già TheFork.” | Ottimo per le prenotazioni. Qui chi cerca sushi, ramen o AYCE a Taranto trova solo locali asiatici; potete indicare il vostro canale di prenotazione preferito. |
| “Non voglio un altro abbonamento.” | Scheda e rivendicazione gratuite; i piani sono facoltativi e si provano senza costi: decidete dopo aver visto i numeri reali. |
| “Non ho bisogno di prenotazioni.” | Sono facoltative: molti clienti chiamano o chiedono indicazioni dalla scheda. |
| “Ho già il mio sito.” | Resta il vostro riferimento e lo colleghiamo alla scheda; AsiaFood vi fa trovare da chi non vi conosce. |
| “Non faccio delivery.” | AsiaFood è scoperta, menu, prenotazioni, offerte, fidelizzazione e visibilità locale; delivery facoltativo. |

## 7. ROI: solo numeri misurati
Dopo le prime conversioni reali, mostra al ristoratore (Partner → ROI 30 gg): visite, chiamate, indicazioni, prenotazioni, ordini, coupon usati, scansioni QR. **Mai promettere risultati futuri.**

## 8. Igiene del CRM
- Ogni contatto → attività con esito e prossima azione con data.
- “Non ricontattare” blocca ogni outreach (anche win-back) e dopo 24 mesi i dati di contatto vengono rimossi.
- Concorrenti: solo se pubblici o dichiarati, con la fonte.
- Referente: solo con consenso a essere contattato; email/telefono di lavoro.
- Creator: non valutarli solo dai follower; collaborazioni tracciate, con #adv se c’è un corrispettivo.

## 9. Target giornalieri (operativi, configurabili)
10 lead ricercati · 10 contatti · 3 demo · 2 rivendicazioni · 1 prova. Servono a organizzare la giornata, non sono promesse.

## 10. Partner success e churn
- Health score di **utilizzo** (profilo, menu, accessi, offerte, risposta alle prenotazioni, azioni dei clienti) — non è qualità del ristorante.
- Segnali di rischio → task automatici (piano gratuito in scadenza, nessun accesso da 14 gg, profilo < 60%, zero azioni clienti in 30 gg).
- Disdetta: motivo **facoltativo** nel dialog; la cancellazione non viene mai impedita. Win-back solo se il contatto è consentito.
- Referral ristorante → ristorante: premi configurabili (mese Premium, crediti sponsorizzazione, beneficio manuale) in Admin → Inviti.
- Sponsorizzazioni per i primi partner Top: sempre etichettate “Sponsorizzato”.
