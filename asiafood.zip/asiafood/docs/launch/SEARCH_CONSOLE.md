# Google Search Console e SEO locale

## Verifica (manuale)
1. search.google.com/search-console → **Aggiungi proprietà**. Consigliata la proprietà **Dominio** (record TXT sul DNS del dominio: copiare il valore esatto fornito da Google nel pannello del registrar — non inventarlo).
2. In alternativa, proprietà **Prefisso URL** con metodo “Tag HTML”: copiare solo il valore di `content` in `VITE_GOOGLE_SITE_VERIFICATION` (Netlify → Environment variables, contesto Production) e rifare il deploy: il meta tag viene inserito in `index.html` in build.
3. Verificare anche la variante `www` se non reindirizzata.

## Sitemap
- In Search Console → Sitemap → invia `https://<dominio>/sitemap.xml` (sitemap index: pagine, città, categorie, offerte, ristoranti).
- La sitemap si rigenera a ogni build (`npm run sitemap`, dal database se configurato). `/taranto` è inclusa solo con almeno 3 locali pubblici; le pagine categoria×città solo sopra la soglia `seo_min_restaurants_category_city`.
- Staging: `robots.txt` blocca tutto (non inviare sitemap di staging).

## Monitoraggio dell’indicizzazione (settimanale)
- **Pagine** → “Non indicizzata”: controllare “Pagina con reindirizzamento” (slug cambiati: 301 corretti), “Esclusa da tag noindex” (atteso per pagine sotto soglia, bozze legali, aree private), “Soft 404”.
- **Prestazioni** → query: `sushi taranto`, `sushi taranto centro`, `all you can eat taranto`, `ristorante giapponese taranto`, `ristorante cinese taranto`, `poke taranto`, `ramen taranto`, `sushi massafra`, `sushi martina franca`, `sushi grottaglie`.
- **Core Web Vitals** (dati di campo, dopo ~28 giorni di traffico) → annotare in `/admin/launch-checklist`.
- Launch Control → **SEO locale**: stato pronto/non pronto delle 9 query prioritarie (pagina categoria×città con abbastanza locali pubblici).

## Regole contenuti
- Nessuna pagina vuota: sotto soglia `noindex` e fuori sitemap.
- Testi utili basati sul database (“N ristoranti di sushi a Taranto disponibili su AsiaFood”), niente testi gonfiati.
- “Taranto centro”: nessuna pagina di quartiere finché i dati non hanno il quartiere.
- Collegamenti interni: landing → categorie×città → schede; schede → comune e categoria; mappa e offerte dalla landing e dal footer.
