# Metriche di lancio: definizioni

Tutte calcolate nel database (`launch_metric`, migrazione 0024). Mercato = provincia del mercato (Taranto). Locali DEMO esclusi salvo `show_demo_data = true` (in quel caso la UI lo dichiara). Utenti: tutti i profili cliente (un solo mercato attivo).

## Ristoranti
| Metrica | Definizione |
|---|---|
| Censiti | Locali nel database del mercato, bozze comprese, esclusi i chiusi definitivamente non pubblicati |
| Pubblicati (listed) | `is_active` e non chiusi definitivamente |
| Verificati | Pubblicati con `is_verified` o `data_status = verified` |
| Rivendicati | Con titolare (`owner_id`) |
| Partner | Rivendicati **e** (Partner Fondatore attivo/concluso **o** piano non free con accesso attivo) |
| Paganti | Abbonamento Stripe nell’ambiente corrente, attivo/past_due, con primo pagamento (`paid_started_at`) |
| Premium/Top | Piano effettivo premium o top |

## Completezza dati (0–100)
Nome 5 · indirizzo 8 · coordinate 10 · telefono/WhatsApp 8 · orari 10 · categorie 8 · logo 5 · copertina o foto 8 · menu 10 · social o sito 6 · servizi 5 · prezzi 6 · AYCE (prezzi se AYCE) 4 · consegna/asporto noti 3 · prenotazioni (canale se dichiarate) 4. **Dati obsoleti**: non rivendicati e non verificati da `data_stale_days` (180). **Doppioni possibili**: stesso nome normalizzato nello stesso comune o stesso telefono. **Posizione anomala**: > 25 km dal centro del comune.

## Segmento commerciale (interno)
Vedi SALES_PLAYBOOK § 2. Non è un giudizio di qualità e non è pubblico.

## Attivazione
- **Utente attivato**: almeno un preferito, un coupon salvato, una prenotazione o un ordine pagato entro 30 giorni dall’iscrizione (misurato sugli iscritti 30–60 giorni fa).
- **Ristorante attivato**: completezza ≥ 70 **e** (menu **o** offerta) **e** almeno una azione misurabile di un cliente (prenotazione, ordine completato, coupon, chiamata, WhatsApp, indicazioni, sito, avvio prenotazione).

## North Star: Successful Food Connections
Prenotazioni **completate** + ordini **completati** + coupon **usati in cassa** + clic su **indicazioni stradali** deduplicati per locale/giorno/sessione (se c’è consenso; altrimenti ogni evento). Le visualizzazioni da sole non sono una misura di successo.

## Funnel
- **Utente (30 gg, conteggi per fase)**: visite → ricerche → schede viste → menu visti → preferiti → prenotazioni/ordini → recensioni → utenti tornati (≥ 2 giorni di attività). Non è il percorso della stessa persona.
- **Business**: censiti → lead → contattati → rivendicati → in prova (Fondatori o trial) → attivati → paganti → trattenuti (paganti da oltre 60 gg).

## Coorti
Utenti per settimana d’iscrizione: ritorno in settimana 2 (giorni 7–13) e dopo. Ristoranti per settimana di rivendicazione: attivati, paganti. Conversione prove: Fondatori conclusi → paganti; prove Stripe concluse → convertite.

## Tempo al valore
Mediane in ore dalla rivendicazione a: profilo completato (onboarding), primo menu, prima offerta, prima prenotazione, primo pagamento.

## Obiettivi
Metriche di stato (censiti, rivendicati, partner, paganti, utenti, attivi, MRR, campagne) misurate **ora**; metriche di flusso (prenotazioni, ordini, coupon, recensioni, referral, QR, Food Connections) nel periodo. Stato: raggiunto se actual ≥ target; troppo presto nel primo 10% del periodo; in linea se actual/target ≥ 90% della frazione di periodo trascorsa; a rischio ≥ 60%; altrimenti in ritardo.

## Acquisizione e attribuzione (privacy)
- `acquisition_visits`: una riga per **sessione** con canale, UTM normalizzati, percorso di atterraggio (senza query string), codice promo valido. **Nessun utente, sessione, IP o user agent.**
- `user_acquisition`: canale dell’iscrizione, **solo con consenso “Statistiche”**, una volta, entro 7 giorni dalla registrazione.
- Canali: ricerca organica, social, QR, diretto, invito utente, invito ristorante, social a pagamento, creator, email, partner, offline, altro (regole in `shared/utm.ts`).
- QR: evento `qr_scan` con il solo tipo (profilo, menu, recensioni, prenotazione, offerte).

## CAC e LTV
- **CAC ristorante** = costi registrati (audience ristoranti) nel periodo ÷ nuovi paganti nel periodo; **CAC utente** = costi (audience utenti) ÷ nuovi iscritti. Calcolati **solo** se ci sono costi e almeno `cac_min_conversions` (5) conversioni; altrimenti “non calcolabile” con il motivo.
- **LTV (preparazione)**: ricavi reali per ristorante (fatture abbonamento pagate + commissioni/costi di servizio degli ordini completati; sponsorizzazioni da aggiungere quando fatturate). Nessun valore attribuito ai singoli utenti.

## Health score partner (utilizzo)
30% completezza + 15 menu + 20 accesso ultimi 7 gg (10 se entro 14) + 15 offerte attive + 10 nessuna prenotazione in attesa da > 24 h + 10 almeno un’azione dei clienti in 30 gg.
