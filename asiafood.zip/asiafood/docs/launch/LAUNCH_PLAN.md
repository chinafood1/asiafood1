# Piano di lancio · Taranto e provincia

## Fasi
| Fase | Perimetro (esempio) | Obiettivo | Impostazioni |
|---|---|---|---|
| **A · Beta privata** | 5–10 ristoranti, 50–100 utenti invitati | bug e feedback | `beta_mode` on, `beta_invite_only` on (inviti da Admin → Sistema), `founding_foodie_open` on |
| **B · Beta locale** | 20+ ristoranti, pubblico limitato a Taranto | primi utenti reali, qualità dati | registrazione aperta, badge Beta |
| **C · Lancio pubblico** | campagna completa | acquisizione | solo con `/admin/launch-checklist` senza blocker |

Cambio fase: Piano e obiettivi → Fasi (conferma, audit). Il cambio **non** tocca impostazioni critiche (inviti, manutenzione, pagamenti): restano in Admin → Sistema.

## Target iniziali (operativi, non garantiti)
100+ ristoranti censiti · 30 rivendicati · 20 partner · 10 paganti · 1.000 utenti registrati · 500 attivi. Prenotazioni e azioni commerciali: da misurare progressivamente (nessun target imposto). Configurabili in Piano e obiettivi (periodo, target). Stato: *troppo presto per valutare* (primo 10% del periodo), *in linea*, *a rischio*, *in ritardo*, *raggiunto*.

## Piano 30 giorni (checklist nel prodotto)
- **Settimana 1** — beta privata, QA dati, sincronizzare i lead, primi 5 Partner Fondatori, bug fixing.
- **Settimana 2** — outreach First 50 (10 contatti/giorno), distribuzione QR Kit, calendario social, prima offerta per ogni partner.
- **Settimana 3** — lancio consumer (/taranto), referral, partnership locali, passaggio a beta locale.
- **Settimana 4** — conversione trial → abbonamento, analisi retention (coorti), preparazione espansione.

## Roadmap 90 giorni
- **Mese 1** — validazione Taranto (prime Food Connections reali, feedback, primi paganti).
- **Mese 2** — saturazione della provincia (comuni prioritari, qualità dati, SEO locale pronta).
- **Mese 3** — preparazione del secondo mercato **basata sui dati** (Piano → Espansione: locali censiti fuori mercato, rivendicazioni, lead, preferiti; CAC reale a Taranto).

## Rituali
**Ogni giorno** — `/daily`: lead in scadenza, follow-up, demo, rivendicazioni (SLA 48 h), piani in scadenza, task. `/today`: segnalazioni dati (priorità), supporto (SLA 24 h), problemi ordini (2 h), pagamenti falliti, incidenti. Qualità dati: chiusi, orari/telefoni errati, posizioni sulla mappa, doppioni.
**Ogni settimana** — `/growth`: review settimanale (contattati, risposte, rivendicazioni, prove, paganti, nuovi utenti, traffico, prenotazioni, ordini, MRR), feedback loop (problemi e richieste principali, abbandoni nel funnel, voce di ristoratori e utenti, NPS), coorti; aggiornare il piano.

## Incidenti di lancio
Categoria `launch_incident` con gravità bassa/media/alta/critica (Operations → Incidenti). Alta/critica compaiono come avviso in panoramica. Procedura tecnica: `docs/RUNBOOK.md`.

## Scenario (forecast)
Solo con ipotesi inserite dall’Admin (contatti/settimana, % contatto→rivendicazione, % rivendicazione→pagante, €/mese), per **Conservative / Base / Growth**, mostrate separate dagli **actual**. Nessuna previsione è calcolata senza ipotesi.

## SLA interni (non pubblici)
Rivendicazioni 48 h · prima risposta supporto 24 h · problemi ordini 2 h · segnalazioni dati 72 h. Configurabili; mai mostrati come garanzia al pubblico.
