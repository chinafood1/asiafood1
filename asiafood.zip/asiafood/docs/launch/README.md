# Go-to-market Taranto (Fase 12)

Obiettivo: portare AsiaFood nel mercato reale di **Taranto e provincia** con una macchina commerciale locale misurabile.
Tutto ciò che richiede persone (telefonate, visite, partnership, stampa, campagne) ha nel prodotto **dashboard, checklist, template e tracciamento**; niente viene inviato o pubblicato automaticamente.

| Documento | Contenuto |
|---|---|
| [SALES_PLAYBOOK.md](SALES_PLAYBOOK.md) | Proposta di valore, segmenti, First 50, script (telefono, WhatsApp, email, Instagram, visita), obiezioni, Partner Fondatori, CRM |
| [MARKETING_PLAN.md](MARKETING_PLAN.md) | Campagna consumer, landing, calendario social 30 giorni, UGC, spotlight, giveaway (compliance), street marketing, partnership, PR, email |
| [LAUNCH_PLAN.md](LAUNCH_PLAN.md) | Fasi A/B/C, piano 30 giorni, roadmap 90 giorni, rituali giornalieri/settimanali, qualità dati, incidenti, scenario |
| [METRICS.md](METRICS.md) | Definizioni: completezza, segmenti, attivazione, North Star, funnel, coorti, obiettivi, CAC/LTV, attribuzione |
| [SEARCH_CONSOLE.md](SEARCH_CONSOLE.md) | Verifica, invio sitemap, monitoraggio indicizzazione, SEO locale |

## Dove si fa cosa (strumenti nel prodotto)

| Area | Percorso |
|---|---|
| Launch Control (panoramica, avvisi, avanzamento, North Star) | `/admin/launch/taranto` |
| Vendite di oggi (target, lead da chiamare, rivendicazioni, piani in scadenza) | `/admin/launch/taranto/daily` |
| Operations "Oggi" (SLA interni, incidenti) | `/admin/launch/taranto/today` |
| Copertura per comune + mappa | `/admin/launch/taranto/coverage` |
| First 50 | `/admin/launch/taranto/first50` |
| CRM (ristoranti, creator, partner locali, stampa) | `/admin/launch/taranto/crm` |
| Qualità dati | `/admin/launch/taranto/quality` |
| Partner success (health, rischi, Fondatori, tempo al valore) | `/admin/launch/taranto/partners` |
| Crescita (review settimanale, funnel, coorti, UTM, codici, esperimenti, CAC) | `/admin/launch/taranto/growth` |
| Marketing (calendario, materiali stampabili, template) | `/admin/launch/taranto/marketing` |
| Piano, obiettivi, scenario, impostazioni, feedback, ambassador, espansione | `/admin/launch/taranto/plan` |
| Kit QR del ristorante (PNG, SVG, PDF) | `/dashboard/restaurants/:id/qr-kit` |
| Kit di lancio del ristorante | `/dashboard/restaurants/:id/launch-kit` |
| Landing consumer | `/taranto` (alias `/launch/taranto`) |
| Press kit · installazione app | `/press` · `/app` |

## Il processo in 24 passi

1. Apri **Launch Control** → 2. **Copertura** per comune → 3. **First 50** → 4. assegna i lead (CRM) → 5. contatta (script, registra l’esito) → 6. invia il link di rivendicazione (template WhatsApp/email; l’attività "Link rivendicazione inviato" aggiorna lo stato) → 7. dopo la rivendicazione approvata attiva **Partner Fondatore** (piano gratuito a tempo, nessun addebito automatico) → 8. il ristoratore completa il profilo (**Kit di lancio**) → 9. genera il **Kit QR** → 10. crea la **prima offerta** (condizioni sue) → 11. distribuisci i QR (table card/counter card/sticker) → 12. lancia la **landing /taranto** → 13. acquisisci utenti (social, partner, volantini con UTM) → 14. traccia le **UTM** (Crescita → Campagne) → 15. attiva **referral** → 16. raccogli prenotazioni/ordini → 17. recensioni (QR "Racconta la tua esperienza", mai incentivi) → 18. misura il **ritorno utenti** (coorti) → 19. converti le prove in abbonamento (Daily → piani in scadenza) → 20. misura l’**MRR** → 21. individua i **partner a rischio** (follow-up automatici) → 22. migliora i dati (**Qualità dati**, segnalazioni) → 23. confronta **target vs actual** (Piano e obiettivi) → 24. prepara l’espansione (**Segnali di espansione**).

## Regole che valgono ovunque
- Numeri solo da dati reali; i DEMO sono inclusi solo se "Mostra dati demo" è attivo e sempre dichiarati.
- Target = obiettivi operativi, mai promesse. Nessuna previsione finanziaria senza ipotesi esplicite (Piano → Scenario).
- Nessun invio automatico di messaggi, campagne, comunicati, push massivi o concorsi.
- Segmenti A/B/C = priorità commerciale interna, **non** qualità del ristorante; mai mostrati al pubblico.
- Note sui concorrenti solo se pubbliche o dichiarate dal ristoratore; mai denigrare.
- Contenuti sponsorizzati sempre etichettati (#adv); UGC solo con permesso; giveaway solo dopo la checklist legale.
