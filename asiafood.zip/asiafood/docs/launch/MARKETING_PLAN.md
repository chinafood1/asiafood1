# Marketing plan · Taranto

## 1. Messaggio
**“Finalmente tutta la cucina asiatica di Taranto in un’unica app.”** Temi: Scopri · Confronta · Prenota · Ordina (se attivo) · Risparmia (offerte decise dai locali) · Guadagna punti.

## 2. Landing `/taranto`
Hero “La cucina asiatica di Taranto, tutta in un posto.” — CTA “Scopri i ristoranti” (esperimento `hero_cta` predisposto) e “Trova sushi vicino a te”. Sezioni generate **solo dai dati**: categorie con locali, AYCE, offerte, mappa, comuni con conteggi, ricerche frequenti (solo coppie categoria×città sopra soglia). Sotto 3 locali pubblici la pagina è `noindex` ed esce dalla sitemap. JSON-LD `CollectionPage`.

## 3. Calendario social 30 giorni
`/admin/launch/taranto/marketing` → “Genera 30 giorni (bozze)”: 30 idee su Instagram/Facebook/TikTok (spotlight, piatto del giorno, AYCE, offerte, nuovi partner, sushi quiz, “dove mangeresti?”, mappa, dietro le quinte, giveaway *solo dopo verifica*, contenuti locali, UGC). Stati: idea → bozza → approvato → programmato → pubblicato (**pubblicazione manuale**). Regole bloccanti nel database:
- **Sponsorizzato** senza “#adv/Sponsorizzato” nella didascalia → non approvabile.
- **UGC** senza permesso dell’autore → resta bozza.
- **Giveaway** senza checklist di conformità → resta bozza.

## 4. UGC
Invito: “Tagga @AsiaFood quando provi un ristorante.” Ripubblicare solo con permesso scritto, citando l’autore; niente volti di terzi senza consenso; niente minori.

## 5. Ristorante della settimana
Solo locali consenzienti, dati verificati, niente superlativi non verificabili. Se c’è un corrispettivo: “Sponsorizzato”/#adv.

## 6. Giveaway — checklist (da validare con un consulente)
Qualificazione (DPR 430/2001, manifestazioni a premio o esclusioni) · eventuali adempimenti ministeriali, cauzione, verbalizzazione · regolamento pubblico con dati del promotore · regole delle piattaforme social · informativa privacy dedicata · nessun obbligo di recensione positiva · solo allora “checklist completata”. **Nessun concorso viene lanciato automaticamente.**

## 7. Street marketing e partner locali
Materiali stampabili (A4 con linee di taglio → “Stampa / Salva PDF”):
- **Volantino clienti** A5: “Cerchi sushi, poke o cucina asiatica a Taranto? Scopri AsiaFood.” QR → `/taranto?utm_source=flyer&utm_medium=offline&utm_campaign=taranto_launch[&utm_content=zona]`.
- **Volantino ristoratori** A5: “Porta il tuo ristorante su AsiaFood.” QR → `/per-ristoratori?…utm_campaign=founding_restaurants`.
- **Poster A4 partner** (hotel, B&B, università, palestre, cinema): “Dove mangiare sushi a Taranto?” QR con `utm_content=<partner>`.
- **Sticker**. Kit per ristorante: table card A6, counter card A5, sticker, sticker piccolo (dashboard → Kit QR).
Partner locali nel CRM (tipo “Partner locali”: hotel, B&B, università, palestre, cinema, eventi, attività).

## 8. Campagne geolocalizzate
Zone predisposte come `utm_content`: Taranto centro, Talsano, San Vito, Massafra, Martina Franca, Grottaglie. **Nessuna pubblicità a pagamento viene attivata dalla piattaforma**; eventuali campagne paid si tracciano con `utm_medium=paid_social` (canale “Social a pagamento”).

## 9. Creator e micro-influencer
CRM “Creator” (nome, Instagram, TikTok, comune, follower facoltativi, contatto, stato, note). Format: tasting al ristorante, demo AsiaFood, walkthrough dell’app, “3 sushi da provare”. Ogni collaborazione è un’attività tracciata con obbligo di trasparenza (#adv) di default. Link personale: generatore UTM → preset “Creator”.

## 10. Ambassador
Programma volontario (candidatura dal profilo → Invita un amico, apertura dall’Admin). Nessun compenso automatico: regolamento e compliance prima di qualsiasi premio.

## 11. Referral
- Utenti: “Invita un amico su AsiaFood” — premio in AsiaPoints secondo le regole (Admin → AsiaPoints). Funnel: inviti → iscritti → qualificati → premiati.
- Ristoranti: un partner invita un altro ristorante (Admin → Inviti) con premio configurabile.

## 12. Stampa e PR
CRM “Stampa e media” (giornali locali, blog, radio, TV). Comunicato **bozza** generato con le sole funzioni attive e i numeri reali della landing (Marketing → Template). Press kit pubblico: `/press` (logo, descrizione, contatti; fondatori e screenshot come segnaposto). **Nessun invio automatico.**

## 13. Email e notifiche
- “AsiaFood è arrivata a Taranto”: solo utenti con consenso marketing, segmentati; link con UTM `newsletter/email`.
- Newsletter ristoratori separata (novità, consigli, statistiche).
- **Mai push massivi senza opt-in**: le campagne push esistenti rispettano preferenze e kill switch.

## 14. App
PWA installabile: `/app` e prompt “Aggiungi AsiaFood alla schermata Home” solo su dispositivi compatibili (Chrome/Android nativo, istruzioni su iOS). **Non dichiarare App Store/Google Play** finché non pubblicate.

## 15. Eventi locali (futuro)
AsiaFood Week, Sushi Week Taranto, Asian Food Festival: da pianificare nel CRM (partner → eventi). Nessun evento fisico lanciato dalla piattaforma.

## 16. Promo code di acquisizione
Codici (es. `TARANTO`, `SUSHI`, nome partner) in Crescita → Codici: usati come `?code=…` o su materiali; servono all’**attribuzione** (conteggio usi). Nessuno sconto automatico.
