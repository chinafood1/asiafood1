// POST /api/orders/action — rimborsi (ristorante/Admin), esecuzione rimborsi dopo rifiuto/annullamento, resync pagamento (Admin).
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { orderAction } from '../../server/orders/handlers';
import { netlifyOrdersHandler } from '../../server/orders/runtime';

// Non bloccato in manutenzione: gli ordini già pagati devono poter proseguire (accetta, rimborsa…).
export default withPlatform('orders-action', netlifyOrdersHandler(orderAction), { envGroups: ['core'], rateLimit: { bucket: 'orders_action', limit: 60, windowSeconds: 60 } });
export const config: Config = { path: '/api/orders/action' };
