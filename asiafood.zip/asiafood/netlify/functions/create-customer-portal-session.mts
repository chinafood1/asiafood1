// POST /api/billing/portal — { restaurant_id, flow? } → { url } (Stripe Customer Portal)
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { createCustomerPortalSession } from '../../server/billing/handlers';
import { netlifyHandler } from '../../server/billing/runtime';

export default withPlatform('create-customer-portal-session', netlifyHandler(createCustomerPortalSession), { envGroups: ['core'], rateLimit: { bucket: 'billing_portal', limit: 20, windowSeconds: 600 } });
export const config: Config = { path: '/api/billing/portal' };
