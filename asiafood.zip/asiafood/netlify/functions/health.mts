// GET /api/health — stato di base (app, database, ora del server). Nessun dato sensibile. Per uptime monitor.
import type { Config } from '@netlify/functions';
import { healthHandler } from '../../server/platform/handlers';
import { withPlatform } from '../../server/platform/http';
import { createLogger } from '../../server/platform/logger';
import { platformStore } from '../../server/platform/store';

const store = () => { try { return platformStore(); } catch { return null; } };
export default withPlatform('health', (req) => healthHandler(req, { store: store(), log: createLogger({ fn: 'health' }) }), {
  rateLimit: { bucket: 'health', limit: 120, windowSeconds: 60 },
});
export const config: Config = { path: '/api/health' };
