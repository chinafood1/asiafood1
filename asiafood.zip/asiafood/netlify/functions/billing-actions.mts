// POST /api/billing/actions — anteprima/cambio piano, cancellazione, riattivazione, conferma checkout, fatture
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { billingActions } from '../../server/billing/handlers';
import { netlifyHandler } from '../../server/billing/runtime';

export default withPlatform('billing-actions', netlifyHandler(billingActions), { envGroups: ['core'], mutating: true, rateLimit: { bucket: 'billing_actions', limit: 30, windowSeconds: 600 } });
export const config: Config = { path: '/api/billing/actions' };
