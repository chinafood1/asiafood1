// Funzione pianificata (ogni 15 minuti): promemoria prenotazioni e coupon, richieste di recensione,
// campagne programmate, scadenze punti; poi invio delle notifiche push in coda.
import type { Config } from '@netlify/functions';
import { scheduledJob } from '../../server/platform/cron';
import { engagementCron } from '../../server/engagement/cron';
import { log, productionDeps } from '../../server/engagement/runtime';

export default async () => {
  // Lock condiviso (niente doppia esecuzione) + registro in background_jobs (/admin/system)
  await scheduledJob('engagement-cron', 600, async () => {
    const r = await engagementCron(productionDeps());
    log('info', 'engagement cron done', { push: r.push });
    return r;
  });
};
export const config: Config = { schedule: '*/15 * * * *' };
