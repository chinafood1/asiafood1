// POST /api/logistics/action — ricalcolo ETA con provider di percorsi (Rider assegnato o Admin).
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { logisticsAction } from '../../server/logistics/handlers';
import { netlifyLogisticsHandler } from '../../server/logistics/runtime';

export default withPlatform('logistics-action', netlifyLogisticsHandler(logisticsAction), { envGroups: ['core'], rateLimit: { bucket: 'logistics_action', limit: 120, windowSeconds: 60 } });
export const config: Config = { path: '/api/logistics/action' };
