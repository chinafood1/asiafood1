// POST /api/orders/connect — Stripe Connect Express: stato, onboarding, aggiornamento, accesso alla dashboard Stripe.
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { payoutsConnect } from '../../server/orders/handlers';
import { netlifyOrdersHandler } from '../../server/orders/runtime';

export default withPlatform('orders-connect', netlifyOrdersHandler(payoutsConnect), { envGroups: ['core'], rateLimit: { bucket: 'orders_connect', limit: 20, windowSeconds: 600 } });
export const config: Config = { path: '/api/orders/connect' };
