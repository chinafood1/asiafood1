// Funzione pianificata (ogni minuto): offerte scadute e nuovo dispatch, ricerca Rider per i job in attesa,
// avvisi al dispatch (con tolleranze), retention delle posizioni GPS e anonimizzazione dei dati vecchi.
import type { Config } from '@netlify/functions';
import { scheduledJob } from '../../server/platform/cron';
import { logisticsCron } from '../../server/logistics/handlers';
import { logisticsDeps } from '../../server/logistics/runtime';

export default async () => {
  // Lock condiviso (niente doppia esecuzione) + registro in background_jobs (/admin/system)
  await scheduledJob('logistics-cron', 55, async () => {
    return logisticsCron(logisticsDeps());
  });
};
export const config: Config = { schedule: '* * * * *' };
