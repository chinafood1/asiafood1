// POST /api/billing/checkout — { restaurant_id, plan, billing_interval, promotion_code? } → { url }
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { createCheckoutSession } from '../../server/billing/handlers';
import { netlifyHandler } from '../../server/billing/runtime';

export default withPlatform('create-checkout-session', netlifyHandler(createCheckoutSession), { envGroups: ['core'], mutating: true, rateLimit: { bucket: 'billing_checkout', limit: 20, windowSeconds: 600 } });
export const config: Config = { path: '/api/billing/checkout' };
