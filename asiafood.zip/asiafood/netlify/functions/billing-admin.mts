// POST /api/billing/admin — solo Admin: stato, sincronizza, estendi prova, crea prezzi su Stripe
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { billingAdmin } from '../../server/billing/handlers';
import { netlifyHandler } from '../../server/billing/runtime';

export default withPlatform('billing-admin', netlifyHandler(billingAdmin), { envGroups: ['core'], rateLimit: { bucket: 'billing_admin', limit: 120, windowSeconds: 60 } });
export const config: Config = { path: '/api/billing/admin' };
