// GET /api/ready — dipendenze critiche (env + database). Dettaglio solo con header X-Health-Token.
import type { Config } from '@netlify/functions';
import { readyHandler } from '../../server/platform/handlers';
import { withPlatform } from '../../server/platform/http';
import { createLogger } from '../../server/platform/logger';
import { platformStore } from '../../server/platform/store';

const store = () => { try { return platformStore(); } catch { return null; } };
export default withPlatform('ready', (req) => readyHandler(req, { store: store(), log: createLogger({ fn: 'ready' }) }), {
  rateLimit: { bucket: 'ready', limit: 60, windowSeconds: 60 },
});
export const config: Config = { path: '/api/ready' };
