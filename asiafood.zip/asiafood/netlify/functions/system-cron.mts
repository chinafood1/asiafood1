// Funzione pianificata (ogni 15 minuti): controlli di sistema per la launch checklist (env, health, dominio, sitemap),
// retention dei dati (ogni 6 ore), cancellazioni account scadute (anonimizzazione + eliminazione Auth), job rimessi in coda.
import type { Config } from '@netlify/functions';
import { systemCron } from '../../server/platform/handlers';
import { createLogger, logger } from '../../server/platform/logger';
import { platformStore } from '../../server/platform/store';

export default async () => {
  try {
    const r = await systemCron({ store: platformStore(), log: createLogger({ fn: 'system-cron' }) });
    logger('info', 'system cron', { status: r.status });
  } catch (e) {
    logger('error', 'system cron failed', { error: e });
  }
};
export const config: Config = { schedule: '*/15 * * * *' };
