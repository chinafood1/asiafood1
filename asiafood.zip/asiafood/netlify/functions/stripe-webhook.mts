// POST /api/billing/webhook — endpoint da registrare in Stripe → Developers → Webhooks.
// La firma (Stripe-Signature) è verificata sul corpo grezzo con STRIPE_WEBHOOK_SECRET.
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { stripeWebhook } from '../../server/billing/handlers';
import { netlifyHandler } from '../../server/billing/runtime';

// Mai bloccato da manutenzione o rate limit: Stripe deve poter consegnare gli eventi (firma verificata nell'handler).
export default withPlatform('stripe-webhook', netlifyHandler(stripeWebhook), { envGroups: ['core'] });
export const config: Config = { path: '/api/billing/webhook' };
