// POST /api/ai/chat — assistente AI (chat, cronologia, eliminazione conversazione)
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { aiChat } from '../../server/ai/aiRouter';
import { netlifyHandler } from '../../server/ai/runtime';

export default withPlatform('ai-chat', netlifyHandler(aiChat), { envGroups: ['core'] });
export const config: Config = { path: '/api/ai/chat' };
