// Funzione pianificata (ogni giorno): elimina conversazioni scadute, cache e utilizzo oltre 13 mesi.
import type { Config } from '@netlify/functions';
import { scheduledJob } from '../../server/platform/cron';
import { log, productionDeps } from '../../server/ai/runtime';

export default async () => {
  // Lock condiviso (niente doppia esecuzione) + registro in background_jobs (/admin/system)
  await scheduledJob('ai-cron', 900, async () => {
    const r = await productionDeps().store.rpc<Record<string, number>>('ai_purge', {});
    log('info', 'ai purge', r ?? {});
    return r;
  });
};
export const config: Config = { schedule: '@daily' };
