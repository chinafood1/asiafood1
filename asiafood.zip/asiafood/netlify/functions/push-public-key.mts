// GET /api/push/public-key — chiave pubblica VAPID (pubblica per definizione). La privata resta sul server.
import type { Config } from '@netlify/functions';
import { vapidPublicKey } from '../../server/engagement/runtime';

export default async () =>
  new Response(JSON.stringify({ publicKey: vapidPublicKey() }), {
    status: 200,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=300' },
  });
export const config: Config = { path: '/api/push/public-key' };
