// Funzione pianificata (ogni ora): fine tolleranza pagamenti, fine periodo dei piani cancellati,
// scadenza dei piani manuali, avvisi "la prova sta per terminare".
import type { Config } from '@netlify/functions';
import { scheduledJob } from '../../server/platform/cron';
import { billingCron } from '../../server/billing/handlers';
import { cronDeps } from '../../server/billing/runtime';

export default async () => {
  // Lock condiviso (niente doppia esecuzione) + registro in background_jobs (/admin/system)
  await scheduledJob('billing-cron', 900, async () => {
    return billingCron(cronDeps());
  });
};
export const config: Config = { schedule: '@hourly' };
