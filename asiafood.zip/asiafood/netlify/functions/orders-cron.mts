// Funzione pianificata (ogni 5 minuti): ordini non pagati scaduti, timeout di accettazione con rimborso,
// rimborsi in attesa, carrelli abbandonati (solo statistica).
import type { Config } from '@netlify/functions';
import { scheduledJob } from '../../server/platform/cron';
import { ordersCron } from '../../server/orders/handlers';
import { ordersDeps } from '../../server/orders/runtime';
import { log } from '../../server/billing/runtime';

export default async () => {
  // Lock condiviso (niente doppia esecuzione) + registro in background_jobs (/admin/system)
  await scheduledJob('orders-cron', 240, async () => {
    const r = await ordersCron(ordersDeps());
    log('info', 'orders cron', r as unknown as Record<string, unknown>);
    return r;
  });
};
export const config: Config = { schedule: '*/5 * * * *' };
