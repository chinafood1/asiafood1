// POST /api/orders/create — crea l'ordine "in attesa di pagamento" (prezzi ricalcolati dal database) e il PaymentIntent Stripe.
import type { Config } from '@netlify/functions';
import { withPlatform } from '../../server/platform/http';
import { createOrder } from '../../server/orders/handlers';
import { netlifyOrdersHandler } from '../../server/orders/runtime';

// Manutenzione: nuovi ordini rifiutati (503 MAINTENANCE); rate limit per cliente/IP già nell'handler.
export default withPlatform('orders-create', netlifyOrdersHandler(createOrder), { envGroups: ['core'], mutating: true });
export const config: Config = { path: '/api/orders/create' };
