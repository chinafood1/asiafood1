// POST /api/support — modulo di contatto/supporto per ospiti (Turnstile se configurato, rate limit per IP).
import type { Config } from '@netlify/functions';
import { supportHandler } from '../../server/platform/handlers';
import { withPlatform } from '../../server/platform/http';
import { createLogger } from '../../server/platform/logger';
import { platformStore } from '../../server/platform/store';
import { turnstileFromEnv } from '../../server/platform/turnstile';

export default withPlatform('support', (req) => supportHandler(req, { store: platformStore(), log: createLogger({ fn: 'support' }), turnstile: turnstileFromEnv() }), {
  envGroups: ['core'],
  rateLimit: { bucket: 'support_api', limit: 10, windowSeconds: 3600 },
  mutating: true,
});
export const config: Config = { path: '/api/support' };
