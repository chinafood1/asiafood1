// searchMenuItems: ricerca testuale (ILIKE su nome, descrizione, ingredienti, tag).
// Predisposto per una futura ricerca semantica (embedding) senza cambiare l'interfaccia.
import type { AiMenuItem, MenuQuery } from '../../../shared/ai/types';
import { bool, compact, intIn, numIn, plainText, slugs, str, UUID_RE, type AiStore } from './validate';

export function validateMenuQuery(q: MenuQuery): Record<string, unknown> {
  const hasLoc = numIn(q.lat, -90, 90) !== undefined && numIn(q.lng, -180, 180) !== undefined;
  const terms = Array.isArray(q.terms) ? q.terms.map((t) => plainText(t, 40)).filter((t): t is string => !!t).slice(0, 5) : undefined;
  return compact({
    terms: terms?.length ? terms : undefined,
    match: q.match === 'any' ? 'any' : 'all',
    restaurant_id: typeof q.restaurant_id === 'string' && UUID_RE.test(q.restaurant_id) ? q.restaurant_id : undefined,
    city: str(q.city, /^[a-z0-9-]{2,60}$/),
    categories: slugs(q.categories),
    lat: hasLoc ? q.lat : undefined,
    lng: hasLoc ? q.lng : undefined,
    radius_km: hasLoc ? numIn(q.radius_km, 0.5, 100) : undefined,
    max_price: numIn(q.max_price, 1, 1000),
    vegetarian: bool(q.vegetarian),
    vegan: bool(q.vegan),
    gluten_free: bool(q.gluten_free),
    spicy: bool(q.spicy),
    limit: intIn(q.limit, 1, 20) ?? 6,
  });
}

export const menuSearchTool = (store: AiStore) => ({
  searchMenuItems: async (q: MenuQuery) => (await store.rpc<AiMenuItem[] | null>('ai_search_menu', { p: validateMenuQuery(q) })) ?? [],
});
