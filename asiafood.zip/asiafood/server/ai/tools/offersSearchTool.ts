// searchOffers: offerte e coupon realmente attivi (date, giorni, orari e condizioni dal database).
import type { AiCoupon, AiOffer, OfferQuery } from '../../../shared/ai/types';
import { compact, dateStr, intIn, numIn, slugs, str, UUID_RE, type AiStore } from './validate';

export function validateOfferQuery(q: OfferQuery): Record<string, unknown> {
  const hasLoc = numIn(q.lat, -90, 90) !== undefined && numIn(q.lng, -180, 180) !== undefined;
  return compact({
    date: dateStr(q.date),
    city: str(q.city, /^[a-z0-9-]{2,60}$/),
    categories: slugs(q.categories),
    restaurant_id: typeof q.restaurant_id === 'string' && UUID_RE.test(q.restaurant_id) ? q.restaurant_id : undefined,
    lat: hasLoc ? q.lat : undefined,
    lng: hasLoc ? q.lng : undefined,
    radius_km: hasLoc ? numIn(q.radius_km, 0.5, 100) : undefined,
    limit: intIn(q.limit, 1, 20) ?? 6,
  });
}

export const offersSearchTool = (store: AiStore) => ({
  searchOffers: async (q: OfferQuery) => {
    const r = await store.rpc<{ offers: AiOffer[] | null; coupons: AiCoupon[] | null; date: string }>('ai_search_offers', { p: validateOfferQuery(q) });
    return { offers: r?.offers ?? [], coupons: r?.coupons ?? [], date: r?.date ?? '' };
  },
});
