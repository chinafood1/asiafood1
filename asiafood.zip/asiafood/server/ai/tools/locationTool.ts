// locationTool: valida la posizione del dispositivo e la arrotonda (~100 m).
// La posizione serve solo al calcolo delle distanze della richiesta corrente:
// non viene salvata nella conversazione, nei log o nella cache.
import { numIn } from './validate';

export interface Coords {
  lat: number;
  lng: number;
}

export function normalizeLocation(v: unknown): Coords | null {
  if (!v || typeof v !== 'object') return null;
  const o = v as Record<string, unknown>;
  const lat = numIn(o.lat, -90, 90);
  const lng = numIn(o.lng, -180, 180);
  if (lat === undefined || lng === undefined || (lat === 0 && lng === 0)) return null;
  return { lat: Math.round(lat * 1000) / 1000, lng: Math.round(lng * 1000) / 1000 };
}

/** Distanza in km (per verifiche lato server/test; il database usa la stessa formula). */
export function haversineKm(a: Coords, b: Coords) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
