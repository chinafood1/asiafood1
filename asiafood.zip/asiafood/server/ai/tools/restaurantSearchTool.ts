// searchRestaurants / findNearbyRestaurants / getRestaurantDetails
// Il modello non scrive SQL: sceglie solo filtri, validati qui e passati
// alla funzione controllata public.ai_search_restaurants.
import type { AiCatalog, AiRestaurantDetail, AiRestaurantResult, RestaurantQuery } from '../../../shared/ai/types';
import { bool, compact, dateStr, intIn, numIn, plainText, slugs, str, timeStr, UUID_RE, uuids, type AiStore } from './validate';

export function validateRestaurantQuery(q: RestaurantQuery): Record<string, unknown> {
  const hasLoc = numIn(q.lat, -90, 90) !== undefined && numIn(q.lng, -180, 180) !== undefined;
  return compact({
    text: plainText(q.text),
    city: str(q.city, /^[a-z0-9-]{2,60}$/),
    categories: slugs(q.categories),
    ids: uuids(q.ids),
    lat: hasLoc ? q.lat : undefined,
    lng: hasLoc ? q.lng : undefined,
    radius_km: hasLoc ? numIn(q.radius_km, 0.5, 100) : undefined,
    max_price: numIn(q.max_price, 1, 1000),
    min_price: numIn(q.min_price, 1, 1000),
    meal: q.meal === 'lunch' || q.meal === 'dinner' ? q.meal : undefined,
    ayce: bool(q.ayce),
    delivery: bool(q.delivery),
    takeaway: bool(q.takeaway),
    reservation: bool(q.reservation),
    open_at: str(q.open_at, /^\d{4}-\d{2}-\d{2}T[\d:.]+Z$/, 30),
    window_date: dateStr(q.window_date),
    window_from: timeStr(q.window_from),
    window_to: timeStr(q.window_to),
    open_required: bool(q.open_required),
    vegetarian: bool(q.vegetarian),
    vegan: bool(q.vegan),
    gluten_free: bool(q.gluten_free),
    spicy: bool(q.spicy),
    has_offers: bool(q.has_offers),
    services: Array.isArray(q.services) ? q.services.filter((s) => typeof s === 'string' && /^[a-z_]{2,30}$/.test(s)).slice(0, 8) : undefined,
    sort: q.sort === 'distance' || q.sort === 'price' ? q.sort : 'relevance',
    limit: intIn(q.limit, 1, 20) ?? 5,
  });
}

export const restaurantSearchTool = (store: AiStore) => ({
  catalog: () => store.rpc<AiCatalog>('ai_catalog', {}),
  searchRestaurants: (q: RestaurantQuery) => store.rpc<AiRestaurantResult>('ai_search_restaurants', { p: validateRestaurantQuery(q) }),
  /** Ricerca geolocalizzata: richiede coordinate valide. */
  findNearbyRestaurants: (q: RestaurantQuery & { lat: number; lng: number }) =>
    store.rpc<AiRestaurantResult>('ai_search_restaurants', { p: validateRestaurantQuery({ ...q, sort: q.sort ?? 'distance' }) }),
  getRestaurantDetails: async (ref: string) => {
    const ok = typeof ref === 'string' && (UUID_RE.test(ref) || /^[a-z0-9-]{2,120}$/.test(ref));
    return ok ? store.rpc<AiRestaurantDetail | null>('ai_restaurant_detail', { p_ref: ref }) : null;
  },
});
