// checkReservationAvailability / getRestaurantOpeningStatus
// Solo lettura: l'assistente verifica gli slot reali ma NON prenota mai.
// La prenotazione avviene nel flusso standard, dopo conferma dell'utente.
import type { Availability, OpenStatus } from '../../../shared/ai/types';
import { dateStr, intIn, UUID_RE, type AiStore } from './validate';

export const availabilityTool = (store: AiStore) => ({
  async checkReservationAvailability(restaurantId: string, date: string, partySize: number): Promise<Availability> {
    const d = dateStr(date);
    const n = intIn(partySize, 1, 30);
    if (!UUID_RE.test(restaurantId) || !d || !n) return { ok: false, reason: 'invalid_input', slots: [] };
    const r = await store.rpc<{ ok?: boolean; reason?: string | null; slots?: { time: string; status: string }[] } | null>(
      'get_reservation_availability', { p_restaurant_id: restaurantId, p_date: d, p_party_size: n },
    );
    return { ok: !!r?.ok, reason: r?.reason ?? null, slots: Array.isArray(r?.slots) ? r!.slots : [] };
  },
  async getRestaurantOpeningStatus(restaurantId: string, at?: Date): Promise<OpenStatus> {
    if (!UUID_RE.test(restaurantId)) return 'unknown';
    const s = await store.rpc<string>('restaurant_open_status', { p_restaurant: restaurantId, p_at: (at ?? new Date()).toISOString() });
    return s === 'open' || s === 'closed' ? s : 'unknown';
  },
});
