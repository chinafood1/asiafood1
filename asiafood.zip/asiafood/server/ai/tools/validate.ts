// Validazione degli input degli strumenti: solo chiavi note, tipi e intervalli controllati.
// Qualunque cosa arrivi (parser, modello, client) passa da qui prima del database.
export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const SLUG_RE = /^[a-z0-9-]{2,40}$/;

export const str = (v: unknown, re: RegExp, max = 60) => (typeof v === 'string' && v.length <= max && re.test(v) ? v : undefined);
export const bool = (v: unknown) => (v === true ? true : undefined);
export const numIn = (v: unknown, min: number, max: number) => (typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max ? v : undefined);
export const intIn = (v: unknown, min: number, max: number) => {
  const n = numIn(v, min, max);
  return n !== undefined && Number.isInteger(n) ? n : undefined;
};
export const slugs = (v: unknown, max = 8) => {
  if (!Array.isArray(v)) return undefined;
  const out = v.filter((x): x is string => typeof x === 'string' && SLUG_RE.test(x)).slice(0, max);
  return out.length ? out : undefined;
};
export const uuids = (v: unknown, max = 10) => {
  if (!Array.isArray(v)) return undefined;
  const out = v.filter((x): x is string => typeof x === 'string' && UUID_RE.test(x)).slice(0, max);
  return out.length ? out : undefined;
};
/** Testo libero per ILIKE: niente caratteri speciali (l'escape di % e _ avviene anche in SQL). */
export const plainText = (v: unknown, max = 60) => {
  if (typeof v !== 'string') return undefined;
  const t = v.replace(/[^\p{L}\p{N} '-]/gu, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
  return t.length >= 2 ? t : undefined;
};
export const dateStr = (v: unknown) => str(v, /^\d{4}-\d{2}-\d{2}$/, 10);
export const timeStr = (v: unknown) => str(v, /^([01]\d|2[0-3]):[0-5]\d$/, 5);

/** Rimuove le chiavi undefined (JSON pulito verso le RPC). */
export function compact<T extends Record<string, unknown>>(o: T): Partial<T> {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined)) as Partial<T>;
}

export interface AiStore {
  rpc<T>(fn: string, args: Record<string, unknown>): Promise<T>;
}
