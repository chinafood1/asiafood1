// ─────────────────────────────────────────────────────────────
//  Adapter del modello linguistico (provider intercambiabile).
//  La chiave API arriva SOLO da variabile d'ambiente del server
//  (AI_API_KEY) e non compare mai in log, errori o risposte.
// ─────────────────────────────────────────────────────────────
import type { LlmPort } from '../../shared/ai/types';

export type ProviderName = 'anthropic' | 'openai' | 'gemini' | 'openai_compatible' | 'none';
export const PROVIDERS: ProviderName[] = ['anthropic', 'openai', 'gemini', 'openai_compatible', 'none'];

export interface ProviderConfig {
  provider: ProviderName;
  apiKey: string;
  model: string;
  baseUrl?: string | null;
  timeoutMs?: number;
}

/** Errore del provider senza dettagli sensibili (mai la chiave, mai il corpo completo). */
export class AiProviderError extends Error {
  constructor(public code: 'timeout' | 'http' | 'network' | 'bad_response' | 'not_configured', public status?: number) {
    super(`provider_${code}${status ? `_${status}` : ''}`);
  }
}

type FetchFn = typeof fetch;

const DEFAULT_MODELS: Record<Exclude<ProviderName, 'none'>, string> = {
  anthropic: 'claude-haiku-4-5-20251001',
  openai: 'gpt-4o-mini',
  gemini: 'gemini-2.0-flash',
  openai_compatible: '',
};

export function normalizeProvider(v: unknown): ProviderName | null {
  const s = typeof v === 'string' ? v.trim().toLowerCase() : '';
  return (PROVIDERS as string[]).includes(s) ? (s as ProviderName) : null;
}

/** null = nessun modello configurato: l'assistente funziona in modalità deterministica (template). */
export function createProvider(cfg: ProviderConfig, fetchFn: FetchFn = fetch): LlmPort | null {
  if (cfg.provider === 'none' || !cfg.apiKey) return null;
  const model = cfg.model || DEFAULT_MODELS[cfg.provider];
  if (!model) return null;
  if (cfg.provider === 'openai_compatible' && !cfg.baseUrl) return null;
  const timeoutMs = Math.min(Math.max(cfg.timeoutMs ?? 12_000, 1_000), 30_000);

  const post = async (url: string, headers: Record<string, string>, body: unknown) => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetchFn(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: ctrl.signal });
      if (!res.ok) throw new AiProviderError('http', res.status);
      return (await res.json()) as Record<string, unknown>;
    } catch (e) {
      if (e instanceof AiProviderError) throw e;
      if ((e as { name?: string })?.name === 'AbortError') throw new AiProviderError('timeout');
      throw new AiProviderError('network');
    } finally {
      clearTimeout(timer);
    }
  };

  const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);

  switch (cfg.provider) {
    case 'anthropic':
      return {
        provider: 'anthropic',
        model,
        async complete({ system, messages, maxTokens, temperature }) {
          const j = await post('https://api.anthropic.com/v1/messages', { 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' }, {
            model, system, messages, max_tokens: maxTokens, temperature,
          });
          const content = Array.isArray(j.content) ? (j.content as { type?: string; text?: string }[]) : [];
          const text = content.filter((c) => c.type === 'text').map((c) => c.text ?? '').join('');
          if (!text) throw new AiProviderError('bad_response');
          const u = (j.usage ?? {}) as Record<string, unknown>;
          return { text, usage: { input_tokens: num(u.input_tokens), output_tokens: num(u.output_tokens) } };
        },
      };
    case 'gemini':
      return {
        provider: 'gemini',
        model,
        async complete({ system, messages, maxTokens, temperature }) {
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
          const j = await post(url, { 'x-goog-api-key': cfg.apiKey }, {
            systemInstruction: { parts: [{ text: system }] },
            contents: messages.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
            generationConfig: { maxOutputTokens: maxTokens, temperature, responseMimeType: 'application/json' },
          });
          const cand = (Array.isArray(j.candidates) ? j.candidates[0] : null) as { content?: { parts?: { text?: string }[] } } | null;
          const text = cand?.content?.parts?.map((p) => p.text ?? '').join('') ?? '';
          if (!text) throw new AiProviderError('bad_response');
          const u = (j.usageMetadata ?? {}) as Record<string, unknown>;
          return { text, usage: { input_tokens: num(u.promptTokenCount), output_tokens: num(u.candidatesTokenCount) } };
        },
      };
    case 'openai':
    case 'openai_compatible': {
      const base = (cfg.provider === 'openai' ? 'https://api.openai.com/v1' : cfg.baseUrl!).replace(/\/$/, '');
      return {
        provider: cfg.provider,
        model,
        async complete({ system, messages, maxTokens, temperature }) {
          const j = await post(`${base}/chat/completions`, { authorization: `Bearer ${cfg.apiKey}` }, {
            model,
            messages: [{ role: 'system', content: system }, ...messages],
            max_tokens: maxTokens,
            temperature,
            response_format: { type: 'json_object' },
          });
          const choice = (Array.isArray(j.choices) ? j.choices[0] : null) as { message?: { content?: string } } | null;
          const text = choice?.message?.content ?? '';
          if (!text) throw new AiProviderError('bad_response');
          const u = (j.usage ?? {}) as Record<string, unknown>;
          return { text, usage: { input_tokens: num(u.prompt_tokens), output_tokens: num(u.completion_tokens) } };
        },
      };
    }
  }
}
