// ─────────────────────────────────────────────────────────────
//  Runtime di produzione dell'assistente (Netlify Functions).
//  Variabili d'ambiente SOLO server: AI_PROVIDER, AI_API_KEY, AI_MODEL,
//  AI_MAX_TOKENS, AI_TEMPERATURE (+ AI_BASE_URL, AI_TIMEOUT_MS, AI_RATE_SALT),
//  SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY. Mai nel bundle del frontend.
// ─────────────────────────────────────────────────────────────
import { createClient } from '@supabase/supabase-js';
import type { LlmPort } from '../../shared/ai/types';
import { createProvider, normalizeProvider } from './aiProvider';
import type { AiRouterDeps, AiSettings, HttpRequest, HttpResponse, Logger } from './aiRouter';
import type { AiStore } from './tools/validate';
import { createLogger } from '../platform/logger';

const env = (k: string) => (process.env[k] ?? '').trim();

// Logger centralizzato (livelli, JSON strutturato, redazione di segreti e PII)
export const log: Logger = createLogger({ scope: 'ai' });

let cached: AiRouterDeps | null = null;
const llmCache = new Map<string, LlmPort | null>();

/** Il modello: configurazione Admin (provider/modello) con ripiego sulle variabili d'ambiente. */
export function llmFromEnv(settings: AiSettings): LlmPort | null {
  const provider = normalizeProvider(settings.provider) ?? normalizeProvider(env('AI_PROVIDER')) ?? 'none';
  const model = settings.model || env('AI_MODEL');
  const key = `${provider}|${model}`;
  if (!llmCache.has(key)) {
    llmCache.set(key, createProvider({
      provider, model, apiKey: env('AI_API_KEY'), baseUrl: env('AI_BASE_URL') || null, timeoutMs: Number(env('AI_TIMEOUT_MS')) || 12_000,
    }));
  }
  return llmCache.get(key) ?? null;
}

function envDefaults() {
  const t = Number(env('AI_TEMPERATURE'));
  const m = Number(env('AI_MAX_TOKENS'));
  return {
    temperature: env('AI_TEMPERATURE') !== '' && Number.isFinite(t) ? Math.min(Math.max(t, 0), 1) : undefined,
    maxTokens: Number.isFinite(m) && m > 0 ? Math.min(Math.round(m), 2000) : undefined,
  };
}

export function productionDeps(): AiRouterDeps {
  if (cached) return cached;
  const url = env('SUPABASE_URL') || env('VITE_SUPABASE_URL');
  const serviceKey = env('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !serviceKey) throw new Error('SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY mancanti');
  const sb = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const store: AiStore = {
    async rpc<T>(fn: string, args: Record<string, unknown>) {
      const { data, error } = await sb.rpc(fn, args);
      if (error) {
        log('error', 'rpc failed', { fn, code: error.code });
        throw new Error(`${fn}: ${error.code ?? 'error'}`);
      }
      return data as T;
    },
  };
  cached = {
    store,
    log,
    llmFor: llmFromEnv,
    defaults: envDefaults(),
    salt: env('AI_RATE_SALT') || serviceKey.slice(-16),
    async verifyUser(token) {
      if (!token || token.length > 4096) return null;
      const { data, error } = await sb.auth.getUser(token);
      return error || !data.user ? null : data.user.id;
    },
  };
  return cached;
}

const HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
  'X-Robots-Tag': 'noindex',
};

export function netlifyHandler(handler: (req: HttpRequest, deps: AiRouterDeps) => Promise<HttpResponse>) {
  return async (request: Request): Promise<Response> => {
    let deps: AiRouterDeps;
    try {
      deps = productionDeps();
    } catch (e) {
      log('error', 'ai not configured', { error: String(e).slice(0, 120) });
      return new Response(JSON.stringify({ error: 'NOT_CONFIGURED', message: 'L’assistente non è disponibile in questo momento. Puoi continuare a usare la ricerca.' }), { status: 503, headers: HEADERS });
    }
    const body = request.method === 'GET' ? '' : await request.text();
    const res = await handler({ method: request.method, header: (n) => request.headers.get(n), body }, deps);
    return new Response(JSON.stringify(res.body), { status: res.status, headers: HEADERS });
  };
}
