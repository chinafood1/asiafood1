// Accesso ai dati per l'orchestratore: SOLO strumenti predefiniti e validati.
import type { AiDataPort } from '../../shared/ai/types';
import { availabilityTool } from './tools/availabilityTool';
import { menuSearchTool } from './tools/menuSearchTool';
import { offersSearchTool } from './tools/offersSearchTool';
import { restaurantSearchTool } from './tools/restaurantSearchTool';
import { SLUG_RE, type AiStore } from './tools/validate';

export function createDataPort(store: AiStore): AiDataPort {
  const rs = restaurantSearchTool(store);
  const ms = menuSearchTool(store);
  const os = offersSearchTool(store);
  const av = availabilityTool(store);
  let catalog: Awaited<ReturnType<typeof rs.catalog>> | null = null;
  return {
    catalog: async () => (catalog ??= await rs.catalog()),
    searchRestaurants: rs.searchRestaurants,
    searchMenu: ms.searchMenuItems,
    searchOffers: os.searchOffers,
    restaurantDetail: rs.getRestaurantDetails,
    availability: av.checkReservationAvailability,
    orderable: () => store.rpc<{ restaurant_id: string; takeaway: boolean; delivery: boolean; order_now: boolean; payments_ready: boolean }[]>('orderable_restaurants', {}).then((r) => r ?? []),
    async sponsoredIds(placement, ctx) {
      const rows = await store.rpc<{ campaign_id: string; restaurant_id: string }[] | null>('sponsored_slots', {
        p_placement: placement,
        p_city_slug: ctx.city && SLUG_RE.test(ctx.city) ? ctx.city : null,
        p_category_slug: ctx.category && SLUG_RE.test(ctx.category) ? ctx.category : null,
        p_limit: 2,
      });
      return (rows ?? []).map((r) => ({ campaign_id: r.campaign_id, restaurant_id: r.restaurant_id }));
    },
  };
}
