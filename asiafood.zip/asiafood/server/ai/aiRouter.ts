// ─────────────────────────────────────────────────────────────
//  POST /api/ai/chat — router dell'assistente (indipendente dal runtime).
//  Ordine: metodo → dimensione → configurazione → utente (facoltativo)
//  → sessione → rate limit → cache → orchestratore → sessione → costi.
//  Mai segreti o coordinate nei log; mai stack trace verso il client.
// ─────────────────────────────────────────────────────────────
import { createHash } from 'node:crypto';
import { runAssistant, type SessionFilters } from '../../shared/ai/engine';
import { localParts } from '../../shared/ai/dates';
import { MAX_MESSAGE_LENGTH, normalize, sanitizeUserMessage } from '../../shared/ai/parse';
import type { AiFilters, AiResponse, AiUserContext, LlmPort } from '../../shared/ai/types';
import { createDataPort } from './dataPort';
import { normalizeLocation } from './tools/locationTool';
import { UUID_RE, type AiStore } from './tools/validate';

export interface HttpRequest {
  method: string;
  header(name: string): string | null;
  body: string;
}
export interface HttpResponse {
  status: number;
  body: unknown;
}
export type Logger = (level: 'info' | 'warn' | 'error', message: string, data?: Record<string, unknown>) => void;

export interface AiSettings {
  enabled: boolean;
  provider: string | null;
  model: string | null;
  maxRestaurants: number;
  /** null = usa la variabile d'ambiente (AI_TEMPERATURE / AI_MAX_TOKENS) o il valore predefinito. */
  temperature: number | null;
  maxTokens: number | null;
  cacheTtl: number;
  retentionDays: number;
}

export interface AiRouterDeps {
  store: AiStore;
  verifyUser(token: string): Promise<string | null>;
  /** Crea il modello in base alla configurazione (la chiave è letta dall'ambiente, non passa di qui). */
  llmFor(settings: AiSettings): LlmPort | null;
  /** Valori predefiniti dall'ambiente, usati quando Admin non li imposta. */
  defaults?: { temperature?: number; maxTokens?: number };
  log: Logger;
  now?: () => Date;
  /** Sale per l'hash dell'indirizzo di rete (mai salvato in chiaro). */
  salt: string;
  timeoutMs?: number;
}

export const MAX_BODY_BYTES = 8 * 1024;
export const HARD_MESSAGE_LIMIT = 2000;
const SESSION_RE = /^[A-Za-z0-9_-]{16,64}$/;

export const MESSAGES = {
  disabled: 'L’assistente AI è momentaneamente disattivato. Puoi continuare a usare la ricerca.',
  rateLimited: 'Hai raggiunto il limite di richieste all’assistente per quest’ora. Nel frattempo puoi usare la ricerca e la mappa.',
  error: 'L’assistente non è disponibile in questo momento. Puoi continuare a usare la ricerca.',
  tooLong: `Il messaggio è troppo lungo: scrivi al massimo ${MAX_MESSAGE_LENGTH} caratteri.`,
  empty: 'Scrivi cosa hai voglia di mangiare.',
  forbidden: 'Questa conversazione non è disponibile.',
  unauthorized: 'Sessione scaduta: accedi di nuovo.',
  badRequest: 'Richiesta non valida.',
};

const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');
const json = (status: number, body: unknown): HttpResponse => ({ status, body });

const clampNum = (v: unknown, min: number, max: number, dflt: number) => {
  const n = typeof v === 'number' ? v : typeof v === 'string' ? Number(v) : NaN;
  return Number.isFinite(n) ? Math.min(Math.max(n, min), max) : dflt;
};

export function readSettings(raw: Record<string, unknown> | null): AiSettings {
  const r = raw ?? {};
  const text = (v: unknown) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, 80) : null);
  return {
    enabled: r.ai_enabled !== false && r.ai_enabled !== 'false',
    provider: text(r.ai_provider),
    model: text(r.ai_model),
    maxRestaurants: Math.round(clampNum(r.ai_max_restaurants, 3, 8, 5)),
    temperature: r.ai_temperature == null || r.ai_temperature === 'null' ? null : clampNum(r.ai_temperature, 0, 1, 0.2),
    maxTokens: r.ai_max_tokens == null || r.ai_max_tokens === 'null' ? null : Math.round(clampNum(r.ai_max_tokens, 100, 2000, 600)),
    cacheTtl: Math.round(clampNum(r.ai_cache_ttl_seconds, 0, 3600, 300)),
    retentionDays: Math.round(clampNum(r.ai_chat_retention_days, 0, 90, 7)),
  };
}

function clientIp(req: HttpRequest) {
  const ip = req.header('x-nf-client-connection-ip') ?? req.header('x-forwarded-for')?.split(',')[0] ?? '';
  return ip.trim().slice(0, 64);
}

/** Risposta sicura per il client: niente campi interni. */
/** Fase 13: solo filtri strutturati e già validati (comune, categoria, primo termine di piatto). Mai il messaggio dell'utente. */
function searchFilters(f: AiFilters | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (f?.city && /^[a-z0-9-]{2,60}$/.test(f.city)) out.search_city = f.city;
  const cat = f?.categories?.[0];
  if (cat && /^[a-z0-9-]{2,60}$/.test(cat)) out.search_category = cat;
  const term = f?.dish_terms?.[0];
  if (term && term.length <= 40) out.search_term = term;
  return out;
}

function publicResponse(r: AiResponse): AiResponse {
  return { ...r, meta: { source: r.meta.source, cached: r.meta.cached, fallback_reason: r.meta.fallback_reason ? 'fallback' : null, provider: r.meta.provider } };
}

export async function aiChat(req: HttpRequest, deps: AiRouterDeps): Promise<HttpResponse> {
  const started = Date.now();
  if (req.method !== 'POST') return json(405, { error: 'METHOD_NOT_ALLOWED', message: 'Metodo non consentito.' });
  if (req.body.length > MAX_BODY_BYTES) return json(413, { error: 'TOO_LONG', message: MESSAGES.tooLong });

  let body: Record<string, unknown>;
  try {
    const parsed = JSON.parse(req.body || '{}');
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('shape');
    body = parsed as Record<string, unknown>;
  } catch {
    return json(400, { error: 'BAD_REQUEST', message: MESSAGES.badRequest });
  }

  const action = body.action === 'delete' || body.action === 'history' ? body.action : 'chat';
  const sessionId = typeof body.session_id === 'string' && SESSION_RE.test(body.session_id) ? body.session_id : null;
  if (!sessionId) return json(400, { error: 'BAD_SESSION', message: MESSAGES.badRequest });
  const tokenHash = sha256(`ai-session:${sessionId}`);

  // Utente facoltativo: un token non valido non viene ignorato in silenzio
  const auth = req.header('authorization') ?? '';
  let user: string | null = null;
  if (auth) {
    const m = /^Bearer\s+(.+)$/i.exec(auth);
    user = m ? await deps.verifyUser(m[1]!.trim()).catch(() => null) : null;
    if (!user) return json(401, { error: 'UNAUTHORIZED', message: MESSAGES.unauthorized });
  }

  try {
    if (action === 'delete') {
      const ok = await deps.store.rpc<boolean>('ai_session_delete', { p_token_hash: tokenHash, p_user: user });
      return ok ? json(200, { ok: true }) : json(403, { error: 'FORBIDDEN', message: MESSAGES.forbidden });
    }

    const settings = readSettings(await deps.store.rpc<Record<string, unknown>>('ai_runtime_config', {}));
    const restaurantId = typeof body.restaurant_id === 'string' && UUID_RE.test(body.restaurant_id) ? body.restaurant_id : null;

    if (action === 'history') {
      const s = await deps.store.rpc<{ ok: boolean; error?: string; history?: unknown[] }>('ai_session_open', { p_token_hash: tokenHash, p_user: user, p_restaurant: restaurantId });
      if (!s.ok) return json(403, { error: 'FORBIDDEN', message: MESSAGES.forbidden });
      return json(200, { ok: true, history: s.history ?? [] });
    }

    const rawMessage = typeof body.message === 'string' ? body.message : '';
    if (rawMessage.length > HARD_MESSAGE_LIMIT) return json(413, { error: 'TOO_LONG', message: MESSAGES.tooLong });
    const message = sanitizeUserMessage(rawMessage);
    if (message.length < 2) return json(400, { error: 'EMPTY', message: MESSAGES.empty });

    const ipHash = (() => {
      const ip = clientIp(req);
      return ip ? sha256(`${deps.salt}:${ip}`).slice(0, 32) : null;
    })();
    const requestType = restaurantId ? 'restaurant_chat' : 'chat';
    const logUsage = (p: Record<string, unknown>) =>
      deps.store.rpc('ai_log_usage', {
        p: { user_id: user, session_id: tokenHash.slice(0, 32), ip_hash: ipHash, request_type: requestType, latency_ms: Date.now() - started, ...p },
      }).catch((e) => deps.log('warn', 'ai usage log failed', { error: String(e).slice(0, 120) }));

    if (!settings.enabled) {
      await logUsage({ status: 'disabled' });
      return json(503, { error: 'AI_DISABLED', message: MESSAGES.disabled });
    }

    // Una sessione di un utente registrato non è accessibile da altri
    const session = await deps.store.rpc<{ ok: boolean; error?: string; id?: string; last_filters?: SessionFilters; message_count?: number; history?: { role: 'user' | 'assistant'; content: string }[] }>(
      'ai_session_open', { p_token_hash: tokenHash, p_user: user, p_restaurant: restaurantId },
    );
    if (!session.ok || !session.id) return json(session.error === 'FORBIDDEN' ? 403 : 400, { error: session.error ?? 'BAD_SESSION', message: MESSAGES.forbidden });

    const rate = await deps.store.rpc<{ ok: boolean; limit: number; remaining: number }>('ai_rate_check', { p_user: user, p_session: tokenHash.slice(0, 32), p_ip: ipHash });
    if (!rate.ok) {
      await logUsage({ status: 'rate_limited' });
      return json(429, { error: 'RATE_LIMITED', message: MESSAGES.rateLimited, limit: rate.limit });
    }

    const location = normalizeLocation(body.location);
    const prev = session.last_filters && Object.keys(session.last_filters).length ? session.last_filters : undefined;
    const now = deps.now?.() ?? new Date();

    // Cache: solo richieste generiche (niente posizione, utente, contesto o disponibilità)
    const cacheable = settings.cacheTtl > 0 && !user && !location && !prev && !restaurantId;
    const cacheKey = cacheable ? sha256(`v1|${localParts(now).date}|${normalize(message)}`) : null;
    if (cacheKey) {
      const hit = await deps.store.rpc<{ response: AiResponse; session_filters: SessionFilters } | null>('ai_cache_get', { p_key: cacheKey });
      if (hit?.response) {
        const response = { ...hit.response, meta: { ...hit.response.meta, cached: true } };
        await deps.store.rpc('ai_session_append', {
          p_session: session.id, p_user_msg: message, p_assistant_msg: response.message,
          p_metadata: { intent: response.intent, ids: hit.session_filters.last_ids ?? [], source: 'cache' }, p_filters: hit.session_filters,
        });
        await logUsage({ status: 'cached', intent: response.intent, result_count: response.restaurants.length, no_results: !response.restaurants.length && !response.offers.length && !response.coupons.length && !response.comparison, ...searchFilters(response.filters) });
        return json(200, { ok: true, response: publicResponse(response), remaining: rate.remaining });
      }
    }

    const userCtx: AiUserContext | null = user ? await deps.store.rpc<AiUserContext | null>('ai_user_context', { p_user: user }).catch(() => null) : null;
    const llm = deps.llmFor(settings);
    const run = runAssistant(message, {
      prev_filters: prev,
      history: session.history ?? [],
      restaurant_id: restaurantId,
      location,
      location_denied: body.location_denied === true,
      user: userCtx,
    }, {
      data: createDataPort(deps.store),
      llm,
      now: () => now,
      settings: {
        maxRestaurants: settings.maxRestaurants,
        maxTokens: settings.maxTokens ?? deps.defaults?.maxTokens ?? 600,
        temperature: settings.temperature ?? deps.defaults?.temperature ?? 0.2,
      },
    });
    const timeoutMs = deps.timeoutMs ?? 25_000;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const result = await Promise.race([
      run,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new Error('engine_timeout')), timeoutMs);
      }),
    ]).finally(() => clearTimeout(timer));

    const r = result.response;
    const noResults = !r.restaurants.length && !r.offers.length && !r.coupons.length && !r.comparison && !r.needs_location && r.intent !== 'general_food_question';
    await deps.store.rpc('ai_session_append', {
      p_session: session.id, p_user_msg: message, p_assistant_msg: r.message,
      p_metadata: { intent: r.intent, ids: result.session_filters.last_ids ?? [], source: r.meta.source }, p_filters: result.session_filters,
    });
    await logUsage({
      provider: llm?.provider ?? null, model: llm?.model ?? null,
      input_tokens: result.usage.input_tokens, output_tokens: result.usage.output_tokens,
      intent: r.intent, status: llm && r.meta.fallback_reason ? 'fallback' : 'ok',
      result_count: r.restaurants.length, no_results: noResults,
      // Fase 13: filtri strutturati (mai il testo libero) → domanda di ricerca / supply gap
      ...searchFilters(r.filters),
    });
    if (result.llm_error) deps.log('warn', 'ai provider fallback', { provider: llm?.provider, reason: result.llm_error });

    const r2 = r;
    if (cacheKey && !r2.needs_location && !r2.filters.open_now && !r2.filters.window_from && !r2.filters.date && r2.intent !== 'reservation_search' && !r2.filters.favorites_similar) {
      await deps.store.rpc('ai_cache_put', { p_key: cacheKey, p_payload: { response: r2, session_filters: result.session_filters }, p_ttl: settings.cacheTtl }).catch(() => undefined);
    }
    return json(200, { ok: true, response: publicResponse(r2), remaining: rate.remaining });
  } catch (e) {
    deps.log('error', 'ai chat failed', { error: (e instanceof Error ? e.message : String(e)).slice(0, 160) });
    await deps.store.rpc('ai_log_usage', {
      p: { user_id: user, session_id: tokenHash.slice(0, 32), request_type: 'chat', status: 'error', latency_ms: Date.now() - started },
    }).catch(() => undefined);
    return json(500, { error: 'AI_ERROR', message: MESSAGES.error });
  }
}
