// ─────────────────────────────────────────────────────────────
//  Runtime di produzione (Netlify Functions). Variabili SOLO server:
//  VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, PUSH_SUBJECT (mailto: o https:),
//  SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY.
// ─────────────────────────────────────────────────────────────
import { createClient } from '@supabase/supabase-js';
import webpush from 'web-push';
import type { EngagementDeps } from './cron';
import type { Log, PushSender, PushStore } from './push';
import { createLogger } from '../platform/logger';

const env = (k: string) => (process.env[k] ?? '').trim();

// Logger centralizzato (livelli, JSON strutturato, redazione di segreti e PII)
export const log: Log = createLogger({ scope: 'engagement' });

export function vapidPublicKey() {
  return env('VAPID_PUBLIC_KEY') || null;
}

/** null = push non configurato: le notifiche in-app funzionano comunque. */
export function pushSender(): PushSender | null {
  const pub = env('VAPID_PUBLIC_KEY');
  const priv = env('VAPID_PRIVATE_KEY');
  const subject = env('PUSH_SUBJECT') || (env('APP_URL') ? env('APP_URL') : '');
  if (!pub || !priv || !/^(mailto:|https:)/.test(subject)) return null;
  webpush.setVapidDetails(subject, pub, priv);
  return async (sub, payload) => {
    const r = await webpush.sendNotification(sub, payload, { TTL: 60 * 60 * 12, urgency: 'normal' });
    return { statusCode: r.statusCode };
  };
}

export function productionDeps(): EngagementDeps {
  const url = env('SUPABASE_URL') || env('VITE_SUPABASE_URL');
  const key = env('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) throw new Error('SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY mancanti');
  const sb = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const store: PushStore = {
    async rpc<T>(fn: string, args: Record<string, unknown>) {
      const { data, error } = await sb.rpc(fn, args);
      if (error) {
        log('error', 'rpc failed', { fn, code: error.code });
        throw new Error(`${fn}: ${error.code ?? 'error'}`);
      }
      return data as T;
    },
  };
  return { store, send: pushSender(), log };
}
