// Scheduler della fidelizzazione: promemoria, richieste di recensione, campagne, scadenze → poi invio push.
import { sendPushBatch, type Log, type PushSender, type PushStore } from './push';

export interface EngagementDeps {
  store: PushStore;
  send: PushSender | null;
  log: Log;
}

export async function engagementCron(deps: EngagementDeps, now?: Date) {
  const tick = await deps.store.rpc<Record<string, number>>('engagement_tick', now ? { p_now: now.toISOString() } : {});
  deps.log('info', 'engagement tick', tick ?? {});
  let total = { items: 0, sent: 0, failed: 0, gone: 0 };
  for (let i = 0; i < 5; i++) {
    const r = await sendPushBatch(deps.store, deps.send, deps.log);
    total = { items: total.items + r.items, sent: total.sent + r.sent, failed: total.failed + r.failed, gone: total.gone + r.gone };
    if (r.items === 0) break;
  }
  return { tick, push: total };
}
