// ─────────────────────────────────────────────────────────────
//  Invio Web Push (VAPID). La coda è nel database (push_outbox):
//  qui si preleva un blocco, si invia a ogni dispositivo attivo
//  dell'utente e si riporta l'esito. Endpoint scaduti (404/410)
//  vengono disattivati. Nessun dato personale nel payload oltre
//  al testo della notifica stessa.
// ─────────────────────────────────────────────────────────────
export interface PushSubscriptionRow {
  id: string;
  endpoint: string;
  p256dh: string;
  auth: string;
}
export interface PushItem {
  id: number;
  title: string;
  body: string | null;
  url: string | null;
  tag: string | null;
  subscriptions: PushSubscriptionRow[];
}
export interface PushStore {
  rpc<T>(fn: string, args: Record<string, unknown>): Promise<T>;
}
/** Invio verso un endpoint: restituisce lo status HTTP del push service (201 = accettato). */
export type PushSender = (sub: { endpoint: string; keys: { p256dh: string; auth: string } }, payload: string) => Promise<{ statusCode: number }>;
export type Log = (level: 'info' | 'warn' | 'error', message: string, data?: Record<string, unknown>) => void;

export interface PushResult {
  id: number;
  sent: number;
  failed: number;
  gone: string[];
  no_subscription?: boolean;
  error?: string;
}

export async function sendPushBatch(store: PushStore, send: PushSender | null, log: Log, limit = 100): Promise<{ items: number; sent: number; failed: number; gone: number }> {
  const items = (await store.rpc<PushItem[] | null>('push_claim_batch', { p_limit: limit })) ?? [];
  if (!items.length) return { items: 0, sent: 0, failed: 0, gone: 0 };
  const results: PushResult[] = [];
  for (const it of items) {
    const r: PushResult = { id: it.id, sent: 0, failed: 0, gone: [] };
    if (!send) {
      r.error = 'push_not_configured';
      r.failed = 1;
      results.push(r);
      continue;
    }
    if (!it.subscriptions.length) {
      r.no_subscription = true;
      results.push(r);
      continue;
    }
    const payload = JSON.stringify({ title: it.title, body: it.body ?? '', url: it.url ?? '/', tag: it.tag ?? undefined });
    for (const s of it.subscriptions) {
      try {
        const res = await send({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payload);
        if (res.statusCode >= 200 && res.statusCode < 300) r.sent++;
        else r.failed++;
      } catch (e) {
        const status = (e as { statusCode?: number }).statusCode ?? 0;
        if (status === 404 || status === 410) r.gone.push(s.id);
        else {
          r.failed++;
          r.error = `push_http_${status || 'error'}`;
        }
      }
    }
    if (!r.sent && !r.failed && r.gone.length) r.error = 'subscription_expired';
    results.push(r);
  }
  await store.rpc('push_report', { p: results });
  const agg = results.reduce((a, r) => ({ sent: a.sent + r.sent, failed: a.failed + r.failed, gone: a.gone + r.gone.length }), { sent: 0, failed: 0, gone: 0 });
  // Mai endpoint o chiavi nei log
  log('info', 'push batch', { items: items.length, ...agg });
  return { items: items.length, ...agg };
}
