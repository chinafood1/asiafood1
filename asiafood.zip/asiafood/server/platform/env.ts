// ─────────────────────────────────────────────────────────────
//  Validazione delle variabili d'ambiente del backend (Zod).
//  - fail safely: se manca un secret critico la funzione risponde 503 NOT_CONFIGURED
//  - i report contengono SOLO i nomi delle variabili, mai i valori
// ─────────────────────────────────────────────────────────────
import { z } from 'zod';
import { resolveAppEnv, type AppEnv } from '../../shared/platform/environment';

const raw = (k: string) => (process.env[k] ?? '').trim();

export const appEnv = (): AppEnv => resolveAppEnv(raw('APP_ENV'), raw('CONTEXT'));
export const isProduction = () => appEnv() === 'production';
export const isStaging = () => appEnv() === 'staging';
export const isDevelopment = () => appEnv() === 'development';

const url = z.string().url().refine((v) => /^https?:\/\//.test(v), 'URL http(s)');
const httpsInProd = (v: string) => !isProduction() || v.startsWith('https://');

/** Gruppi di variabili: ogni funzione valida solo quelli che usa. */
export const ENV_GROUPS = {
  core: z.object({
    SUPABASE_URL: url,
    SUPABASE_SERVICE_ROLE_KEY: z.string().min(20),
    APP_URL: url.refine(httpsInProd, 'APP_URL deve essere https in produzione'),
  }),
  stripe: z.object({
    STRIPE_SECRET_KEY: z.string().regex(/^(sk|rk)_(test|live)_[A-Za-z0-9]+$/, 'formato sk_test_/sk_live_'),
    STRIPE_WEBHOOK_SECRET: z.string().regex(/^whsec_[A-Za-z0-9]+$/, 'formato whsec_'),
    STRIPE_MODE: z.enum(['test', 'live']),
  }),
  orders: z.object({
    ORDER_TOKEN_SECRET: z.string().min(32, 'almeno 32 caratteri (openssl rand -hex 32)'),
  }),
  ai: z.object({
    AI_PROVIDER: z.enum(['anthropic', 'openai', 'gemini', 'openai_compatible', 'none', '']).optional(),
    AI_API_KEY: z.string().optional(),
  }),
  push: z.object({
    VAPID_PUBLIC_KEY: z.string().min(40),
    VAPID_PRIVATE_KEY: z.string().min(20),
  }),
  security: z.object({
    TURNSTILE_SECRET_KEY: z.string().min(10).optional(),
    HEALTH_CHECK_TOKEN: z.string().min(16).optional(),
    IP_HASH_SALT: z.string().min(16).optional(),
  }),
  monitoring: z.object({
    SENTRY_DSN: z.string().url().optional(),
  }),
} as const;
export type EnvGroup = keyof typeof ENV_GROUPS;

export interface EnvReport {
  env: AppEnv;
  ok: boolean;
  /** Nomi delle variabili mancanti o non valide (mai i valori). */
  missing: string[];
  invalid: { name: string; reason: string }[];
  warnings: string[];
}

function snapshot(): Record<string, string | undefined> {
  const out: Record<string, string | undefined> = {};
  for (const k of Object.keys(process.env)) out[k] = raw(k) || undefined;
  // Alias storici
  out.SUPABASE_URL ??= raw('VITE_SUPABASE_URL') || undefined;
  out.APP_URL ??= (raw('URL') || raw('VITE_SITE_URL')) || undefined;
  return out;
}

/** Valida i gruppi richiesti + regole di coerenza tra ambiente e chiavi. */
export function validateEnv(groups: EnvGroup[] = ['core']): EnvReport {
  const env = appEnv();
  const src = snapshot();
  const missing: string[] = [];
  const invalid: { name: string; reason: string }[] = [];
  const warnings: string[] = [];
  for (const g of groups) {
    const res = ENV_GROUPS[g].safeParse(src);
    if (res.success) continue;
    for (const issue of res.error.issues) {
      const name = String(issue.path[0] ?? g);
      if (src[name] === undefined) missing.push(name);
      else invalid.push({ name, reason: issue.message });
    }
  }
  // Coerenza ambiente ↔ Stripe: mai chiavi live fuori da production, mai test in production (salvo scelta esplicita)
  const sk = src.STRIPE_SECRET_KEY ?? '';
  if (sk) {
    const live = /^(sk|rk)_live_/.test(sk);
    if (live && env !== 'production') invalid.push({ name: 'STRIPE_SECRET_KEY', reason: `chiave LIVE in ambiente ${env}` });
    if (!live && env === 'production') warnings.push('STRIPE_SECRET_KEY di test in produzione (ok solo per la beta)');
    if (src.STRIPE_MODE && src.STRIPE_MODE !== (live ? 'live' : 'test')) invalid.push({ name: 'STRIPE_MODE', reason: 'non coincide con il tipo di chiave' });
  }
  if (env === 'production' && groups.includes('orders') && !src.ORDER_TOKEN_SECRET) {
    // in produzione il segreto dei link ospite non deve essere derivato dalla service role
    if (!missing.includes('ORDER_TOKEN_SECRET')) missing.push('ORDER_TOKEN_SECRET');
  }
  if (src.AI_PROVIDER && !['none', ''].includes(src.AI_PROVIDER) && !src.AI_API_KEY && src.AI_PROVIDER !== 'openai_compatible') {
    missing.push('AI_API_KEY');
  }
  // Una variabile segreta con prefisso VITE_ finirebbe nel bundle del browser
  for (const k of Object.keys(src)) {
    if (/^VITE_.*(SECRET|SERVICE_ROLE|PRIVATE|WEBHOOK|API_KEY$)/.test(k) && !/^VITE_(GOOGLE_MAPS_API_KEY|MAPBOX_ACCESS_TOKEN)$/.test(k)) {
      invalid.push({ name: k, reason: 'segreto con prefisso VITE_: verrebbe incluso nel frontend' });
    }
  }
  return { env, ok: missing.length === 0 && invalid.length === 0, missing: [...new Set(missing)], invalid, warnings };
}

export class ConfigError extends Error {
  constructor(readonly report: EnvReport) {
    super(`Configurazione incompleta: ${[...report.missing, ...report.invalid.map((i) => i.name)].join(', ')}`);
    this.name = 'ConfigError';
  }
}

/** Lancia ConfigError (solo nomi, mai valori) se i gruppi richiesti non sono validi. */
export function requireEnv(groups: EnvGroup[]): void {
  const r = validateEnv(groups);
  if (!r.ok) throw new ConfigError(r);
}
