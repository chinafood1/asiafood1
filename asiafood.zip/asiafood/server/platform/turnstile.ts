// Verifica Cloudflare Turnstile lato server (TURNSTILE_SECRET_KEY solo nel backend).
export type TurnstileVerifier = (token: string | null | undefined) => Promise<{ ok: boolean; reason?: string }>;

export function turnstileFromEnv(): TurnstileVerifier | null {
  const secret = (process.env.TURNSTILE_SECRET_KEY ?? '').trim();
  if (!secret) return null;
  return async (token) => {
    if (!token || token.length > 2048) return { ok: false, reason: 'missing-token' };
    try {
      const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ secret, response: token }),
        signal: AbortSignal.timeout(5000),
      });
      const j = (await res.json()) as { success?: boolean; 'error-codes'?: string[] };
      return j.success ? { ok: true } : { ok: false, reason: (j['error-codes'] ?? []).join(',') || 'failed' };
    } catch {
      return { ok: false, reason: 'unreachable' };
    }
  };
}
