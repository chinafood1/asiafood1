// ─────────────────────────────────────────────────────────────
//  Endpoint di piattaforma (Fase 11):
//   GET  /api/health  → app attiva, database raggiungibile, ora del server (nessun dato sensibile)
//   GET  /api/ready   → dipendenze critiche; dettaglio solo con X-Health-Token
//   POST /api/support → ticket di supporto per gli ospiti (Turnstile + rate limit)
//   system-cron       → controlli di sistema, retention, cancellazioni account, job in coda
//  Gli handler ricevono le dipendenze (testabili senza rete).
// ─────────────────────────────────────────────────────────────
import { timingSafeEqual } from 'node:crypto';
import { appEnv, validateEnv, type EnvGroup } from './env';
import { runCronJob } from './cron';
import { errorResponse, jsonResponse, clientIpHash } from './http';
import type { LogFn } from './logger';
import type { PlatformStore } from './store';
import type { TurnstileVerifier } from './turnstile';

export interface PlatformDeps {
  store: PlatformStore | null;
  log: LogFn;
  now?: () => Date;
  turnstile?: TurnstileVerifier | null;
  fetchImpl?: typeof fetch;
}

const version = () => (process.env.COMMIT_REF ?? '').slice(0, 12) || 'dev';

async function dbPing(store: PlatformStore | null, timeoutMs = 3000): Promise<{ ok: boolean; ms: number }> {
  const t = Date.now();
  if (!store) return { ok: false, ms: 0 };
  try {
    await Promise.race([store.rpc('system_ping'), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), timeoutMs))]);
    return { ok: true, ms: Date.now() - t };
  } catch {
    return { ok: false, ms: Date.now() - t };
  }
}

/** /api/health — pubblico, nessun segreto, nessuna configurazione rivelata. */
export async function healthHandler(req: Request, deps: PlatformDeps): Promise<Response> {
  const rid = req.headers.get('x-request-id') ?? crypto.randomUUID();
  if (req.method !== 'GET' && req.method !== 'HEAD') return errorResponse(405, 'METHOD_NOT_ALLOWED', undefined, rid);
  const db = await dbPing(deps.store);
  const body = {
    status: db.ok ? 'ok' : 'degraded',
    time: (deps.now?.() ?? new Date()).toISOString(),
    version: version(),
    checks: { app: 'ok', database: db.ok ? 'ok' : 'unreachable', supabase: db.ok ? 'ok' : 'unreachable' },
    latency_ms: { database: db.ms },
  };
  return jsonResponse(db.ok ? 200 : 503, body, rid);
}

function tokenOk(given: string | null): boolean {
  const expected = (process.env.HEALTH_CHECK_TOKEN ?? '').trim();
  if (!expected || !given) return false;
  const a = Buffer.from(given);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

/** Gruppi di variabili richiesti per ambiente. */
export function requiredGroups(env = appEnv()): EnvGroup[] {
  return env === 'production' ? ['core', 'stripe', 'orders'] : ['core'];
}

/** /api/ready — dipendenze critiche. Pubblico: solo "ready". Con X-Health-Token: dettaglio (nomi, mai valori). */
export async function readyHandler(req: Request, deps: PlatformDeps): Promise<Response> {
  const rid = req.headers.get('x-request-id') ?? crypto.randomUUID();
  if (req.method !== 'GET') return errorResponse(405, 'METHOD_NOT_ALLOWED', undefined, rid);
  const env = validateEnv(requiredGroups());
  const db = await dbPing(deps.store);
  const ready = env.ok && db.ok;
  if (!tokenOk(req.headers.get('x-health-token'))) return jsonResponse(ready ? 200 : 503, { ready }, rid);
  return jsonResponse(ready ? 200 : 503, {
    ready,
    env: env.env,
    checks: {
      database: db.ok ? 'ok' : 'unreachable',
      environment: env.ok ? 'ok' : 'incomplete',
      missing: env.missing,
      invalid: env.invalid.map((i) => `${i.name}: ${i.reason}`),
      warnings: env.warnings,
      stripe: process.env.STRIPE_SECRET_KEY ? 'configured' : 'missing',
      ai: process.env.AI_PROVIDER && process.env.AI_PROVIDER !== 'none' ? 'configured' : 'disabled',
      push: process.env.VAPID_PRIVATE_KEY ? 'configured' : 'missing',
      error_tracking: process.env.SENTRY_DSN ? 'sentry' : 'internal',
    },
    version: version(),
  }, rid);
}

const CATEGORIES = new Set(['order', 'reservation', 'account', 'privacy', 'restaurant', 'business', 'billing', 'rider', 'bug', 'other']);

/** /api/support — modulo di contatto per ospiti. Utenti autenticati: RPC diretta support_ticket_create. */
export async function supportHandler(req: Request, deps: PlatformDeps): Promise<Response> {
  const rid = req.headers.get('x-request-id') ?? crypto.randomUUID();
  if (req.method !== 'POST') return errorResponse(405, 'METHOD_NOT_ALLOWED', undefined, rid);
  if (!deps.store) return errorResponse(503, 'NOT_CONFIGURED', undefined, rid);
  let b: Record<string, unknown>;
  try {
    const text = await req.text();
    if (text.length > 12_000) return errorResponse(413, 'BAD_REQUEST', 'Messaggio troppo lungo.', rid);
    b = JSON.parse(text) as Record<string, unknown>;
  } catch {
    return errorResponse(400, 'BAD_REQUEST', undefined, rid);
  }
  const str = (k: string, max: number) => (typeof b[k] === 'string' ? (b[k] as string).trim().slice(0, max) : '');
  const p = {
    category: CATEGORIES.has(str('category', 20)) ? str('category', 20) : 'other',
    subject: str('subject', 140),
    description: str('description', 4000),
    email: str('email', 254),
    name: str('name', 80),
    order_number: str('order_number', 20).toUpperCase(),
    order_token: str('order_token', 200),
    restaurant_id: str('restaurant_id', 36),
  };
  const errors: Record<string, string> = {};
  if (p.subject.length < 3) errors.subject = 'Inserisci un oggetto.';
  if (p.description.length < 10) errors.description = 'Descrivi il problema (almeno 10 caratteri).';
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(p.email)) errors.email = 'Email non valida.';
  if (Object.keys(errors).length) return errorResponse(422, 'BAD_REQUEST', 'Controlla i campi evidenziati.', rid, { fields: errors });
  // Anti-bot: obbligatorio quando Turnstile è configurato (in produzione la checklist ne richiede la configurazione)
  if (deps.turnstile) {
    const v = await deps.turnstile(typeof b.turnstile_token === 'string' ? b.turnstile_token : null);
    if (!v.ok) {
      deps.log('warn', 'turnstile rifiutato', { reason: v.reason });
      return errorResponse(400, 'CAPTCHA_FAILED', undefined, rid);
    }
  }
  try {
    const t = await deps.store.rpc<{ id: string; reference: string }>('support_ticket_create', { p, p_ip_hash: clientIpHash(req) ?? 'unknown' });
    return jsonResponse(201, { ok: true, reference: t.reference }, rid);
  } catch (e) {
    const msg = e instanceof Error ? e.message : '';
    if (/RATE_LIMITED/.test(msg)) return errorResponse(429, 'RATE_LIMITED', undefined, rid);
    if (/Ordine non trovato/.test(msg)) return errorResponse(422, 'BAD_REQUEST', 'Ordine non trovato: controlla numero e link di tracciamento.', rid, { fields: { order_number: 'Ordine non trovato' } });
    deps.log('error', 'support ticket failed', { error: e });
    return errorResponse(500, 'INTERNAL', undefined, rid);
  }
}

/** Controlli di sistema registrati nella launch checklist (solo esiti e nomi, mai valori). */
export async function recordSystemChecks(deps: PlatformDeps): Promise<Record<string, string>> {
  const store = deps.store!;
  const env = appEnv();
  const out: Record<string, string> = {};
  const rec = async (key: string, status: 'pass' | 'fail' | 'warn' | 'pending' | 'na', notes: string) => {
    out[key] = status;
    await store.rpc('system_record_check', { p_key: key, p_status: status, p_notes: notes.slice(0, 900) });
  };
  const core = validateEnv(requiredGroups(env));
  await rec('env_secrets', core.ok ? 'pass' : 'fail', core.ok ? `Variabili obbligatorie presenti (${env})` : `Mancanti/non valide: ${[...core.missing, ...core.invalid.map((i) => i.name)].join(', ')}`);
  const sk = process.env.STRIPE_SECRET_KEY ?? '';
  await rec('env_app_env', env === 'production' ? (core.warnings.length ? 'warn' : 'pass') : 'pending',
    env === 'production' ? (core.warnings.join('; ') || 'APP_ENV=production, chiavi coerenti') : `Ambiente attuale: ${env}`);
  const stripe = validateEnv(['stripe']);
  await rec('env_stripe', stripe.ok ? (sk.includes('_live_') ? 'pass' : env === 'production' ? 'warn' : 'pass') : 'fail',
    stripe.ok ? `Stripe ${sk.includes('_live_') ? 'LIVE' : 'TEST'} configurato` : `Mancanti: ${[...stripe.missing, ...stripe.invalid.map((i) => i.name)].join(', ')}`);
  const ai = process.env.AI_PROVIDER ?? '';
  await rec('env_ai', !ai || ai === 'none' ? 'pass' : process.env.AI_API_KEY || ai === 'openai_compatible' ? 'pass' : 'fail',
    !ai || ai === 'none' ? 'Assistente in modalità dati (senza modello)' : `Provider: ${ai}`);
  await rec('env_push', process.env.VAPID_PRIVATE_KEY && process.env.VAPID_PUBLIC_KEY ? 'pass' : 'warn', process.env.VAPID_PRIVATE_KEY ? 'VAPID configurato' : 'Push disattivate (solo notifiche in-app)');
  await rec('env_error_tracking', 'pass', process.env.SENTRY_DSN ? 'Sentry + log interno' : 'Log errori interno (/admin/system); Sentry facoltativo');
  const appUrl = (process.env.APP_URL || process.env.URL || '').trim();
  const custom = /^https:\/\//.test(appUrl) && !/\.netlify\.app$/.test(new URL(appUrl || 'https://x.netlify.app').hostname);
  await rec('env_domain', custom ? 'pass' : env === 'production' ? 'fail' : 'pending', custom ? `Dominio ${new URL(appUrl).hostname} in HTTPS` : 'Dominio personalizzato HTTPS non configurato');
  // sitemap e robots raggiungibili (solo dominio pubblico configurato)
  if (/^https:\/\//.test(appUrl)) {
    const f = deps.fetchImpl ?? fetch;
    try {
      const [sm, rb] = await Promise.all([
        f(`${appUrl.replace(/\/$/, '')}/sitemap.xml`, { signal: AbortSignal.timeout(5000) }),
        f(`${appUrl.replace(/\/$/, '')}/robots.txt`, { signal: AbortSignal.timeout(5000) }),
      ]);
      const ok = sm.ok && rb.ok && (await sm.text()).includes('<sitemapindex');
      await rec('env_sitemap', ok ? 'pass' : 'fail', ok ? 'sitemap index e robots.txt OK' : `sitemap ${sm.status}, robots ${rb.status}`);
    } catch {
      await rec('env_sitemap', 'fail', 'Dominio non raggiungibile');
    }
  }
  const db = await dbPing(store);
  await rec('mon_health', db.ok ? 'pass' : 'fail', db.ok ? `Database OK (${db.ms} ms)` : 'Database non raggiungibile');
  return out;
}

/** Cron di sistema (ogni 15 minuti). */
export async function systemCron(deps: PlatformDeps, opts: { retentionEveryHours?: number } = {}) {
  const store = deps.store;
  if (!store) throw new Error('store non configurato');
  return runCronJob(store, 'system-cron', 600, async () => {
    const res: Record<string, unknown> = {};
    res.checks = await recordSystemChecks(deps);
    // Retention: al massimo ogni N ore (default 6)
    const every = opts.retentionEveryHours ?? 6;
    // "Cancello" sul contatore condiviso: una sola esecuzione per finestra, anche con più istanze
    const last = await store.rpc<string | null>('rate_limit_check', { p_bucket: 'retention_cleanup_gate', p_key: 'global', p_limit: 1, p_window_seconds: every * 3600 });
    if (last) {
      res.retention = await runCronJob(store, 'retention_cleanup', 900, () => store.rpc('retention_cleanup'));
    }
    // Fase 12: manutenzione di lancio una volta al giorno (obiettivi, follow-up dei partner a rischio,
    // fine beneficio Partner Fondatori, retention CRM). Nessun messaggio inviato ai clienti.
    const launchGate = await store.rpc<string | null>('rate_limit_check', { p_bucket: 'launch_daily_gate', p_key: 'global', p_limit: 1, p_window_seconds: 86400 });
    if (launchGate) {
      res.launch = await runCronJob(store, 'launch_daily_maintenance', 600, () => store.rpc('launch_daily_maintenance'));
    }
    // Fase 13: Business Intelligence. Orario: aggregato di oggi, alert, automazioni dovute (kill switch rispettato).
    // Giornaliero: giorno precedente definitivo, pulizia ricerche grezze, report settimanale. Tutto idempotente.
    const growthHourly = await store.rpc<string | null>('rate_limit_check', { p_bucket: 'growth_hourly_gate', p_key: 'global', p_limit: 1, p_window_seconds: 3300 });
    if (growthHourly) {
      res.growth_hourly = await runCronJob(store, 'growth_hourly', 300, () => store.rpc('growth_hourly'));
    }
    const growthDaily = await store.rpc<string | null>('rate_limit_check', { p_bucket: 'growth_daily_gate', p_key: 'global', p_limit: 1, p_window_seconds: 86400 });
    if (growthDaily) {
      res.growth_daily = await runCronJob(store, 'growth_daily', 900, () => store.rpc('growth_daily'));
    }
    // Cancellazioni account scadute: anonimizzazione nel DB, poi eliminazione dell'utente Auth
    const del = await store.rpc<{ hard_delete: string[]; blocked: number; postponed: number }>('process_account_deletions', { p_limit: 20 });
    let deleted = 0;
    for (const uid of del.hard_delete ?? []) {
      try {
        await store.deleteAuthUser?.(uid);
        await store.rpc('account_deletion_mark_hard_deleted', { p_user: uid });
        deleted++;
      } catch (e) {
        deps.log('error', 'eliminazione utente Auth fallita (riprovata al prossimo giro)', { error: e });
      }
    }
    res.deletions = { hard_deleted: deleted, blocked: del.blocked, postponed: del.postponed };
    // Job rimessi in coda dall'Admin (retry controllato)
    const queued = await store.rpc<{ id: string; job_type: string }[]>('background_jobs_claim', { p_types: '{retention_cleanup,account_deletions}', p_limit: 5 });
    for (const j of queued ?? []) {
      try {
        const r = j.job_type === 'retention_cleanup' ? await store.rpc('retention_cleanup') : { rerun: true };
        await store.rpc('background_job_finish', { p_id: j.id, p_status: 'completed', p_error: null, p_result: r });
      } catch (e) {
        await store.rpc('background_job_finish', { p_id: j.id, p_status: 'failed', p_error: e instanceof Error ? e.message : 'errore', p_result: null });
      }
    }
    res.requeued = (queued ?? []).length;
    return res;
  });
}
