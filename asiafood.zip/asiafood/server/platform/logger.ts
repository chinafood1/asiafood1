// ─────────────────────────────────────────────────────────────
//  Logger centralizzato del backend: JSON strutturato (Netlify → Functions → Logs),
//  livelli debug/info/warn/error (debug spento in produzione), redazione automatica
//  di segreti e dati personali. Tutti i moduli (billing, ordini, AI, push, logistica) lo usano.
// ─────────────────────────────────────────────────────────────
import { appEnv } from './env';

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';
const ORDER: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40 };

const SENSITIVE_KEY = /(authorization|cookie|password|passwd|secret|(^|[_-])token$|^token|api[_-]?key|service[_-]?role|signature|private|p256dh|^auth$|card|cvc|iban|signed[_-]?url|email|phone|address|endpoint)/i;

/** Redazione di stringhe: JWT, chiavi Stripe, bearer, URL firmati, email, telefoni. */
export function redactString(s: string): string {
  return s
    .replace(/eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+/g, '[jwt]')
    .replace(/\b(sk|rk|pk|whsec)_(live|test)?_?[A-Za-z0-9]{8,}/g, '[stripe-key]')
    .replace(/(bearer\s+)[^\s"']+/gi, '$1[redacted]')
    .replace(/([?&](token|t|key|sig|signature|X-Amz-Signature|access_token)=)[^&\s"']+/gi, '$1[redacted]')
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '[email]')
    .replace(/\+?\d[\d .-]{7,}\d/g, '[number]');
}

/** Redazione ricorsiva di oggetti (chiavi sensibili → "[redacted]"), profondità e lunghezze limitate. */
export function redact(value: unknown, depth = 0): unknown {
  if (value == null) return value;
  if (typeof value === 'string') return redactString(value).slice(0, 1000);
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (value instanceof Error) return { name: value.name, message: redactString(value.message).slice(0, 500) };
  if (depth > 4) return '[depth]';
  if (Array.isArray(value)) return value.slice(0, 20).map((v) => redact(v, depth + 1));
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>).slice(0, 40)) {
      out[k] = SENSITIVE_KEY.test(k) ? '[redacted]' : redact(v, depth + 1);
    }
    return out;
  }
  return String(value);
}

const minLevel = (): LogLevel => {
  const l = (process.env.LOG_LEVEL ?? '').toLowerCase() as LogLevel;
  if (l in ORDER) return appEnv() === 'production' && l === 'debug' ? 'info' : l;
  return appEnv() === 'production' ? 'info' : 'debug';
};

export type LogFn = (level: LogLevel, message: string, data?: Record<string, unknown>) => void;

/** Logger con contesto fisso (scope, request_id, …). */
export function createLogger(context: Record<string, unknown> = {}): LogFn {
  return (level, message, data) => {
    if (ORDER[level] < ORDER[minLevel()]) return;
    const line = JSON.stringify({
      level,
      message: redactString(message).slice(0, 300),
      ...(redact(context) as Record<string, unknown>),
      ...((data ? redact(data) : {}) as Record<string, unknown>),
      env: appEnv(),
      at: new Date().toISOString(),
    });
    if (level === 'error') console.error(line);
    else if (level === 'warn') console.warn(line);
    else console.log(line);
  };
}

export const logger = createLogger();

/** ID sicuro per il Payment Intent nei log (prefisso + ultimi 6 caratteri). */
export const safeId = (id: string | null | undefined) => (id ? `${id.slice(0, 3)}…${id.slice(-6)}` : null);
