// Client Supabase con service role per le funzioni di piattaforma (health, supporto, cron di sistema).
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { ConfigError, validateEnv } from './env';

export interface PlatformStore {
  rpc<T>(fn: string, args?: Record<string, unknown>): Promise<T>;
  /** Eliminazione definitiva dell'utente Auth (dopo l'anonimizzazione). */
  deleteAuthUser?(userId: string): Promise<void>;
}

export class RpcError extends Error {
  constructor(readonly fn: string, readonly code: string | undefined, message: string) {
    super(message);
    this.name = 'RpcError';
  }
}

let cached: { sb: SupabaseClient; store: PlatformStore } | null = null;

export function platformStore(): PlatformStore {
  if (cached) return cached.store;
  const r = validateEnv(['core']);
  if (r.missing.includes('SUPABASE_URL') || r.missing.includes('SUPABASE_SERVICE_ROLE_KEY')) throw new ConfigError(r);
  const url = (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').trim();
  const key = (process.env.SUPABASE_SERVICE_ROLE_KEY ?? '').trim();
  const sb = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const store: PlatformStore = {
    async rpc<T>(fn: string, args: Record<string, unknown> = {}) {
      const { data, error } = await sb.rpc(fn, args);
      // Messaggio del database (già in italiano, senza dati sensibili); dettagli tecnici solo nei log
      if (error) throw new RpcError(fn, error.code, error.message);
      return data as T;
    },
    async deleteAuthUser(userId: string) {
      const { error } = await sb.auth.admin.deleteUser(userId);
      if (error) throw new RpcError('auth.admin.deleteUser', error.status ? String(error.status) : undefined, error.message);
    },
  };
  cached = { sb, store };
  return store;
}
