// ─────────────────────────────────────────────────────────────
//  Esecuzione dei job pianificati con lock (niente doppia esecuzione concorrente),
//  registro in background_jobs (stato, tentativi, errore) e cattura errori.
// ─────────────────────────────────────────────────────────────
import { captureServerError } from './errorTracker';
import { createLogger } from './logger';
import type { PlatformStore } from './store';

export interface CronResult {
  status: 'completed' | 'failed' | 'skipped';
  result?: unknown;
  error?: string;
}

export async function runCronJob(store: PlatformStore, name: string, ttlSeconds: number, fn: () => Promise<unknown>): Promise<CronResult> {
  const log = createLogger({ job: name });
  const holder = crypto.randomUUID();
  let locked = false;
  try {
    locked = await store.rpc<boolean>('job_lock_acquire', { p_name: name, p_holder: holder, p_ttl_seconds: ttlSeconds });
  } catch (e) {
    log('warn', 'lock non disponibile: esecuzione senza registro', { error: e });
    // Database non raggiungibile: il job fallirebbe comunque, ma lo si prova (idempotente per costruzione)
    try {
      return { status: 'completed', result: await fn() };
    } catch (err) {
      return { status: 'failed', error: err instanceof Error ? err.message : String(err) };
    }
  }
  if (!locked) {
    log('info', 'già in esecuzione altrove: saltato');
    return { status: 'skipped' };
  }
  let jobId: string | null = null;
  try {
    jobId = await store.rpc<string>('background_job_start', { p_type: name, p_payload: {} });
  } catch { /* registro facoltativo */ }
  try {
    const result = await fn();
    if (jobId) await store.rpc('background_job_finish', { p_id: jobId, p_status: 'completed', p_error: null, p_result: result ?? null }).catch(() => undefined);
    log('info', 'completato', { result: result as Record<string, unknown> });
    return { status: 'completed', result };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (jobId) await store.rpc('background_job_finish', { p_id: jobId, p_status: 'failed', p_error: msg.slice(0, 500), p_result: null }).catch(() => undefined);
    log('error', 'fallito', { error: e });
    await captureServerError(store, { source: 'cron', code: 'CRON_FAILED', message: `${name}: ${msg}` });
    return { status: 'failed', error: msg };
  } finally {
    await store.rpc('job_lock_release', { p_name: name, p_holder: holder }).catch(() => undefined);
  }
}

/** Per le Netlify scheduled functions: lock + registro con lo store di piattaforma (se configurato). */
export async function scheduledJob(name: string, ttlSeconds: number, fn: () => Promise<unknown>): Promise<CronResult> {
  const { platformStore } = await import('./store');
  let store: PlatformStore | null = null;
  try {
    store = platformStore();
  } catch {
    store = null;
  }
  if (!store) {
    const log = createLogger({ job: name });
    try {
      const result = await fn();
      log('info', 'completato (senza registro: Supabase non configurato)');
      return { status: 'completed', result };
    } catch (e) {
      log('error', 'fallito', { error: e });
      return { status: 'failed', error: e instanceof Error ? e.message : String(e) };
    }
  }
  return runCronJob(store, name, ttlSeconds, fn);
}
