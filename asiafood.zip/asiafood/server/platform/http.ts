// ─────────────────────────────────────────────────────────────
//  Strato HTTP comune a tutte le Netlify Functions:
//  - request_id (X-Request-Id) e log strutturato di ogni richiesta (metodo, rotta, stato, durata)
//  - formato errori standard { error: { code, message, requestId } } (mai stack trace)
//  - validazione env (fail safely → 503), rate limit condiviso nel DB, modalità manutenzione
//  - errori 5xx → system_error_log (+ Sentry se configurato)
// ─────────────────────────────────────────────────────────────
import { createHash } from 'node:crypto';
import { validateEnv, type EnvGroup } from './env';
import { captureServerError } from './errorTracker';
import { createLogger } from './logger';
import { platformStore, type PlatformStore } from './store';

export interface ApiErrorBody {
  error: { code: string; message: string; requestId: string };
  [k: string]: unknown;
}

const JSON_HEADERS = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };

export const DEFAULT_MESSAGES: Record<string, string> = {
  INTERNAL: 'Si è verificato un errore. Riprova tra poco.',
  NOT_CONFIGURED: 'Servizio non ancora configurato. Riprova più tardi.',
  RATE_LIMITED: 'Troppe richieste in poco tempo. Riprova tra qualche minuto.',
  MAINTENANCE: 'Stiamo effettuando un aggiornamento. Riprova tra qualche minuto.',
  METHOD_NOT_ALLOWED: 'Metodo non consentito.',
  BAD_REQUEST: 'Richiesta non valida.',
  UNAUTHORIZED: 'Accedi per continuare.',
  FORBIDDEN: 'Non hai i permessi per questa operazione.',
  CAPTCHA_FAILED: 'Verifica anti-bot non riuscita. Riprova.',
};

export function errorResponse(status: number, code: string, message: string | undefined, requestId: string, extra: Record<string, unknown> = {}): Response {
  const body: ApiErrorBody = { ...extra, error: { code, message: message ?? DEFAULT_MESSAGES[code] ?? DEFAULT_MESSAGES.INTERNAL, requestId } };
  return new Response(JSON.stringify(body), { status, headers: { ...JSON_HEADERS, 'X-Request-Id': requestId } });
}

export function jsonResponse(status: number, body: unknown, requestId: string, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), { status, headers: { ...JSON_HEADERS, 'X-Request-Id': requestId, ...headers } });
}

/** Converte le risposte d'errore "storiche" ({ error: 'CODE', message }) nel formato standard. */
export async function normalizeResponse(res: Response, requestId: string): Promise<Response> {
  const headers = new Headers(res.headers);
  headers.set('X-Request-Id', requestId);
  headers.set('X-Content-Type-Options', 'nosniff');
  if (!headers.has('Cache-Control')) headers.set('Cache-Control', 'no-store');
  const ct = headers.get('Content-Type') ?? '';
  if (res.status < 400 || !ct.includes('application/json')) return new Response(res.body, { status: res.status, headers });
  const text = await res.text();
  let body: Record<string, unknown>;
  try {
    body = JSON.parse(text) as Record<string, unknown>;
  } catch {
    return new Response(text, { status: res.status, headers });
  }
  if (body && typeof body.error === 'string') {
    const { error, message, ...rest } = body;
    const out: ApiErrorBody = { ...rest, error: { code: error, message: typeof message === 'string' ? message : DEFAULT_MESSAGES[error] ?? DEFAULT_MESSAGES.INTERNAL, requestId } };
    return new Response(JSON.stringify(out), { status: res.status, headers });
  }
  if (body && typeof body.error === 'object' && body.error !== null) {
    (body.error as Record<string, unknown>).requestId ??= requestId;
  }
  return new Response(JSON.stringify(body), { status: res.status, headers });
}

/** IP del client (Netlify) → hash salato: mai salvato né loggato in chiaro. */
export function clientIpHash(req: Request): string | null {
  const ip = req.headers.get('x-nf-client-connection-ip') ?? req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? null;
  if (!ip) return null;
  const salt = process.env.IP_HASH_SALT || process.env.AI_RATE_SALT || process.env.SUPABASE_SERVICE_ROLE_KEY || 'asiafood';
  return createHash('sha256').update(`${ip}|${salt}`).digest('hex').slice(0, 32);
}

const sanitizeRequestId = (v: string | null) => (v && /^[A-Za-z0-9._-]{8,64}$/.test(v) ? v : null);

let maintenanceCache: { at: number; on: boolean } | null = null;
async function maintenanceOn(store: PlatformStore): Promise<boolean> {
  if (maintenanceCache && Date.now() - maintenanceCache.at < 30_000) return maintenanceCache.on;
  try {
    const cfg = await store.rpc<{ settings?: Record<string, unknown> }>('public_runtime_config');
    maintenanceCache = { at: Date.now(), on: cfg?.settings?.maintenance_mode === true };
  } catch {
    maintenanceCache = { at: Date.now(), on: false }; // DB irraggiungibile: se ne occupa l'handler (niente blocco "cieco")
  }
  return maintenanceCache.on;
}
/** Solo per i test. */
export const __resetMaintenanceCache = () => { maintenanceCache = null; };

export interface PlatformOptions {
  /** Gruppi di variabili d'ambiente obbligatori per questa funzione. */
  envGroups?: EnvGroup[];
  /** Rate limit per hash IP, condiviso tra istanze (tabella rate_limits). */
  rateLimit?: { bucket: string; limit: number; windowSeconds: number };
  /** Endpoint che crea/modifica dati: rifiutato in manutenzione (503). */
  mutating?: boolean;
  /** Store iniettabile (test). */
  store?: () => PlatformStore | null;
}

export type NetlifyHandler = (req: Request, ctx?: unknown) => Promise<Response>;

export function withPlatform(name: string, inner: NetlifyHandler, opts: PlatformOptions = {}): NetlifyHandler {
  return async (req, ctx) => {
    const requestId = sanitizeRequestId(req.headers.get('x-request-id')) ?? crypto.randomUUID();
    const started = Date.now();
    const log = createLogger({ fn: name, request_id: requestId });
    let route = '/';
    try {
      route = new URL(req.url).pathname;
    } catch {
      /* URL relativo nei test */
    }
    const getStore = opts.store ?? (() => { try { return platformStore(); } catch { return null; } });
    const finish = async (res: Response) => {
      const out = await normalizeResponse(res, requestId);
      const ms = Date.now() - started;
      log(out.status >= 500 ? 'error' : out.status >= 400 ? 'warn' : 'info', 'request', { method: req.method, route, status: out.status, ms });
      if (out.status >= 500) {
        let code = 'HTTP_' + out.status;
        try {
          code = ((await out.clone().json()) as ApiErrorBody).error?.code ?? code;
        } catch { /* corpo non JSON */ }
        await captureServerError(getStore(), { source: 'server', code, message: `${name} ${out.status} ${code}`, route, requestId });
      }
      return out;
    };
    try {
      if (opts.envGroups?.length) {
        const r = validateEnv(opts.envGroups);
        if (!r.ok) {
          log('error', 'configurazione incompleta', { missing: r.missing, invalid: r.invalid.map((i) => i.name) });
          return finish(errorResponse(503, 'NOT_CONFIGURED', undefined, requestId));
        }
      }
      const store = getStore();
      if (opts.rateLimit && store) {
        const key = clientIpHash(req) ?? 'unknown';
        try {
          const ok = await store.rpc<boolean>('rate_limit_check', { p_bucket: opts.rateLimit.bucket, p_key: `ip:${key}`, p_limit: opts.rateLimit.limit, p_window_seconds: opts.rateLimit.windowSeconds });
          if (!ok) return finish(errorResponse(429, 'RATE_LIMITED', undefined, requestId));
        } catch (e) {
          log('warn', 'rate limit non disponibile (fail-open)', { error: e });
        }
      }
      if (opts.mutating && req.method !== 'GET' && store && (await maintenanceOn(store))) {
        return finish(errorResponse(503, 'MAINTENANCE', undefined, requestId));
      }
      return await finish(await inner(req, ctx));
    } catch (e) {
      log('error', 'errore non gestito', { error: e });
      return finish(errorResponse(500, 'INTERNAL', undefined, requestId));
    }
  };
}
