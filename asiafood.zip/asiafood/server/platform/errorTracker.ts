// ─────────────────────────────────────────────────────────────
//  Error tracking lato server, configurabile:
//  - sempre: riga in system_error_log (visibile in /admin/system), messaggio ripulito da PII
//  - se SENTRY_DSN è impostato: evento minimale verso Sentry (API "store"), con scrubbing
//  Mai: dati carta, indirizzi completi, telefoni, email, documenti, chiavi AI.
// ─────────────────────────────────────────────────────────────
import { appEnv } from './env';
import { redact, redactString } from './logger';

export interface ErrorStore {
  rpc<T>(fn: string, args: Record<string, unknown>): Promise<T>;
}

interface Captured {
  source: 'server' | 'cron' | 'webhook';
  code: string;
  message: string;
  route?: string;
  requestId?: string;
  extra?: Record<string, unknown>;
}

function parseDsn(dsn: string) {
  const m = /^https:\/\/([^@]+)@([^/]+)\/(\d+)$/.exec(dsn.trim());
  return m ? { key: m[1], host: m[2], project: m[3] } : null;
}

async function sendToSentry(e: Captured) {
  const dsn = parseDsn(process.env.SENTRY_DSN ?? '');
  if (!dsn) return;
  const body = {
    event_id: crypto.randomUUID().replace(/-/g, ''),
    timestamp: Date.now() / 1000,
    platform: 'node',
    level: 'error',
    environment: process.env.SENTRY_ENVIRONMENT || appEnv(),
    release: process.env.COMMIT_REF?.slice(0, 12),
    logger: e.source,
    message: { formatted: redactString(e.message).slice(0, 500) },
    tags: { code: e.code, route: e.route ?? '', request_id: e.requestId ?? '' },
    extra: redact(e.extra ?? {}),
  };
  await fetch(`https://${dsn.host}/api/${dsn.project}/store/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Sentry-Auth': `Sentry sentry_version=7, sentry_key=${dsn.key}, sentry_client=asiafood-server/1.0` },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(2500),
  }).catch(() => undefined);
}

/** Best effort: non lancia mai (un errore nel tracking non deve peggiorare la risposta). */
export async function captureServerError(store: ErrorStore | null, e: Captured): Promise<void> {
  const tasks: Promise<unknown>[] = [sendToSentry(e)];
  if (store) {
    tasks.push(store.rpc('system_log_error', { p: { source: e.source, code: e.code, message: redactString(e.message).slice(0, 400), route: e.route, request_id: e.requestId, environment: appEnv(), release: process.env.COMMIT_REF?.slice(0, 12) } }).catch(() => undefined));
  }
  await Promise.allSettled(tasks);
}
