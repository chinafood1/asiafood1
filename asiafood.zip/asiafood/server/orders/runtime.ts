// ─────────────────────────────────────────────────────────────
//  Runtime di produzione degli ordini (Netlify Functions).
//  Riusa Stripe/Supabase del modulo di fatturazione (stesse chiavi
//  server-side), ma con endpoint e logica separati.
//  Segreti letti SOLO qui: STRIPE_SECRET_KEY, SUPABASE_SERVICE_ROLE_KEY,
//  ORDER_TOKEN_SECRET, MAPBOX_GEOCODING_TOKEN (facoltativo).
// ─────────────────────────────────────────────────────────────
import { createHmac } from 'node:crypto';
import { productionDeps, log } from '../billing/runtime';
import { isProduction } from '../platform/env';
import { BillingError } from '../billing/errors';
import type { HttpRequest } from '../billing/types';
import type { GeocodePoint, OrdersDeps, OrdersHandler } from './types';

const env = (k: string) => (process.env[k] ?? '').trim();

let cached: OrdersDeps | null = null;

async function mapboxGeocode(token: string, query: string): Promise<GeocodePoint | null> {
  const url = `https://api.mapbox.com/search/geocode/v6/forward?q=${encodeURIComponent(query)}&country=it&language=it&limit=1&types=address&access_token=${encodeURIComponent(token)}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(6000) });
  if (!res.ok) return null;
  const data = (await res.json()) as { features?: { geometry: { coordinates: [number, number] }; properties?: { coordinates?: { accuracy?: string } } }[] };
  const f = data.features?.[0];
  // Solo risultati a livello di indirizzo (non la sola città): altrimenti l'area di consegna non è verificabile
  if (!f || !['rooftop', 'parcel', 'point', 'interpolated', 'street'].includes(f.properties?.coordinates?.accuracy ?? 'street')) return null;
  return { lng: f.geometry.coordinates[0], lat: f.geometry.coordinates[1] };
}

export function ordersDeps(): OrdersDeps {
  if (cached) return cached;
  const base = productionDeps();
  const serviceKey = env('SUPABASE_SERVICE_ROLE_KEY');
  // Segreto dedicato; in mancanza, derivato dalla service key (mai esposta) per non bloccare l'avvio
  // In produzione il segreto dei link ospite è obbligatorio (niente derivazione dalla service role: rotazioni indipendenti)
  if (isProduction() && env('ORDER_TOKEN_SECRET').length < 32) throw new BillingError('NOT_CONFIGURED', 'ORDER_TOKEN_SECRET mancante o corto in produzione');
  const tokenSecret = env('ORDER_TOKEN_SECRET') || createHmac('sha256', serviceKey).update('asiafood-order-token').digest('hex');
  const geoToken = env('MAPBOX_GEOCODING_TOKEN');
  cached = {
    stripe: base.stripe,
    store: base.store,
    verifyUser: base.verifyUser,
    log,
    config: { env: base.config.env, appUrl: base.config.appUrl, tokenSecret },
    geocode: geoToken ? (q) => mapboxGeocode(geoToken, q) : undefined,
  };
  return cached;
}

const HEADERS = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };

export function netlifyOrdersHandler(handler: OrdersHandler) {
  return async (request: Request): Promise<Response> => {
    let deps: OrdersDeps;
    try {
      deps = ordersDeps();
    } catch (e) {
      log('error', 'orders not configured', { error: e instanceof BillingError ? e.detail : String(e) });
      return new Response(JSON.stringify({ error: 'NOT_CONFIGURED', message: 'I pagamenti online non sono ancora attivi. Riprova più tardi.' }), { status: 503, headers: HEADERS });
    }
    const req: HttpRequest = {
      method: request.method,
      header: (name) => request.headers.get(name),
      body: request.method === 'GET' ? '' : await request.text(),
    };
    const res = await handler(req, deps);
    return new Response(JSON.stringify(res.body), { status: res.status, headers: HEADERS });
  };
}
