// Errori degli endpoint ordini: codice stabile + messaggio italiano per l'utente. Dettagli SOLO nei log.
export type OrdersErrorCode =
  | 'UNAUTHORIZED'
  | 'FORBIDDEN'
  | 'BAD_REQUEST'
  | 'NOT_FOUND'
  | 'METHOD_NOT_ALLOWED'
  | 'NOT_CONFIGURED'
  | 'RATE_LIMITED'
  | 'ORDER_INVALID'
  | 'ADDRESS_NOT_FOUND'
  | 'STRIPE_UNAVAILABLE'
  | 'PAYMENT_SETUP_FAILED'
  | 'REFUND_FAILED'
  | 'REFUND_WINDOW_CLOSED'
  | 'AMOUNT_INVALID'
  | 'NOT_PAID'
  | 'REASON_REQUIRED'
  | 'CONNECT_FAILED'
  | 'INTERNAL';

const MESSAGES: Record<OrdersErrorCode, [number, string]> = {
  UNAUTHORIZED: [401, 'Accedi per continuare.'],
  FORBIDDEN: [403, 'Non hai i permessi per questa operazione.'],
  BAD_REQUEST: [400, 'Richiesta non valida.'],
  NOT_FOUND: [404, 'Ordine non trovato.'],
  METHOD_NOT_ALLOWED: [405, 'Metodo non consentito.'],
  NOT_CONFIGURED: [503, 'I pagamenti online non sono ancora attivi. Riprova più tardi.'],
  RATE_LIMITED: [429, 'Troppe richieste in poco tempo. Riprova tra qualche minuto.'],
  ORDER_INVALID: [409, 'Il carrello è cambiato: controlla i prodotti e riprova.'],
  ADDRESS_NOT_FOUND: [422, 'Non riusciamo a verificare questo indirizzo: controlla via, numero civico e CAP.'],
  STRIPE_UNAVAILABLE: [503, 'Il servizio di pagamento non risponde. Riprova tra poco: nessun addebito è stato effettuato.'],
  PAYMENT_SETUP_FAILED: [502, 'Non è stato possibile preparare il pagamento. Riprova tra poco.'],
  REFUND_FAILED: [502, 'Il rimborso non è andato a buon fine. Lo staff AsiaFood è stato avvisato.'],
  REFUND_WINDOW_CLOSED: [409, 'Il periodo per rimborsare questo ordine è scaduto: contatta il supporto AsiaFood.'],
  AMOUNT_INVALID: [400, 'Importo non valido: non può superare quanto pagato e non ancora rimborsato.'],
  NOT_PAID: [409, 'L’ordine non risulta pagato.'],
  REASON_REQUIRED: [400, 'Indica il motivo del rimborso.'],
  CONNECT_FAILED: [502, 'Non è stato possibile collegare Stripe. Riprova tra poco.'],
  INTERNAL: [500, 'Si è verificato un errore. Riprova tra poco.'],
};

export class OrdersError extends Error {
  readonly status: number;
  constructor(
    readonly code: OrdersErrorCode,
    readonly detail?: string,
    readonly extra?: Record<string, unknown>,
  ) {
    super(MESSAGES[code][1]);
    this.name = 'OrdersError';
    this.status = MESSAGES[code][0];
  }
}

/** Errori SDK Stripe → codici applicativi (senza esporre dettagli al client). */
export function fromStripe(e: unknown, fallback: OrdersErrorCode): OrdersError {
  if (e instanceof OrdersError) return e;
  const err = e as { type?: string; code?: string; message?: string; statusCode?: number };
  const detail = `${err.type ?? 'Error'}${err.code ? `/${err.code}` : ''}: ${err.message ?? String(e)}`.slice(0, 400);
  if (['StripeConnectionError', 'StripeAPIError', 'StripeRateLimitError'].includes(err.type ?? '') || (err.statusCode ?? 0) >= 500) {
    return new OrdersError('STRIPE_UNAVAILABLE', detail);
  }
  if (err.type === 'StripeAuthenticationError' || err.type === 'StripePermissionError') return new OrdersError('NOT_CONFIGURED', detail);
  return new OrdersError(fallback, detail);
}

export const isConnectionError = (e: unknown) => {
  const t = (e as { type?: string }).type ?? '';
  return ['StripeConnectionError', 'StripeAPIError', 'StripeRateLimitError'].includes(t) || ((e as { statusCode?: number }).statusCode ?? 0) >= 500;
};
