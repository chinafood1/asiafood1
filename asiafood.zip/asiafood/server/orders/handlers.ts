// ─────────────────────────────────────────────────────────────
//  Endpoint ordini (indipendenti dal runtime).
//  Regole: prezzi, sconti, costi di consegna, commissioni e totale
//  li calcola SOLO il database (order_create → order_quote_core);
//  lo stato "pagato" lo scrive SOLO il webhook Stripe; token ospite
//  derivato con HMAC dal server (nel DB solo il suo hash).
// ─────────────────────────────────────────────────────────────
import { createHash, createHmac } from 'node:crypto';
import type Stripe from 'stripe';
import { OrdersError, fromStripe, isConnectionError } from './errors';
import type { CreateResult, HttpRequest, HttpResponse, OrdersDeps, OrdersHandler, PendingRefund } from './types';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const json = (status: number, body: unknown): HttpResponse => ({ status, body });

// ─── Utilità ─────────────────────────────────────────────────
/** Token di accesso ospite: HMAC(segreto, order_id). Ricalcolabile dal server, mai salvato in chiaro. */
export function orderAccessToken(secret: string, orderId: string): string {
  return createHmac('sha256', secret).update(`order:${orderId}`).digest('base64url').slice(0, 32);
}
export const sha256Hex = (s: string) => createHash('sha256').update(s, 'utf8').digest('hex');

function readBody(req: HttpRequest): Record<string, unknown> {
  if (req.body.length > 40_000) throw new OrdersError('BAD_REQUEST', 'body too large');
  try {
    const v = JSON.parse(req.body || '{}') as unknown;
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('not an object');
    return v as Record<string, unknown>;
  } catch {
    throw new OrdersError('BAD_REQUEST', 'invalid json');
  }
}

async function optionalUser(req: HttpRequest, deps: OrdersDeps): Promise<string | null> {
  const token = /^Bearer\s+(.+)$/i.exec(req.header('authorization') ?? '')?.[1] ?? null;
  if (!token) return null;
  const user = await deps.verifyUser(token);
  // Un token presente ma non valido non viene "declassato" a ospite: l'utente deve riaccedere
  if (!user) throw new OrdersError('UNAUTHORIZED');
  return user;
}
async function requireUser(req: HttpRequest, deps: OrdersDeps): Promise<string> {
  const u = await optionalUser(req, deps);
  if (!u) throw new OrdersError('UNAUTHORIZED');
  return u;
}

/** Chiave anonima per i limiti (mai l'IP in chiaro). */
function clientKey(req: HttpRequest, deps: OrdersDeps, user: string | null, session: string | null): string {
  if (user) return `u:${user}`;
  // Ospiti: chiave sull'IP (anonimizzato). La sessione è scelta dal client e non basta a limitare gli abusi.
  const ip = (req.header('x-nf-client-connection-ip') ?? req.header('x-forwarded-for') ?? '').split(',')[0]!.trim();
  void session;
  return `g:${sha256Hex(`${deps.config.tokenSecret}|${ip || 'unknown'}`).slice(0, 40)}`;
}
function ipHash(req: HttpRequest, deps: OrdersDeps): string | null {
  const ip = (req.header('x-nf-client-connection-ip') ?? req.header('x-forwarded-for') ?? '').split(',')[0]!.trim();
  return ip ? sha256Hex(`${deps.config.tokenSecret}|ip|${ip}`).slice(0, 40) : null;
}

async function rateLimit(deps: OrdersDeps, key: string, action: string, max: number, windowSeconds: number) {
  const ok = await deps.store.rpc<boolean>('order_rate_check', { p_key: key, p_action: action, p_max: max, p_window_seconds: windowSeconds });
  if (!ok) throw new OrdersError('RATE_LIMITED');
}

/** Avvolge un handler: metodo, errori → JSON con messaggio per l'utente (mai stack trace). */
export function endpoint(fn: (req: HttpRequest, deps: OrdersDeps) => Promise<unknown>, method = 'POST'): OrdersHandler {
  return async (req, deps) => {
    if (req.method !== method) return json(405, { error: 'METHOD_NOT_ALLOWED', message: 'Metodo non consentito.' });
    try {
      return json(200, await fn(req, deps));
    } catch (e) {
      const err = e instanceof OrdersError ? e : new OrdersError('INTERNAL', e instanceof Error ? e.message : String(e));
      deps.log(err.status >= 500 ? 'error' : 'warn', `orders ${err.code}`, { detail: err.detail });
      return json(err.status, { error: err.code, message: err.message, ...(err.extra ?? {}) });
    }
  };
}

// ═════════════════════════════════════════════════════════════
//  create-order: ordine "in attesa di pagamento" + PaymentIntent
// ═════════════════════════════════════════════════════════════
export const createOrder = endpoint(async (req, deps) => {
  const user = await optionalUser(req, deps);
  const body = readBody(req);
  const session = typeof body.session_id === 'string' && /^[A-Za-z0-9-]{8,64}$/.test(body.session_id) ? body.session_id : null;
  const idem = typeof body.idempotency_key === 'string' && /^[A-Za-z0-9-]{8,80}$/.test(body.idempotency_key) ? body.idempotency_key : null;
  if (typeof body.restaurant_id !== 'string' || !UUID.test(body.restaurant_id)) throw new OrdersError('BAD_REQUEST', 'restaurant_id');
  if (!Array.isArray(body.items) || body.items.length === 0 || body.items.length > 50) throw new OrdersError('BAD_REQUEST', 'items');
  if (!idem) throw new OrdersError('BAD_REQUEST', 'idempotency_key');
  if (!user && !session) throw new OrdersError('BAD_REQUEST', 'session_id');
  await rateLimit(deps, clientKey(req, deps, user, session), 'create', 12, 600);

  // Input per il database: solo i campi attesi (il resto viene ignorato)
  const p: Record<string, unknown> = {
    restaurant_id: body.restaurant_id,
    order_type: body.order_type,
    items: body.items,
    scheduled_for: body.scheduled_for ?? null,
    coupon_code: body.coupon_code ?? null,
    reward_code: body.reward_code ?? null,
    contact: body.contact ?? null,
    notes: body.notes ?? null,
    source: body.source ?? 'web',
    address: body.address ?? null,
  };

  // Geocoding lato server (se configurato): coordinate autorevoli per l'area di consegna
  if (body.order_type === 'delivery' && deps.geocode && body.address && typeof body.address === 'object') {
    const a = body.address as Record<string, unknown>;
    if (a.geocode_source !== 'device') {
      const q = [a.address_line_1, a.postal_code, a.city, 'Italia'].filter((x) => typeof x === 'string' && x.trim()).join(', ');
      const pt = q.length >= 8 ? await deps.geocode(q).catch(() => null) : null;
      if (!pt) throw new OrdersError('ADDRESS_NOT_FOUND');
      p.address = { ...a, latitude: pt.lat, longitude: pt.lng, geocode_source: 'geocoder' };
    }
  }

  // L'hash del token si calcola dopo aver conosciuto l'ID: order_create riceve un hash provvisorio e lo sostituisce
  const provisional = sha256Hex(`${deps.config.tokenSecret}|${idem}`);
  const res = await deps.store.rpc<CreateResult>('order_create', {
    p, p_user: user, p_session: session, p_idem: idem, p_token_hash: provisional, p_ip_hash: ipHash(req, deps),
  });
  if (!res.ok || !res.order_id) {
    throw new OrdersError('ORDER_INVALID', JSON.stringify(res.errors ?? []).slice(0, 300), { errors: res.errors ?? [] });
  }
  const token = orderAccessToken(deps.config.tokenSecret, res.order_id);
  await deps.store.rpc('order_set_token', { p_order: res.order_id, p_token_hash: sha256Hex(token) });

  const out = { ok: true, order_id: res.order_id, order_number: res.order_number, access_token: token, total: res.total, payment_mode: res.payment_mode };
  // Ordine già pagato (doppio click dopo il pagamento): nessun nuovo PaymentIntent
  if (res.existing && res.payment_status && ['paid', 'refunded', 'partially_refunded'].includes(res.payment_status)) {
    return { ...out, client_secret: null, already_paid: true };
  }

  const pi = await ensurePaymentIntent(deps, res);
  return { ...out, client_secret: pi.client_secret, payment_intent_id: pi.id };
});

async function ensurePaymentIntent(deps: OrdersDeps, o: CreateResult): Promise<Stripe.PaymentIntent> {
  const { stripe, config } = deps;
  try {
    if (o.payment_intent_id) {
      const existing = await stripe.paymentIntents.retrieve(o.payment_intent_id);
      if (existing.status !== 'canceled') return existing;
    }
    const amount = o.total_cents!;
    const params: Stripe.PaymentIntentCreateParams = {
      amount,
      currency: (o.currency ?? 'EUR').toLowerCase(),
      automatic_payment_methods: { enabled: true },
      description: `AsiaFood ordine ${o.order_number}${o.restaurant_name ? ` — ${o.restaurant_name}` : ''}`,
      // Metadati minimi, nessun dato personale
      metadata: { source: 'asiafood_order', order_id: o.order_id!, order_number: o.order_number!, restaurant_id: o.restaurant_id!, environment: config.env },
      receipt_email: o.customer_email,
    };
    if (o.payment_mode === 'connect' && o.destination) {
      // Destination charge: il ristorante riceve il netto, AsiaFood trattiene commissione + costo di servizio
      params.transfer_data = { destination: o.destination };
      params.application_fee_amount = Math.min(o.application_fee_cents ?? 0, amount);
    } else if (o.payment_mode !== 'platform_test') {
      throw new OrdersError('NOT_CONFIGURED', `payment mode ${o.payment_mode}`);
    } else if (config.env !== 'test') {
      // Incasso sulla piattaforma senza Connect: consentito SOLO in ambiente di test
      throw new OrdersError('NOT_CONFIGURED', 'platform collection outside test mode');
    }
    const pi = await stripe.paymentIntents.create(params, { idempotencyKey: `asiafood-order-pi-${o.order_id}-${amount}` });
    await deps.store.rpc('order_attach_payment', { p_order: o.order_id, p_payment_intent: pi.id, p_env: config.env });
    deps.log('info', 'order payment intent', { order: o.order_number, mode: o.payment_mode, amount });
    return pi;
  } catch (e) {
    throw fromStripe(e, 'PAYMENT_SETUP_FAILED');
  }
}

// ═════════════════════════════════════════════════════════════
//  Rimborsi (eseguiti SOLO qui, mai dal browser)
// ═════════════════════════════════════════════════════════════
export async function processPendingRefunds(deps: OrdersDeps, orderId: string | null): Promise<{ processed: number; failed: number }> {
  const list = await deps.store.rpc<PendingRefund[]>('order_refunds_claim', { p_order: orderId, p_limit: 20 });
  let processed = 0;
  let failed = 0;
  for (const r of list) {
    if (!r.payment_intent_id) {
      await deps.store.rpc('order_refund_result', { p_refund: r.refund_id, p_stripe_refund: null, p_status: 'failed', p_error: 'Nessun pagamento Stripe collegato' });
      failed++;
      continue;
    }
    try {
      const refund = await deps.stripe.refunds.create(
        {
          payment_intent: r.payment_intent_id,
          amount: r.amount_cents,
          reason: 'requested_by_customer',
          metadata: { source: 'asiafood_order', order_id: r.order_id, refund_id: r.refund_id },
          // Destination charge: si stornano trasferimento al ristorante e commissione (proporzionale)
          ...(r.payment_mode === 'connect' ? { reverse_transfer: true, refund_application_fee: true } : {}),
        },
        { idempotencyKey: `asiafood-refund-${r.refund_id}` },
      );
      await deps.store.rpc('order_refund_result', { p_refund: r.refund_id, p_stripe_refund: refund.id, p_status: refund.status ?? 'pending', p_error: null });
      processed++;
    } catch (e) {
      if (isConnectionError(e)) {
        // Stripe non raggiungibile: resta "in elaborazione", lo scheduler ritenterà
        deps.log('warn', 'refund deferred', { refund: r.refund_id, error: String((e as Error).message) });
        continue;
      }
      await deps.store.rpc('order_refund_result', { p_refund: r.refund_id, p_stripe_refund: null, p_status: 'failed', p_error: String((e as Error).message).slice(0, 300) });
      deps.log('error', 'refund failed', { refund: r.refund_id, order: r.order_number });
      failed++;
    }
  }
  return { processed, failed };
}

interface PaymentInfo { ok: boolean; order_id: string; restaurant_id: string; status: string; payment_status: string; payment_intent_id: string | null; user_id: string | null }

/** Annulla su Stripe il PaymentIntent di un ordine annullato e non pagato (best effort). */
async function cancelIntentIfUnpaid(deps: OrdersDeps, info: PaymentInfo) {
  if (!info.payment_intent_id || info.status !== 'cancelled' || ['paid', 'refunded', 'partially_refunded'].includes(info.payment_status)) return;
  try {
    const pi = await deps.stripe.paymentIntents.retrieve(info.payment_intent_id);
    if (['requires_payment_method', 'requires_confirmation', 'requires_action', 'requires_capture'].includes(pi.status)) {
      await deps.stripe.paymentIntents.cancel(info.payment_intent_id, { cancellation_reason: 'abandoned' });
    }
  } catch (e) {
    deps.log('warn', 'payment intent cancel failed', { error: String((e as Error).message) });
  }
}

/** Legge da Stripe (fonte autorevole) lo stato di pagamento e rimborsi di un ordine. */
export async function syncOrderPayment(deps: OrdersDeps, paymentIntentId: string) {
  const pi = await deps.stripe.paymentIntents.retrieve(paymentIntentId);
  const map: Record<string, string> = { succeeded: 'succeeded', canceled: 'canceled', processing: 'processing', requires_payment_method: 'failed' };
  let result: unknown = { status: 'unchanged' };
  const type = pi.status === 'requires_payment_method' && !pi.last_payment_error ? null : map[pi.status];
  if (type) {
    result = await deps.store.rpc('order_payment_event', {
      p: {
        type, payment_intent: pi.id, order_id: pi.metadata?.order_id ?? null, amount: pi.amount_received || pi.amount, currency: pi.currency,
        charge: typeof pi.latest_charge === 'string' ? pi.latest_charge : pi.latest_charge?.id ?? null,
        error_code: pi.last_payment_error?.code ?? pi.last_payment_error?.decline_code ?? null, source: 'resync',
      },
    });
  }
  const refunds = await deps.stripe.refunds.list({ payment_intent: pi.id, limit: 50 });
  if (refunds.data.length) {
    await deps.store.rpc('order_refund_sync', {
      p_payment_intent: pi.id,
      p_refunds: refunds.data.map((r) => ({ id: r.id, amount: r.amount, status: r.status, failure_reason: r.failure_reason ?? null })),
    });
  }
  return { payment_intent_status: pi.status, result, refunds: refunds.data.length };
}

// ═════════════════════════════════════════════════════════════
//  Azioni: rimborso, esecuzione rimborsi in attesa, resync (Admin)
// ═════════════════════════════════════════════════════════════
export const orderAction = endpoint(async (req, deps) => {
  const body = readBody(req);
  const action = typeof body.action === 'string' ? body.action : '';
  const orderId = typeof body.order_id === 'string' && UUID.test(body.order_id) ? body.order_id : null;
  if (!orderId) throw new OrdersError('BAD_REQUEST', 'order_id');

  if (action === 'after_change') {
    // Dopo rifiuto/annullamento (fatti via RPC con i permessi dell'utente): esegue i rimborsi già validati
    // e annulla il pagamento non completato. Non concede nulla di nuovo: agisce solo su richieste già registrate.
    const user = await optionalUser(req, deps);
    await rateLimit(deps, clientKey(req, deps, user, null), 'after_change', 30, 600);
    const info = await deps.store.rpc<PaymentInfo>('order_payment_info', { p_order: orderId });
    if (!info?.ok) throw new OrdersError('NOT_FOUND');
    await cancelIntentIfUnpaid(deps, info);
    return processPendingRefunds(deps, orderId);
  }

  if (action === 'resume_payment') {
    // Riprendere un pagamento non completato: proprietario autenticato oppure token ospite (HMAC)
    const user = await optionalUser(req, deps);
    await rateLimit(deps, clientKey(req, deps, user, null), 'resume', 30, 600);
    const info = await deps.store.rpc<PaymentInfo>('order_payment_info', { p_order: orderId });
    const token = typeof body.access_token === 'string' ? body.access_token : '';
    const allowed = info?.ok && ((user && info.user_id === user) || (token.length >= 16 && token === orderAccessToken(deps.config.tokenSecret, orderId)));
    if (!allowed) throw new OrdersError('NOT_FOUND');
    if (info.status !== 'pending_payment' || !info.payment_intent_id) return { client_secret: null, status: info.status };
    try {
      const pi = await deps.stripe.paymentIntents.retrieve(info.payment_intent_id);
      return { client_secret: ['requires_payment_method', 'requires_confirmation', 'requires_action'].includes(pi.status) ? pi.client_secret : null, status: pi.status };
    } catch (e) {
      throw fromStripe(e, 'PAYMENT_SETUP_FAILED');
    }
  }

  const user = await requireUser(req, deps);
  if (action === 'refund') {
    await rateLimit(deps, `u:${user}`, 'refund', 20, 3600);
    const amount = Number(body.amount);
    const reason = typeof body.reason === 'string' ? body.reason.slice(0, 300) : '';
    if (!Number.isFinite(amount) || amount <= 0) throw new OrdersError('AMOUNT_INVALID');
    const r = await deps.store.rpc<{ ok: boolean; error?: string; refund_id?: string }>('order_refund_request', {
      p_actor: user, p_order: orderId, p_amount: Math.round(amount * 100) / 100, p_reason: reason,
    });
    if (!r.ok) {
      const code = r.error === 'FORBIDDEN' ? 'FORBIDDEN' : r.error === 'NOT_FOUND' ? 'NOT_FOUND' : r.error === 'REFUND_WINDOW_CLOSED' ? 'REFUND_WINDOW_CLOSED'
        : r.error === 'NOT_PAID' ? 'NOT_PAID' : r.error === 'REASON_REQUIRED' ? 'REASON_REQUIRED' : 'AMOUNT_INVALID';
      throw new OrdersError(code, r.error);
    }
    const res = await processPendingRefunds(deps, orderId);
    if (res.failed > 0) throw new OrdersError('REFUND_FAILED');
    return { ok: true, refund_id: r.refund_id, ...res };
  }

  if (action === 'resync') {
    const admin = await deps.store.rpc<boolean>('is_admin_user', { p_user: user });
    if (!admin) throw new OrdersError('FORBIDDEN');
    const info = await deps.store.rpc<PaymentInfo>('order_payment_info', { p_order: orderId });
    if (!info?.ok) throw new OrdersError('NOT_FOUND');
    if (!info.payment_intent_id) return { ok: true, note: 'Nessun pagamento Stripe collegato a questo ordine.' };
    try {
      const r = await syncOrderPayment(deps, info.payment_intent_id);
      const pending = await processPendingRefunds(deps, orderId);
      return { ok: true, ...r, refunds_processed: pending.processed };
    } catch (e) {
      throw fromStripe(e, 'INTERNAL');
    }
  }
  throw new OrdersError('BAD_REQUEST', `action ${action}`);
});

// ═════════════════════════════════════════════════════════════
//  Stripe Connect Express: onboarding e stato (dati bancari SOLO su Stripe)
// ═════════════════════════════════════════════════════════════
interface PayoutContext {
  ok: boolean;
  error?: string;
  restaurant: { id: string; name: string; website: string | null };
  email: string | null;
  account: { stripe_account_id: string; charges_enabled: boolean; details_submitted: boolean } | null;
}

function accountPayload(a: Stripe.Account) {
  return {
    stripe_account_id: a.id,
    charges_enabled: !!a.charges_enabled,
    payouts_enabled: !!a.payouts_enabled,
    details_submitted: !!a.details_submitted,
    requirements_due: (a.requirements?.currently_due ?? []).slice(0, 20),
  };
}

export const payoutsConnect = endpoint(async (req, deps) => {
  const user = await requireUser(req, deps);
  const body = readBody(req);
  const restaurantId = typeof body.restaurant_id === 'string' && UUID.test(body.restaurant_id) ? body.restaurant_id : null;
  const action = typeof body.action === 'string' ? body.action : 'status';
  if (!restaurantId) throw new OrdersError('BAD_REQUEST', 'restaurant_id');
  await rateLimit(deps, `u:${user}`, 'connect', 30, 600);
  const ctx = await deps.store.rpc<PayoutContext>('payout_context', { p_user: user, p_restaurant: restaurantId, p_env: deps.config.env });
  if (!ctx.ok) throw new OrdersError(ctx.error === 'FORBIDDEN' ? 'FORBIDDEN' : 'NOT_FOUND', ctx.error);
  const base = `${deps.config.appUrl}/dashboard/restaurants/${restaurantId}/payouts`;
  try {
    if (action === 'status') return { environment: deps.config.env, account: ctx.account };
    if (action === 'onboard') {
      let accountId = ctx.account?.stripe_account_id ?? null;
      if (!accountId) {
        const acct = await deps.stripe.accounts.create(
          {
            type: 'express',
            country: 'IT',
            email: ctx.email ?? undefined,
            business_type: 'company',
            business_profile: { name: ctx.restaurant.name, mcc: '5812', url: ctx.restaurant.website ?? undefined },
            capabilities: { card_payments: { requested: true }, transfers: { requested: true } },
            metadata: { restaurant_id: restaurantId, source: 'asiafood_connect' },
          },
          { idempotencyKey: `asiafood-connect-${restaurantId}-${deps.config.env}` },
        );
        accountId = acct.id;
        await deps.store.rpc('payout_account_upsert', { p_restaurant: restaurantId, p_env: deps.config.env, p: accountPayload(acct) });
      }
      const link = await deps.stripe.accountLinks.create({ account: accountId, type: 'account_onboarding', refresh_url: `${base}?refresh=1`, return_url: `${base}?return=1` });
      return { url: link.url };
    }
    if (!ctx.account) throw new OrdersError('NOT_FOUND', 'no account');
    if (action === 'refresh') {
      const acct = await deps.stripe.accounts.retrieve(ctx.account.stripe_account_id);
      const saved = await deps.store.rpc('payout_account_upsert', { p_restaurant: restaurantId, p_env: deps.config.env, p: accountPayload(acct) });
      return { environment: deps.config.env, account: saved };
    }
    if (action === 'dashboard') {
      const l = await deps.stripe.accounts.createLoginLink(ctx.account.stripe_account_id);
      return { url: l.url };
    }
  } catch (e) {
    throw fromStripe(e, 'CONNECT_FAILED');
  }
  throw new OrdersError('BAD_REQUEST', `action ${action}`);
});

// ═════════════════════════════════════════════════════════════
//  Webhook: eventi di pagamento degli ordini (chiamato dal webhook unico)
// ═════════════════════════════════════════════════════════════
export const ORDER_EVENT_TYPES = new Set([
  'payment_intent.succeeded', 'payment_intent.payment_failed', 'payment_intent.canceled', 'payment_intent.processing',
  'charge.refunded', 'charge.refund.updated', 'refund.updated', 'refund.created', 'refund.failed',
  'charge.dispute.created', 'account.updated',
]);

type OrderEventDeps = Pick<OrdersDeps, 'stripe' | 'store' | 'log'> & { config: Pick<OrdersDeps['config'], 'env'> };

export async function processOrderEvent(deps: OrderEventDeps, event: Stripe.Event): Promise<{ status: 'processed' | 'ignored'; restaurantId?: string | null; note?: string }> {
  const type = event.type as string;
  if (type.startsWith('payment_intent.')) {
    const pi = event.data.object as Stripe.PaymentIntent;
    if (pi.metadata?.source !== 'asiafood_order' && !pi.metadata?.order_id) return { status: 'ignored', note: 'not an order payment' };
    const kind = type === 'payment_intent.succeeded' ? 'succeeded' : type === 'payment_intent.payment_failed' ? 'failed'
      : type === 'payment_intent.canceled' ? 'canceled' : 'processing';
    const r = await deps.store.rpc<{ ok: boolean; status: string; order_id?: string }>('order_payment_event', {
      p: {
        type: kind, payment_intent: pi.id, order_id: pi.metadata?.order_id ?? null,
        amount: kind === 'succeeded' ? pi.amount_received || pi.amount : pi.amount, currency: pi.currency,
        charge: typeof pi.latest_charge === 'string' ? pi.latest_charge : pi.latest_charge?.id ?? null,
        error_code: pi.last_payment_error?.decline_code ?? pi.last_payment_error?.code ?? null, source: 'webhook',
      },
    });
    if (r.status === 'refund_needed' && r.order_id) await processPendingRefunds(deps as OrdersDeps, r.order_id);
    return { status: r.ok ? 'processed' : 'ignored', restaurantId: pi.metadata?.restaurant_id ?? null, note: r.status };
  }
  if (type.startsWith('charge.refund') || type === 'charge.refunded' || type.startsWith('refund.')) {
    const obj = event.data.object as Stripe.Charge | Stripe.Refund;
    const piRef = (obj as { payment_intent?: string | Stripe.PaymentIntent | null }).payment_intent;
    const piId = typeof piRef === 'string' ? piRef : piRef?.id;
    if (!piId) return { status: 'ignored', note: 'no payment intent' };
    // Stato dei rimborsi letto da Stripe (fonte autorevole), non dal payload
    const refunds = await deps.stripe.refunds.list({ payment_intent: piId, limit: 50 });
    const r = await deps.store.rpc<{ ok: boolean }>('order_refund_sync', {
      p_payment_intent: piId,
      p_refunds: refunds.data.map((x) => ({ id: x.id, amount: x.amount, status: x.status, failure_reason: x.failure_reason ?? null })),
    });
    return { status: r.ok ? 'processed' : 'ignored', note: r.ok ? undefined : 'not an order' };
  }
  if (type === 'charge.dispute.created') {
    const d = event.data.object as Stripe.Dispute;
    const piId = typeof d.payment_intent === 'string' ? d.payment_intent : d.payment_intent?.id;
    if (!piId) return { status: 'ignored' };
    const r = await deps.store.rpc<{ ok: boolean }>('order_payment_event', { p: { type: 'dispute', payment_intent: piId, reason: d.reason } });
    return { status: r.ok ? 'processed' : 'ignored' };
  }
  if (type === 'account.updated') {
    const a = event.data.object as Stripe.Account;
    const r = await deps.store.rpc<{ ok?: boolean; error?: string }>('payout_account_sync', { p: accountPayload(a) });
    return { status: r && r.error ? 'ignored' : 'processed' };
  }
  return { status: 'ignored', note: 'event not handled' };
}

// ═════════════════════════════════════════════════════════════
//  Scheduler: scadenze, timeout di accettazione, rimborsi in attesa
// ═════════════════════════════════════════════════════════════
export async function ordersCron(deps: OrdersDeps) {
  const tick = await deps.store.rpc<{ expired: number; accept_timeouts: number; reminders: number; abandoned_carts: number; cancel_payment_intents: string[] }>(
    'orders_tick', { p_now: new Date(deps.now?.() ?? Date.now()).toISOString() },
  );
  let cancelled = 0;
  for (const pi of tick.cancel_payment_intents ?? []) {
    try {
      const x = await deps.stripe.paymentIntents.retrieve(pi);
      if (['requires_payment_method', 'requires_confirmation', 'requires_action', 'requires_capture'].includes(x.status)) {
        await deps.stripe.paymentIntents.cancel(pi, { cancellation_reason: 'abandoned' });
        cancelled++;
      }
    } catch (e) {
      deps.log('warn', 'cron: payment intent cancel failed', { error: String((e as Error).message) });
    }
  }
  const refunds = await processPendingRefunds(deps, null);
  const { cancel_payment_intents: _pis, ...rest } = tick;
  return { ...rest, payment_intents_cancelled: cancelled, refunds_processed: refunds.processed, refunds_failed: refunds.failed };
}
