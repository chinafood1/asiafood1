// ─────────────────────────────────────────────────────────────
//  Fase 8 · Ordini B2C (takeaway/delivery). Modulo SEPARATO dalla
//  fatturazione B2B (server/billing): condivide solo il webhook
//  Stripe (un endpoint) e la tabella stripe_events (idempotenza).
// ─────────────────────────────────────────────────────────────
import type Stripe from 'stripe';
import type { HttpRequest, HttpResponse, Logger, StripeEnvironment, Store } from '../billing/types';

export type { HttpRequest, HttpResponse, Logger, Store };

export interface OrdersConfig {
  env: StripeEnvironment;
  /** URL pubblico del sito (APP_URL). */
  appUrl: string;
  /** Segreto per derivare i token di accesso ospite: HMAC(segreto, order_id). Mai esposto. */
  tokenSecret: string;
}

export interface GeocodePoint {
  lat: number;
  lng: number;
}

export interface OrdersDeps {
  stripe: Stripe;
  store: Store;
  config: OrdersConfig;
  /** JWT Supabase → ID utente (null se assente/non valido). */
  verifyUser: (token: string | null) => Promise<string | null>;
  log: Logger;
  /** Geocoding lato server (facoltativo): se presente è autorevole per le consegne. */
  geocode?: (query: string) => Promise<GeocodePoint | null>;
  now?: () => number;
}

export type OrdersHandler = (req: HttpRequest, deps: OrdersDeps) => Promise<HttpResponse>;

export interface CreateResult {
  ok: boolean;
  existing?: boolean;
  errors?: { code: string; message: string; field?: string; index?: number }[];
  order_id?: string;
  order_number?: string;
  status?: string;
  payment_status?: string;
  total?: number;
  total_cents?: number;
  currency?: string;
  payment_mode?: 'connect' | 'platform_test';
  destination?: string | null;
  application_fee_cents?: number;
  payment_intent_id?: string | null;
  customer_email?: string;
  restaurant_id?: string;
  restaurant_name?: string;
}

export interface PendingRefund {
  refund_id: string;
  order_id: string;
  amount_cents: number;
  payment_intent_id: string | null;
  payment_mode: 'connect' | 'platform_test' | 'demo';
  full: boolean;
  order_number: string;
}
