import type Stripe from 'stripe';
import type { StripeEnvironment } from './types';

// Conversioni Stripe → payload per le RPC del database. Solo dati "safe":
// della carta si tengono marca, ultime 4 cifre e scadenza, mai il numero.

const iso = (ts: number | null | undefined) => (ts ? new Date(ts * 1000).toISOString() : null);
const idOf = (x: string | { id: string } | null | undefined) => (typeof x === 'string' ? x : x?.id ?? null);

export const envOf = (livemode: boolean): StripeEnvironment => (livemode ? 'live' : 'test');

const STATUSES = new Set(['trialing', 'active', 'past_due', 'unpaid', 'canceled', 'incomplete', 'incomplete_expired', 'paused']);

type LegacyPeriod = { current_period_start?: number; current_period_end?: number };

/** Il primo item della subscription (AsiaFood usa sempre un solo prezzo per abbonamento). */
export function primaryItem(sub: Stripe.Subscription): Stripe.SubscriptionItem | null {
  return sub.items?.data?.[0] ?? null;
}

function paymentMethodInfo(pm: Stripe.PaymentMethod | null | undefined) {
  const card = pm?.card;
  if (!card) return {};
  return { pm_brand: card.brand ?? null, pm_last4: card.last4 ?? null, pm_exp_month: card.exp_month ?? null, pm_exp_year: card.exp_year ?? null };
}

export function subscriptionPayload(
  sub: Stripe.Subscription,
  opts: { restaurantId?: string | null; fallbackPaymentMethod?: Stripe.PaymentMethod | null } = {},
) {
  const item = primaryItem(sub);
  const price = item?.price;
  // Dal 2025 il periodo corrente è sugli item; le versioni API precedenti lo avevano sulla subscription
  const legacy = sub as unknown as LegacyPeriod;
  const periodStart = (item as unknown as LegacyPeriod | null)?.current_period_start ?? legacy.current_period_start;
  const periodEnd = (item as unknown as LegacyPeriod | null)?.current_period_end ?? legacy.current_period_end;
  const pm = typeof sub.default_payment_method === 'object' ? sub.default_payment_method : null;
  const latest = sub.latest_invoice;
  // Cancellazione programmata a fine periodo (anche tramite cancel_at impostato dal Customer Portal)
  const cancelAtEnd = !!sub.cancel_at_period_end || (!!sub.cancel_at && !!periodEnd && sub.cancel_at <= periodEnd + 60 && sub.status !== 'canceled');
  const meta = sub.metadata ?? {};
  return {
    stripe_subscription_id: sub.id,
    restaurant_id: meta.restaurant_id || opts.restaurantId || null,
    plan_code: meta.plan_code || null,
    user_id: meta.user_id || null,
    billing_account_id: meta.billing_account_id || null,
    customer_id: idOf(sub.customer as string | { id: string }),
    status: STATUSES.has(sub.status) ? sub.status : 'incomplete',
    price_id: price?.id ?? null,
    interval: price?.recurring?.interval === 'year' ? 'year' : 'month',
    unit_amount: price?.unit_amount != null ? price.unit_amount * (item?.quantity ?? 1) : null,
    currency: (price?.currency ?? 'eur').toUpperCase(),
    trial_start: iso(sub.trial_start),
    trial_end: iso(sub.trial_end),
    current_period_start: iso(periodStart),
    current_period_end: iso(periodEnd),
    cancel_at_period_end: cancelAtEnd,
    canceled_at: iso(sub.canceled_at),
    ended_at: iso(sub.ended_at),
    latest_invoice_id: idOf(latest as string | { id: string } | null),
    latest_invoice_status: typeof latest === 'object' && latest ? latest.status : null,
    schedule_id: idOf(sub.schedule as string | { id: string } | null),
    environment: envOf(sub.livemode),
    ...paymentMethodInfo(pm ?? opts.fallbackPaymentMethod ?? null),
  };
}

/** ID della subscription collegata a una fattura (API nuova: parent.subscription_details; vecchia: subscription). */
export function invoiceSubscriptionId(inv: Stripe.Invoice): string | null {
  const fromParent = inv.parent?.subscription_details?.subscription;
  const legacy = (inv as unknown as { subscription?: string | { id: string } | null }).subscription;
  return idOf((fromParent ?? legacy ?? null) as string | { id: string } | null);
}

export function invoicePayload(inv: Stripe.Invoice) {
  return {
    id: inv.id,
    subscription_id: invoiceSubscriptionId(inv),
    restaurant_id: inv.parent?.subscription_details?.metadata?.restaurant_id ?? null,
    customer_id: idOf(inv.customer as string | { id: string } | null),
    number: inv.number,
    status: inv.status ?? 'open',
    amount_due: inv.amount_due,
    amount_paid: inv.amount_paid,
    currency: (inv.currency ?? 'eur').toUpperCase(),
    hosted_invoice_url: inv.hosted_invoice_url ?? null,
    invoice_pdf: inv.invoice_pdf ?? null,
    period_start: iso(inv.period_start),
    period_end: iso(inv.period_end),
    created: iso(inv.created),
    environment: envOf(inv.livemode),
  };
}

/** Somma delle righe di proration (anteprima di un upgrade). */
export function prorationAmount(preview: Stripe.Invoice): number {
  const lines = preview.lines?.data ?? [];
  let sum = 0;
  let found = false;
  for (const l of lines) {
    const parent = (l as unknown as { parent?: { subscription_item_details?: { proration?: boolean } } }).parent;
    const legacy = (l as unknown as { proration?: boolean }).proration;
    if (parent?.subscription_item_details?.proration || legacy) {
      sum += l.amount;
      found = true;
    }
  }
  return found ? sum : preview.amount_due;
}
