import type Stripe from 'stripe';
import { BillingError, fromStripeError } from './errors';
import { subscriptionPayload } from './mapping';
import type { BillingDeps, CheckoutContext, HttpRequest } from './types';

// ─── Validazione input ────────────────────────────────────────
export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function readJson(req: HttpRequest): Record<string, unknown> {
  if (req.body.length > 10_000) throw new BillingError('BAD_REQUEST', 'body too large');
  try {
    const v = JSON.parse(req.body || '{}') as unknown;
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('not an object');
    return v as Record<string, unknown>;
  } catch {
    throw new BillingError('BAD_REQUEST', 'invalid json');
  }
}

export function uuidField(body: Record<string, unknown>, key: string): string {
  const v = body[key];
  if (typeof v !== 'string' || !UUID_RE.test(v)) throw new BillingError('BAD_REQUEST', `${key} non valido`);
  return v.toLowerCase();
}

export function textField(body: Record<string, unknown>, key: string, re: RegExp, optional = false): string | null {
  const v = body[key];
  if ((v === undefined || v === null || v === '') && optional) return null;
  if (typeof v !== 'string' || !re.test(v)) throw new BillingError('BAD_REQUEST', `${key} non valido`);
  return v;
}

export const intervalField = (body: Record<string, unknown>) =>
  textField(body, 'billing_interval', /^(month|year)$/) as 'month' | 'year';

export const planField = (body: Record<string, unknown>) => textField(body, 'plan', /^[a-z0-9_-]{2,40}$/i)!;

/** Utente autenticato dal JWT Supabase (header Authorization: Bearer …). */
export async function requireUser(req: HttpRequest, deps: BillingDeps): Promise<string> {
  const h = req.header('authorization') ?? '';
  const token = /^Bearer\s+(.+)$/i.exec(h)?.[1] ?? null;
  const user = token ? await deps.verifyUser(token) : null;
  if (!user) throw new BillingError('UNAUTHORIZED');
  return user;
}

export async function rateLimit(deps: BillingDeps, user: string, action: string, max: number, windowSeconds: number) {
  const ok = await deps.store.rpc<boolean>('billing_rate_check', { p_user: user, p_action: action, p_max: max, p_window_seconds: windowSeconds });
  if (!ok) throw new BillingError('RATE_LIMITED');
}

/** Codici di errore restituiti dalle RPC di contesto → errori applicativi. */
export function contextError(code: string | undefined): BillingError {
  switch (code) {
    case 'FORBIDDEN':
    case 'RESTAURANT_NOT_FOUND':
    case 'INVALID_PLAN':
    case 'INVALID_INTERVAL':
    case 'PRICE_NOT_CONFIGURED':
    case 'ALREADY_SUBSCRIBED':
    case 'PROMO_INVALID':
    case 'SUBSCRIPTION_NOT_FOUND':
    case 'SAME_PLAN':
      return new BillingError(code);
    default:
      return new BillingError('INTERNAL', `context error ${code}`);
  }
}

// ─── Cliente Stripe ───────────────────────────────────────────
function customerDetails(acc: CheckoutContext['account']): Stripe.CustomerUpdateParams {
  const address =
    acc.address_line || acc.city || acc.postal_code
      ? { line1: acc.address_line ?? undefined, postal_code: acc.postal_code ?? undefined, city: acc.city ?? undefined, state: acc.province ?? undefined, country: acc.country || 'IT' }
      : undefined;
  return {
    email: acc.email ?? undefined,
    name: acc.business_name ?? undefined,
    address,
    preferred_locales: ['it'],
    metadata: {
      billing_account_id: acc.id,
      // Dati utili alla futura fatturazione elettronica (SdI non implementato in questa fase)
      vat_number: acc.vat_number ?? '',
      tax_code: acc.tax_code ?? '',
      pec: acc.pec ?? '',
      recipient_code: acc.recipient_code ?? '',
    },
  };
}

/**
 * Restituisce il cliente Stripe dell'account di fatturazione, creandolo se manca
 * (o se è stato eliminato dalla dashboard Stripe). La chiave di idempotenza evita
 * clienti duplicati in caso di doppio click o ritentativi.
 */
export async function ensureCustomer(deps: BillingDeps, acc: CheckoutContext['account'], userId: string): Promise<string> {
  const { stripe, store, config } = deps;
  if (acc.stripe_customer_id) {
    try {
      const c = await stripe.customers.retrieve(acc.stripe_customer_id);
      if (!(c as Stripe.DeletedCustomer).deleted) {
        await stripe.customers.update(acc.stripe_customer_id, customerDetails(acc)).catch((e: unknown) =>
          deps.log('warn', 'customer update failed', { error: String(e) }),
        );
        return acc.stripe_customer_id;
      }
      deps.log('warn', 'stripe customer deleted: recreating', { account: acc.id });
    } catch (e) {
      const code = (e as { code?: string }).code;
      if (code !== 'resource_missing') throw fromStripeError(e, 'CHECKOUT_FAILED');
      deps.log('warn', 'stripe customer missing: recreating', { account: acc.id });
    }
  }
  try {
    const created = await stripe.customers.create(
      { ...(customerDetails(acc) as Stripe.CustomerCreateParams), metadata: { ...customerDetails(acc).metadata, user_id: userId } },
      { idempotencyKey: `asiafood-customer-${acc.id}-${config.env}-${acc.stripe_customer_id ?? 'new'}` },
    );
    await store.rpc('billing_set_customer', { p_account: acc.id, p_customer: created.id, p_env: config.env });
    return created.id;
  } catch (e) {
    throw fromStripeError(e, 'CHECKOUT_FAILED');
  }
}

/** Coupon Stripe corrispondente a una promozione B2B interna (creato una volta per ambiente). */
export async function ensurePromotionCoupon(deps: BillingDeps, promo: NonNullable<CheckoutContext['promotion']>): Promise<string | null> {
  if (promo.discount_type === 'free_days') return null;
  if (promo.stripe_coupon_id) return promo.stripe_coupon_id;
  const params: Stripe.CouponCreateParams = {
    name: promo.code,
    duration: promo.duration,
    metadata: { promotion_id: promo.id, source: 'asiafood_billing_promotions' },
  };
  if (promo.duration === 'repeating') params.duration_in_months = promo.duration_in_months ?? 1;
  if (promo.discount_type === 'percent') params.percent_off = Number(promo.discount_value);
  else {
    params.amount_off = Math.round(Number(promo.discount_value) * 100);
    params.currency = 'eur';
  }
  try {
    const c = await deps.stripe.coupons.create(params, { idempotencyKey: `asiafood-coupon-${promo.id}-${deps.config.env}` });
    await deps.store.rpc('billing_set_promotion_coupon', { p_promotion: promo.id, p_env: deps.config.env, p_coupon: c.id });
    return c.id;
  } catch (e) {
    throw fromStripeError(e, 'CHECKOUT_FAILED');
  }
}

// ─── Sincronizzazione Stripe → database ───────────────────────
export interface SyncResult {
  ok: boolean;
  error?: string;
  id?: string;
  restaurant_id?: string;
  plan_code?: string;
  status?: string;
  effective_plan?: string;
  created?: boolean;
}

/**
 * Legge SEMPRE lo stato attuale da Stripe (mai dal payload del browser o
 * dell'evento, che può arrivare fuori ordine) e lo scrive nel database.
 */
export async function syncSubscription(deps: BillingDeps, subscriptionId: string, hint: { restaurantId?: string | null } = {}): Promise<SyncResult> {
  const { stripe, store } = deps;
  let sub: Stripe.Subscription;
  try {
    sub = await stripe.subscriptions.retrieve(subscriptionId, { expand: ['default_payment_method', 'latest_invoice'] });
  } catch (e) {
    if ((e as { code?: string }).code === 'resource_missing') throw new BillingError('SUBSCRIPTION_NOT_FOUND', subscriptionId);
    throw fromStripeError(e, 'INTERNAL');
  }
  // Metodo di pagamento predefinito del cliente se la subscription non ne ha uno proprio
  let fallbackPm: Stripe.PaymentMethod | null = null;
  if (!sub.default_payment_method && typeof sub.customer === 'string') {
    try {
      const c = await stripe.customers.retrieve(sub.customer, { expand: ['invoice_settings.default_payment_method'] });
      const pm = (c as Stripe.Customer).invoice_settings?.default_payment_method;
      if (pm && typeof pm === 'object') fallbackPm = pm;
    } catch (e) {
      deps.log('warn', 'customer pm lookup failed', { error: String(e) });
    }
  }
  const payload = subscriptionPayload(sub, { restaurantId: hint.restaurantId, fallbackPaymentMethod: fallbackPm });
  const res = await store.rpc<SyncResult>('billing_upsert_subscription', { p: payload });
  if (!res.ok) return res;

  // Cambio programmato (downgrade a fine periodo), anche se creato dal Customer Portal
  const scheduleId = payload.schedule_id;
  if (scheduleId) {
    try {
      const sched = await stripe.subscriptionSchedules.retrieve(scheduleId);
      const periodEnd = payload.current_period_end ? Date.parse(payload.current_period_end) / 1000 : 0;
      const next = (sched.phases ?? []).find((ph) => ph.start_date >= periodEnd - 60 && ph.start_date > (deps.now?.() ?? Date.now()) / 1000);
      const nextPrice = next?.items?.[0]?.price;
      const priceId = typeof nextPrice === 'string' ? nextPrice : nextPrice?.id ?? null;
      await store.rpc('billing_set_scheduled_change', {
        p_stripe_sub: sub.id,
        p_schedule: scheduleId,
        p_price: priceId && priceId !== payload.price_id ? priceId : null,
        p_at: next ? new Date(next.start_date * 1000).toISOString() : null,
      });
    } catch (e) {
      deps.log('warn', 'schedule sync failed', { schedule: scheduleId, error: String(e) });
    }
  }
  return res;
}
