// ─────────────────────────────────────────────────────────────
//  Errori di fatturazione: codice stabile per il frontend,
//  messaggio in italiano per l'utente, dettagli SOLO nei log.
// ─────────────────────────────────────────────────────────────

export type BillingErrorCode =
  | 'UNAUTHORIZED'
  | 'FORBIDDEN'
  | 'BAD_REQUEST'
  | 'METHOD_NOT_ALLOWED'
  | 'NOT_CONFIGURED'
  | 'RESTAURANT_NOT_FOUND'
  | 'INVALID_PLAN'
  | 'INVALID_INTERVAL'
  | 'PRICE_NOT_CONFIGURED'
  | 'ALREADY_SUBSCRIBED'
  | 'PROMO_INVALID'
  | 'SUBSCRIPTION_NOT_FOUND'
  | 'SAME_PLAN'
  | 'NO_CUSTOMER'
  | 'RATE_LIMITED'
  | 'STRIPE_UNAVAILABLE'
  | 'CHECKOUT_FAILED'
  | 'PORTAL_FAILED'
  | 'PAYMENT_FAILED'
  | 'CHANGE_FAILED'
  | 'SESSION_NOT_FOUND'
  | 'INVALID_SIGNATURE'
  | 'INTERNAL';

const MESSAGES: Record<BillingErrorCode, [status: number, message: string]> = {
  UNAUTHORIZED: [401, 'Accedi per continuare.'],
  FORBIDDEN: [403, 'Non hai i permessi per gestire la fatturazione di questo locale. Serve il ruolo di titolare.'],
  BAD_REQUEST: [400, 'Richiesta non valida.'],
  METHOD_NOT_ALLOWED: [405, 'Metodo non consentito.'],
  NOT_CONFIGURED: [503, 'I pagamenti online non sono ancora attivi. Riprova più tardi o contatta il supporto.'],
  RESTAURANT_NOT_FOUND: [404, 'Locale non trovato.'],
  INVALID_PLAN: [400, 'Piano non valido o non più disponibile.'],
  INVALID_INTERVAL: [400, 'Periodo di fatturazione non valido.'],
  PRICE_NOT_CONFIGURED: [409, 'Questo piano non è ancora acquistabile online (prezzo non configurato). Contatta il supporto.'],
  ALREADY_SUBSCRIBED: [409, 'Il locale ha già un abbonamento attivo: usa «Cambia piano» dalla pagina Fatturazione.'],
  PROMO_INVALID: [400, 'Codice promozionale non valido, scaduto o già utilizzato.'],
  SUBSCRIPTION_NOT_FOUND: [404, 'Nessun abbonamento attivo da modificare.'],
  SAME_PLAN: [400, 'Hai già questo piano con questo periodo di fatturazione.'],
  NO_CUSTOMER: [409, 'Non c’è ancora un profilo di pagamento per questo locale: attiva prima un piano.'],
  RATE_LIMITED: [429, 'Troppe richieste in poco tempo. Riprova tra qualche minuto.'],
  STRIPE_UNAVAILABLE: [503, 'Il servizio di pagamento non risponde. Riprova tra poco: nessun addebito è stato effettuato.'],
  CHECKOUT_FAILED: [502, 'Non è stato possibile avviare il pagamento. Riprova tra poco.'],
  PORTAL_FAILED: [502, 'Non è stato possibile aprire la gestione dell’abbonamento. Riprova tra poco.'],
  PAYMENT_FAILED: [402, 'Il pagamento non è andato a buon fine: aggiorna il metodo di pagamento e riprova. Il piano non è cambiato.'],
  CHANGE_FAILED: [502, 'Non è stato possibile modificare l’abbonamento. Riprova tra poco: il piano attuale non è cambiato.'],
  SESSION_NOT_FOUND: [404, 'Sessione di pagamento non trovata.'],
  INVALID_SIGNATURE: [400, 'Firma non valida.'],
  INTERNAL: [500, 'Si è verificato un errore. Riprova tra poco.'],
};

export class BillingError extends Error {
  readonly status: number;
  constructor(
    readonly code: BillingErrorCode,
    readonly detail?: string,
  ) {
    super(MESSAGES[code][1]);
    this.name = 'BillingError';
    this.status = MESSAGES[code][0];
  }
}

export const isBillingErrorCode = (c: unknown): c is BillingErrorCode => typeof c === 'string' && c in MESSAGES;

/**
 * Traduce gli errori dell'SDK Stripe in codici applicativi.
 * `fallback` = codice da usare per errori di richiesta non previsti.
 */
export function fromStripeError(e: unknown, fallback: BillingErrorCode): BillingError {
  if (e instanceof BillingError) return e;
  const err = e as { type?: string; code?: string; message?: string; statusCode?: number };
  const detail = `${err.type ?? 'Error'}${err.code ? `/${err.code}` : ''}: ${err.message ?? String(e)}`.slice(0, 400);
  switch (err.type) {
    case 'StripeConnectionError':
    case 'StripeAPIError':
    case 'StripeRateLimitError':
      return new BillingError('STRIPE_UNAVAILABLE', detail);
    case 'StripeCardError':
      return new BillingError('PAYMENT_FAILED', detail);
    case 'StripeAuthenticationError':
    case 'StripePermissionError':
      return new BillingError('NOT_CONFIGURED', detail);
    default:
      if ((err.statusCode ?? 0) >= 500) return new BillingError('STRIPE_UNAVAILABLE', detail);
      return new BillingError(fallback, detail);
  }
}
