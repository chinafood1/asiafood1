// ─────────────────────────────────────────────────────────────
//  Runtime di produzione (Netlify Functions, Node 20).
//  Le chiavi segrete si leggono SOLO qui, da variabili d'ambiente
//  del server: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET,
//  SUPABASE_SERVICE_ROLE_KEY. Mai nel bundle del frontend.
// ─────────────────────────────────────────────────────────────
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import Stripe from 'stripe';
import { BillingError } from './errors';
import type { BillingConfig, BillingDeps, Handler, HttpRequest, Logger, StripeEnvironment, Store } from './types';
import { createLogger } from '../platform/logger';

const env = (k: string) => (process.env[k] ?? '').trim();

/** Ambiente Stripe dalla chiave; STRIPE_MODE (facoltativo) impedisce di usare per errore la chiave live. */
export function resolveStripeEnvironment(secretKey: string, mode: string): StripeEnvironment {
  const fromKey: StripeEnvironment | null = /^(sk|rk)_live_/.test(secretKey) ? 'live' : /^(sk|rk)_test_/.test(secretKey) ? 'test' : null;
  if (!fromKey) throw new Error('STRIPE_SECRET_KEY non valida (attesa sk_test_… o sk_live_…)');
  if (mode && mode !== fromKey) throw new Error(`STRIPE_MODE=${mode} ma la chiave è di tipo ${fromKey}: configurazione rifiutata`);
  return fromKey;
}

// Logger centralizzato (livelli, JSON strutturato, redazione di segreti e PII): Netlify → Functions → Logs
export const log: Logger = createLogger({ scope: 'billing' });

let cached: { deps: BillingDeps; envSynced: boolean } | null = null;

function supabaseStore(sb: SupabaseClient): Store {
  return {
    async rpc<T>(fn: string, args: Record<string, unknown>) {
      const { data, error } = await sb.rpc(fn, args);
      if (error) {
        log('error', 'rpc failed', { fn, code: error.code, message: error.message });
        throw new BillingError('INTERNAL', `${fn}: ${error.message}`);
      }
      return data as T;
    },
  };
}

/** Solo database (cron): funziona anche senza Stripe configurato, per le scadenze dei piani manuali. */
export function cronDeps(): Pick<BillingDeps, 'store' | 'log'> {
  const supabaseUrl = env('SUPABASE_URL') || env('VITE_SUPABASE_URL');
  const serviceKey = env('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !serviceKey) throw new Error('SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY mancanti');
  return { store: supabaseStore(createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } })), log };
}

/** Dipendenze di produzione (create una volta per istanza della funzione). */
export function productionDeps(): BillingDeps {
  if (cached) return cached.deps;
  const secret = env('STRIPE_SECRET_KEY');
  const supabaseUrl = env('SUPABASE_URL') || env('VITE_SUPABASE_URL');
  const serviceKey = env('SUPABASE_SERVICE_ROLE_KEY');
  const appUrl = (env('APP_URL') || env('URL') || env('VITE_SITE_URL')).replace(/\/$/, '');
  if (!secret || !supabaseUrl || !serviceKey || !appUrl) {
    throw new BillingError('NOT_CONFIGURED', 'missing STRIPE_SECRET_KEY / SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY / APP_URL');
  }
  const config: BillingConfig = {
    env: resolveStripeEnvironment(secret, env('STRIPE_MODE').toLowerCase()),
    appUrl,
    webhookSecret: env('STRIPE_WEBHOOK_SECRET') || null,
    connectWebhookSecret: env('STRIPE_CONNECT_WEBHOOK_SECRET') || null,
    taxEnabled: env('STRIPE_TAX_ENABLED').toLowerCase() === 'true',
    portalConfigurationId: env('STRIPE_PORTAL_CONFIGURATION_ID') || null,
    allowPromotionCodes: env('STRIPE_ALLOW_PROMOTION_CODES').toLowerCase() === 'true',
  };
  const stripe = new Stripe(secret, { maxNetworkRetries: 2, timeout: 20_000, appInfo: { name: 'AsiaFood' } });
  const sb = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const deps: BillingDeps = {
    stripe,
    store: supabaseStore(sb),
    config,
    log,
    async verifyUser(token) {
      if (!token || token.length > 4096) return null;
      const { data, error } = await sb.auth.getUser(token);
      return error || !data.user ? null : data.user.id;
    },
  };
  cached = { deps, envSynced: false };
  return deps;
}

async function syncEnvironmentOnce(deps: BillingDeps) {
  if (!cached || cached.envSynced) return;
  try {
    await deps.store.rpc('billing_set_environment', { p_env: deps.config.env });
    cached.envSynced = true;
  } catch (e) {
    log('warn', 'billing_set_environment failed', { error: String(e) });
  }
}

const HEADERS = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };

/** Adattatore Request/Response (Netlify Functions v2) → handler di fatturazione. */
export function netlifyHandler(handler: Handler) {
  return async (request: Request): Promise<Response> => {
    let deps: BillingDeps;
    try {
      deps = productionDeps();
    } catch (e) {
      log('error', 'billing not configured', { error: e instanceof BillingError ? e.detail : String(e) });
      return new Response(JSON.stringify({ error: 'NOT_CONFIGURED', message: new BillingError('NOT_CONFIGURED').message }), { status: 503, headers: HEADERS });
    }
    await syncEnvironmentOnce(deps);
    const req: HttpRequest = {
      method: request.method,
      header: (name) => request.headers.get(name),
      body: request.method === 'GET' ? '' : await request.text(),
    };
    const res = await handler(req, deps);
    return new Response(JSON.stringify(res.body), { status: res.status, headers: HEADERS });
  };
}
