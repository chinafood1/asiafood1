// ─────────────────────────────────────────────────────────────
//  Endpoint di fatturazione (indipendenti dal runtime).
//  Regole: utente verificato dal JWT, ruolo titolare verificato
//  nel DB, Price/Customer/Subscription ID letti SOLO dal DB,
//  Stripe come fonte autorevole, nessun dato sensibile in uscita.
// ─────────────────────────────────────────────────────────────
import type Stripe from 'stripe';
import {
  contextError,
  ensureCustomer,
  ensurePromotionCoupon,
  intervalField,
  planField,
  rateLimit,
  readJson,
  requireUser,
  syncSubscription,
  textField,
  uuidField,
} from './core';
import { BillingError, fromStripeError } from './errors';
import { envOf, invoicePayload, invoiceSubscriptionId, primaryItem, prorationAmount } from './mapping';
import type { BillingDeps, ChangeContext, CheckoutContext, Handler, HttpRequest, HttpResponse, ManageContext } from './types';
import { ORDER_EVENT_TYPES, processOrderEvent } from '../orders/handlers';

const json = (status: number, body: unknown): HttpResponse => ({ status, body });
const nowSec = (deps: BillingDeps) => Math.floor((deps.now?.() ?? Date.now()) / 1000);

/** Avvolge un handler: metodo, errori → risposta JSON con messaggio per l'utente (mai stack trace). */
export function endpoint(fn: (req: HttpRequest, deps: BillingDeps) => Promise<unknown>, method = 'POST'): Handler {
  return async (req, deps) => {
    if (req.method !== method) return json(405, { error: 'METHOD_NOT_ALLOWED', message: 'Metodo non consentito.' });
    try {
      return json(200, await fn(req, deps));
    } catch (e) {
      const err = e instanceof BillingError ? e : new BillingError('INTERNAL', e instanceof Error ? e.message : String(e));
      deps.log(err.status >= 500 ? 'error' : 'warn', `billing ${err.code}`, { detail: err.detail });
      return json(err.status, { error: err.code, message: err.message });
    }
  };
}

async function manageContext(deps: BillingDeps, user: string, restaurantId: string): Promise<ManageContext> {
  const ctx = await deps.store.rpc<ManageContext>('billing_manage_context', { p_user: user, p_restaurant: restaurantId, p_env: deps.config.env });
  if (!ctx.ok) throw contextError(ctx.error);
  return ctx;
}

// ═════════════════════════════════════════════════════════════
//  create-checkout-session
// ═════════════════════════════════════════════════════════════
export const createCheckoutSession = endpoint(async (req, deps) => {
  const user = await requireUser(req, deps);
  const body = readJson(req);
  const restaurantId = uuidField(body, 'restaurant_id');
  const plan = planField(body);
  const interval = intervalField(body);
  const promoCode = textField(body, 'promotion_code', /^[A-Za-z0-9_-]{3,30}$/, true);
  await rateLimit(deps, user, 'checkout', 8, 600);

  const ctx = await deps.store.rpc<CheckoutContext>('billing_checkout_context', {
    p_user: user, p_restaurant: restaurantId, p_plan: plan, p_interval: interval, p_env: deps.config.env, p_promo: promoCode,
  });
  if (!ctx.ok) throw contextError(ctx.error);

  const customer = await ensureCustomer(deps, ctx.account, user);
  const coupon = ctx.promotion ? await ensurePromotionCoupon(deps, ctx.promotion) : null;
  const { appUrl, taxEnabled, allowPromotionCodes } = deps.config;
  const metadata: Record<string, string> = {
    restaurant_id: ctx.restaurant.id,
    plan_code: ctx.plan.code,
    billing_interval: interval,
    user_id: user,
    billing_account_id: ctx.account.id,
    ...(ctx.promotion ? { promotion_id: ctx.promotion.id } : {}),
  };
  const trial = ctx.trial_days > 0;
  const params: Stripe.Checkout.SessionCreateParams = {
    mode: 'subscription',
    customer,
    client_reference_id: ctx.restaurant.id,
    line_items: [{ price: ctx.plan.price_id, quantity: 1 }],
    locale: 'it',
    success_url: `${appUrl}/dashboard/billing/success?session_id={CHECKOUT_SESSION_ID}&restaurant=${ctx.restaurant.id}`,
    cancel_url: `${appUrl}/dashboard/billing/cancel?restaurant=${ctx.restaurant.id}&plan=${ctx.plan.code}`,
    metadata,
    subscription_data: {
      metadata,
      description: `AsiaFood ${ctx.plan.name} — ${ctx.restaurant.name}`,
      ...(trial
        ? { trial_period_days: ctx.trial_days, trial_settings: { end_behavior: { missing_payment_method: 'cancel' } } }
        : {}),
    },
    // Prova senza carta: Stripe non chiede il metodo di pagamento finché non serve
    payment_method_collection: trial && !ctx.require_payment_method ? 'if_required' : 'always',
    billing_address_collection: taxEnabled ? 'required' : 'auto',
  };
  if (coupon) params.discounts = [{ coupon }];
  else if (allowPromotionCodes) params.allow_promotion_codes = true;
  if (taxEnabled) {
    params.automatic_tax = { enabled: true };
    params.customer_update = { address: 'auto', name: 'auto' };
    params.tax_id_collection = { enabled: true };
  }

  try {
    const minute = Math.floor(nowSec(deps) / 60);
    const session = await deps.stripe.checkout.sessions.create(params, {
      idempotencyKey: `asiafood-checkout-${ctx.restaurant.id}-${ctx.plan.code}-${interval}-${ctx.promotion?.id ?? 'none'}-${minute}`,
    });
    if (!session.url) throw new BillingError('CHECKOUT_FAILED', 'session without url');
    deps.log('info', 'checkout created', { restaurant: ctx.restaurant.id, plan: ctx.plan.code, interval, trial_days: ctx.trial_days });
    return { url: session.url, session_id: session.id, trial_days: ctx.trial_days };
  } catch (e) {
    throw fromStripeError(e, 'CHECKOUT_FAILED');
  }
});

// ═════════════════════════════════════════════════════════════
//  create-customer-portal-session
// ═════════════════════════════════════════════════════════════
export const createCustomerPortalSession = endpoint(async (req, deps) => {
  const user = await requireUser(req, deps);
  const body = readJson(req);
  const restaurantId = uuidField(body, 'restaurant_id');
  const flow = textField(body, 'flow', /^(payment_method_update|subscription_cancel)$/, true);
  await rateLimit(deps, user, 'portal', 10, 600);
  const ctx = await manageContext(deps, user, restaurantId);
  if (!ctx.customer_id) throw new BillingError('NO_CUSTOMER');
  const params: Stripe.BillingPortal.SessionCreateParams = {
    customer: ctx.customer_id,
    return_url: `${deps.config.appUrl}/dashboard/restaurants/${restaurantId}/billing`,
    locale: 'it',
  };
  if (deps.config.portalConfigurationId) params.configuration = deps.config.portalConfigurationId;
  if (flow === 'payment_method_update') params.flow_data = { type: 'payment_method_update' };
  if (flow === 'subscription_cancel' && ctx.subscription?.stripe_subscription_id) {
    params.flow_data = { type: 'subscription_cancel', subscription_cancel: { subscription: ctx.subscription.stripe_subscription_id } };
  }
  try {
    const session = await deps.stripe.billingPortal.sessions.create(params);
    return { url: session.url };
  } catch (e) {
    throw fromStripeError(e, 'PORTAL_FAILED');
  }
});

// ═════════════════════════════════════════════════════════════
//  Azioni sull'abbonamento (ristoratore)
// ═════════════════════════════════════════════════════════════
async function changeContext(deps: BillingDeps, user: string, restaurantId: string, body: Record<string, unknown>): Promise<ChangeContext> {
  const ctx = await deps.store.rpc<ChangeContext>('billing_change_context', {
    p_user: user, p_restaurant: restaurantId, p_plan: planField(body), p_interval: intervalField(body), p_env: deps.config.env,
  });
  if (!ctx.ok) throw contextError(ctx.error);
  return ctx;
}

async function retrieveSub(deps: BillingDeps, id: string): Promise<Stripe.Subscription> {
  try {
    return await deps.stripe.subscriptions.retrieve(id);
  } catch (e) {
    if ((e as { code?: string }).code === 'resource_missing') throw new BillingError('SUBSCRIPTION_NOT_FOUND', id);
    throw fromStripeError(e, 'CHANGE_FAILED');
  }
}

async function releaseSchedule(deps: BillingDeps, scheduleId: string | null | undefined) {
  if (!scheduleId) return;
  try {
    await deps.stripe.subscriptionSchedules.release(scheduleId);
  } catch (e) {
    // Già rilasciata o completata: non è un errore per l'utente
    deps.log('warn', 'schedule release failed', { schedule: scheduleId, error: String(e) });
  }
}

const periodEndOf = (sub: Stripe.Subscription) =>
  (primaryItem(sub) as unknown as { current_period_end?: number } | null)?.current_period_end ??
  (sub as unknown as { current_period_end?: number }).current_period_end ??
  0;
const periodStartOf = (sub: Stripe.Subscription) =>
  (primaryItem(sub) as unknown as { current_period_start?: number } | null)?.current_period_start ??
  (sub as unknown as { current_period_start?: number }).current_period_start ??
  0;

async function previewChange(deps: BillingDeps, ctx: ChangeContext) {
  const s = ctx.subscription!;
  const base = {
    kind: ctx.kind,
    immediate: ctx.immediate,
    target: ctx.target,
    currency: 'EUR',
    trialing: s.status === 'trialing',
  };
  if (!ctx.immediate) return { ...base, amount_due_cents: 0, effective_at: s.current_period_end };
  if (s.status === 'trialing') return { ...base, amount_due_cents: 0, effective_at: new Date(nowSec(deps) * 1000).toISOString() };
  const sub = await retrieveSub(deps, s.stripe_subscription_id);
  const item = primaryItem(sub);
  if (!item) throw new BillingError('SUBSCRIPTION_NOT_FOUND', 'no items');
  try {
    const preview = await deps.stripe.invoices.createPreview({
      customer: ctx.customer_id ?? (typeof sub.customer === 'string' ? sub.customer : sub.customer.id),
      subscription: sub.id,
      subscription_details: {
        items: [{ id: item.id, price: ctx.target.price_id }],
        proration_behavior: ctx.proration_behavior === 'none' ? 'none' : 'create_prorations',
        proration_date: nowSec(deps),
      },
    });
    // Cambio di intervallo = nuovo ciclo: si paga subito la fattura intera (al netto del credito)
    const intervalChanges = ctx.target.interval !== s.billing_interval;
    const amount = ctx.proration_behavior === 'none' ? 0 : intervalChanges ? preview.amount_due : Math.max(prorationAmount(preview), 0);
    return {
      ...base,
      amount_due_cents: amount,
      currency: (preview.currency ?? 'eur').toUpperCase(),
      charged_now: ctx.proration_behavior === 'always_invoice' || intervalChanges,
      effective_at: new Date(nowSec(deps) * 1000).toISOString(),
    };
  } catch (e) {
    throw fromStripeError(e, 'CHANGE_FAILED');
  }
}

async function applyChange(deps: BillingDeps, ctx: ChangeContext) {
  const s = ctx.subscription!;
  const sub = await retrieveSub(deps, s.stripe_subscription_id);
  const item = primaryItem(sub);
  if (!item) throw new BillingError('SUBSCRIPTION_NOT_FOUND', 'no items');
  const metadata = { ...(sub.metadata ?? {}), plan_code: ctx.target.plan_code, billing_interval: ctx.target.interval };

  if (ctx.immediate) {
    // Un cambio immediato annulla eventuali cambi programmati
    await releaseSchedule(deps, s.stripe_schedule_id ?? (typeof sub.schedule === 'string' ? sub.schedule : sub.schedule?.id));
    const trialing = sub.status === 'trialing';
    try {
      await deps.stripe.subscriptions.update(sub.id, {
        items: [{ id: item.id, price: ctx.target.price_id }],
        proration_behavior: trialing ? 'none' : ctx.proration_behavior,
        // Se l'addebito immediato fallisce Stripe annulla il cambio: il piano resta quello pagato
        ...(trialing || ctx.proration_behavior !== 'always_invoice' ? {} : { payment_behavior: 'error_if_incomplete' as const }),
        metadata,
      });
    } catch (e) {
      throw fromStripeError(e, 'CHANGE_FAILED');
    }
    const res = await syncSubscription(deps, sub.id);
    return { status: 'updated', plan_code: res.plan_code ?? ctx.target.plan_code, effective_at: new Date(nowSec(deps) * 1000).toISOString() };
  }

  // Downgrade o passaggio da annuale a mensile: a fine ciclo, tramite Subscription Schedule
  try {
    if (sub.cancel_at_period_end) await deps.stripe.subscriptions.update(sub.id, { cancel_at_period_end: false });
    let scheduleId = typeof sub.schedule === 'string' ? sub.schedule : sub.schedule?.id ?? null;
    if (!scheduleId) {
      const created = await deps.stripe.subscriptionSchedules.create({ from_subscription: sub.id });
      scheduleId = created.id;
    }
    const periodEnd = periodEndOf(sub);
    await deps.stripe.subscriptionSchedules.update(scheduleId, {
      end_behavior: 'release',
      proration_behavior: 'none',
      phases: [
        { items: [{ price: item.price.id, quantity: item.quantity ?? 1 }], start_date: periodStartOf(sub), end_date: periodEnd, metadata: sub.metadata ?? {} },
        { items: [{ price: ctx.target.price_id, quantity: 1 }], metadata },
      ],
    });
    await deps.store.rpc('billing_set_scheduled_change', {
      p_stripe_sub: sub.id, p_schedule: scheduleId, p_price: ctx.target.price_id, p_at: new Date(periodEnd * 1000).toISOString(),
    });
    await syncSubscription(deps, sub.id);
    return { status: 'scheduled', plan_code: ctx.target.plan_code, effective_at: new Date(periodEnd * 1000).toISOString() };
  } catch (e) {
    throw fromStripeError(e, 'CHANGE_FAILED');
  }
}

export const billingActions = endpoint(async (req, deps) => {
  const user = await requireUser(req, deps);
  const body = readJson(req);
  const action = textField(body, 'action', /^(preview_change|change_plan|cancel|resume|cancel_scheduled_change|confirm_checkout|refresh_invoices)$/)!;

  if (action === 'confirm_checkout') {
    // Ritorno dal checkout: legge la sessione DA STRIPE (non si fida dell'URL) e sincronizza.
    // La conferma definitiva arriva comunque dal webhook; questa lettura rende la pagina immediata.
    const sessionId = textField(body, 'session_id', /^cs_(test|live)_[A-Za-z0-9]{10,200}$/)!;
    await rateLimit(deps, user, 'confirm', 30, 600);
    let session: Stripe.Checkout.Session;
    try {
      session = await deps.stripe.checkout.sessions.retrieve(sessionId);
    } catch (e) {
      if ((e as { code?: string }).code === 'resource_missing') throw new BillingError('SESSION_NOT_FOUND');
      throw fromStripeError(e, 'INTERNAL');
    }
    const restaurantId = session.metadata?.restaurant_id ?? '';
    if (!restaurantId) throw new BillingError('SESSION_NOT_FOUND', 'no metadata');
    await manageContext(deps, user, restaurantId); // l'utente deve poter gestire quel locale
    const subId = typeof session.subscription === 'string' ? session.subscription : session.subscription?.id ?? null;
    let synced = null;
    if (session.status === 'complete' && subId) {
      synced = await syncSubscription(deps, subId, { restaurantId });
      if (session.metadata?.promotion_id) {
        await deps.store.rpc('billing_redeem_promotion', {
          p_promotion: session.metadata.promotion_id, p_restaurant: restaurantId, p_user: user, p_stripe_sub: subId,
        });
      }
    }
    return {
      status: session.status,
      payment_status: session.payment_status,
      restaurant_id: restaurantId,
      plan_code: session.metadata?.plan_code ?? null,
      billing_interval: session.metadata?.billing_interval ?? null,
      subscription_status: synced?.status ?? null,
      effective_plan: synced?.effective_plan ?? null,
    };
  }

  const restaurantId = uuidField(body, 'restaurant_id');
  await rateLimit(deps, user, 'action', 30, 600);

  if (action === 'preview_change') return previewChange(deps, await changeContext(deps, user, restaurantId, body));
  if (action === 'change_plan') {
    await rateLimit(deps, user, 'change_plan', 10, 600);
    return applyChange(deps, await changeContext(deps, user, restaurantId, body));
  }

  const ctx = await manageContext(deps, user, restaurantId);
  const s = ctx.subscription;

  if (action === 'refresh_invoices') {
    if (!ctx.customer_id) return { invoices: 0 };
    try {
      const list = await deps.stripe.invoices.list({ customer: ctx.customer_id, limit: 24 });
      for (const inv of list.data) {
        if (!inv.id) continue;
        await deps.store.rpc('billing_record_invoice', { p: { ...invoicePayload(inv), restaurant_id: restaurantId }, p_event: 'invoice.synced' });
      }
      return { invoices: list.data.length };
    } catch (e) {
      throw fromStripeError(e, 'INTERNAL');
    }
  }

  if (!s || !['trialing', 'active', 'past_due', 'unpaid', 'paused'].includes(s.status)) throw new BillingError('SUBSCRIPTION_NOT_FOUND');

  try {
    if (action === 'cancel') {
      // Default: cancellazione a fine periodo. Eventuali cambi programmati vengono annullati.
      if (s.stripe_schedule_id) {
        await releaseSchedule(deps, s.stripe_schedule_id);
        await deps.store.rpc('billing_set_scheduled_change', { p_stripe_sub: s.stripe_subscription_id, p_schedule: null, p_price: null, p_at: null });
      }
      await deps.stripe.subscriptions.update(s.stripe_subscription_id, { cancel_at_period_end: true });
      const res = await syncSubscription(deps, s.stripe_subscription_id);
      return { status: 'cancel_scheduled', until: s.status === 'trialing' ? s.trial_end : s.current_period_end, subscription_status: res.status };
    }
    if (action === 'resume') {
      await deps.stripe.subscriptions.update(s.stripe_subscription_id, { cancel_at_period_end: false });
      const res = await syncSubscription(deps, s.stripe_subscription_id);
      return { status: 'resumed', subscription_status: res.status };
    }
    // cancel_scheduled_change
    await releaseSchedule(deps, s.stripe_schedule_id);
    await deps.store.rpc('billing_set_scheduled_change', { p_stripe_sub: s.stripe_subscription_id, p_schedule: null, p_price: null, p_at: null });
    await syncSubscription(deps, s.stripe_subscription_id);
    return { status: 'change_cancelled' };
  } catch (e) {
    throw fromStripeError(e, 'CHANGE_FAILED');
  }
});

// ═════════════════════════════════════════════════════════════
//  Webhook Stripe
// ═════════════════════════════════════════════════════════════
const SUBSCRIPTION_EVENTS = new Set([
  'customer.subscription.created',
  'customer.subscription.updated',
  'customer.subscription.deleted',
  'customer.subscription.paused',
  'customer.subscription.resumed',
  'customer.subscription.trial_will_end',
]);
const INVOICE_EVENTS = new Set([
  'invoice.paid',
  'invoice.payment_succeeded',
  'invoice.payment_failed',
  'invoice.payment_action_required',
  'invoice.finalized',
]);

async function processEvent(deps: BillingDeps, event: Stripe.Event): Promise<{ status: 'processed' | 'ignored'; restaurantId?: string | null; note?: string }> {
  const type = event.type as string;
  // Fase 8: pagamenti degli ordini B2C e Stripe Connect → modulo ordini (stesso endpoint, stessa idempotenza)
  if (ORDER_EVENT_TYPES.has(type)) {
    return processOrderEvent({ stripe: deps.stripe, store: deps.store, log: deps.log, config: { env: deps.config.env } }, event);
  }
  if (type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    if (session.mode !== 'subscription') return { status: 'ignored', note: 'not a subscription checkout' };
    const subId = typeof session.subscription === 'string' ? session.subscription : session.subscription?.id;
    const restaurantId = session.metadata?.restaurant_id ?? session.client_reference_id ?? null;
    if (!subId) return { status: 'ignored', note: 'no subscription' };
    const res = await syncSubscription(deps, subId, { restaurantId });
    if (!res.ok) return { status: 'ignored', restaurantId, note: res.error };
    if (session.metadata?.promotion_id && restaurantId) {
      await deps.store.rpc('billing_redeem_promotion', {
        p_promotion: session.metadata.promotion_id, p_restaurant: restaurantId, p_user: session.metadata.user_id ?? null, p_stripe_sub: subId,
      });
    }
    return { status: 'processed', restaurantId: res.restaurant_id };
  }
  if (SUBSCRIPTION_EVENTS.has(type)) {
    const sub = event.data.object as Stripe.Subscription;
    const res = await syncSubscription(deps, sub.id, { restaurantId: sub.metadata?.restaurant_id });
    if (!res.ok) return { status: 'ignored', note: res.error };
    if (type === 'customer.subscription.trial_will_end') await deps.store.rpc('billing_trial_expiring', { p_stripe_sub: sub.id });
    return { status: 'processed', restaurantId: res.restaurant_id };
  }
  if (INVOICE_EVENTS.has(type)) {
    const inv = event.data.object as Stripe.Invoice;
    if (!inv.id) return { status: 'ignored', note: 'draft preview' };
    const subId = invoiceSubscriptionId(inv);
    // Prima la subscription (lo stato può essere cambiato), poi la fattura
    if (subId) await syncSubscription(deps, subId).catch((e: unknown) => deps.log('warn', 'sync before invoice failed', { error: String(e) }));
    const kind = type === 'invoice.payment_succeeded' ? 'invoice.paid' : type;
    const res = await deps.store.rpc<{ ok: boolean; restaurant_id?: string }>('billing_record_invoice', { p: invoicePayload(inv), p_event: kind });
    if (subId) await syncSubscription(deps, subId).catch(() => undefined);
    return { status: 'processed', restaurantId: res.restaurant_id ?? null };
  }
  if (type === 'customer.updated') {
    // I dati di fatturazione di AsiaFood restano la fonte per nome/P.IVA: qui solo registro l'evento.
    return { status: 'processed' };
  }
  return { status: 'ignored', note: 'event not handled' };
}

export const stripeWebhook: Handler = async (req, deps) => {
  if (req.method !== 'POST') return json(405, { error: 'METHOD_NOT_ALLOWED' });
  if (!deps.config.webhookSecret) {
    deps.log('error', 'STRIPE_WEBHOOK_SECRET missing');
    return json(503, { error: 'NOT_CONFIGURED' });
  }
  let event: Stripe.Event;
  try {
    event = deps.stripe.webhooks.constructEvent(req.body, req.header('stripe-signature') ?? '', deps.config.webhookSecret);
  } catch (e) {
    // Eventi degli account collegati (Stripe Connect) arrivano da un endpoint "Connect" con il proprio segreto
    let connectEvent: Stripe.Event | null = null;
    if (deps.config.connectWebhookSecret) {
      try {
        connectEvent = deps.stripe.webhooks.constructEvent(req.body, req.header('stripe-signature') ?? '', deps.config.connectWebhookSecret);
      } catch {
        connectEvent = null;
      }
    }
    if (!connectEvent) {
      deps.log('warn', 'webhook signature invalid', { error: e instanceof Error ? e.message : String(e) });
      return json(400, { error: 'INVALID_SIGNATURE' });
    }
    event = connectEvent;
  }
  const env = envOf(event.livemode);
  if (env !== deps.config.env) {
    // Eventi di un altro ambiente (test ↔ live) non si mescolano mai
    return json(200, { received: true, ignored: 'environment' });
  }
  const obj = event.data.object as { id?: string };
  const begin = await deps.store.rpc<string>('billing_event_begin', {
    p_event_id: event.id, p_type: event.type, p_env: env, p_object_id: obj.id ?? null,
  });
  if (begin === 'duplicate') return json(200, { received: true, duplicate: true });
  if (begin === 'in_progress') return json(409, { error: 'IN_PROGRESS' });
  try {
    const r = await processEvent(deps, event);
    await deps.store.rpc('billing_event_finish', { p_event_id: event.id, p_status: r.status, p_error: r.note ?? null, p_restaurant: r.restaurantId ?? null });
    return json(200, { received: true, status: r.status });
  } catch (e) {
    const msg = e instanceof BillingError ? `${e.code}: ${e.detail ?? ''}` : e instanceof Error ? e.message : String(e);
    deps.log('error', 'webhook processing failed', { event: event.id, type: event.type, error: msg });
    await deps.store.rpc('billing_event_finish', { p_event_id: event.id, p_status: 'failed', p_error: msg.slice(0, 480), p_restaurant: null }).catch(() => undefined);
    // 500 → Stripe ritenta la consegna (con backoff) fino a 3 giorni
    return json(500, { error: 'PROCESSING_FAILED' });
  }
};

// ═════════════════════════════════════════════════════════════
//  Admin: sincronizzazione, estensione prova, prezzi, stato
// ═════════════════════════════════════════════════════════════
interface AdminContext {
  ok: boolean;
  error?: string;
  source?: string;
  stripe_subscription_id?: string | null;
  stripe_environment?: string | null;
  status?: string;
  trial_end?: string | null;
}

interface ProvisionPlan {
  code: string;
  name: string;
  description: string | null;
  monthly_price: number;
  yearly_price: number | null;
  currency: string;
  stripe_product_id: string | null;
  stripe_monthly_price_id: string | null;
  stripe_yearly_price_id: string | null;
}

async function ensurePrice(deps: BillingDeps, plan: ProvisionPlan, product: string, interval: 'month' | 'year', amount: number | null, current: string | null) {
  if (!amount || amount <= 0) return current;
  const cents = Math.round(Number(amount) * 100);
  if (current) {
    try {
      const p = await deps.stripe.prices.retrieve(current);
      if (p.active && p.unit_amount === cents && p.recurring?.interval === interval && (typeof p.product === 'string' ? p.product : p.product.id) === product) return current;
    } catch (e) {
      deps.log('warn', 'price lookup failed: creating a new one', { price: current, error: String(e) });
    }
  }
  // I prezzi Stripe sono immutabili: un nuovo importo = nuovo Price (gli abbonati esistenti restano sul precedente)
  const created = await deps.stripe.prices.create(
    {
      product,
      currency: (plan.currency || 'EUR').toLowerCase(),
      unit_amount: cents,
      recurring: { interval },
      lookup_key: `asiafood_${plan.code}_${interval}`,
      transfer_lookup_key: true,
      nickname: `${plan.name} ${interval === 'year' ? 'annuale' : 'mensile'}`,
      metadata: { plan_code: plan.code, interval },
    },
    { idempotencyKey: `asiafood-price-${plan.code}-${interval}-${cents}-${product}` },
  );
  return created.id;
}

export const billingAdmin = endpoint(async (req, deps) => {
  const user = await requireUser(req, deps);
  const body = readJson(req);
  const action = textField(body, 'action', /^(status|sync|sync_all|extend_trial|provision_prices|refresh_plans)$/)!;
  const subscriptionId = action === 'sync' || action === 'extend_trial' ? uuidField(body, 'subscription_id') : null;
  const ctx = await deps.store.rpc<AdminContext>('billing_admin_context', { p_user: user, p_subscription: subscriptionId });
  if (!ctx.ok) throw contextError(ctx.error);
  await rateLimit(deps, user, 'admin', 60, 600);

  if (action === 'status') {
    return {
      configured: true,
      environment: deps.config.env,
      tax_enabled: deps.config.taxEnabled,
      webhook_secret_configured: !!deps.config.webhookSecret,
      portal_configuration: deps.config.portalConfigurationId ? 'custom' : 'default',
      allow_promotion_codes: deps.config.allowPromotionCodes,
      app_url: deps.config.appUrl,
    };
  }
  if (action === 'refresh_plans') return { changed: await deps.store.rpc<number>('billing_refresh_plans', {}) };

  if (action === 'sync') {
    if (ctx.source !== 'stripe' || !ctx.stripe_subscription_id) throw new BillingError('BAD_REQUEST', 'not a stripe subscription');
    if (ctx.stripe_environment && ctx.stripe_environment !== deps.config.env) throw new BillingError('BAD_REQUEST', 'other environment');
    return syncSubscription(deps, ctx.stripe_subscription_id);
  }
  if (action === 'sync_all') {
    const ids = await deps.store.rpc<string[]>('billing_stripe_subscription_ids', { p_env: deps.config.env });
    let ok = 0;
    const errors: string[] = [];
    for (const id of (ids ?? []).slice(0, 200)) {
      try {
        const r = await syncSubscription(deps, id);
        if (r.ok) ok++;
        else errors.push(`${id}: ${r.error}`);
      } catch (e) {
        errors.push(`${id}: ${e instanceof BillingError ? e.code : 'errore'}`);
      }
    }
    const changed = await deps.store.rpc<number>('billing_refresh_plans', {});
    return { synced: ok, errors: errors.slice(0, 20), plans_changed: changed };
  }
  if (action === 'extend_trial') {
    const days = Number(body.days);
    const max = 60;
    if (!Number.isInteger(days) || days < 1 || days > max) throw new BillingError('BAD_REQUEST', 'days');
    if (ctx.source !== 'stripe' || !ctx.stripe_subscription_id || ctx.status !== 'trialing') {
      throw new BillingError('BAD_REQUEST', 'only trialing stripe subscriptions');
    }
    const base = Math.max(ctx.trial_end ? Date.parse(ctx.trial_end) / 1000 : 0, nowSec(deps));
    try {
      await deps.stripe.subscriptions.update(ctx.stripe_subscription_id, { trial_end: Math.floor(base + days * 86400), proration_behavior: 'none' });
    } catch (e) {
      throw fromStripeError(e, 'CHANGE_FAILED');
    }
    return syncSubscription(deps, ctx.stripe_subscription_id);
  }
  // provision_prices: crea (o riallinea) prodotti e prezzi Stripe dai prezzi del database
  const plans = await deps.store.rpc<ProvisionPlan[]>('billing_plans_for_provisioning', {});
  const out: Record<string, { product: string; monthly: string | null; yearly: string | null }> = {};
  try {
    for (const plan of plans) {
      let product = plan.stripe_product_id;
      if (product) {
        try {
          const p = await deps.stripe.products.retrieve(product);
          if (!p.active) product = null;
        } catch {
          product = null;
        }
      }
      if (!product) {
        const created = await deps.stripe.products.create(
          { name: `AsiaFood ${plan.name}`, description: plan.description ?? undefined, metadata: { plan_code: plan.code } },
          { idempotencyKey: `asiafood-product-${plan.code}-${deps.config.env}` },
        );
        product = created.id;
      }
      const monthly = await ensurePrice(deps, plan, product, 'month', plan.monthly_price, plan.stripe_monthly_price_id);
      const yearly = await ensurePrice(deps, plan, product, 'year', plan.yearly_price, plan.stripe_yearly_price_id);
      await deps.store.rpc('billing_set_plan_stripe_ids', { p_plan: plan.code, p_product: product, p_monthly: monthly, p_yearly: yearly });
      out[plan.code] = { product, monthly, yearly };
    }
  } catch (e) {
    throw fromStripeError(e, 'INTERNAL');
  }
  return { environment: deps.config.env, plans: out };
});

// ═════════════════════════════════════════════════════════════
//  Cron orario: scadenze (tolleranza, fine periodo, piani manuali) e avvisi fine prova
// ═════════════════════════════════════════════════════════════
export async function billingCron(deps: Pick<BillingDeps, 'store' | 'log'>) {
  const changed = await deps.store.rpc<number>('billing_refresh_plans', {});
  const expiring = await deps.store.rpc<number>('billing_trial_expiring', { p_stripe_sub: null });
  deps.log('info', 'billing cron', { changed, expiring });
  return { changed, expiring };
}
