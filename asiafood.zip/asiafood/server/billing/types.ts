import type Stripe from 'stripe';

export type StripeEnvironment = 'test' | 'live';

/** Configurazione server-side (mai esposta al browser). */
export interface BillingConfig {
  /** Ambiente dedotto dalla chiave segreta (sk_test_ / sk_live_), verificato contro STRIPE_MODE se presente. */
  env: StripeEnvironment;
  /** URL pubblico del sito, per success/cancel/return URL (APP_URL). */
  appUrl: string;
  webhookSecret: string | null;
  /** Segreto dell'endpoint Connect (eventi degli account collegati), facoltativo. */
  connectWebhookSecret?: string | null;
  /** STRIPE_TAX_ENABLED=true → automatic_tax + raccolta indirizzo e P.IVA nel checkout. */
  taxEnabled: boolean;
  /** Configurazione Customer Portal (facoltativa: altrimenti quella predefinita di Stripe). */
  portalConfigurationId: string | null;
  /** STRIPE_ALLOW_PROMOTION_CODES=true → campo "codice promozionale" di Stripe nel checkout. */
  allowPromotionCodes: boolean;
}

/** Accesso al database: solo RPC server-side (service role), nessuna query libera. */
export interface Store {
  rpc<T = unknown>(fn: string, args: Record<string, unknown>): Promise<T>;
}

export type Logger = (level: 'info' | 'warn' | 'error', message: string, data?: Record<string, unknown>) => void;

export interface BillingDeps {
  stripe: Stripe;
  store: Store;
  config: BillingConfig;
  /** Verifica il JWT Supabase e restituisce l'ID utente (null se non valido). */
  verifyUser: (token: string | null) => Promise<string | null>;
  log: Logger;
  now?: () => number;
}

/** Richiesta HTTP minimale (indipendente dal runtime: Netlify, test, altro). */
export interface HttpRequest {
  method: string;
  header: (name: string) => string | null;
  /** Corpo grezzo: necessario per verificare la firma dei webhook. */
  body: string;
}

export interface HttpResponse {
  status: number;
  body: unknown;
}

export type Handler = (req: HttpRequest, deps: BillingDeps) => Promise<HttpResponse>;

export interface CheckoutContext {
  ok: boolean;
  error?: string;
  restaurant: { id: string; name: string; slug: string };
  plan: { code: string; name: string; price_id: string; interval: 'month' | 'year'; amount: number };
  trial_days: number;
  require_payment_method: boolean;
  account: {
    id: string;
    stripe_customer_id: string | null;
    email: string | null;
    business_name: string | null;
    vat_number: string | null;
    tax_code: string | null;
    pec: string | null;
    recipient_code: string | null;
    address_line: string | null;
    postal_code: string | null;
    city: string | null;
    province: string | null;
    country: string;
  };
  promotion: null | {
    id: string;
    code: string;
    discount_type: 'percent' | 'amount' | 'free_days';
    discount_value: number | null;
    duration: 'once' | 'repeating' | 'forever';
    duration_in_months: number | null;
    free_days: number | null;
    stripe_coupon_id: string | null;
  };
}

export interface ManagedSubscription {
  id: string;
  stripe_subscription_id: string;
  stripe_schedule_id: string | null;
  status: string;
  plan_code: string;
  plan_order: number;
  billing_interval: 'month' | 'year';
  stripe_price_id: string | null;
  current_period_end: string | null;
  cancel_at_period_end: boolean;
  trial_end: string | null;
  scheduled_plan_code: string | null;
  scheduled_interval: string | null;
}

export interface ManageContext {
  ok: boolean;
  error?: string;
  customer_id: string | null;
  account_id: string | null;
  subscription: ManagedSubscription | null;
}

export interface ChangeContext extends ManageContext {
  kind: 'upgrade' | 'downgrade' | 'interval_up' | 'interval_down';
  immediate: boolean;
  proration_behavior: 'always_invoice' | 'create_prorations' | 'none';
  target: { plan_code: string; plan_name: string; interval: 'month' | 'year'; price_id: string; amount: number };
}
