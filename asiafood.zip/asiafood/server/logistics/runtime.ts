// ─────────────────────────────────────────────────────────────
//  Runtime di produzione della logistica (Netlify Functions).
//  Segreti letti SOLO qui: SUPABASE_SERVICE_ROLE_KEY (via billing runtime),
//  MAPBOX_DIRECTIONS_TOKEN (facoltativo, per l'ETA con percorsi reali).
// ─────────────────────────────────────────────────────────────
import { productionDeps, log } from '../billing/runtime';
import type { HttpRequest } from '../billing/types';
import type { LatLngPoint, LogisticsDeps, LogisticsHandler } from './handlers';

const env = (k: string) => (process.env[k] ?? '').trim();
let cached: LogisticsDeps | null = null;

async function mapboxMinutes(token: string, from: LatLngPoint, to: LatLngPoint, vehicle: string): Promise<number | null> {
  const profile = vehicle === 'bike' || vehicle === 'e-bike' ? 'cycling' : 'driving';
  const url = `https://api.mapbox.com/directions/v5/mapbox/${profile}/${from.lng},${from.lat};${to.lng},${to.lat}?overview=false&access_token=${encodeURIComponent(token)}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
  if (!res.ok) return null;
  const data = (await res.json()) as { routes?: { duration: number }[] };
  const d = data.routes?.[0]?.duration;
  return typeof d === 'number' ? d / 60 : null;
}

export function logisticsDeps(): LogisticsDeps {
  if (cached) return cached;
  const base = productionDeps();
  const token = env('MAPBOX_DIRECTIONS_TOKEN');
  cached = { store: base.store, verifyUser: base.verifyUser, log, routing: token ? (a, b, v) => mapboxMinutes(token, a, b, v) : undefined };
  return cached;
}

const HEADERS = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };

export function netlifyLogisticsHandler(handler: LogisticsHandler) {
  return async (request: Request): Promise<Response> => {
    let deps: LogisticsDeps;
    try {
      deps = logisticsDeps();
    } catch (e) {
      log('error', 'logistics not configured', { error: String(e) });
      return new Response(JSON.stringify({ error: 'NOT_CONFIGURED', message: 'Servizio non disponibile.' }), { status: 503, headers: HEADERS });
    }
    const req: HttpRequest = { method: request.method, header: (n) => request.headers.get(n), body: request.method === 'GET' ? '' : await request.text() };
    const res = await handler(req, deps);
    return new Response(JSON.stringify(res.body), { status: res.status, headers: HEADERS });
  };
}
