// ─────────────────────────────────────────────────────────────
//  Fase 9 · Logistica: endpoint server (indipendenti dal runtime).
//  Tutta la logica di dispatch, stati, compensi e privacy vive nel
//  database (funzioni security definer). Qui:
//   - ETA con provider di percorsi (facoltativo, lato server: il token
//     non arriva mai al browser) — solo su eventi, mai a ogni GPS;
//   - scheduler (offerte scadute, dispatch, avvisi, retention).
// ─────────────────────────────────────────────────────────────
import type { HttpRequest, HttpResponse, Logger, Store } from '../billing/types';

export interface LatLngPoint { lat: number; lng: number }
export type RoutingFn = (from: LatLngPoint, to: LatLngPoint, vehicle: string) => Promise<number | null>;

export interface LogisticsDeps {
  store: Store;
  verifyUser: (token: string | null) => Promise<string | null>;
  log: Logger;
  /** Minuti di percorso (provider esterno). Assente = stima del database. */
  routing?: RoutingFn;
  now?: () => number;
}
export type LogisticsHandler = (req: HttpRequest, deps: LogisticsDeps) => Promise<HttpResponse>;

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const json = (status: number, body: unknown): HttpResponse => ({ status, body });

interface EtaContext {
  status: string;
  vehicle_type: string | null;
  rider: LatLngPoint | null;
  pickup: LatLngPoint;
  dropoff: LatLngPoint;
}

/** Ricalcola l'ETA con il provider di percorsi, se configurato. Ritorna la fonte usata. */
export async function refreshEta(deps: LogisticsDeps, jobId: string): Promise<'routing' | 'estimate' | 'skipped'> {
  if (!deps.routing) return 'estimate';
  const ctx = await deps.store.rpc<EtaContext | null>('lg_eta_context', { p_job: jobId });
  if (!ctx || ctx.pickup.lat == null || ctx.dropoff.lat == null) return 'skipped';
  const vehicle = ctx.vehicle_type ?? 'scooter';
  try {
    let toPickup: number | null = null;
    let toCustomer: number | null;
    if (['assigned', 'rider_to_restaurant'].includes(ctx.status)) {
      toPickup = ctx.rider ? await deps.routing(ctx.rider, ctx.pickup, vehicle) : null;
      toCustomer = await deps.routing(ctx.pickup, ctx.dropoff, vehicle);
    } else if (ctx.status === 'arrived_restaurant' || ['waiting_assignment', 'offered'].includes(ctx.status)) {
      toCustomer = await deps.routing(ctx.pickup, ctx.dropoff, vehicle);
    } else {
      toCustomer = ctx.rider ? await deps.routing(ctx.rider, ctx.dropoff, vehicle) : null;
    }
    if (toCustomer == null) return 'estimate';
    await deps.store.rpc('lg_eta_apply', { p_job: jobId, p_to_pickup_minutes: toPickup == null ? null : Math.round(toPickup), p_to_customer_minutes: Math.round(toCustomer) });
    return 'routing';
  } catch (e) {
    // Il provider non raggiungibile non blocca nulla: resta la stima del database
    deps.log('warn', 'routing unavailable', { error: e instanceof Error ? e.message : String(e) });
    return 'estimate';
  }
}

/** POST /api/logistics/action — { action: 'eta_refresh', job_id } (Rider assegnato o Admin). */
export const logisticsAction: LogisticsHandler = async (req, deps) => {
  if (req.method !== 'POST') return json(405, { error: 'METHOD_NOT_ALLOWED', message: 'Metodo non consentito.' });
  let body: Record<string, unknown>;
  try {
    const parsed = JSON.parse(req.body || '{}');
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('shape');
    body = parsed as Record<string, unknown>;
  } catch {
    return json(400, { error: 'BAD_REQUEST', message: 'Richiesta non valida.' });
  }
  const auth = req.header('authorization');
  const user = await deps.verifyUser(auth?.startsWith('Bearer ') ? auth.slice(7) : null);
  if (!user) return json(401, { error: 'UNAUTHORIZED', message: 'Accedi per continuare.' });
  const jobId = String(body.job_id ?? '');
  if (body.action !== 'eta_refresh' || !UUID.test(jobId)) return json(400, { error: 'BAD_REQUEST', message: 'Richiesta non valida.' });
  try {
    const allowed = await deps.store.rpc<boolean>('lg_can_refresh', { p_job: jobId, p_user: user });
    if (!allowed) return json(403, { error: 'FORBIDDEN', message: 'Non autorizzato.' });
    return json(200, { ok: true, source: await refreshEta(deps, jobId) });
  } catch (e) {
    deps.log('error', 'logistics action failed', { error: e instanceof Error ? e.message : String(e) });
    return json(500, { error: 'INTERNAL', message: 'Operazione non riuscita. Riprova tra poco.' });
  }
};

/** Scheduler (ogni minuto). */
export async function logisticsCron(deps: LogisticsDeps) {
  return deps.store.rpc<Record<string, number>>('logistics_tick', { p_now: new Date(deps.now?.() ?? Date.now()).toISOString() });
}
