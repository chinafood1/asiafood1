import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { AuthProvider } from '@/context/AuthContext';
import { FavoritesProvider } from '@/context/FavoritesContext';
import { ReferenceDataProvider } from '@/context/ReferenceDataContext';
import { UpgradeProvider } from '@/context/UpgradeContext';
import { CartProvider } from '@/context/CartContext';
import { ToastProvider } from '@/components/ui/Toast';
import { RuntimeConfigProvider } from '@/context/RuntimeConfigContext';
import { initMonitoring } from '@/lib/monitoring';
import { captureLanding } from '@/lib/attribution';
// Font self-hosted (nessuna richiesta a Google Fonts: niente IP degli utenti a terzi, CSP più stretta)
import '@fontsource-variable/inter/wght.css';
import '@fontsource-variable/bricolage-grotesque/opsz.css';
import './index.css';

initMonitoring();
// Fase 12: canale di arrivo (una visita per sessione, senza identificativi)
captureLanding();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <RuntimeConfigProvider>
          <ReferenceDataProvider>
            <UpgradeProvider>
              <FavoritesProvider>
                <CartProvider>
                  <App />
                </CartProvider>
              </FavoritesProvider>
            </UpgradeProvider>
          </ReferenceDataProvider>
          </RuntimeConfigProvider>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  </StrictMode>,
);
