import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { ShoppingBag } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/services';
import { Button } from '@/components/ui/Button';
import { Sheet } from '@/components/ui/Sheet';
import type { Cart, CartLine, QuoteInput } from '@/types/orders';
import { lineTotal, sumMoney } from '@shared/money';

// ─────────────────────────────────────────────────────────────
//  Carrello: UN CARRELLO = UN RISTORANTE.
//  Persistenza locale (ospite) + sincronizzazione per gli utenti
//  registrati. I prezzi qui sono solo indicativi: il server li
//  ricalcola sempre (carrello, checkout, creazione ordine).
// ─────────────────────────────────────────────────────────────
const KEY = 'af_cart_v1';
/** Dopo questo tempo i prezzi salvati vanno riverificati prima di mostrarli come attuali. */
export const CART_REVALIDATE_MS = 12 * 3600_000;
/** Un carrello locale più vecchio di così viene scartato (niente prezzi vecchi di giorni). */
const CART_MAX_AGE_MS = 7 * 24 * 3600_000;

type AddInput = Omit<CartLine, 'key'>;
interface Restaurantish {
  id: string;
  name: string;
  slug: string;
}

interface CartApi {
  cart: Cart | null;
  count: number;
  /** Totale indicativo (prezzi al momento dell'aggiunta). */
  estimate: number;
  add(r: Restaurantish, line: AddInput): 'added' | 'conflict';
  setQuantity(key: string, qty: number): void;
  remove(key: string): void;
  clear(): void;
  /** Aggiorna i prezzi con quelli ricalcolati dal server. */
  applyServerPrices(prices: { key: string; unit_price: number }[]): void;
  /** Sostituisce il carrello (es. "Ordina di nuovo"). */
  replace(cart: Cart): void;
  toQuoteItems(): QuoteInput['items'];
}

const Ctx = createContext<CartApi | null>(null);

export const lineKey = (l: Pick<CartLine, 'menu_item_id' | 'variant_id' | 'addons' | 'options' | 'notes'>) =>
  [l.menu_item_id, l.variant_id ?? '', l.addons.map((a) => `${a.id}x${a.quantity}`).sort().join('+'), l.options.map((o) => o.id).sort().join('+'), (l.notes ?? '').trim().toLowerCase()].join('|');

function read(): Cart | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const c = JSON.parse(raw) as Cart;
    if (!c?.restaurant_id || !Array.isArray(c.lines) || Date.now() - Date.parse(c.updated_at) > CART_MAX_AGE_MS) return null;
    return c;
  } catch {
    return null;
  }
}
function write(c: Cart | null) {
  try {
    if (c && c.lines.length) localStorage.setItem(KEY, JSON.stringify(c));
    else localStorage.removeItem(KEY);
  } catch {
    /* storage non disponibile: si resta in memoria */
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [cart, setCart] = useState<Cart | null>(() => read());
  const [conflict, setConflict] = useState<{ r: Restaurantish; line: AddInput } | null>(null);
  const syncTimer = useRef<number | null>(null);
  const loadedFor = useRef<string | null>(null);

  const commit = useCallback((next: Cart | null) => {
    const c = next && next.lines.length ? next : null;
    setCart(c);
    write(c);
    if (user) {
      if (syncTimer.current) window.clearTimeout(syncTimer.current);
      syncTimer.current = window.setTimeout(() => {
        void api.saveCart(c ? { restaurant_id: c.restaurant_id, items: c.lines.map((l) => ({ menu_item_id: l.menu_item_id, variant_id: l.variant_id, options: l.options.map((o) => o.id), addons: l.addons.map((a) => ({ id: a.id, quantity: a.quantity })), quantity: l.quantity, notes: l.notes, unit_price: l.unit_price })) } : null);
      }, 800);
    }
  }, [user]);

  // Stesso carrello in più schede
  useEffect(() => {
    const on = (e: StorageEvent) => e.key === KEY && setCart(read());
    window.addEventListener('storage', on);
    return () => window.removeEventListener('storage', on);
  }, []);

  // Utente registrato: se il carrello locale è vuoto recupera quello salvato (altro dispositivo)
  useEffect(() => {
    if (!user || loadedFor.current === user.id) return;
    loadedFor.current = user.id;
    if (read()) return;
    void api.loadCart().then(async (saved) => {
      if (!saved || !Array.isArray(saved.items) || !saved.items.length || read()) return;
      // Ricostruzione con i dati attuali del menu (nomi, extra, scelte): i prezzi li verifica il server al carrello
      const { rebuildCart } = await import('@/lib/reorder');
      const c = await rebuildCart(saved.restaurant_id, saved.items as never).catch(() => null);
      if (c && c.cart.lines.length) {
        setCart(c.cart);
        write(c.cart);
      }
    }, () => undefined);
  }, [user]);

  const add = useCallback<CartApi['add']>((r, line) => {
    const cur = read() ?? cart;
    if (cur && cur.restaurant_id !== r.id && cur.lines.length) {
      setConflict({ r, line });
      return 'conflict';
    }
    const key = lineKey(line);
    const base: Cart = cur && cur.restaurant_id === r.id ? cur : { restaurant_id: r.id, restaurant_name: r.name, restaurant_slug: r.slug, lines: [], updated_at: new Date().toISOString(), validated_at: null };
    const existing = base.lines.find((l) => l.key === key);
    const lines = existing
      ? base.lines.map((l) => (l.key === key ? { ...l, quantity: Math.min(20, l.quantity + line.quantity) } : l))
      : [...base.lines, { ...line, key }];
    commit({ ...base, lines, updated_at: new Date().toISOString() });
    void api.track(r.id, 'add_to_cart', 'web', { item: line.menu_item_id });
    return 'added';
  }, [cart, commit]);

  const value = useMemo<CartApi>(() => ({
    cart,
    count: cart?.lines.reduce((s, l) => s + l.quantity, 0) ?? 0,
    estimate: sumMoney((cart?.lines ?? []).map((l) => lineTotal(l.unit_price, l.quantity))),
    add,
    setQuantity(key, qty) {
      if (!cart) return;
      const lines = qty <= 0 ? cart.lines.filter((l) => l.key !== key) : cart.lines.map((l) => (l.key === key ? { ...l, quantity: Math.min(20, qty) } : l));
      if (qty <= 0) void api.track(cart.restaurant_id, 'remove_from_cart', 'web');
      commit({ ...cart, lines, updated_at: new Date().toISOString() });
    },
    remove(key) {
      if (!cart) return;
      void api.track(cart.restaurant_id, 'remove_from_cart', 'web');
      commit({ ...cart, lines: cart.lines.filter((l) => l.key !== key), updated_at: new Date().toISOString() });
    },
    clear() {
      commit(null);
    },
    applyServerPrices(prices) {
      if (!cart) return;
      const lines = cart.lines.map((l) => {
        const p = prices.find((x) => x.key === l.key);
        return p ? { ...l, unit_price: p.unit_price } : l;
      });
      const next = { ...cart, lines, validated_at: new Date().toISOString() };
      setCart(next);
      write(next);
    },
    replace(c) {
      commit(c);
    },
    toQuoteItems() {
      return (cart?.lines ?? []).map((l) => ({
        menu_item_id: l.menu_item_id, variant_id: l.variant_id, addons: l.addons.map((a) => ({ id: a.id, quantity: a.quantity })), options: l.options.map((o) => o.id),
        quantity: l.quantity, notes: l.notes,
      }));
    },
  }), [cart, add, commit]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <Sheet open={!!conflict} onClose={() => setConflict(null)} title="Carrello di un altro ristorante">
        <div className="space-y-4">
          <p className="flex items-start gap-3">
            <ShoppingBag className="mt-0.5 h-5 w-5 shrink-0 text-coral" />
            <span>
              <strong>Hai già prodotti di un altro ristorante nel carrello.</strong>
              <span className="block text-sm text-ink-muted">
                Un ordine può contenere piatti di un solo ristorante ({cart?.restaurant_name}). Vuoi svuotarlo e continuare con {conflict?.r.name}?
              </span>
            </span>
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            <Button variant="outline" onClick={() => setConflict(null)}>Mantieni carrello</Button>
            <Button
              onClick={() => {
                const c = conflict!;
                setConflict(null);
                const line = { ...c.line, key: lineKey(c.line) };
                commit({ restaurant_id: c.r.id, restaurant_name: c.r.name, restaurant_slug: c.r.slug, lines: [line], updated_at: new Date().toISOString(), validated_at: null });
                void api.track(c.r.id, 'add_to_cart', 'web', { item: c.line.menu_item_id });
              }}
            >
              Svuota e continua
            </Button>
          </div>
        </div>
      </Sheet>
    </Ctx.Provider>
  );
}

export function useCart() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useCart fuori da CartProvider');
  return v;
}
