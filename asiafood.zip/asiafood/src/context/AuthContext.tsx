import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { APP } from '@/config/app';
import { DEMO_USERS, getDemoProfile, upsertDemoProfile } from '@/services/demoSource';
import { isDemoMode } from '@/services';
import type { Profile, UserRole } from '@/types/domain';

interface AuthUser {
  id: string;
  email: string | null;
}

interface AuthContextValue {
  user: AuthUser | null;
  profile: Profile | null;
  role: UserRole | null;
  loading: boolean;
  isAdmin: boolean;
  isOwner: boolean;
  signIn(email: string, password: string): Promise<void>;
  signUp(fullName: string, email: string, password: string, redirectPath?: string): Promise<{ needsConfirmation: boolean }>;
  signOut(): Promise<void>;
  sendPasswordReset(email: string): Promise<void>;
  updatePassword(password: string): Promise<void>;
  signInWithMagicLink(email: string): Promise<void>;
  demoSignIn(role: UserRole): void;
  refreshProfile(): Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);
const DEMO_SESSION_KEY = 'asiafood-demo-session';

const translateAuthError = (msg: string) => {
  if (/invalid login credentials/i.test(msg)) return 'Email o password non corretti.';
  if (/email not confirmed/i.test(msg)) return 'Conferma prima il tuo indirizzo email.';
  if (/already registered/i.test(msg)) return 'Esiste già un account con questa email.';
  if (/password should be at least/i.test(msg)) return 'La password deve contenere almeno 8 caratteri.';
  if (/rate limit/i.test(msg)) return 'Troppi tentativi, riprova tra qualche minuto.';
  return msg;
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (u: AuthUser | null) => {
    if (!u) return setProfile(null);
    if (isDemoMode) return setProfile(getDemoProfile(u.id) ?? null);
    const { data } = await supabase!.from('profiles').select('*').eq('id', u.id).maybeSingle();
    setProfile((data as Profile) ?? null);
  }, []);

  // Fase 12: attribuzione dell'iscrizione al canale di arrivo (solo account nuovi e solo con consenso "Statistiche")
  useEffect(() => {
    if (!profile?.id || !profile.created_at || Date.now() - Date.parse(profile.created_at) > 7 * 86_400_000) return;
    void import('@/lib/attribution').then((m) => m.attributeSignup(profile.id));
  }, [profile?.id, profile?.created_at]);

  useEffect(() => {
    if (isDemoMode) {
      let id: string | null = null;
      try {
        id = localStorage.getItem(DEMO_SESSION_KEY);
      } catch {
        /* noop */
      }
      const p = id ? getDemoProfile(id) : undefined;
      setUser(p ? { id: p.id, email: p.email } : null);
      setProfile(p ?? null);
      setLoading(false);
      return;
    }
    let active = true;
    supabase!.auth.getSession().then(async ({ data }) => {
      const u = data.session?.user ? { id: data.session.user.id, email: data.session.user.email ?? null } : null;
      if (!active) return;
      setUser(u);
      await loadProfile(u);
      setLoading(false);
    });
    const { data: sub } = supabase!.auth.onAuthStateChange((_event, session) => {
      const u = session?.user ? { id: session.user.id, email: session.user.email ?? null } : null;
      setUser(u);
      // evita deadlock: la query profilo va fuori dal callback
      setTimeout(() => loadProfile(u), 0);
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const value = useMemo<AuthContextValue>(() => {
    const role = profile?.role ?? null;
    return {
      user,
      profile,
      role,
      loading,
      isAdmin: role === 'admin',
      isOwner: role === 'restaurant_owner' || role === 'admin',

      async signIn(email, password) {
        if (isDemoMode) throw new Error('In modalità demo usa i pulsanti "Accedi come…".');
        const { error } = await supabase!.auth.signInWithPassword({ email, password });
        if (error) throw new Error(translateAuthError(error.message));
      },

      async signUp(fullName, email, password, redirectPath = '/profilo') {
        if (isDemoMode) {
          const id = crypto.randomUUID();
          upsertDemoProfile({ id, role: 'customer', full_name: fullName, email, phone: null, avatar_url: null, city_id: null, is_blocked: false, created_at: new Date().toISOString() });
          localStorage.setItem(DEMO_SESSION_KEY, id);
          setUser({ id, email });
          setProfile(getDemoProfile(id) ?? null);
          return { needsConfirmation: false };
        }
        const { data, error } = await supabase!.auth.signUp({
          email,
          password,
          options: { data: { full_name: fullName }, emailRedirectTo: `${APP.siteUrl}${redirectPath}` },
        });
        if (error) throw new Error(translateAuthError(error.message));
        return { needsConfirmation: !data.session };
      },

      async signOut() {
        if (isDemoMode) {
          localStorage.removeItem(DEMO_SESSION_KEY);
          setUser(null);
          setProfile(null);
          return;
        }
        await supabase!.auth.signOut();
      },

      async sendPasswordReset(email) {
        if (isDemoMode) return;
        const { error } = await supabase!.auth.resetPasswordForEmail(email, { redirectTo: `${APP.siteUrl}/reimposta-password` });
        if (error) throw new Error(translateAuthError(error.message));
      },

      async updatePassword(password) {
        if (isDemoMode) return;
        const { error } = await supabase!.auth.updateUser({ password });
        if (error) throw new Error(translateAuthError(error.message));
      },

      async signInWithMagicLink(email) {
        if (isDemoMode) throw new Error('Non disponibile in modalità demo.');
        const { error } = await supabase!.auth.signInWithOtp({ email, options: { emailRedirectTo: `${APP.siteUrl}/profilo` } });
        if (error) throw new Error(translateAuthError(error.message));
      },

      demoSignIn(r) {
        const id = r === 'admin' ? DEMO_USERS.admin : r === 'restaurant_owner' ? DEMO_USERS.owner : r === 'rider' ? DEMO_USERS.rider : DEMO_USERS.customer;
        localStorage.setItem(DEMO_SESSION_KEY, id);
        const p = getDemoProfile(id);
        setUser({ id, email: p?.email ?? null });
        setProfile(p ?? null);
      },

      async refreshProfile() {
        await loadProfile(user);
      },
    };
  }, [user, profile, loading, loadProfile]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve essere usato dentro AuthProvider');
  return ctx;
}
