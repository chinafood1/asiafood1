import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Lock, Sparkles } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import {
  FEATURES,
  getFeatureLimit,
  hasFeature,
  isPlanError,
  requiredPlanFor,
  withinLimit,
  type FeatureKey,
} from '@/lib/entitlements';
import type { PlanCode } from '@/types/domain';
import { Button } from '@/components/ui/Button';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';

/**
 * Entitlement per un piano: unico accesso della UI alle regole di piano.
 * L'Admin non è soggetto ai limiti (come nel DB), ma vede quali funzioni ha il locale.
 */
export function useEntitlements(plan: PlanCode | string | null | undefined) {
  const { plans } = useReferenceData();
  const { isAdmin } = useAuth();
  return useMemo(
    () => ({
      plan,
      bypass: isAdmin,
      /** Incluso nel piano del locale (per l'Admin: sempre utilizzabile). */
      can: (key: FeatureKey) => isAdmin || hasFeature(plans, plan, key),
      /** Incluso nel piano, senza eccezione Admin (per mostrare cosa vede il pubblico). */
      has: (key: FeatureKey) => hasFeature(plans, plan, key),
      limit: (key: FeatureKey) => getFeatureLimit(plans, plan, key),
      within: (key: FeatureKey, current: number) => isAdmin || withinLimit(plans, plan, key, current),
      required: (key: FeatureKey, minLimit?: number) => requiredPlanFor(plans, key, minLimit),
    }),
    [plans, plan, isAdmin],
  );
}

interface UpgradeState {
  feature: FeatureKey;
  kind: 'feature' | 'limit';
  restaurantId?: string;
  plan?: string | null;
}

interface UpgradeApi {
  openUpgrade(feature: FeatureKey, opts?: { restaurantId?: string; kind?: 'feature' | 'limit'; plan?: string | null }): void;
  /** Mostra la modale per gli errori di piano, altrimenti un toast. */
  handleError(e: unknown, restaurantId?: string, plan?: string | null): void;
}

const Ctx = createContext<UpgradeApi | null>(null);

export function UpgradeProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<UpgradeState | null>(null);
  const toast = useToast();
  const { plans } = useReferenceData();

  const openUpgrade = useCallback<UpgradeApi['openUpgrade']>((feature, opts = {}) => {
    setState({ feature, kind: opts.kind ?? 'feature', restaurantId: opts.restaurantId, plan: opts.plan });
  }, []);

  const handleError = useCallback<UpgradeApi['handleError']>(
    (e, restaurantId, plan) => {
      if (isPlanError(e)) return openUpgrade(e.feature, { restaurantId, kind: e.kind, plan });
      // Nessuno stack trace all'utente: solo il messaggio già leggibile
      const msg = e instanceof Error ? e.message : 'Qualcosa è andato storto. Riprova.';
      toast(/fetch|network|Failed to/i.test(msg) ? 'Connessione assente o instabile. Riprova tra poco.' : msg, 'error');
    },
    [openUpgrade, toast],
  );

  const info = state ? FEATURES[state.feature] : null;
  const current = state?.plan ? plans.find((p) => p.code === state.plan) : undefined;
  const minLimit = state?.kind === 'limit' && state.plan ? (getFeatureLimit(plans, state.plan, state.feature) ?? 0) + 1 : 1;
  const target = state ? requiredPlanFor(plans, state.feature, minLimit) : undefined;
  const link = `/dashboard/plans${state?.restaurantId ? `?restaurant=${state.restaurantId}` : ''}`;

  return (
    <Ctx.Provider value={{ openUpgrade, handleError }}>
      {children}
      <Sheet
        open={!!state}
        onClose={() => setState(null)}
        title={state?.kind === 'limit' ? 'Limite del piano raggiunto' : 'Funzione non inclusa nel piano'}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="ghost" onClick={() => setState(null)}>
              Non ora
            </Button>
            <Link
              to={link}
              onClick={() => setState(null)}
              className="inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-[15px] font-semibold text-white hover:bg-ink-soft"
            >
              <Sparkles className="h-4 w-4" /> Scopri i piani
            </Link>
          </div>
        }
      >
        {info && (
          <div className="flex gap-4">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-coral-50 text-coral-700">
              <Lock className="h-6 w-6" />
            </span>
            <div>
              <p className="text-lg font-bold">{info.label}</p>
              <p className="mt-1 text-[15px] text-ink-soft">
                {state?.kind === 'limit'
                  ? `Hai raggiunto il limite previsto dal piano${current ? ` ${current.name}` : ''}.`
                  : `Questa funzione è disponibile con il piano ${target?.name ?? 'superiore'}.`}
                {state?.kind === 'limit' && target && ` Con il piano ${target.name} il limite aumenta.`}
              </p>
              <p className="mt-2 text-sm text-ink-muted">{info.description}.</p>
            </div>
          </div>
        )}
      </Sheet>
    </Ctx.Provider>
  );
}

export function useUpgrade() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useUpgrade deve essere usato dentro UpgradeProvider');
  return ctx;
}

/** Blocco "funzione non inclusa" con invito all'upgrade al posto del contenuto. */
export function FeatureGate({
  plan,
  feature,
  restaurantId,
  children,
  title,
}: {
  plan: PlanCode | string;
  feature: FeatureKey;
  restaurantId?: string;
  children: ReactNode;
  title?: string;
}) {
  const ent = useEntitlements(plan);
  if (ent.can(feature)) {
    return (
      <>
        {ent.bypass && !ent.has(feature) && (
          <p className="mb-4 rounded-2xl bg-amber-50 px-4 py-2.5 text-sm text-amber-900">
            Vista Admin: “{FEATURES[feature].label}” non è incluso nel piano <strong className="uppercase">{plan}</strong>, il titolare vede l’invito all’upgrade.
          </p>
        )}
        {children}
      </>
    );
  }
  const target = ent.required(feature);
  return (
    <div className="flex flex-col items-center rounded-4xl border border-dashed border-line bg-white px-6 py-12 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-coral-50 text-coral-700">
        <Lock className="h-6 w-6" />
      </span>
      <h2 className="mt-4 text-xl font-bold">{title ?? FEATURES[feature].label}</h2>
      <p className="mt-1 max-w-md text-[15px] text-ink-muted">
        Questa funzione è disponibile con il piano {target?.name ?? 'superiore'}. {FEATURES[feature].description}.
      </p>
      <Link
        to={`/dashboard/plans${restaurantId ? `?restaurant=${restaurantId}` : ''}`}
        className="mt-5 inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-sm font-semibold text-white hover:bg-ink-soft"
      >
        <Sparkles className="h-4 w-4" /> Scopri i piani
      </Link>
    </div>
  );
}
