// Configurazione pubblica a runtime (manutenzione, beta, feature flag, dati legali): una chiamata all'avvio,
// ricaricata ogni 5 minuti e al ritorno sulla scheda. Valori prudenti se il backend non risponde.
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api } from '@/services';
import type { RuntimeConfig } from '@/types/platform';

const FALLBACK: RuntimeConfig = { settings: { maintenance_mode: false, beta_mode: true, consent_policy_version: '2026-10-01' }, legal: {} };

interface Ctx {
  config: RuntimeConfig;
  loaded: boolean;
  reload(): Promise<void>;
  setting<T = unknown>(key: string, fallback?: T): T;
}
const RuntimeConfigContext = createContext<Ctx | null>(null);

export function RuntimeConfigProvider({ children }: { children: ReactNode }) {
  const [config, setConfig] = useState<RuntimeConfig>(FALLBACK);
  const [loaded, setLoaded] = useState(false);
  const reload = useCallback(async () => {
    try {
      const c = await api.getRuntimeConfig();
      setConfig({ settings: { ...FALLBACK.settings, ...c.settings }, legal: c.legal ?? {}, server_time: c.server_time });
    } catch {
      /* backend non raggiungibile: si resta sui valori prudenti */
    } finally {
      setLoaded(true);
    }
  }, []);
  useEffect(() => {
    void reload();
    const id = window.setInterval(() => void reload(), 5 * 60_000);
    const onVis = () => document.visibilityState === 'visible' && void reload();
    document.addEventListener('visibilitychange', onVis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [reload]);
  const value = useMemo<Ctx>(() => ({
    config, loaded, reload,
    setting: <T,>(key: string, fallback?: T) => ((config.settings[key] ?? fallback) as T),
  }), [config, loaded, reload]);
  return <RuntimeConfigContext.Provider value={value}>{children}</RuntimeConfigContext.Provider>;
}

export function useRuntimeConfig(): Ctx {
  const c = useContext(RuntimeConfigContext);
  if (!c) return { config: FALLBACK, loaded: false, reload: async () => undefined, setting: <T,>(_k: string, f?: T) => f as T };
  return c;
}
