import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { api } from '@/services';
import { useAuth } from './AuthContext';

interface FavoritesValue {
  ids: Set<string>;
  isFavorite(id: string): boolean;
  toggle(id: string): Promise<void>;
}

const FavoritesContext = createContext<FavoritesValue | null>(null);

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [ids, setIds] = useState<Set<string>>(new Set());
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!user) return setIds(new Set());
    api.getFavoriteIds(user.id).then((list) => setIds(new Set(list)), () => setIds(new Set()));
  }, [user]);

  const toggle = useCallback(
    async (id: string) => {
      if (!user) {
        navigate(`/accedi?next=${encodeURIComponent(location.pathname + location.search)}&motivo=preferiti`);
        return;
      }
      const on = !ids.has(id);
      // aggiornamento ottimistico
      setIds((prev) => {
        const next = new Set(prev);
        if (on) next.add(id);
        else next.delete(id);
        return next;
      });
      try {
        await api.setFavorite(user.id, id, on);
        // Fase 13: intenzione nel funnel (nessun dato personale; sessione solo con consenso)
        if (on) api.trackAppEvent('favorite_added', { restaurantId: id, source: 'web' });
      } catch {
        setIds((prev) => {
          const next = new Set(prev);
          if (on) next.delete(id);
          else next.add(id);
          return next;
        });
      }
    },
    [user, ids, navigate, location],
  );

  return (
    <FavoritesContext.Provider value={{ ids, isFavorite: (id) => ids.has(id), toggle }}>{children}</FavoritesContext.Provider>
  );
}

export function useFavorites() {
  const ctx = useContext(FavoritesContext);
  if (!ctx) throw new Error('useFavorites deve essere usato dentro FavoritesProvider');
  return ctx;
}
