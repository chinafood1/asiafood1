import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api } from '@/services';
import type { Category, City, PlanWithFeatures } from '@/types/domain';

interface RefData {
  categories: Category[];
  cities: City[];
  /** Piani con feature (tutti; il pubblico usa solo quelli attivi). */
  plans: PlanWithFeatures[];
  ready: boolean;
  categoryBySlug(slug?: string): Category | undefined;
  cityBySlug(slug?: string): City | undefined;
  reloadPlans(): Promise<void>;
}

const Ctx = createContext<RefData | null>(null);

/** Categorie, comuni e piani caricati una volta e condivisi da tutta l'app. */
export function ReferenceDataProvider({ children }: { children: ReactNode }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [plans, setPlans] = useState<PlanWithFeatures[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    Promise.all([api.getCategories(), api.getCities(), api.getPlans().catch(() => [] as PlanWithFeatures[])])
      .then(([cats, cts, pls]) => {
        setCategories(cats);
        setCities(cts);
        setPlans(pls);
      })
      .finally(() => setReady(true));
  }, []);

  const reloadPlans = useCallback(async () => {
    setPlans(await api.getPlans());
  }, []);

  return (
    <Ctx.Provider
      value={{
        categories,
        cities,
        plans,
        ready,
        categoryBySlug: (s) => categories.find((c) => c.slug === s),
        cityBySlug: (s) => cities.find((c) => c.slug === s),
        reloadPlans,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useReferenceData() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useReferenceData deve essere usato dentro ReferenceDataProvider');
  return ctx;
}
