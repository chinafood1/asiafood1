import { useEffect, useState } from 'react';
import { api } from '@/services';
import type { OrderableRestaurant } from '@/types/orders';

export type OrderMode = 'now' | 'takeaway' | 'delivery';

// Cache condivisa (1 richiesta per pagina, rinnovata dopo 2 minuti): i badge delle card non moltiplicano le chiamate.
let cache: { at: number; p: Promise<Map<string, OrderableRestaurant>> } | null = null;
export function loadOrderable(): Promise<Map<string, OrderableRestaurant>> {
  if (!cache || Date.now() - cache.at > 120_000) {
    const p = api.getOrderableRestaurants()
      .then((rows) => new Map(rows.map((r) => [r.restaurant_id, r])))
      .catch(() => new Map<string, OrderableRestaurant>());
    cache = { at: Date.now(), p };
  }
  return cache.p;
}

/** Ristoranti che accettano ordini online (takeaway/delivery, ordinabili adesso). */
export function useOrderable() {
  const [map, setMap] = useState<Map<string, OrderableRestaurant> | null>(null);
  useEffect(() => {
    let alive = true;
    void loadOrderable().then((m) => alive && setMap(m));
    return () => { alive = false; };
  }, []);
  return map;
}

export function matchesOrderMode(o: OrderableRestaurant | undefined, mode: OrderMode): boolean {
  if (!o || !o.payments_ready) return false;
  if (mode === 'now') return o.order_now;
  return mode === 'delivery' ? o.delivery : o.takeaway;
}

export const ORDER_MODE_LABEL: Record<OrderMode, string> = { now: 'Ordina ora', delivery: 'Delivery disponibile', takeaway: 'Takeaway disponibile' };
