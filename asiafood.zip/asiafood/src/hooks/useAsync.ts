import { useCallback, useEffect, useRef, useState } from 'react';

/** Esegue una funzione async e ne espone stato; si rilancia quando cambiano le deps. */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | undefined>(undefined);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);
  const seq = useRef(0);

  const run = useCallback(() => {
    const id = ++seq.current;
    setLoading(true);
    setError(null);
    fn().then(
      (v) => {
        if (id === seq.current) {
          setData(v);
          setLoading(false);
        }
      },
      (e: unknown) => {
        if (id === seq.current) {
          setError(e instanceof Error ? e : new Error(String(e)));
          setLoading(false);
        }
      },
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => {
    run();
  }, [run]);

  return { data, error, loading, reload: run, setData };
}
