import { useCallback, useState } from 'react';
import { DEFAULT_RADIUS_KM, RADIUS_OPTIONS } from '@/config/app';

const KEY = 'af_radius_km';

function read(): number {
  try {
    const v = Number(localStorage.getItem(KEY));
    return (RADIUS_OPTIONS as readonly number[]).includes(v) ? v : DEFAULT_RADIUS_KM;
  } catch {
    return DEFAULT_RADIUS_KM;
  }
}

/** Raggio "Vicino a me" preferito, ricordato solo in questo browser (default 10 km). */
export function useRadius() {
  const [radius, setRadiusState] = useState(read);
  const setRadius = useCallback((km: number) => {
    setRadiusState(km);
    try {
      localStorage.setItem(KEY, String(km));
    } catch {
      /* noop */
    }
  }, []);
  return [radius, setRadius] as const;
}
