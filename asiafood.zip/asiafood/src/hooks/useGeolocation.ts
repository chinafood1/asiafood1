import { useCallback, useSyncExternalStore } from 'react';
import { api } from '@/services';

export type GeoStatus = 'idle' | 'loading' | 'granted' | 'denied' | 'unavailable' | 'timeout' | 'unsupported';

export interface GeoState {
  coords: { lat: number; lng: number } | null;
  status: GeoStatus;
}

/**
 * Posizione dell'utente condivisa da tutta l'app (home, esplora, mappa).
 * Privacy: richiesta solo dopo un'azione esplicita, conservata solo per la
 * sessione del browser (sessionStorage), mai inviata o salvata nel database.
 */
const CACHE_KEY = 'af_geo';
const listeners = new Set<() => void>();

function readCache(): GeoState['coords'] {
  try {
    const raw = sessionStorage.getItem(CACHE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

let state: GeoState = (() => {
  const c = readCache();
  return { coords: c, status: c ? 'granted' : 'idle' };
})();

const set = (next: GeoState) => {
  state = next;
  listeners.forEach((l) => l());
};

export const GEO_MESSAGES: Record<Exclude<GeoStatus, 'idle' | 'loading' | 'granted'>, string> = {
  denied: 'Permesso di posizione negato. Puoi sempre cercare per comune.',
  unavailable: 'Posizione non disponibile al momento. Riprova tra poco o cerca per comune.',
  timeout: 'La posizione sta impiegando troppo tempo. Riprova o cerca per comune.',
  unsupported: 'Il tuo browser non supporta la geolocalizzazione. Cerca per comune.',
};

let pending: Promise<GeoState['coords']> | null = null;

/** Chiede la posizione (una richiesta alla volta). Risolve con le coordinate o null. */
export function requestPosition(source = 'app'): Promise<GeoState['coords']> {
  if (pending) return pending;
  if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
    set({ coords: null, status: 'unsupported' });
    return Promise.resolve(null);
  }
  set({ ...state, status: 'loading' });
  api.trackAppEvent('location_permission_requested', { source });
  pending = new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        // ~11 m di precisione bastano: niente coordinate più precise del necessario
        const coords = { lat: Math.round(pos.coords.latitude * 1e4) / 1e4, lng: Math.round(pos.coords.longitude * 1e4) / 1e4 };
        try {
          sessionStorage.setItem(CACHE_KEY, JSON.stringify(coords));
        } catch {
          /* noop */
        }
        set({ coords, status: 'granted' });
        api.trackAppEvent('location_permission_granted', { source });
        pending = null;
        resolve(coords);
      },
      (err) => {
        const status: GeoStatus = err.code === err.PERMISSION_DENIED ? 'denied' : err.code === err.TIMEOUT ? 'timeout' : 'unavailable';
        set({ coords: null, status });
        if (status === 'denied') api.trackAppEvent('location_permission_denied', { source });
        pending = null;
        resolve(null);
      },
      { enableHighAccuracy: false, timeout: 12000, maximumAge: 5 * 60 * 1000 },
    );
  });
  return pending;
}

export function clearPosition() {
  try {
    sessionStorage.removeItem(CACHE_KEY);
  } catch {
    /* noop */
  }
  set({ coords: null, status: 'idle' });
}

/** Stato condiviso + azione esplicita per richiedere la posizione (mai all'avvio). */
export function useGeolocation(source?: string) {
  const s = useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => state,
  );
  const request = useCallback(() => requestPosition(source), [source]);
  const message = s.status in GEO_MESSAGES ? GEO_MESSAGES[s.status as keyof typeof GEO_MESSAGES] : null;
  return { ...s, request, clear: clearPosition, message };
}
