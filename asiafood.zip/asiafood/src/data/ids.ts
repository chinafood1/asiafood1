// UUID deterministici per dati di riferimento e demo.
// Stessi ID nel seed SQL e nella modalità demo del frontend.
const PREFIX = {
  region: 'a0000000',
  province: 'b0000000',
  city: 'c0000000',
  category: 'd0000000',
  restaurant: 'e0000000',
  image: 'e1000000',
  hour: 'e2000000',
  menu: 'e3000000',
  menuCategory: 'e4000000',
  menuItem: 'e5000000',
  offer: 'f0000000',
  coupon: 'f1000000',
  sponsored: 'f2000000',
  plan: 'f3000000',
  planFeature: 'f4000000',
  variant: 'e6000000',
  addon: 'e7000000',
  slot: 'f5000000',
  closure: 'f6000000',
  reservation: 'f7000000',
  couponClaim: 'f8000000',
  subscription: 'f9000000',
  optionGroup: 'fa000000',
  menuOption: 'fb000000',
  deliveryZone: 'fc000000',
  orderSettings: 'fd000000',
} as const;

export type IdKind = keyof typeof PREFIX;

export function fixedId(kind: IdKind, n: number): string {
  return `${PREFIX[kind]}-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
}
