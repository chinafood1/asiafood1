// ─────────────────────────────────────────────────────────────
//  DATI DEMO — locali di fantasia, NON reali.
//  Ogni record ha is_demo = true e in UI mostra il badge "DEMO".
//  Nomi, indirizzi, telefoni e prezzi sono inventati a scopo
//  dimostrativo. Coordinate: centro del comune + piccolo offset.
// ─────────────────────────────────────────────────────────────
import type { DeliveryZone, MenuOptionGroup, RestaurantOrderSettings } from '../types/orders';
import type {
  Coupon,
  Menu,
  MenuCategory,
  MenuItem,
  MenuItemAddon,
  MenuItemVariant,
  Offer,
  PlanCode,
  Restaurant,
  RestaurantCategory,
  RestaurantHour,
  RestaurantImage,
  SponsoredCampaign,
  Subscription,
} from '@/types/domain';
import { fixedId } from './ids';
import { categories, cities } from './reference';

const img = (id: string, w = 1200) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=70`;

type Cuisine = 'sushi' | 'ramen' | 'chinese' | 'thai' | 'korean' | 'poke' | 'street' | 'fusion';

const IMAGE_POOL: Record<Cuisine, string[]> = {
  sushi: ['1579871494447-9811cf80d66c', '1553621042-f6e147245754', '1611143669185-af224c5e3252', '1617196034796-73dfa7b1fd56'],
  ramen: ['1569718212165-3a8278d5f624', '1557872943-16a5ac26437e', '1591814468924-caf88d1232e1', '1617093727343-374698b1b08d'],
  chinese: ['1525755662778-989d0524087e', '1563245372-f21724e3856d', '1512058564366-18510be2db19', '1496116218417-1a781b1c416c'],
  thai: ['1559314809-0d155014e29e', '1562565652-a0d8f0c59eb4', '1455619452474-d2be8b1e70cd', '1548943487-a2e4e43b4853'],
  korean: ['1590301157890-4810ed352733', '1498654896293-37aacf113fd9', '1580651214613-f4692d6d138f', '1583224964978-2257b960c3d3'],
  poke: ['1546069901-ba9599a7e63c', '1512621776951-a57141f2eefd', '1623855244183-52fd8d3ce2f7', '1540189549336-e6e99c3679fe'],
  street: ['1496116218417-1a781b1c416c', '1563245372-f21724e3856d', '1541696432-82c6da8ce7bf', '1585032226651-759b368d7246'],
  fusion: ['1540189549336-e6e99c3679fe', '1611143669185-af224c5e3252', '1414235077428-338989a2e8c0', '1517248135467-4c7edcad34c4'],
};

const catId = (slug: string) => {
  const c = categories.find((x) => x.slug === slug);
  if (!c) throw new Error(`Categoria sconosciuta: ${slug}`);
  return c.id;
};
const city = (slug: string) => {
  const c = cities.find((x) => x.slug === slug);
  if (!c) throw new Error(`Comune sconosciuto: ${slug}`);
  return c;
};

interface Spec {
  name: string;
  city: string;
  cuisine: Cuisine;
  cats: string[]; // slug categorie, la prima è primaria
  short: string;
  description: string;
  price: 1 | 2 | 3 | 4;
  avg: number;
  ayce?: [lunch: number, dinner: number, weekend?: number];
  delivery?: boolean;
  takeaway?: boolean;
  reservation?: boolean;
  featured?: boolean;
  sponsored?: boolean;
  popularity: number;
  openedAt?: string;
  services: string[];
  closedDay?: number; // giorno di chiusura settimanale (1–7)
  lunch?: false; // niente servizio a pranzo
  offset: [number, number];
  website?: boolean;
}

const SPECS: Spec[] = [
  {
    name: 'Kaizen Sushi Lab',
    city: 'taranto',
    cuisine: 'sushi',
    cats: ['sushi', 'giapponese', 'all-you-can-eat', 'fusion'],
    short: 'Sushi contemporaneo e formula All You Can Eat con ordinazione al tablet.',
    description:
      'Scheda dimostrativa. Un sushi bar dal design essenziale dove la formula All You Can Eat convive con una carta di roll d’autore. Pesce abbattuto secondo normativa, riso condito al momento e una selezione di tempura leggera.',
    price: 2,
    avg: 28,
    ayce: [18.9, 27.9, 29.9],
    takeaway: true,
    delivery: true,
    reservation: true,
    featured: true,
    sponsored: true,
    popularity: 98,
    services: ['wifi', 'accessibile', 'aria_condizionata', 'pagamento_carta'],
    closedDay: 1,
    offset: [0.004, -0.006],
    website: true,
  },
  {
    name: 'Ramen Kōen',
    city: 'taranto',
    cuisine: 'ramen',
    cats: ['ramen', 'giapponese'],
    short: 'Brodi cotti 18 ore, noodles freschi e gyoza alla piastra.',
    description:
      'Scheda dimostrativa. Piccola ramen-ya con bancone e pochi tavoli: tonkotsu, shoyu e un miso piccante. Menu corto, rotazione stagionale e opzione vegetariana a base di brodo di funghi.',
    price: 2,
    avg: 22,
    takeaway: true,
    popularity: 91,
    services: ['bancone', 'pagamento_carta', 'vegetariano'],
    closedDay: 2,
    offset: [-0.003, 0.004],
  },
  {
    name: 'Drago di Giada',
    city: 'taranto',
    cuisine: 'chinese',
    cats: ['cinese', 'street-food'],
    short: 'Cucina cinese di famiglia: ravioli al vapore, wok e anatra laccata.',
    description:
      'Scheda dimostrativa. Trattoria cinese dall’atmosfera familiare con ravioli fatti a mano, noodles saltati al wok e piatti della tradizione cantonese. Asporto e consegna nelle zone vicine.',
    price: 1,
    avg: 16,
    takeaway: true,
    delivery: true,
    popularity: 84,
    services: ['asporto', 'pagamento_carta', 'famiglie'],
    offset: [0.008, 0.01],
  },
  {
    name: 'Bangkok Street',
    city: 'taranto',
    cuisine: 'thai',
    cats: ['thai', 'street-food'],
    short: 'Street food thailandese: pad thai, curry verde e mango sticky rice.',
    description:
      'Scheda dimostrativa. Cucina a vista e ritmo da mercato notturno: wok ad alta fiamma, curry pestati al momento e livelli di piccantezza a scelta.',
    price: 1,
    avg: 17,
    takeaway: true,
    delivery: true,
    popularity: 79,
    openedAt: '2026-07-15',
    services: ['asporto', 'dehors', 'vegano'],
    closedDay: 1,
    lunch: false,
    offset: [-0.006, -0.012],
  },
  {
    name: 'Seoul Grill House',
    city: 'taranto',
    cuisine: 'korean',
    cats: ['coreano'],
    short: 'Barbecue coreano al tavolo, banchan fatti in casa e bibimbap.',
    description:
      'Scheda dimostrativa. Griglie integrate nei tavoli, tagli marinati e banchan che cambiano ogni settimana. Ideale per gruppi: consigliata la prenotazione nel weekend.',
    price: 3,
    avg: 35,
    reservation: true,
    featured: true,
    popularity: 88,
    services: ['gruppi', 'pagamento_carta', 'aria_condizionata'],
    closedDay: 1,
    lunch: false,
    offset: [0.011, -0.002],
  },
  {
    name: 'Aloha Poke Ionio',
    city: 'taranto',
    cuisine: 'poke',
    cats: ['poke'],
    short: 'Poke bowl componibili con pesce, tofu e topping croccanti.',
    description:
      'Scheda dimostrativa. Bowl personalizzabili in quattro passaggi: base, proteina, topping e salsa. Pranzo veloce, asporto e consegna.',
    price: 1,
    avg: 13,
    takeaway: true,
    delivery: true,
    popularity: 76,
    openedAt: '2026-09-02',
    services: ['asporto', 'vegano', 'senza_glutine'],
    offset: [-0.01, 0.007],
  },
  {
    name: 'Umami Garden',
    city: 'massafra',
    cuisine: 'sushi',
    cats: ['sushi', 'all-you-can-eat', 'fusion'],
    short: 'All You Can Eat con giardino estivo e roll fusion.',
    description:
      'Scheda dimostrativa. Ampia sala e giardino per la bella stagione, formula All You Can Eat a pranzo e cena con piatti caldi, sushi e dessert.',
    price: 2,
    avg: 25,
    ayce: [16.9, 25.9, 27.9],
    takeaway: true,
    reservation: true,
    popularity: 82,
    services: ['dehors', 'parcheggio', 'famiglie', 'accessibile'],
    closedDay: 1,
    offset: [0.003, 0.004],
  },
  {
    name: 'Hanami Sushi & Grill',
    city: 'martina-franca',
    cuisine: 'sushi',
    cats: ['sushi', 'giapponese', 'all-you-can-eat'],
    short: 'Sushi, robata grill e formula All You Can Eat nel centro storico.',
    description:
      'Scheda dimostrativa. Cucina giapponese tra griglia robata e banco sushi. Formula All You Can Eat con limite di ordini per turno per garantire qualità.',
    price: 2,
    avg: 27,
    ayce: [19.9, 28.9, 30.9],
    reservation: true,
    takeaway: true,
    featured: true,
    popularity: 90,
    services: ['pagamento_carta', 'aria_condizionata', 'gruppi'],
    closedDay: 2,
    offset: [-0.002, 0.003],
    website: true,
  },
  {
    name: 'Wok Station',
    city: 'grottaglie',
    cuisine: 'chinese',
    cats: ['cinese', 'street-food'],
    short: 'Noodles e riso saltati al wok, pronti in pochi minuti.',
    description: 'Scheda dimostrativa. Formula veloce: scegli base, proteina e salsa, il wok fa il resto. Perfetto per l’asporto.',
    price: 1,
    avg: 12,
    takeaway: true,
    delivery: true,
    popularity: 68,
    services: ['asporto', 'pagamento_carta'],
    offset: [0.002, -0.003],
  },
  {
    name: 'Sakura Bay',
    city: 'manduria',
    cuisine: 'sushi',
    cats: ['sushi', 'all-you-can-eat'],
    short: 'All You Can Eat a due passi dal mare, anche per asporto.',
    description: 'Scheda dimostrativa. Sushi e cucina calda in formula illimitata, menu bambini e sala per feste private.',
    price: 2,
    avg: 24,
    ayce: [15.9, 24.9, 26.9],
    takeaway: true,
    reservation: true,
    popularity: 74,
    services: ['famiglie', 'parcheggio', 'feste_private'],
    closedDay: 1,
    offset: [-0.004, 0.005],
  },
  {
    name: 'Momo Dumpling Bar',
    city: 'castellaneta',
    cuisine: 'street',
    cats: ['street-food', 'cinese'],
    short: 'Dumpling, bao e gyoza fatti a mano ogni giorno.',
    description: 'Scheda dimostrativa. Laboratorio di ravioli asiatici: al vapore, alla piastra o fritti, con salse della casa.',
    price: 1,
    avg: 15,
    takeaway: true,
    popularity: 71,
    openedAt: '2026-08-20',
    services: ['asporto', 'vegetariano'],
    closedDay: 3,
    offset: [0.002, 0.002],
  },
  {
    name: 'Tokyo Nights',
    city: 'ginosa',
    cuisine: 'sushi',
    cats: ['sushi', 'giapponese'],
    short: 'Sushi alla carta e cocktail giapponesi, solo a cena.',
    description: 'Scheda dimostrativa. Locale serale con banco sushi, piccoli piatti caldi e una lista di cocktail a base di sake e yuzu.',
    price: 3,
    avg: 38,
    reservation: true,
    popularity: 66,
    services: ['cocktail_bar', 'pagamento_carta'],
    closedDay: 1,
    lunch: false,
    offset: [-0.002, -0.002],
  },
  {
    name: 'Lemongrass Kitchen',
    city: 'mottola',
    cuisine: 'thai',
    cats: ['thai', 'fusion'],
    short: 'Cucina thai e contaminazioni mediterranee con prodotti locali.',
    description: 'Scheda dimostrativa. Curry, insalate croccanti e piatti di pesce che uniscono ricette thai e materie prime pugliesi.',
    price: 2,
    avg: 26,
    reservation: true,
    takeaway: true,
    popularity: 63,
    services: ['dehors', 'vegano', 'senza_glutine'],
    closedDay: 2,
    offset: [0.003, -0.001],
  },
  {
    name: 'Poke Lab Pulsano',
    city: 'pulsano',
    cuisine: 'poke',
    cats: ['poke', 'fusion'],
    short: 'Poke e bowl estive a pochi minuti dalle spiagge.',
    description: 'Scheda dimostrativa. Bowl fresche da portare al mare, smoothie e dolci leggeri. Aperto tutti i giorni in estate.',
    price: 1,
    avg: 12,
    takeaway: true,
    delivery: true,
    popularity: 60,
    services: ['asporto', 'vegano'],
    offset: [0.001, 0.003],
  },
  {
    name: 'Nami Fusion',
    city: 'leporano',
    cuisine: 'fusion',
    cats: ['fusion', 'sushi'],
    short: 'Crudi, roll d’autore e vista mare: il fusion della costa ionica.',
    description: 'Scheda dimostrativa. Terrazza sul mare, crudi di pesce locale e roll che incontrano ingredienti mediterranei.',
    price: 3,
    avg: 45,
    reservation: true,
    featured: true,
    popularity: 77,
    openedAt: '2026-06-28',
    services: ['vista_mare', 'dehors', 'parcheggio', 'pagamento_carta'],
    closedDay: 1,
    lunch: false,
    offset: [-0.003, 0.002],
    website: true,
  },
  {
    name: 'Golden Lotus',
    city: 'san-giorgio-ionico',
    cuisine: 'chinese',
    cats: ['cinese', 'all-you-can-eat', 'sushi'],
    short: 'Cucina cinese e giapponese in formula All You Can Eat.',
    description: 'Scheda dimostrativa. Grande sala con formula illimitata che unisce specialità cinesi, sushi e piatti alla griglia.',
    price: 1,
    avg: 20,
    ayce: [14.9, 22.9, 24.9],
    takeaway: true,
    delivery: true,
    reservation: true,
    popularity: 70,
    services: ['famiglie', 'parcheggio', 'gruppi'],
    offset: [0.002, -0.002],
  },
  {
    name: 'Bao & Co.',
    city: 'palagiano',
    cuisine: 'street',
    cats: ['street-food', 'fusion'],
    short: 'Bao soffici, fried chicken coreano e bubble tea.',
    description: 'Scheda dimostrativa. Street food asiatico informale: bao ripieni, pollo fritto in stile coreano e bevande fresche.',
    price: 1,
    avg: 14,
    takeaway: true,
    popularity: 58,
    openedAt: '2026-09-10',
    services: ['asporto', 'dehors'],
    closedDay: 1,
    offset: [-0.001, 0.002],
  },
];

// ─── Template menu per cucina ────────────────────────────────
type ItemTpl = [name: string, desc: string, price: number, pieces?: number, tags?: string[]];
type SectionTpl = [name: string, items: ItemTpl[]];

const MENU_TPL: Record<Cuisine, SectionTpl[]> = {
  sushi: [
    ['Antipasti', [
      ['Edamame', 'Fagioli di soia al vapore con sale Maldon', 4.5, undefined, ['vegan']],
      ['Gyoza di gamberi', 'Ravioli alla piastra, salsa ponzu', 6.5, 5],
      ['Tempura mista', 'Gamberi e verdure in pastella leggera', 9],
    ]],
    ['Nigiri & Sashimi', [
      ['Nigiri salmone', 'Salmone norvegese su riso condito', 4, 2],
      ['Nigiri tonno', 'Tonno pinna gialla', 5, 2],
      ['Sashimi misto', 'Selezione del giorno', 16, 12, ['signature']],
    ]],
    ['Roll', [
      ['California roll', 'Surimi, avocado, cetriolo, sesamo', 9, 8],
      ['Dragon roll', 'Tempura di gamberi, avocado, salsa teriyaki', 13, 8, ['signature']],
      ['Spicy tuna', 'Tonno, maionese piccante, erba cipollina', 11, 8, ['spicy']],
      ['Veggie roll', 'Avocado, mango, cetriolo, philadelphia', 8, 8, ['vegetarian']],
    ]],
    ['Dolci', [
      ['Mochi', 'Tre gusti a scelta', 5.5, 3],
      ['Dorayaki', 'Pancake ripieno di crema di azuki', 4.5],
    ]],
  ],
  ramen: [
    ['Ramen', [
      ['Tonkotsu', 'Brodo di maiale 18 ore, chashu, uovo marinato, nori', 14, undefined, ['signature']],
      ['Shoyu', 'Brodo di pollo e soia, bambù, cipollotto', 13],
      ['Spicy miso', 'Miso piccante, maiale macinato, mais', 14, undefined, ['spicy']],
      ['Veggie shiitake', 'Brodo di funghi, tofu, pak choi', 12.5, undefined, ['vegan']],
    ]],
    ['Side', [
      ['Gyoza di maiale', 'Alla piastra con salsa ponzu', 6.5, 5],
      ['Karaage', 'Pollo fritto giapponese, maionese kewpie', 7.5],
      ['Onigiri', 'Triangolo di riso con salmone', 4, 1],
    ]],
    ['Bevande', [
      ['Tè matcha freddo', 'Preparato al momento', 4],
      ['Ramune', 'Soda giapponese', 3.5],
    ]],
  ],
  chinese: [
    ['Ravioli', [
      ['Ravioli al vapore', 'Carne e verdure', 5, 4],
      ['Ravioli di gamberi', 'Har gow al vapore', 6, 4, ['signature']],
      ['Involtini primavera', 'Fritti, salsa agrodolce', 3.5, 2],
    ]],
    ['Wok', [
      ['Spaghetti di soia saltati', 'Verdure, uovo, salsa di soia', 6.5],
      ['Riso alla cantonese', 'Prosciutto, piselli, uovo', 5],
      ['Pollo alle mandorle', 'Saltato con verdure croccanti', 8],
      ['Manzo piccante', 'Peperoncino e pepe di Sichuan', 9.5, undefined, ['spicy']],
    ]],
    ['Specialità', [
      ['Anatra laccata', 'Mezza porzione con crêpes e cetriolo', 18, undefined, ['signature']],
      ['Tofu mapo', 'Tofu, salsa di fagioli fermentati', 8, undefined, ['spicy', 'vegetarian']],
    ]],
  ],
  thai: [
    ['Street', [
      ['Pad thai', 'Noodles di riso, gamberi, arachidi, lime', 11, undefined, ['signature']],
      ['Satay di pollo', 'Spiedini con salsa di arachidi', 7, 4],
      ['Som tam', 'Insalata di papaya verde', 7.5, undefined, ['spicy', 'vegan']],
    ]],
    ['Curry', [
      ['Green curry', 'Latte di cocco, basilico thai, pollo', 12, undefined, ['spicy']],
      ['Massaman', 'Manzo, patate, arachidi', 13],
      ['Red curry veg', 'Verdure di stagione e tofu', 11, undefined, ['vegan']],
    ]],
    ['Dolci', [['Mango sticky rice', 'Riso glutinoso, mango fresco, cocco', 6]]],
  ],
  korean: [
    ['BBQ al tavolo', [
      ['Samgyeopsal', 'Pancia di maiale, 250 g', 16],
      ['Bulgogi', 'Manzo marinato, 250 g', 19, undefined, ['signature']],
      ['Dak galbi', 'Pollo piccante marinato', 15, undefined, ['spicy']],
    ]],
    ['Piatti', [
      ['Bibimbap', 'Riso, verdure, uovo, gochujang', 13],
      ['Kimchi jjigae', 'Stufato di kimchi e tofu', 12, undefined, ['spicy']],
      ['Pajeon', 'Frittella di cipollotto e frutti di mare', 10],
    ]],
    ['Banchan', [['Selezione banchan', 'Sei contorni fermentati della casa', 6, undefined, ['vegetarian']]]],
  ],
  poke: [
    ['Poke signature', [
      ['Classic salmon', 'Salmone, edamame, avocado, cipolla croccante', 11.5, undefined, ['signature']],
      ['Tuna spicy', 'Tonno, mango, jalapeño, salsa sriracha', 12.5, undefined, ['spicy']],
      ['Green tofu', 'Tofu marinato, alga wakame, cetriolo', 10, undefined, ['vegan']],
    ]],
    ['Componi la tua', [
      ['Bowl regular', 'Base + 1 proteina + 4 topping + salsa', 10],
      ['Bowl large', 'Base + 2 proteine + 5 topping + salsa', 13],
    ]],
    ['Bevande', [['Smoothie tropicale', 'Mango, ananas, passion fruit', 4.5]]],
  ],
  street: [
    ['Bao', [
      ['Bao pork belly', 'Pancia di maiale glassata, cetriolo, arachidi', 5.5, 1, ['signature']],
      ['Bao crispy chicken', 'Pollo fritto, slaw, mayo piccante', 5, 1, ['spicy']],
      ['Bao tofu', 'Tofu croccante, hoisin, cipollotto', 5, 1, ['vegan']],
    ]],
    ['Dumpling', [
      ['Gyoza mix', 'Maiale e verdure alla piastra', 7, 6],
      ['Xiao long bao', 'Ravioli in brodo al vapore', 8, 5],
    ]],
    ['Snack', [
      ['Korean fried chicken', 'Glassa dolce-piccante', 9, undefined, ['spicy']],
      ['Bubble tea', 'Tè al latte con perle di tapioca', 4.5],
    ]],
  ],
  fusion: [
    ['Crudi', [
      ['Tartare di tonno', 'Tonno, avocado, ponzu agli agrumi', 16, undefined, ['signature']],
      ['Carpaccio di ricciola', 'Yuzu, olio evo, sale affumicato', 15],
    ]],
    ['Roll d’autore', [
      ['Ionio roll', 'Gambero rosso, burrata, pistacchio', 16, 8, ['signature']],
      ['Salento roll', 'Polpo, patata, cime di rapa', 14, 8],
    ]],
    ['Caldi', [
      ['Black cod miso', 'Merluzzo nero marinato 48 ore', 24],
      ['Ramen di mare', 'Brodo di crostacei, cozze tarantine', 18],
    ]],
  ],
};

// ─── Costruzione dataset ─────────────────────────────────────
const CREATED = '2026-09-01T09:00:00.000Z';

/** Piatto con i campi Fase 4 (flag dietetici derivati dalle etichette). */
function menuItem(p: Pick<MenuItem, 'id' | 'menu_category_id' | 'restaurant_id' | 'name' | 'description' | 'price' | 'sort_order'> & Partial<MenuItem>): MenuItem {
  const tags = p.tags ?? [];
  return {
    image_url: null,
    pieces: null,
    allergens: [],
    ingredients: [],
    discount_price: null,
    is_available: true,
    is_ayce_included: false,
    ayce_limit: null,
    is_featured: tags.includes('signature'),
    is_spicy: tags.includes('spicy'),
    is_vegan: tags.includes('vegan'),
    is_vegetarian: tags.includes('vegetarian') || tags.includes('vegan'),
    is_gluten_free: tags.includes('gluten_free'),
    ...p,
    tags,
  };
}

export const demoRestaurants: Restaurant[] = [];
export const demoRestaurantCategories: RestaurantCategory[] = [];
export const demoImages: RestaurantImage[] = [];
export const demoHours: RestaurantHour[] = [];
export const demoMenus: Menu[] = [];
export const demoMenuCategories: MenuCategory[] = [];
export const demoMenuItems: MenuItem[] = [];

let imageN = 0;
let hourN = 0;
let menuN = 0;
let sectionN = 0;
let itemN = 0;

const slugify = (s: string) =>
  s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/&/g, ' ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

SPECS.forEach((s, i) => {
  const n = i + 1;
  const id = fixedId('restaurant', n);
  const c = city(s.city);
  const pool = IMAGE_POOL[s.cuisine];
  const pad = String(n).padStart(2, '0');

  demoRestaurants.push({
    id,
    owner_id: null,
    name: s.name,
    slug: `${slugify(s.name)}-${c.slug}`,
    short_description: s.short,
    description: s.description,
    address: `Via Esempio ${10 + n} (indirizzo DEMO)`,
    city_id: c.id,
    province_id: c.province_id,
    region_id: c.region_id,
    postal_code: c.postal_code,
    latitude: Number(((c.latitude ?? 0) + s.offset[0]).toFixed(6)),
    longitude: Number(((c.longitude ?? 0) + s.offset[1]).toFixed(6)),
    phone: `+39 000 000 00${pad}`,
    whatsapp: `3900000000${pad}`,
    email: `demo${pad}@example.com`,
    website: s.website ? 'https://example.com' : null,
    instagram: null,
    facebook: null,
    tiktok: null,
    logo_url: null,
    cover_url: img(pool[0], 1600),
    price_range: s.price,
    average_price: s.avg,
    is_all_you_can_eat: !!s.ayce,
    ayce_lunch_price: s.ayce?.[0] ?? null,
    ayce_dinner_price: s.ayce?.[1] ?? null,
    ayce_weekend_price: s.ayce?.[2] ?? null,
    has_delivery: !!s.delivery,
    has_takeaway: !!s.takeaway,
    has_reservation: !!s.reservation,
    reservation_url: null,
    services: s.services,
    timezone: 'Europe/Rome',
    is_verified: false,
    is_active: true,
    is_featured: !!s.featured,
    is_sponsored: !!s.sponsored,
    is_demo: true,
    subscription_plan: s.sponsored ? 'top' : s.featured ? 'premium' : 'free',
    popularity_score: s.popularity,
    opened_at: s.openedAt ?? null,
    meta_title: null,
    meta_description: null,
    // Fase 2 — i dati demo non hanno fonti reali: restano "unverified"
    source_name: null,
    source_url: null,
    external_id: null,
    google_place_id: null,
    data_status: 'unverified',
    last_verified_at: null,
    claimed_at: null,
    claimed_by: null,
    verification_notes: 'Scheda DEMO di fantasia: nessuna fonte reale.',
    menu_last_verified_at: null,
    opening_hours_last_verified_at: null,
    is_temporarily_closed: false,
    is_permanently_closed: false,
    created_at: s.openedAt ? `${s.openedAt}T09:00:00.000Z` : CREATED,
    updated_at: CREATED,
  });

  s.cats.forEach((slug, k) =>
    demoRestaurantCategories.push({ restaurant_id: id, category_id: catId(slug), is_primary: k === 0 }),
  );

  pool.forEach((photo, k) => {
    imageN += 1;
    demoImages.push({
      id: fixedId('image', imageN),
      restaurant_id: id,
      url: img(photo),
      storage_path: null,
      alt: `${s.name} — foto ${k + 1} (immagine di repertorio)`,
      kind: k === 3 && s.cuisine === 'fusion' ? 'interior' : 'dish',
      sort_order: k,
    });
  });

  for (let d = 1; d <= 7; d++) {
    const closed = s.closedDay === d;
    if (closed) {
      hourN += 1;
      demoHours.push({ id: fixedId('hour', hourN), restaurant_id: id, day_of_week: d, opens_at: null, closes_at: null, is_closed: true, label: null });
      continue;
    }
    if (s.lunch !== false) {
      hourN += 1;
      demoHours.push({ id: fixedId('hour', hourN), restaurant_id: id, day_of_week: d, opens_at: '12:00', closes_at: '15:00', is_closed: false, label: 'Pranzo' });
    }
    hourN += 1;
    const late = d >= 5; // venerdì–domenica chiusura dopo mezzanotte
    demoHours.push({
      id: fixedId('hour', hourN),
      restaurant_id: id,
      day_of_week: d,
      opens_at: '19:00',
      closes_at: late ? '00:30' : '23:30',
      is_closed: false,
      label: 'Cena',
    });
  }

  // Il locale n. 1 ha un menu completo dedicato (vedi buildFullMenu)
  if (n === 1) return;

  // Menu alla carta
  menuN += 1;
  const menuId = fixedId('menu', menuN);
  demoMenus.push({ id: menuId, restaurant_id: id, name: 'Menu alla carta', description: 'Prezzi dimostrativi.', menu_type: 'a_la_carte', price: null, is_active: true, is_public: true, valid_from: null, valid_until: null, sort_order: 0 });
  MENU_TPL[s.cuisine].forEach(([sectionName, items], si) => {
    sectionN += 1;
    const sectionId = fixedId('menuCategory', sectionN);
    demoMenuCategories.push({ id: sectionId, menu_id: menuId, restaurant_id: id, name: sectionName, description: null, is_active: true, sort_order: si });
    items.forEach(([name, desc, price, pieces, tags], ii) => {
      itemN += 1;
      demoMenuItems.push(menuItem({
        id: fixedId('menuItem', itemN),
        menu_category_id: sectionId,
        restaurant_id: id,
        name,
        description: desc,
        price,
        pieces: pieces ?? null,
        tags: tags ?? [],
        is_ayce_included: !!s.ayce,
        sort_order: ii,
      }));
    });
  });

  // Menu AYCE
  if (s.ayce) {
    menuN += 1;
    demoMenus.push({
      id: fixedId('menu', menuN),
      restaurant_id: id,
      name: 'All You Can Eat',
      description: `Pranzo € ${s.ayce[0].toFixed(2)} · Cena € ${s.ayce[1].toFixed(2)}. Bevande, coperto e dolci esclusi. Il cibo avanzato può essere addebitato.`,
      menu_type: 'all_you_can_eat',
      price: s.ayce[1],
      is_active: true,
      is_public: true,
      valid_from: null,
      valid_until: null,
      sort_order: 1,
    });
  }
});

// ─── Piani demo: 1 Free, 1 Business, 1 Premium, 1 Top (almeno) ───
// Kaizen (1) = Top · Ramen Kōen (2) = Business · Seoul (5), Hanami (8), Nami (15) = Premium · gli altri Free
export const PLAN_BY_RESTAURANT: Record<number, PlanCode> = { 1: 'top', 2: 'business', 5: 'premium', 8: 'premium', 15: 'premium' };
demoRestaurants.forEach((r, i) => (r.subscription_plan = PLAN_BY_RESTAURANT[i + 1] ?? 'free'));

// ─── Menu completo (Kaizen Sushi Lab): più menu, varianti, extra, allergeni, ingredienti ───
export const demoMenuItemVariants: MenuItemVariant[] = [];
export const demoMenuItemAddons: MenuItemAddon[] = [];

type FullItem = {
  name: string;
  desc?: string;
  price: number | null;
  discount?: number;
  allergens?: string[];
  ingredients?: string[];
  flags?: ('spicy' | 'vegetarian' | 'vegan' | 'gluten_free' | 'featured')[];
  pieces?: number;
  variants?: [string, number][];
  addons?: [string, number][];
  photo?: string;
  unavailable?: boolean;
};
type FullMenu = { name: string; type: Menu['menu_type']; price?: number; description?: string; sections: [string, FullItem[]][] };

const SUSHI_PHOTOS = IMAGE_POOL.sushi;
const KAIZEN_MENUS: FullMenu[] = [
  {
    name: 'Menu principale',
    type: 'a_la_carte',
    description: 'Prezzi dimostrativi. Coperto € 2.',
    sections: [
      ['Antipasti', [
        { name: 'Edamame', desc: 'Fagioli di soia al vapore con sale Maldon', price: 4.5, allergens: ['soy'], ingredients: ['edamame', 'sale Maldon'], flags: ['vegan', 'gluten_free'] },
        { name: 'Gyoza di gamberi', desc: 'Ravioli alla piastra, salsa ponzu', price: 6.5, pieces: 5, allergens: ['gluten', 'crustaceans', 'soy', 'sesame'], ingredients: ['gamberi', 'cavolo cinese', 'zenzero', 'ponzu'] },
        { name: 'Tempura mista', desc: 'Gamberi e verdure in pastella leggera', price: 9, allergens: ['gluten', 'crustaceans', 'eggs'], ingredients: ['gamberi', 'zucchine', 'patata dolce', 'pastella'], photo: SUSHI_PHOTOS[2] },
        { name: 'Wakame salad', desc: 'Alga wakame, sesamo e cetriolo', price: 5, allergens: ['sesame', 'soy'], ingredients: ['alga wakame', 'cetriolo', 'sesamo'], flags: ['vegan'] },
      ]],
      ['Nigiri', [
        { name: 'Nigiri salmone', desc: 'Salmone norvegese su riso condito', price: 4, pieces: 2, allergens: ['fish'], ingredients: ['riso', 'salmone'], flags: ['gluten_free'], variants: [['2 pezzi', 4], ['4 pezzi', 7.5]] },
        { name: 'Nigiri tonno', desc: 'Tonno pinna gialla', price: 5, pieces: 2, allergens: ['fish'], ingredients: ['riso', 'tonno pinna gialla'], flags: ['gluten_free'], variants: [['2 pezzi', 5], ['4 pezzi', 9.5]] },
        { name: 'Nigiri gambero rosso', desc: 'Gambero rosso crudo e lime', price: 7, pieces: 2, allergens: ['crustaceans'], ingredients: ['riso', 'gambero rosso', 'lime'], flags: ['featured'] },
      ]],
      ['Sashimi', [
        { name: 'Sashimi salmone', desc: 'Tagli spessi di salmone', price: 10, allergens: ['fish'], ingredients: ['salmone'], flags: ['gluten_free'], variants: [['6 pezzi', 10], ['12 pezzi', 18]], photo: SUSHI_PHOTOS[1] },
        { name: 'Sashimi misto', desc: 'Selezione del giorno', price: 16, discount: 14, pieces: 12, allergens: ['fish', 'molluscs'], ingredients: ['salmone', 'tonno', 'branzino', 'capesante'], flags: ['featured'] },
      ]],
      ['Uramaki', [
        { name: 'California roll', desc: 'Surimi, avocado, cetriolo, sesamo', price: 9, allergens: ['fish', 'eggs', 'sesame', 'gluten'], ingredients: ['surimi', 'avocado', 'cetriolo', 'maionese', 'sesamo'], variants: [['4 pezzi', 5.5], ['8 pezzi', 9]], addons: [['Extra avocado', 1.5], ['Salsa spicy', 0.5]] },
        { name: 'Dragon roll', desc: 'Tempura di gamberi, avocado, salsa teriyaki', price: 13, allergens: ['gluten', 'crustaceans', 'eggs', 'soy', 'sesame'], ingredients: ['gambero in tempura', 'avocado', 'salsa teriyaki', 'sesamo'], flags: ['featured'], variants: [['4 pezzi', 7], ['8 pezzi', 13]], addons: [['Extra salmone', 2.5], ['Extra avocado', 1.5]], photo: SUSHI_PHOTOS[3] },
        { name: 'Spicy tuna', desc: 'Tonno, maionese piccante, erba cipollina', price: 11, allergens: ['fish', 'eggs', 'sesame'], ingredients: ['tonno', 'maionese piccante', 'erba cipollina'], flags: ['spicy'], variants: [['4 pezzi', 6], ['8 pezzi', 11]], addons: [['Extra salsa spicy', 0.5]] },
        { name: 'Veggie roll', desc: 'Avocado, mango, cetriolo, philadelphia', price: 8, allergens: ['milk', 'sesame'], ingredients: ['avocado', 'mango', 'cetriolo', 'formaggio spalmabile'], flags: ['vegetarian'], variants: [['4 pezzi', 4.5], ['8 pezzi', 8]] },
        { name: 'Ebiten roll al tartufo', desc: 'Gambero in tempura e crema di tartufo', price: 14, allergens: ['gluten', 'crustaceans', 'eggs', 'milk'], ingredients: ['gambero', 'tartufo', 'panko'], unavailable: true },
      ]],
      ['Ramen', [
        { name: 'Tonkotsu ramen', desc: 'Brodo di maiale, chashu, uovo marinato', price: 14, allergens: ['gluten', 'eggs', 'soy', 'sesame'], ingredients: ['noodles di frumento', 'brodo di maiale', 'chashu', 'uovo', 'nori'], addons: [['Uovo marinato extra', 1.5], ['Chashu extra', 3]] },
        { name: 'Spicy miso ramen', desc: 'Miso piccante, maiale macinato, mais', price: 14, allergens: ['gluten', 'soy', 'sesame'], ingredients: ['noodles', 'miso', 'peperoncino', 'mais'], flags: ['spicy'] },
      ]],
      ['Dolci', [
        { name: 'Mochi', desc: 'Tre gusti a scelta', price: 5.5, pieces: 3, allergens: ['milk'], ingredients: ['farina di riso glutinoso', 'gelato'], flags: ['vegetarian', 'gluten_free'] },
        { name: 'Dorayaki', desc: 'Pancake ripieno di crema di azuki', price: 4.5, allergens: ['gluten', 'eggs', 'milk'], ingredients: ['pancake', 'azuki'], flags: ['vegetarian'] },
      ]],
    ],
  },
  {
    name: 'Pranzo',
    type: 'lunch',
    price: 14.9,
    description: 'Dal martedì al venerdì, 12:00–15:00. Zuppa di miso inclusa.',
    sections: [
      ['Formule pranzo', [
        { name: 'Bento salmone', desc: 'Sashimi, nigiri, uramaki e riso', price: 14.9, allergens: ['fish', 'soy', 'sesame'], ingredients: ['salmone', 'riso', 'alga nori'] },
        { name: 'Poke lunch', desc: 'Riso, salmone o tofu, edamame, avocado', price: 12.9, allergens: ['fish', 'soy', 'sesame'], ingredients: ['riso', 'salmone', 'edamame', 'avocado'], addons: [['Extra salmone', 2.5], ['Extra avocado', 1.5]] },
      ]],
    ],
  },
  {
    name: 'All You Can Eat',
    type: 'all_you_can_eat',
    price: 27.9,
    description: 'Pranzo € 18,90 · Cena € 27,90 · Weekend € 29,90. Bevande, coperto e dolci esclusi. Il cibo avanzato può essere addebitato.',
    sections: [
      ['Inclusi nella formula', [
        { name: 'Uramaki a scelta', desc: 'Compreso nel menu AYCE (max 2 per giro)', price: null, allergens: ['fish', 'sesame', 'gluten'] },
        { name: 'Nigiri misti', desc: 'Compreso nel menu AYCE', price: null, allergens: ['fish'] },
        { name: 'Gyoza', desc: 'Compreso nel menu AYCE', price: null, allergens: ['gluten', 'soy'] },
      ]],
    ],
  },
  {
    name: 'Bevande',
    type: 'drinks',
    sections: [
      ['Bevande', [
        { name: 'Tè verde caldo', price: 2.5, flags: ['vegan', 'gluten_free'] },
        { name: 'Birra giapponese', desc: 'Asahi o Sapporo', price: 5, allergens: ['gluten'], variants: [['33 cl', 5], ['50 cl', 7]] },
        { name: 'Acqua minerale', price: 2, flags: ['vegan', 'gluten_free'] },
      ]],
    ],
  },
];

function buildFullMenu(restaurantN: number, menus: FullMenu[]) {
  const rid = fixedId('restaurant', restaurantN);
  let variantN = 0;
  let addonN = 0;
  menus.forEach((m, mi) => {
    menuN += 1;
    const menuId = fixedId('menu', menuN);
    demoMenus.push({ id: menuId, restaurant_id: rid, name: m.name, description: m.description ?? null, menu_type: m.type, price: m.price ?? null, is_active: true, is_public: true, valid_from: null, valid_until: null, sort_order: mi });
    m.sections.forEach(([sectionName, items], si) => {
      sectionN += 1;
      const sectionId = fixedId('menuCategory', sectionN);
      demoMenuCategories.push({ id: sectionId, menu_id: menuId, restaurant_id: rid, name: sectionName, description: null, is_active: true, sort_order: si });
      items.forEach((it, ii) => {
        itemN += 1;
        const itemId = fixedId('menuItem', itemN);
        const f = new Set(it.flags ?? []);
        demoMenuItems.push(menuItem({
          id: itemId, menu_category_id: sectionId, restaurant_id: rid, name: it.name, description: it.desc ?? null, price: it.price,
          discount_price: it.discount ?? null, pieces: it.pieces ?? null, allergens: it.allergens ?? [], ingredients: it.ingredients ?? [],
          image_url: it.photo ? img(it.photo, 400) : null, is_available: !it.unavailable, is_ayce_included: m.type === 'all_you_can_eat',
          is_spicy: f.has('spicy'), is_vegan: f.has('vegan'), is_vegetarian: f.has('vegetarian') || f.has('vegan'),
          is_gluten_free: f.has('gluten_free'), is_featured: f.has('featured'), tags: f.has('featured') ? ['signature'] : [], sort_order: ii,
        }));
        (it.variants ?? []).forEach(([name, price], k) => {
          variantN += 1;
          demoMenuItemVariants.push({ id: fixedId('variant', restaurantN * 1000 + variantN), menu_item_id: itemId, restaurant_id: rid, name, price, is_available: true, display_order: k });
        });
        (it.addons ?? []).forEach(([name, price], k) => {
          addonN += 1;
          demoMenuItemAddons.push({ id: fixedId('addon', restaurantN * 1000 + addonN), menu_item_id: itemId, restaurant_id: rid, name, price, is_available: true, display_order: k });
        });
      });
    });
  });
}
buildFullMenu(1, KAIZEN_MENUS);

// ─── Fase 8: ordini online DEMO ───────────────────────────────
// Seoul Grill House (5): takeaway + delivery a zone, sushi/kimbap con varianti ed extra, bowl con scelte.
// Ramen Kōen (2): solo takeaway (non tutti i locali offrono entrambi).
export const demoOptionGroups: MenuOptionGroup[] = [];
let optionGroupN = 0;
let optionN = 0;
function addOrderSection(restaurantN: number, sectionName: string, items: (FullItem & { groups?: { name: string; min: number; max: number; required: boolean; options: [string, number][] }[] })[]) {
  const rid = fixedId('restaurant', restaurantN);
  const menu = demoMenus.find((m) => m.restaurant_id === rid && m.menu_type === 'a_la_carte');
  if (!menu) throw new Error('menu mancante');
  sectionN += 1;
  const sectionId = fixedId('menuCategory', sectionN);
  demoMenuCategories.push({ id: sectionId, menu_id: menu.id, restaurant_id: rid, name: sectionName, description: null, is_active: true,
    sort_order: 10 + demoMenuCategories.filter((c) => c.menu_id === menu.id).length });
  items.forEach((it, ii) => {
    itemN += 1;
    const itemId = fixedId('menuItem', itemN);
    const f = new Set(it.flags ?? []);
    demoMenuItems.push(menuItem({
      id: itemId, menu_category_id: sectionId, restaurant_id: rid, name: it.name, description: it.desc ?? null, price: it.price,
      discount_price: it.discount ?? null, pieces: it.pieces ?? null, allergens: it.allergens ?? [], ingredients: it.ingredients ?? [],
      image_url: it.photo ? img(it.photo, 400) : null, is_available: !it.unavailable, is_spicy: f.has('spicy'), is_vegan: f.has('vegan'),
      is_vegetarian: f.has('vegetarian') || f.has('vegan'), is_gluten_free: f.has('gluten_free'), is_featured: f.has('featured'),
      tags: f.has('featured') ? ['signature'] : [], sort_order: ii,
    }));
    (it.variants ?? []).forEach(([name, price], k) => {
      demoMenuItemVariants.push({ id: fixedId('variant', restaurantN * 1000 + 500 + demoMenuItemVariants.length), menu_item_id: itemId, restaurant_id: rid, name, price, is_available: true, display_order: k });
    });
    (it.addons ?? []).forEach(([name, price], k) => {
      demoMenuItemAddons.push({ id: fixedId('addon', restaurantN * 1000 + 500 + demoMenuItemAddons.length), menu_item_id: itemId, restaurant_id: rid, name, price, is_available: true, display_order: k });
    });
    (it.groups ?? []).forEach((g, gi) => {
      optionGroupN += 1;
      const gid = fixedId('optionGroup', optionGroupN);
      demoOptionGroups.push({
        id: gid, menu_item_id: itemId, restaurant_id: rid, name: g.name, min_select: g.min, max_select: g.max, required: g.required, display_order: gi, is_active: true,
        options: g.options.map(([name, price], oi) => {
          optionN += 1;
          return { id: fixedId('menuOption', optionN), option_group_id: gid, restaurant_id: rid, name, price, is_available: true, display_order: oi };
        }),
      });
    });
  });
}
addOrderSection(5, 'Sushi e kimbap', [
  { name: 'Uramaki salmone e avocado', desc: 'Salmone, avocado, sesamo tostato', price: 11, allergens: ['fish', 'sesame', 'soy'], ingredients: ['riso', 'salmone', 'avocado', 'sesamo'], variants: [['4 pezzi', 6], ['8 pezzi', 11]], addons: [['Extra salmone', 2.5], ['Extra avocado', 1.5], ['Salsa spicy', 0.5]], photo: SUSHI_PHOTOS[3], flags: ['featured'] },
  { name: 'Nigiri salmone', desc: 'Salmone su riso condito', price: 4.5, pieces: 2, allergens: ['fish'], ingredients: ['riso', 'salmone'], flags: ['gluten_free'], variants: [['2 pezzi', 4.5], ['4 pezzi', 8.5]] },
  { name: 'Kimbap bulgogi', desc: 'Rotolo coreano con manzo marinato, uovo e verdure', price: 9, pieces: 8, allergens: ['eggs', 'soy', 'sesame', 'gluten'], ingredients: ['riso', 'alga', 'manzo bulgogi', 'uovo', 'carota', 'spinaci'] },
  { name: 'Sushi misto 12 pezzi', desc: 'Selezione dello chef: nigiri e uramaki', price: 16, pieces: 12, allergens: ['fish', 'crustaceans', 'sesame'], ingredients: ['salmone', 'tonno', 'gambero'] },
]);
addOrderSection(5, 'Bowl', [
  { name: 'Bibimbap bowl', desc: 'Componi la tua bowl: base, proteina e salse', price: 12.5, allergens: ['soy', 'sesame', 'eggs'], ingredients: ['verdure saltate', 'uovo', 'gochujang'], addons: [['Uovo fritto extra', 1.5], ['Kimchi extra', 2]],
    groups: [
      { name: 'Base', min: 1, max: 1, required: true, options: [['Riso bianco', 0], ['Riso integrale', 0.5], ['Insalata', 0]] },
      { name: 'Proteina', min: 1, max: 1, required: true, options: [['Manzo bulgogi', 0], ['Pollo piccante', 0], ['Tofu', 0], ['Salmone', 2]] },
      { name: 'Salse', min: 0, max: 2, required: false, options: [['Gochujang', 0], ['Salsa di soia', 0], ['Maionese spicy', 0.5]] },
    ] },
  { name: 'Poke coreano', desc: 'Riso, salmone marinato, avocado, edamame', price: 13, allergens: ['fish', 'soy', 'sesame'], ingredients: ['riso', 'salmone', 'avocado', 'edamame'], addons: [['Extra salmone', 2.5], ['Extra avocado', 1.5]] },
]);
addOrderSection(5, 'Bevande', [
  { name: 'Birra coreana', desc: 'Cass o Hite', price: 4.5, allergens: ['gluten'], variants: [['33 cl', 4.5], ['50 cl', 6.5]] },
  { name: 'Acqua naturale', price: 2, flags: ['vegan', 'gluten_free'] },
  { name: 'Tè d\'orzo freddo', price: 3, flags: ['vegan'] },
]);

const orderSettings = (n: number, o: Partial<RestaurantOrderSettings>): RestaurantOrderSettings => ({
  id: fixedId('orderSettings', n), restaurant_id: fixedId('restaurant', n), orders_enabled: true, takeaway_enabled: true, delivery_enabled: false,
  minimum_order_amount: 10, takeaway_minimum_order: null, delivery_minimum_order: null, default_preparation_minutes: 20, busy_extra_minutes: 0,
  delivery_estimated_minutes: 25, slot_interval_minutes: 15, max_orders_per_slot: 6, accept_orders_automatically: false, allow_scheduled_orders: true,
  max_advance_days: 2, delivery_radius_km: null, free_delivery_threshold: null, delivery_fee_type: 'fixed', delivery_fee: 0,
  delivery_provider_type: 'restaurant', service_fee_enabled: true, orders_paused_until: null, delivery_paused_until: null, takeaway_paused_until: null,
  pickup_instructions: null, ...o,
});
export const demoOrderSettings: RestaurantOrderSettings[] = [
  orderSettings(5, { delivery_enabled: true, delivery_minimum_order: 15, delivery_radius_km: 10, free_delivery_threshold: 45, delivery_fee_type: 'distance',
    pickup_instructions: 'Ritiro alla cassa: indica il numero d’ordine. Parcheggio in via Principe Amedeo.' }),
  orderSettings(2, { minimum_order_amount: 8, max_orders_per_slot: 4, pickup_instructions: 'Ritiro al bancone.' }),
];
const zone = (n: number, restaurant: number, name: string, min: number, max: number, fee: number, minimum: number, eta: number): DeliveryZone => ({
  id: fixedId('deliveryZone', n), restaurant_id: fixedId('restaurant', restaurant), name, zone_type: 'distance', radius_km: null,
  min_distance_km: min, max_distance_km: max, delivery_fee: fee, minimum_order: minimum, estimated_delivery_minutes: eta, is_active: true,
});
export const demoDeliveryZones: DeliveryZone[] = [
  zone(1, 5, 'Entro 3 km', 0, 3, 2.5, 15, 25),
  zone(2, 5, 'Da 3 a 6 km', 3, 6, 4, 20, 35),
  zone(3, 5, 'Da 6 a 10 km', 6, 10, 6, 25, 45),
];

const R = (n: number) => fixedId('restaurant', n);
const FROM = '2026-09-01T00:00:00.000Z';
const offer = (n: number, restaurant: number, o: Partial<Offer> & Pick<Offer, 'title' | 'offer_type' | 'discount_type'>): Offer => ({
  id: fixedId('offer', n), restaurant_id: R(restaurant), description: null, discount_value: null, minimum_spend: null, image_url: null,
  days_of_week: [], start_time: null, end_time: null, starts_at: FROM, ends_at: '2027-06-30T22:00:00.000Z', terms: 'Offerta DEMO.',
  is_active: true, is_featured: false, max_redemptions: null, redemptions_count: 0, ...o,
});

export const demoOffers: Offer[] = [
  offer(1, 1, { title: 'Martedì AYCE a € 22,90', description: 'Formula All You Can Eat a cena a prezzo ridotto ogni martedì.', offer_type: 'ayce_promo', discount_type: 'fixed_price', discount_value: 22.9, days_of_week: [2], terms: 'Bevande escluse. Offerta DEMO.', is_featured: true }),
  offer(2, 1, { title: 'Happy hour: uramaki a metà prezzo', description: 'Tutti gli uramaki da 8 pezzi a metà prezzo, dal mercoledì al venerdì.', offer_type: 'happy_hour', discount_type: 'percent', discount_value: 50, days_of_week: [3, 4, 5], start_time: '18:30', end_time: '20:00' }),
  offer(3, 2, { title: 'Ramen + gyoza a € 16', description: 'Un ramen a scelta con 5 gyoza, a pranzo dal martedì al venerdì.', offer_type: 'special_menu', discount_type: 'fixed_price', discount_value: 16, days_of_week: [2, 3, 4, 5], start_time: '12:00', end_time: '15:00', ends_at: '2027-03-31T22:00:00.000Z', terms: 'Solo a pranzo. Offerta DEMO.' }),
  offer(4, 5, { title: '2x1 sul bibimbap', description: 'Ordina due bibimbap: il secondo è in omaggio.', offer_type: 'two_for_one', discount_type: 'free_item', days_of_week: [1, 2, 3, 4], ends_at: '2026-12-31T22:00:00.000Z', terms: 'Sul piatto di valore inferiore. Offerta DEMO.' }),
  offer(5, 8, { title: 'Bambini under 10 a € 12', description: 'Formula AYCE ridotta per i più piccoli, a pranzo e cena.', offer_type: 'ayce_promo', discount_type: 'fixed_price', discount_value: 12 }),
  offer(6, 15, { title: 'Calice di benvenuto', description: 'Un calice di prosecco in omaggio con una spesa di almeno € 40.', offer_type: 'free_dish', discount_type: 'free_item', minimum_spend: 40, terms: 'Un calice a persona. Offerta DEMO.' }),
];

const coupon = (n: number, restaurant: number, c: Partial<Coupon> & Pick<Coupon, 'code' | 'title' | 'discount_type'>): Coupon => ({
  id: fixedId('coupon', n), restaurant_id: R(restaurant), offer_id: null, description: null, discount_value: null, minimum_spend: null,
  max_redemptions: null, max_redemptions_per_user: 1, claims_count: 0, redemptions_count: 0, valid_from: FROM,
  valid_until: '2027-06-30T22:00:00.000Z', terms: 'Coupon DEMO, non valido.', is_active: true, ...c,
});

export const demoCoupons: Coupon[] = [
  coupon(1, 1, { code: 'KAIZEN10', title: '-10% sul conto', description: 'Mostra il codice alla cassa.', discount_type: 'percent', discount_value: 10, minimum_spend: 30, max_redemptions: 200, terms: 'Non cumulabile con altre offerte. Coupon DEMO, non valido.' }),
  coupon(2, 5, { code: 'SEOUL5', title: '€ 5 di sconto', description: 'Su una spesa di almeno € 25.', discount_type: 'amount', discount_value: 5, minimum_spend: 25 }),
  coupon(3, 8, { code: 'HANAMIDOLCE', title: 'Dolce in omaggio', description: 'Un dolce della casa ogni due formule AYCE.', discount_type: 'free_item', max_redemptions: 100 }),
];

// ─── Prenotazioni demo (date relative a oggi: calcolate all'avvio o nel seed SQL) ───
export interface DemoReservationSeed {
  restaurant: number;
  dayOffset: number;
  time: string;
  party: number;
  name: string;
  surname: string;
  status: 'pending' | 'confirmed' | 'completed' | 'no_show' | 'cancelled' | 'rejected';
  code: string;
  notes?: string;
  /** Prenotazione del cliente demo (visibile in "Le mie prenotazioni"). */
  customer?: boolean;
  source?: 'web' | 'restaurant';
}

export const demoReservationSeeds: DemoReservationSeed[] = [
  { restaurant: 5, dayOffset: 0, time: '20:00', party: 4, name: 'Giulia', surname: 'Esempio', status: 'confirmed', code: 'ASF-DM001', notes: 'Serve un seggiolone.' },
  { restaurant: 5, dayOffset: 0, time: '21:00', party: 2, name: 'Marco', surname: 'Prova', status: 'pending', code: 'ASF-DM002' },
  { restaurant: 5, dayOffset: 1, time: '20:30', party: 6, name: 'Sara', surname: 'Demo', status: 'pending', code: 'ASF-DM003', notes: 'Compleanno: possiamo portare una torta?' },
  { restaurant: 5, dayOffset: 1, time: '19:30', party: 2, name: 'Luca', surname: 'Fittizio', status: 'confirmed', code: 'ASF-DM004', source: 'restaurant' },
  { restaurant: 5, dayOffset: 3, time: '20:00', party: 4, name: 'Anna', surname: 'Esempio', status: 'confirmed', code: 'ASF-DM005' },
  { restaurant: 5, dayOffset: 5, time: '21:00', party: 8, name: 'Paolo', surname: 'Prova', status: 'pending', code: 'ASF-DM006', notes: 'Tavolo unico se possibile.' },
  { restaurant: 5, dayOffset: -1, time: '20:00', party: 2, name: 'Elena', surname: 'Demo', status: 'completed', code: 'ASF-DM007' },
  { restaurant: 5, dayOffset: -2, time: '21:00', party: 4, name: 'Davide', surname: 'Fittizio', status: 'no_show', code: 'ASF-DM008' },
  { restaurant: 5, dayOffset: -3, time: '20:30', party: 3, name: 'Chiara', surname: 'Esempio', status: 'cancelled', code: 'ASF-DM009' },
  { restaurant: 1, dayOffset: 4, time: '20:00', party: 2, name: 'Cliente', surname: 'Demo', status: 'confirmed', code: 'ASF-DM010', customer: true },
  { restaurant: 1, dayOffset: 2, time: '13:00', party: 5, name: 'Franco', surname: 'Prova', status: 'confirmed', code: 'ASF-DM011' },
];

/** Fasce di prenotazione: pranzo e cena nei giorni di apertura (dagli orari demo). */
export interface DemoSlotSeed { restaurant: number; day: number; start: string; end: string; interval: number; maxRes: number; maxGuests: number; label: string }
export const demoReservationSettings: { restaurant: number; auto_confirm: boolean; max_party: number; notice: number; message: string | null }[] = [
  { restaurant: 1, auto_confirm: true, max_party: 10, notice: 60, message: 'Il tavolo viene tenuto per 15 minuti dall’orario prenotato.' },
  { restaurant: 5, auto_confirm: false, max_party: 12, notice: 120, message: 'Per gruppi oltre 12 persone chiamaci.' },
  { restaurant: 8, auto_confirm: true, max_party: 8, notice: 60, message: null },
  { restaurant: 15, auto_confirm: false, max_party: 8, notice: 180, message: 'Terrazza soggetta al meteo.' },
];
export const demoReservationSlots: DemoSlotSeed[] = demoReservationSettings.flatMap(({ restaurant }) => {
  const rid = R(restaurant);
  const days = [1, 2, 3, 4, 5, 6, 7].filter((d) => !demoHours.some((h) => h.restaurant_id === rid && h.day_of_week === d && h.is_closed));
  return days.flatMap((d) => {
    const hasLunch = demoHours.some((h) => h.restaurant_id === rid && h.day_of_week === d && h.label === 'Pranzo');
    const dinner: DemoSlotSeed = { restaurant, day: d, start: '19:30', end: '22:00', interval: 30, maxRes: 4, maxGuests: 40, label: 'Cena' };
    return hasLunch ? [{ restaurant, day: d, start: '12:30', end: '14:00', interval: 30, maxRes: 3, maxGuests: 24, label: 'Pranzo' }, dinner] : [dinner];
  });
});
export const demoClosures: { restaurant: number; dayOffset: number; start: string | null; end: string | null; reason: string }[] = [
  { restaurant: 5, dayOffset: 9, start: null, end: null, reason: 'Evento privato (DEMO)' },
  { restaurant: 1, dayOffset: 6, start: '12:00', end: '15:00', reason: 'Pranzo riservato a un gruppo (DEMO)' },
];

/** Coupon già ottenuti (DEMO): uno del cliente demo, uno già utilizzato. */
export const demoCouponClaims: { coupon: number; code: string; customer?: boolean; email?: string; redeemedDaysAgo?: number; claimedDaysAgo: number }[] = [
  { coupon: 1, code: 'KAIZEN10-DM01', customer: true, claimedDaysAgo: 2 },
  { coupon: 2, code: 'SEOUL5-DM02', email: 'luca.demo@example.com', claimedDaysAgo: 5, redeemedDaysAgo: 3 },
  { coupon: 2, code: 'SEOUL5-DM03', email: 'sara.demo@example.com', claimedDaysAgo: 1 },
];

/**
 * Campagne sponsorizzate DEMO (AsiaFood Ads). Stessi ID delle sponsorizzazioni Fase 1,
 * così la migrazione e il seed restano coerenti. Etichetta "Sponsorizzato" sempre visibile.
 */
const campaign = (n: number, restaurant: number, name: string, placement: SponsoredCampaign['placement'], extra: Partial<SponsoredCampaign> = {}): SponsoredCampaign => ({
  id: fixedId('sponsored', n),
  restaurant_id: R(restaurant),
  name: `DEMO — ${name}`,
  status: 'active',
  placement,
  start_date: '2026-09-01',
  end_date: '2027-06-30',
  daily_budget: null,
  total_budget: null,
  spend: 0,
  priority: 10,
  target_cities: [],
  target_categories: [],
  notes: null,
  created_at: '2026-09-01T08:00:00.000Z',
  updated_at: '2026-09-01T08:00:00.000Z',
  ...extra,
});
export const demoCampaigns: SponsoredCampaign[] = [
  campaign(1, 1, 'Lancio Taranto', 'home_featured', { total_budget: 300, spend: 0 }),
  campaign(2, 1, 'Ricerca Taranto', 'search_top', { target_cities: [cities[0].id] }),
  campaign(3, 5, 'Offerte in evidenza', 'offers_featured', { priority: 5 }),
  campaign(4, 8, 'Mappa Taranto', 'map_featured', { priority: 5, target_cities: [cities[0].id] }),
  campaign(5, 2, 'Promo estate (conclusa)', 'home_featured', { status: 'ended', start_date: '2026-07-01', end_date: '2026-08-31' }),
  campaign(6, 5, 'Categoria coreano (bozza)', 'category_top', { status: 'draft', priority: 3 }),
];

/**
 * Piani DEMO: concessioni Admin (source = 'admin'), mai finti abbonamenti Stripe.
 * Il piano del locale deriva sempre dagli abbonamenti (vedi restaurant_effective_plan).
 */
export const demoSubscriptions: Subscription[] = Object.entries(PLAN_BY_RESTAURANT).map(([n, plan], i) => ({
  id: fixedId('subscription', i + 1),
  restaurant_id: R(Number(n)),
  user_id: null,
  billing_account_id: null,
  plan_id: null,
  plan_code: plan,
  status: 'active',
  source: 'admin',
  billing_interval: 'month',
  stripe_customer_id: null,
  stripe_subscription_id: null,
  stripe_price_id: null,
  stripe_environment: null,
  trial_start: null,
  trial_end: null,
  current_period_start: '2026-09-01T08:00:00.000Z',
  current_period_end: null,
  cancel_at_period_end: false,
  cancelled_at: null,
  ended_at: null,
  expires_at: null,
  revoked_at: null,
  unit_amount_cents: null,
  currency: 'EUR',
  payment_failed_at: null,
  paid_started_at: null,
  pm_brand: null,
  pm_last4: null,
  pm_exp_month: null,
  pm_exp_year: null,
  latest_invoice_id: null,
  latest_invoice_status: null,
  scheduled_plan_code: null,
  scheduled_interval: null,
  scheduled_change_at: null,
  stripe_schedule_id: null,
  trial_expiring_notified_at: null,
  last_synced_at: null,
  notes: 'DEMO — piano concesso per la dimostrazione',
  created_at: '2026-09-01T08:00:00.000Z',
  updated_at: '2026-09-01T08:00:00.000Z',
}));
