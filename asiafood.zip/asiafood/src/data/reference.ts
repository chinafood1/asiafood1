// ─────────────────────────────────────────────────────────────
//  Dati di riferimento (produzione): regioni, province, comuni,
//  categorie, piani. Fonte unica → migrazione SQL + modalità demo.
//  Espansione: aggiungere province/comuni qui (o importare il
//  dataset ISTAT completo) senza toccare il codice applicativo.
// ─────────────────────────────────────────────────────────────
import type { Category, City, PlanFeature, Province, Region, SubscriptionPlan } from '@/types/domain';
import { fixedId } from './ids';

const REGION_NAMES: [code: string, name: string, slug: string][] = [
  ['01', 'Piemonte', 'piemonte'],
  ['02', "Valle d'Aosta", 'valle-d-aosta'],
  ['03', 'Lombardia', 'lombardia'],
  ['04', 'Trentino-Alto Adige', 'trentino-alto-adige'],
  ['05', 'Veneto', 'veneto'],
  ['06', 'Friuli-Venezia Giulia', 'friuli-venezia-giulia'],
  ['07', 'Liguria', 'liguria'],
  ['08', 'Emilia-Romagna', 'emilia-romagna'],
  ['09', 'Toscana', 'toscana'],
  ['10', 'Umbria', 'umbria'],
  ['11', 'Marche', 'marche'],
  ['12', 'Lazio', 'lazio'],
  ['13', 'Abruzzo', 'abruzzo'],
  ['14', 'Molise', 'molise'],
  ['15', 'Campania', 'campania'],
  ['16', 'Puglia', 'puglia'],
  ['17', 'Basilicata', 'basilicata'],
  ['18', 'Calabria', 'calabria'],
  ['19', 'Sicilia', 'sicilia'],
  ['20', 'Sardegna', 'sardegna'],
];

export const regions: Region[] = REGION_NAMES.map(([code, name, slug], i) => ({
  id: fixedId('region', Number(code)),
  name,
  slug,
  code,
  country_code: 'IT',
  // Solo la Puglia è attiva al lancio; le altre si attivano dall'Admin.
  is_active: slug === 'puglia',
  sort_order: i,
}));

const PUGLIA = fixedId('region', 16);

const PROVINCE_DATA: [n: number, name: string, slug: string, code: string][] = [
  [1, 'Taranto', 'provincia-di-taranto', 'TA'],
  [2, 'Bari', 'citta-metropolitana-di-bari', 'BA'],
  [3, 'Brindisi', 'provincia-di-brindisi', 'BR'],
  [4, 'Lecce', 'provincia-di-lecce', 'LE'],
  [5, 'Foggia', 'provincia-di-foggia', 'FG'],
  [6, 'Barletta-Andria-Trani', 'provincia-bat', 'BT'],
];

export const provinces: Province[] = PROVINCE_DATA.map(([n, name, slug, code]) => ({
  id: fixedId('province', n),
  region_id: PUGLIA,
  name,
  slug,
  code,
  is_active: code === 'TA',
}));

const TARANTO_PROV = fixedId('province', 1);

// Coordinate approssimative del centro comunale (centroidi indicativi: usati solo
// come fallback per mappa e "vicino a te", mai come indirizzo di un locale).
// Provincia di Taranto completa: 29 comuni.
const CITY_DATA: [n: number, name: string, slug: string, cap: string, lat: number, lng: number][] = [
  [1, 'Taranto', 'taranto', '74121', 40.4644, 17.247],
  [2, 'Massafra', 'massafra', '74016', 40.5875, 17.1128],
  [3, 'Martina Franca', 'martina-franca', '74015', 40.7056, 17.3361],
  [4, 'Grottaglie', 'grottaglie', '74023', 40.5363, 17.4368],
  [5, 'Manduria', 'manduria', '74024', 40.402, 17.634],
  [6, 'Castellaneta', 'castellaneta', '74011', 40.629, 16.938],
  [7, 'Ginosa', 'ginosa', '74013', 40.578, 16.757],
  [8, 'Laterza', 'laterza', '74014', 40.626, 16.8],
  [9, 'Palagiano', 'palagiano', '74019', 40.578, 17.04],
  [10, 'Mottola', 'mottola', '74017', 40.634, 17.038],
  [11, 'Pulsano', 'pulsano', '74026', 40.383, 17.354],
  [12, 'Leporano', 'leporano', '74020', 40.382, 17.334],
  [13, 'San Giorgio Ionico', 'san-giorgio-ionico', '74027', 40.459, 17.379],
  // Fase 2: resto della provincia
  [14, 'Statte', 'statte', '74010', 40.564, 17.206],
  [15, 'Monteiasi', 'monteiasi', '74020', 40.5, 17.383],
  [16, 'Montemesola', 'montemesola', '74020', 40.568, 17.336],
  [17, 'Carosino', 'carosino', '74021', 40.466, 17.398],
  [18, 'Faggiano', 'faggiano', '74020', 40.42, 17.388],
  [19, 'Fragagnano', 'fragagnano', '74022', 40.434, 17.472],
  [20, 'Lizzano', 'lizzano', '74020', 40.391, 17.447],
  [21, 'Torricella', 'torricella', '74020', 40.356, 17.5],
  [22, 'Maruggio', 'maruggio', '74020', 40.322, 17.572],
  [23, 'Sava', 'sava', '74028', 40.403, 17.556],
  [24, 'Avetrana', 'avetrana', '74020', 40.353, 17.733],
  [25, 'Monteparano', 'monteparano', '74020', 40.444, 17.414],
  [26, 'San Marzano di San Giuseppe', 'san-marzano-di-san-giuseppe', '74020', 40.454, 17.505],
  [27, 'Roccaforzata', 'roccaforzata', '74020', 40.438, 17.389],
  [28, 'Crispiano', 'crispiano', '74012', 40.604, 17.23],
  [29, 'Palagianello', 'palagianello', '74018', 40.609, 16.978],
];

export const cities: City[] = CITY_DATA.map(([n, name, slug, cap, lat, lng]) => ({
  id: fixedId('city', n),
  province_id: TARANTO_PROV,
  region_id: PUGLIA,
  name,
  slug,
  istat_code: null,
  postal_code: cap,
  latitude: lat,
  longitude: lng,
  population: null,
  is_active: true,
  is_launch_market: true,
}));

const CATEGORY_DATA: [n: number, name: string, slug: string, emoji: string, desc: string][] = [
  [1, 'Sushi', 'sushi', '🍣', 'Nigiri, uramaki, sashimi e roll creativi.'],
  [2, 'Giapponese', 'giapponese', '🍱', 'Cucina giapponese tradizionale e contemporanea.'],
  [3, 'Cinese', 'cinese', '🥢', 'Ravioli, noodles, wok e specialità regionali cinesi.'],
  [4, 'Thai', 'thai', '🌶️', 'Pad thai, curry e sapori del sud-est asiatico.'],
  [5, 'Coreano', 'coreano', '🥩', 'Barbecue coreano, bibimbap e kimchi.'],
  [6, 'Poke', 'poke', '🥗', 'Bowl hawaiane fresche e personalizzabili.'],
  [7, 'Ramen', 'ramen', '🍜', 'Brodi lenti, noodles fatti a mano e topping.'],
  [8, 'Asian Fusion', 'fusion', '✨', 'Contaminazioni creative tra Asia e Mediterraneo.'],
  [9, 'Asian Street Food', 'street-food', '🥟', 'Bao, gyoza, dumpling e snack da strada.'],
  [10, 'All You Can Eat', 'all-you-can-eat', '♾️', 'Formula a prezzo fisso, pranzo e cena.'],
  // Fase 2: categorie accessorie (solo se pertinenti alla cucina asiatica)
  [11, 'Bubble Tea', 'bubble-tea', '🧋', 'Tè al latte, perle di tapioca e bevande asiatiche.'],
  [12, 'Asian Bakery', 'asian-bakery', '🥮', 'Dolci e prodotti da forno della tradizione asiatica.'],
  [13, 'Asian Grocery', 'asian-grocery', '🛒', 'Alimentari asiatici con cucina o somministrazione.'],
];

export const categories: Category[] = CATEGORY_DATA.map(([n, name, slug, emoji, desc], i) => ({
  id: fixedId('category', n),
  name,
  slug,
  emoji,
  description: desc,
  seo_title: null,
  seo_description: null,
  image_url: null,
  sort_order: i,
  is_active: true,
}));

// ─── Piani (Fase 4). Stessi valori della migrazione 0012: l'Admin li modifica da /admin/plans ───
type Tier = [free: boolean | number | null, business: boolean | number | null, premium: boolean | number | null, top: boolean | number | null];
/** true/false = funzione attiva/disattiva; numero = limite; null = illimitato (funzione attiva). */
export const PLAN_FEATURE_MATRIX: Record<string, Tier> = {
  profile_full: [false, true, true, true],
  menu_enabled: [false, true, true, true],
  max_menu_items: [false, 150, null, null],
  max_images: [3, 15, 40, null],
  whatsapp_enabled: [false, true, true, true],
  analytics_enabled: [false, true, true, true],
  advanced_analytics: [false, false, true, true],
  offers_enabled: [false, true, true, true],
  max_active_offers: [false, 2, 10, null],
  coupons_enabled: [false, false, true, true],
  max_active_coupons: [false, false, 5, null],
  reservations_enabled: [false, false, true, true],
  premium_badge: [false, false, true, true],
  search_boost: [false, false, 1, 2],
  featured_listing: [false, false, false, true],
  sponsored_ads: [false, false, false, true],
  marketing_tools: [false, false, false, true],
  // Fase 7: campagne del ristoratore (notifiche in-app/push, invio fatto dalla piattaforma)
  push_campaigns_enabled: [false, false, true, true],
  monthly_campaign_limit: [false, false, 2, 8],
};

const PLAN_CODES = ['free', 'business', 'premium', 'top'] as const;

export const planFeatures: PlanFeature[] = PLAN_CODES.flatMap((code, t) =>
  Object.entries(PLAN_FEATURE_MATRIX).map(([key, tiers], k) => {
    const v = tiers[t];
    return {
      id: fixedId('planFeature', t * 100 + k + 1),
      plan_code: code,
      feature_key: key,
      enabled: v !== false,
      limit_value: typeof v === 'number' ? v : null,
    };
  }),
);

const featuresJson = (code: string) =>
  Object.fromEntries(
    planFeatures
      .filter((f) => f.plan_code === code)
      .map((f) => [f.feature_key, !f.enabled ? false : f.limit_value ?? true]),
  );

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: fixedId('plan', 1),
    code: 'free',
    name: 'Free',
    description: 'Scheda base: telefono, indirizzo, categorie, orari e presenza nella ricerca.',
    monthly_price: 0,
    yearly_price: 0,
    currency: 'EUR',
    features: featuresJson('free'),
    sort_order: 0,
    is_active: true,
  },
  {
    id: fixedId('plan', 2),
    code: 'business',
    name: 'Business',
    description: 'Profilo completo, menu digitale, galleria, WhatsApp, offerte e statistiche base.',
    monthly_price: 29.9,
    yearly_price: 299,
    currency: 'EUR',
    features: featuresJson('business'),
    sort_order: 1,
    is_active: true,
  },
  {
    id: fixedId('plan', 3),
    code: 'premium',
    name: 'Premium',
    description: 'Tutto Business + prenotazioni, coupon, statistiche avanzate, più visibilità e badge Premium.',
    monthly_price: 59.9,
    yearly_price: 599,
    currency: 'EUR',
    features: featuresJson('premium'),
    sort_order: 2,
    is_active: true,
  },
  {
    id: fixedId('plan', 4),
    code: 'top',
    name: 'Top',
    description: 'Tutto Premium + sponsorizzazione prioritaria, campagne promozionali e posizionamento in evidenza.',
    monthly_price: 99.9,
    yearly_price: 999,
    currency: 'EUR',
    features: featuresJson('top'),
    sort_order: 3,
    is_active: true,
  },
];
