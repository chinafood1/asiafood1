// Filtri ⇄ query string, condivisi da Esplora (/restaurants) e Mappa (/map).
// Gli alias italiani della Fase 1 (categoria, citta, …) restano leggibili.
import type { FilterState } from '@/components/search/FiltersPanel';
import type { SortKey } from '@/services';

export type ExploreView = 'card' | 'list' | 'map';

const bool = (v: string | null) => (v === '1' || v === 'true' ? true : undefined);
const get = (p: URLSearchParams, ...keys: string[]) => keys.map((k) => p.get(k)).find((v) => v !== null && v !== '') ?? null;

export function filtersFromParams(p: URLSearchParams): FilterState & { view: ExploreView } {
  return {
    q: get(p, 'q') ?? undefined,
    categorySlug: get(p, 'category', 'categoria') ?? undefined,
    citySlug: get(p, 'city', 'citta') ?? undefined,
    priceRanges: get(p, 'price', 'prezzo')?.split(',').map(Number).filter(Boolean),
    ayce: bool(get(p, 'ayce')),
    delivery: bool(get(p, 'delivery')),
    takeaway: bool(get(p, 'takeaway', 'asporto')),
    reservation: bool(get(p, 'reservation', 'prenotazione')),
    openNow: bool(get(p, 'open', 'aperto')),
    hasOffers: bool(get(p, 'offers', 'offerte')),
    featured: bool(get(p, 'featured', 'evidenza')),
    verified: bool(get(p, 'verified')),
    orderMode: ((v) => (v === 'now' || v === 'takeaway' || v === 'delivery' ? v : undefined))(get(p, 'order')),
    radiusKm: get(p, 'km') ? Number(get(p, 'km')) : undefined,
    useLocation: bool(get(p, 'near', 'vicino')),
    sort: (get(p, 'sort', 'ordina') as SortKey) ?? undefined,
    view: (get(p, 'view', 'vista') as ExploreView) ?? 'card',
  };
}

export function filtersToParams(f: FilterState & { view?: ExploreView }, extra: Record<string, string | undefined> = {}): URLSearchParams {
  const p = new URLSearchParams();
  const put = (k: string, v: unknown) => v !== undefined && v !== '' && v !== false && v !== null && p.set(k, v === true ? '1' : String(v));
  put('q', f.q);
  put('category', f.categorySlug);
  put('city', f.citySlug);
  if (f.priceRanges?.length) p.set('price', f.priceRanges.join(','));
  put('ayce', f.ayce);
  put('delivery', f.delivery);
  put('takeaway', f.takeaway);
  put('reservation', f.reservation);
  put('open', f.openNow);
  put('offers', f.hasOffers);
  put('featured', f.featured);
  put('verified', f.verified);
  put('order', f.orderMode);
  put('km', f.radiusKm);
  put('near', f.useLocation || !!f.radiusKm);
  if (f.sort && f.sort !== 'relevance') p.set('sort', f.sort);
  if (f.view && f.view !== 'card' && f.view !== 'map') p.set('view', f.view);
  Object.entries(extra).forEach(([k, v]) => v && p.set(k, v));
  return p;
}
