import type { RestaurantHour } from '@/types/domain';

export const DAY_NAMES = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'];
export const DAY_SHORT = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];

/** Giorno ISO (1–7) e minuti dalla mezzanotte nel fuso del ristorante. */
export function zonedNow(timezone = 'Europe/Rome', now = new Date()): { day: number; minutes: number } {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: timezone,
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(now);
  const wd = parts.find((p) => p.type === 'weekday')?.value ?? 'Mon';
  const h = Number(parts.find((p) => p.type === 'hour')?.value ?? 0) % 24;
  const m = Number(parts.find((p) => p.type === 'minute')?.value ?? 0);
  const day = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].indexOf(wd) + 1;
  return { day, minutes: h * 60 + m };
}

export const toMinutes = (t: string | null) => {
  if (!t) return 0;
  const [h, m] = t.split(':').map(Number);
  return (h ?? 0) * 60 + (m ?? 0);
};

export const shortTime = (t: string | null) => (t ? t.slice(0, 5) : '');

const prevDay = (d: number) => (d === 1 ? 7 : d - 1);
const nextDay = (d: number) => (d === 7 ? 1 : d + 1);

export type OpenState =
  | { kind: 'unknown' }
  | { kind: 'open'; closesAt: string; closingSoon: boolean }
  | { kind: 'closed'; opensAt?: string; opensDay?: number };

/** Calcola lo stato apertura, gestendo fasce multiple e orari oltre la mezzanotte. */
export function openState(hours: RestaurantHour[], timezone = 'Europe/Rome', now = new Date()): OpenState {
  const slots = hours.filter((h) => !h.is_closed && h.opens_at && h.closes_at);
  if (!hours.length) return { kind: 'unknown' };
  const { day, minutes } = zonedNow(timezone, now);

  for (const s of slots) {
    const o = toMinutes(s.opens_at);
    const c = toMinutes(s.closes_at);
    const overnight = c <= o;
    let remaining = -1;
    if (s.day_of_week === day) {
      if (!overnight && minutes >= o && minutes < c) remaining = c - minutes;
      if (overnight && minutes >= o) remaining = 24 * 60 - minutes + c;
    }
    if (overnight && s.day_of_week === prevDay(day) && minutes < c) remaining = c - minutes;
    if (remaining >= 0) return { kind: 'open', closesAt: shortTime(s.closes_at), closingSoon: remaining <= 45 };
  }

  // Prossima apertura (fino a 7 giorni)
  for (let i = 0; i < 8; i++) {
    let d = day;
    for (let k = 0; k < i; k++) d = nextDay(d);
    const upcoming = slots
      .filter((s) => s.day_of_week === d && (i > 0 || toMinutes(s.opens_at) > minutes))
      .sort((a, b) => toMinutes(a.opens_at) - toMinutes(b.opens_at));
    if (upcoming[0]) return { kind: 'closed', opensAt: shortTime(upcoming[0].opens_at), opensDay: i === 0 ? undefined : d };
  }
  return { kind: 'closed' };
}

export const isOpenNow = (hours: RestaurantHour[], tz?: string) => openState(hours, tz).kind === 'open';

export function openStateLabel(state: OpenState): string {
  switch (state.kind) {
    case 'open':
      return state.closingSoon ? `Chiude alle ${state.closesAt}` : `Aperto · chiude alle ${state.closesAt}`;
    case 'closed':
      if (!state.opensAt) return 'Chiuso';
      if (!state.opensDay) return `Chiuso · apre alle ${state.opensAt}`;
      return `Chiuso · apre ${DAY_SHORT[state.opensDay - 1]!.toLowerCase()} ${state.opensAt}`;
    default:
      return 'Orari non disponibili';
  }
}

/** Raggruppa gli orari per giorno, ordinati. */
export function hoursByDay(hours: RestaurantHour[]) {
  return Array.from({ length: 7 }, (_, i) => {
    const d = i + 1;
    const rows = hours.filter((h) => h.day_of_week === d).sort((a, b) => toMinutes(a.opens_at) - toMinutes(b.opens_at));
    const closed = rows.length === 0 || rows.every((r) => r.is_closed);
    return { day: d, name: DAY_NAMES[i]!, closed, slots: rows.filter((r) => !r.is_closed) };
  });
}
