// ─────────────────────────────────────────────────────────────
//  Fase 12 · Template modificabili per stampa, email e social.
//  Menzionano SOLO funzioni attive (flag reali) e numeri reali passati dal chiamante.
//  Nessun invio automatico: si copiano e si inviano da una persona.
// ─────────────────────────────────────────────────────────────
export interface ActiveFeatures { orders: boolean; ai: boolean; reviews: boolean; loyalty: boolean; reservations: boolean; delivery: boolean }

function features(f: ActiveFeatures): string[] {
  return [
    'scoprire i ristoranti di cucina asiatica sulla mappa e per categoria (sushi, giapponese, cinese, poke, ramen, All You Can Eat)',
    'consultare menu, orari, prezzi e offerte',
    f.reservations ? 'prenotare un tavolo nei locali che lo consentono' : null,
    f.orders ? 'ordinare da asporto' + (f.delivery ? ' o con consegna' : '') + ' nei locali che lo consentono' : null,
    f.reviews ? 'leggere e scrivere recensioni verificate' : null,
    f.loyalty ? 'accumulare AsiaPoints e invitare gli amici' : null,
    f.ai ? 'chiedere consiglio all’assistente AI, che risponde solo con i dati presenti sulla piattaforma' : null,
  ].filter(Boolean) as string[];
}

export function pressRelease(o: { app: string; restaurants: number; cities: number; features: ActiveFeatures; company?: string | null; contact?: string | null }) {
  const list = features(o.features).map((x) => `– ${x};`).join('\n');
  return `COMUNICATO STAMPA — BOZZA (da verificare prima dell’invio)

Nasce ${o.app}, la piattaforma dedicata alla cucina asiatica di Taranto e provincia

Taranto, [data] — Debutta ${o.app}, una piattaforma web installabile come app, pensata esclusivamente per chi cerca cucina asiatica a Taranto e provincia. Al lancio sono presenti ${o.restaurants} locali in ${o.cities} comuni [verificare i numeri il giorno dell’invio].

Con ${o.app} è possibile:
${list}

Per i ristoratori la scheda è gratuita e può essere rivendicata per gestire in autonomia menu, orari, foto, offerte e statistiche.

[Citazione del fondatore — da scrivere e approvare]

Contatti stampa: ${o.contact ?? '[email/telefono]'}
${o.company ?? '[Ragione sociale]'}`;
}

export function launchEmailUsers(o: { app: string; url: string; features: ActiveFeatures }) {
  return {
    subject: `${o.app} è arrivata a Taranto`,
    body: `Ciao,

${o.app} è arrivata a Taranto: tutta la cucina asiatica della città e della provincia in un unico posto.

Cosa puoi fare:
${features(o.features).map((x) => `• ${x.charAt(0).toUpperCase()}${x.slice(1)}`).join('\n')}

Scopri i ristoranti: ${o.url}

Ricevi questa email perché hai scelto di ricevere comunicazioni da ${o.app}. Puoi disiscriverti in qualsiasi momento dalle impostazioni del profilo.`,
    note: 'Solo destinatari con consenso marketing (opt-in). Segmentare per comune/interessi; mai a chi ha revocato il consenso.',
  };
}

export function restaurantNewsletter(o: { app: string; dashboardUrl: string }) {
  return {
    subject: `${o.app} per i ristoratori — novità del mese`,
    body: `Buongiorno,

ecco le novità di ${o.app} per i ristoranti partner:

1. Novità della piattaforma: [elencare solo funzioni rilasciate]
2. Consiglio del mese: [es. aggiornare le foto dei piatti principali; creare un’offerta per la pausa pranzo]
3. Le vostre statistiche: visite, chiamate, indicazioni e prenotazioni sono nella dashboard → ${o.dashboardUrl}

Per domande: rispondete a questa email o scriveteci dalla pagina Supporto.`,
    note: 'Separata dalle comunicazioni ai clienti. Destinatari: titolari e membri dei locali rivendicati (comunicazione di servizio); contenuti promozionali solo con consenso.',
  };
}

export const UGC_GUIDELINES = [
  'Invito pubblico: “Tagga @AsiaFood quando provi un ristorante.”',
  'Prima di ripubblicare: chiedere il permesso all’autore (messaggio scritto) e salvarlo; indicare sempre l’autore.',
  'Nel calendario contenuti: spuntare “Permesso dell’autore confermato”, altrimenti il contenuto resta bozza.',
  'Mai foto con volti riconoscibili di terzi senza consenso; mai contenuti di minori.',
];

export const SPOTLIGHT_RULES = [
  'Formato “Ristorante della settimana” / “Scopri [Ristorante]”: solo locali che hanno dato il consenso e con dati verificati.',
  'Se il ristorante paga o riceve un vantaggio per il contenuto: etichetta “Sponsorizzato” / #adv obbligatoria (il sistema blocca l’approvazione senza).',
  'Niente superlativi non verificabili (“il migliore di Taranto”); descrivere fatti (menu, specialità, servizi).',
];

/** Checklist di conformità prima di un giveaway/concorso (da validare con un consulente). */
export const GIVEAWAY_CHECKLIST = [
  'Verificare con un consulente se l’iniziativa è una “manifestazione a premio” (DPR 430/2001) o rientra nelle esclusioni.',
  'Se è un concorso a premio: regolamento, eventuale comunicazione al Ministero delle Imprese e del Made in Italy, cauzione/fideiussione, verbalizzazione dell’estrazione (notaio o funzionario camerale) — secondo la consulenza.',
  'Regolamento pubblico con: promotore (dati societari reali), durata, area (Taranto e provincia), modalità, premi e valore, modalità di consegna, destinazione dei premi non assegnati.',
  'Regole della piattaforma social (Instagram/Facebook/TikTok): esonero di responsabilità della piattaforma, niente obbligo di taggare in modo ingannevole.',
  'Informativa privacy specifica per i partecipanti; dati minimi; nessuna partecipazione di minori salvo regole dedicate.',
  'Nessun obbligo di recensione positiva per partecipare (vietato).',
  'Solo dopo tutti i punti: spuntare “Checklist di conformità completata” nel contenuto.',
];

export const GEO_CAMPAIGNS = [
  { zone: 'Taranto centro', utm: 'taranto_centro' }, { zone: 'Talsano', utm: 'talsano' }, { zone: 'San Vito', utm: 'san_vito' },
  { zone: 'Massafra', utm: 'massafra' }, { zone: 'Martina Franca', utm: 'martina_franca' }, { zone: 'Grottaglie', utm: 'grottaglie' },
];
