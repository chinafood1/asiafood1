/**
 * Destinazione interna sicura per "?next=" (anti open redirect).
 * Solo percorsi relativi dell'app: niente "//host", "/\host" (normalizzato dai browser in "//"),
 * schemi (javascript:, data:), caratteri di controllo o sequenze codificate che li nascondono.
 */
const hasControlChars = (v: string) => [...v].some((c) => c.charCodeAt(0) < 32 || c.charCodeAt(0) === 127);

export function safeNext(n: string | null | undefined, fallback = '/profilo'): string {
  if (!n || n.length > 512) return fallback;
  let decoded = n;
  try {
    decoded = decodeURIComponent(n);
  } catch {
    return fallback;
  }
  for (const v of [n, decoded]) {
    if (!v.startsWith('/') || v.startsWith('//') || v.includes('\\') || hasControlChars(v) || /^\/+[a-z]+:/i.test(v)) return fallback;
  }
  return n;
}

const EXTERNAL_ALLOW = [/^https:\/\/checkout\.stripe\.com\//, /^https:\/\/billing\.stripe\.com\//, /^https:\/\/connect\.stripe\.com\//, /^https:\/\/dashboard\.stripe\.com\//];

/** URL di reindirizzamento ricevuti dal backend (Stripe): solo host attesi o stessa origine. */
export function safeAssign(url: string | null | undefined): boolean {
  if (!url) return false;
  const sameOrigin = typeof window !== 'undefined' && (url.startsWith('/') ? safeNext(url, '') === url : url.startsWith(`${window.location.origin}/`));
  if (!sameOrigin && !EXTERNAL_ALLOW.some((r) => r.test(url))) return false;
  window.location.assign(url);
  return true;
}
