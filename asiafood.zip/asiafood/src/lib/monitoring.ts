// ─────────────────────────────────────────────────────────────
//  Error tracking + Core Web Vitals lato browser.
//  - errori: sempre al log interno (/admin/system) con PII rimossa; Sentry solo se VITE_SENTRY_DSN
//    (caricato on-demand, sendDefaultPii=false, beforeSend con scrubbing, nessun replay)
//  - Web Vitals: solo con consenso "Statistiche", pagina "modello" (es. /ristorante/:slug), niente ID
// ─────────────────────────────────────────────────────────────
import { api } from '@/services';
import { hasConsent } from './consent';

const env = (import.meta.env ?? {}) as Record<string, string | undefined>;
const SENTRY_DSN = env.VITE_SENTRY_DSN ?? '';
export const APP_ENV = env.VITE_APP_ENV || (env.PROD ? 'production' : 'development');
const RELEASE = env.VITE_RELEASE || '';

export function scrubText(s: string): string {
  return s
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '[email]')
    .replace(/eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+/g, '[jwt]')
    .replace(/\b(sk|rk|pk|whsec)_(live|test)?_?[A-Za-z0-9]{8,}/g, '[key]')
    .replace(/([?&](t|token|key|sig|signature|access_token)=)[^&\s]+/gi, '$1[redacted]')
    .replace(/\+?\d[\d .-]{7,}\d/g, '[number]')
    .slice(0, 400);
}

/** Percorso senza identificativi (slug, numeri d'ordine, UUID). */
export function routeTemplate(path: string): string {
  return path
    .replace(/[?#].*$/, '')
    .replace(/\/ristorante\/[^/]+/, '/ristorante/:slug')
    .replace(/\/orders\/[^/]+/, '/orders/:number')
    .replace(/\/invite\/[^/]+/, '/invite/:code')
    .replace(/\/r\/[^/]+/, '/r/:slug')
    .replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, ':id')
    .slice(0, 80);
}

let recent: string[] = [];
function report(message: string, code?: string) {
  const key = `${code}|${message}`.slice(0, 200);
  if (recent.includes(key)) return; // niente raffiche dello stesso errore
  recent = [...recent.slice(-19), key];
  try {
    api.reportClientError({ message: scrubText(message), code: code?.slice(0, 60), route: routeTemplate(location.pathname), release: RELEASE, environment: APP_ENV });
  } catch {
    /* mai propagare errori del tracking */
  }
}

type SentryLike = { captureException(e: unknown): void };
let sentry: SentryLike | null = null;

async function initSentry() {
  if (!SENTRY_DSN) return;
  const S = await import('@sentry/browser');
  S.init({
    dsn: SENTRY_DSN,
    environment: env.VITE_SENTRY_ENVIRONMENT || APP_ENV,
    release: RELEASE || undefined,
    sendDefaultPii: false,
    tracesSampleRate: 0,
    integrations: [],
    beforeSend(event) {
      if (event.request) {
        delete event.request.cookies;
        delete event.request.headers;
        delete event.request.data;
        if (event.request.url) event.request.url = routeTemplate(new URL(event.request.url).pathname);
      }
      delete event.user;
      if (event.message) event.message = scrubText(event.message);
      for (const ex of event.exception?.values ?? []) if (ex.value) ex.value = scrubText(ex.value);
      event.breadcrumbs = (event.breadcrumbs ?? []).filter((b) => b.category !== 'console').map((b) => ({ ...b, message: b.message ? scrubText(b.message) : b.message, data: undefined }));
      return event;
    },
  });
  sentry = S;
}

export function captureError(e: unknown, code = 'ClientError') {
  const msg = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
  report(msg, code);
  sentry?.captureException(e);
}

let started = false;
export function initMonitoring() {
  if (started || typeof window === 'undefined') return;
  started = true;
  window.addEventListener('error', (ev) => {
    if (ev.error || ev.message) captureError(ev.error ?? ev.message, 'window.onerror');
  });
  window.addEventListener('unhandledrejection', (ev) => captureError(ev.reason, 'unhandledrejection'));
  // Caricamento differito: niente peso sul primo rendering
  const idle = (fn: () => void) => ('requestIdleCallback' in window ? (window as unknown as { requestIdleCallback(f: () => void): void }).requestIdleCallback(fn) : setTimeout(fn, 1500));
  idle(() => {
    void initSentry().catch(() => undefined);
    void initVitals();
  });
}

async function initVitals() {
  const { onLCP, onINP, onCLS, onFCP, onTTFB } = await import('web-vitals');
  const device: 'mobile' | 'desktop' = matchMedia('(max-width: 768px)').matches ? 'mobile' : 'desktop';
  const send = (m: { name: string; value: number; rating?: string }) => {
    if (!hasConsent('analytics')) return;
    api.recordWebVital({ metric: m.name as 'LCP', value: Math.round(m.value * (m.name === 'CLS' ? 1000 : 1)) / (m.name === 'CLS' ? 1000 : 1), rating: m.rating as 'good', route: routeTemplate(location.pathname), device });
  };
  onLCP(send);
  onINP(send);
  onCLS(send);
  onFCP(send);
  onTTFB(send);
}
