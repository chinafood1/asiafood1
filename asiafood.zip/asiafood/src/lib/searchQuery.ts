// ─────────────────────────────────────────────────────────────
//  Interpretazione della ricerca libera: "Sushi Taranto",
//  "Cinese Massafra", "All You Can Eat Martina Franca", "Ramen".
//  Estrae categoria e comune dal testo; ciò che resta è il nome
//  del locale. Nessuna dipendenza da alias "@/": usato anche dagli
//  script Node (import).
// ─────────────────────────────────────────────────────────────

export interface NamedSlug {
  name: string;
  slug: string;
}

/** Sinonimi (IT/EN) per slug di categoria. Estendibile senza toccare il resto. */
export const CATEGORY_SYNONYMS: Record<string, string[]> = {
  sushi: ['sushi', 'sushi bar', 'uramaki', 'nigiri', 'sashimi', 'temaki'],
  giapponese: ['giapponese', 'giapponesi', 'japanese', 'giappone', 'japan', 'jap', 'cucina giapponese', 'ristorante giapponese', 'izakaya'],
  cinese: ['cinese', 'cinesi', 'chinese', 'cina', 'china', 'cucina cinese', 'ristorante cinese'],
  thai: ['thai', 'thailandese', 'tailandese', 'thailandia', 'cucina thai', 'pad thai'],
  coreano: ['coreano', 'coreana', 'coreani', 'korean', 'corea', 'korea', 'kbbq', 'korean bbq'],
  poke: ['poke', 'poke bowl', 'pokebowl', 'poke bar'],
  ramen: ['ramen', 'ramen bar', 'ramenya'],
  fusion: ['fusion', 'asian fusion', 'fusion asiatica', 'cucina fusion'],
  'street-food': ['street food', 'streetfood', 'asian street food', 'street food asiatico', 'bao', 'dumpling', 'dumplings', 'gyoza'],
  'all-you-can-eat': ['all you can eat', 'all-you-can-eat', 'allyoucaneat', 'ayce', 'all u can eat', 'formula illimitata'],
  'bubble-tea': ['bubble tea', 'bubbletea', 'boba', 'bubble tea shop'],
  'asian-bakery': ['asian bakery', 'pasticceria asiatica', 'bakery asiatica', 'forno asiatico'],
  'asian-grocery': ['asian grocery', 'alimentari asiatici', 'market asiatico', 'supermercato asiatico', 'asian market'],
};

const STOPWORDS = new Set([
  'a', 'ad', 'in', 'di', 'da', 'del', 'della', 'il', 'la', 'lo', 'i', 'le', 'gli', 'e', 'the', 'at', 'near',
  'ristorante', 'ristoranti', 'restaurant', 'restaurants', 'locale', 'locali', 'cucina', 'vicino', 'zona', 'provincia',
]);

export function normalizeText(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/&/g, ' e ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Restituisce lo slug di categoria corrispondente a un termine (nome, slug o sinonimo). */
export function resolveCategorySlug(term: string, categories: NamedSlug[]): string | undefined {
  const n = normalizeText(term);
  if (!n) return undefined;
  for (const c of categories) {
    if (normalizeText(c.name) === n || normalizeText(c.slug) === n) return c.slug;
  }
  for (const [slug, words] of Object.entries(CATEGORY_SYNONYMS)) {
    if (words.some((w) => normalizeText(w) === n) && categories.some((c) => c.slug === slug)) return slug;
  }
  return undefined;
}

/** Restituisce lo slug del comune (accetta "Taranto", "taranto", "San Giorgio Ionico", "Taranto (TA)"). */
export function resolveCitySlug(term: string, cities: NamedSlug[]): string | undefined {
  const n = normalizeText(term.replace(/\([^)]*\)/g, ' '));
  if (!n) return undefined;
  return cities.find((c) => normalizeText(c.name) === n || normalizeText(c.slug) === n)?.slug;
}

export interface ParsedQuery {
  categorySlug?: string;
  citySlug?: string;
  /** true se nel testo compare "all you can eat" insieme a un'altra categoria */
  ayce?: boolean;
  /** testo residuo da cercare nel nome del locale */
  text?: string;
}

/** Scompone la ricerca libera in categoria + comune + testo residuo. */
export function parseSearchQuery(q: string | undefined, categories: NamedSlug[], cities: NamedSlug[]): ParsedQuery {
  if (!q) return {};
  let hay = ` ${normalizeText(q)} `;
  if (!hay.trim()) return {};
  const out: ParsedQuery = {};

  // 1. Comuni (prima i nomi più lunghi: "martina franca" prima di "franca")
  const cityTerms = cities
    .flatMap((c) => [{ slug: c.slug, t: normalizeText(c.name) }, { slug: c.slug, t: normalizeText(c.slug) }])
    .filter((x) => x.t)
    .sort((a, b) => b.t.length - a.t.length);
  for (const { slug, t } of cityTerms) {
    if (hay.includes(` ${t} `)) {
      out.citySlug = slug;
      hay = hay.replace(` ${t} `, ' ');
      break;
    }
  }

  // 2. Categorie (nome, slug e sinonimi; più lunghi prima)
  const available = new Set(categories.map((c) => c.slug));
  const catTerms = [
    ...categories.flatMap((c) => [{ slug: c.slug, t: normalizeText(c.name) }, { slug: c.slug, t: normalizeText(c.slug) }]),
    ...Object.entries(CATEGORY_SYNONYMS).flatMap(([slug, words]) => words.map((w) => ({ slug, t: normalizeText(w) }))),
  ]
    .filter((x) => x.t && available.has(x.slug))
    .sort((a, b) => b.t.length - a.t.length);
  const found: string[] = [];
  for (const { slug, t } of catTerms) {
    if (hay.includes(` ${t} `) && !found.includes(slug)) {
      found.push(slug);
      hay = hay.replace(` ${t} `, ' ');
    }
  }
  const nonAyce = found.filter((s) => s !== 'all-you-can-eat');
  if (nonAyce.length) {
    out.categorySlug = nonAyce[0];
    if (found.includes('all-you-can-eat')) out.ayce = true;
  } else if (found.length) {
    out.categorySlug = found[0];
  }

  // 3. Testo residuo (senza parole vuote)
  const rest = hay
    .split(' ')
    .filter((w) => w && !STOPWORDS.has(w))
    .join(' ')
    .trim();
  if (rest.length >= 2) out.text = rest;
  return out;
}
