// Verifica indirizzo di consegna → coordinate. Nessun token segreto nel browser:
// - Mapbox (token PUBBLICO con restrizione URL) se configurato;
// - in DEMO un geocoder dimostrativo (centro del comune + scostamento deterministico, "posizione approssimata");
// - altrimenti null: il cliente può usare la posizione del dispositivo (solo su sua richiesta).
// Il server ricalcola comunque distanza e zona; con MAPBOX_GEOCODING_TOKEN lato server rifà anche il geocoding.
import { MAPS } from '@/config/app';
import { geocodeAddress } from '@/lib/maps/geocode';
import { normalizeText } from '@/lib/searchQuery';
import { isDemoMode } from '@/services';
import type { City } from '@/types/domain';

export interface VerifiedPoint {
  latitude: number;
  longitude: number;
  source: 'geocoder' | 'demo';
  label: string;
  approximate: boolean;
}

export const canVerifyAddress = () => MAPS.geocoding || isDemoMode;

function hash(s: string) {
  let h = 2166136261;
  for (const ch of s) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  return (h >>> 0) / 4294967295;
}

export async function verifyAddress(a: { address_line_1: string; postal_code: string; city: string }, cities: City[]): Promise<VerifiedPoint | null> {
  const line = a.address_line_1.trim();
  if (line.length < 3 || !/^\d{5}$/.test(a.postal_code) || a.city.trim().length < 2) return null;
  if (MAPS.geocoding) {
    const g = await geocodeAddress(`${line}, ${a.postal_code} ${a.city}, Italia`);
    // Solo risultati a livello di via/civico: il solo comune non basta per l'area di consegna
    if (!g || (g.accuracy && !['rooftop', 'parcel', 'point', 'interpolated', 'street'].includes(g.accuracy))) return null;
    return { latitude: g.lat, longitude: g.lng, source: 'geocoder', label: g.label, approximate: false };
  }
  if (isDemoMode) {
    const c = cities.find((x) => normalizeText(x.name) === normalizeText(a.city));
    if (!c || c.latitude == null || c.longitude == null) return null;
    const h1 = hash(normalizeText(line));
    const h2 = hash(`${normalizeText(line)}#`);
    const km = 0.2 + h1 * 1.3;
    const ang = h2 * Math.PI * 2;
    return {
      latitude: Math.round((c.latitude + (km / 111.2) * Math.sin(ang)) * 1e6) / 1e6,
      longitude: Math.round((c.longitude + (km / (111.2 * Math.cos((c.latitude * Math.PI) / 180))) * Math.cos(ang)) * 1e6) / 1e6,
      source: 'demo', label: `${line}, ${a.postal_code} ${c.name}`, approximate: true,
    };
  }
  return null;
}
