// ─────────────────────────────────────────────────────────────
//  Fatturazione: etichette, formattazione e stato "da mostrare".
//  Lo stato non viene MAI deciso qui: arriva dal DB (sincronizzato
//  da Stripe via webhook). Qui solo la presentazione.
// ─────────────────────────────────────────────────────────────
import type {
  BillingActivityEvent,
  BillingInterval,
  BillingOverview,
  CampaignStatus,
  CompletionKey,
  PlanWithFeatures,
  SponsoredPlacement,
  Subscription,
  SubscriptionSource,
  SubscriptionStatus,
} from '@/types/domain';

type Tone = 'green' | 'amber' | 'coral' | 'neutral' | 'outline' | 'dark';

export const SUBSCRIPTION_STATUS: Record<SubscriptionStatus, { label: string; tone: Tone }> = {
  trialing: { label: 'In prova', tone: 'amber' },
  active: { label: 'Attivo', tone: 'green' },
  past_due: { label: 'Pagamento in ritardo', tone: 'coral' },
  unpaid: { label: 'Non pagato', tone: 'coral' },
  canceled: { label: 'Cancellato', tone: 'neutral' },
  incomplete: { label: 'Pagamento incompleto', tone: 'amber' },
  incomplete_expired: { label: 'Scaduto', tone: 'neutral' },
  paused: { label: 'In pausa', tone: 'neutral' },
  free: { label: 'Free', tone: 'outline' },
};

export const SUBSCRIPTION_SOURCE: Record<SubscriptionSource, string> = {
  stripe: 'Stripe',
  manual: 'Manuale',
  promo: 'Promozione',
  admin: 'Admin',
};

export const INTERVAL_LABEL: Record<BillingInterval, string> = { month: 'Mensile', year: 'Annuale' };

export const PLACEMENT_LABELS: Record<SponsoredPlacement, string> = {
  home_featured: 'Home — in evidenza',
  search_top: 'Ricerca — sopra i risultati',
  category_top: 'Pagina categoria — in cima',
  city_top: 'Pagina comune — in cima',
  map_featured: 'Mappa — in evidenza',
  offers_featured: 'Offerte — in evidenza',
  home_hero: 'Home — hero (Fase 1)',
};

export const CAMPAIGN_STATUS: Record<CampaignStatus, { label: string; tone: Tone }> = {
  draft: { label: 'Bozza', tone: 'outline' },
  scheduled: { label: 'Programmata', tone: 'amber' },
  active: { label: 'Attiva', tone: 'green' },
  paused: { label: 'In pausa', tone: 'neutral' },
  ended: { label: 'Terminata', tone: 'dark' },
};

export const ACTIVITY_LABELS: Record<BillingActivityEvent, string> = {
  trial_started: 'Prova gratuita iniziata',
  trial_expiring: 'Avviso: la prova sta per terminare',
  trial_ended: 'Prova terminata',
  trial_extended: 'Scadenza estesa dallo staff',
  subscription_started: 'Abbonamento attivato',
  subscription_upgraded: 'Upgrade del piano',
  subscription_downgraded: 'Downgrade del piano',
  interval_changed: 'Periodo di fatturazione cambiato',
  change_scheduled: 'Cambio piano programmato',
  change_cancelled: 'Cambio programmato annullato',
  subscription_cancelled: 'Cancellazione a fine periodo',
  subscription_resumed: 'Abbonamento riattivato',
  subscription_ended: 'Abbonamento terminato',
  payment_succeeded: 'Pagamento ricevuto',
  payment_failed: 'Pagamento non riuscito',
  payment_recovered: 'Pagamento recuperato',
  payment_action_required: 'Conferma del pagamento richiesta',
  plan_granted: 'Piano assegnato dallo staff',
  plan_revoked: 'Piano revocato dallo staff',
  duplicate_subscription: 'Abbonamento duplicato (verifica staff)',
  email_error: 'Errore invio email',
};

export const COMPLETION_LABELS: Record<CompletionKey, string> = {
  name: 'Nome attività',
  phone: 'Telefono',
  address: 'Indirizzo',
  logo: 'Logo',
  cover: 'Cover',
  hours: 'Orari',
  categories: 'Categorie',
  menu: 'Menu',
  photos: 'Foto',
  offer: 'Offerta',
  reservations: 'Prenotazioni',
};

const eur = new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' });
export function formatCents(cents: number | null | undefined, currency = 'EUR') {
  const v = (cents ?? 0) / 100;
  return currency.toUpperCase() === 'EUR' ? eur.format(v) : new Intl.NumberFormat('it-IT', { style: 'currency', currency }).format(v);
}

export const formatDay = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' }) : '—';
export const formatDayShort = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleDateString('it-IT', { day: 'numeric', month: 'long' }) : '—';

/** Giorni (arrotondati per eccesso) da adesso a una data. */
export function daysUntil(iso: string | null | undefined, now = Date.now()) {
  if (!iso) return null;
  return Math.max(0, Math.ceil((Date.parse(iso) - now) / 86_400_000));
}

export const planName = (plans: PlanWithFeatures[], code: string | null | undefined) => plans.find((p) => p.code === code)?.name ?? (code ? code[0]!.toUpperCase() + code.slice(1) : '');

/** Prezzo del piano per intervallo (dal DB: nessun prezzo scritto nel codice). */
export function planPrice(plans: PlanWithFeatures[], code: string, interval: BillingInterval): number {
  const p = plans.find((x) => x.code === code);
  return (interval === 'year' ? p?.yearly_price : p?.monthly_price) ?? 0;
}

/** Risparmio annuale rispetto a 12 mensilità (per l'etichetta "risparmi X%"). */
export function yearlySaving(plans: PlanWithFeatures[], code: string): number {
  const p = plans.find((x) => x.code === code);
  if (!p?.yearly_price || !p.monthly_price) return 0;
  return Math.max(0, Math.round((1 - p.yearly_price / (p.monthly_price * 12)) * 100));
}

export type BillingNotice =
  | { kind: 'payment_failed'; plan: string; until: string | null }
  | { kind: 'trial_expiring'; plan: string; days: number; hasPaymentMethod: boolean }
  | { kind: 'cancel_scheduled'; plan: string; until: string | null }
  | { kind: 'change_scheduled'; plan: string; to: string; at: string | null };

/** Avviso da mostrare in dashboard, derivato dallo stato sincronizzato. */
export function billingNotice(o: BillingOverview | null | undefined, plans: PlanWithFeatures[], now = Date.now()): BillingNotice | null {
  const s: Subscription | null | undefined = o?.stripe;
  if (!o || !s) return null;
  const plan = planName(plans, s.plan_code);
  if (s.status === 'past_due' || s.status === 'unpaid') {
    const from = s.payment_failed_at ?? s.current_period_end;
    return { kind: 'payment_failed', plan, until: from ? new Date(Date.parse(from) + o.grace_days * 86_400_000).toISOString() : null };
  }
  if (s.status === 'trialing' && !s.cancel_at_period_end) {
    const days = daysUntil(s.trial_end, now);
    if (days !== null && days <= o.trial_expiring_days) return { kind: 'trial_expiring', plan, days, hasPaymentMethod: !!s.pm_last4 };
  }
  if (s.cancel_at_period_end && ['active', 'trialing', 'past_due'].includes(s.status)) {
    return { kind: 'cancel_scheduled', plan, until: s.status === 'trialing' ? s.trial_end : s.current_period_end };
  }
  if (s.scheduled_plan_code && ['active', 'trialing', 'past_due'].includes(s.status)) {
    return { kind: 'change_scheduled', plan, to: planName(plans, s.scheduled_plan_code), at: s.scheduled_change_at };
  }
  return null;
}

/** Messaggio di errore leggibile (mai stack trace). */
export function billingErrorMessage(e: unknown) {
  const m = e instanceof Error ? e.message : '';
  return m && m.length < 300 && !/\bat \w+ \(/.test(m) ? m : 'Si è verificato un errore. Riprova tra poco.';
}

/**
 * Punti chiave dei piani per la pagina prezzi (testo commerciale; prezzi e limiti
 * restano nel DB). Nessuna promessa di risultati garantiti.
 */
export const PLAN_HIGHLIGHTS: Record<string, { intro?: string; items: string[] }> = {
  free: { items: ['Profilo base', 'Presenza nella ricerca', 'Presenza sulla mappa', 'Telefono e indicazioni', 'Orari di apertura', 'Categorie di cucina'] },
  business: { intro: 'Tutto Free, più', items: ['Profilo avanzato (descrizione, social, servizi)', 'Menu digitale', 'Galleria fotografica', 'Pulsante WhatsApp', 'Offerte', 'Statistiche base'] },
  premium: { intro: 'Tutto Business, più', items: ['Prenotazioni online', 'Coupon con validazione in cassa', 'Statistiche avanzate', 'Migliore visibilità a parità di pertinenza', 'Supporto prioritario'] },
  top: { intro: 'Tutto Premium, più', items: ['Posizionamento prioritario a parità di pertinenza', 'Sponsorizzazioni (etichettate come tali)', 'Promozioni avanzate', 'Strumenti di marketing', 'Massima visibilità nei piani AsiaFood'] },
};
