// "Ordina di nuovo" e carrello salvato: ricostruzione dal menu ATTUALE.
// Mai i prezzi vecchi: i prezzi mostrati sono quelli del menu di oggi e il server li ricalcola comunque.
import { api } from '@/services';
import type { MenuItemFull } from '@/types/domain';
import type { Cart, CartLine, MenuOptionGroup, OrderView } from '@/types/orders';
import { lineKey } from '@/context/CartContext';

interface SavedItem {
  menu_item_id: string;
  variant_id?: string | null;
  addons?: { id: string; quantity: number }[];
  options?: string[];
  quantity: number;
  notes?: string | null;
}

async function loadMenu(restaurantId: string) {
  const [summary] = await api.getRestaurantsByIds([restaurantId]);
  if (!summary) return null;
  const r = await api.getRestaurantBySlug(summary.slug);
  if (!r) return null;
  const items = new Map<string, MenuItemFull>();
  r.menus.filter((m) => m.menu_type !== 'all_you_can_eat').forEach((m) => m.sections.forEach((s) => s.items.forEach((it) => items.set(it.id, it))));
  const groups = await api.getMenuOptionGroups(restaurantId).catch(() => [] as MenuOptionGroup[]);
  return { r, items, groups };
}

export const itemAvailable = (it: MenuItemFull) => it.is_available && (!it.unavailable_until || Date.parse(it.unavailable_until) <= Date.now());

function buildLine(it: MenuItemFull, groups: MenuOptionGroup[], s: { variant_id: string | null; addons: { id: string; quantity: number }[]; option_ids: string[]; quantity: number; notes: string | null }): CartLine | null {
  const variants = it.variants.filter((v) => v.is_available);
  const variant = s.variant_id ? variants.find((v) => v.id === s.variant_id) : null;
  if (variants.length && !variant) return null;
  const addons = s.addons.map((a) => {
    const x = it.addons.find((y) => y.id === a.id && y.is_available);
    return x ? { id: x.id, name: x.name, price: x.price ?? 0, quantity: Math.max(1, Math.min(5, a.quantity)) } : null;
  });
  if (addons.some((a) => !a)) return null;
  const myGroups = groups.filter((g) => g.menu_item_id === it.id);
  const options = s.option_ids.map((id) => {
    const g = myGroups.find((gg) => gg.options.some((o) => o.id === id));
    const o = g?.options.find((x) => x.id === id);
    return g && o ? { id: o.id, group: g.name, name: o.name, price: o.price } : null;
  });
  if (options.some((o) => !o)) return null;
  // Gruppi obbligatori ancora rispettati?
  for (const g of myGroups) {
    const n = options.filter((o) => o!.group === g.name).length;
    if (n < Math.max(g.min_select, g.required ? 1 : 0) || n > g.max_select) return null;
  }
  const base = variant?.price ?? (it.discount_price != null && it.price != null && it.discount_price < it.price ? it.discount_price : it.price);
  if (base == null) return null;
  const unit = Math.round((base + addons.reduce((t, a) => t + a!.price * a!.quantity, 0) + options.reduce((t, o) => t + o!.price, 0)) * 100) / 100;
  const line = {
    menu_item_id: it.id, name: it.name, image_url: it.image_url, variant_id: variant?.id ?? null, variant_name: variant?.name ?? null,
    addons: addons as CartLine['addons'], options: options as CartLine['options'], quantity: Math.max(1, Math.min(20, s.quantity)), notes: s.notes, unit_price: unit,
  };
  return { ...line, key: lineKey(line) };
}

/** Carrello salvato (sincronizzazione tra dispositivi) → carrello locale. */
export async function rebuildCart(restaurantId: string, items: SavedItem[]): Promise<{ cart: Cart; skipped: number }> {
  const m = await loadMenu(restaurantId);
  if (!m) throw new Error('Ristorante non disponibile.');
  const lines: CartLine[] = [];
  let skipped = 0;
  for (const s of items) {
    const it = m.items.get(s.menu_item_id);
    const line = it && itemAvailable(it) ? buildLine(it, m.groups, { variant_id: s.variant_id ?? null, addons: s.addons ?? [], option_ids: s.options ?? [], quantity: s.quantity, notes: s.notes ?? null }) : null;
    if (line) lines.push(line);
    else skipped++;
  }
  return { cart: { restaurant_id: m.r.id, restaurant_name: m.r.name, restaurant_slug: m.r.slug, lines, updated_at: new Date().toISOString(), validated_at: null }, skipped };
}

/** "Ordina di nuovo": stessi piatti e scelte (per nome) sul menu attuale; prodotti non più disponibili esclusi. */
export async function cartFromOrder(o: OrderView): Promise<{ cart: Cart; skipped: string[] }> {
  const m = await loadMenu(o.restaurant.id);
  if (!m) throw new Error('Il ristorante non è più disponibile.');
  const lines: CartLine[] = [];
  const skipped: string[] = [];
  for (const oi of o.items) {
    const it = oi.menu_item_id ? m.items.get(oi.menu_item_id) : undefined;
    if (!it || !itemAvailable(it)) {
      skipped.push(oi.name);
      continue;
    }
    const variant = oi.variant ? it.variants.find((v) => v.is_available && (v.id === oi.variant_id || v.name === oi.variant)) : null;
    const addons = oi.options.filter((x) => x.kind === 'addon').map((x) => {
      const a = it.addons.find((y) => y.name === x.name && y.is_available);
      return a ? { id: a.id, quantity: x.quantity } : null;
    });
    const groups = m.groups.filter((g) => g.menu_item_id === it.id);
    const opts = oi.options.filter((x) => x.kind === 'option').map((x) => groups.find((g) => g.name === x.group)?.options.find((y) => y.name === x.name)?.id ?? null);
    if ((oi.variant && !variant) || addons.some((a) => !a) || opts.some((x) => !x)) {
      skipped.push(oi.name);
      continue;
    }
    const line = buildLine(it, m.groups, { variant_id: variant?.id ?? null, addons: addons as { id: string; quantity: number }[], option_ids: opts as string[], quantity: oi.quantity, notes: oi.notes });
    if (line) lines.push(line);
    else skipped.push(oi.name);
  }
  return { cart: { restaurant_id: m.r.id, restaurant_name: m.r.name, restaurant_slug: m.r.slug, lines, updated_at: new Date().toISOString(), validated_at: null }, skipped };
}
