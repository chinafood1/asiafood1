// Prenotazioni: etichette, transizioni di stato e calcolo disponibilità.
// computeAvailability è lo specchio TypeScript di get_reservation_availability (SQL),
// usato dalla sorgente demo: stesse regole, stessi messaggi.
import type { Availability, Reservation, ReservationSettings, ReservationSlot, ReservationStatus, RestaurantClosure, SlotStatus } from '@/types/domain';

export const RESERVATION_STATUS: Record<ReservationStatus, { label: string; tone: 'amber' | 'green' | 'neutral' | 'coral' | 'dark' }> = {
  pending: { label: 'Da confermare', tone: 'amber' },
  confirmed: { label: 'Confermata', tone: 'green' },
  rejected: { label: 'Rifiutata', tone: 'coral' },
  cancelled: { label: 'Cancellata', tone: 'neutral' },
  completed: { label: 'Completata', tone: 'dark' },
  no_show: { label: 'No show', tone: 'coral' },
};

/** Azioni consentite al gestore per ogni stato (identiche al DB). */
export const NEXT_STATUSES: Record<ReservationStatus, ReservationStatus[]> = {
  pending: ['confirmed', 'rejected', 'cancelled'],
  confirmed: ['completed', 'no_show', 'cancelled'],
  rejected: [],
  cancelled: [],
  completed: [],
  no_show: [],
};

export const ACTIVE_STATUSES: ReservationStatus[] = ['pending', 'confirmed'];

const TZ = 'Europe/Rome';

/** Data e ora locali (fuso del ristorante) come 'YYYY-MM-DD' e 'HH:MM'. */
export function localNow(tz = TZ, at = new Date()): { date: string; time: string; ts: number } {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
      .formatToParts(at)
      .map((p) => [p.type, p.value]),
  );
  const date = `${parts.year}-${parts.month}-${parts.day}`;
  const time = `${parts.hour}:${parts.minute}`;
  return { date, time, ts: Date.parse(`${date}T${time}:00Z`) };
}

export const addDays = (date: string, n: number) => {
  const d = new Date(`${date}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
/** 1 = lunedì … 7 = domenica */
export const isoDow = (date: string) => ((new Date(`${date}T12:00:00Z`).getUTCDay() + 6) % 7) + 1;
export const hhmm = (t: string) => t.slice(0, 5);
const minutes = (t: string) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));
const fromMinutes = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;

export interface AvailabilityContext {
  isPublic: boolean;
  closedNow: boolean; // chiuso temporaneamente o definitivamente
  hasReservation: boolean;
  planAllows: boolean;
  settings: ReservationSettings | null;
  slots: ReservationSlot[];
  closures: RestaurantClosure[];
  reservations: Pick<Reservation, 'reservation_date' | 'reservation_time' | 'party_size' | 'status'>[];
  tz?: string;
  now?: Date;
}

export function computeAvailability(ctx: AvailabilityContext, date: string, partySize: number): Availability {
  const st = ctx.settings;
  const now = localNow(ctx.tz, ctx.now);
  const fail = (reason: string): Availability => ({ ok: false, reason, slots: [] });
  if (!ctx.isPublic) return fail('Ristorante non trovato.');
  if (ctx.closedNow) return fail('Il ristorante non accetta prenotazioni in questo periodo.');
  if (!ctx.hasReservation || !st || !st.reservation_enabled || !ctx.planAllows) return fail('Le prenotazioni online non sono attive per questo ristorante.');
  if (!date || date < now.date) return fail('Scegli una data a partire da oggi.');
  if (date > addDays(now.date, st.max_advance_days)) return fail(`Puoi prenotare al massimo ${st.max_advance_days} giorni prima.`);
  if (!partySize || partySize < st.min_party_size) return fail(`Il numero minimo di persone è ${st.min_party_size}.`);
  if (partySize > st.max_party_size) return fail(`Per gruppi di più di ${st.max_party_size} persone contatta direttamente il ristorante.`);
  const dayClosures = ctx.closures.filter((c) => c.date === date);
  if (dayClosures.some((c) => !c.start_time)) return fail('Il ristorante è chiuso in questa data.');

  const active = ctx.reservations.filter((r) => r.reservation_date === date && ACTIVE_STATUSES.includes(r.status));
  const byTime = new Map<string, SlotStatus>();
  ctx.slots
    .filter((s) => s.is_active && s.day_of_week === isoDow(date))
    .sort((a, b) => a.start_time.localeCompare(b.start_time))
    .forEach((s) => {
      const start = minutes(s.start_time);
      const end = minutes(s.end_time);
      const guestsWindow = active.filter((r) => minutes(r.reservation_time) >= start && minutes(r.reservation_time) <= end).reduce((a, r) => a + r.party_size, 0);
      for (let m = start; m <= end; m += s.slot_interval_minutes) {
        const t = fromMinutes(m);
        if (byTime.has(t)) continue;
        const nAt = active.filter((r) => hhmm(r.reservation_time) === t).length;
        const closed = dayClosures.some((c) => c.start_time && m >= minutes(c.start_time) && m < minutes(c.end_time!));
        const tooSoon = Date.parse(`${date}T${t}:00Z`) < now.ts + st.booking_notice_minutes * 60_000;
        const full = (s.max_reservations != null && nAt >= s.max_reservations) || (s.max_guests != null && guestsWindow + partySize > s.max_guests);
        byTime.set(t, closed ? 'closed' : tooSoon ? 'too_soon' : full ? 'full' : 'available');
      }
    });
  const slots = [...byTime.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([time, status]) => ({ time, status }));
  return {
    ok: true,
    reason: slots.some((s) => s.status === 'available') ? null : 'Nessun orario disponibile in questa data.',
    slots,
    auto_confirm: st.auto_confirm,
    guest_message: st.guest_message,
  };
}

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
/** Codice casuale leggibile (senza 0/O/1/I), come random_code() nel DB. */
export function randomCode(len: number): string {
  const bytes = new Uint8Array(len);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => CODE_CHARS[b % 32]).join('');
}

export const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
export const PHONE_RE = /^\+?[0-9 ().-]{6,20}$/;

/** Data leggibile: "sab 27 set". */
export function formatDay(date: string, opts: Intl.DateTimeFormatOptions = { weekday: 'short', day: 'numeric', month: 'short' }) {
  return new Intl.DateTimeFormat('it-IT', { ...opts, timeZone: 'UTC' }).format(new Date(`${date}T12:00:00Z`));
}
