import { forwardRef, useState } from 'react';
import { MAPS } from '@/config/app';
import { LiteMap } from './LiteMap';
import { MapboxMap } from './MapboxMap';
import type { InteractiveMapProps, MapHandle } from './types';

/**
 * Mappa interattiva unica per tutta l'app.
 *  - Mapbox GL se VITE_MAPBOX_ACCESS_TOKEN è configurato (tessere, clustering nativo);
 *  - altrimenti, o in caso di errore (token errato, rete, WebGL), la mappa integrata:
 *    la pagina non si rompe mai e la lista resta sempre disponibile.
 */
export const InteractiveMap = forwardRef<MapHandle, InteractiveMapProps>(function InteractiveMap(props, ref) {
  const [failed, setFailed] = useState(false);
  if (MAPS.provider === 'mapbox' && MAPS.mapboxToken && !failed) {
    return (
      <MapboxMap
        {...props}
        ref={ref}
        onFail={(msg) => {
          setFailed(true);
          props.onProviderError?.(msg);
        }}
      />
    );
  }
  return <LiteMap {...props} ref={ref} />;
});

export const hasFullMap = () => MAPS.provider === 'mapbox' && !!MAPS.mapboxToken;
