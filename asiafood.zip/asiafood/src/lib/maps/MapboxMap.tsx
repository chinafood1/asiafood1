/* eslint-disable @typescript-eslint/no-explicit-any */
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { MAPS } from '@/config/app';
import { cn } from '@/lib/format';
import { circlePolygon, loadScript, type InteractiveMapProps, type MapHandle, type MapPoint } from './types';

declare global {
  interface Window {
    mapboxgl?: any;
  }
}

const VERSION = '3.7.0';
const STYLE = 'mapbox://styles/mapbox/light-v11';
const INK = '#16161A';
const CORAL = '#FF5A4E';

const toFeatures = (points: MapPoint[]) => ({
  type: 'FeatureCollection',
  features: points.map((p) => ({
    type: 'Feature',
    properties: { id: p.id, label: p.label, sponsored: !!(p.sponsored ?? p.highlighted) },
    geometry: { type: 'Point', coordinates: [p.lng, p.lat] },
  })),
});

/**
 * Adapter Mapbox GL JS (attivo con VITE_MAPBOX_ACCESS_TOKEN).
 * Clustering nativo della sorgente GeoJSON: scala a migliaia di punti.
 * Qualsiasi errore di caricamento/token chiama onFail → fallback alla mappa integrata.
 */
export const MapboxMap = forwardRef<MapHandle, InteractiveMapProps & { onFail: (msg: string) => void }>(function MapboxMap(props, ref) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<any>(null);
  const [ready, setReady] = useState(false);
  const readyRef = useRef(false);
  const latest = useRef(props);
  latest.current = props;
  const editMarker = useRef<any>(null);
  const labelMarker = useRef<any>(null);
  const failed = useRef(false);

  const fail = (msg: string) => {
    if (failed.current) return;
    failed.current = true;
    props.onFail(msg);
  };

  const pad = () => ({ top: 40, bottom: 40, left: 40, right: 40, ...latest.current.padding });

  useImperativeHandle(ref, () => ({
    flyTo: (c, zoom) => map.current?.flyTo({ center: [c.lng, c.lat], zoom: zoom ?? Math.max(map.current.getZoom(), 14), padding: pad(), essential: true }),
    fitBounds: (b, p) => map.current?.fitBounds([[b.west, b.south], [b.east, b.north]], { padding: p ?? pad(), maxZoom: 16 }),
    getBounds: () => {
      const b = map.current?.getBounds?.();
      return b ? { north: b.getNorth(), south: b.getSouth(), east: b.getEast(), west: b.getWest() } : null;
    },
    getZoom: () => map.current?.getZoom?.() ?? 10,
  }));

  // ─── Inizializzazione ───────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    loadScript(`https://api.mapbox.com/mapbox-gl-js/v${VERSION}/mapbox-gl.js`, `https://api.mapbox.com/mapbox-gl-js/v${VERSION}/mapbox-gl.css`)
      .then(() => {
        const mb = window.mapboxgl;
        if (cancelled || !el.current || !mb) return;
        if (typeof mb.supported === 'function' && !mb.supported()) return fail('Il browser non supporta WebGL');
        mb.accessToken = MAPS.mapboxToken;
        const p = latest.current;
        const iv = p.initialView;
        const m = new mb.Map({
          container: el.current,
          style: STYLE,
          ...(iv && 'bounds' in iv
            ? { bounds: [[iv.bounds.west, iv.bounds.south], [iv.bounds.east, iv.bounds.north]], fitBoundsOptions: { padding: 40 } }
            : { center: iv ? [iv.center.lng, iv.center.lat] : [17.2, 40.5], zoom: iv ? iv.zoom : 9 }),
          interactive: p.interactive !== false,
          attributionControl: true,
          locale: { 'NavigationControl.ZoomIn': 'Aumenta zoom', 'NavigationControl.ZoomOut': 'Riduci zoom' },
        });
        map.current = m;
        if (p.interactive !== false && p.controls !== false) m.addControl(new mb.NavigationControl({ showCompass: false }), 'bottom-right');
        m.on('error', (e: any) => {
          const status = e?.error?.status;
          if (status === 401 || status === 403 || /access token/i.test(String(e?.error?.message ?? ''))) fail('Token Mapbox non valido');
        });
        m.on('load', () => {
          if (cancelled) return;
          setupLayers(m);
          readyRef.current = true;
          syncData();
          setReady(true);
          emitMoveEnd(false);
        });
        m.on('moveend', (e: any) => emitMoveEnd(!!e.originalEvent));
      })
      .catch(() => fail('Impossibile caricare Mapbox'));
    const timeout = window.setTimeout(() => !readyRef.current && fail('Timeout caricamento mappa'), 15000);
    return () => {
      cancelled = true;
      clearTimeout(timeout);
      map.current?.remove?.();
      map.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const emitMoveEnd = (userInitiated: boolean) => {
    const m = map.current;
    if (!m) return;
    const b = m.getBounds();
    const c = m.getCenter();
    latest.current.onMoveEnd?.({
      bounds: { north: b.getNorth(), south: b.getSouth(), east: b.getEast(), west: b.getWest() },
      center: { lat: c.lat, lng: c.lng },
      zoom: m.getZoom(),
      userInitiated,
    });
  };

  const setupLayers = (m: any) => {
    m.addSource('restaurants', { type: 'geojson', data: toFeatures([]), cluster: latest.current.clustering !== false, clusterRadius: 50, clusterMaxZoom: 15 });
    m.addSource('selected', { type: 'geojson', data: toFeatures([]) });
    m.addSource('user', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
    m.addLayer({ id: 'user-radius', type: 'fill', source: 'user', filter: ['==', ['geometry-type'], 'Polygon'], paint: { 'fill-color': '#3B82F6', 'fill-opacity': 0.07 } });
    m.addLayer({ id: 'user-radius-line', type: 'line', source: 'user', filter: ['==', ['geometry-type'], 'Polygon'], paint: { 'line-color': '#3B82F6', 'line-opacity': 0.4, 'line-width': 2 } });
    m.addLayer({
      id: 'clusters', type: 'circle', source: 'restaurants', filter: ['has', 'point_count'],
      paint: { 'circle-color': INK, 'circle-radius': ['step', ['get', 'point_count'], 18, 10, 23, 50, 29], 'circle-stroke-width': 3, 'circle-stroke-color': '#fff' },
    });
    m.addLayer({
      id: 'cluster-count', type: 'symbol', source: 'restaurants', filter: ['has', 'point_count'],
      layout: { 'text-field': ['get', 'point_count_abbreviated'], 'text-font': ['DIN Pro Medium', 'Arial Unicode MS Bold'], 'text-size': 13 },
      paint: { 'text-color': '#fff' },
    });
    m.addLayer({
      id: 'points', type: 'circle', source: 'restaurants', filter: ['!', ['has', 'point_count']],
      paint: {
        'circle-radius': ['case', ['get', 'sponsored'], 9, 7.5],
        'circle-color': ['case', ['get', 'sponsored'], CORAL, '#fff'],
        'circle-stroke-width': 3,
        'circle-stroke-color': ['case', ['get', 'sponsored'], '#fff', CORAL],
      },
    });
    m.addLayer({ id: 'selected', type: 'circle', source: 'selected', paint: { 'circle-radius': 11, 'circle-color': INK, 'circle-stroke-width': 3, 'circle-stroke-color': '#fff' } });
    m.addLayer({ id: 'user-dot', type: 'circle', source: 'user', filter: ['==', ['geometry-type'], 'Point'], paint: { 'circle-radius': 7, 'circle-color': '#3B82F6', 'circle-stroke-width': 3, 'circle-stroke-color': '#fff' } });

    m.on('click', 'clusters', (e: any) => {
      const f = e.features?.[0];
      if (!f) return;
      m.getSource('restaurants').getClusterExpansionZoom(f.properties.cluster_id, (err: unknown, zoom: number) => {
        if (!err) m.easeTo({ center: f.geometry.coordinates, zoom });
      });
    });
    m.on('click', 'points', (e: any) => latest.current.onSelect?.(e.features?.[0]?.properties?.id ?? null));
    m.on('click', (e: any) => {
      const hit = m.queryRenderedFeatures(e.point, { layers: ['points', 'clusters', 'selected'] });
      if (hit.length) return;
      const ed = latest.current.editable;
      if (ed?.placing) ed.onChange({ lat: e.lngLat.lat, lng: e.lngLat.lng });
      else latest.current.onSelect?.(null);
    });
    for (const layer of ['points', 'clusters', 'selected']) {
      m.on('mouseenter', layer, (e: any) => {
        m.getCanvas().style.cursor = 'pointer';
        if (layer === 'points') latest.current.onHover?.(e.features?.[0]?.properties?.id ?? null);
      });
      m.on('mouseleave', layer, () => {
        m.getCanvas().style.cursor = '';
        if (layer === 'points') latest.current.onHover?.(null);
      });
    }
  };

  // ─── Sincronizzazione dati/stati ────────────────────────────
  const syncData = () => {
    const m = map.current;
    const mb = window.mapboxgl;
    if (!m?.getSource?.('restaurants') || !mb) return;
    const p = latest.current;
    m.getSource('restaurants').setData(toFeatures(p.points.filter((x) => x.id !== p.selectedId)));
    const sel = p.points.find((x) => x.id === p.selectedId);
    m.getSource('selected').setData(toFeatures(sel ? [sel] : []));
    m.getSource('user').setData({
      type: 'FeatureCollection',
      features: p.user
        ? [
            { type: 'Feature', properties: {}, geometry: { type: 'Point', coordinates: [p.user.lng, p.user.lat] } },
            ...(p.radiusKm ? [{ type: 'Feature', properties: {}, geometry: { type: 'Polygon', coordinates: [circlePolygon(p.user, p.radiusKm)] } }] : []),
          ]
        : [],
    });
    // hover: cerchio più grande e bordo scuro
    m.setPaintProperty('points', 'circle-radius', ['case', ['==', ['get', 'id'], p.hoveredId ?? ''], 10.5, ['get', 'sponsored'], 9, 7.5]);
    // etichetta del selezionato
    labelMarker.current?.remove();
    labelMarker.current = null;
    if (sel) {
      const node = document.createElement('div');
      node.textContent = sel.label;
      node.style.cssText = `transform:translateY(-26px);background:${INK};color:#fff;font:600 12px Inter,system-ui,sans-serif;padding:4px 10px;border-radius:999px;white-space:nowrap;box-shadow:0 6px 18px rgba(0,0,0,.25);pointer-events:none`;
      labelMarker.current = new mb.Marker({ element: node, anchor: 'bottom' }).setLngLat([sel.lng, sel.lat]).addTo(m);
    }
    // marker modificabile
    const ed = p.editable;
    if (ed?.position) {
      if (!editMarker.current) {
        editMarker.current = new mb.Marker({ color: CORAL, draggable: true }).setLngLat([ed.position.lng, ed.position.lat]).addTo(m);
        editMarker.current.on('dragend', () => {
          const ll = editMarker.current.getLngLat();
          latest.current.editable?.onChange({ lat: ll.lat, lng: ll.lng });
        });
      } else editMarker.current.setLngLat([ed.position.lng, ed.position.lat]);
    } else {
      editMarker.current?.remove();
      editMarker.current = null;
    }
    m.getCanvas().style.cursor = ed?.placing ? 'crosshair' : '';
  };

  useEffect(() => {
    if (ready) syncData();
  }, [ready, props.points, props.selectedId, props.hoveredId, props.user?.lat, props.user?.lng, props.radiusKm, props.editable?.position?.lat, props.editable?.position?.lng, props.editable?.placing]);

  return (
    <div className={cn('relative isolate overflow-hidden bg-[#EDF0EA]', props.className)}>
      <div ref={el} className="absolute inset-0" role="application" aria-label={props.ariaLabel ?? 'Mappa dei ristoranti'} />
      {!ready && <div className="skeleton absolute inset-0" aria-hidden />}
    </div>
  );
});
