/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useRef, useState } from 'react';
import { MAPS } from '@/config/app';
import { cn } from '@/lib/format';
import { InteractiveMap } from './InteractiveMap';
import { loadScript, type MapViewProps } from './types';

declare global {
  interface Window {
    google?: any;
  }
}

/** Adapter Google Maps (compatibilità: attivo solo con VITE_MAPS_PROVIDER=google + chiave). */
function GoogleMap(props: MapViewProps & { onFail: () => void }) {
  const el = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let cancelled = false;
    loadScript(`https://maps.googleapis.com/maps/api/js?key=${MAPS.googleKey}&v=weekly`)
      .then(() => {
        if (cancelled || !el.current || !window.google) return;
        const c = props.center ?? props.points[0] ?? { lat: 40.4644, lng: 17.247 };
        const map = new window.google.maps.Map(el.current, { center: c, zoom: props.zoom ?? 11, disableDefaultUI: true, zoomControl: true, clickableIcons: false });
        props.points.forEach((p) => new window.google.maps.Marker({ position: { lat: p.lat, lng: p.lng }, map, title: p.label }));
      })
      .catch(props.onFail);
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return <div ref={el} className={cn('bg-cream', props.className)} />;
}

/**
 * Anteprima di mappa non interattiva (scheda ristorante, editor).
 * Per l'esperienza completa usare InteractiveMap / pagina /map.
 */
export function MapView(props: MapViewProps) {
  const [failed, setFailed] = useState(false);
  if (!failed && MAPS.provider === 'google' && MAPS.googleKey) return <GoogleMap {...props} onFail={() => setFailed(true)} />;
  const c = props.center ?? props.points[0];
  return (
    <InteractiveMap
      points={props.points}
      selectedId={props.activeId}
      user={props.user}
      interactive={false}
      clustering={false}
      initialView={c ? { center: c, zoom: props.zoom ?? 13 } : undefined}
      className={props.className}
      ariaLabel="Anteprima della posizione sulla mappa"
    />
  );
}
