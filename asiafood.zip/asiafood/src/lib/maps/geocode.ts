import { MAPS } from '@/config/app';
import type { LatLng } from './types';

export interface GeocodeResult extends LatLng {
  label: string;
  /** Precisione dichiarata dal provider (es. rooftop, street, place). */
  accuracy: string | null;
}

const cache = new Map<string, GeocodeResult | null>();
let last = 0;

/**
 * Geocoding indirizzo → coordinate con il provider configurato (Mapbox).
 * Chiamate solo su azione esplicita (Admin o titolare), con cache e max 1 richiesta/secondo.
 */
export async function geocodeAddress(query: string): Promise<GeocodeResult | null> {
  if (!MAPS.geocoding) throw new Error('Geocoding non configurato: imposta VITE_MAPBOX_ACCESS_TOKEN.');
  const q = query.trim();
  if (q.length < 5) throw new Error('Indirizzo troppo corto.');
  if (cache.has(q)) return cache.get(q)!;
  const wait = 1000 - (Date.now() - last);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  last = Date.now();
  const url = `https://api.mapbox.com/search/geocode/v6/forward?q=${encodeURIComponent(q)}&country=it&language=it&limit=1&types=address,street,place&access_token=${encodeURIComponent(MAPS.mapboxToken)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(res.status === 401 ? 'Token Mapbox non valido.' : 'Servizio di geocoding non disponibile.');
  const data = (await res.json()) as { features?: { geometry: { coordinates: [number, number] }; properties: { full_address?: string; name?: string; coordinates?: { accuracy?: string } } }[] };
  const f = data.features?.[0];
  const out = f
    ? { lng: f.geometry.coordinates[0], lat: f.geometry.coordinates[1], label: f.properties.full_address ?? f.properties.name ?? q, accuracy: f.properties.coordinates?.accuracy ?? null }
    : null;
  cache.set(q, out);
  return out;
}
