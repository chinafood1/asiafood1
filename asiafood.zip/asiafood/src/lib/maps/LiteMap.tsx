import { forwardRef, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState, type PointerEvent as RPointerEvent } from 'react';
import Supercluster from 'supercluster';
import { Minus, Plus } from 'lucide-react';
import { cn } from '@/lib/format';
import type { GeoBounds, InteractiveMapProps, LatLng, MapHandle, MapLandmark, MapPoint } from './types';

/**
 * Mappa integrata senza servizi esterni (fallback di Mapbox):
 * proiezione Web Mercator, pan/zoom (mouse, rotella, touch, pinch, tastiera),
 * clustering (supercluster), posizione utente con raggio, marker trascinabile.
 * Non mostra tessere cartografiche: è una vista semplificata con i comuni come riferimento.
 */
const TILE = 256;
const MIN_Z = 5;
const MAX_Z = 18;
const clampZ = (z: number) => Math.min(MAX_Z, Math.max(MIN_Z, z));

function project(p: LatLng, z: number) {
  const s = TILE * 2 ** z;
  const sin = Math.min(0.9999, Math.max(-0.9999, Math.sin((p.lat * Math.PI) / 180)));
  return { x: ((p.lng + 180) / 360) * s, y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s };
}
function unproject(x: number, y: number, z: number): LatLng {
  const s = TILE * 2 ** z;
  const n = Math.PI - (2 * Math.PI * y) / s;
  return { lat: (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lng: (x / s) * 360 - 180 };
}
const metersPerPixel = (lat: number, z: number) => (156543.03392 * Math.cos((lat * Math.PI) / 180)) / 2 ** z;

interface View {
  lat: number;
  lng: number;
  zoom: number;
}

type ClusterProps = { cluster: true; cluster_id: number; point_count: number } | { cluster?: false; id: string };

export const LiteMap = forwardRef<MapHandle, InteractiveMapProps>(function LiteMap(props, ref) {
  const {
    points, selectedId, hoveredId, onSelect, onHover, onMoveEnd, user, radiusKm, initialView, landmarks, controls = true,
    interactive = true, clustering = true, editable, padding, className, ariaLabel,
  } = props;
  const box = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [view, setView] = useState<View>({ lat: 40.5, lng: 17.2, zoom: 9 });
  const viewRef = useRef(view);
  viewRef.current = view;
  const sizeRef = useRef(size);
  sizeRef.current = size;
  const cb = useRef({ onMoveEnd, onSelect, editable });
  cb.current = { onMoveEnd, onSelect, editable };
  const initialized = useRef(false);
  const anim = useRef<number | null>(null);
  const wheelTimer = useRef<number | null>(null);
  const drag = useRef<{ moved: boolean; downOnMarker?: boolean; pointers: Map<number, { x: number; y: number }>; start?: { view: View; x: number; y: number; dist?: number; mid?: { x: number; y: number } } }>({ moved: false, pointers: new Map() });
  const [dragPin, setDragPin] = useState<LatLng | null>(null);

  // ─── Geometria ──────────────────────────────────────────────
  const toScreen = useCallback((p: LatLng, v: View = viewRef.current) => {
    const a = project(p, v.zoom);
    const c = project(v, v.zoom);
    return { x: a.x - c.x + sizeRef.current.w / 2, y: a.y - c.y + sizeRef.current.h / 2 };
  }, []);
  const fromScreen = useCallback((x: number, y: number, v: View = viewRef.current) => {
    const c = project(v, v.zoom);
    return unproject(c.x + x - sizeRef.current.w / 2, c.y + y - sizeRef.current.h / 2, v.zoom);
  }, []);
  const boundsOfView = useCallback(
    (v: View = viewRef.current): GeoBounds => {
      const tl = fromScreen(0, 0, v);
      const br = fromScreen(sizeRef.current.w, sizeRef.current.h, v);
      return { north: tl.lat, south: br.lat, west: tl.lng, east: br.lng };
    },
    [fromScreen],
  );
  const emitMoveEnd = useCallback(
    (userInitiated: boolean) => {
      const v = viewRef.current;
      cb.current.onMoveEnd?.({ bounds: boundsOfView(v), center: { lat: v.lat, lng: v.lng }, zoom: v.zoom, userInitiated });
    },
    [boundsOfView],
  );

  const animateTo = useCallback(
    (target: View, userInitiated = false) => {
      if (anim.current) cancelAnimationFrame(anim.current);
      const from = { ...viewRef.current };
      const t0 = performance.now();
      const dur = 380;
      const step = (t: number) => {
        const k = Math.min(1, (t - t0) / dur);
        const e = 1 - (1 - k) ** 3;
        setView({ lat: from.lat + (target.lat - from.lat) * e, lng: from.lng + (target.lng - from.lng) * e, zoom: from.zoom + (target.zoom - from.zoom) * e });
        if (k < 1) anim.current = requestAnimationFrame(step);
        else {
          anim.current = null;
          viewRef.current = target;
          emitMoveEnd(userInitiated);
        }
      };
      anim.current = requestAnimationFrame(step);
    },
    [emitMoveEnd],
  );

  /** Centro della vista tale che `p` cada al centro dell'area libera (tenendo conto del padding). */
  const centerFor = useCallback(
    (p: LatLng, zoom: number): View => {
      const pad = { top: 0, bottom: 0, left: 0, right: 0, ...padding };
      const a = project(p, zoom);
      const dx = (pad.left - pad.right) / 2;
      const dy = (pad.top - pad.bottom) / 2;
      const c = unproject(a.x - dx, a.y - dy, zoom);
      return { lat: c.lat, lng: c.lng, zoom };
    },
    [padding],
  );

  const fitView = useCallback(
    (b: GeoBounds, pad = 48): View => {
      const { w, h } = sizeRef.current;
      const extra = { top: 0, bottom: 0, left: 0, right: 0, ...padding };
      const a = project({ lat: b.north, lng: b.west }, 0);
      const c = project({ lat: b.south, lng: b.east }, 0);
      const dx = Math.max(c.x - a.x, 1e-9);
      const dy = Math.max(c.y - a.y, 1e-9);
      const availW = Math.max(40, w - pad * 2 - extra.left - extra.right);
      const availH = Math.max(40, h - pad * 2 - extra.top - extra.bottom);
      const z = clampZ(Math.min(Math.log2(availW / dx), Math.log2(availH / dy), 16));
      return centerFor({ lat: (b.north + b.south) / 2, lng: (b.east + b.west) / 2 }, z);
    },
    [centerFor, padding],
  );

  useImperativeHandle(
    ref,
    () => ({
      flyTo: (c, zoom) => animateTo(centerFor(c, clampZ(zoom ?? Math.max(viewRef.current.zoom, 14)))),
      fitBounds: (b, pad) => animateTo(fitView(b, pad)),
      getBounds: () => (sizeRef.current.w ? boundsOfView() : null),
      getZoom: () => viewRef.current.zoom,
    }),
    [animateTo, boundsOfView, centerFor, fitView],
  );

  // ─── Dimensioni e vista iniziale ────────────────────────────
  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const ro = new ResizeObserver(([e]) => setSize({ w: e!.contentRect.width, h: e!.contentRect.height }));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (initialized.current || !size.w || !size.h) return;
    initialized.current = true;
    let v: View;
    if (initialView && 'bounds' in initialView) v = fitView(initialView.bounds);
    else if (initialView) v = { ...initialView.center, zoom: clampZ(initialView.zoom) };
    else if (points.length) {
      const lats = points.map((p) => p.lat);
      const lngs = points.map((p) => p.lng);
      v = fitView({ north: Math.max(...lats), south: Math.min(...lats), east: Math.max(...lngs), west: Math.min(...lngs) });
    } else v = { lat: 40.5, lng: 17.2, zoom: 9 };
    viewRef.current = v;
    setView(v);
    queueMicrotask(() => emitMoveEnd(false));
  }, [size, initialView, points, fitView, emitMoveEnd]);

  // ─── Interazioni ────────────────────────────────────────────
  const zoomAround = useCallback(
    (pt: { x: number; y: number }, z: number, base: View = viewRef.current) => {
      const nz = clampZ(z);
      const ll = fromScreen(pt.x, pt.y, base);
      const p = project(ll, nz);
      const c = unproject(p.x - (pt.x - sizeRef.current.w / 2), p.y - (pt.y - sizeRef.current.h / 2), nz);
      const next = { lat: c.lat, lng: c.lng, zoom: nz };
      viewRef.current = next;
      setView(next);
    },
    [fromScreen],
  );

  useEffect(() => {
    const el = box.current;
    if (!el || !interactive) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (anim.current) cancelAnimationFrame(anim.current);
      const r = el.getBoundingClientRect();
      const delta = e.deltaMode === 1 ? e.deltaY * 40 : e.deltaY;
      zoomAround({ x: e.clientX - r.left, y: e.clientY - r.top }, viewRef.current.zoom - delta * 0.0025);
      if (wheelTimer.current) clearTimeout(wheelTimer.current);
      wheelTimer.current = window.setTimeout(() => emitMoveEnd(true), 260);
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, [interactive, zoomAround, emitMoveEnd]);

  const local = (e: { clientX: number; clientY: number }) => {
    const r = box.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const onPointerDown = (e: RPointerEvent<HTMLDivElement>) => {
    if (!interactive) return;
    if (anim.current) cancelAnimationFrame(anim.current);
    const d = drag.current;
    d.pointers.set(e.pointerId, local(e));
    // La cattura del puntatore parte solo quando inizia il trascinamento:
    // catturarlo subito "ruberebbe" il click ai marker e ai cluster.
    d.downOnMarker = !!(e.target as HTMLElement).closest('[data-marker],button');
    const pts = [...d.pointers.values()];
    if (pts.length === 1) {
      d.moved = false;
      d.start = { view: { ...viewRef.current }, x: pts[0]!.x, y: pts[0]!.y };
    } else if (pts.length === 2) {
      const [a, b] = pts as [{ x: number; y: number }, { x: number; y: number }];
      d.start = { view: { ...viewRef.current }, x: 0, y: 0, dist: Math.hypot(a.x - b.x, a.y - b.y), mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 } };
      d.moved = true;
      d.pointers.forEach((_, id) => {
        try {
          box.current?.setPointerCapture(id);
        } catch {
          /* noop */
        }
      });
    }
  };

  const onPointerMove = (e: RPointerEvent<HTMLDivElement>) => {
    const d = drag.current;
    if (!d.pointers.has(e.pointerId) || !d.start) return;
    d.pointers.set(e.pointerId, local(e));
    const pts = [...d.pointers.values()];
    if (pts.length >= 2 && d.start.dist && d.start.mid) {
      const [a, b] = pts as [{ x: number; y: number }, { x: number; y: number }];
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      zoomAround(d.start.mid, d.start.view.zoom + Math.log2(dist / d.start.dist), d.start.view);
      return;
    }
    const p = pts[0]!;
    const dx = p.x - d.start.x;
    const dy = p.y - d.start.y;
    if (!d.moved && Math.hypot(dx, dy) < 5) return;
    if (!d.moved) {
      try {
        box.current?.setPointerCapture(e.pointerId);
      } catch {
        /* puntatore già rilasciato */
      }
    }
    d.moved = true;
    const c = project(d.start.view, d.start.view.zoom);
    const ll = unproject(c.x - dx, c.y - dy, d.start.view.zoom);
    const next = { lat: ll.lat, lng: ll.lng, zoom: d.start.view.zoom };
    viewRef.current = next;
    setView(next);
  };

  const onPointerUp = (e: RPointerEvent<HTMLDivElement>) => {
    const d = drag.current;
    if (!d.pointers.has(e.pointerId)) return;
    const pt = local(e);
    d.pointers.delete(e.pointerId);
    if (d.pointers.size > 0) {
      // da pinch a un dito: riparte il pan dal dito rimasto
      const rest = [...d.pointers.values()][0]!;
      d.start = { view: { ...viewRef.current }, x: rest.x, y: rest.y };
      return;
    }
    if (d.moved) emitMoveEnd(true);
    else if (!d.downOnMarker && !(e.target as HTMLElement).closest('[data-marker]')) {
      // tap sulla mappa vuota
      if (cb.current.editable?.placing) cb.current.editable.onChange(fromScreen(pt.x, pt.y));
      else cb.current.onSelect?.(null);
    }
    d.start = undefined;
  };

  const onDoubleClick = (e: React.MouseEvent) => {
    if (!interactive || (e.target as HTMLElement).closest('[data-marker]')) return;
    const p = local(e);
    animateTo({ ...fromScreen(p.x, p.y), zoom: clampZ(viewRef.current.zoom + 1) }, true);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (!interactive) return;
    const v = viewRef.current;
    const step = 90;
    const moves: Record<string, [number, number]> = { ArrowUp: [0, -step], ArrowDown: [0, step], ArrowLeft: [-step, 0], ArrowRight: [step, 0] };
    if (moves[e.key]) {
      e.preventDefault();
      const [dx, dy] = moves[e.key]!;
      const c = project(v, v.zoom);
      animateTo({ ...unproject(c.x + dx, c.y + dy, v.zoom), zoom: v.zoom }, true);
    } else if (e.key === '+' || e.key === '=') animateTo({ ...v, zoom: clampZ(Math.round(v.zoom) + 1) }, true);
    else if (e.key === '-') animateTo({ ...v, zoom: clampZ(Math.round(v.zoom) - 1) }, true);
  };

  // ─── Clustering ─────────────────────────────────────────────
  const index = useMemo(() => {
    const sc = new Supercluster<{ id: string }, Record<string, never>>({ radius: 58, maxZoom: 16 });
    sc.load(points.filter((p) => p.id !== selectedId).map((p) => ({ type: 'Feature', properties: { id: p.id }, geometry: { type: 'Point', coordinates: [p.lng, p.lat] } })));
    return sc;
  }, [points, selectedId]);
  const byId = useMemo(() => new Map(points.map((p) => [p.id, p])), [points]);

  const items = useMemo(() => {
    if (!size.w) return [];
    const b = boundsOfView(view);
    const padDeg = (b.east - b.west) * 0.1;
    const bbox: [number, number, number, number] = [b.west - padDeg, b.south - padDeg, b.east + padDeg, b.north + padDeg];
    if (!clustering) return points.filter((p) => p.id !== selectedId).map((p) => ({ kind: 'point' as const, p }));
    return index.getClusters(bbox, Math.floor(view.zoom)).map((f) => {
      const props = f.properties as ClusterProps;
      const [lng, lat] = f.geometry.coordinates as [number, number];
      if (props.cluster) return { kind: 'cluster' as const, id: props.cluster_id, count: props.point_count, lat, lng };
      return { kind: 'point' as const, p: byId.get(props.id)! };
    });
  }, [index, view, size, boundsOfView, clustering, points, selectedId, byId]);

  const selected = selectedId ? byId.get(selectedId) : undefined;

  const openCluster = (id: number, lat: number, lng: number) => {
    const z = Math.min(index.getClusterExpansionZoom(id), MAX_Z);
    animateTo({ lat, lng, zoom: Math.max(z, viewRef.current.zoom + 1) }, true);
  };

  // ─── Rendering ──────────────────────────────────────────────
  const grid = 128 * 2 ** (view.zoom - Math.floor(view.zoom));
  const cpx = size.w ? project(view, view.zoom) : { x: 0, y: 0 };
  const bgPos = `${(-(cpx.x - size.w / 2)) % grid}px ${(-(cpx.y - size.h / 2)) % grid}px`;
  const userPx = user && size.w ? toScreen(user, view) : null;
  const radiusPx = user && radiusKm ? (radiusKm * 1000) / metersPerPixel(user.lat, view.zoom) : 0;
  const editPos = dragPin ?? editable?.position ?? null;
  const editPx = editPos && size.w ? toScreen(editPos, view) : null;

  const marker = (p: MapPoint) => {
    const s = toScreen(p, view);
    const isSel = p.id === selectedId;
    const isHover = p.id === hoveredId;
    const sponsored = p.sponsored ?? p.highlighted;
    const pos = { left: 0, top: 0, transform: `translate(${s.x}px, ${s.y}px)`, zIndex: isSel ? 30 : isHover ? 20 : sponsored ? 11 : 10 };
    const body = (
      <>
        <span
          className={cn(
            'absolute left-1/2 top-full -translate-x-1/2 -translate-y-full flex items-center justify-center rounded-full rounded-bl-md border-2 shadow-[0_4px_14px_rgba(22,22,26,.28)] transition-transform duration-150',
            isSel ? 'h-11 w-11 scale-110 border-white bg-ink text-lg' : sponsored ? 'h-10 w-10 border-white bg-coral text-base' : 'h-9 w-9 border-white bg-white text-base',
            isHover && !isSel && 'scale-[1.18] border-coral',
            'focus-visible:ring-2 focus-visible:ring-coral',
          )}
          style={{ rotate: '-45deg' }}
        >
          <span style={{ rotate: '45deg' }}>{p.emoji ?? '🥢'}</span>
        </span>
        {(isSel || isHover) && (
          <span className="pointer-events-none absolute left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-ink px-3 py-1 text-xs font-semibold text-white shadow-lift" style={{ top: isSel ? -26 : -20 }}>
            {p.label}
          </span>
        )}
      </>
    );
    // Anteprima statica (es. dentro un link): segnaposto decorativi, nessun controllo annidato
    if (!interactive) {
      return (
        <div key={p.id} data-marker aria-hidden="true" className="absolute -ml-5 -mt-11 h-11 w-10" style={pos}>
          {body}
        </div>
      );
    }
    return (
      <button
        key={p.id}
        type="button"
        data-marker
        aria-label={`${p.label}${sponsored ? ', sponsorizzato' : ''}`}
        aria-pressed={isSel}
        onClick={(e) => {
          e.stopPropagation();
          if (drag.current.moved) return;
          onSelect?.(p.id);
        }}
        onMouseEnter={() => onHover?.(p.id)}
        onMouseLeave={() => onHover?.(null)}
        onFocus={() => onHover?.(p.id)}
        onBlur={() => onHover?.(null)}
        // Area cliccabile reale (40×44) con la punta del segnaposto sulla coordinata
        className="absolute -ml-5 -mt-11 h-11 w-10 outline-none"
        style={pos}
      >
        {body}
      </button>
    );
  };

  return (
    <div
      ref={box}
      role={interactive ? 'application' : 'img'}
      aria-label={ariaLabel ?? 'Mappa dei ristoranti'}
      aria-roledescription="mappa"
      tabIndex={interactive ? 0 : undefined}
      onKeyDown={onKeyDown}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      onDoubleClick={onDoubleClick}
      className={cn(
        'relative isolate select-none overflow-hidden bg-[#EDF0EA] outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-coral',
        interactive ? 'cursor-grab touch-none active:cursor-grabbing' : 'pointer-events-none',
        editable?.placing && '!cursor-crosshair',
        className,
      )}
      style={{
        backgroundImage: 'linear-gradient(#DDE3DA 1px, transparent 1px), linear-gradient(90deg, #DDE3DA 1px, transparent 1px)',
        backgroundSize: `${grid}px ${grid}px`,
        backgroundPosition: bgPos,
      }}
    >
      {size.w > 0 && (
        <>
          {/* Comuni di riferimento */}
          {view.zoom >= 8.5 &&
            placeLandmarks(landmarks ?? [], (l) => toScreen(l, view), size).map(({ l, s }) => {
              return (
                <span key={l.label} className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 whitespace-nowrap text-[11px] font-semibold uppercase tracking-[0.14em] text-[#9AA59B]" style={{ left: s.x, top: s.y }}>
                  {l.label}
                </span>
              );
            })}

          {/* Posizione utente e raggio */}
          {userPx && radiusPx > 0 && (
            <span className="pointer-events-none absolute rounded-full border-2 border-[#3B82F6]/40 bg-[#3B82F6]/[0.07]" style={{ left: userPx.x - radiusPx, top: userPx.y - radiusPx, width: radiusPx * 2, height: radiusPx * 2 }} />
          )}
          {userPx && (
            <span className="pointer-events-none absolute z-40 -translate-x-1/2 -translate-y-1/2" style={{ left: userPx.x, top: userPx.y }} aria-label="La tua posizione">
              <span className="absolute -inset-3 animate-ping rounded-full bg-[#3B82F6]/25" />
              <span className="relative block h-4 w-4 rounded-full border-[3px] border-white bg-[#3B82F6] shadow" />
            </span>
          )}

          {items.map((it) =>
            it.kind === 'cluster' ? (
              (() => {
                const s = toScreen(it, view);
                const d = Math.min(58, 34 + Math.log2(it.count) * 6);
                return (
                  <button
                    key={`c${it.id}`}
                    type="button"
                    data-marker
                    aria-label={`${it.count} ristoranti in questa zona: ingrandisci`}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (!drag.current.moved) openCluster(it.id, it.lat, it.lng);
                    }}
                    className="absolute z-[15] flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-[3px] border-white bg-ink font-display text-sm font-bold text-white shadow-lift transition hover:scale-110"
                    style={{ left: s.x, top: s.y, width: d, height: d }}
                  >
                    {it.count}
                  </button>
                );
              })()
            ) : (
              marker(it.p)
            ),
          )}
          {selected && marker(selected)}

          {/* Marker modificabile (editor) */}
          {editPx && (
            <span
              data-marker
              role="slider"
              aria-label="Posizione del locale: trascina per spostare"
              aria-valuetext={`${editPos!.lat.toFixed(5)}, ${editPos!.lng.toFixed(5)}`}
              tabIndex={0}
              className="absolute z-50 -translate-x-1/2 -translate-y-full cursor-move touch-none"
              style={{ left: editPx.x, top: editPx.y }}
              onPointerDown={(e) => {
                e.stopPropagation();
                (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                setDragPin(editPos);
              }}
              onPointerMove={(e) => {
                if (!dragPin) return;
                e.stopPropagation();
                const p = local(e);
                setDragPin(fromScreen(p.x, p.y));
              }}
              onPointerUp={(e) => {
                e.stopPropagation();
                if (dragPin) editable?.onChange(dragPin);
                setDragPin(null);
              }}
            >
              <svg width="36" height="46" viewBox="0 0 36 46" aria-hidden>
                <path d="M18 45C18 45 34 28.5 34 17A16 16 0 1 0 2 17C2 28.5 18 45 18 45Z" fill="#FF5A4E" stroke="#fff" strokeWidth="3" />
                <circle cx="18" cy="17" r="6" fill="#fff" />
              </svg>
            </span>
          )}
        </>
      )}

      {interactive && controls && (
        <div className="absolute bottom-3 right-3 z-40 flex flex-col overflow-hidden rounded-2xl bg-white shadow-card">
          <button type="button" aria-label="Aumenta zoom" onPointerDown={(e) => e.stopPropagation()} onClick={() => animateTo({ ...viewRef.current, zoom: clampZ(Math.round(viewRef.current.zoom) + 1) }, true)} className="flex h-10 w-10 items-center justify-center hover:bg-cream">
            <Plus className="h-4 w-4" />
          </button>
          <span className="h-px bg-line" />
          <button type="button" aria-label="Riduci zoom" onPointerDown={(e) => e.stopPropagation()} onClick={() => animateTo({ ...viewRef.current, zoom: clampZ(Math.round(viewRef.current.zoom) - 1) }, true)} className="flex h-10 w-10 items-center justify-center hover:bg-cream">
            <Minus className="h-4 w-4" />
          </button>
        </div>
      )}
      <span className="pointer-events-none absolute bottom-2 left-3 z-30 rounded-full bg-white/80 px-2 py-0.5 text-[10px] text-ink-muted">Mappa semplificata</span>
    </div>
  );
});

/** Etichette dei comuni senza sovrapposizioni: prima i più popolosi, poi gli altri se c'è spazio. */
function placeLandmarks<T extends MapLandmark>(list: T[], project: (l: T) => { x: number; y: number }, size: { w: number; h: number }) {
  const placed: { l: T; s: { x: number; y: number }; box: [number, number, number, number] }[] = [];
  const sorted = [...list].sort((a, b) => (b.rank ?? 0) - (a.rank ?? 0));
  for (const l of sorted) {
    const s = project(l);
    if (s.x < -80 || s.y < -20 || s.x > size.w + 80 || s.y > size.h + 20) continue;
    const w = l.label.length * 8.6 + 16;
    const box: [number, number, number, number] = [s.x - w / 2, s.y - 11, s.x + w / 2, s.y + 11];
    if (placed.some((p) => box[0] < p.box[2] && box[2] > p.box[0] && box[1] < p.box[3] && box[3] > p.box[1])) continue;
    placed.push({ l, s, box });
  }
  return placed;
}
