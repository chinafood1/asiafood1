// Contratto comune per le mappe: qualunque provider riceve gli stessi punti
// ed espone gli stessi comandi (flyTo, fitBounds…).

export interface LatLng {
  lat: number;
  lng: number;
}

/** Riquadro geografico visibile/di ricerca. */
export interface GeoBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}

export interface MapPoint {
  id: string;
  lat: number;
  lng: number;
  label: string;
  emoji?: string | null;
  /** Campagna sponsorizzata attiva: marker leggermente più evidente (sempre dichiarato nella card). */
  sponsored?: boolean;
  /** @deprecated usa `sponsored` (compatibilità Fase 1) */
  highlighted?: boolean;
}

export interface MapLandmark extends LatLng {
  label: string;
  /** Priorità dell'etichetta (es. popolazione): con poco spazio si mostrano le più importanti. */
  rank?: number;
}

export interface MoveEndEvent {
  bounds: GeoBounds;
  center: LatLng;
  zoom: number;
  /** true se il movimento è stato causato dall'utente (trascinamento, zoom), false se programmatico */
  userInitiated: boolean;
}

export interface MapHandle {
  flyTo(center: LatLng, zoom?: number): void;
  fitBounds(bounds: GeoBounds, padding?: number): void;
  getBounds(): GeoBounds | null;
  getZoom(): number;
}

export interface InteractiveMapProps {
  points: MapPoint[];
  selectedId?: string | null;
  hoveredId?: string | null;
  onSelect?: (id: string | null) => void;
  onHover?: (id: string | null) => void;
  onMoveEnd?: (e: MoveEndEvent) => void;
  /** Posizione dell'utente (solo in memoria) e raggio di ricerca da disegnare. */
  user?: LatLng | null;
  radiusKm?: number | null;
  initialView?: { center: LatLng; zoom: number } | { bounds: GeoBounds };
  /** Riferimenti geografici (comuni) per orientarsi nella mappa integrata. */
  landmarks?: MapLandmark[];
  /** false = anteprima statica (niente pan/zoom), es. nella scheda ristorante. */
  interactive?: boolean;
  clustering?: boolean;
  /** Marker singolo trascinabile (editor Admin/ristoratore). */
  editable?: { position: LatLng | null; placing?: boolean; onChange: (p: LatLng) => void };
  /** Spazio da lasciare libero (es. bottom sheet mobile) quando si centra un punto. */
  padding?: { top?: number; bottom?: number; left?: number; right?: number };
  onProviderError?: (message: string) => void;
  /** Pulsanti +/− (su mobile si usa il pinch e si lascia spazio a lista e carosello). */
  controls?: boolean;
  className?: string;
  ariaLabel?: string;
}

/** Props della vecchia MapView (anteprime semplici). */
export interface MapViewProps {
  points: MapPoint[];
  center?: LatLng;
  user?: LatLng | null;
  activeId?: string | null;
  onSelect?: (id: string) => void;
  className?: string;
  /** Zoom iniziale per singolo punto (scheda ristorante). */
  zoom?: number;
}

// ─── Utility geografiche ──────────────────────────────────────
export const KM_PER_DEG_LAT = 111.32;

/** Riquadro che contiene un cerchio di raggio `km` attorno a `c` (per il prefiltro). */
export function boundsAround(c: LatLng, km: number): GeoBounds {
  const dLat = km / KM_PER_DEG_LAT;
  const dLng = km / (KM_PER_DEG_LAT * Math.max(Math.cos((c.lat * Math.PI) / 180), 0.01));
  return { north: c.lat + dLat, south: c.lat - dLat, east: c.lng + dLng, west: c.lng - dLng };
}

export function boundsOf(points: LatLng[]): GeoBounds | null {
  if (!points.length) return null;
  return {
    north: Math.max(...points.map((p) => p.lat)),
    south: Math.min(...points.map((p) => p.lat)),
    east: Math.max(...points.map((p) => p.lng)),
    west: Math.min(...points.map((p) => p.lng)),
  };
}

export const inBounds = (p: LatLng, b: GeoBounds) => p.lat <= b.north && p.lat >= b.south && p.lng <= b.east && p.lng >= b.west;

/** Arrotonda il riquadro verso l'esterno (≈ 1 km) per URL stabili e cache. */
export function roundBounds(b: GeoBounds, digits = 2): GeoBounds {
  const f = 10 ** digits;
  return { north: Math.ceil(b.north * f) / f, south: Math.floor(b.south * f) / f, east: Math.ceil(b.east * f) / f, west: Math.floor(b.west * f) / f };
}

export const boundsToParam = (b: GeoBounds) => [b.west, b.south, b.east, b.north].map((x) => x.toFixed(3)).join(',');
export function boundsFromParam(s: string | null): GeoBounds | null {
  if (!s) return null;
  const [west, south, east, north] = s.split(',').map(Number);
  if ([west, south, east, north].some((x) => x === undefined || !Number.isFinite(x))) return null;
  if (south! >= north! || west! >= east! || Math.abs(north!) > 85 || Math.abs(east!) > 180) return null;
  return { west: west!, south: south!, east: east!, north: north! };
}

/** Area di lancio (provincia di Taranto) usata come vista iniziale. */
export const LAUNCH_BOUNDS: GeoBounds = { north: 40.78, south: 40.28, east: 17.8, west: 16.68 };

/** Poligono che approssima un cerchio (per disegnare il raggio). */
export function circlePolygon(c: LatLng, km: number, steps = 64): [number, number][] {
  const out: [number, number][] = [];
  for (let i = 0; i <= steps; i++) {
    const a = (i / steps) * 2 * Math.PI;
    const dLat = (km / KM_PER_DEG_LAT) * Math.sin(a);
    const dLng = (km / (KM_PER_DEG_LAT * Math.cos((c.lat * Math.PI) / 180))) * Math.cos(a);
    out.push([c.lng + dLng, c.lat + dLat]);
  }
  return out;
}

const loaded = new Map<string, Promise<void>>();

/** Carica uno script esterno una sola volta. */
export function loadScript(src: string, css?: string): Promise<void> {
  if (css && !document.querySelector(`link[href="${css}"]`)) {
    const l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = css;
    document.head.appendChild(l);
  }
  if (!loaded.has(src)) {
    loaded.set(
      src,
      new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = src;
        s.async = true;
        s.onload = () => resolve();
        s.onerror = () => {
          loaded.delete(src);
          reject(new Error(`Impossibile caricare ${src}`));
        };
        document.head.appendChild(s);
      }),
    );
  }
  return loaded.get(src)!;
}
