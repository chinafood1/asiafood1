import { APP } from '@/config/app';

export const cn = (...parts: (string | false | null | undefined)[]) => parts.filter(Boolean).join(' ');

const eur = new Intl.NumberFormat(APP.locale, { style: 'currency', currency: APP.currency, minimumFractionDigits: 2 });
const eurShort = new Intl.NumberFormat(APP.locale, { style: 'currency', currency: APP.currency, maximumFractionDigits: 0 });

export function formatPrice(v: number | null | undefined, short = false): string {
  if (v === null || v === undefined || Number.isNaN(Number(v))) return '—';
  const n = Number(v);
  return short && Number.isInteger(n) ? eurShort.format(n) : eur.format(n);
}

export const priceRangeLabel = (p: number | null | undefined) => (p ? '€'.repeat(p) : '');

export const PRICE_RANGE_TEXT: Record<number, string> = {
  1: 'Economico',
  2: 'Nella media',
  3: 'Curato',
  4: 'Alta cucina',
};

/**
 * Distanza leggibile senza false precisioni:
 * < 1 km → metri arrotondati a 10 m (min. 10 m) · < 100 km → km con max 1 decimale · oltre → km interi.
 */
export function formatDistance(km: number | undefined | null): string {
  if (km === undefined || km === null || !Number.isFinite(km)) return '';
  if (km < 0.995) return `${Math.max(10, Math.round((km * 1000) / 10) * 10)} m`;
  if (km < 100) return `${(Math.round(km * 10) / 10).toLocaleString(APP.locale, { maximumFractionDigits: 1 })} km`;
  return `${Math.round(km).toLocaleString(APP.locale)} km`;
}

export function formatDate(iso: string | null | undefined, opts: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric' }) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString(APP.locale, { timeZone: APP.timezone, ...opts });
}

export function slugify(input: string): string {
  return input
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/&/g, ' ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export const initials = (name: string) =>
  name
    .replace(/[^\p{L}\p{N} ]/gu, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join('');

export const SERVICE_LABELS: Record<string, string> = {
  wifi: 'Wi-Fi',
  dehors: 'Dehors',
  parcheggio: 'Parcheggio',
  accessibile: 'Accessibile',
  aria_condizionata: 'Aria condizionata',
  pagamento_carta: 'Pagamento con carta',
  vegetariano: 'Opzioni vegetariane',
  vegano: 'Opzioni vegane',
  senza_glutine: 'Opzioni senza glutine',
  famiglie: 'Adatto alle famiglie',
  gruppi: 'Ideale per gruppi',
  asporto: 'Asporto',
  bancone: 'Posti al bancone',
  cocktail_bar: 'Cocktail bar',
  vista_mare: 'Vista mare',
  feste_private: 'Feste private',
  pet_friendly: 'Animali ammessi',
};

export const MENU_TAG_LABELS: Record<string, string> = {
  vegetarian: 'Vegetariano',
  vegan: 'Vegano',
  spicy: 'Piccante',
  gluten_free: 'Senza glutine',
  signature: 'Signature',
};

export const whatsappUrl = (number: string, text?: string) =>
  `https://wa.me/${number.replace(/[^\d]/g, '')}${text ? `?text=${encodeURIComponent(text)}` : ''}`;

export const telUrl = (phone: string) => `tel:${phone.replace(/[^\d+]/g, '')}`;

export const socialUrl = (kind: 'instagram' | 'facebook' | 'tiktok', value: string) => {
  if (/^https?:\/\//.test(value)) return value;
  const handle = value.replace(/^@/, '');
  return kind === 'instagram'
    ? `https://instagram.com/${handle}`
    : kind === 'facebook'
      ? `https://facebook.com/${handle}`
      : `https://tiktok.com/@${handle}`;
};
