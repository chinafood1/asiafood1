// ─────────────────────────────────────────────────────────────
//  Fase 12 · Attribuzione dell'acquisizione (first-party, senza identificativi).
//  - Una visita per sessione di navigazione: canale + UTM + percorso di atterraggio (senza query string).
//  - L'iscrizione viene attribuita al canale SOLO con consenso "Statistiche".
//  - Nessun cookie, nessun servizio esterno, nessun dato personale.
// ─────────────────────────────────────────────────────────────
import { classifyChannel, cleanUtmValue } from '@shared/utm';
import { api } from '@/services';
import { hasConsent, subscribeConsent } from './consent';
import type { VisitInput } from '@/types/launch';
import { deviceType, trackContext } from './trackContext';

export { deviceType, trackContext };

const TOUCH_KEY = 'af_touch';
/** Fase 13: primo canale noto del browser (first touch), salvato SOLO con consenso "Statistiche". */
const FIRST_KEY = 'af_first_touch';

function readFirst(): VisitInput | null {
  try {
    const raw = localStorage.getItem(FIRST_KEY);
    return raw ? (JSON.parse(raw) as VisitInput) : null;
  } catch {
    return null;
  }
}
/** Salva il first touch solo con consenso (dopo il banner può essere chiamata di nuovo). */
export function rememberFirstTouch() {
  if (!hasConsent('analytics') || readFirst()) return;
  const t = readTouch();
  if (!t) return;
  try {
    localStorage.setItem(FIRST_KEY, JSON.stringify(t));
  } catch {
    /* ignorato */
  }
}

function readTouch(): VisitInput | null {
  try {
    const raw = sessionStorage.getItem(TOUCH_KEY);
    return raw ? (JSON.parse(raw) as VisitInput) : null;
  } catch {
    return null;
  }
}

/** Da chiamare all'avvio: registra il primo atterraggio della sessione (una sola volta). */
export function captureLanding(loc: Location = window.location, referrer: string = document.referrer) {
  if (readTouch()) return;
  const q = new URLSearchParams(loc.search);
  const code = (q.get('code') ?? q.get('promo') ?? '').replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 20) || null;
  const touch: VisitInput = {
    channel: classifyChannel({ utm_source: q.get('utm_source'), utm_medium: q.get('utm_medium'), path: loc.pathname, referrer, ownHost: loc.hostname }),
    utm_source: cleanUtmValue(q.get('utm_source')) || null,
    utm_medium: cleanUtmValue(q.get('utm_medium')) || null,
    utm_campaign: cleanUtmValue(q.get('utm_campaign')) || null,
    utm_content: cleanUtmValue(q.get('utm_content')) || null,
    landing_path: loc.pathname.slice(0, 200),
    promo_code: code,
    market: 'taranto',
  };
  try {
    sessionStorage.setItem(TOUCH_KEY, JSON.stringify(touch));
  } catch {
    /* storage non disponibile: la visita si registra comunque una volta */
  }
  void api.launch.recordVisit({ ...touch, device_type: deviceType() });
  rememberFirstTouch();
  // Consenso dato dopo l'atterraggio: il first touch si salva in quel momento
  try {
    subscribeConsent(rememberFirstTouch);
  } catch {
    /* ignorato */
  }
  api.trackAppEvent('session_started', { source: touch.channel, metadata: trackContext() });
}

/** Dopo l'iscrizione: collega il canale di arrivo all'account, solo con consenso "Statistiche". */
export async function attributeSignup(userId: string) {
  if (!hasConsent('analytics')) return;
  const key = `af_attr_${userId}`;
  try {
    if (localStorage.getItem(key)) return;
  } catch {
    return;
  }
  const touch = readTouch();
  if (!touch) return;
  // Modello semplice e dichiarato: first touch (se noto) + last touch (sessione dell'iscrizione)
  const first = readFirst() ?? touch;
  const ok = await api.launch.attributeSignup({ ...first, last_channel: touch.channel, last_utm_source: touch.utm_source ?? null, last_utm_campaign: touch.utm_campaign ?? null });
  // Fase 13: iscrizione come conversione degli esperimenti con metrica "signup"
  if (ok) void import('./experiments').then((m) => m.experimentGoal('signup'));
  try {
    localStorage.setItem(key, ok ? '1' : '0');
  } catch {
    /* ignorato */
  }
}
