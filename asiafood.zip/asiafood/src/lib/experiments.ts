// ─────────────────────────────────────────────────────────────
//  Fase 12 · Esperimenti A/B leggeri (max 2 attivi, gestiti dall'Admin).
//  Variante stabile per browser (hash di un identificativo locale casuale);
//  l'esposizione viene registrata SOLO con consenso "Statistiche".
// ─────────────────────────────────────────────────────────────
import { useEffect, useState } from 'react';
import { api } from '@/services';
import { hasConsent } from './consent';
import { pickVariant } from '@shared/experiment';
import { pickWeighted } from '@shared/growth';

export { pickVariant };

let running: Promise<{ key: string; variants: string[]; weights?: number[] }[]> | null = null;
const exposed = new Set<string>();

function localId(): string {
  try {
    let id = localStorage.getItem('af_exp_id');
    if (!id) {
      id = Array.from(crypto.getRandomValues(new Uint8Array(8)), (b) => b.toString(16).padStart(2, '0')).join('');
      localStorage.setItem('af_exp_id', id);
    }
    return id;
  } catch {
    return 'no-storage';
  }
}

/** Restituisce la variante dell'esperimento (o "control" se non attivo). */
export function useExperiment(key: string): string {
  const [variant, setVariant] = useState('control');
  useEffect(() => {
    let alive = true;
    running ??= api.launch.runningExperiments().catch(() => []);
    void running.then((list) => {
      const e = list.find((x) => x.key === key);
      if (!alive || !e) return;
      // Fase 13: allocazione pesata (a pesi uguali coincide con pickVariant della Fase 12)
      const v = pickWeighted(key, e.variants, e.weights, localId());
      setVariant(v);
      if (!exposed.has(key) && hasConsent('analytics')) {
        exposed.add(key);
        api.trackAppEvent('experiment_exposure', { source: 'experiment', metadata: { experiment: key, variant: v } });
        api.growth.experimentAssign(key, v, localId());
      }
    });
    return () => {
      alive = false;
    };
  }, [key]);
  return variant;
}

/**
 * Fase 13: conversione sulla metrica primaria degli esperimenti attivi (solo con consenso "Statistiche").
 * Metriche ammesse: reservation_completed, order_completed, coupon_claimed, signup.
 */
export function experimentGoal(metric: 'reservation_completed' | 'order_completed' | 'coupon_claimed' | 'signup') {
  if (!hasConsent('analytics')) return;
  api.growth.experimentGoal(metric, localId());
}

/** Fase 13: segnale di conversione della sessione (solo funnel; i totali restano quelli del database). */
export function sessionConversion(kind: 'reservation_completed' | 'order_completed' | 'coupon_claimed', restaurantId?: string | null) {
  if (!hasConsent('analytics')) return;
  api.trackAppEvent('conversion', { restaurantId: restaurantId ?? null, source: 'web', metadata: { kind } });
  experimentGoal(kind);
}
