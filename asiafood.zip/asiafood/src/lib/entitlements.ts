// ─────────────────────────────────────────────────────────────
//  Entitlements: UNICO punto in cui il frontend decide cosa un
//  piano consente. Le regole vivono nel DB (plan_features, modificabili
//  da /admin/plans); qui solo lettura. Il DB le applica comunque
//  (trigger e RPC): il frontend serve a evitare errori e mostrare
//  l'invito all'upgrade al posto di un errore tecnico.
// ─────────────────────────────────────────────────────────────
import type { PlanCode, PlanWithFeatures } from '@/types/domain';

export type FeatureKey =
  | 'profile_full'
  | 'menu_enabled'
  | 'max_menu_items'
  | 'max_images'
  | 'whatsapp_enabled'
  | 'analytics_enabled'
  | 'advanced_analytics'
  | 'offers_enabled'
  | 'max_active_offers'
  | 'coupons_enabled'
  | 'max_active_coupons'
  | 'reservations_enabled'
  | 'premium_badge'
  | 'search_boost'
  | 'featured_listing'
  | 'sponsored_ads'
  | 'marketing_tools'
  | 'push_campaigns_enabled'
  | 'monthly_campaign_limit';

export interface FeatureInfo {
  label: string;
  description: string;
  /** limit = valore numerico (max elementi); flag = on/off. */
  kind: 'flag' | 'limit';
  group: 'Profilo' | 'Menu' | 'Promozioni' | 'Prenotazioni' | 'Statistiche' | 'Visibilità';
}

/** Catalogo delle feature: etichette per confronto piani, admin e modali di upgrade. */
export const FEATURES: Record<FeatureKey, FeatureInfo> = {
  profile_full: { label: 'Profilo completo', description: 'Descrizione estesa, social e servizi', kind: 'flag', group: 'Profilo' },
  max_images: { label: 'Foto in galleria', description: 'Numero massimo di foto', kind: 'limit', group: 'Profilo' },
  whatsapp_enabled: { label: 'Pulsante WhatsApp', description: 'Contatto diretto su WhatsApp dalla scheda', kind: 'flag', group: 'Profilo' },
  menu_enabled: { label: 'Menu digitale', description: 'Menu, categorie e piatti gestiti in autonomia', kind: 'flag', group: 'Menu' },
  max_menu_items: { label: 'Piatti nel menu', description: 'Numero massimo di piatti', kind: 'limit', group: 'Menu' },
  offers_enabled: { label: 'Offerte', description: 'Promozioni visibili nella scheda e nella pagina Offerte', kind: 'flag', group: 'Promozioni' },
  max_active_offers: { label: 'Offerte attive', description: 'Offerte attive contemporaneamente', kind: 'limit', group: 'Promozioni' },
  coupons_enabled: { label: 'Coupon', description: 'Coupon con codice personale e validazione in cassa', kind: 'flag', group: 'Promozioni' },
  max_active_coupons: { label: 'Coupon attivi', description: 'Coupon attivi contemporaneamente', kind: 'limit', group: 'Promozioni' },
  reservations_enabled: { label: 'Prenotazioni online', description: 'Prenotazione tavolo con agenda e disponibilità', kind: 'flag', group: 'Prenotazioni' },
  analytics_enabled: { label: 'Statistiche', description: 'Visualizzazioni, contatti, prenotazioni e coupon', kind: 'flag', group: 'Statistiche' },
  advanced_analytics: { label: 'Statistiche avanzate', description: 'Andamento giornaliero e provenienza delle visite', kind: 'flag', group: 'Statistiche' },
  premium_badge: { label: 'Badge Premium', description: 'Badge sulla scheda e nei risultati', kind: 'flag', group: 'Visibilità' },
  search_boost: { label: 'Maggiore visibilità', description: 'Priorità a parità di pertinenza nei risultati', kind: 'limit', group: 'Visibilità' },
  featured_listing: { label: 'Posizionamento in evidenza', description: 'Offerte in evidenza in home e nella pagina Offerte', kind: 'flag', group: 'Visibilità' },
  sponsored_ads: { label: 'Sponsorizzazione prioritaria', description: 'Campagne sponsorizzate assegnate dallo staff', kind: 'flag', group: 'Visibilità' },
  marketing_tools: { label: 'Campagne promozionali', description: 'Strumenti di marketing avanzati', kind: 'flag', group: 'Visibilità' },
  push_campaigns_enabled: { label: 'Campagne ai clienti', description: 'Notifiche in-app e push a follower e clienti che hanno dato il consenso', kind: 'flag', group: 'Promozioni' },
  monthly_campaign_limit: { label: 'Campagne al mese', description: 'Numero massimo di campagne inviate in un mese', kind: 'limit', group: 'Promozioni' },
};

export const FEATURE_ORDER = Object.keys(FEATURES) as FeatureKey[];

function row(plans: PlanWithFeatures[], plan: PlanCode | string | null | undefined, key: string) {
  return plans.find((p) => p.code === plan)?.plan_features.find((f) => f.feature_key === key);
}

/** La funzione è inclusa nel piano? (riga mancante = no) */
export function hasFeature(plans: PlanWithFeatures[], plan: PlanCode | string | null | undefined, key: FeatureKey): boolean {
  return !!row(plans, plan, key)?.enabled;
}

/** Limite numerico: null = illimitato, 0 = non disponibile. */
export function getFeatureLimit(plans: PlanWithFeatures[], plan: PlanCode | string | null | undefined, key: FeatureKey): number | null {
  const f = row(plans, plan, key);
  if (!f || !f.enabled) return 0;
  return f.limit_value;
}

/** true se si può aggiungere un elemento (current = elementi già presenti). */
export function withinLimit(plans: PlanWithFeatures[], plan: PlanCode | string | null | undefined, key: FeatureKey, current: number): boolean {
  const l = getFeatureLimit(plans, plan, key);
  return l === null || current < l;
}

/** Piano più economico (attivo) che include la funzione, per l'invito all'upgrade. */
export function requiredPlanFor(plans: PlanWithFeatures[], key: FeatureKey, minLimit = 1): PlanWithFeatures | undefined {
  return [...plans]
    .filter((p) => p.is_active)
    .sort((a, b) => a.sort_order - b.sort_order)
    .find((p) => {
      const f = p.plan_features.find((x) => x.feature_key === key);
      return !!f?.enabled && (FEATURES[key].kind === 'flag' || f.limit_value === null || f.limit_value >= minLimit);
    });
}

/** Testo leggibile di una feature per un piano (tabella di confronto). */
export function featureValueLabel(plans: PlanWithFeatures[], plan: PlanCode | string, key: FeatureKey): string | boolean {
  const f = row(plans, plan, key);
  if (!f || !f.enabled) return false;
  if (FEATURES[key].kind === 'flag') return true;
  if (key === 'search_boost') return f.limit_value ? (f.limit_value > 1 ? 'Massima' : 'Alta') : false;
  return f.limit_value === null ? 'Illimitati' : String(f.limit_value);
}

// ─── Errori di piano (dal DB o dalla sorgente demo) ────────────
export class PlanError extends Error {
  constructor(
    readonly kind: 'feature' | 'limit',
    readonly feature: FeatureKey,
  ) {
    super(kind === 'feature' ? 'Funzione non inclusa nel piano attuale.' : 'Hai raggiunto il limite del piano attuale.');
    this.name = 'PlanError';
  }
}

/** Riconosce i messaggi PLAN_FEATURE:<key> / PLAN_LIMIT:<key> sollevati dal DB. */
export function toPlanError(message: string | undefined | null): PlanError | null {
  const m = /PLAN_(FEATURE|LIMIT):([a-z_]+)/.exec(message ?? '');
  if (!m || !(m[2]! in FEATURES)) return null;
  return new PlanError(m[1] === 'LIMIT' ? 'limit' : 'feature', m[2] as FeatureKey);
}

export const isPlanError = (e: unknown): e is PlanError => e instanceof PlanError;
