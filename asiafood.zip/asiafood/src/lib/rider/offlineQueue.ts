// Azioni "sicure" del Rider conservate in locale quando la rete manca e inviate al ritorno.
// Solo conferme di arrivo/partenza: ritiro con codice, consegna e annullamenti richiedono SEMPRE il server.
const KEY = 'af_rider_queue_v1';
export const SAFE_ACTIONS = ['depart', 'arrived_restaurant', 'arrived_customer', 'not_ready'] as const;
export type SafeAction = (typeof SAFE_ACTIONS)[number];
interface Queued { job: string; action: SafeAction; at: number }

function read(): Queued[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || '[]') as Queued[];
  } catch {
    return [];
  }
}
function write(q: Queued[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(q.slice(-20)));
  } catch {
    /* storage non disponibile */
  }
}
export const isSafeAction = (a: string): a is SafeAction => (SAFE_ACTIONS as readonly string[]).includes(a);
export function enqueue(job: string, action: SafeAction) {
  write([...read().filter((x) => !(x.job === job && x.action === action)), { job, action, at: Date.now() }]);
}
export const pendingFor = (job: string) => read().filter((x) => x.job === job);
/** Invia le azioni in coda (in ordine). Quelle rifiutate dal server vengono scartate: vale lo stato del server. */
export async function flushQueue(send: (job: string, action: SafeAction) => Promise<unknown>) {
  const q = read();
  if (!q.length) return 0;
  write([]);
  let n = 0;
  for (const x of q) {
    if (Date.now() - x.at > 2 * 3600_000) continue;
    try {
      await send(x.job, x.action);
      n++;
    } catch {
      /* stato già cambiato o non valido: il server ha l'ultima parola */
    }
  }
  return n;
}
