// ─────────────────────────────────────────────────────────────
//  Tracciamento GPS del Rider, separato dalla UI (riusabile da una
//  futura app React Native / Capacitor: basta sostituire la sorgente
//  di posizione). Regole:
//   - attivo SOLO mentre il Rider è online (lo avvia/ferma la UI);
//   - frequenza dal server: ~15 s in consegna, ~60 s in attesa;
//   - alta precisione solo durante una consegna (risparmio batteria);
//   - se il Rider è fermo (< 25 m) gli invii si diradano;
//   - il server valida tutto (timestamp, salti, precisione).
// ─────────────────────────────────────────────────────────────
import type { LocationInput, LocationResult } from '@/types/logistics';

export interface TrackerOptions {
  send: (p: LocationInput) => Promise<LocationResult>;
  onResult?: (r: LocationResult, p: LocationInput) => void;
  onError?: (message: string) => void;
  /** Sorgente di posizione (default: navigator.geolocation). */
  geolocation?: Geolocation;
}

const STILL_METERS = 25;

function meters(a: LocationInput, b: LocationInput) {
  const R = 6371e3;
  const toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(b.latitude - a.latitude);
  const dLng = toRad(b.longitude - a.longitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.latitude)) * Math.cos(toRad(b.latitude)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export class RiderTracker {
  private watchId: number | null = null;
  private intervalMs = 60_000;
  private highAccuracy = false;
  private lastSent: { at: number; p: LocationInput } | null = null;
  private latest: LocationInput | null = null;
  private timer: ReturnType<typeof setInterval> | null = null;
  private sending = false;
  constructor(private readonly opts: TrackerOptions) {}

  get active() {
    return this.watchId !== null;
  }

  /** Avvia (o aggiorna) il tracciamento con la modalità indicata. */
  start(mode: { intervalSeconds: number; highAccuracy: boolean }) {
    const geo = this.opts.geolocation ?? (typeof navigator !== 'undefined' ? navigator.geolocation : undefined);
    if (!geo) {
      this.opts.onError?.('Il tuo dispositivo non supporta la geolocalizzazione.');
      return;
    }
    const changed = mode.highAccuracy !== this.highAccuracy;
    this.intervalMs = Math.max(5, mode.intervalSeconds) * 1000;
    this.highAccuracy = mode.highAccuracy;
    if (this.watchId !== null && !changed) return;
    this.stopWatch(geo);
    this.watchId = geo.watchPosition(
      (pos) => {
        this.latest = {
          latitude: pos.coords.latitude, longitude: pos.coords.longitude, accuracy: Math.round(pos.coords.accuracy),
          heading: pos.coords.heading ?? null, speed: pos.coords.speed ?? null, recorded_at: new Date(pos.timestamp || Date.now()).toISOString(),
        };
        void this.flush(false);
      },
      (err) => this.opts.onError?.(err.code === err.PERMISSION_DENIED ? 'Permesso di posizione negato: senza posizione non puoi ricevere consegne.' : 'Posizione non disponibile al momento.'),
      { enableHighAccuracy: this.highAccuracy, maximumAge: this.highAccuracy ? 5_000 : 30_000, timeout: 20_000 },
    );
    this.timer ??= setInterval(() => void this.flush(false), 5_000);
  }

  /** Invio immediato (es. appena accettata una consegna). */
  sendNow() {
    return this.flush(true);
  }

  stop() {
    const geo = this.opts.geolocation ?? (typeof navigator !== 'undefined' ? navigator.geolocation : undefined);
    if (geo) this.stopWatch(geo);
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.latest = null;
    this.lastSent = null;
  }

  private stopWatch(geo: Geolocation) {
    if (this.watchId !== null) geo.clearWatch(this.watchId);
    this.watchId = null;
  }

  private async flush(force: boolean) {
    const p = this.latest;
    if (!p || this.sending) return;
    const now = Date.now();
    if (!force && this.lastSent) {
      const elapsed = now - this.lastSent.at;
      // Fermo: invii diradati (x3); in movimento: intervallo del server
      const still = meters(this.lastSent.p, p) < STILL_METERS;
      if (elapsed < this.intervalMs * (still ? 3 : 1)) return;
    }
    this.sending = true;
    try {
      const r = await this.opts.send({ ...p, recorded_at: new Date(Math.min(Date.parse(p.recorded_at ?? '') || now, now)).toISOString() });
      if (r.accepted || r.reason !== 'TOO_FREQUENT') this.lastSent = { at: now, p };
      if (r.interval_seconds) this.intervalMs = r.interval_seconds * 1000;
      this.opts.onResult?.(r, p);
    } catch (e) {
      this.opts.onError?.(e instanceof Error ? e.message : 'Invio della posizione non riuscito.');
    } finally {
      this.sending = false;
    }
  }
}
