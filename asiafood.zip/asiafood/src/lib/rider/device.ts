// Utilità dispositivo per l'app Rider: navigazione esterna e schermo sempre acceso (uso prudente).

/** Link di navigazione verso l'app installata (nessun navigatore proprietario). */
export function navigationLinks(lat: number, lng: number, label?: string) {
  const q = `${lat},${lng}`;
  return {
    google: `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(q)}&travelmode=driving`,
    apple: `https://maps.apple.com/?daddr=${encodeURIComponent(q)}${label ? `&q=${encodeURIComponent(label)}` : ''}`,
    /** geo: apre l'app di mappe predefinita su Android */
    geo: `geo:${q}?q=${encodeURIComponent(q)}${label ? `(${encodeURIComponent(label)})` : ''}`,
  };
}
export const isAppleDevice = () => typeof navigator !== 'undefined' && /iPhone|iPad|iPod|Macintosh/.test(navigator.userAgent) && 'ontouchend' in document;

type WakeLockLike = { release(): Promise<void>; released?: boolean };
let lock: WakeLockLike | null = null;

/** Mantiene lo schermo acceso SOLO durante una consegna attiva (se supportato). */
export async function keepScreenOn(on: boolean) {
  const nav = navigator as Navigator & { wakeLock?: { request(type: 'screen'): Promise<WakeLockLike> } };
  try {
    if (on && !lock && nav.wakeLock && document.visibilityState === 'visible') lock = await nav.wakeLock.request('screen');
    if (!on && lock) {
      await lock.release();
      lock = null;
    }
  } catch {
    lock = null;
  }
}
export const wakeLockSupported = () => typeof navigator !== 'undefined' && 'wakeLock' in navigator;
