// ─────────────────────────────────────────────────────────────
//  Preparazione upload nel browser: validazione (dimensione, estensione, firma reale del file)
//  e, per le foto, ridimensionamento + ricodifica WebP. La ricodifica elimina anche i metadati
//  EXIF (es. coordinate GPS dello scatto). I limiti di MIME/dimensione valgono anche nello Storage.
// ─────────────────────────────────────────────────────────────
import { checkUpload, safeStorageName, type UploadKind } from '@shared/uploads';

export interface PreparedUpload {
  file: Blob;
  mime: string;
  ext: string;
  /** Nome casuale per lo storage (mai il nome originale: può contenere dati personali). */
  name: string;
}

async function reencode(file: Blob, maxDim: number, quality: number): Promise<Blob | null> {
  if (typeof createImageBitmap !== 'function' || typeof document === 'undefined') return null;
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * scale);
    const h = Math.round(bmp.height * scale);
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    canvas.getContext('2d')!.drawImage(bmp, 0, 0, w, h);
    bmp.close?.();
    const out = await new Promise<Blob | null>((res) => canvas.toBlob(res, 'image/webp', quality));
    return out && out.type === 'image/webp' ? out : null;
  } catch {
    return null;
  }
}

/**
 * Valida e prepara un file. Lancia un Error con messaggio in italiano se non è consentito.
 * - image: foto pubbliche (max 2000 px, WebP)   - proof: foto consegna (max 1600 px, WebP)   - document: PDF/immagini private
 */
export async function prepareUpload(file: File, kind: UploadKind, opts: { maxMb?: number } = {}): Promise<PreparedUpload> {
  const head = new Uint8Array(await file.slice(0, 512).arrayBuffer());
  const check = checkUpload(file, head, kind, opts.maxMb);
  if (!check.ok) throw new Error(check.error);
  let out: Blob = file;
  let mime = check.mime!;
  let ext = check.ext!;
  if ((kind === 'image' || kind === 'proof') && mime !== 'image/avif') {
    const re = await reencode(file, kind === 'image' ? 2000 : 1600, kind === 'image' ? 0.85 : 0.8);
    // Si usa la versione ricodificata se esiste (niente EXIF), anche se di poco più grande
    if (re && re.size <= Math.max(file.size * 1.1, 50_000)) {
      out = re;
      mime = 'image/webp';
      ext = 'webp';
    }
  }
  return { file: out, mime, ext, name: safeStorageName(ext) };
}
