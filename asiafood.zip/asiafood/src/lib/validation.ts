// Validazioni formali per dati aziendali italiani (non sostituiscono la verifica umana).

/** Partita IVA italiana: 11 cifre con carattere di controllo (algoritmo ufficiale). */
export function isValidVat(v: string): boolean {
  const d = v.replace(/^IT/i, '').replace(/\s/g, '');
  if (!/^\d{11}$/.test(d)) return false;
  let s = 0;
  for (let i = 0; i < 10; i++) {
    let n = Number(d[i]);
    if (i % 2 === 1) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    s += n;
  }
  return (10 - (s % 10)) % 10 === Number(d[10]);
}

/** Codice fiscale: 11 cifre (società) o 16 caratteri (persona fisica/ditta individuale). */
export const isValidTaxCode = (v: string) => /^\d{11}$/.test(v) || /^[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]$/i.test(v);
