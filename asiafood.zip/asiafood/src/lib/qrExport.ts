// ─────────────────────────────────────────────────────────────
//  Fase 12 · Esportazione QR (SVG vettoriale e PNG ad alta risoluzione) generati nel browser.
//  Il contenuto del QR è solo un URL pubblico (mai dati personali).
// ─────────────────────────────────────────────────────────────
type QrFactory = typeof import('qrcode-generator');
const load = () => import('qrcode-generator').then((m) => (m as unknown as { default: QrFactory }).default ?? (m as unknown as QrFactory));

async function matrix(value: string) {
  const qrcode = await load();
  const qr = qrcode(0, 'M');
  qr.addData(value);
  qr.make();
  const n = qr.getModuleCount();
  return { n, dark: (r: number, c: number) => qr.isDark(r, c) };
}

/** SVG autonomo (4 moduli di margine), adatto alla stampa professionale. */
export async function qrSvg(value: string, color = '#16161A'): Promise<string> {
  const { n, dark } = await matrix(value);
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (dark(r, c)) d += `M${c + 4},${r + 4}h1v1h-1z`;
  const s = n + 8;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${s} ${s}" width="1024" height="1024" shape-rendering="crispEdges"><rect width="${s}" height="${s}" fill="#fff"/><path d="${d}" fill="${color}"/></svg>`;
}

/** PNG (default 1024 px) disegnato su canvas. */
export async function qrPng(value: string, size = 1024): Promise<Blob> {
  const { n, dark } = await matrix(value);
  const s = n + 8;
  const cell = Math.floor(size / s);
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = cell * s;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#16161A';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (dark(r, c)) ctx.fillRect((c + 4) * cell, (r + 4) * cell, cell, cell);
  return new Promise((res, rej) => canvas.toBlob((b) => (b ? res(b) : rej(new Error('PNG non generato'))), 'image/png'));
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
