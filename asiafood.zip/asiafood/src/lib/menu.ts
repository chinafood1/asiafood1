// Allergeni (Reg. UE 1169/2011) ed etichette del menu.
// normalizeAllergens è lo specchio della funzione SQL normalize_allergens.
import type { AllergenCode, MenuItem, MenuType } from '@/types/domain';

export const ALLERGENS: { code: AllergenCode; name: string; eu: number; icon: string }[] = [
  { code: 'gluten', name: 'Glutine', eu: 1, icon: '🌾' },
  { code: 'crustaceans', name: 'Crostacei', eu: 2, icon: '🦐' },
  { code: 'eggs', name: 'Uova', eu: 3, icon: '🥚' },
  { code: 'fish', name: 'Pesce', eu: 4, icon: '🐟' },
  { code: 'peanuts', name: 'Arachidi', eu: 5, icon: '🥜' },
  { code: 'soy', name: 'Soia', eu: 6, icon: '🫘' },
  { code: 'milk', name: 'Latte', eu: 7, icon: '🥛' },
  { code: 'nuts', name: 'Frutta a guscio', eu: 8, icon: '🌰' },
  { code: 'celery', name: 'Sedano', eu: 9, icon: '🥬' },
  { code: 'mustard', name: 'Senape', eu: 10, icon: '🟡' },
  { code: 'sesame', name: 'Sesamo', eu: 11, icon: '⚪' },
  { code: 'sulphites', name: 'Solfiti', eu: 12, icon: '🍷' },
  { code: 'lupin', name: 'Lupini', eu: 13, icon: '🌼' },
  { code: 'molluscs', name: 'Molluschi', eu: 14, icon: '🦑' },
];
export const ALLERGEN_BY_CODE = Object.fromEntries(ALLERGENS.map((a) => [a.code, a])) as Record<AllergenCode, (typeof ALLERGENS)[number]>;

export const ALLERGEN_DISCLAIMER = 'Per allergie o intolleranze contatta direttamente il ristorante.';

const SYNONYMS: Record<string, AllergenCode> = {
  glutine: 'gluten', cereali: 'gluten', crostacei: 'crustaceans', uova: 'eggs', uovo: 'eggs', pesce: 'fish', arachidi: 'peanuts',
  soia: 'soy', latte: 'milk', lattosio: 'milk', 'frutta a guscio': 'nuts', 'frutta secca': 'nuts', sedano: 'celery', senape: 'mustard',
  sesamo: 'sesame', solfiti: 'sulphites', 'anidride solforosa': 'sulphites', lupini: 'lupin', molluschi: 'molluscs',
};

/** Codici, numeri UE (1–14) e nomi IT/EN → codici; valori sconosciuti scartati. */
export function normalizeAllergens(values: (string | number)[] | null | undefined): AllergenCode[] {
  const out = new Set<AllergenCode>();
  (values ?? []).forEach((v) => {
    const k = String(v).trim().toLowerCase().replace(/\s+/g, ' ');
    if (k in ALLERGEN_BY_CODE) out.add(k as AllergenCode);
    else if (SYNONYMS[k]) out.add(SYNONYMS[k]!);
    else if (/^\d+$/.test(k)) {
      const a = ALLERGENS.find((x) => x.eu === Number(k));
      if (a) out.add(a.code);
    }
  });
  return ALLERGENS.filter((a) => out.has(a.code)).map((a) => a.code);
}

export const MENU_TYPE_LABELS: Record<MenuType, string> = {
  a_la_carte: 'Menu principale',
  lunch: 'Pranzo',
  dinner: 'Cena',
  all_you_can_eat: 'All You Can Eat',
  takeaway: 'Take away',
  delivery: 'Delivery',
  drinks: 'Bevande',
  dessert: 'Dessert',
  seasonal: 'Menu stagionale',
  other: 'Altro',
};

export type DietFilter = 'vegetarian' | 'vegan' | 'gluten_free' | 'spicy';
export const DIET_FILTERS: { key: DietFilter; label: string; field: keyof MenuItem }[] = [
  { key: 'vegetarian', label: 'Vegetariano', field: 'is_vegetarian' },
  { key: 'vegan', label: 'Vegano', field: 'is_vegan' },
  { key: 'gluten_free', label: 'Gluten free', field: 'is_gluten_free' },
  { key: 'spicy', label: 'Piccante', field: 'is_spicy' },
];

/** Menu visibile al pubblico oggi (specchio di menu_is_public). */
export function isMenuPublicToday(m: { is_active: boolean; is_public: boolean; valid_from: string | null; valid_until: string | null }, today = new Date().toISOString().slice(0, 10)) {
  return m.is_active && m.is_public && (!m.valid_from || m.valid_from <= today) && (!m.valid_until || m.valid_until >= today);
}
