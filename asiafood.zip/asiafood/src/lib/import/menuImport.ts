// Import menu da CSV o JSON: normalizzazione e validazione lato client
// (il DB rivalida tutto in import_menu). Nessun OCR/PDF in questa fase.
import type { MenuImportRow } from '@/services/types';
import { normalizeAllergens } from '@/lib/menu';
import { csvToObjects } from './csv';

export const MENU_CSV_TEMPLATE = [
  'menu;categoria;nome;descrizione;prezzo;prezzo_scontato;allergeni;ingredienti;vegetariano;vegano;senza_glutine;piccante;disponibile;consigliato;varianti;extra',
  'Menu principale;Antipasti;Edamame;Fagioli di soia al vapore;4,50;;soia;edamame|sale;sì;sì;sì;no;sì;no;;',
  'Menu principale;Uramaki;California roll;Surimi, avocado, cetriolo;9;;pesce|uova|sesamo;surimi|avocado|cetriolo;no;no;no;no;sì;sì;4 pezzi=5,50|8 pezzi=9;Extra avocado=1,50',
  'All You Can Eat;Inclusi;Nigiri misti;Compreso nella formula;;;pesce;;no;no;sì;no;sì;no;;',
].join('\n');

const pick = (o: Record<string, unknown>, ...keys: string[]) => {
  for (const k of keys) {
    const v = o[k];
    if (v !== undefined && v !== null && String(v).trim() !== '') return v;
  }
  return undefined;
};
const num = (v: unknown): number | null | 'invalid' => {
  if (v === undefined || v === null || String(v).trim() === '') return null;
  const n = typeof v === 'number' ? v : Number(String(v).replace(/[€\s]/g, '').replace(',', '.'));
  return Number.isFinite(n) && n >= 0 && n <= 10000 ? Math.round(n * 100) / 100 : 'invalid';
};
const bool = (v: unknown, fallback: boolean) => {
  if (v === undefined || v === null || String(v).trim() === '') return fallback;
  if (typeof v === 'boolean') return v;
  return /^(1|s|si|sì|y|yes|true|x|vero)$/i.test(String(v).trim());
};
const list = (v: unknown): string[] =>
  Array.isArray(v) ? v.map(String).map((x) => x.trim()).filter(Boolean) : v ? String(v).split(/[|;,]/).map((x) => x.trim()).filter(Boolean) : [];
const options = (v: unknown): { name: string; price: number | null }[] => {
  if (Array.isArray(v)) return v.map((x) => ({ name: String((x as { name?: unknown }).name ?? '').trim(), price: (() => { const n = num((x as { price?: unknown }).price); return n === 'invalid' ? null : n; })() })).filter((x) => x.name);
  if (!v) return [];
  return String(v)
    .split('|')
    .map((part) => {
      const [name, price] = part.split('=');
      const n = num(price);
      return { name: (name ?? '').trim(), price: n === 'invalid' ? null : n };
    })
    .filter((x) => x.name);
};

export interface MenuImportPreview {
  rows: MenuImportRow[];
  errors: { row: number; message: string }[];
}

export function parseMenuFile(text: string, fileName = ''): MenuImportPreview {
  let raw: Record<string, unknown>[];
  const trimmed = text.trim();
  if (!trimmed) return { rows: [], errors: [{ row: 0, message: 'Il file è vuoto.' }] };
  if (fileName.toLowerCase().endsWith('.json') || trimmed.startsWith('[') || trimmed.startsWith('{')) {
    try {
      const data = JSON.parse(trimmed) as unknown;
      raw = (Array.isArray(data) ? data : ((data as { items?: unknown[] }).items ?? [])) as Record<string, unknown>[];
    } catch {
      return { rows: [], errors: [{ row: 0, message: 'JSON non valido.' }] };
    }
  } else {
    raw = csvToObjects(trimmed).map((o) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k.trim().toLowerCase(), v])));
  }
  const rows: MenuImportRow[] = [];
  const errors: MenuImportPreview['errors'] = [];
  raw.forEach((o, i) => {
    const n = i + 1;
    const name = String(pick(o, 'name', 'nome', 'piatto') ?? '').trim();
    const category = String(pick(o, 'category', 'categoria', 'sezione') ?? '').trim();
    const price = num(pick(o, 'price', 'prezzo'));
    const discount = num(pick(o, 'discount_price', 'prezzo_scontato'));
    if (!name) return errors.push({ row: n, message: 'Nome del piatto mancante.' });
    if (!category) return errors.push({ row: n, message: `“${name}”: categoria mancante.` });
    if (price === 'invalid') return errors.push({ row: n, message: `“${name}”: prezzo non valido.` });
    if (discount === 'invalid') return errors.push({ row: n, message: `“${name}”: prezzo scontato non valido.` });
    if (name.length > 120) return errors.push({ row: n, message: `“${name.slice(0, 20)}…”: nome troppo lungo (max 120).` });
    const vegan = bool(pick(o, 'is_vegan', 'vegano'), false);
    rows.push({
      menu: String(pick(o, 'menu') ?? 'Menu principale').trim(),
      menu_type: pick(o, 'menu_type', 'tipo_menu') as string | undefined,
      category,
      name,
      description: (pick(o, 'description', 'descrizione') as string | undefined)?.toString().trim() || null,
      price,
      discount_price: discount,
      allergens: normalizeAllergens(list(pick(o, 'allergens', 'allergeni'))),
      ingredients: list(pick(o, 'ingredients', 'ingredienti')),
      is_vegetarian: vegan || bool(pick(o, 'is_vegetarian', 'vegetariano'), false),
      is_vegan: vegan,
      is_gluten_free: bool(pick(o, 'is_gluten_free', 'senza_glutine', 'gluten_free'), false),
      is_spicy: bool(pick(o, 'is_spicy', 'piccante'), false),
      is_available: bool(pick(o, 'is_available', 'disponibile'), true),
      is_featured: bool(pick(o, 'is_featured', 'consigliato'), false),
      variants: options(pick(o, 'variants', 'varianti')),
      addons: options(pick(o, 'addons', 'extra')),
    });
  });
  if (rows.length > 1000) errors.push({ row: 0, message: 'Massimo 1000 piatti per importazione.' });
  return { rows, errors };
}
