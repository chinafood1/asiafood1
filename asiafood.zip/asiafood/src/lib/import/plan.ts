// ─────────────────────────────────────────────────────────────
//  Analisi di un file e costruzione delle operazioni di import.
//  Nessuna scrittura qui: produce un'anteprima con errori,
//  avvisi, possibili duplicati e una decisione proposta per riga.
// ─────────────────────────────────────────────────────────────
import type { DataStatus, SourceType } from '../../types/domain';
import { csvToObjects } from './csv';
import { findMatches, type MatchCandidate, type MatchResult } from './match';
import { normalizeRecord, type ImportContext, type NormalizedRecord } from './normalize';

export type ImportDecision = 'create' | 'skip' | 'update' | 'merge' | 'create_anyway';

/** Candidato esistente con i campi necessari per merge/aggiornamento. */
export interface ExistingRestaurant extends MatchCandidate {
  owner_id: string | null;
  data_status: DataStatus;
  is_active: boolean;
  is_demo: boolean;
  category_slugs: string[];
  [field: string]: unknown;
}

export interface ImportRow {
  /** Numero di riga nel file (1 = primo record) */
  index: number;
  raw: Record<string, unknown>;
  record: NormalizedRecord | null;
  errors: string[];
  warnings: string[];
  matches: MatchResult<ExistingRestaurant>[];
  /** Duplicato di una riga precedente dello stesso file */
  duplicateOfRow?: number;
  decision: ImportDecision;
  targetId?: string;
}

export interface ImportOptions {
  /** Pubblica subito i nuovi locali (is_active = true). Default: false → bozza da verificare. */
  publish: boolean;
  /** Stato dati per i record che non lo specificano. */
  defaultStatus: DataStatus;
}

export interface ImportOperation {
  restaurantId: string | null;
  data: Record<string, unknown>;
  categorySlugs: string[] | null;
  replaceCategories: boolean;
  source: { source_type: SourceType; source_name: string | null; source_url: string | null; external_id: string | null; last_checked_at: string | null } | null;
  /** Avvisi generati dalla costruzione dell'operazione (es. locale rivendicato protetto). */
  notes: string[];
}

export function parseFile(text: string, format: 'csv' | 'json'): Record<string, unknown>[] {
  if (format === 'csv') return csvToObjects(text);
  const parsed: unknown = JSON.parse(text);
  const arr = Array.isArray(parsed) ? parsed : (parsed as { restaurants?: unknown }).restaurants;
  if (!Array.isArray(arr)) throw new Error('Il JSON deve essere un array di ristoranti oppure { "restaurants": [ … ] }');
  return arr.map((x, i) => {
    if (!x || typeof x !== 'object' || Array.isArray(x)) throw new Error(`Elemento ${i + 1} non è un oggetto`);
    return x as Record<string, unknown>;
  });
}

export const detectFormat = (fileName: string, text: string): 'csv' | 'json' =>
  /\.json$/i.test(fileName) || /^\s*[[{]/.test(text) ? 'json' : 'csv';

/** Analizza tutte le righe: normalizza, valida, cerca duplicati (DB + file) e propone una decisione. */
export function analyzeRows(rawRows: Record<string, unknown>[], existing: ExistingRestaurant[], ctx: ImportContext): ImportRow[] {
  const rows: ImportRow[] = [];
  const seen: { row: number; cand: ExistingRestaurant }[] = [];

  rawRows.forEach((raw, i) => {
    const { record, errors, warnings } = normalizeRecord(raw, ctx);
    const row: ImportRow = { index: i + 1, raw, record, errors, warnings, matches: [], decision: 'skip' };
    if (record) {
      row.matches = findMatches(record, existing.filter((e) => e.city_id === record.city_id || !!record.google_place_id || !!record.phone));
      const inFile = findMatches(record, seen.map((s) => s.cand), 1)[0];
      if (inFile) {
        row.duplicateOfRow = seen.find((s) => s.cand === inFile.candidate)!.row;
        row.warnings.push(`Possibile duplicato della riga ${row.duplicateOfRow} del file (${inFile.reasons.join(', ')})`);
      }
      // Proposta prudente: mai creare automaticamente un possibile duplicato
      row.decision = row.matches.length || row.duplicateOfRow ? 'skip' : 'create';
      row.targetId = row.matches[0]?.candidate.id;
      seen.push({ row: row.index, cand: recordAsCandidate(record, `row-${row.index}`) });
    }
    rows.push(row);
  });
  return rows;
}

function recordAsCandidate(r: NormalizedRecord, id: string): ExistingRestaurant {
  return {
    id,
    name: r.name,
    city_id: r.city_id,
    address: r.address ?? null,
    phone: r.phone ?? null,
    whatsapp: r.whatsapp ?? null,
    website: r.website ?? null,
    latitude: r.latitude ?? null,
    longitude: r.longitude ?? null,
    google_place_id: r.google_place_id ?? null,
    external_id: r.external_id ?? null,
    source_name: r.source_name ?? null,
    owner_id: null,
    data_status: r.data_status ?? 'unverified',
    is_active: false,
    is_demo: false,
    category_slugs: r.category_slugs,
  };
}

/** Campi del record che finiscono nella tabella restaurants. */
const DATA_FIELDS = [
  'name', 'city_id', 'address', 'postal_code', 'latitude', 'longitude', 'phone', 'whatsapp', 'email', 'website',
  'instagram', 'facebook', 'tiktok', 'short_description', 'description', 'is_all_you_can_eat', 'ayce_lunch_price',
  'ayce_dinner_price', 'ayce_weekend_price', 'has_delivery', 'has_takeaway', 'has_reservation', 'reservation_url',
  'price_range', 'average_price', 'services', 'source_name', 'source_url', 'external_id', 'google_place_id',
  'data_status', 'last_verified_at', 'is_temporarily_closed', 'is_permanently_closed', 'logo_url', 'cover_url',
  'verification_notes',
] as const;

const isEmpty = (v: unknown) => v === null || v === undefined || v === '' || (Array.isArray(v) && v.length === 0);

export const slugBase = (name: string, citySlug: string) =>
  `${name}-${citySlug}`
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/&/g, ' ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

/** Trasforma riga + decisione in un'operazione di scrittura (null = nessuna scrittura). */
export function buildOperation(row: ImportRow, existing: ExistingRestaurant | undefined, opts: ImportOptions): ImportOperation | null {
  const rec = row.record;
  if (!rec || row.decision === 'skip') return null;
  const notes: string[] = [];
  const source =
    rec.source_url || rec.source_name
      ? {
          source_type: rec.source_type ?? 'import',
          source_name: rec.source_name ?? null,
          source_url: rec.source_url ?? null,
          external_id: rec.external_id ?? null,
          last_checked_at: rec.last_verified_at ?? null,
        }
      : null;
  const provided = Object.fromEntries(DATA_FIELDS.filter((k) => rec[k] !== undefined).map((k) => [k, rec[k]])) as Record<string, unknown>;

  if (row.decision === 'create' || row.decision === 'create_anyway') {
    const data: Record<string, unknown> = Object.fromEntries(Object.entries(provided).filter(([, v]) => v !== null));
    data.slug = slugBase(rec.name, rec.city_slug);
    data.data_status = rec.data_status ?? opts.defaultStatus;
    data.is_active = opts.publish;
    return { restaurantId: null, data, categorySlugs: rec.category_slugs, replaceCategories: false, source, notes };
  }

  if (!existing) throw new Error(`Riga ${row.index}: seleziona il ristorante da aggiornare/unire`);
  // Un locale rivendicato è gestito dal titolare: l'import può solo completare i campi vuoti
  const protectedByOwner = !!existing.owner_id;
  const mode = row.decision === 'update' && protectedByOwner ? 'merge' : row.decision;
  if (mode !== row.decision) notes.push('Locale rivendicato: aggiornamento eseguito come unione (i dati del titolare non vengono sovrascritti)');

  const data: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(provided)) {
    if (k === 'name' || k === 'city_id') {
      if (mode === 'update' && v && v !== existing[k]) data[k] = v;
      continue;
    }
    if (k === 'data_status') continue;
    if (mode === 'update') {
      if (v !== null && v !== undefined) data[k] = v;
    } else {
      // merge: solo campi vuoti; per i booleani aggiunge i "sì" mancanti
      const cur = existing[k];
      if (typeof v === 'boolean') {
        if (v && !cur) data[k] = true;
      } else if (Array.isArray(v)) {
        const merged = Array.from(new Set([...((cur as string[] | null) ?? []), ...v]));
        if (merged.length !== ((cur as string[] | null) ?? []).length) data[k] = merged;
      } else if (isEmpty(cur) && !isEmpty(v)) data[k] = v;
    }
  }
  // Stato dati: mai toccare "claimed"; altrimenti migliora solo se il record porta una verifica
  if (!protectedByOwner && rec.data_status) {
    const rank: Record<DataStatus, number> = { outdated: 0, unverified: 1, partially_verified: 2, verified: 3, claimed: 4 };
    if (mode === 'update' || rank[rec.data_status] > rank[existing.data_status]) data.data_status = rec.data_status;
  }
  return {
    restaurantId: existing.id,
    data,
    categorySlugs: rec.category_slugs.length ? rec.category_slugs : null,
    replaceCategories: mode === 'update' && !protectedByOwner && rec.category_slugs.length > 0,
    source,
    notes,
  };
}

export interface ImportSummary {
  total: number;
  created: number;
  updated: number;
  merged: number;
  skipped: number;
  errors: { row: number; name?: string; message: string }[];
}

export const emptySummary = (total: number): ImportSummary => ({ total, created: 0, updated: 0, merged: 0, skipped: 0, errors: [] });
