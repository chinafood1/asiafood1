// ─────────────────────────────────────────────────────────────
//  Normalizzazione e validazione di un record importato.
//  Principio: nessun dato inventato. Ciò che manca resta null,
//  ciò che non è valido viene scartato con un avviso/errore.
// ─────────────────────────────────────────────────────────────
import type { DataStatus, SourceType } from '../../types/domain';
import { normalizeText, resolveCategorySlug, resolveCitySlug } from '../searchQuery';

export interface ImportCity {
  id: string;
  name: string;
  slug: string;
  province_id: string;
  latitude: number | null;
  longitude: number | null;
}
export interface ImportCategory {
  id: string;
  name: string;
  slug: string;
}
export interface ImportProvince {
  id: string;
  name: string;
  code: string;
}

export interface ImportContext {
  cities: ImportCity[];
  categories: ImportCategory[];
  provinces?: ImportProvince[];
  now?: Date;
}

/** Record normalizzato: undefined = "non fornito" (importante per il merge). */
export interface NormalizedRecord {
  name: string;
  city_id: string;
  city_slug: string;
  city_name: string;
  address?: string | null;
  postal_code?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  phone?: string | null;
  whatsapp?: string | null;
  email?: string | null;
  website?: string | null;
  instagram?: string | null;
  facebook?: string | null;
  tiktok?: string | null;
  short_description?: string | null;
  description?: string | null;
  category_slugs: string[];
  is_all_you_can_eat?: boolean;
  ayce_lunch_price?: number | null;
  ayce_dinner_price?: number | null;
  ayce_weekend_price?: number | null;
  has_delivery?: boolean;
  has_takeaway?: boolean;
  has_reservation?: boolean;
  reservation_url?: string | null;
  price_range?: 1 | 2 | 3 | 4 | null;
  average_price?: number | null;
  services?: string[];
  source_name?: string | null;
  source_url?: string | null;
  source_type?: SourceType;
  external_id?: string | null;
  google_place_id?: string | null;
  data_status?: DataStatus;
  last_verified_at?: string | null;
  is_temporarily_closed?: boolean;
  is_permanently_closed?: boolean;
  logo_url?: string | null;
  cover_url?: string | null;
  verification_notes?: string | null;
}

export interface NormalizeResult {
  record: NormalizedRecord | null;
  errors: string[];
  warnings: string[];
}

// ─── Intestazioni accettate (IT/EN) → campo canonico ─────────
const ALIASES: Record<string, string[]> = {
  name: ['name', 'nome', 'nome_locale', 'insegna', 'restaurant', 'ristorante', 'title'],
  address: ['address', 'indirizzo', 'via', 'street'],
  city: ['city', 'comune', 'citta', 'localita', 'town'],
  province: ['province', 'provincia', 'prov'],
  region: ['region', 'regione'],
  postal_code: ['postal_code', 'cap', 'zip', 'postcode'],
  latitude: ['latitude', 'lat', 'latitudine'],
  longitude: ['longitude', 'lng', 'lon', 'long', 'longitudine'],
  phone: ['phone', 'telefono', 'tel', 'phone_number'],
  whatsapp: ['whatsapp', 'wa'],
  email: ['email', 'mail', 'e_mail'],
  website: ['website', 'sito', 'sito_web', 'web', 'url_sito', 'site'],
  instagram: ['instagram', 'ig'],
  facebook: ['facebook', 'fb'],
  tiktok: ['tiktok'],
  short_description: ['short_description', 'descrizione_breve'],
  description: ['description', 'descrizione'],
  categories: ['categories', 'categorie', 'category', 'categoria', 'cucina', 'cuisine', 'tipologia'],
  is_all_you_can_eat: ['is_all_you_can_eat', 'all_you_can_eat', 'ayce'],
  ayce_lunch_price: ['ayce_lunch_price', 'prezzo_ayce_pranzo', 'ayce_pranzo'],
  ayce_dinner_price: ['ayce_dinner_price', 'prezzo_ayce_cena', 'ayce_cena'],
  ayce_weekend_price: ['ayce_weekend_price', 'prezzo_ayce_weekend', 'ayce_weekend'],
  has_delivery: ['has_delivery', 'delivery', 'consegna'],
  has_takeaway: ['has_takeaway', 'takeaway', 'asporto'],
  has_reservation: ['has_reservation', 'reservation', 'prenotazione'],
  reservation_url: ['reservation_url', 'link_prenotazione'],
  price_range: ['price_range', 'fascia_prezzo'],
  average_price: ['average_price', 'prezzo_medio'],
  services: ['services', 'servizi'],
  source_name: ['source_name', 'fonte', 'nome_fonte'],
  source_url: ['source_url', 'url_fonte', 'fonte_url', 'link_fonte'],
  source_type: ['source_type', 'tipo_fonte'],
  external_id: ['external_id', 'id_esterno'],
  google_place_id: ['google_place_id', 'place_id'],
  data_status: ['data_status', 'stato_dati'],
  last_verified_at: ['last_verified_at', 'verificato_il', 'data_verifica'],
  is_temporarily_closed: ['is_temporarily_closed', 'chiuso_temporaneamente'],
  is_permanently_closed: ['is_permanently_closed', 'chiuso_definitivamente'],
  logo_url: ['logo_url', 'logo'],
  cover_url: ['cover_url', 'cover', 'immagine'],
  image_rights_confirmed: ['image_rights_confirmed', 'diritti_immagini'],
  verification_notes: ['verification_notes', 'note', 'notes'],
};
const KEY_BY_ALIAS = new Map(Object.entries(ALIASES).flatMap(([k, as]) => as.map((a) => [a, k] as const)));
const normKey = (k: string) => normalizeText(k).replace(/ /g, '_');

export const IMPORT_FIELDS = Object.keys(ALIASES);

/** Riporta le chiavi del record ai nomi canonici (accetta intestazioni italiane). */
export function canonicalize(raw: Record<string, unknown>): { data: Record<string, unknown>; unknown: string[] } {
  const data: Record<string, unknown> = {};
  const unknown: string[] = [];
  for (const [k, v] of Object.entries(raw)) {
    const key = KEY_BY_ALIAS.get(normKey(k));
    if (key) data[key] = v;
    else if (k.trim()) unknown.push(k);
  }
  return { data, unknown };
}

// ─── Helper di parsing ───────────────────────────────────────
const isBlank = (v: unknown) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
const str = (v: unknown): string | null | undefined => (v === undefined ? undefined : isBlank(v) ? null : String(v).trim().replace(/\s+/g, ' '));

function bool(v: unknown): boolean | undefined {
  if (isBlank(v)) return undefined;
  if (typeof v === 'boolean') return v;
  const n = normalizeText(String(v));
  if (['true', '1', 'si', 'yes', 'y', 'x', 'vero'].includes(n)) return true;
  if (['false', '0', 'no', 'n', 'falso'].includes(n)) return false;
  return undefined;
}

function num(v: unknown): number | null | undefined {
  if (v === undefined) return undefined;
  if (isBlank(v)) return null;
  const n = typeof v === 'number' ? v : Number(String(v).replace(/\s/g, '').replace(',', '.'));
  return Number.isFinite(n) ? n : NaN;
}

function list(v: unknown): string[] | undefined {
  if (isBlank(v)) return undefined;
  if (Array.isArray(v)) return v.map((x) => String(x).trim()).filter(Boolean);
  return String(v)
    .split(/[|;,/]/)
    .map((x) => x.trim())
    .filter(Boolean);
}

function url(v: unknown): string | null | undefined | false {
  const s = str(v);
  if (s === undefined || s === null) return s;
  const withProto = /^https?:\/\//i.test(s) ? s : `https://${s.replace(/^\/\//, '')}`;
  try {
    const u = new URL(withProto);
    if (!u.hostname.includes('.')) return false;
    u.hostname = u.hostname.toLowerCase();
    return u.toString().replace(/\/$/, '');
  } catch {
    return false;
  }
}

/** Normalizza un telefono italiano in formato "+39 0991234567". false = non valido. */
export function normalizePhone(v: unknown): string | null | undefined | false {
  const s = str(v);
  if (s === undefined || s === null) return s;
  let d = s.replace(/[^\d+]/g, '');
  if (d.startsWith('00')) d = `+${d.slice(2)}`;
  if (!d.startsWith('+')) {
    if (/^(3\d{8,9}|0\d{5,10})$/.test(d)) d = `+39${d}`;
    else return false;
  }
  const digits = d.slice(1);
  if (!/^\d{8,15}$/.test(digits)) return false;
  return digits.startsWith('39') ? `+39 ${digits.slice(2)}` : `+${digits}`;
}

/** Solo cifre con prefisso internazionale, come si aspetta wa.me (es. 393331234567). */
function whatsapp(v: unknown): string | null | undefined | false {
  const p = normalizePhone(v);
  if (!p) return p;
  return p.replace(/[^\d]/g, '');
}

function social(v: unknown, host: 'instagram.com' | 'facebook.com' | 'tiktok.com'): string | null | undefined | false {
  const s = str(v);
  if (s === undefined || s === null) return s;
  if (/^https?:\/\//i.test(s) || s.includes(`${host}`)) {
    const u = url(s);
    return u && u.includes(host.split('.')[0]!) ? u : false;
  }
  const handle = s.replace(/^@/, '');
  if (!/^[A-Za-z0-9._-]{2,80}$/.test(handle)) return false;
  return host === 'tiktok.com' ? `https://www.tiktok.com/@${handle}` : `https://www.${host}/${handle}`;
}

function date(v: unknown): string | null | undefined | false {
  const s = str(v);
  if (s === undefined || s === null) return s;
  const it = s.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})(?:[ T](\d{1,2}):(\d{2}))?$/);
  const d = it ? new Date(Date.UTC(+it[3]!, +it[2]! - 1, +it[1]!, +(it[4] ?? 12), +(it[5] ?? 0))) : new Date(s);
  return Number.isNaN(d.getTime()) ? false : d.toISOString();
}

const DATA_STATUS_ALIASES: Record<string, DataStatus> = {
  verified: 'verified', verificato: 'verified',
  partially_verified: 'partially_verified', 'partially verified': 'partially_verified', parzialmente_verificato: 'partially_verified', 'parzialmente verificato': 'partially_verified',
  unverified: 'unverified', 'non verificato': 'unverified', non_verificato: 'unverified',
  outdated: 'outdated', obsoleto: 'outdated', 'da aggiornare': 'outdated',
  claimed: 'claimed', rivendicato: 'claimed',
};

const SOURCE_TYPES: SourceType[] = ['google_business', 'official_website', 'facebook', 'instagram', 'directory', 'owner', 'admin', 'import', 'other'];
const DIRECTORY_HOSTS = ['tripadvisor', 'thefork', 'paginegialle', 'paginebianche', 'justeat', 'deliveroo', 'glovo', 'yelp', 'restaurantguru', 'misterimprese', 'ubereats'];

export function hostOf(u: string | null | undefined): string | null {
  if (!u) return null;
  try {
    return new URL(u).hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return null;
  }
}

/** Deduce il tipo di fonte dall'URL. */
export function inferSourceType(sourceUrl: string | null | undefined, website?: string | null): SourceType {
  const h = hostOf(sourceUrl);
  if (!h) return 'other';
  if (/(^|\.)google\.[a-z.]+$/.test(h) || h === 'goo.gl' || h === 'maps.app.goo.gl' || h === 'g.page') return 'google_business';
  if (h.endsWith('facebook.com') || h === 'fb.com') return 'facebook';
  if (h.endsWith('instagram.com')) return 'instagram';
  if (website && hostOf(website) === h) return 'official_website';
  if (DIRECTORY_HOSTS.some((d) => h.includes(d))) return 'directory';
  return 'other';
}

const ITALY_BBOX = { minLat: 35.3, maxLat: 47.2, minLng: 6.5, maxLng: 18.8 };

function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

// ─── Normalizzazione di un record ────────────────────────────
export function normalizeRecord(raw: Record<string, unknown>, ctx: ImportContext): NormalizeResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const { data, unknown } = canonicalize(raw);
  if (unknown.length) warnings.push(`Colonne ignorate: ${unknown.join(', ')}`);

  // Nome
  const name = str(data.name);
  if (!name) errors.push('Nome mancante');
  else if (name.length > 120) errors.push('Nome troppo lungo (max 120 caratteri)');

  // Comune (obbligatorio, deve essere gestito dalla piattaforma)
  const cityRaw = str(data.city);
  const citySlug = cityRaw ? resolveCitySlug(cityRaw, ctx.cities) : undefined;
  const city = citySlug ? ctx.cities.find((c) => c.slug === citySlug) : undefined;
  if (!cityRaw) errors.push('Comune mancante');
  else if (!city) errors.push(`Comune non gestito: "${cityRaw}" (aggiungilo in Admin → Città e territori)`);

  const provRaw = str(data.province);
  if (city && provRaw && ctx.provinces?.length) {
    const prov = ctx.provinces.find((p) => p.id === city.province_id);
    const n = normalizeText(provRaw.replace(/^provincia di /i, ''));
    if (prov && n !== normalizeText(prov.name) && n !== normalizeText(prov.code)) {
      warnings.push(`Provincia "${provRaw}" non coerente con ${city.name} (${prov.code})`);
    }
  }

  const rec: Partial<NormalizedRecord> = {};
  const setUrlLike = (key: keyof NormalizedRecord, v: string | null | undefined | false, label: string) => {
    if (v === false) warnings.push(`${label} non valido: scartato`);
    else if (v !== undefined) (rec as Record<string, unknown>)[key] = v;
  };

  rec.address = str(data.address);
  const cap = str(data.postal_code);
  if (cap !== undefined) {
    if (cap === null || /^\d{5}$/.test(cap)) rec.postal_code = cap;
    else warnings.push(`CAP non valido: "${cap}"`);
  }

  // Coordinate: entrambe o nessuna, in Italia, vicine al comune
  const lat = num(data.latitude);
  const lng = num(data.longitude);
  if (lat !== undefined || lng !== undefined) {
    if (lat == null || lng == null || Number.isNaN(lat) || Number.isNaN(lng)) {
      if (!(lat === null && lng === null)) warnings.push('Coordinate incomplete o non valide: scartate');
    } else if (lat < ITALY_BBOX.minLat || lat > ITALY_BBOX.maxLat || lng < ITALY_BBOX.minLng || lng > ITALY_BBOX.maxLng) {
      warnings.push('Coordinate fuori dall’Italia (lat/lng invertite?): scartate');
    } else {
      rec.latitude = lat;
      rec.longitude = lng;
      if (city?.latitude != null && city.longitude != null) {
        const km = haversineKm({ lat, lng }, { lat: city.latitude, lng: city.longitude });
        if (km > 25) warnings.push(`Coordinate a ${Math.round(km)} km da ${city.name}: verifica comune e posizione`);
      }
    }
  }

  setUrlLike('phone', normalizePhone(data.phone), 'Telefono');
  setUrlLike('whatsapp', whatsapp(data.whatsapp), 'WhatsApp');
  const email = str(data.email);
  if (email !== undefined) {
    if (email === null || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) rec.email = email?.toLowerCase() ?? null;
    else warnings.push(`Email non valida: "${email}"`);
  }
  setUrlLike('website', url(data.website), 'Sito web');
  setUrlLike('instagram', social(data.instagram, 'instagram.com'), 'Instagram');
  setUrlLike('facebook', social(data.facebook, 'facebook.com'), 'Facebook');
  setUrlLike('tiktok', social(data.tiktok, 'tiktok.com'), 'TikTok');
  setUrlLike('reservation_url', url(data.reservation_url), 'Link prenotazione');

  rec.short_description = str(data.short_description);
  if (rec.short_description && rec.short_description.length > 160) {
    warnings.push('Descrizione breve oltre 160 caratteri: troncata');
    rec.short_description = `${rec.short_description.slice(0, 157)}…`;
  }
  rec.description = str(data.description);
  if (rec.description && rec.description.length > 600) {
    warnings.push('Descrizione lunga: verifica che sia un testo originale e non copiato da siti terzi');
  }

  // Categorie (multiple, IT/EN)
  const cats: string[] = [];
  for (const term of list(data.categories) ?? []) {
    const slug = resolveCategorySlug(term, ctx.categories);
    if (slug) {
      if (!cats.includes(slug)) cats.push(slug);
    } else warnings.push(`Categoria sconosciuta ignorata: "${term}"`);
  }
  const ayce = bool(data.is_all_you_can_eat);
  if (ayce !== undefined) rec.is_all_you_can_eat = ayce;
  if (cats.includes('all-you-can-eat') && rec.is_all_you_can_eat === undefined) rec.is_all_you_can_eat = true;
  if (rec.is_all_you_can_eat && !cats.includes('all-you-can-eat') && ctx.categories.some((c) => c.slug === 'all-you-can-eat')) cats.push('all-you-can-eat');
  rec.category_slugs = cats;
  if (!cats.length) warnings.push('Nessuna categoria riconosciuta: il locale non comparirà nei filtri per cucina');

  for (const k of ['ayce_lunch_price', 'ayce_dinner_price', 'ayce_weekend_price', 'average_price'] as const) {
    const v = num(data[k]);
    if (v === undefined) continue;
    if (v !== null && (Number.isNaN(v) || v <= 0 || v > 500)) warnings.push(`${k} non valido: scartato`);
    else rec[k] = v;
  }
  const pr = num(data.price_range) ?? (typeof data.price_range === 'string' && /^€{1,4}$/.test(data.price_range.trim()) ? data.price_range.trim().length : undefined);
  if (pr !== undefined) {
    if (pr === null) rec.price_range = null;
    else if ([1, 2, 3, 4].includes(pr)) rec.price_range = pr as 1 | 2 | 3 | 4;
    else warnings.push('Fascia prezzo non valida (1–4 o €…€€€€): scartata');
  }

  for (const k of ['has_delivery', 'has_takeaway', 'has_reservation', 'is_temporarily_closed', 'is_permanently_closed'] as const) {
    const v = bool(data[k]);
    if (v !== undefined) rec[k] = v;
  }
  const services = list(data.services);
  if (services) rec.services = services.map((s) => normalizeText(s).replace(/ /g, '_'));

  // Provenienza
  rec.source_name = str(data.source_name);
  setUrlLike('source_url', url(data.source_url), 'URL fonte');
  const st = str(data.source_type) as SourceType | null | undefined;
  rec.source_type = st && SOURCE_TYPES.includes(st) ? st : inferSourceType(rec.source_url, rec.website);
  rec.external_id = str(data.external_id);
  rec.google_place_id = str(data.google_place_id);
  rec.verification_notes = str(data.verification_notes);

  const lv = date(data.last_verified_at);
  if (lv === false) warnings.push('last_verified_at non valida: scartata');
  else if (lv && new Date(lv).getTime() > (ctx.now ?? new Date()).getTime() + 86_400_000) warnings.push('last_verified_at nel futuro: scartata');
  else if (lv !== undefined) rec.last_verified_at = lv;

  const dsRaw = str(data.data_status);
  if (dsRaw) {
    const ds = DATA_STATUS_ALIASES[normalizeText(dsRaw)] ?? DATA_STATUS_ALIASES[dsRaw.toLowerCase()];
    if (!ds) warnings.push(`data_status sconosciuto: "${dsRaw}"`);
    else if (ds === 'claimed') warnings.push('data_status "claimed" si ottiene solo con una rivendicazione approvata: ignorato');
    else rec.data_status = ds;
  }
  if (!rec.source_url && !rec.source_name) {
    warnings.push('Nessuna fonte: il record resterà "unverified"');
    rec.data_status = 'unverified';
  } else if (rec.data_status === 'verified' && (!rec.source_url || !rec.last_verified_at)) {
    warnings.push('"verified" richiede source_url e last_verified_at: impostato "partially_verified"');
    rec.data_status = 'partially_verified';
  }

  // Immagini: importate SOLO se i diritti d'uso sono confermati esplicitamente
  const rights = bool(data.image_rights_confirmed) === true;
  for (const k of ['logo_url', 'cover_url'] as const) {
    if (isBlank(data[k])) continue;
    if (!rights) warnings.push(`${k} ignorato: imposta image_rights_confirmed = true solo se hai il diritto di usare l’immagine`);
    else setUrlLike(k, url(data[k]), k);
  }

  if (errors.length || !name || !city) return { record: null, errors, warnings };
  return {
    record: { ...(rec as NormalizedRecord), name, city_id: city.id, city_slug: city.slug, city_name: city.name },
    errors,
    warnings,
  };
}
