// ─────────────────────────────────────────────────────────────
//  Rilevamento duplicati: confronta un record importato con i
//  ristoranti esistenti (e con le righe precedenti del file).
//  Segnala, non decide: la scelta finale è sempre dell'Admin.
// ─────────────────────────────────────────────────────────────
import { normalizeText } from '../searchQuery';
import { hostOf, type NormalizedRecord } from './normalize';

export interface MatchCandidate {
  id: string;
  name: string;
  slug?: string;
  city_id: string;
  address: string | null;
  phone: string | null;
  whatsapp?: string | null;
  website: string | null;
  latitude: number | null;
  longitude: number | null;
  google_place_id: string | null;
  external_id: string | null;
  source_name: string | null;
}

export type MatchConfidence = 'certain' | 'high' | 'medium';

export interface MatchResult<T extends MatchCandidate = MatchCandidate> {
  candidate: T;
  score: number;
  confidence: MatchConfidence;
  reasons: string[];
}

// Parole generiche che non distinguono un locale da un altro
const NAME_NOISE = new Set(['ristorante', 'restaurant', 'ristorantino', 'trattoria', 'srl', 'snc', 'sas', 'srls', 'di', 'da', 'il', 'la', 'lo', 'the', 'e', 'and']);
// Host che NON identificano un locale (pagine social, directory, link brevi)
const GENERIC_HOSTS = ['facebook.com', 'instagram.com', 'tiktok.com', 'google.com', 'goo.gl', 'g.page', 'linktr.ee', 'tripadvisor.it', 'tripadvisor.com', 'thefork.it', 'justeat.it', 'deliveroo.it', 'glovoapp.com', 'wixsite.com', 'business.site'];

export function normalizeName(s: string): string {
  return normalizeText(s)
    .split(' ')
    .filter((w) => w && !NAME_NOISE.has(w))
    .join(' ');
}

export function normalizeAddress(s: string): string {
  return normalizeText(
    s
      .toLowerCase()
      .replace(/\bv\.\s*le\b|\bv\.le\b/g, 'viale')
      .replace(/\bc\.\s*so\b|\bc\.so\b/g, 'corso')
      .replace(/\bp\.\s*zz?a\b|\bp\.zz?a\b/g, 'piazza')
      .replace(/\bl\.\s*go\b/g, 'largo')
      .replace(/\bv\.\s+/g, 'via ')
      .replace(/\bn\.\s*(\d)/g, '$1')
      .replace(/\bsnc\b|\bs\.n\.c\.?\b/g, ' '),
  );
}

const phoneKey = (p: string | null | undefined) => {
  const d = (p ?? '').replace(/\D/g, '').replace(/^0039|^39(?=\d{9,10}$)/, '');
  return d.length >= 8 ? d.slice(-9) : null;
};

function bigrams(s: string): Map<string, number> {
  const m = new Map<string, number>();
  const t = s.replace(/\s+/g, ' ');
  for (let i = 0; i < t.length - 1; i++) {
    const g = t.slice(i, i + 2);
    m.set(g, (m.get(g) ?? 0) + 1);
  }
  return m;
}

/** Similarità 0..1: massimo tra coefficiente di Dice (bigrammi) e sovrapposizione di parole. */
export function similarity(a: string, b: string): number {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const A = bigrams(a);
  const B = bigrams(b);
  let inter = 0;
  A.forEach((n, g) => (inter += Math.min(n, B.get(g) ?? 0)));
  const total = [...A.values()].reduce((x, y) => x + y, 0) + [...B.values()].reduce((x, y) => x + y, 0);
  const dice = total ? (2 * inter) / total : 0;
  const ta = new Set(a.split(' '));
  const tb = new Set(b.split(' '));
  const common = [...ta].filter((w) => tb.has(w)).length;
  const tokens = common / Math.max(1, Math.min(ta.size, tb.size));
  // la sovrapposizione di parole conta solo se entrambi hanno almeno 2 parole (evita "sushi" ≈ "sushi bar")
  return Math.max(dice, Math.min(ta.size, tb.size) >= 2 ? tokens * 0.95 : 0);
}

function distanceM(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371000;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

const siteKey = (u: string | null | undefined) => {
  const h = hostOf(u);
  return h && !GENERIC_HOSTS.some((g) => h === g || h.endsWith(`.${g}`)) ? h : null;
};

/** Punteggio di somiglianza tra un record e un candidato esistente. */
export function scoreMatch(rec: NormalizedRecord, c: MatchCandidate): { score: number; reasons: string[] } {
  const reasons: string[] = [];
  let score = 0;

  if (rec.google_place_id && c.google_place_id && rec.google_place_id === c.google_place_id) {
    return { score: 100, reasons: ['Stesso Google Place ID'] };
  }
  if (rec.external_id && c.external_id && rec.external_id === c.external_id && (rec.source_name ?? '') === (c.source_name ?? '')) {
    return { score: 100, reasons: [`Stesso ID esterno (${rec.source_name ?? 'fonte'})`] };
  }

  const pr = phoneKey(rec.phone) ?? phoneKey(rec.whatsapp);
  const pc = [phoneKey(c.phone), phoneKey(c.whatsapp)].filter(Boolean);
  if (pr && pc.includes(pr)) {
    score += 60;
    reasons.push('Stesso numero di telefono');
  }

  const sr = siteKey(rec.website);
  if (sr && sr === siteKey(c.website)) {
    score += 50;
    reasons.push('Stesso sito web');
  }

  const sameCity = rec.city_id === c.city_id;
  const nameSim = similarity(normalizeName(rec.name), normalizeName(c.name));
  if (nameSim >= 0.95 && sameCity) {
    score += 55;
    reasons.push('Stesso nome nello stesso comune');
  } else if (nameSim >= 0.85) {
    score += sameCity ? 40 : 15;
    reasons.push(`Nome molto simile (${Math.round(nameSim * 100)}%)${sameCity ? '' : ' in altro comune'}`);
  } else if (nameSim >= 0.7 && sameCity) {
    score += 25;
    reasons.push(`Nome simile (${Math.round(nameSim * 100)}%)`);
  }

  if (rec.address && c.address && sameCity) {
    const addrSim = similarity(normalizeAddress(rec.address), normalizeAddress(c.address));
    if (addrSim >= 0.8) {
      score += 30;
      reasons.push(`Indirizzo molto simile (${Math.round(addrSim * 100)}%)`);
    }
  }

  if (rec.latitude != null && rec.longitude != null && c.latitude != null && c.longitude != null) {
    const d = distanceM({ lat: rec.latitude, lng: rec.longitude }, { lat: c.latitude, lng: c.longitude });
    if (d < 50) {
      score += 30;
      reasons.push(`A ${Math.round(d)} m di distanza`);
    } else if (d < 150) {
      score += 15;
      reasons.push(`A ${Math.round(d)} m di distanza`);
    }
  }

  return { score: Math.min(score, 99), reasons };
}

const confidenceOf = (score: number): MatchConfidence | null => (score >= 100 ? 'certain' : score >= 80 ? 'high' : score >= 50 ? 'medium' : null);

/** Trova i possibili duplicati, ordinati per punteggio (soglia: 50). */
export function findMatches<T extends MatchCandidate>(rec: NormalizedRecord, candidates: T[], limit = 3): MatchResult<T>[] {
  const out: MatchResult<T>[] = [];
  for (const c of candidates) {
    const { score, reasons } = scoreMatch(rec, c);
    const confidence = confidenceOf(score);
    if (confidence) out.push({ candidate: c, score, confidence, reasons });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}
