// Etichette in italiano per enum di dominio (una sola fonte per tutta la UI).
import type { ClaimStatus, DataStatus, MemberRole, ReportStatus, ReportType, SourceType, VerificationMethod } from '@/types/domain';

export type Tone = 'neutral' | 'coral' | 'dark' | 'green' | 'amber' | 'outline';

export const CLAIM_STATUS: Record<ClaimStatus, { label: string; tone: Tone; hint: string }> = {
  pending: { label: 'Inviata', tone: 'neutral', hint: 'In coda: verrà esaminata a breve.' },
  under_review: { label: 'In revisione', tone: 'amber', hint: 'Un amministratore sta verificando i dati.' },
  more_information_required: { label: 'Informazioni aggiuntive richieste', tone: 'coral', hint: 'Rispondi al messaggio per proseguire.' },
  approved: { label: 'Approvata', tone: 'green', hint: 'Ora gestisci la scheda dalla dashboard.' },
  rejected: { label: 'Rifiutata', tone: 'outline', hint: 'La richiesta non è stata accolta.' },
};

export const DATA_STATUS: Record<DataStatus, { label: string; tone: Tone; hint: string }> = {
  verified: { label: 'Verificato', tone: 'green', hint: 'Dati controllati su fonti pubbliche.' },
  partially_verified: { label: 'Parz. verificato', tone: 'amber', hint: 'Alcuni dati controllati, altri da confermare.' },
  unverified: { label: 'Non verificato', tone: 'neutral', hint: 'Dati non ancora controllati.' },
  claimed: { label: 'Gestito dal titolare', tone: 'dark', hint: 'Scheda rivendicata e aggiornata dal proprietario.' },
  outdated: { label: 'Da aggiornare', tone: 'coral', hint: 'Dati probabilmente non più attuali.' },
};

export const VERIFICATION_METHOD: Record<VerificationMethod, { label: string; description: string }> = {
  phone: { label: 'Telefono', description: 'Ti chiamiamo al numero pubblico del locale per confermare.' },
  email: { label: 'Email aziendale', description: 'Ti scriviamo all’email del locale o del dominio del sito ufficiale.' },
  document: { label: 'Documento', description: 'Carica una visura camerale o un documento aziendale (privato, visibile solo allo staff).' },
  manual: { label: 'Verifica manuale', description: 'Ti contatta un operatore per concordare la verifica più adatta.' },
};

export const REPORT_TYPE: Record<ReportType, string> = {
  wrong_address: 'Indirizzo errato',
  wrong_phone: 'Telefono errato',
  wrong_hours: 'Orari errati',
  closed: 'Attività chiusa',
  wrong_menu: 'Menu errato',
  wrong_price: 'Prezzo errato',
  other: 'Altro',
};

export const REPORT_STATUS: Record<ReportStatus, { label: string; tone: Tone }> = {
  open: { label: 'Aperta', tone: 'coral' },
  in_progress: { label: 'In lavorazione', tone: 'amber' },
  resolved: { label: 'Risolta', tone: 'green' },
  dismissed: { label: 'Archiviata', tone: 'outline' },
};

export const SOURCE_TYPE: Record<SourceType, string> = {
  google_business: 'Google Business Profile',
  official_website: 'Sito ufficiale',
  facebook: 'Pagina Facebook',
  instagram: 'Profilo Instagram',
  directory: 'Directory pubblica',
  owner: 'Titolare',
  admin: 'Redazione',
  import: 'Import',
  other: 'Altra fonte',
};

export const MEMBER_ROLE: Record<MemberRole, string> = {
  owner: 'Titolare',
  manager: 'Gestore',
  staff: 'Staff',
};

export const BUSINESS_ROLES = ['Titolare', 'Legale rappresentante', 'Socio', 'Gestore', 'Responsabile marketing', 'Altro'];
