import { useEffect } from 'react';
import { APP } from '@/config/app';
import type { RestaurantDetail } from '@/types/domain';
import { hoursByDay, shortTime } from './hours';
import { priceRangeLabel } from './format';

export interface SeoInput {
  title: string;
  description?: string;
  /** Path canonico (es. /ristoranti/taranto). Default: path corrente senza query. */
  path?: string;
  image?: string | null;
  type?: 'website' | 'article' | 'restaurant';
  noindex?: boolean;
  jsonLd?: Record<string, unknown> | Record<string, unknown>[];
}

function upsertMeta(attr: 'name' | 'property', key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function upsertLink(rel: string, href: string) {
  let el = document.head.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.rel = rel;
    document.head.appendChild(el);
  }
  el.href = href;
}

export const absoluteUrl = (path: string) => `${APP.siteUrl}${path.startsWith('/') ? path : `/${path}`}`;

/**
 * Gestione meta tag per pagina (title, description, canonical, OG, Twitter, JSON-LD).
 * In SPA i crawler moderni eseguono JS; per SEO massima vedi README → "Prerendering".
 */
export function useSeo(input: SeoInput) {
  const key = JSON.stringify(input);
  useEffect(() => {
    const title = input.title.includes(APP.name) ? input.title : `${input.title} | ${APP.name}`;
    const description = input.description ?? APP.tagline;
    const url = absoluteUrl(input.path ?? window.location.pathname);
    document.title = title;
    upsertMeta('name', 'description', description);
    upsertMeta('name', 'robots', input.noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large');
    upsertLink('canonical', url);
    upsertMeta('property', 'og:site_name', APP.name);
    upsertMeta('property', 'og:locale', 'it_IT');
    upsertMeta('property', 'og:type', input.type === 'restaurant' ? 'restaurant.restaurant' : input.type ?? 'website');
    upsertMeta('property', 'og:title', title);
    upsertMeta('property', 'og:description', description);
    upsertMeta('property', 'og:url', url);
    if (input.image) upsertMeta('property', 'og:image', input.image);
    upsertMeta('name', 'twitter:card', input.image ? 'summary_large_image' : 'summary');
    upsertMeta('name', 'twitter:title', title);
    upsertMeta('name', 'twitter:description', description);

    const id = 'seo-jsonld';
    document.getElementById(id)?.remove();
    if (input.jsonLd) {
      const s = document.createElement('script');
      s.type = 'application/ld+json';
      s.id = id;
      s.textContent = JSON.stringify(input.jsonLd);
      document.head.appendChild(s);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
}

const DAY_SCHEMA = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

/** schema.org/Restaurant per la scheda locale. */
export function restaurantJsonLd(r: RestaurantDetail, rating?: { count: number; average: number | null } | null): Record<string, unknown> {
  const url = absoluteUrl(`/ristorante/${r.slug}`);
  const opening = hoursByDay(r.hours).flatMap((d) =>
    d.slots.map((s) => ({
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: `https://schema.org/${DAY_SCHEMA[d.day - 1]}`,
      opens: shortTime(s.opens_at),
      closes: shortTime(s.closes_at),
    })),
  );
  return {
    '@context': 'https://schema.org',
    '@type': 'Restaurant',
    '@id': url,
    name: r.name,
    url,
    description: r.short_description ?? undefined,
    image: [r.cover_url, ...r.images.map((i) => i.url)].filter(Boolean).slice(0, 6),
    telephone: r.phone ?? undefined,
    email: r.email ?? undefined,
    priceRange: priceRangeLabel(r.price_range) || undefined,
    servesCuisine: r.categories.map((c) => c.name),
    acceptsReservations: r.has_reservation ? 'True' : 'False',
    hasMenu: r.menus.length ? `${url}#menu` : undefined,
    address: {
      '@type': 'PostalAddress',
      streetAddress: r.address ?? undefined,
      addressLocality: r.city?.name,
      addressRegion: r.province?.code,
      postalCode: r.postal_code ?? undefined,
      addressCountry: 'IT',
    },
    geo: r.latitude != null ? { '@type': 'GeoCoordinates', latitude: r.latitude, longitude: r.longitude } : undefined,
    openingHoursSpecification: opening.length ? opening : undefined,
    sameAs: [r.website, r.instagram, r.facebook].filter(Boolean),
    // Solo recensioni reali pubblicate e visibili nella pagina: mai valutazioni inventate o importate
    aggregateRating: rating && rating.count >= 1 && rating.average != null
      ? { '@type': 'AggregateRating', ratingValue: Math.round(rating.average * 10) / 10, reviewCount: rating.count, bestRating: 5, worstRating: 1 }
      : undefined,
  };
}

export function breadcrumbJsonLd(items: { name: string; path: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.name, item: absoluteUrl(it.path) })),
  };
}

export function itemListJsonLd(name: string, restaurants: { name: string; slug: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name,
    itemListElement: restaurants.slice(0, 30).map((r, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      url: absoluteUrl(`/ristorante/${r.slug}`),
      name: r.name,
    })),
  };
}
