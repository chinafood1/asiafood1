// ─────────────────────────────────────────────────────────────
//  Errori applicativi con codice stabile → messaggio comprensibile per l'utente.
//  Il backend risponde con { error: { code, message, requestId } }; il database con "CODICE: messaggio".
// ─────────────────────────────────────────────────────────────
import { t, type MessageKey } from '@/i18n';

export class AppError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly requestId?: string,
    readonly status?: number,
  ) {
    super(message);
    this.name = 'AppError';
  }
}

const CODE_MESSAGES: Record<string, MessageKey> = {
  RATE_LIMITED: 'errors.rate_limited',
  MAINTENANCE: 'errors.maintenance',
  NOT_CONFIGURED: 'errors.not_configured',
  PAYMENT_PROVIDER_UNAVAILABLE: 'errors.payment_unavailable',
  STRIPE_UNAVAILABLE: 'errors.payment_unavailable',
  CAPTCHA_FAILED: 'errors.captcha',
  REAUTH_REQUIRED: 'errors.reauth',
  FORBIDDEN: 'errors.forbidden',
  UNAUTHORIZED: 'errors.unauthorized',
  NOT_FOUND: 'errors.not_found',
  OFFLINE: 'errors.offline',
  NETWORK: 'errors.offline',
  INTERNAL: 'errors.generic',
};

/** Legge il corpo d'errore nel formato standard (e in quello storico { error: 'CODE', message }). */
export function readApiError(body: unknown, status: number, fallback: string): { code: string; message: string; requestId?: string } {
  const b = (body ?? {}) as Record<string, unknown>;
  const e = b.error;
  if (e && typeof e === 'object') {
    const o = e as { code?: string; message?: string; requestId?: string };
    return { code: o.code ?? `HTTP_${status}`, message: o.message ?? fallback, requestId: o.requestId };
  }
  if (typeof e === 'string') return { code: e, message: typeof b.message === 'string' ? b.message : fallback };
  return { code: `HTTP_${status}`, message: fallback };
}

/** Messaggio del database "CODICE: testo" → AppError con codice. */
export function fromDbMessage(message: string): AppError | null {
  const m = /^([A-Z][A-Z_]{3,40}): (.+)$/s.exec(message);
  return m ? new AppError(m[1]!, m[2]!) : null;
}

/** Testo da mostrare all'utente per qualsiasi errore (mai stack o dettagli tecnici). */
export function friendlyError(e: unknown): string {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return t('errors.offline');
  if (e instanceof AppError) {
    const key = CODE_MESSAGES[e.code];
    const base = e.message && !/^HTTP_\d+$/.test(e.message) ? e.message : key ? t(key) : t('errors.generic');
    return e.requestId && (e.status ?? 0) >= 500 ? `${base} ${t('errors.request_id', { id: e.requestId.slice(0, 8) })}` : base;
  }
  if (e instanceof Error) {
    const db = fromDbMessage(e.message);
    if (db) return db.message;
    if (/Failed to fetch|NetworkError|Load failed/i.test(e.message)) return t('errors.offline');
    return e.message || t('errors.generic');
  }
  return t('errors.generic');
}
