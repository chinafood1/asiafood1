// ─────────────────────────────────────────────────────────────
//  Consenso cookie/tracciamento (GDPR / Linee guida Garante):
//  - "necessari" sempre attivi (sessione, sicurezza, carrello, questa scelta)
//  - statistiche, marketing, personalizzazione solo con consenso esplicito (default: NO)
//  - scelta salvata nel browser (cookie tecnico/localStorage) + registrata nel database come prova,
//    con ID anonimo casuale (ospiti) o utente; nuova versione dell'informativa → si richiede di nuovo.
// ─────────────────────────────────────────────────────────────
import type { ConsentChoices, ConsentType } from '@/types/platform';

const KEY = 'af_consent';
export const CONSENT_DEFAULT: ConsentChoices = { analytics: false, marketing: false, personalization: false };

export interface StoredConsent {
  version: string;
  choices: ConsentChoices;
  at: string;
  anonymous_id: string;
}

const listeners = new Set<() => void>();
let memory: StoredConsent | null = null;

function randomId() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return `anon_${Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('')}`;
}

export function readConsent(): StoredConsent | null {
  if (memory) return memory;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) memory = JSON.parse(raw) as StoredConsent;
  } catch {
    /* storage non disponibile: nessun consenso (default prudente) */
  }
  return memory;
}

export function anonymousConsentId(): string {
  return readConsent()?.anonymous_id ?? randomId();
}

/** true solo se l'utente ha dato il consenso per quella categoria e per la versione corrente. */
export function hasConsent(type: ConsentType, currentVersion?: string): boolean {
  if (type === 'necessary') return true;
  const c = readConsent();
  if (!c) return false;
  if (currentVersion && c.version !== currentVersion) return false;
  return !!c.choices[type];
}

/** Serve mostrare il banner? (nessuna scelta o informativa aggiornata) */
export function needsConsent(currentVersion: string): boolean {
  const c = readConsent();
  return !c || c.version !== currentVersion;
}

export function writeConsent(choices: ConsentChoices, version: string): StoredConsent {
  const c: StoredConsent = { version, choices: { ...CONSENT_DEFAULT, ...choices }, at: new Date().toISOString(), anonymous_id: readConsent()?.anonymous_id ?? randomId() };
  memory = c;
  try {
    localStorage.setItem(KEY, JSON.stringify(c));
  } catch {
    /* resta in memoria per questa visita */
  }
  listeners.forEach((l) => l());
  return c;
}

export function subscribeConsent(fn: () => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

/** Evento per riaprire il pannello (link "Preferenze cookie" nel footer e nelle impostazioni). */
export const OPEN_CONSENT_EVENT = 'af:open-consent';
export const openConsentPreferences = () => window.dispatchEvent(new Event(OPEN_CONSENT_EVENT));
