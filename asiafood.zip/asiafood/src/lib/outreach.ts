// ─────────────────────────────────────────────────────────────
//  Fase 12 · Template di outreach commerciale (telefono, WhatsApp, email, Instagram, visita).
//  Regole: frasi vere solo se applicabili (es. "profilo già presente" solo se la scheda esiste
//  ed è pubblica), nessuna promessa di risultati, nessun invio automatico: si copia o si apre
//  l'app di messaggistica e l'invio lo fa una persona.
// ─────────────────────────────────────────────────────────────
export interface OutreachContext {
  business: string;
  city?: string | null;
  /** URL pubblico della scheda, solo se la scheda esiste ed è visibile */
  profileUrl?: string | null;
  claimUrl?: string | null;
  sender?: string | null;
  founding?: { enabled: boolean; name: string; plan: string; days: number; slotsLeft: number } | null;
  appName?: string;
}

const planName = (p: string) => p.charAt(0).toUpperCase() + p.slice(1);

function offerLine(c: OutreachContext): string | null {
  const f = c.founding;
  if (!f?.enabled || f.slotsLeft <= 0 || f.days <= 0) return null;
  return `Per i primi ristoranti che aderiscono c'è il programma “${f.name}”: ${f.days} giorni di piano ${planName(f.plan)} senza costi, poi decidete voi se continuare (nessun rinnovo automatico).`;
}

export function whatsappMessage(c: OutreachContext): string {
  const app = c.appName ?? 'AsiaFood';
  const hello = `Ciao! Sono ${c.sender ?? '[nome]'} di ${app}, la piattaforma dedicata alla cucina asiatica a Taranto e provincia.`;
  const why = c.profileUrl
    ? `${c.business} è già presente su ${app} con una scheda base: potete rivendicarla gratis e gestire voi menu, orari, foto e offerte.`
    : `Stiamo selezionando i primi ristoranti partner della zona e ${c.business} ci sembra perfetto.`;
  const cta = c.profileUrl ? 'Ti mando il link della vostra scheda?' : 'Ti mando due righe su come funziona?';
  return [hello, why, cta].join('\n\n');
}

export function emailTemplate(c: OutreachContext): { subject: string; body: string } {
  const app = c.appName ?? 'AsiaFood';
  const offer = offerLine(c);
  const lines = [
    'Buongiorno,',
    `mi chiamo ${c.sender ?? '[nome]'} e lavoro al lancio di ${app}, una piattaforma dedicata esclusivamente alla cucina asiatica a Taranto e provincia: i clienti scoprono i locali, consultano menu e offerte, prenotano e salvano coupon.`,
    c.profileUrl
      ? `${c.business} ha già una scheda di base, creata da fonti pubbliche: ${c.profileUrl}\nRivendicandola (gratis) potete correggere i dati e gestire menu, orari, foto e offerte, e vedere le statistiche della scheda.`
      : `Ci piacerebbe inserire ${c.business} tra i primi locali della piattaforma.`,
    offer,
    c.claimUrl ? `Per rivendicare la scheda: ${c.claimUrl}` : null,
    'Se preferite, posso mostrarvi una demo di 10 minuti al telefono o di persona, quando vi è più comodo.',
    'Grazie per l’attenzione,',
    `${c.sender ?? '[nome e cognome]'}\n${app} · [telefono] · [email]`,
  ].filter(Boolean);
  return { subject: `${c.business} su ${app}${c.city ? ` · ${c.city}` : ''}`, body: lines.join('\n\n') };
}

export function instagramDm(c: OutreachContext): string {
  const app = c.appName ?? 'AsiaFood';
  return c.profileUrl
    ? `Ciao! Siamo ${app}, la nuova app della cucina asiatica a Taranto 🍣 ${c.business} ha già una scheda: volete gestirla voi (gratis)? Vi mandiamo il link?`
    : `Ciao! Siamo ${app}, la nuova app della cucina asiatica a Taranto 🍣 Stiamo selezionando i primi ristoranti partner: vi va di saperne di più?`;
}

/** Traccia per la telefonata: struttura, non un copione da leggere parola per parola. */
export function phoneScript(c: OutreachContext): { step: string; text: string }[] {
  const app = c.appName ?? 'AsiaFood';
  const offer = offerLine(c);
  return [
    { step: 'Presentazione (10 secondi)', text: `Buongiorno, sono ${c.sender ?? '[nome]'} di ${app}. Parlo con il titolare o con chi gestisce la comunicazione di ${c.business}?` },
    { step: 'Motivo del contatto', text: `Stiamo lanciando ${app}, una piattaforma dedicata esclusivamente alla cucina asiatica a Taranto e provincia.` },
    ...(c.profileUrl
      ? [{ step: 'Profilo già presente (solo se vero)', text: `Abbiamo già predisposto una scheda di base di ${c.business} con i dati pubblici, e stiamo selezionando i primi ristoranti partner della zona.` }]
      : []),
    { step: 'Vantaggio', text: 'Il cliente trova il vostro menu, gli orari, le offerte e può prenotare o chiamarvi in un tocco. Voi vedete quante persone guardano la scheda, chiamano o chiedono indicazioni.' },
    { step: 'Demo', text: 'Posso mostrarvela in 5 minuti adesso sul telefono, oppure passo io nei prossimi giorni con un tablet: cosa preferite?' },
    { step: 'Rivendicazione', text: 'La rivendicazione è gratuita: vi mando il link su WhatsApp o email e in due minuti la scheda è vostra.' },
    ...(offer ? [{ step: 'Prova', text: offer }] : []),
    { step: 'Chiusura', text: 'Registro ogni esito nel CRM (interessato, richiamare, non interessato). Se chiedono di non essere ricontattati: “Non ricontattare”.' },
  ];
}

/** Visita di persona: 2–3 minuti iniziali, poi demo solo se c'è interesse. */
export function visitScript(c: OutreachContext): string[] {
  return [
    `Presentarsi al banco nei momenti tranquilli (mai durante il servizio): “Buongiorno, sono ${c.sender ?? '[nome]'} di ${c.appName ?? 'AsiaFood'}, bastano due minuti.”`,
    c.profileUrl ? 'Mostrare sullo smartphone la scheda del locale già presente e la mappa della zona.' : 'Mostrare sullo smartphone la mappa e una scheda di esempio.',
    'Mostrare il QR del ristorante (table card) e come il cliente arriva a menu, recensioni e prenotazione.',
    'Lasciare il volantino “Porta il tuo ristorante su AsiaFood” con il QR per la pagina ristoratori e i prezzi.',
    'Se interessati: rivendicazione subito dal loro telefono, poi prima offerta scelta da loro.',
    'Annotare nel CRM: esito, persona di riferimento (solo se ha dato il consenso), prossima azione.',
  ];
}

export const whatsappLink = (phone: string | null | undefined, text: string) => {
  const d = (phone ?? '').replace(/\D/g, '');
  const intl = d.startsWith('39') ? d : d ? `39${d}` : '';
  return intl ? `https://wa.me/${intl}?text=${encodeURIComponent(text)}` : `https://wa.me/?text=${encodeURIComponent(text)}`;
};
export const mailtoLink = (email: string | null | undefined, subject: string, body: string) =>
  `mailto:${encodeURIComponent(email ?? '')}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

/** Obiezioni frequenti: risposte che posizionano AsiaFood come verticale, senza denigrare nessuno. */
export const OBJECTIONS: { q: string; a: string }[] = [
  { q: 'Uso già Just Eat.', a: 'Perfetto, continuate pure: AsiaFood non sostituisce il delivery. È una vetrina dedicata solo alla cucina asiatica: menu, prenotazioni, offerte e indicazioni, e porta clienti anche in sala e all’asporto.' },
  { q: 'Uso già TheFork.', a: 'Ottimo per le prenotazioni. AsiaFood è specializzato: chi cerca sushi, ramen o AYCE a Taranto trova solo locali asiatici, con menu e offerte. La scheda base è gratuita e potete indicare il vostro canale di prenotazione preferito.' },
  { q: 'Non voglio un altro abbonamento.', a: 'La scheda e la rivendicazione sono gratuite. I piani a pagamento sono facoltativi e si possono provare senza costi: decidete voi dopo aver visto i numeri reali della vostra scheda.' },
  { q: 'Non ho bisogno di prenotazioni.', a: 'Nessun problema: le prenotazioni sono facoltative. Molti clienti vi chiamano o chiedono indicazioni direttamente dalla scheda; potete anche solo tenere aggiornati menu e orari.' },
  { q: 'Ho già il mio sito.', a: 'Il sito resta il vostro riferimento e lo colleghiamo alla scheda. AsiaFood vi fa trovare da chi ancora non vi conosce e cerca cucina asiatica in zona.' },
  { q: 'Non faccio delivery.', a: 'AsiaFood non è solo delivery: è scoperta, menu, prenotazioni, offerte, fidelizzazione e visibilità locale. Asporto e consegna sono opzionali.' },
];

export const VALUE_PROPOSITION = [
  'Scoperta: una vetrina solo per la cucina asiatica di Taranto e provincia (ricerca, mappa, assistente AI).',
  'Profilo: scheda verificata con menu, orari, foto, servizi e prezzi aggiornati dal ristoratore.',
  'Menu digitale e QR per tavoli e banco.',
  'Prenotazioni e ordini (facoltativi).',
  'Offerte e coupon con condizioni decise dal ristoratore.',
  'Fidelizzazione: AsiaPoints, inviti, recensioni verificate.',
  'Visibilità locale e statistiche reali della scheda (visualizzazioni, chiamate, indicazioni, prenotazioni).',
];
