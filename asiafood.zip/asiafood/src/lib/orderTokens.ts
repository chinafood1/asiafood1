// Token di accesso degli ordini ospite: restano SOLO su questo dispositivo (niente account richiesto).
// Il server conserva solo l'hash: senza token (o login del proprietario) l'ordine non è visibile.
const KEY = 'af_order_tokens';
type Store = Record<string, { t: string; at: number }>;

function read(): Store {
  try {
    return JSON.parse(localStorage.getItem(KEY) || '{}') as Store;
  } catch {
    return {};
  }
}

export function saveOrderToken(orderNumber: string, token: string) {
  try {
    const s = read();
    s[orderNumber] = { t: token, at: Date.now() };
    const keep = Object.entries(s).sort((a, b) => b[1].at - a[1].at).slice(0, 20);
    localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(keep)));
  } catch {
    /* storage non disponibile */
  }
}

export const getOrderToken = (orderNumber: string): string | null => read()[orderNumber]?.t ?? null;

/** Ordini ospite recenti su questo dispositivo (per "I miei ordini" senza account). */
export const recentGuestOrders = () => Object.entries(read()).sort((a, b) => b[1].at - a[1].at).map(([n, v]) => ({ order_number: n, token: v.t }));
