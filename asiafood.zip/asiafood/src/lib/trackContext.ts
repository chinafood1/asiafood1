// ─────────────────────────────────────────────────────────────
//  Fase 13 · Metadati standard degli eventi (nessun dato personale):
//  tipo di dispositivo e campagna di atterraggio della sessione (sessionStorage "af_touch").
//  Modulo senza dipendenze dai servizi (evita import circolari).
// ─────────────────────────────────────────────────────────────
import { hasConsent } from './consent';

export type DeviceType = 'mobile' | 'tablet' | 'desktop';

export function deviceType(): DeviceType {
  try {
    const w = window.innerWidth;
    return w < 768 ? 'mobile' : w < 1100 && matchMedia('(pointer: coarse)').matches ? 'tablet' : 'desktop';
  } catch {
    return 'desktop';
  }
}

export function trackContext(): Record<string, string> {
  const out: Record<string, string> = { device_type: deviceType() };
  try {
    const raw = sessionStorage.getItem('af_touch');
    const t = raw ? (JSON.parse(raw) as { channel?: string; utm_source?: string | null; utm_campaign?: string | null }) : null;
    if (t?.utm_source) out.utm_source = t.utm_source;
    if (t?.utm_campaign) out.utm_campaign = t.utm_campaign;
    if (t?.channel) out.channel = t.channel;
  } catch {
    /* storage non disponibile */
  }
  return out;
}

/** ID della sessione di navigazione SOLO con consenso "Statistiche" (stesso "af_sid" degli eventi analytics). */
export function consentedSessionId(): string | null {
  if (!hasConsent('analytics')) return null;
  try {
    let id = sessionStorage.getItem('af_sid');
    if (!id) {
      id = crypto.randomUUID();
      sessionStorage.setItem('af_sid', id);
    }
    return id;
  } catch {
    return null;
  }
}
