import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { isSupabaseConfigured, SUPABASE } from '@/config/app';

/**
 * Client Supabase singleton. È `null` quando le variabili ambiente
 * non sono impostate: in quel caso l'app usa la modalità DEMO.
 * (Tipi DB generabili con: npx supabase gen types typescript)
 */
export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(SUPABASE.url, SUPABASE.anonKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    })
  : null;
