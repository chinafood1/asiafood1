export interface LatLng {
  lat: number;
  lng: number;
}

export function haversineKm(a: LatLng, b: LatLng): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

export const isAppleDevice = () =>
  typeof navigator !== 'undefined' && (/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1));

/**
 * Link indicazioni: nessuna API key. Su iPhone/iPad apre Apple Maps,
 * altrove Google Maps (che su Android apre l'app di navigazione).
 */
export function directionsUrl(
  r: { latitude: number | null; longitude: number | null; name: string; address?: string | null; city?: { name: string } | null },
  apple = isAppleDevice(),
) {
  const hasCoords = r.latitude != null && r.longitude != null;
  const query = [r.name, r.address, r.city?.name].filter(Boolean).join(', ');
  if (apple) {
    return hasCoords
      ? `https://maps.apple.com/?daddr=${r.latitude},${r.longitude}&q=${encodeURIComponent(r.name)}`
      : `https://maps.apple.com/?daddr=${encodeURIComponent(query)}`;
  }
  return `https://www.google.com/maps/dir/?api=1&destination=${hasCoords ? `${r.latitude},${r.longitude}` : encodeURIComponent(query)}`;
}
