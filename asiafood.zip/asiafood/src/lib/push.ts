// ─────────────────────────────────────────────────────────────
//  Notifiche push web/PWA (Web Push VAPID). Mai richieste all'apertura
//  del sito: solo dopo un'azione esplicita. Se il browser non le
//  supporta (o l'utente rifiuta) l'app funziona normalmente.
// ─────────────────────────────────────────────────────────────
import { api, isDemoMode } from '@/services';
import { setDemoPushHandler } from '@/services/demoSource';
import { safeAssign } from './safeRedirect';

const DISMISS_KEY = 'af_push_prompt_dismissed';

export type PushState = 'unsupported' | 'denied' | 'default' | 'granted';

export function pushSupport(): { supported: boolean; reason?: string } {
  if (typeof window === 'undefined' || !('Notification' in window)) return { supported: false, reason: 'Questo browser non supporta le notifiche.' };
  if (!isDemoMode && !('serviceWorker' in navigator && 'PushManager' in window)) {
    return { supported: false, reason: /iPhone|iPad/.test(navigator.userAgent) ? 'Su iPhone le notifiche funzionano dopo aver aggiunto AsiaFood alla schermata Home.' : 'Questo browser non supporta le notifiche push.' };
  }
  return { supported: true };
}

export const pushPermission = (): PushState => (!pushSupport().supported ? 'unsupported' : (Notification.permission as PushState));

export function promptDismissed() {
  try {
    return !!localStorage.getItem(DISMISS_KEY);
  } catch {
    return false;
  }
}
export function dismissPrompt() {
  try {
    localStorage.setItem(DISMISS_KEY, new Date().toISOString());
  } catch {
    /* noop */
  }
  void api.saveNotificationPrefs({ push_prompt_dismissed_at: new Date().toISOString() }).catch(() => undefined);
}

const b64ToUint8 = (b64: string) => {
  const pad = '='.repeat((4 - (b64.length % 4)) % 4);
  const raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
};
const toB64Url = (buf: ArrayBuffer | null) =>
  buf ? btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '') : '';

const deviceLabel = () => {
  const ua = navigator.userAgent;
  const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Mac/.test(ua) ? 'macOS' : /Windows/.test(ua) ? 'Windows' : 'Web';
  const br = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  return { device: `${br} su ${os}`, platform: os.toLowerCase() };
};

/** In DEMO le push sono notifiche locali del browser (nessun servizio esterno). */
function installDemoHandler() {
  setDemoPushHandler((title, body, url) => {
    if (Notification.permission !== 'granted') return;
    try {
      const n = new Notification(title, { body, icon: '/icons/icon-192.png' });
      n.onclick = () => {
        window.focus();
        if (url) safeAssign(url);
      };
    } catch {
      /* alcuni browser mobili consentono solo notifiche dal service worker */
    }
  });
}

export async function enablePush(): Promise<{ ok: boolean; message: string }> {
  const sup = pushSupport();
  if (!sup.supported) return { ok: false, message: sup.reason ?? 'Notifiche non supportate.' };
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') {
    dismissPrompt();
    return { ok: false, message: 'Permesso non concesso: puoi riattivarlo dalle impostazioni del browser.' };
  }
  const { device, platform } = deviceLabel();
  if (isDemoMode) {
    installDemoHandler();
    let id = '';
    try {
      id = localStorage.getItem('af_demo_push_endpoint') ?? `demo:${crypto.randomUUID()}`;
      localStorage.setItem('af_demo_push_endpoint', id);
    } catch {
      id = `demo:${crypto.randomUUID()}`;
    }
    await api.savePushSubscription({ endpoint: id, p256dh: 'demo', auth: 'demo', device, platform });
    return { ok: true, message: 'Notifiche attivate su questo dispositivo (DEMO: notifiche locali).' };
  }
  const res = await fetch('/api/push/public-key').then((r) => (r.ok ? r.json() : { publicKey: null })).catch(() => ({ publicKey: null }));
  if (!res.publicKey) return { ok: false, message: 'Le notifiche push non sono ancora configurate su questo sito. Riceverai comunque le notifiche nell’app.' };
  const reg = await navigator.serviceWorker.ready;
  const sub = (await reg.pushManager.getSubscription()) ?? (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToUint8(res.publicKey) }));
  await api.savePushSubscription({ endpoint: sub.endpoint, p256dh: toB64Url(sub.getKey('p256dh')), auth: toB64Url(sub.getKey('auth')), device, platform });
  return { ok: true, message: 'Notifiche attivate su questo dispositivo.' };
}

export async function disablePush() {
  if (isDemoMode) {
    const id = (() => {
      try {
        return localStorage.getItem('af_demo_push_endpoint');
      } catch {
        return null;
      }
    })();
    if (id) await api.removePushSubscription(id);
    setDemoPushHandler(null);
    return;
  }
  if (!('serviceWorker' in navigator)) return;
  const reg = await navigator.serviceWorker.ready;
  const sub = await reg.pushManager.getSubscription();
  if (sub) {
    await api.removePushSubscription(sub.endpoint);
    await sub.unsubscribe().catch(() => undefined);
  }
}

/** All'avvio (senza chiedere nulla): ripristina il gestore DEMO se il permesso era già stato dato. */
export function restorePushHandler() {
  if (isDemoMode && pushSupport().supported && Notification.permission === 'granted') installDemoHandler();
}

/** Badge PWA con le notifiche non lette (se supportato; altrimenti niente). */
export function setAppBadge(n: number) {
  const nav = navigator as Navigator & { setAppBadge?: (n: number) => Promise<void>; clearAppBadge?: () => Promise<void> };
  try {
    if (n > 0) void nav.setAppBadge?.(n).catch(() => undefined);
    else void nav.clearAppBadge?.().catch(() => undefined);
  } catch {
    /* non supportato */
  }
}
