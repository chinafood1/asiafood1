// Inglese (predisposto per una futura versione): le chiavi mancanti ricadono sull'italiano.
import type { MessageKey } from './it';

export const en: Partial<Record<MessageKey, string>> = {
  'errors.generic': 'Something went wrong. Please try again shortly.',
  'errors.offline': 'You are offline. Check your connection and try again.',
  'pwa.update_available': 'An update is available.',
  'pwa.update': 'Update',
  'maintenance.title': 'We are performing an update.',
};
