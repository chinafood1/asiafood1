// i18n minimale: italiano predefinito, struttura pronta per altre lingue (VITE_LOCALE o scelta utente futura).
import { en } from './en';
import { it, type MessageKey } from './it';

const DICTS: Record<string, Partial<Record<MessageKey, string>>> = { it, en };
let locale: string = ((import.meta.env ?? {}) as Record<string, string | undefined>).VITE_LOCALE || 'it';

export const setLocale = (l: string) => {
  locale = DICTS[l] ? l : 'it';
};
export const getLocale = () => locale;

/** Traduzione con segnaposto {nome}. */
export function t(key: MessageKey, vars: Record<string, string | number> = {}): string {
  const raw = DICTS[locale]?.[key] ?? it[key] ?? key;
  return raw.replace(/\{(\w+)\}/g, (_, k: string) => String(vars[k] ?? `{${k}}`));
}
export type { MessageKey };
