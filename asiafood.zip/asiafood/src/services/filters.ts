// Pipeline di filtro/ordinamento condivisa tra sorgente demo e Supabase.
// Supabase esegue lato DB i filtri indicizzati; qui restano quelli
// dipendenti dal tempo (aperto ora) o dalla posizione dell'utente,
// che non viene mai inviata al server se non strettamente necessario.
import { NEW_OPENING_DAYS } from '@/config/app';
import { haversineKm } from '@/lib/geo';
import { isOpenNow } from '@/lib/hours';
import { normalizeText, parseSearchQuery, type NamedSlug } from '@/lib/searchQuery';
import type { Category, OfferWithRestaurant, RestaurantSummary } from '@/types/domain';
import type { OfferFilters, RestaurantFilters } from './types';

export const isAyceCategory = (slug?: string) => slug === 'all-you-can-eat';

/**
 * Interpreta la ricerca libera. Restituisce i filtri effettivi e, se il
 * testo conteneva categoria/comune, una variante "solo testo" da usare
 * come ripiego se la prima non trova nulla (es. un locale chiamato "Taranto Sushi").
 */
export function resolveQuery(f: RestaurantFilters, categories: NamedSlug[], cities: NamedSlug[]): { primary: RestaurantFilters; fallback?: RestaurantFilters } {
  if (!f.q?.trim()) return { primary: { ...f, q: undefined } };
  const p = parseSearchQuery(f.q, categories, cities);
  const primary: RestaurantFilters = {
    ...f,
    q: undefined,
    text: p.text,
    categorySlug: f.categorySlug ?? p.categorySlug,
    citySlug: f.citySlug ?? p.citySlug,
    ayce: f.ayce || p.ayce || undefined,
  };
  const structured = !!(p.categorySlug || p.citySlug);
  return { primary, fallback: structured ? { ...f, q: undefined, text: normalizeText(f.q) } : undefined };
}

/** Ogni parola del testo deve comparire in nome, descrizioni, indirizzo, comune o categorie. */
export function matchesText(r: RestaurantSummary, text: string): boolean {
  const words = normalizeText(text).split(' ').filter((w) => w.length > 1);
  if (!words.length) return true;
  const hay = normalizeText(
    [r.name, r.short_description, r.description, r.address, r.city?.name, ...r.categories.map((c) => c.name)].filter(Boolean).join(' '),
  );
  return words.every((w) => hay.includes(w));
}

export function isNewOpening(r: { opened_at: string | null }, now = Date.now()): boolean {
  if (!r.opened_at) return false;
  const age = (now - new Date(r.opened_at).getTime()) / 86_400_000;
  return age >= 0 && age <= NEW_OPENING_DAYS;
}

/** "Aperto ora" solo con orari disponibili e locale non chiuso: mai supposizioni. */
export const isOpenNowStrict = (r: Pick<RestaurantSummary, 'hours' | 'timezone' | 'is_temporarily_closed' | 'is_permanently_closed'>) =>
  !r.is_temporarily_closed && !r.is_permanently_closed && r.hours.length > 0 && isOpenNow(r.hours, r.timezone);

export function applyFilters(
  list: RestaurantSummary[],
  f: RestaurantFilters,
  opts: { categories: Category[]; skipServerSide?: boolean; boostedIds?: string[]; /** Visibilità da piano (search_boost). */ planBoost?: (r: RestaurantSummary) => number },
): RestaurantSummary[] {
  let out = list.filter((r) => r.is_active);

  // Filtri "server-side" (nella sorgente demo li applichiamo qui)
  if (!opts.skipServerSide) {
    if (!f.includeClosed) out = out.filter((r) => !r.is_permanently_closed);
    if (f.text) out = out.filter((r) => matchesText(r, f.text!));
    if (f.categorySlug) {
      const slug = f.categorySlug;
      out = out.filter((r) => (isAyceCategory(slug) ? r.is_all_you_can_eat || r.categories.some((c) => c.slug === slug) : r.categories.some((c) => c.slug === slug)));
    }
    if (f.citySlug) out = out.filter((r) => r.city?.slug === f.citySlug);
    if (f.priceRanges?.length) out = out.filter((r) => r.price_range != null && f.priceRanges!.includes(r.price_range));
    if (f.ayce) out = out.filter((r) => r.is_all_you_can_eat);
    if (f.delivery) out = out.filter((r) => r.has_delivery);
    if (f.takeaway) out = out.filter((r) => r.has_takeaway);
    if (f.reservation) out = out.filter((r) => r.has_reservation);
    if (f.featured) out = out.filter((r) => r.is_featured);
    if (f.verified) out = out.filter((r) => r.is_verified && !!r.owner_id);
    if (f.bounds) {
      const b = f.bounds;
      out = out.filter((r) => r.latitude != null && r.longitude != null && r.latitude <= b.north && r.latitude >= b.south && r.longitude <= b.east && r.longitude >= b.west);
    }
  }

  // Filtri sempre client-side
  if (f.newOpenings) out = out.filter((r) => isNewOpening(r));
  if (f.hasOffers) out = out.filter((r) => r.active_offers_count > 0);
  if (f.openNow) out = out.filter((r) => isOpenNowStrict(r));

  // Distanza calcolata nel browser: la posizione dell'utente resta sul dispositivo
  if (f.near) {
    const origin = { lat: f.near.lat, lng: f.near.lng };
    out = out
      .map((r) => ({
        ...r,
        distance_km: r.latitude != null && r.longitude != null ? haversineKm(origin, { lat: r.latitude, lng: r.longitude }) : undefined,
      }))
      .filter((r) => (f.near!.radiusKm ? r.distance_km !== undefined && r.distance_km <= f.near!.radiusKm : true));
  }

  // Ordinamenti: nessun rating o recensione fittizia
  const sort = f.sort ?? (f.near ? 'distance' : 'relevance');
  const byPopular = (a: RestaurantSummary, b: RestaurantSummary) => b.popularity_score - a.popularity_score;
  const textRank = (r: RestaurantSummary) => (f.text && normalizeText(r.name).includes(normalizeText(f.text)) ? 1 : 0);
  const boost = (r: RestaurantSummary) => opts.planBoost?.(r) ?? 0;
  const trust = (r: RestaurantSummary) => (r.data_status === 'claimed' || r.data_status === 'verified' ? 1 : 0);
  const sorters: Record<string, (a: RestaurantSummary, b: RestaurantSummary) => number> = {
    relevance: (a, b) =>
      textRank(b) - textRank(a) || Number(b.is_featured) - Number(a.is_featured) || boost(b) - boost(a) || trust(b) - trust(a) || byPopular(a, b) || a.name.localeCompare(b.name),
    popular: (a, b) => byPopular(a, b) || a.name.localeCompare(b.name),
    distance: (a, b) => (a.distance_km ?? 9e9) - (b.distance_km ?? 9e9),
    price_asc: (a, b) => (a.average_price ?? a.price_range ?? 9e9) - (b.average_price ?? b.price_range ?? 9e9),
    price_desc: (a, b) => (b.average_price ?? b.price_range ?? 0) - (a.average_price ?? a.price_range ?? 0),
    newest: (a, b) => (b.opened_at ?? b.created_at).localeCompare(a.opened_at ?? a.created_at),
  };
  out = [...out].sort(sorters[sort] ?? sorters.relevance);

  // Temporaneamente chiusi in fondo (restano visibili con l'avviso)
  out = [...out.filter((r) => !r.is_temporarily_closed), ...out.filter((r) => r.is_temporarily_closed)];

  // Le sponsorizzazioni NON alterano l'ordine organico: hanno slot separati ed etichettati (sponsored_slots)
  return f.limit ? out.slice(0, f.limit) : out;
}

export const isOfferActiveNow = (o: { is_active: boolean; starts_at: string; ends_at: string | null }, now = Date.now()) =>
  o.is_active && new Date(o.starts_at).getTime() <= now && (!o.ends_at || new Date(o.ends_at).getTime() > now);

/** Giorno ISO (1 = lunedì) di una data YYYY-MM-DD. */
const isoDayOf = (date: string) => ((new Date(`${date}T12:00:00Z`).getUTCDay() + 6) % 7) + 1;

/**
 * Filtri della pagina Offerte (comuni a demo e Supabase). Le offerte in ingresso
 * sono già quelle pubbliche (attive, locale pubblicato, piano che include le offerte).
 */
export function filterOffers(rows: OfferWithRestaurant[], f: OfferFilters): OfferWithRestaurant[] {
  let out = rows.filter((o) => isOfferActiveNow(o));
  const date = f.date ?? (f.today ? new Date().toISOString().slice(0, 10) : undefined);
  if (date) {
    const start = `${date}T23:59:59.999Z`;
    const end = `${date}T00:00:00.000Z`;
    const day = isoDayOf(date);
    out = out.filter((o) => o.starts_at <= start && (!o.ends_at || o.ends_at >= end) && (!o.days_of_week.length || o.days_of_week.includes(day)));
  }
  if (f.citySlug) out = out.filter((o) => o.restaurant.city_slug === f.citySlug);
  if (f.categorySlug) {
    out = out.filter((o) =>
      isAyceCategory(f.categorySlug) ? o.restaurant.is_all_you_can_eat || o.offer_type === 'ayce_promo' : o.restaurant.category_slugs.includes(f.categorySlug!),
    );
  }
  if (f.ayce) out = out.filter((o) => o.offer_type === 'ayce_promo' || o.restaurant.is_all_you_can_eat);
  if (f.offerType) out = out.filter((o) => o.offer_type === f.offerType);
  if (f.near) {
    const origin = { lat: f.near.lat, lng: f.near.lng };
    out = out
      .map((o) => ({
        ...o,
        distance_km: o.restaurant.latitude != null && o.restaurant.longitude != null ? haversineKm(origin, { lat: o.restaurant.latitude, lng: o.restaurant.longitude }) : undefined,
      }))
      .filter((o) => o.distance_km !== undefined && (!f.near!.radiusKm || o.distance_km <= f.near!.radiusKm));
  }
  out = [...out].sort(
    (a, b) =>
      Number(b.is_featured) - Number(a.is_featured) ||
      (f.near ? (a.distance_km ?? 9e9) - (b.distance_km ?? 9e9) : 0) ||
      b.starts_at.localeCompare(a.starts_at),
  );
  return f.limit ? out.slice(0, f.limit) : out;
}
