/* eslint-disable @typescript-eslint/no-explicit-any -- motore DEMO su un database locale eterogeneo (righe di più moduli) */
// ─────────────────────────────────────────────────────────────
//  Fase 13 in modalità DEMO: stesse regole delle migrazioni 0025–0027 su dati locali.
//  In DEMO gli aggregati sono calcolati al volo dai dati del browser (nessuna tabella giornaliera):
//  ogni giorno risulta quindi "aggregato". Nessun invio reale: le bozze approvate diventano notifiche locali.
// ─────────────────────────────────────────────────────────────
import {
  churnReason, DEFAULT_MARKET_WEIGHTS, growthChannel, healthScore, marketScore, MARKET_SCORE_KEYS, normalizeQuery, searchDemandScore, type MarketScoreKey, type RestaurantPerformance,
} from '@shared/growth';
import { AppError } from '@/lib/errors';
import type {
  AutomationItem, AutomationRule, AutomationRun, ExperimentReport, GrowthAlert, GrowthApi, GrowthExperiment, GrowthLearning, GrowthReport, GrowthTask, MarketCandidate,
  MarketReadiness, OperatingCost, PeriodTotals, PlaybookItem, RestaurantHealth, SearchLogInput, SupplyGapRow,
} from '@/types/growth';
import type { LaunchOverview } from '@/types/launch';
import type { LaunchState } from './launchDemo';
import { consentedSessionId } from '@/lib/trackContext';

type R = any;

export interface GrowthState {
  search_events: { source: string; query_norm: string | null; city_slug: string | null; category_slug: string | null; result_count: number; result_ids: string[]; session_id: string | null; created_at: string }[];
  alerts: GrowthAlert[];
  rules: Omit<AutomationRule, 'owner_name' | 'pending_items' | 'last_run'>[];
  runs: Omit<AutomationRun, 'rule_name'>[];
  items: (Omit<AutomationItem, 'rule_name' | 'restaurant_name' | 'has_recipient'> & { dedupe_key: string; target_user_id: string | null })[];
  variants: { experiment_id: string; name: string; allocation: number }[];
  assignments: { experiment_id: string; variant: string; anonymous_id: string; user_id: string | null; converted_at: string | null; created_at: string }[];
  exp_meta: Record<string, { end_at: string | null; secondary_metrics: string[]; guardrail_area: GrowthExperiment['guardrail_area']; review_approved_at: string | null; review_note: string | null; created_by: string | null }>;
  reports: GrowthReport[];
  tasks: GrowthTask[];
  learnings: GrowthLearning[];
  candidates: { slug: string; name: string; province_code: string | null; region_name: string; status: MarketCandidate['status']; market_id: string | null; research_started_at: string | null }[];
  playbook: PlaybookItem[];
  costs: OperatingCost[];
  settings: Record<string, unknown>;
  kill_switch: boolean;
}

export interface GrowthAccess {
  db: R;
  save(): void;
  uid(): string | null;
  isAdmin(): boolean;
  canManage(restaurantId: string): boolean;
  demoVisible(): boolean;
  launch(): LaunchState;
  launchOverview(slug: string): Promise<LaunchOverview>;
  completion(r: R): { score: number; missing: string[]; has_menu: boolean; has_hours: boolean };
  orders(): R[];
  carts(): R[];
  reviews(): R[];
  referrals(): R[];
  loyaltyTx(): R[];
  loyaltyAccounts(): R[];
  rewardRedemptions(): R[];
  activityDays(): { user_id: string; day: string }[];
  marketingOk(uid: string): boolean;
  notify(uid: string, type: string, title: string, body: string, link: string | null): void;
  supportTickets(): R[];
  aiUsage(): R[];
}

const DAY = 86_400_000;
const nowIso = () => new Date().toISOString();
const uuid = () => crypto.randomUUID();
const romeDay = (d: Date = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome' }).format(d);
const dayOf = (iso: string | null | undefined) => (iso ? romeDay(new Date(iso)) : '');
const addDays = (d: string, n: number) => {
  const t = new Date(`${d}T12:00:00Z`);
  t.setUTCDate(t.getUTCDate() + n);
  return t.toISOString().slice(0, 10);
};
const diffDays = (a: string, b: string) => Math.round((Date.parse(`${a}T12:00:00Z`) - Date.parse(`${b}T12:00:00Z`)) / DAY);
const ts = (s: string | null | undefined) => (s ? Date.parse(s) : NaN);
const inR = (iso: string | null | undefined, from: string, to: string) => {
  const d = dayOf(iso);
  return !!d && d >= from && d <= to;
};
const r1 = (x: number) => Math.round(x * 10) / 10;
const deny = () => new AppError('FORBIDDEN', 'Operazione non consentita.');
const fail = (m: string) => new Error(m);

const DEFAULT_SETTINGS: Record<string, unknown> = {
  growth_return_window_days: 30, growth_min_sample: 30, growth_experiment_min_sample: 100, growth_directions_as_conversion: false, growth_supply_gap_min_searches: 5,
  growth_alert_zero_result_min: 10, growth_alert_no_login_days: 21, growth_anomaly_min_baseline: 10, growth_anomaly_drop_pct: 60, growth_checkout_drop_pct: 25,
  growth_search_log_days: 90, growth_market_weights: DEFAULT_MARKET_WEIGHTS, growth_forecast: null, growth_payment_fee_pct: null,
  growth_expansion_candidates: ['bari', 'lecce', 'brindisi', 'matera', 'foggia'], cac_min_conversions: 5,
};

const RULE_SEED: [string, string, string, AutomationRule['audience'], string, AutomationRule['action'], boolean, boolean, boolean, Record<string, unknown>, number][] = [
  ['consumer_category_affinity', 'Affinità categoria → offerte (es. Sushi)', 'Utenti con almeno N preferiti nella categoria e consenso marketing: bozza di suggerimento verso offerte attive della categoria. Nessun invio senza approvazione.', 'consumer', 'favorites_category_affinity', 'draft_user_message', false, true, true, { category: 'sushi', min_favorites: 3 }, 1440],
  ['consumer_abandoned_cart', 'Carrello abbandonato', 'Carrelli con prodotti fermi da 2–48 ore senza ordine, solo utenti con consenso marketing: bozza di promemoria da approvare.', 'consumer', 'abandoned_cart', 'draft_user_message', false, true, true, { min_hours: 2, max_hours: 48 }, 120],
  ['consumer_abandoned_reservation', 'Prenotazione abbandonata', 'NON DISPONIBILE: l\'avvio della prenotazione è tracciato in forma anonima (senza utente), quindi non è possibile sapere chi l\'ha abbandonata senza raccogliere dati aggiuntivi.', 'consumer', 'abandoned_reservation', 'unavailable', false, true, true, {}, 1440],
  ['consumer_dormant_reactivation', 'Riattivazione utenti dormienti', 'Utenti senza attività da 30–90 giorni, con consenso marketing, e nuovi ristoranti pubblicati nel loro comune negli ultimi 30 giorni: bozza "Nuovi ristoranti sono arrivati su AsiaFood".', 'consumer', 'dormant_new_restaurants', 'draft_user_message', false, true, true, { min_days: 30, max_days: 90 }, 1440],
  ['restaurant_incomplete_profile', 'Profilo ristorante incompleto', 'Ristoranti rivendicati con completezza < 60%: task CRM interno "Aiutare a completare il profilo".', 'restaurant', 'profile_incomplete', 'create_crm_task', true, false, false, { threshold: 60 }, 1440],
  ['restaurant_trial_ending', 'Prova in scadenza (3 giorni)', 'Prove che terminano entro 3 giorni: task di follow-up commerciale. Notifica in-app al titolare solo se abilitata e se il sistema di fatturazione non l\'ha già inviata.', 'restaurant', 'trial_ending', 'create_crm_task', true, false, false, { days: 3, notify_owner: false }, 720],
  ['restaurant_payment_failed', 'Pagamento non riuscito', 'Abbonamenti in past_due/unpaid: task di supporto (Stripe invia già le comunicazioni di fatturazione).', 'restaurant', 'payment_failed', 'create_crm_task', true, false, false, {}, 720],
  ['sales_no_reply', 'Lead senza risposta (4 giorni)', 'Lead contattati senza risposta da 4 giorni: task con bozza di follow-up (il messaggio NON viene inviato).', 'sales', 'lead_no_reply', 'create_crm_task', true, false, false, { days: 4 }, 1440],
  ['sales_demo_done', 'Demo completata → prossimo passo', 'Demo registrata negli ultimi 7 giorni senza attività successive: task "Inviare link di rivendicazione / proporre la prova".', 'sales', 'demo_completed', 'create_crm_task', true, false, false, {}, 1440],
  ['sales_trial_mid', 'Metà prova → follow-up', 'Prove oltre la metà della durata, non convertite: task di follow-up con i dati di performance del locale (senza promettere risultati).', 'sales', 'trial_midpoint', 'create_crm_task', true, false, false, {}, 1440],
  ['restaurant_winback', 'Win-back ristoranti', 'Abbonamenti terminati negli ultimi 90 giorni: task per chiedere feedback. Mai riattivare un abbonamento senza consenso esplicito del ristoratore.', 'restaurant', 'subscription_ended', 'create_crm_task', true, false, false, { days: 90 }, 1440],
];

export function growthDefaults(): GrowthState {
  const t = nowIso();
  return {
    search_events: [], alerts: [], runs: [], items: [], variants: [], assignments: [], exp_meta: {}, reports: [], tasks: [], learnings: [], playbook: [], costs: [], settings: {},
    kill_switch: false,
    rules: RULE_SEED.map(([key, name, description, audience, trigger_key, action, enabled, requires_approval, consent_required, config, interval_minutes]) => ({
      id: uuid(), key, name, description, audience, trigger_key, action, enabled, requires_approval, consent_required, config, interval_minutes,
      owner_id: null, last_run_at: null, next_run_at: null, failure_count: 0, last_error: null, created_at: t, updated_at: t,
    })) as GrowthState['rules'],
    candidates: [['bari', 'Bari', 'BA', 'Puglia'], ['lecce', 'Lecce', 'LE', 'Puglia'], ['brindisi', 'Brindisi', 'BR', 'Puglia'], ['matera', 'Matera', 'MT', 'Basilicata'], ['foggia', 'Foggia', 'FG', 'Puglia']]
      .map(([slug, name, province_code, region_name]) => ({ slug: slug!, name: name!, province_code: province_code!, region_name: region_name!, status: 'candidate' as const, market_id: null, research_started_at: null })),
  };
}

export function createGrowthDemo(a: GrowthAccess): GrowthApi {
  const db = () => a.db;
  const st = (): GrowthState => {
    const s = (db().growth ??= growthDefaults()) as GrowthState;
    return s;
  };
  const L = () => a.launch();
  const setting = <T = number>(k: string): T => (k in st().settings ? st().settings[k] : DEFAULT_SETTINGS[k]) as T;
  const minSample = () => Number(setting('growth_min_sample'));
  const admin = () => {
    if (!a.isAdmin()) throw deny();
  };
  const today = () => romeDay();
  const inScope = (r: R) => !!r && (!r.is_demo || a.demoVisible());
  const rest = (id: string | null | undefined) => db().restaurants.find((x: R) => x.id === id);
  const cityOf = (id: string | null | undefined) => db().cities.find((c: R) => c.id === id);
  const provinceByCode = (code: string | null | undefined) => db().provinces.find((p: R) => p.code === code);
  const catsOf = (rid: string) => db().restaurant_categories.filter((x: R) => x.restaurant_id === rid).map((x: R) => db().categories.find((c: R) => c.id === x.category_id)?.slug).filter(Boolean);
  const events = (): R[] => db().analytics ?? [];
  const appEvents = (): R[] => db().app_events ?? [];
  const subs = (): R[] => db().subscriptions ?? [];
  const reservations = (): R[] => db().reservations ?? [];
  const claims = (): R[] => db().coupon_claims ?? [];
  const customers = (): R[] => db().profiles.filter((p: R) => p.role === 'customer');
  const grants = (s: R) => (s.source !== 'stripe' ? ['active', 'trialing'].includes(s.status) && !s.revoked_at && (!s.expires_at || ts(s.expires_at) > Date.now())
    : ['active', 'trialing', 'past_due'].includes(s.status));
  const mrrOf = (s: R) => (s.billing_interval === 'year' ? (s.unit_amount_cents ?? 0) / 12 : s.unit_amount_cents ?? 0);
  const payingSub = (s: R) => s.source === 'stripe' && s.paid_started_at && ['active', 'past_due'].includes(s.status) && grants(s);
  const marketBySlug = (slug: string | null | undefined) => (slug ? L().markets.find((m) => m.slug === slug) : undefined);
  const marketRestIds = (slug: string | null | undefined): Set<string> => {
    const m = marketBySlug(slug);
    const prov = m ? provinceByCode(m.province_code) : null;
    return new Set(db().restaurants.filter((r: R) => inScope(r) && (!slug || (prov && (r.province_id ?? cityOf(r.city_id)?.province_id) === prov.id))).map((r: R) => r.id));
  };
  const lastLogin = (uid: string | null | undefined) => (uid ? a.activityDays().filter((x) => x.user_id === uid).map((x) => x.day).sort().pop() ?? null : null);
  const paidOrder = (o: R) => ['paid', 'partially_refunded'].includes(o.payment_status) && !['rejected', 'cancelled', 'refunded'].includes(o.status);

  // ─── Metriche per ristorante in un intervallo (specchio di daily_restaurant_metrics) ───
  function restMetrics(from: string, to: string) {
    const m = new Map<string, R>();
    const get = (rid: string) => {
      let x = m.get(rid);
      if (!x) {
        x = { impressions: 0, views: 0, menu_views: 0, item_views: 0, calls: 0, whatsapp: 0, directions: 0, offer_views: 0, add_to_cart: 0, favorites: 0, bookings: 0,
          bookings_completed: 0, orders: 0, orders_completed: 0, orders_rejected: 0, revenue_cents: 0, coupon_claims: 0, coupon_redemptions: 0, reviews: 0 };
        m.set(rid, x);
      }
      return x;
    };
    const map: Record<string, string> = { restaurant_view: 'views', view: 'views', menu_view: 'menu_views', click_menu: 'menu_views', menu_item_view: 'item_views', phone_click: 'calls',
      click_phone: 'calls', whatsapp_click: 'whatsapp', click_whatsapp: 'whatsapp', directions_click: 'directions', click_directions: 'directions', offer_view: 'offer_views',
      coupon_reveal: 'offer_views', add_to_cart: 'add_to_cart' };
    for (const e of events()) if (e.restaurant_id && map[e.event_type] && inR(e.created_at, from, to)) get(e.restaurant_id)[map[e.event_type]!]++;
    for (const s of st().search_events) if (inR(s.created_at, from, to)) for (const id of s.result_ids) get(id).impressions++;
    for (const f of db().favorites ?? []) if (inR(f.created_at, from, to)) get(f.restaurant_id).favorites++;
    for (const r of reservations()) {
      if (inR(r.created_at, from, to) && r.status !== 'rejected') get(r.restaurant_id).bookings++;
      if (r.status === 'completed' && r.reservation_date >= from && r.reservation_date <= to) get(r.restaurant_id).bookings_completed++;
    }
    for (const o of a.orders()) {
      if (inR(o.paid_at, from, to) && ['paid', 'partially_refunded', 'refunded'].includes(o.payment_status)) get(o.restaurant_id).orders++;
      if (inR(o.paid_at, from, to) && paidOrder(o)) get(o.restaurant_id).revenue_cents += Math.round(Number(o.total) * 100);
      if (inR(o.completed_at, from, to) && o.status === 'completed') get(o.restaurant_id).orders_completed++;
      if (inR(o.rejected_at, from, to)) get(o.restaurant_id).orders_rejected++;
    }
    for (const c of claims()) {
      if (inR(c.claimed_at, from, to)) get(c.restaurant_id).coupon_claims++;
      if (c.status === 'redeemed' && inR(c.redeemed_at, from, to)) get(c.restaurant_id).coupon_redemptions++;
    }
    for (const r of a.reviews()) if (inR(r.created_at, from, to)) get(r.restaurant_id).reviews++;
    for (const k of [...m.keys()]) if (!inScope(rest(k))) m.delete(k);
    return m;
  }
  const sumM = (m: Map<string, R>, key: string, ids?: Set<string>) => [...m].reduce((s, [rid, x]) => s + (!ids || ids.has(rid) ? x[key] : 0), 0);

  function searchesIn(from: string, to: string, slug?: string | null) {
    const prov = slug ? provinceByCode(marketBySlug(slug)?.province_code) : null;
    return st().search_events.filter((s) => inR(s.created_at, from, to) && (!prov || (s.city_slug && db().cities.find((c: R) => c.slug === s.city_slug)?.province_id === prov.id)));
  }

  function totals(from: string, to: string, market?: string | null): PeriodTotals {
    const m = restMetrics(from, to);
    const ids = market ? marketRestIds(market) : undefined;
    const ss = searchesIn(from, to, market);
    const appSearch = market ? 0 : appEvents().filter((e) => ['search', 'near_me_search', 'map_area_search'].includes(e.event_type) && inR(e.created_at, from, to)).length;
    const visits = (L().visits ?? []).filter((v) => inR(v.created_at, from, to)).length;
    const days = diffDays(to, from) + 1;
    const fee = a.orders().filter((o) => inR(o.paid_at, from, to) && paidOrder(o) && inScope(rest(o.restaurant_id))).reduce((s, o) => s + Math.round((Number(o.platform_fee ?? 0) + Number(o.service_fee ?? 0)) * 100), 0);
    const invoices = (db().billing_invoices ?? []).filter((i: R) => i.status === 'paid' && inR(i.created_at ?? i.stripe_created_at, from, to)).reduce((s: number, i: R) => s + (i.amount_paid_cents ?? 0), 0);
    const ai = a.aiUsage().filter((u) => inR(u.created_at, from, to));
    const actSet = new Set(a.activityDays().filter((x) => x.day >= from && x.day <= to).map((x) => x.user_id));
    return {
      visits, new_users: customers().filter((p: R) => inR(p.created_at, from, to)).length, sessions: new Set([...events(), ...appEvents()].filter((e) => e.session_id && inR(e.created_at, from, to)).map((e) => e.session_id)).size,
      searches: ss.filter((s) => s.source !== 'ai').length + appSearch, zero_result_searches: ss.filter((s) => s.result_count === 0).length,
      ai_queries: ai.filter((u) => ['ok', 'fallback', 'cached'].includes(u.status)).length, restaurant_views: sumM(m, 'views', ids), menu_views: sumM(m, 'menu_views', ids) + sumM(m, 'item_views', ids),
      intents: ['calls', 'whatsapp', 'directions', 'add_to_cart', 'favorites', 'item_views'].reduce((s, k) => s + sumM(m, k, ids), 0)
        + events().filter((e) => ['reservation_start', 'click_reservation'].includes(e.event_type) && inR(e.created_at, from, to) && (!ids || ids.has(e.restaurant_id))).length,
      reservations: sumM(m, 'bookings', ids), reservations_completed: sumM(m, 'bookings_completed', ids), orders: sumM(m, 'orders', ids), orders_completed: sumM(m, 'orders_completed', ids),
      checkouts: events().filter((e) => e.event_type === 'checkout_started' && inR(e.created_at, from, to)).length,
      payment_failures: events().filter((e) => e.event_type === 'payment_failed' && inR(e.created_at, from, to)).length,
      gmv_cents: sumM(m, 'revenue_cents', ids), order_fees_cents: fee, subscription_revenue_cents: invoices, platform_revenue_cents: fee + invoices,
      coupon_claims: sumM(m, 'coupon_claims', ids), coupon_redemptions: sumM(m, 'coupon_redemptions', ids), reviews: sumM(m, 'reviews', ids),
      referrals_qualified: a.referrals().filter((r) => inR(r.qualified_at, from, to)).length,
      new_paid_restaurants: new Set(subs().filter((s) => s.source === 'stripe' && inR(s.paid_started_at, from, to)).map((s) => s.restaurant_id)).size,
      ai_cost_micros: 0, ai_errors: ai.filter((u) => u.status === 'error').length, active_users: actSet.size,
      days, days_computed: days, complete: true,
    };
  }
  const conversions = (t: PeriodTotals, from: string, to: string, market?: string | null) => t.reservations + t.orders + t.coupon_redemptions
    + (setting<boolean>('growth_directions_as_conversion') ? (() => { const m = restMetrics(from, to); const ids = market ? marketRestIds(market) : undefined; return sumM(m, 'directions', ids) + sumM(m, 'calls', ids); })() : 0);

  // ─── Health (specchio di growth_restaurant_health) ───
  function health(rid: string): RestaurantHealth {
    const r = rest(rid);
    if (!r?.owner_id) return { score: null, status: 'not_claimed', components: {}, signals: [] };
    const t = today();
    const comp: Record<string, number> = {};
    const c = a.completion(r);
    comp.completeness = c.score / 100;
    const last = lastLogin(r.owner_id);
    comp.recent_login = last && last >= addDays(t, -7) ? 1 : last && last >= addDays(t, -30) ? 0.5 : 0;
    const menuTs = db().menu_items.filter((i: R) => i.restaurant_id === rid).map((i: R) => ts(i.updated_at ?? i.created_at)).filter(Number.isFinite);
    const menuMax = menuTs.length ? Math.max(...menuTs) : null;
    comp.menu_updated = menuMax == null ? 0 : menuMax > Date.now() - 60 * DAY ? 1 : menuMax > Date.now() - 180 * DAY ? 0.5 : 0;
    const res = reservations().filter((x) => x.restaurant_id === rid && ts(x.created_at) > Date.now() - 60 * DAY);
    const unanswered = res.filter((x) => x.status === 'pending' && x.reservation_date < t && x.reservation_date >= addDays(t, -30)).length;
    if (res.length) comp.reservation_response = res.filter((x) => x.status !== 'pending' || x.reservation_date >= t).length / res.length;
    const ord = a.orders().filter((o) => o.restaurant_id === rid && ts(o.created_at) > Date.now() - 60 * DAY);
    const acc = ord.filter((o) => o.accepted_at).length;
    const rej = ord.filter((o) => o.rejected_at).length;
    if (acc + rej) comp.order_acceptance = acc / (acc + rej);
    comp.offers = db().offers.some((o: R) => o.restaurant_id === rid && o.is_active && (!o.ends_at || ts(o.ends_at) > Date.now()))
      || db().coupons.some((o: R) => o.restaurant_id === rid && o.is_active && (!o.valid_until || ts(o.valid_until) > Date.now())) ? 1 : 0;
    const m = restMetrics(addDays(t, -29), t).get(rid);
    const act = m ? m.calls + m.whatsapp + m.directions + m.bookings + m.orders + m.coupon_redemptions : 0;
    comp.customer_actions = act >= 10 ? 1 : act >= 1 ? 0.5 : 0;
    const s = subs().filter((x) => x.restaurant_id === rid).sort((x, y) => Number(['active', 'trialing', 'past_due'].includes(y.status)) - Number(['active', 'trialing', 'past_due'].includes(x.status)) || String(y.created_at).localeCompare(String(x.created_at)))[0];
    comp.subscription = !s ? 0.5 : ['past_due', 'unpaid'].includes(s.status) ? 0 : s.cancel_at_period_end ? 0.25 : s.status === 'trialing' ? 0.75 : s.status === 'active' && s.paid_started_at ? 1 : 0.5;
    const signals: RestaurantHealth['signals'] = [];
    if (s?.status === 'trialing' && s.trial_end && ts(s.trial_end) > Date.now() && ts(s.trial_end) < Date.now() + 7 * DAY) signals.push({ key: 'trial_ending', label: `Prova in scadenza il ${new Date(s.trial_end).toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit' })}` });
    if (s && ['past_due', 'unpaid'].includes(s.status)) signals.push({ key: 'payment_failed', label: 'Pagamento non riuscito' });
    if (!last || last < addDays(t, -30)) signals.push({ key: 'no_login_30d', label: last ? `Nessun accesso da ${diffDays(t, last)} giorni` : 'Nessun accesso registrato' });
    if (c.score < 60) signals.push({ key: 'profile_incomplete', label: `Profilo completo al ${c.score}%` });
    if (act === 0) signals.push({ key: 'zero_actions', label: 'Nessuna azione dei clienti negli ultimi 30 giorni' });
    if (unanswered) signals.push({ key: 'reservations_unanswered', label: `${unanswered} prenotazioni rimaste senza risposta` });
    if (rej >= 3 && rej / (acc + rej) >= 0.3) signals.push({ key: 'orders_rejected', label: `${rej} ordini rifiutati su ${acc + rej}` });
    const h = healthScore(comp);
    return { ...h, status: signals.some((x) => x.key === 'payment_failed') ? 'at_risk' : h.status, components: comp, signals, last_login: last };
  }

  // ─── Supply gap (specchio di growth_supply_gap) ───
  function supplyGap(from: string, to: string, market?: string | null): SupplyGapRow[] {
    const minS = Number(setting('growth_supply_gap_min_searches'));
    const agg = new Map<string, { city_slug: string; category_slug: string; term: string; searches: number; zero: number; ai: number }>();
    for (const s of searchesIn(from, to, market)) {
      if (!s.city_slug || (!s.category_slug && !s.query_norm)) continue;
      const term = s.category_slug ? '' : s.query_norm ?? '';
      const k = `${s.city_slug}|${s.category_slug ?? ''}|${term}`;
      const x = agg.get(k) ?? { city_slug: s.city_slug, category_slug: s.category_slug ?? '', term, searches: 0, zero: 0, ai: 0 };
      x.searches++;
      if (s.result_count === 0) x.zero++;
      if (s.source === 'ai') x.ai++;
      agg.set(k, x);
    }
    const rows = [...agg.values()].filter((x) => x.searches >= minS);
    const max = Math.max(1, ...rows.map((x) => x.searches));
    return rows.map((x) => {
      const supply = db().restaurants.filter((r: R) => cityOf(r.city_id)?.slug === x.city_slug && r.is_active && inScope(r) && !r.is_permanently_closed
        && (!x.category_slug || catsOf(r.id).includes(x.category_slug) || (x.category_slug === 'all-you-can-eat' && r.is_all_you_can_eat))).length;
      const demand = Math.round((40 * Math.log(1 + x.searches)) / Math.log(1 + max));
      const zero = Math.round((40 * x.zero) / x.searches);
      const low = supply === 0 ? 20 : supply < 3 ? 10 : 0;
      return {
        city_slug: x.city_slug, city: db().cities.find((c: R) => c.slug === x.city_slug)?.name ?? null, category_slug: x.category_slug || null,
        category: db().categories.find((c: R) => c.slug === x.category_slug)?.name ?? null, term: x.term || null, searches: x.searches, zero_results: x.zero, ai_searches: x.ai, supply,
        zero_pct: Math.round((x.zero * 100) / x.searches),
        score: Math.min(100, Math.round((40 * Math.log(1 + x.searches)) / Math.log(1 + max) + (40 * x.zero) / x.searches + low)), breakdown: { demand, zero_results: zero, low_supply: low },
      };
    }).sort((p, q) => q.zero_results - p.zero_results || q.searches - p.searches);
  }

  // ─── Mercati e candidate ───
  function readiness(marketId: string | null): MarketReadiness | null {
    const m = L().markets.find((x) => x.id === marketId);
    if (!m) return null;
    const prov = provinceByCode(m.province_code);
    const rs = db().restaurants.filter((r: R) => !r.is_demo && r.is_active && prov && (r.province_id ?? cityOf(r.city_id)?.province_id) === prov.id);
    const complete = rs.filter((r: R) => a.completion(r).score >= 60).length;
    const leads = L().leads.filter((l) => l.market_id === m.id);
    const contacted = leads.filter((l) => ['contacted', 'replied', 'demo_scheduled', 'demo_done', 'claim_sent', 'claimed', 'trial', 'activated', 'paid'].includes(l.status)).length;
    const perCity = new Map<string, number>();
    for (const r of rs) perCity.set(r.city_id, (perCity.get(r.city_id) ?? 0) + 1);
    const seo = [...perCity.values()].filter((n) => n >= 3).length;
    const items = st().playbook.filter((i) => i.market_id === m.id);
    const pb: Record<string, { done: number; total: number }> = {};
    for (const i of items) {
      pb[i.stage] ??= { done: 0, total: 0 };
      pb[i.stage]!.total++;
      if (i.done_at) pb[i.stage]!.done++;
    }
    const dataOk = rs.length >= 20 && complete >= rs.length * 0.6;
    const salesOk = leads.length >= 20 && contacted >= 10;
    return {
      data: { ok: dataOk, detail: `${rs.length} ristoranti, ${complete} con profilo ≥ 60%` },
      sales: { ok: salesOk, detail: `${leads.length} lead, ${contacted} contattati` },
      seo: { ok: seo >= 1, detail: `${seo} comuni con ≥ 3 ristoranti (pagine indicizzabili)` },
      operational: { ok: (pb.partners?.done ?? 0) >= 1 && (pb.beta_users?.done ?? 0) >= 1, detail: 'Almeno un\'attività completata in Partner e Beta users nel playbook' },
      launch_ready: { ok: dataOk && salesOk && seo >= 1 && (pb.launch?.total ?? 0) > 0 && pb.launch!.done === pb.launch!.total, detail: 'Tutti i criteri precedenti + checklist "Launch" completa' },
      playbook: pb,
    };
  }
  function areaInputs(code: string | null, name: string) {
    const prov = provinceByCode(code);
    const word = name.toLowerCase();
    const re = new RegExp(`(^| )${word}( |$)`);
    const since = Date.now() - 90 * DAY;
    const ss = st().search_events.filter((s) => ts(s.created_at) > since && ((prov && s.city_slug && db().cities.find((c: R) => c.slug === s.city_slug)?.province_id === prov.id) || (s.query_norm && re.test(s.query_norm))));
    const demand = ss.length;
    const zero = ss.filter((s) => s.result_count === 0).length;
    const supply = prov ? db().restaurants.filter((r: R) => !r.is_demo && r.is_active && !r.is_permanently_closed && (r.province_id ?? cityOf(r.city_id)?.province_id) === prov.id).length : 0;
    const leads = (prov ? L().leads.filter((l) => cityOf(l.city_id)?.province_id === prov.id).length : 0) + supply;
    const organic = prov ? customers().filter((p: R) => cityOf(p.city_id)?.province_id === prov.id).length : 0;
    const commercial = prov ? (db().restaurant_claims ?? []).filter((c: R) => { const r = rest(c.restaurant_id); return r && !r.is_demo && (r.province_id ?? cityOf(r.city_id)?.province_id) === prov.id; }).length
      + L().leads.filter((l) => cityOf(l.city_id)?.province_id === prov.id && ['replied', 'demo_scheduled', 'demo_done', 'claim_sent', 'claimed', 'trial', 'activated', 'paid'].includes(l.status)).length : 0;
    return { search_demand: demand, zero_results: zero, supply_gap: zero + (supply < 5 ? Math.max(demand - zero, 0) : 0), supply, lead_availability: leads, organic_interest: organic, commercial_interest: commercial };
  }
  function candidates(): MarketCandidate[] {
    const list = setting<string[]>('growth_expansion_candidates');
    const w = setting<Record<MarketScoreKey, number>>('growth_market_weights');
    const rows = st().candidates.filter((c) => c.status !== 'rejected' && list.includes(c.slug)).filter((c) => {
      const mk = L().markets.find((m) => m.province_code === c.province_code);
      return !mk || mk.status === ('planned' as never);
    }).map((c) => ({ c, inputs: areaInputs(c.province_code, c.name) }));
    const max = Object.fromEntries(MARKET_SCORE_KEYS.map((k) => [k, Math.max(0, ...rows.map((r) => r.inputs[k]))])) as Record<MarketScoreKey, number>;
    return rows.map(({ c, inputs }) => {
      const sc = marketScore(inputs, max, w);
      return {
        ...c, province_id: provinceByCode(c.province_code)?.id ?? null, has_province: !!provinceByCode(c.province_code), inputs, ...sc,
        data_points: Object.entries(inputs).filter(([k, v]) => k !== 'supply' && v > 0).length, readiness: readiness(c.market_id),
      } as MarketCandidate;
    }).sort((x, y) => y.score - x.score || x.name.localeCompare(y.name));
  }

  // ─── Alert (specchio di growth_alerts_refresh, soglie identiche) ───
  function upsertAlert(seen: Set<string>, key: string, severity: GrowthAlert['severity'], category: string, title: string, detail: string | null, link: string | null, metric: R = {}) {
    seen.add(key);
    const x = st().alerts.find((al) => al.key === key);
    if (x) {
      Object.assign(x, { severity, title, detail, link, metric, last_seen_at: nowIso() });
      if (x.status === 'resolved') Object.assign(x, { status: 'open', resolved_at: null });
    } else {
      st().alerts.push({ id: uuid(), key, severity, category, title, detail, link, metric, status: 'open', first_seen_at: nowIso(), last_seen_at: nowIso(), resolved_at: null });
    }
  }
  function refreshAlerts() {
    const seen = new Set<string>();
    const t = today();
    const zmin = Number(setting('growth_alert_zero_result_min'));
    const combos = new Map<string, { q: string; city: string; cat: string; z: number }>();
    for (const s of searchesIn(addDays(t, -6), t)) {
      if (s.result_count !== 0) continue;
      const k = `${s.query_norm ?? ''}:${s.city_slug ?? ''}:${s.category_slug ?? ''}`;
      const x = combos.get(k) ?? { q: s.query_norm ?? '', city: s.city_slug ?? '', cat: s.category_slug ?? '', z: 0 };
      x.z++;
      combos.set(k, x);
    }
    for (const [k, x] of [...combos].filter(([, v]) => v.z >= zmin).sort((p, q) => q[1].z - p[1].z).slice(0, 10)) {
      const label = [db().categories.find((c: R) => c.slug === x.cat)?.name ?? x.q, db().cities.find((c: R) => c.slug === x.city)?.name].filter(Boolean).join(' · ');
      upsertAlert(seen, `zero:${k}`, 'warning', 'search', `«${label}»: ${x.z} ricerche senza risultati in 7 giorni`, 'Domanda non servita: valutare censimento di nuovi locali o contatto con ristoranti della zona.', '/admin/growth/search', { zero_results: x.z });
    }
    for (const s of subs()) {
      const r = rest(s.restaurant_id);
      if (!inScope(r)) continue;
      if (s.status === 'trialing' && s.trial_end && ts(s.trial_end) > Date.now() && ts(s.trial_end) < Date.now() + 3 * DAY) {
        upsertAlert(seen, `trial:${r.id}`, 'warning', 'trial', `Prova di «${r.name}» in scadenza il ${new Date(s.trial_end).toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit' })}`,
          'Follow-up commerciale consigliato (nessun addebito o rinnovo automatico viene attivato da AsiaFood).', '/admin/growth/restaurants', { restaurant_id: r.id });
      }
      if (['past_due', 'unpaid'].includes(s.status)) upsertAlert(seen, `payfail:${r.id}`, 'critical', 'billing', `Pagamento non riuscito: «${r.name}»`, 'Stripe riprova automaticamente; verificare se serve supporto al ristoratore.', '/admin/growth/churn', { restaurant_id: r.id });
    }
    const noLogin = Number(setting('growth_alert_no_login_days'));
    for (const r of db().restaurants.filter((x: R) => x.owner_id && inScope(x) && subs().some((s) => s.restaurant_id === x.id && ['active', 'trialing', 'past_due'].includes(s.status)))) {
      const last = lastLogin(r.owner_id);
      if (!last || diffDays(t, last) >= noLogin) {
        upsertAlert(seen, `nologin:${r.id}`, 'warning', 'restaurant', last ? `«${r.name}» non accede da ${diffDays(t, last)} giorni` : `«${r.name}» non ha mai effettuato l'accesso`,
          'Rischio di abbandono: contatto di supporto consigliato.', '/admin/growth/restaurants', { restaurant_id: r.id });
      }
    }
    const unanswered = reservations().filter((x) => x.status === 'pending' && x.reservation_date < t && x.reservation_date >= addDays(t, -7) && inScope(rest(x.restaurant_id))).length;
    if (unanswered >= 3) upsertAlert(seen, `reservations:unanswered:${t}`, 'warning', 'reservations', `${unanswered} prenotazioni rimaste senza risposta (7 giorni)`, 'Clienti senza conferma: verificare con i ristoranti la gestione delle richieste.', '/admin/growth/restaurants');
    for (const ru of st().rules.filter((x) => x.failure_count >= 3)) upsertAlert(seen, `automation:${ru.id}`, 'warning', 'automation', `Automazione «${ru.name}»: ${ru.failure_count} errori consecutivi`, 'Controllare lo storico esecuzioni.', '/admin/growth/automations');
    let resolved = 0;
    for (const al of st().alerts) if (al.status === 'open' && !seen.has(al.key)) { Object.assign(al, { status: 'resolved', resolved_at: nowIso() }); resolved++; }
    a.save();
    return { active: seen.size, resolved };
  }

  // ─── Automazioni ───
  function crmTask(rule: GrowthState['rules'][number], dedupe: string, rid: string | null, leadId: string | null, title: string, reason: string) {
    if (st().items.some((i) => i.rule_id === rule.id && i.dedupe_key === dedupe)) return 0;
    if (!L().tasks.some((x) => x.status === 'open' && x.restaurant_id === rid && x.reason === reason && x.source !== 'manual')) {
      L().tasks.push({ id: uuid(), lead_id: leadId, restaurant_id: rid, title, reason, due_at: new Date(Date.now() + DAY).toISOString(), assigned_to: rule.owner_id, status: 'open', source: 'system', created_at: nowIso(), market_id: L().markets[0]?.id ?? null });
    }
    st().items.push({ id: uuid(), rule_id: rule.id, dedupe_key: dedupe, status: 'done', target_user_id: null, restaurant_id: rid, title: title.slice(0, 140), body: null, link: null, payload: {}, created_at: nowIso(), decided_at: null, sent_at: null });
    return 1;
  }
  function draft(rule: GrowthState['rules'][number], dedupe: string, uid: string, title: string, body: string, link: string) {
    if (!a.marketingOk(uid) || st().items.some((i) => i.rule_id === rule.id && i.dedupe_key === dedupe)) return 0;
    st().items.push({ id: uuid(), rule_id: rule.id, dedupe_key: dedupe, status: 'pending_approval', target_user_id: uid, restaurant_id: null, title, body, link, payload: {}, created_at: nowIso(), decided_at: null, sent_at: null });
    return 1;
  }
  function evaluate(rule: GrowthState['rules'][number], dry: boolean): number {
    const c = rule.config as R;
    const t = today();
    const month = t.slice(0, 7);
    let n = 0;
    const leadOf = (rid: string) => L().leads.find((l) => l.restaurant_id === rid)?.id ?? null;
    const real = (r: R) => r && !r.is_demo;
    switch (rule.trigger_key) {
      case 'favorites_category_affinity': {
        const cat = c.category ?? 'sushi';
        const hasOffer = db().offers.some((o: R) => o.is_active && (!o.ends_at || ts(o.ends_at) > Date.now()) && catsOf(o.restaurant_id).includes(cat));
        if (!hasOffer) return 0;
        const byUser = new Map<string, number>();
        for (const f of db().favorites ?? []) if (catsOf(f.restaurant_id).includes(cat)) byUser.set(f.user_id, (byUser.get(f.user_id) ?? 0) + 1);
        for (const [uid, k] of byUser) {
          if (k < (c.min_favorites ?? 3)) continue;
          n += dry ? 1 : draft(rule, `${uid}:${month}`, uid, `Offerte ${db().categories.find((x: R) => x.slug === cat)?.name ?? cat} attive su AsiaFood`, 'Ci sono offerte attive nei locali della categoria che segui. Scoprile nella sezione Offerte.', '/offerte');
        }
        return n;
      }
      case 'abandoned_cart':
        for (const cart of a.carts()) {
          const age = Date.now() - ts(cart.updated_at);
          if (cart.status !== 'active' || !cart.user_id || age < (c.min_hours ?? 2) * 3_600_000 || age > (c.max_hours ?? 48) * 3_600_000) continue;
          if (a.orders().some((o) => o.user_id === cart.user_id && ts(o.created_at) > ts(cart.updated_at))) continue;
          n += dry ? 1 : draft(rule, `cart:${cart.user_id}:${cart.restaurant_id}`, cart.user_id, 'Il tuo carrello ti aspetta', `Hai lasciato dei piatti nel carrello di ${rest(cart.restaurant_id)?.name ?? 'un ristorante'}.`, '/carrello');
        }
        return n;
      case 'dormant_new_restaurants':
        for (const p of customers().filter((x: R) => x.city_id && !x.is_blocked)) {
          const last = lastLogin(p.id);
          if (!last || diffDays(t, last) < (c.min_days ?? 30) || diffDays(t, last) > (c.max_days ?? 90)) continue;
          const prov = cityOf(p.city_id)?.province_id;
          const fresh = db().restaurants.filter((r: R) => r.is_active && !r.is_demo && cityOf(r.city_id)?.province_id === prov && ts(r.created_at) > Date.now() - 30 * DAY).length;
          if (!fresh) continue;
          n += dry ? 1 : draft(rule, `dormant:${p.id}:${month}`, p.id, 'Nuovi ristoranti sono arrivati su AsiaFood', `${fresh} nuovi locali nella tua zona da scoprire.`, '/esplora');
        }
        return n;
      case 'profile_incomplete':
        for (const r of db().restaurants.filter((x: R) => x.owner_id && x.is_active && real(x))) {
          const sc = a.completion(r).score;
          const thr = Number(c.threshold ?? 60);
          if (!Number.isFinite(thr)) throw fail('Soglia non valida');
          if (sc >= thr) continue;
          n += dry ? 1 : crmTask(rule, `incomplete:${r.id}`, r.id, leadOf(r.id), `Aiutare «${r.name}» a completare il profilo (${sc}%)`, 'growth_incomplete');
        }
        return n;
      case 'trial_ending':
        for (const s of subs().filter((x) => x.status === 'trialing' && x.trial_end && ts(x.trial_end) > Date.now() && ts(x.trial_end) < Date.now() + (c.days ?? 3) * DAY)) {
          const r = rest(s.restaurant_id);
          if (!real(r)) continue;
          n += dry ? 1 : crmTask(rule, `trial:${r.id}:${dayOf(s.trial_end)}`, r.id, leadOf(r.id), `Prova di «${r.name}» in scadenza il ${dayOf(s.trial_end)}: follow-up`, 'trial_ending');
          if (!dry && c.notify_owner && r.owner_id && !s.trial_expiring_notified_at && !st().items.some((i) => i.dedupe_key === `notify:${r.id}:${dayOf(s.trial_end)}`)) {
            a.notify(r.owner_id, 'billing_trial_expiring', 'La prova gratuita sta per terminare', `La prova di ${r.name} termina il ${dayOf(s.trial_end)}. Nessun addebito automatico da AsiaFood.`, `/dashboard/restaurants/${r.id}/billing`);
            st().items.push({ id: uuid(), rule_id: rule.id, dedupe_key: `notify:${r.id}:${dayOf(s.trial_end)}`, status: 'sent', target_user_id: null, restaurant_id: r.id, title: 'Notifica prova in scadenza', body: null, link: null, payload: {}, created_at: nowIso(), decided_at: null, sent_at: nowIso() });
          }
        }
        return n;
      case 'payment_failed':
        for (const s of subs().filter((x) => ['past_due', 'unpaid'].includes(x.status))) {
          const r = rest(s.restaurant_id);
          if (!real(r)) continue;
          n += dry ? 1 : crmTask(rule, `payfail:${s.id}:${month}`, r.id, leadOf(r.id), `Pagamento non riuscito per «${r.name}»: offrire supporto`, 'payment_failed');
        }
        return n;
      case 'lead_no_reply':
        for (const l of L().leads.filter((x) => x.status === 'contacted' && x.kind === 'restaurant')) {
          const acts = L().activities.filter((x) => x.lead_id === l.id && ['call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'follow_up'].includes(x.type));
          if (!acts.length || acts.some((x) => x.outcome === 'replied')) continue;
          const lastC = acts.map((x) => x.created_at).sort().pop()!;
          if (ts(lastC) > Date.now() - (c.days ?? 4) * DAY) continue;
          n += dry ? 1 : crmTask(rule, `noreply:${l.id}:${dayOf(lastC)}`, l.restaurant_id, l.id, `Follow-up «${l.name}»: nessuna risposta da ${Math.floor((Date.now() - ts(lastC)) / DAY)} giorni`, 'followup_no_reply');
        }
        return n;
      case 'demo_completed':
        for (const d of L().activities.filter((x) => x.type === 'demo' && ts(x.created_at) > Date.now() - 7 * DAY && ['done', 'interested', null].includes(x.outcome as never))) {
          if (L().activities.some((x) => x.lead_id === d.lead_id && x.created_at > d.created_at)) continue;
          const l = L().leads.find((x) => x.id === d.lead_id);
          if (!l) continue;
          n += dry ? 1 : crmTask(rule, `demo:${l.id}:${dayOf(d.created_at)}`, l.restaurant_id, l.id, `Dopo la demo con «${l.name}»: link di rivendicazione o prova`, 'demo_next_step');
        }
        return n;
      case 'trial_midpoint':
        for (const tr of db().billing_trials ?? []) {
          const r = rest(tr.restaurant_id);
          if (!real(r) || tr.converted_at || !tr.ends_at || ts(tr.ends_at) < Date.now()) continue;
          if (Date.now() < ts(tr.started_at) + (ts(tr.ends_at) - ts(tr.started_at)) / 2) continue;
          n += dry ? 1 : crmTask(rule, `midtrial:${r.id}:${dayOf(tr.started_at)}`, r.id, leadOf(r.id), `Metà prova per «${r.name}»: condividere i dati di performance`, 'trial_midpoint');
        }
        return n;
      case 'subscription_ended':
        for (const s of subs().filter((x) => x.source === 'stripe' && x.paid_started_at && x.ended_at && ts(x.ended_at) > Date.now() - (c.days ?? 90) * DAY)) {
          const r = rest(s.restaurant_id);
          if (!real(r) || subs().some((x) => x.restaurant_id === r.id && ['active', 'trialing'].includes(x.status))) continue;
          n += dry ? 1 : crmTask(rule, `winback:${s.id}`, r.id, leadOf(r.id), `Win-back «${r.name}»: chiedere feedback (nessuna riattivazione senza consenso)`, 'winback');
        }
        return n;
      default:
        return -1;
    }
  }
  function runRule(id: string, trigger: 'schedule' | 'manual' | 'dry_run') {
    const ru = st().rules.find((x) => x.id === id);
    if (!ru) throw fail('Regola non trovata');
    const run: GrowthState['runs'][number] = { id: uuid(), rule_id: ru.id, trigger, status: 'running', records_affected: 0, started_at: nowIso(), completed_at: null, error: null };
    st().runs.unshift(run);
    if (trigger !== 'dry_run' && (st().kill_switch || !ru.enabled || ru.action === 'unavailable')) {
      Object.assign(run, { status: 'skipped', completed_at: nowIso(), error: ru.action === 'unavailable' ? 'Automazione non disponibile' : !ru.enabled ? 'Regola disattivata' : 'Kill switch attivo' });
      a.save();
      return { run_id: run.id, status: 'skipped' };
    }
    try {
      const n = evaluate(ru, trigger === 'dry_run');
      if (n < 0) {
        Object.assign(run, { status: 'skipped', completed_at: nowIso(), error: 'Trigger non disponibile' });
        return { run_id: run.id, status: 'skipped' };
      }
      Object.assign(run, { status: 'success', records_affected: n, completed_at: nowIso() });
      if (trigger !== 'dry_run') Object.assign(ru, { last_run_at: nowIso(), next_run_at: new Date(Date.now() + ru.interval_minutes * 60_000).toISOString(), failure_count: 0, last_error: null });
      a.save();
      return { run_id: run.id, status: 'success', records_affected: n, dry_run: trigger === 'dry_run' };
    } catch (e) {
      const msg = (e as Error).message.slice(0, 480);
      Object.assign(run, { status: 'failed', completed_at: nowIso(), error: msg });
      ru.failure_count++;
      Object.assign(ru, { last_error: msg, last_run_at: nowIso(), enabled: ru.failure_count >= 5 ? false : ru.enabled });
      a.save();
      return { run_id: run.id, status: 'failed', error: msg };
    }
  }

  // ─── Esperimenti (sulla tabella della Fase 12 in LaunchState) ───
  const expRow = (e: R): GrowthExperiment => {
    const meta = st().exp_meta[e.id] ?? { end_at: null, secondary_metrics: [], guardrail_area: 'none', review_approved_at: null, review_note: null, created_by: null };
    const vars = st().variants.filter((v) => v.experiment_id === e.id);
    return {
      ...e, ...meta, secondary_metrics: meta.secondary_metrics ?? [],
      allocations: e.variants.map((name: string) => ({ name, allocation: vars.find((v) => v.name === name)?.allocation ?? Math.floor(100 / e.variants.length) })),
      assignments: st().assignments.filter((x) => x.experiment_id === e.id).length, same_creator: meta.created_by === a.uid(),
    };
  };

  function perf(rid: string): RestaurantPerformance {
    const r = rest(rid);
    if (!r) throw fail('Ristorante non trovato');
    const t = today();
    const pick = (m: Map<string, R>) => {
      const x = m.get(rid);
      return { impressions: x?.impressions ?? 0, views: x?.views ?? 0, menu_views: (x?.menu_views ?? 0) + (x?.item_views ?? 0), calls: x?.calls ?? 0, whatsapp: x?.whatsapp ?? 0,
        directions: x?.directions ?? 0, bookings: x?.bookings ?? 0, orders: x?.orders ?? 0, coupon_redemptions: x?.coupon_redemptions ?? 0, revenue_cents: x?.revenue_cents ?? 0,
        reviews: x?.reviews ?? 0, favorites: x?.favorites ?? 0 };
    };
    const period = (k: number) => ({ current: pick(restMetrics(addDays(t, -(k - 1)), t)), previous: pick(restMetrics(addDays(t, -(2 * k - 1)), addDays(t, -k))), previous_complete: true });
    const items = db().menu_items.filter((i: R) => i.restaurant_id === rid);
    const since30 = Date.now() - 30 * DAY;
    const top = items.map((i: R) => ({
      id: i.id, name: i.name, has_image: !!i.image_url,
      views: events().filter((e) => e.restaurant_id === rid && e.event_type === 'menu_item_view' && (e as R).metadata?.item === i.id && ts(e.created_at) > since30).length,
      add_to_cart: events().filter((e) => e.restaurant_id === rid && e.event_type === 'add_to_cart' && (e as R).metadata?.item === i.id && ts(e.created_at) > since30).length,
      ordered: a.orders().filter((o) => o.restaurant_id === rid && paidOrder(o) && ts(o.paid_at) > since30).flatMap((o) => o.items ?? []).filter((x: R) => x.menu_item_id === i.id).reduce((s: number, x: R) => s + (x.quantity ?? 1), 0),
    })).sort((x: R, y: R) => y.views - x.views || x.name.localeCompare(y.name)).slice(0, 15);
    const cc = claims().filter((c) => c.restaurant_id === rid && ts(c.claimed_at) > Date.now() - 90 * DAY);
    const byCoupon = new Map<string, { title: string; redemptions: number; claims: number }>();
    for (const c of cc) {
      const cp = db().coupons.find((x: R) => x.id === c.coupon_id);
      const x = byCoupon.get(c.coupon_id) ?? { title: cp?.title ?? 'Coupon', redemptions: 0, claims: 0 };
      x.claims++;
      if (c.status === 'redeemed') x.redemptions++;
      byCoupon.set(c.coupon_id, x);
    }
    const best = [...byCoupon.values()].sort((x, y) => y.redemptions - x.redemptions || y.claims - x.claims)[0] ?? null;
    const users = new Map<string, number>();
    for (const x of reservations()) if (x.restaurant_id === rid && x.user_id && !['rejected', 'cancelled'].includes(x.status) && ts(x.created_at) > Date.now() - 90 * DAY) users.set(x.user_id, (users.get(x.user_id) ?? 0) + 1);
    for (const o of a.orders()) if (o.restaurant_id === rid && o.user_id && paidOrder(o) && ts(o.paid_at) > Date.now() - 90 * DAY) users.set(o.user_id, (users.get(o.user_id) ?? 0) + 1);
    const revs = a.reviews().filter((x) => x.restaurant_id === rid && x.status === 'published');
    return {
      restaurant: { id: r.id, name: r.name, slug: r.slug, plan: r.subscription_plan, has_cover: !!r.cover_url || db().restaurant_images.some((i: R) => i.restaurant_id === rid),
        has_reservation: (db().reservation_settings ?? []).some((s: R) => s.restaurant_id === rid && s.reservation_enabled),
        accepts_orders: (db().market?.order_settings ?? []).some((s: R) => s.restaurant_id === rid) },
      completion: a.completion(r),
      periods: { 7: period(7), 30: period(30) },
      menu: { items: items.length, with_image: items.filter((i: R) => i.image_url).length, top },
      offers_active: db().offers.filter((o: R) => o.restaurant_id === rid && o.is_active && (!o.ends_at || ts(o.ends_at) > Date.now())).length
        + db().coupons.filter((o: R) => o.restaurant_id === rid && o.is_active && (!o.valid_until || ts(o.valid_until) > Date.now())).length,
      best_offer: best,
      repeat_customers_90d: [...users.values()].filter((n) => n >= 2).length,
      reviews: { count: revs.length, avg: revs.length ? r1(revs.reduce((s, x) => s + x.rating_overall, 0) / revs.length) : null },
      freshness: nowIso(),
    };
  }

  const api: GrowthApi = {
    async overview(from, to, market) {
      admin();
      const days = diffDays(to, from) + 1;
      if (days < 1 || days > 401) throw fail('Intervallo non valido');
      const pto = addDays(from, -1);
      const pfrom = addDays(from, -days);
      const cur = totals(from, to, market);
      const prev = totals(pfrom, pto, market);
      const t = today();
      const ids = marketRestIds(market);
      const rs = db().restaurants.filter((r: R) => ids.has(r.id));
      const minS = minSample();
      const conv = conversions(cur, from, to, market);
      const acts = a.activityDays();
      const cohort = customers().filter((p: R) => ts(p.created_at) < Date.now() - 30 * DAY && ts(p.created_at) > Date.now() - 180 * DAY);
      const d30 = cohort.filter((p: R) => { const d0 = dayOf(p.created_at); return acts.some((x) => x.user_id === p.id && x.day > d0 && x.day <= addDays(d0, 30)); }).length;
      const series = Array.from({ length: days }, (_, i) => {
        const d = addDays(from, i);
        const x = totals(d, d, market);
        return { date: d, visits: x.visits, active_users: x.active_users ?? 0, new_users: x.new_users ?? 0, searches: x.searches, reservations: x.reservations, orders: x.orders, gmv_cents: x.gmv_cents, mrr_cents: 0 };
      });
      const quality = [] as { key: string; severity: 'info' | 'warning' | 'critical'; message: string }[];
      if (a.demoVisible()) quality.push({ key: 'demo_included', severity: 'warning', message: 'Le metriche includono i locali DEMO (show_demo_data attivo): non sono risultati reali.' });
      quality.push({ key: 'demo_live', severity: 'info', message: 'Modalità DEMO: gli aggregati sono calcolati al momento dai dati salvati in questo browser.' });
      return {
        range: { from, to, days, prev_from: pfrom, prev_to: pto }, market: market || null,
        current: { ...cur, conversions: conv }, previous: { ...prev, conversions: conversions(prev, pfrom, pto, market) },
        conversion_rate: cur.visits >= minS ? r1((conv * 100) / cur.visits) : null,
        state: {
          users_total: customers().length, users_today: new Set(acts.filter((x) => x.day === t).map((x) => x.user_id)).size,
          users_7d: new Set(acts.filter((x) => x.day > addDays(t, -7)).map((x) => x.user_id)).size, users_30d: new Set(acts.filter((x) => x.day > addDays(t, -30)).map((x) => x.user_id)).size,
          new_users_7d: customers().filter((p: R) => ts(p.created_at) > Date.now() - 7 * DAY).length,
          restaurants_active: rs.filter((r: R) => r.is_active).length, restaurants_claimed: rs.filter((r: R) => r.owner_id).length,
          restaurants_paying: new Set(subs().filter((s) => ids.has(s.restaurant_id) && payingSub(s)).map((s) => s.restaurant_id)).size,
          trials_active: subs().filter((s) => ids.has(s.restaurant_id) && s.status === 'trialing').length,
          trials_expiring_7d: subs().filter((s) => ids.has(s.restaurant_id) && s.status === 'trialing' && s.trial_end && ts(s.trial_end) > Date.now() && ts(s.trial_end) < Date.now() + 7 * DAY).length,
          mrr_cents: Math.round(subs().filter((s) => ids.has(s.restaurant_id) && s.source === 'stripe' && ['active', 'past_due'].includes(s.status)).reduce((x, s) => x + mrrOf(s), 0)),
          retention_d30: cohort.length >= minS ? r1((d30 * 100) / cohort.length) : null,
        },
        series, freshness: { today_at: nowIso(), batch_at: nowIso() }, data_quality: quality, min_sample: minS, demo_included: a.demoVisible(),
      };
    },

    async funnels(from, to, market) {
      admin();
      const inP = (e: R) => e.session_id && inR(e.created_at, from, to);
      const ses = (list: R[]) => new Set(list.filter(inP).map((e) => e.session_id));
      const all = new Set([...ses(events()), ...ses(appEvents()), ...ses(st().search_events)]);
      const search = new Set([...ses(st().search_events), ...ses(appEvents().filter((e) => ['search', 'near_me_search', 'map_area_search'].includes(e.event_type)))]);
      const view = ses(events().filter((e) => ['restaurant_view', 'view'].includes(e.event_type)));
      const intent = new Set([...ses(events().filter((e) => ['directions_click', 'phone_click', 'whatsapp_click', 'menu_item_view', 'reservation_start', 'add_to_cart', 'checkout_started', 'offer_view'].includes(e.event_type))),
        ...ses(appEvents().filter((e) => e.event_type === 'favorite_added' || (e.event_type === 'conversion' && e.metadata?.kind === 'coupon_claimed')))]);
      const conv = new Set([...ses(appEvents().filter((e) => e.event_type === 'conversion' && ['reservation_completed', 'order_completed'].includes(e.metadata?.kind))),
        ...a.orders().filter((o) => o.session_id && inR(o.paid_at, from, to) && paidOrder(o)).map((o) => o.session_id)]);
      const win = Number(setting('growth_return_window_days'));
      const first = new Map<string, string>();
      for (const x of reservations()) if (x.user_id && inR(x.created_at, from, to) && x.status !== 'rejected') first.set(x.user_id, [first.get(x.user_id), x.created_at].filter(Boolean).sort()[0]!);
      for (const o of a.orders()) if (o.user_id && inR(o.paid_at, from, to) && paidOrder(o)) first.set(o.user_id, [first.get(o.user_id), o.paid_at].filter(Boolean).sort()[0]!);
      const returned = [...first].filter(([u, at]) => a.activityDays().some((x) => x.user_id === u && x.day > dayOf(at) && x.day <= addDays(dayOf(at), win))).length;
      const ids = marketRestIds(market);
      const leads = L().leads.filter((l) => l.kind === 'restaurant' && (!market || l.market_id === marketBySlug(market)?.id));
      const rankOf = (s: string) => ['new', 'researched', 'contacted', 'replied', 'demo_scheduled', 'demo_done', 'claim_sent', 'claimed', 'trial', 'activated', 'paid'].indexOf(s);
      const trials = (db().billing_trials ?? []).filter((t: R) => ids.has(t.restaurant_id));
      const vel = (pairs: [string | null | undefined, string | null | undefined][]) => {
        const ok = pairs.filter(([x, y]) => x && y && ts(y) >= ts(x));
        return { avg_days: ok.length ? r1(ok.reduce((s, [x, y]) => s + (ts(y) - ts(x)) / DAY, 0) / ok.length) : null, n: ok.length };
      };
      return {
        consumer: [{ key: 'visit', label: 'Visita (sessione)', value: all.size }, { key: 'search', label: 'Ricerca', value: [...search].filter((s) => all.has(s)).length },
          { key: 'view', label: 'Scheda ristorante', value: view.size }, { key: 'intent', label: 'Intenzione', value: intent.size }, { key: 'conversion', label: 'Conversione', value: conv.size }],
        return: { window_days: win, converted_users: first.size, returned_users: returned, window_open: [...first.values()].filter((at) => ts(at) > Date.now() - win * DAY).length },
        b2b: [
          { key: 'discovered', label: 'Ristoranti censiti', value: db().restaurants.filter((r: R) => ids.has(r.id) && r.is_active).length },
          { key: 'lead', label: 'Lead CRM', value: leads.length },
          { key: 'contacted', label: 'Contattati', value: leads.filter((l) => rankOf(l.status) >= 2).length },
          { key: 'replied', label: 'Hanno risposto', value: leads.filter((l) => rankOf(l.status) >= 3).length },
          { key: 'claimed', label: 'Rivendicati', value: db().restaurants.filter((r: R) => ids.has(r.id) && r.owner_id).length },
          { key: 'trial', label: 'Prova avviata', value: trials.length },
          { key: 'activated', label: 'Attivati', value: db().restaurants.filter((r: R) => ids.has(r.id) && r.owner_id && a.completion(r).score >= 70).length },
          { key: 'paid', label: 'Paganti (almeno una volta)', value: new Set(subs().filter((s) => ids.has(s.restaurant_id) && s.paid_started_at && s.source === 'stripe').map((s) => s.restaurant_id)).size },
          { key: 'retained', label: 'Ancora paganti dopo 30 giorni', value: new Set(subs().filter((s) => ids.has(s.restaurant_id) && payingSub(s) && ts(s.paid_started_at) < Date.now() - 30 * DAY).map((s) => s.restaurant_id)).size },
        ],
        velocity: {
          lead_to_contact: vel(leads.map((l) => [l.created_at, L().activities.filter((x) => x.lead_id === l.id && ['call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'demo', 'claim_link_sent', 'follow_up'].includes(x.type)).map((x) => x.created_at).sort()[0]])),
          lead_to_claim: vel(leads.map((l) => [l.created_at, rest(l.restaurant_id)?.claimed_at])),
          claim_to_trial: vel(trials.map((t: R) => [rest(t.restaurant_id)?.claimed_at, t.started_at])),
          trial_to_paid: vel(trials.map((t: R) => [t.started_at, subs().filter((s) => s.restaurant_id === t.restaurant_id && s.paid_started_at).map((s) => s.paid_started_at).sort()[0]])),
        },
        min_sample: minSample(), directions_as_conversion: setting<boolean>('growth_directions_as_conversion'),
        definitions: {
          unit: 'Sessioni con consenso "Statistiche" (le visite senza consenso non sono collegabili tra loro).',
          intent: 'Indicazioni, chiamata, WhatsApp, piatto aperto, prenotazione iniziata, carrello/checkout, offerta vista, preferito, coupon richiesto.',
          conversion: 'Prenotazione inviata o ordine pagato.', return: `Utente registrato con una conversione che ha un giorno di attività nei ${win} giorni successivi.`,
        },
      };
    },

    async retention(weeks = 8) {
      admin();
      const t = today();
      const acts = a.activityDays();
      const us = customers().filter((p: R) => ts(p.created_at) > Date.now() - 180 * DAY).map((p: R) => ({ id: p.id, d0: dayOf(p.created_at) }));
      const back = (u: { id: string; d0: string }, lo: number, hi: number) => acts.some((x) => x.user_id === u.id && x.day >= addDays(u.d0, lo) && x.day <= addDays(u.d0, hi));
      const pt = (n: number, lo: number) => { const el = us.filter((u) => u.d0 <= addDays(t, -n)); return { eligible: el.length, returned: el.filter((u) => back(u, lo, n)).length }; };
      const monday = (d: string) => addDays(d, -((new Date(`${d}T12:00:00Z`).getUTCDay() + 6) % 7));
      const all = customers().map((p: R) => ({ id: p.id, d0: dayOf(p.created_at), ws: monday(dayOf(p.created_at)) }));
      const w = Math.min(Math.max(weeks, 1), 26);
      const cohorts = Array.from({ length: w }, (_, i) => addDays(monday(t), -7 * i)).map((ws) => ({
        week: ws, size: all.filter((u) => u.ws === ws).length,
        weeks: [0, 1, 2, 3, 4].map((k) => (addDays(ws, 7 * k) > t ? null : all.filter((u) => u.ws === ws && acts.some((x) => x.user_id === u.id && x.day > u.d0 && x.day >= addDays(ws, 7 * k) && x.day <= addDays(ws, 7 * k + 6))).length)),
      }));
      const trials = (db().billing_trials ?? []).filter((x: R) => inScope(rest(x.restaurant_id)));
      const paid = subs().filter((s) => s.source === 'stripe' && s.paid_started_at && inScope(rest(s.restaurant_id)));
      const alive = (s: R, d: number) => !s.ended_at || ts(s.ended_at) > ts(s.paid_started_at) + d * DAY;
      return {
        users: { d1: pt(1, 1), d7: pt(7, 1), d30: pt(30, 1) }, cohorts,
        restaurants: {
          trial_to_paid: { ended: trials.filter((x: R) => ts(x.ends_at) <= Date.now() || x.converted_at).length, converted: trials.filter((x: R) => x.converted_at).length },
          paid_m1_m2: { base: paid.filter((s) => ts(s.paid_started_at) < Date.now() - 60 * DAY && alive(s, 30)).length, retained: paid.filter((s) => ts(s.paid_started_at) < Date.now() - 60 * DAY && alive(s, 60)).length },
          paid_m2_m3: { base: paid.filter((s) => ts(s.paid_started_at) < Date.now() - 90 * DAY && alive(s, 60)).length, retained: paid.filter((s) => ts(s.paid_started_at) < Date.now() - 90 * DAY && alive(s, 90)).length },
        },
        min_sample: minSample(),
        definitions: {
          return: 'Un utente registrato "torna" se ha un giorno di attività (accesso all\'app) dopo il giorno di registrazione.',
          d1: 'Attivo il giorno successivo alla registrazione.', d7: 'Attivo almeno un giorno entro 7 giorni.', d30: 'Attivo almeno un giorno entro 30 giorni.',
          cohort: 'Righe = settimana di registrazione (lunedì). Colonne = settimana 0…4: utenti attivi in quella settimana (esclusa la giornata di registrazione). Celle vuote = settimana non ancora conclusa.',
          restaurant: 'Trial → pagante sulle prove concluse. M1→M2: abbonamenti paganti ancora attivi a 60 giorni tra quelli attivi a 30 giorni.',
        },
      };
    },

    async restaurants(p) {
      admin();
      const m = restMetrics(p.from, p.to);
      const ids = marketRestIds(p.market);
      let rows = db().restaurants.filter((r: R) => ids.has(r.id) && r.is_active && (!p.search || r.name.toLowerCase().includes(p.search.toLowerCase()))).map((r: R) => {
        const x = m.get(r.id) ?? {};
        const g = (k: string) => x[k] ?? 0;
        const actions = g('directions') + g('calls') + g('whatsapp') + g('bookings') + g('orders') + g('coupon_redemptions');
        const users = new Map<string, number>();
        for (const v of reservations()) if (v.restaurant_id === r.id && v.user_id && !['rejected', 'cancelled'].includes(v.status)) users.set(v.user_id, (users.get(v.user_id) ?? 0) + 1);
        return {
          id: r.id, name: r.name, slug: r.slug, city: cityOf(r.city_id)?.name ?? '', subscription_plan: r.subscription_plan, claimed: !!r.owner_id,
          impressions: g('impressions'), views: g('views'), menu_views: g('menu_views') + g('item_views'), directions: g('directions'), calls: g('calls'), whatsapp: g('whatsapp'),
          bookings: g('bookings'), orders: g('orders'), coupon_redemptions: g('coupon_redemptions'), reviews: g('reviews'), revenue_cents: g('revenue_cents'),
          repeat_customers: [...users.values()].filter((n) => n >= 2).length, conversion_actions: actions, conversion_rate: g('views') > 0 ? r1((actions * 100) / g('views')) : null, health: health(r.id),
        };
      });
      if (p.status) rows = rows.filter((x: R) => x.health.status === p.status);
      rows.sort((x: R, y: R) => Number(y.health.status === 'at_risk') - Number(x.health.status === 'at_risk') || y.views - x.views || x.name.localeCompare(y.name));
      const off = p.offset ?? 0;
      return {
        total: rows.length, rows: rows.slice(off, off + Math.min(p.limit ?? 50, 200)),
        definitions: { conversion: 'Azioni di conversione (indicazioni + chiamate + WhatsApp + prenotazioni + ordini + coupon utilizzati) / visualizzazioni della scheda.',
          health: 'Punteggio interno 0–100 di salute commerciale del rapporto (completezza, accessi, menu, gestione prenotazioni/ordini, offerte, azioni clienti, abbonamento). Non è un giudizio sulla qualità del ristorante.' },
      };
    },

    async churn(from, to) {
      admin();
      const f = Date.parse(`${from}T00:00:00`);
      const tt = Date.parse(`${to}T23:59:59`);
      const paid = subs().filter((s) => s.source === 'stripe' && s.paid_started_at && inScope(rest(s.restaurant_id)));
      const base = new Set(paid.filter((s) => ts(s.paid_started_at) < f && (!s.ended_at || ts(s.ended_at) >= f)).map((s) => s.restaurant_id));
      const lost = new Set(paid.filter((s) => base.has(s.restaurant_id) && s.ended_at && ts(s.ended_at) >= f && ts(s.ended_at) <= tt).map((s) => s.restaurant_id));
      const row = (s: R) => ({ restaurant_id: s.restaurant_id, name: rest(s.restaurant_id)?.name ?? '', plan: s.plan_code, mrr_cents: Math.round(mrrOf(s)) });
      const reasons = new Map<string, number>();
      for (const fb of L().feedback.filter((x) => x.type === 'cancellation' && inR(x.created_at, from, to))) {
        const k = churnReason(fb.reason);
        reasons.set(k, (reasons.get(k) ?? 0) + 1);
      }
      return {
        churn: { base: base.size, lost: lost.size, rate: base.size ? r1((lost.size * 100) / base.size) : null },
        mrr: { new_mrr_cents: Math.round(paid.filter((s) => inR(s.paid_started_at, from, to)).reduce((x, s) => x + mrrOf(s), 0)),
          churned_mrr_cents: Math.round(paid.filter((s) => inR(s.ended_at, from, to)).reduce((x, s) => x + mrrOf(s), 0)),
          expansion_mrr_cents: null, contraction_mrr_cents: null, expansion_available: false,
          note: 'Espansione/contrazione richiedono fotografie MRR giornaliere osservate: non disponibili in modalità DEMO.' },
        lists: {
          cancelled: paid.filter((s) => inR(s.ended_at, from, to)).map((s) => ({ ...row(s), ended_at: s.ended_at })),
          cancel_scheduled: subs().filter((s) => s.cancel_at_period_end && ['active', 'trialing', 'past_due'].includes(s.status)).map((s) => ({ ...row(s), until: s.current_period_end })),
          past_due: subs().filter((s) => ['past_due', 'unpaid'].includes(s.status)).map((s) => ({ ...row(s), since: s.payment_failed_at ?? null })),
          inactive_trials: subs().filter((s) => s.status === 'trialing' && inScope(rest(s.restaurant_id)) && !a.activityDays().some((x) => x.user_id === rest(s.restaurant_id)?.owner_id && x.day > addDays(today(), -7)))
            .map((s) => ({ restaurant_id: s.restaurant_id, name: rest(s.restaurant_id)?.name ?? '', trial_end: s.trial_end, last_login: lastLogin(rest(s.restaurant_id)?.owner_id) })),
          at_risk: db().restaurants.filter((r: R) => inScope(r) && r.owner_id && subs().some((s) => s.restaurant_id === r.id && ['active', 'trialing', 'past_due'].includes(s.status)))
            .map((r: R) => ({ restaurant_id: r.id, name: r.name, health: health(r.id) })).filter((x: R) => x.health.status === 'at_risk'),
        },
        reasons: [...reasons].map(([reason, count]) => ({ reason, count })).sort((x, y) => y.count - x.count),
        definitions: { churn_rate: 'Ristoranti paganti persi nel periodo / ristoranti paganti all\'inizio del periodo.', reasons: 'Motivo facoltativo indicato alla disdetta (mai obbligatorio). "unknown" = nessun motivo indicato.' },
      };
    },

    async revenue(from, to) {
      admin();
      const paying = subs().filter((s) => payingSub(s) && inScope(rest(s.restaurant_id)));
      const mrr = Math.round(paying.reduce((x, s) => x + mrrOf(s), 0));
      const n = new Set(paying.map((s) => s.restaurant_id)).size;
      const tot = totals(from, to);
      const churn = await api.churn(from, to);
      const months = new Set(subs().filter((s) => s.source === 'stripe' && s.paid_started_at).map((s) => String(s.paid_started_at).slice(0, 7))).size;
      const sponsor = Math.round((db().sponsored_campaigns ?? []).filter((c: R) => inScope(rest(c.restaurant_id)) && c.start_date <= to && (!c.end_date || c.end_date >= from)).reduce((s: number, c: R) => s + Number(c.spend ?? 0), 0) * 100);
      return {
        mrr_cents: mrr, arr_cents: mrr * 12, paying_restaurants: n, arpa_cents: n ? Math.round(mrr / n) : null, movements: churn.mrr,
        sources: [
          { key: 'subscriptions', label: 'Abbonamenti (fatture pagate)', cents: tot.subscription_revenue_cents ?? 0 },
          { key: 'orders', label: 'Commissioni e costi di servizio ordini', cents: tot.order_fees_cents ?? 0 },
          { key: 'ads', label: 'Sponsorizzazioni (spesa registrata delle campagne attive nel periodo, cumulativa)', cents: sponsor },
          { key: 'other', label: 'Altro', cents: 0 },
        ],
        gmv_cents: tot.gmv_cents, ltv_cents: null,
        ltv_reason: months < 3 ? 'Dati insufficienti: servono almeno 3 mesi di abbonamenti paganti.' : `Dati insufficienti: base paganti < ${minSample()} o nessuna disdetta osservata (il churn non è stimabile).`,
        mrr_series: [], complete: true,
        definitions: { arpa: 'MRR / ristoranti paganti (solo paganti).', ltv: 'ARPA / churn mensile medio (ultimi 90 giorni), solo con storico sufficiente.', mrr: 'Somma dei canoni mensili degli abbonamenti Stripe attivi (annuali /12).' },
      };
    },

    async acquisition(from, to) {
      admin();
      const minC = Number(setting('cac_min_conversions'));
      const ch = new Map<string, R>();
      const get = (k: string) => {
        let x = ch.get(k);
        if (!x) { x = { channel: k, visits: 0, signups: 0, activated: 0, reservations: 0, orders: 0, paying_restaurants: 0, cost_cents: null, cac_cents: null, cac_reason: null }; ch.set(k, x); }
        return x;
      };
      for (const v of L().visits.filter((x) => inR(x.created_at, from, to))) get(growthChannel(v.channel, v.utm_source)).visits++;
      const ua = L().user_acquisition.filter((u) => inR(db().profiles.find((p: R) => p.id === u.user_id)?.created_at, from, to));
      for (const u of ua) {
        const x = get(growthChannel(u.channel, u.utm_source));
        x.signups++;
        const res = reservations().filter((r) => r.user_id === u.user_id && r.status !== 'rejected');
        const ord = a.orders().filter((o) => o.user_id === u.user_id && paidOrder(o));
        if (res.length || ord.length || claims().some((c) => c.user_id === u.user_id)) x.activated++;
        x.reservations += res.filter((r) => inR(r.created_at, from, to)).length;
        x.orders += ord.filter((o) => inR(o.paid_at, from, to)).length;
      }
      const business = ['organic_google', 'direct', 'instagram', 'facebook', 'tiktok', 'restaurant_qr', 'referral', 'creator', 'paid_social', 'partner', 'email', 'other_social', 'other'];
      for (const c of L().costs.filter((x) => x.spent_on >= from && x.spent_on <= to)) {
        const k = business.includes((c.channel ?? '').toLowerCase()) ? (c.channel ?? '').toLowerCase() : growthChannel((c.channel ?? 'other').toLowerCase(), (c.channel ?? '').toLowerCase());
        const x = get(k);
        x.cost_cents = (x.cost_cents ?? 0) + c.amount_cents;
      }
      for (const x of ch.values()) {
        if (x.cost_cents && x.signups >= minC) x.cac_cents = Math.round(x.cost_cents / x.signups);
        else x.cac_reason = !x.cost_cents ? 'N/A: nessun costo registrato' : `N/A: meno di ${minC} iscrizioni attribuite`;
      }
      const camp = new Map<string, R>();
      for (const v of L().visits.filter((x) => inR(x.created_at, from, to) && (x.utm_source || x.utm_campaign))) {
        const k = `${v.utm_source ?? ''}|${v.utm_campaign ?? ''}`;
        const x = camp.get(k) ?? { utm_source: v.utm_source ?? '', utm_campaign: v.utm_campaign ?? '', visits: 0, signups: 0 };
        x.visits++;
        camp.set(k, x);
      }
      const last = new Map<string, number>();
      for (const u of ua) { const k = growthChannel((u as R).last_channel ?? u.channel, (u as R).last_utm_source ?? u.utm_source); last.set(k, (last.get(k) ?? 0) + 1); }
      return {
        channels: [...ch.values()].sort((x, y) => y.visits - x.visits), campaigns: [...camp.values()].sort((x, y) => y.visits - x.visits).slice(0, 30),
        last_touch: [...last].map(([channel, signups]) => ({ channel, signups })).sort((x, y) => y.signups - x.signups),
        coverage: { signups_total: customers().filter((p: R) => inR(p.created_at, from, to)).length, signups_attributed: ua.length },
        definitions: { model: 'First touch = primo canale noto del browser (con consenso) · Last touch = canale della sessione di iscrizione. Nessun modello multi-touch.',
          cac: `Costo registrato del canale / iscrizioni attribuite, solo con almeno ${minC} iscrizioni e costi reali inseriti.`,
          activated: 'Utenti iscritti nel periodo con almeno una prenotazione, un ordine pagato o un coupon richiesto.' },
      };
    },

    async search(from, to, market) {
      admin();
      const ss = searchesIn(from, to, market);
      const agg = new Map<string, R>();
      for (const s of ss) {
        const k = `${s.query_norm ?? ''}|${s.city_slug ?? ''}|${s.category_slug ?? ''}`;
        const x = agg.get(k) ?? { query: s.query_norm, city_slug: s.city_slug, category_slug: s.category_slug, searches: 0, zero_results: 0, sess: new Set<string>(), ai_searches: 0, with_session: 0, converted: 0, rep: new Map<string, number>() };
        x.searches++;
        if (s.result_count === 0) x.zero_results++;
        if (s.source === 'ai') x.ai_searches++;
        if (s.session_id) {
          x.sess.add(s.session_id);
          x.rep.set(s.session_id, (x.rep.get(s.session_id) ?? 0) + 1);
          x.with_session++;
          if (events().some((e) => e.session_id === s.session_id && ['restaurant_view', 'view'].includes(e.event_type) && ts(e.created_at) >= ts(s.created_at) && ts(e.created_at) <= ts(s.created_at) + 1_800_000)) x.converted++;
        }
        agg.set(k, x);
      }
      const max = Math.max(1, ...[...agg.values()].map((x) => x.searches));
      const top = [...agg.values()].sort((x, y) => y.searches - x.searches).slice(0, 50).map((x) => ({
        query: x.query, city_slug: x.city_slug, category_slug: x.category_slug, city: db().cities.find((c: R) => c.slug === x.city_slug)?.name ?? null,
        category: db().categories.find((c: R) => c.slug === x.category_slug)?.name ?? null, searches: x.searches, zero_results: x.zero_results, sessions: x.sess.size, ai_searches: x.ai_searches,
        converted: x.with_session ? x.converted : null, with_session: x.with_session || null,
        demand_score: searchDemandScore(x.searches, max, x.zero_results / x.searches, x.sess.size ? [...x.rep.values()].filter((n: number) => n > 1).length / x.sess.size : null, x.with_session ? 1 - x.converted / x.with_session : null),
      }));
      const group = (key: 'category_slug' | 'city_slug', list: 'categories' | 'cities') => {
        const g = new Map<string, { searches: number; zero_results: number }>();
        for (const s of ss) { const k = s[key]; if (!k) continue; const x = g.get(k) ?? { searches: 0, zero_results: 0 }; x.searches++; if (!s.result_count) x.zero_results++; g.set(k, x); }
        return [...g].map(([slug, v]) => ({ slug, name: db()[list].find((c: R) => c.slug === slug)?.name ?? null, ...v })).sort((x, y) => y.searches - x.searches);
      };
      const withSes = ss.filter((s) => s.session_id);
      return {
        totals: { searches: ss.length, zero_results: ss.filter((s) => !s.result_count).length, ai_searches: ss.filter((s) => s.source === 'ai').length },
        top, zero_results: top.filter((x) => x.zero_results > 0).sort((x, y) => y.zero_results - x.zero_results),
        categories: group('category_slug', 'categories'), cities: group('city_slug', 'cities'),
        conversion: { with_session: withSes.length, converted: top.reduce((s, x) => s + (x.converted ?? 0), 0) },
        supply_gap: supplyGap(from, to, market), min_sample: minSample(),
        definitions: {
          zero_result: 'Ricerca con 0 risultati mostrati all\'utente (Esplora) o 0 ristoranti proposti dall\'assistente AI.',
          converted: 'Ricerca seguita, nella stessa sessione con consenso, dall\'apertura di una scheda ristorante entro 30 minuti.',
          demand_score: 'Punteggio 0–100 = volume (40, logaritmico) + quota senza risultati (30) + sessioni che ripetono la ricerca (15) + ricerche non seguite da una scheda (15).',
          supply_gap: 'Combinazioni comune/categoria (o termine) con almeno growth_supply_gap_min_searches ricerche. Punteggio = domanda (40) + quota senza risultati (40) + offerta scarsa (20).',
          privacy: 'Testo normalizzato; ricerche con email, numeri lunghi o link non vengono salvate. Nessun utente associato.',
        },
      };
    },

    async engagement(from, to) {
      admin();
      const minS = minSample();
      const ai = a.aiUsage().filter((u) => inR(u.created_at, from, to));
      const aiBookings = reservations().filter((r) => r.source === 'ai' && inR(r.created_at, from, to)).length;
      const aiOrders = a.orders().filter((o) => o.source === 'ai' && inR(o.paid_at, from, to) && paidOrder(o)).length;
      const intents = new Map<string, number>();
      for (const u of ai.filter((x) => ['ok', 'fallback', 'cached'].includes(x.status))) intents.set(u.intent ?? 'sconosciuto', (intents.get(u.intent ?? 'sconosciuto') ?? 0) + 1);
      const noRes = new Map<string, R>();
      for (const u of ai.filter((x) => x.no_results && (x.search_city || x.search_category || x.search_term))) {
        const k = `${u.search_city}|${u.search_category}|${u.search_term}`;
        const x = noRes.get(k) ?? { city: u.search_city ?? null, category: u.search_category ?? null, term: u.search_term ?? null, count: 0 };
        x.count++;
        noRes.set(k, x);
      }
      const ev = (t: string) => events().filter((e) => e.event_type === t && inR(e.created_at, from, to)).length;
      const coupons = db().coupons.filter((c: R) => inScope(rest(c.restaurant_id))).map((c: R) => ({
        id: c.id, title: c.title, restaurant: rest(c.restaurant_id)?.name ?? '', discount_type: c.discount_type,
        claims: claims().filter((x) => x.coupon_id === c.id && inR(x.claimed_at, from, to)).length, redemptions: claims().filter((x) => x.coupon_id === c.id && x.status === 'redeemed' && inR(x.redeemed_at, from, to)).length,
        orders: a.orders().filter((o) => o.coupon_id === c.id && inR(o.paid_at, from, to) && paidOrder(o)).length,
      })).filter((x: R) => x.claims || x.redemptions).sort((x: R, y: R) => y.redemptions - x.redemptions || y.claims - x.claims);
      const byType = new Map<string, R>();
      for (const c of claims().filter((x) => inR(x.claimed_at, from, to))) {
        const t = db().coupons.find((x: R) => x.id === c.coupon_id)?.discount_type ?? 'other';
        const x = byType.get(t) ?? { discount_type: t, claims: 0, redemptions: 0 };
        x.claims++;
        if (c.status === 'redeemed') x.redemptions++;
        byType.set(t, x);
      }
      const itemViews = new Map<string, number>();
      for (const e of events().filter((x) => x.event_type === 'menu_item_view' && inR(x.created_at, from, to) && (x as R).metadata?.item)) itemViews.set((e as R).metadata.item, (itemViews.get((e as R).metadata.item) ?? 0) + 1);
      const items = [...itemViews].sort((x, y) => y[1] - x[1]).slice(0, 30).map(([id, views]) => {
        const mi = db().menu_items.find((i: R) => i.id === id);
        const ordered = a.orders().filter((o) => inR(o.paid_at, from, to) && paidOrder(o)).flatMap((o) => o.items ?? []).filter((x: R) => x.menu_item_id === id).reduce((s: number, x: R) => s + (x.quantity ?? 1), 0);
        return { id, name: mi?.name ?? '—', restaurant: rest(mi?.restaurant_id)?.name ?? '', views, add_to_cart: events().filter((e) => e.event_type === 'add_to_cart' && (e as R).metadata?.item === id && inR(e.created_at, from, to)).length,
          ordered, order_rate: views >= minS ? r1((ordered * 100) / views) : null };
      }).filter((x) => x.name !== '—');
      const terms = new Map<string, R>();
      for (const s of searchesIn(from, to).filter((x) => x.query_norm && !x.category_slug)) {
        const x = terms.get(s.query_norm!) ?? { term: s.query_norm, searches: 0, zero_results: 0 };
        x.searches++;
        if (!s.result_count) x.zero_results++;
        terms.set(s.query_norm!, x);
      }
      const reg = a.referrals().filter((r) => inR(r.registered_at, from, to)).length;
      const newUsers = customers().filter((p: R) => inR(p.created_at, from, to)).length;
      const rv = a.reviews().filter((x) => inR(x.created_at, from, to));
      const win = Number(setting('growth_return_window_days'));
      const back = rv.filter((x) => a.activityDays().some((d) => d.user_id === x.user_id && d.day > dayOf(x.created_at) && d.day <= addDays(dayOf(x.created_at), win))).length;
      const repeat = new Map<string, number>();
      for (const x of reservations()) if (x.user_id && inR(x.created_at, from, to) && !['rejected', 'cancelled'].includes(x.status)) repeat.set(x.user_id, (repeat.get(x.user_id) ?? 0) + 1);
      for (const o of a.orders()) if (o.user_id && inR(o.paid_at, from, to) && paidOrder(o)) repeat.set(o.user_id, (repeat.get(o.user_id) ?? 0) + 1);
      const published = rv.filter((x) => x.status === 'published');
      return {
        offers: { views: ev('offer_view') + ev('coupon_reveal'), coupons, by_type: [...byType.values()].filter((x) => x.claims >= minS) },
        menu: { items, searched_terms: [...terms.values()].sort((x, y) => y.searches - x.searches).slice(0, 20) },
        ai: {
          queries: ai.filter((u) => ['ok', 'fallback', 'cached'].includes(u.status)).length, errors: ai.filter((u) => u.status === 'error').length,
          intents: [...intents].map(([intent, count]) => ({ intent, count })).sort((x, y) => y.count - x.count), result_clicks: ev('ai_result_click'), map_opens: ev('ai_map_open'),
          reservation_clicks: ev('ai_reservation_click'), bookings: aiBookings, orders: aiOrders, no_results: ai.filter((u) => u.no_results).length,
          no_result_top: [...noRes.values()].sort((x, y) => y.count - x.count).slice(0, 15), cost_cents: 0, cost_per_assisted_conversion_cents: null,
          note: 'Conversioni "assistite": prenotazioni/ordini con origine AI. Non è un ROI: l\'attribuzione non esclude che l\'utente avrebbe convertito comunque. In DEMO non c\'è costo reale del provider.',
        },
        referral: {
          shared: appEvents().filter((e) => e.event_type === 'referral_shared' && inR(e.created_at, from, to)).length, registered: reg,
          qualified: a.referrals().filter((r) => inR(r.qualified_at, from, to)).length,
          points_issued: a.loyaltyTx().filter((x) => x.type === 'referral' && x.points > 0 && inR(x.created_at, from, to)).reduce((s, x) => s + x.points, 0), point_value_cents: null,
          k_factor: newUsers >= minS && reg >= minS ? Math.round((reg / newUsers) * 100) / 100 : null,
          k_factor_note: 'Iscrizioni da invito / nuove iscrizioni del periodo (approssimazione del coefficiente virale). Nascosto con dati insufficienti.',
        },
        loyalty: {
          points_issued: a.loyaltyTx().filter((x) => x.points > 0 && ['earn', 'bonus', 'referral'].includes(x.type) && inR(x.created_at, from, to)).reduce((s, x) => s + x.points, 0),
          points_redeemed: -a.loyaltyTx().filter((x) => x.points < 0 && x.type === 'redeem' && inR(x.created_at, from, to)).reduce((s, x) => s + x.points, 0),
          outstanding: a.loyaltyAccounts().reduce((s, x) => s + (x.points_balance ?? 0), 0), reward_claims: a.rewardRedemptions().filter((x) => inR(x.created_at, from, to)).length,
          repeat_users: [...repeat.values()].filter((n) => n >= 2).length,
        },
        reviews: { new: rv.length, verified: rv.filter((x) => x.is_verified).length, avg_rating: published.length ? Math.round((published.reduce((s, x) => s + x.rating_overall, 0) / published.length) * 100) / 100 : null,
          responded: rv.filter((x) => (x.restaurant_response_count ?? 0) > 0 || x.response).length, reviewers_returned: back, reviewers: rv.length,
          note: 'Ritorno dei recensori: correlazione osservata, non un effetto causale della recensione.' },
        min_sample: minS,
      };
    },

    async voice(from, to) {
      admin();
      const fb = L().feedback.filter((f) => inR(f.created_at, from, to) && f.type !== 'nps');
      const cat = (f: R) => f.category ?? (f.type === 'bug' ? 'bug' : f.type === 'feature_request' ? 'feature_request' : f.type === 'cancellation' && churnReason(f.reason) === 'too_expensive' ? 'pricing'
        : f.type === 'cancellation' && churnReason(f.reason) === 'missing_feature' ? 'feature_request' : f.type === 'cancellation' && churnReason(f.reason) === 'too_complicated' ? 'ux' : 'uncategorized');
      const by = new Map<string, R[]>();
      for (const f of fb) by.set(cat(f), [...(by.get(cat(f)) ?? []), f]);
      const nps = L().feedback.filter((f) => f.type === 'nps' && inR(f.created_at, from, to));
      const tickets = a.supportTickets().filter((t) => inR(t.created_at, from, to));
      const byCat = new Map<string, number>();
      for (const t of tickets) byCat.set(t.category, (byCat.get(t.category) ?? 0) + 1);
      const res = tickets.filter((t) => t.resolved_at).map((t) => (ts(t.resolved_at) - ts(t.created_at)) / 3_600_000).sort((x, y) => x - y);
      return {
        feedback: {
          total: fb.length,
          by_category: [...by].map(([category, list]) => ({ category: category as never, count: list.length,
            recent: list.filter((f) => f.message).sort((x, y) => y.created_at.localeCompare(x.created_at)).slice(0, 5).map((f) => ({ id: f.id, message: (f.message ?? '').slice(0, 280), type: f.type, page: f.page, created_at: f.created_at })) })).sort((x, y) => y.count - x.count),
          nps: { responses: nps.length, promoters: nps.filter((f) => (f.rating ?? 0) >= 9).length, detractors: nps.filter((f) => (f.rating ?? 10) <= 6).length },
          summary_basis: 'Sintesi deterministica: conteggi per categoria e ultimi messaggi. Nessun tema generato automaticamente.',
        },
        support: {
          total: tickets.length, open: a.supportTickets().filter((t) => ['open', 'in_progress', 'waiting_customer'].includes(t.status)).length,
          reopened: tickets.reduce((s, t) => s + (t.reopened_count ?? 0), 0), median_resolution_hours: res.length ? r1(res[Math.floor(res.length / 2)]!) : null,
          by_category: [...byCat].map(([category, count]) => ({ category, count })).sort((x, y) => y.count - x.count),
          product_insights: [...byCat].filter(([, n]) => n >= 5).map(([category, count]) => ({ category, count, message: `${count} ticket "${category}" nel periodo: verificare se c'è un problema di prodotto ricorrente.` })),
          insight_threshold: 5,
        },
      };
    },
    async setFeedbackCategory(id, category) {
      admin();
      const f = L().feedback.find((x) => x.id === id) as R;
      if (f) f.category = category || null;
      a.save();
    },

    async segments() {
      admin();
      const t = today();
      const acts = a.activityDays();
      const us = customers().filter((p: R) => !p.is_blocked);
      const last = (id: string) => acts.filter((x) => x.user_id === id).map((x) => x.day).sort().pop() ?? null;
      const cnt = (pred: (p: R) => boolean) => { const l = us.filter(pred); return { count: l.length, marketing_consent: l.filter((p: R) => a.marketingOk(p.id)).length }; };
      const catCount = (uid: string, cat: string) => [...(db().favorites ?? []).filter((f: R) => f.user_id === uid), ...reservations().filter((x) => x.user_id === uid && !['rejected', 'cancelled'].includes(x.status)),
        ...a.orders().filter((o) => o.user_id === uid && paidOrder(o))].filter((x: R) => catsOf(x.restaurant_id).includes(cat)).length;
      const defs: [string, (p: R) => boolean][] = [
        ['new', (p) => ts(p.created_at) > Date.now() - 14 * DAY], ['active', (p) => (last(p.id) ?? '') >= addDays(t, -7)],
        ['returning', (p) => (last(p.id) ?? '') >= addDays(t, -30) && acts.some((x) => x.user_id === p.id && x.day >= addDays(t, -90) && x.day <= addDays(t, -31))],
        ['dormant', (p) => { const l = last(p.id); return !!l && l < addDays(t, -30) && l >= addDays(t, -180); }], ['sushi_lovers', (p) => catCount(p.id, 'sushi') >= 2],
        ['ayce_users', (p) => [...(db().favorites ?? []).filter((f: R) => f.user_id === p.id), ...reservations().filter((x) => x.user_id === p.id)].some((x: R) => rest(x.restaurant_id)?.is_all_you_can_eat)],
        ['offer_seekers', (p) => claims().filter((c) => c.user_id === p.id && ts(c.claimed_at) > Date.now() - 90 * DAY).length >= 2],
        ['order_users', (p) => a.orders().some((o) => o.user_id === p.id && paidOrder(o))], ['booking_users', (p) => reservations().some((x) => x.user_id === p.id)],
      ];
      const rs = db().restaurants.filter((r: R) => inScope(r) && r.is_active);
      const t30 = restMetrics(addDays(t, -29), t);
      return {
        customers: defs.map(([key, pred]) => ({ key, ...cnt(pred) })),
        restaurants: [
          { key: 'new_lead', count: L().leads.filter((l) => l.kind === 'restaurant' && ['new', 'researched'].includes(l.status)).length },
          { key: 'claimed', count: rs.filter((r: R) => r.owner_id && !subs().some((s) => s.restaurant_id === r.id)).length },
          { key: 'trial', count: rs.filter((r: R) => subs().some((s) => s.restaurant_id === r.id && s.status === 'trialing')).length },
          { key: 'activated', count: rs.filter((r: R) => r.owner_id && a.completion(r).score >= 70).length },
          { key: 'paid', count: rs.filter((r: R) => subs().some((s) => s.restaurant_id === r.id && payingSub(s))).length },
          { key: 'high_engagement', count: rs.filter((r: R) => { const x = t30.get(r.id); return x && x.calls + x.whatsapp + x.directions + x.bookings + x.orders + x.coupon_redemptions >= 20; }).length },
          { key: 'at_risk', count: rs.filter((r: R) => health(r.id).status === 'at_risk').length },
          { key: 'churned', count: rs.filter((r: R) => subs().some((s) => s.restaurant_id === r.id && s.paid_started_at && s.ended_at)).length },
        ],
        definitions: {
          new: 'Iscritti da ≤ 14 giorni', active: 'Attivi negli ultimi 7 giorni', returning: 'Attivi negli ultimi 30 giorni e anche tra 31 e 90 giorni fa', dormant: 'Ultima attività tra 30 e 180 giorni fa',
          sushi_lovers: 'Almeno 2 tra preferiti/prenotazioni/ordini in locali Sushi', ayce_users: 'Preferito o prenotazione in un locale All You Can Eat', offer_seekers: 'Almeno 2 coupon richiesti in 90 giorni',
          order_users: 'Almeno un ordine pagato', booking_users: 'Almeno una prenotazione', marketing_consent: 'Quanti nel segmento hanno scelto di ricevere comunicazioni promozionali (unici contattabili per marketing).',
        },
      };
    },

    async markets() {
      admin();
      const t = today();
      const rows = L().markets.map((m) => {
        const ids = marketRestIds(m.slug);
        const rs = db().restaurants.filter((r: R) => ids.has(r.id));
        const cur = totals(addDays(t, -29), t, m.slug);
        const prev = totals(addDays(t, -59), addDays(t, -30), m.slug);
        const prov = provinceByCode(m.province_code);
        return {
          id: m.id, slug: m.slug, name: m.name, status: m.status, restaurants: rs.filter((r: R) => r.is_active).length, claimed: rs.filter((r: R) => r.owner_id).length,
          paying: new Set(subs().filter((s) => ids.has(s.restaurant_id) && payingSub(s)).map((s) => s.restaurant_id)).size,
          users: customers().filter((p: R) => prov && cityOf(p.city_id)?.province_id === prov.id).length, searches_30d: cur.searches, zero_results_30d: cur.zero_result_searches,
          reservations_30d: cur.reservations, orders_30d: cur.orders, gmv_30d_cents: cur.gmv_cents,
          mrr_cents: Math.round(subs().filter((s) => ids.has(s.restaurant_id) && s.source === 'stripe' && ['active', 'past_due'].includes(s.status)).reduce((x, s) => x + mrrOf(s), 0)),
          supply_gaps: supplyGap(addDays(t, -29), t, m.slug).length, visits_30d: cur.visits, visits_prev_30d: prev.visits,
          traffic_growth_pct: prev.visits >= minSample() ? r1(((cur.visits - prev.visits) * 100) / prev.visits) : null, readiness: readiness(m.id),
        };
      });
      return { markets: rows, candidates: candidates(), weights: setting('growth_market_weights') };
    },
    async startResearch(slug) {
      admin();
      const c = st().candidates.find((x) => x.slug === slug);
      if (!c) throw fail('Città candidata non trovata');
      const prov = provinceByCode(c.province_code);
      if (!prov) throw fail(`La provincia ${c.province_code ?? '?'} non è presente nei dati di riferimento: aggiungila in "Città e territori" prima di avviare la ricerca.`);
      let m = L().markets.find((x) => x.province_code === c.province_code);
      if (!m) {
        m = { id: uuid(), slug: c.slug, name: c.name, province_code: c.province_code!, status: 'planned' as never, launched_at: null };
        L().markets.push(m);
      }
      const seed: [PlaybookItem['stage'], string, string][] = [
        ['research', 'Censire i ristoranti asiatici della provincia (fonti pubbliche)', 'Import con fonti verificabili (Importa). Nessun dato inventato.'],
        ['research', 'Analizzare la domanda di ricerca e le ricerche senza risultati', 'Growth → Ricerca, filtro sul mercato.'],
        ['data', 'Coordinate, orari e telefoni verificati per i locali censiti', 'Qualità dati ≥ 60% per almeno il 60% dei locali.'],
        ['data', 'Analisi copertura per comune e categoria', 'Growth → Supply gap.'],
        ['sales', 'Creare i lead CRM dai ristoranti censiti', 'CRM → "Crea lead dai ristoranti".'],
        ['sales', 'Primi 10 contatti con lo script del Sales Playbook', 'Solo contatti consentiti; registrare ogni attività.'],
        ['seo', 'Verificare pagine città/categoria indicizzabili (≥ 3 locali)', 'Sitemap generata solo per pagine con contenuto reale.'],
        ['partners', 'Individuare 3 partner locali (hotel, università, eventi)', 'CRM → Partner.'],
        ['beta_users', 'Invitare i primi utenti beta del territorio', 'beta_invite_only; nessuna campagna automatica.'],
        ['launch', 'Revisione go/no-go con i dati di readiness', 'Decisione umana. Il lancio non è mai automatico.'],
      ];
      let items = 0;
      seed.forEach(([stage, title, hint], i) => {
        if (st().playbook.some((x) => x.market_id === m!.id && x.stage === stage && x.title === title)) return;
        st().playbook.push({ id: uuid(), market_id: m!.id, stage, sort: i, title, hint, done_at: null });
        items++;
      });
      let tasks = 0;
      for (const [k, title, description] of [
        ['discovery', `Discovery: censire i ristoranti asiatici di ${c.name}`, 'Discovery Agent non disponibile (Fase 10 non implementata): attività manuale con fonti pubbliche verificabili.'],
        ['research', `Research: verificare dati e fonti dei locali di ${c.name}`, 'Research Agent non disponibile: verifica manuale (telefono, sito, social).'],
        ['leads', `Creare i lead CRM per ${c.name}`, 'Dopo il censimento: CRM → "Crea lead dai ristoranti".'],
        ['coverage', `Analisi copertura di ${c.name} (comuni × categorie)`, 'Confrontare con la domanda di ricerca reale.'],
        ['seo', `Preparazione SEO per ${c.name}`, 'Pagine città/categoria solo con contenuto reale; nessuna pagina vuota.'],
      ] as const) {
        const ref = `research:${c.slug}:${k}`;
        if (st().tasks.some((x) => x.status === 'open' && x.source === 'expansion' && x.source_ref === ref)) continue;
        st().tasks.push({ id: uuid(), market_id: m.id, market_slug: m.slug, title, description, source: 'expansion', source_ref: ref, priority: 'normal', status: 'open', due_at: null, created_at: nowIso(), done_at: null });
        tasks++;
      }
      Object.assign(c, { status: c.status === 'candidate' ? 'researching' : c.status, market_id: m.id, research_started_at: c.research_started_at ?? nowIso() });
      a.save();
      return { market_id: m.id, playbook_items: items, tasks };
    },
    async playbook(market) {
      admin();
      const m = marketBySlug(market);
      return { market_id: m?.id ?? null, readiness: readiness(m?.id ?? null), items: st().playbook.filter((i) => i.market_id === m?.id).sort((x, y) => x.sort - y.sort),
        learnings: st().learnings.filter((l) => l.market_id !== m?.id) };
    },
    async setPlaybookItem(id, done) {
      admin();
      const i = st().playbook.find((x) => x.id === id);
      if (i) i.done_at = done ? i.done_at ?? nowIso() : null;
      a.save();
    },
    async marketReview(market = 'taranto') {
      admin();
      const ov = await a.launchOverview(market);
      const m = marketBySlug(market)!;
      const ids = marketRestIds(market);
      const trials = (db().billing_trials ?? []).filter((t: R) => ids.has(t.restaurant_id));
      const prov = provinceByCode(m.province_code);
      const us = customers().filter((p: R) => prov && cityOf(p.city_id)?.province_id === prov.id && ts(p.created_at) < Date.now() - 30 * DAY);
      const pipeline: Record<string, number> = {};
      for (const l of L().leads.filter((x) => x.market_id === m.id && x.kind === 'restaurant')) pipeline[l.status] = (pipeline[l.status] ?? 0) + 1;
      return {
        market: { id: m.id, slug: m.slug, name: m.name, status: m.status },
        goals: ov.goals.map((g) => ({ metric_key: g.metric_key, target: g.target_value, actual: g.actual_value, gap: Math.max(g.target_value - (g.actual_value ?? 0), 0),
          pct: g.target_value > 0 ? Math.round(((g.actual_value ?? 0) * 100) / g.target_value) : null, status: g.status, period_start: g.period_start, period_end: g.period_end })),
        correlated: {
          pipeline, restaurants_indexed: ov.kpis.listed, restaurants_claimed: ov.kpis.claimed, restaurants_paying: ov.kpis.paying,
          trials: { started: trials.length, ended: trials.filter((t: R) => ts(t.ends_at) <= Date.now() || t.converted_at).length, converted: trials.filter((t: R) => t.converted_at).length },
          activated: db().restaurants.filter((r: R) => ids.has(r.id) && r.owner_id && a.completion(r).score >= 70).length,
          users_d30: { eligible: us.length, returned: us.filter((p: R) => a.activityDays().some((x) => x.user_id === p.id && x.day > dayOf(p.created_at) && x.day <= addDays(dayOf(p.created_at), 30))).length },
          conversions_30d: ov.kpis.food_connections_30d,
        },
        note: 'I dati correlati descrivono la situazione: non indicano la causa di un gap. Le cause vanno verificate (colloqui, feedback, test).',
      };
    },

    async alerts(status = 'open') {
      admin();
      const order = { critical: 0, warning: 1, info: 2 };
      return st().alerts.filter((x) => !status || x.status === status).sort((x, y) => order[x.severity] - order[y.severity] || y.last_seen_at.localeCompare(x.last_seen_at));
    },
    async setAlert(id, status) {
      admin();
      const x = st().alerts.find((al) => al.id === id);
      if (x) Object.assign(x, { status, resolved_at: status === 'resolved' ? nowIso() : null });
      a.save();
    },
    async refreshAlerts() {
      admin();
      return refreshAlerts();
    },

    async automationRules() {
      admin();
      return {
        kill_switch: st().kill_switch,
        rules: st().rules.map((r) => {
          const last = st().runs.find((x) => x.rule_id === r.id);
          return { ...r, owner_name: db().profiles.find((p: R) => p.id === r.owner_id)?.full_name ?? null, pending_items: st().items.filter((i) => i.rule_id === r.id && i.status === 'pending_approval').length,
            last_run: last ? { status: last.status, records_affected: last.records_affected, started_at: last.started_at, completed_at: last.completed_at, error: last.error } : null };
        }),
      };
    },
    async updateAutomationRule(id, patch) {
      admin();
      const r = st().rules.find((x) => x.id === id);
      if (!r) throw fail('Regola non trovata');
      if (patch.enabled && r.action === 'unavailable') throw fail('Automazione non disponibile: non può essere attivata');
      if (patch.config) for (const [k, v] of Object.entries(patch.config)) if (k in r.config) r.config[k] = v;
      if (patch.enabled !== undefined) {
        if (patch.enabled && !r.enabled) r.next_run_at = nowIso();
        if (patch.enabled) r.failure_count = 0;
        r.enabled = patch.enabled;
      }
      if (patch.interval_minutes) r.interval_minutes = patch.interval_minutes;
      if ('owner_id' in patch) r.owner_id = patch.owner_id ?? null;
      r.updated_at = nowIso();
      a.save();
    },
    async runAutomation(id, dryRun = false) {
      admin();
      return runRule(id, dryRun ? 'dry_run' : 'manual');
    },
    async setKillSwitch(on) {
      admin();
      st().kill_switch = on;
      a.save();
    },
    async automationRuns(ruleId) {
      admin();
      return st().runs.filter((x) => !ruleId || x.rule_id === ruleId).slice(0, 50).map((x) => ({ ...x, rule_name: st().rules.find((r) => r.id === x.rule_id)?.name ?? '' }));
    },
    async automationItems(status = 'pending_approval') {
      admin();
      return st().items.filter((i) => !status || i.status === status).slice().reverse().slice(0, 100).map(({ target_user_id, dedupe_key: _d, ...i }) => ({
        ...i, rule_name: st().rules.find((r) => r.id === i.rule_id)?.name ?? '', restaurant_name: rest(i.restaurant_id)?.name ?? null, has_recipient: !!target_user_id,
      }));
    },
    async decideAutomationItem(id, approve) {
      admin();
      const i = st().items.find((x) => x.id === id);
      if (!i || i.status !== 'pending_approval') throw fail('Elemento non in attesa di approvazione');
      Object.assign(i, { decided_at: nowIso() });
      if (!approve) { i.status = 'rejected'; a.save(); return 'rejected'; }
      if (!i.target_user_id || !a.marketingOk(i.target_user_id)) { i.status = 'skipped'; a.save(); return 'skipped_no_consent'; }
      a.notify(i.target_user_id, 'marketing_campaign', i.title, i.body ?? '', i.link);
      Object.assign(i, { status: 'sent', sent_at: nowIso() });
      a.save();
      return 'sent';
    },

    async experiments() {
      admin();
      return L().experiments.map(expRow).sort((x, y) => y.created_at.localeCompare(x.created_at));
    },
    async upsertExperiment(p) {
      admin();
      const vars = (p.variants as R[] | undefined)?.map((v: R) => (typeof v === 'string' ? { name: v, allocation: 0 } : v));
      if (vars && (vars.length < 2 || vars.length > 3)) throw fail('Servono 2 o 3 varianti');
      let alloc = vars?.map((v: R) => Number(v.allocation) || 0);
      if (alloc && alloc.reduce((s, x) => s + x, 0) === 0) alloc = alloc.map(() => Math.floor(100 / alloc!.length));
      if (alloc && ![100, Math.floor(100 / alloc.length) * alloc.length].includes(alloc.reduce((s, x) => s + x, 0))) throw fail('Le allocazioni devono sommare a 100');
      let e = L().experiments.find((x) => x.id === p.id);
      if (!e) {
        if (!/^[a-z0-9_]{3,40}$/.test(p.key ?? '')) throw fail('Chiave non valida');
        e = { id: uuid(), key: p.key!, name: p.name ?? p.key!, hypothesis: p.hypothesis ?? null, primary_metric: p.primary_metric ?? null, variants: vars?.map((v: R) => v.name) ?? ['control', 'variant_b'],
          status: 'draft', started_at: null, stopped_at: null, created_at: nowIso() };
        L().experiments.push(e);
        st().exp_meta[e.id] = { end_at: p.end_at ?? null, secondary_metrics: p.secondary_metrics ?? [], guardrail_area: p.guardrail_area ?? 'none', review_approved_at: null, review_note: null, created_by: a.uid() };
      } else {
        const meta = (st().exp_meta[e.id] ??= { end_at: null, secondary_metrics: [], guardrail_area: 'none', review_approved_at: null, review_note: null, created_by: null });
        Object.assign(e, { name: p.name ?? e.name, hypothesis: p.hypothesis ?? e.hypothesis });
        if (e.status === 'draft') {
          if (p.primary_metric) e.primary_metric = p.primary_metric;
          if (vars) e.variants = vars.map((v: R) => v.name);
          if (p.guardrail_area && p.guardrail_area !== meta.guardrail_area) Object.assign(meta, { guardrail_area: p.guardrail_area, review_approved_at: null });
        }
        if (p.secondary_metrics) meta.secondary_metrics = p.secondary_metrics;
        if ('end_at' in p) meta.end_at = p.end_at ?? null;
      }
      if (vars && e.status === 'draft') {
        st().variants = st().variants.filter((v) => v.experiment_id !== e!.id);
        vars.forEach((v: R, i: number) => st().variants.push({ experiment_id: e!.id, name: v.name, allocation: Math.max(1, alloc![i]!) }));
      }
      a.save();
      return e.id;
    },
    async setExperimentStatus(id, status) {
      admin();
      const e = L().experiments.find((x) => x.id === id);
      if (!e) throw fail('Esperimento non trovato');
      const meta = st().exp_meta[id];
      if (status === 'running' && meta && meta.guardrail_area !== 'none' && !meta.review_approved_at) throw fail(`Esperimento su area sensibile (${meta.guardrail_area}): serve la revisione di un secondo Admin prima dell'avvio`);
      if (status === 'running' && L().experiments.filter((x) => x.status === 'running' && x.id !== id).length >= 2) throw fail('Troppi esperimenti attivi: fermane uno prima di avviarne un altro');
      Object.assign(e, { status, started_at: status === 'running' ? e.started_at ?? nowIso() : e.started_at, stopped_at: status === 'stopped' ? nowIso() : null });
      a.save();
    },
    async reviewExperiment(id, note) {
      admin();
      const meta = st().exp_meta[id];
      if (!meta || meta.guardrail_area === 'none') throw fail('Nessuna revisione necessaria');
      if ((note ?? '').trim().length < 10) throw fail('Motiva la revisione (almeno 10 caratteri)');
      if (meta.created_by === a.uid()) throw fail('La revisione deve essere fatta da un Admin diverso da chi ha creato l\'esperimento');
      Object.assign(meta, { review_approved_at: nowIso(), review_note: note.slice(0, 500) });
      a.save();
    },
    async experimentReport(id): Promise<ExperimentReport> {
      admin();
      const e = L().experiments.find((x) => x.id === id);
      if (!e) throw fail('Esperimento non trovato');
      const row = expRow(e);
      return {
        experiment: row, min_sample: Number(setting('growth_experiment_min_sample')),
        variants: row.allocations.map((v) => ({ variant: v.name, allocation: v.allocation, users: st().assignments.filter((x) => x.experiment_id === id && x.variant === v.name).length,
          conversions: st().assignments.filter((x) => x.experiment_id === id && x.variant === v.name && x.converted_at).length })),
        exposures: appEvents().filter((x) => x.event_type === 'experiment_exposure' && x.metadata?.experiment === e.key).length,
      };
    },

    async reports() {
      admin();
      return st().reports.slice().sort((x, y) => y.period_end.localeCompare(x.period_end)).slice(0, 20);
    },
    async generateReport(type, from, to, market) {
      admin();
      const cur = totals(from, to, market);
      const days = diffDays(to, from) + 1;
      const prev = totals(addDays(from, -days), addDays(from, -1), market);
      const ids = marketRestIds(market);
      const paying = new Set(subs().filter((s) => ids.has(s.restaurant_id) && payingSub(s)).map((s) => s.restaurant_id)).size;
      const mrr = Math.round(subs().filter((s) => ids.has(s.restaurant_id) && s.source === 'stripe' && ['active', 'past_due'].includes(s.status)).reduce((x, s) => x + mrrOf(s), 0));
      const delta = prev.visits > 0 ? ` (${cur.visits >= prev.visits ? '+' : ''}${Math.round(((cur.visits - prev.visits) * 100) / prev.visits)}% sul periodo precedente)` : '';
      const fmt = (d: string) => d.split('-').reverse().join('/');
      const summary = [
        `Periodo ${fmt(from)} – ${fmt(to)}${market ? ` · mercato ${market}` : ''}.`,
        `Visite: ${cur.visits}${delta}. Nuovi utenti: ${cur.new_users ?? 'n/d'}. Utenti attivi: ${cur.active_users ?? 'n/d'}.`,
        `Ricerche: ${cur.searches}, di cui senza risultati: ${cur.zero_result_searches}.`,
        `Prenotazioni: ${cur.reservations}. Ordini pagati: ${cur.orders}. Coupon utilizzati: ${cur.coupon_redemptions}.`,
        `Ristoranti paganti: ${paying}. MRR: € ${(mrr / 100).toLocaleString('it-IT', { minimumFractionDigits: 2 })}.`,
        a.demoVisible() ? 'I numeri includono i locali DEMO (ambiente non di produzione).' : null,
      ].filter(Boolean).join('\n');
      const metrics = { period: { from, to, market: market ?? null }, current: cur, previous: prev, restaurants: { paying }, revenue: { mrr_cents: mrr },
        top_searches: (await api.search(from, to, market)).top.slice(0, 10), supply_gaps: supplyGap(from, to, market).slice(0, 10),
        churn_risks: st().alerts.filter((x) => x.status !== 'resolved' && ['trial', 'billing', 'restaurant'].includes(x.category)).map((x) => ({ title: x.title, severity: x.severity })),
        next_actions: st().tasks.filter((x) => x.status === 'open').slice(0, 10).map((x) => ({ title: x.title, source: x.source })) };
      const existing = type !== 'custom' ? st().reports.find((r) => r.report_type === type && r.period_start === from && r.period_end === to && r.market_id === (marketBySlug(market)?.id ?? null)) : undefined;
      if (existing) {
        Object.assign(existing, { metrics_json: metrics, summary, created_at: nowIso() });
        a.save();
        return existing.id;
      }
      const id = uuid();
      st().reports.push({ id, period_start: from, period_end: to, market_id: marketBySlug(market)?.id ?? null, report_type: type, metrics_json: metrics, summary, created_at: nowIso() });
      a.save();
      return id;
    },
    async today() {
      admin();
      const out: { priority: number; kind: string; title: string; detail: string | null; link: string }[] = [];
      for (const x of st().alerts.filter((al) => al.status === 'open' && al.severity === 'critical').slice(0, 4)) out.push({ priority: 1, kind: 'alert', title: x.title, detail: x.detail, link: x.link ?? '/admin/growth/alerts' });
      const pend = st().items.filter((i) => i.status === 'pending_approval').length;
      if (pend) out.push({ priority: 2, kind: 'approval', title: `${pend} messaggi in attesa di approvazione`, detail: 'Nessun messaggio parte senza approvazione.', link: '/admin/growth/automations' });
      const exp = subs().filter((s) => s.status === 'trialing' && s.trial_end && ts(s.trial_end) > Date.now() && ts(s.trial_end) < Date.now() + 3 * DAY).length;
      if (exp) out.push({ priority: 2, kind: 'trial', title: `${exp} prove in scadenza entro 3 giorni`, detail: 'Follow-up commerciale.', link: '/admin/growth/churn' });
      const crm = L().tasks.filter((t) => t.status === 'open' && (!t.due_at || ts(t.due_at) < Date.now() + DAY)).length;
      if (crm) out.push({ priority: 3, kind: 'crm', title: `${crm} task CRM in scadenza o scaduti`, detail: null, link: '/admin/launch/taranto/sales' });
      const hi = st().tasks.filter((t) => t.status === 'open' && t.priority === 'high').length;
      if (hi) out.push({ priority: 3, kind: 'growth_task', title: `${hi} task growth ad alta priorità`, detail: null, link: '/admin/growth/tasks' });
      for (const x of st().alerts.filter((al) => al.status === 'open' && al.severity === 'warning').slice(0, 4)) out.push({ priority: 4, kind: 'alert', title: x.title, detail: x.detail, link: x.link ?? '/admin/growth/alerts' });
      const fb = L().feedback.filter((f) => f.status === 'new').length;
      if (fb) out.push({ priority: 5, kind: 'feedback', title: `${fb} feedback da leggere`, detail: null, link: '/admin/launch/taranto/quality' });
      const tk = a.supportTickets().filter((t) => t.status === 'open').length;
      if (tk) out.push({ priority: 5, kind: 'support', title: `${tk} ticket di supporto aperti`, detail: null, link: '/admin/support' });
      return out.sort((x, y) => x.priority - y.priority).slice(0, 10);
    },

    async tasks(status = 'open') {
      admin();
      return st().tasks.filter((t) => !status || t.status === status).sort((x, y) => Number(y.priority === 'high') - Number(x.priority === 'high') || y.created_at.localeCompare(x.created_at));
    },
    async upsertTask(p) {
      admin();
      if (!p.id) {
        const dup = p.source_ref ? st().tasks.find((t) => t.status === 'open' && t.source === (p.source ?? 'manual') && t.source_ref === p.source_ref) : undefined;
        if (dup) return dup.id;
        if ((p.title ?? '').trim().length < 3) throw fail('Titolo troppo corto');
        const m = marketBySlug(p.market ?? null);
        const t: GrowthTask = { id: uuid(), market_id: m?.id ?? null, market_slug: m?.slug ?? null, title: p.title, description: p.description ?? null, source: p.source ?? 'manual', source_ref: p.source_ref ?? null,
          priority: p.priority ?? 'normal', status: 'open', due_at: p.due_at ?? null, created_at: nowIso(), done_at: null };
        st().tasks.push(t);
        a.save();
        return t.id;
      }
      const t = st().tasks.find((x) => x.id === p.id);
      if (t) Object.assign(t, { title: p.title ?? t.title, description: p.description ?? t.description, priority: p.priority ?? t.priority, due_at: p.due_at ?? t.due_at });
      a.save();
      return p.id;
    },
    async setTaskStatus(id, status) {
      admin();
      if (!['open', 'done', 'dismissed'].includes(status)) throw fail('Stato non valido');
      const t = st().tasks.find((x) => x.id === id);
      if (t) Object.assign(t, { status, done_at: status === 'done' ? nowIso() : null });
      a.save();
    },
    async learnings() {
      admin();
      return st().learnings.map((l) => ({ ...l, market_slug: L().markets.find((m) => m.id === l.market_id)?.slug ?? null })).sort((x, y) => y.created_at.localeCompare(x.created_at));
    },
    async learningEvidence(market = 'taranto') {
      admin();
      const m = marketBySlug(market);
      const acts = L().activities.filter((x) => L().leads.find((l) => l.id === x.lead_id)?.market_id === m?.id && ['call', 'whatsapp', 'email', 'instagram_dm', 'visit'].includes(x.type));
      const by = new Map<string, { contacts: number; replied: number }>();
      for (const x of acts) { const v = by.get(x.type) ?? { contacts: 0, replied: 0 }; v.contacts++; if (['replied', 'interested', 'scheduled'].includes(x.outcome ?? '')) v.replied++; by.set(x.type, v); }
      const ids = marketRestIds(market);
      const trials = (db().billing_trials ?? []).filter((t: R) => ids.has(t.restaurant_id));
      const acq = new Map<string, number>();
      for (const u of L().user_acquisition) acq.set(growthChannel(u.channel, u.utm_source), (acq.get(growthChannel(u.channel, u.utm_source)) ?? 0) + 1);
      return {
        outreach: [...by].map(([channel, v]) => ({ channel, ...v, rate: v.contacts ? Math.round((v.replied * 100) / v.contacts) : null, confidence: (v.contacts >= 30 ? 'high' : v.contacts >= 10 ? 'medium' : 'low') as 'low' | 'medium' | 'high' }))
          .sort((x, y) => (y.rate ?? -1) - (x.rate ?? -1)),
        trial_conversion: { ended: trials.filter((t: R) => ts(t.ends_at) <= Date.now() || t.converted_at).length, converted: trials.filter((t: R) => t.converted_at).length },
        qr: { scans: L().qr_scans.length, visits: L().visits.filter((v) => v.channel === 'qr').length, signups: L().user_acquisition.filter((u) => u.channel === 'qr').length },
        acquisition: [...acq].map(([channel, signups]) => ({ channel, signups })).sort((x, y) => y.signups - x.signups),
        note: 'Evidenze osservate in questo mercato. Prima di applicarle a un altro mercato vanno verificate: contesti diversi, risultati diversi.',
      };
    },
    async upsertLearning(p) {
      admin();
      if (!['low', 'medium', 'high'].includes(p.confidence)) throw fail('Confidenza non valida');
      if (p.id) {
        const l = st().learnings.find((x) => x.id === p.id);
        if (l) Object.assign(l, { category: p.category, title: p.title, description: p.description, evidence_json: p.evidence ?? l.evidence_json, confidence: p.confidence });
        a.save();
        return p.id;
      }
      const l: GrowthLearning = { id: uuid(), market_id: marketBySlug(p.market ?? null)?.id ?? null, category: p.category, title: p.title, description: p.description, evidence_json: p.evidence ?? {}, confidence: p.confidence, created_at: nowIso() };
      st().learnings.push(l);
      a.save();
      return l.id;
    },
    async deleteLearning(id) {
      admin();
      st().learnings = st().learnings.filter((x) => x.id !== id);
      a.save();
    },

    async costs(from, to) {
      admin();
      const ai = 0;
      const orders = a.orders().filter((o) => inR(o.paid_at, from, to) && paidOrder(o) && inScope(rest(o.restaurant_id)));
      const proc = orders.reduce((s, o) => s + Math.round(Number(o.payment_processing_fee ?? 0) * 100), 0);
      const missing = orders.filter((o) => o.payment_processing_fee == null).length;
      const manual: Record<string, number> = {};
      for (const c of st().costs.filter((x) => x.period_start <= to && x.period_end >= from)) {
        const overlap = diffDays(c.period_end < to ? c.period_end : to, c.period_start > from ? c.period_start : from) + 1;
        manual[c.category] = (manual[c.category] ?? 0) + Math.round((c.amount_cents * overlap) / (diffDays(c.period_end, c.period_start) + 1));
      }
      const mkt = L().costs.filter((x) => x.spent_on >= from && x.spent_on <= to).reduce((s, x) => s + x.amount_cents, 0);
      const tot = totals(from, to);
      const active = new Set(a.activityDays().filter((x) => x.day >= from && x.day <= to).map((x) => x.user_id)).size;
      const paying = new Set(subs().filter((s) => s.source === 'stripe' && s.paid_started_at && ts(s.paid_started_at) <= Date.parse(`${to}T23:59:59`) && (!s.ended_at || s.ended_at >= from)).map((s) => s.restaurant_id)).size;
      const variable = ai + proc + (manual.ai ?? 0) + (manual.email ?? 0) + (manual.push ?? 0) + (manual.maps ?? 0) + (manual.payment_processing ?? 0);
      return {
        costs: [
          { key: 'ai', label: 'AI (consumo token × tariffe configurate)', cents: ai + (manual.ai ?? 0), source: 'computed' },
          { key: 'payment_processing', label: 'Incasso pagamenti (commissioni reali degli ordini)', cents: proc + (manual.payment_processing ?? 0), source: 'real' },
          { key: 'payment_processing_estimate', label: `Incasso stimato per ${missing} ordini senza commissione registrata (ipotesi non configurata)`, cents: null, source: 'assumption' },
          { key: 'email', label: 'Email', cents: manual.email ?? null, source: 'manual' }, { key: 'push', label: 'Push', cents: manual.push ?? null, source: 'manual' },
          { key: 'maps', label: 'Mappe', cents: manual.maps ?? null, source: 'manual' }, { key: 'infrastructure', label: 'Infrastruttura', cents: manual.infrastructure ?? null, source: 'manual' },
          { key: 'ads', label: 'Pubblicità e marketing (costi di acquisizione registrati + manuali)', cents: mkt + (manual.ads ?? 0), source: 'manual' },
          { key: 'other', label: 'Altro', cents: manual.other ?? null, source: 'manual' },
        ],
        unit: {
          revenue_per_paid_restaurant_cents: paying ? Math.round((tot.subscription_revenue_cents ?? 0) / paying) : null, ai_cost_per_active_user_cents: active ? 0 : null,
          processing_cost_per_order_cents: orders.length && !missing ? Math.round((proc / orders.length) * 100) / 100 : null, contribution_margin_cents: (tot.platform_revenue_cents ?? 0) - variable,
          assumptions: ['Margine di contribuzione APPROSSIMATO = ricavi piattaforma (fatture abbonamenti + commissioni ordini) − costi variabili (AI, incasso, email, push, mappe).',
            'I costi manuali sono ripartiti in proporzione ai giorni del periodo.', 'In DEMO il costo AI non è disponibile (nessun provider reale).',
            missing ? `${missing} ordini non riportano la commissione di incasso reale: costo per ordine non calcolato.` : null],
        },
        counts: { orders: orders.length, active_users: active, paying_restaurants: paying },
        manual: st().costs.filter((x) => x.period_start <= to && x.period_end >= from),
      };
    },
    async addCost(p) {
      admin();
      if (!(p.amount_cents > 0) || p.period_end < p.period_start) throw fail('Dati del costo non validi');
      const c: OperatingCost = { id: uuid(), category: p.category, amount_cents: Math.round(p.amount_cents), period_start: p.period_start, period_end: p.period_end, notes: p.notes ?? null, created_at: nowIso() };
      st().costs.push(c);
      a.save();
      return c.id;
    },
    async deleteCost(id) {
      admin();
      st().costs = st().costs.filter((x) => x.id !== id);
      a.save();
    },
    async settings() {
      admin();
      return { ...DEFAULT_SETTINGS, ...st().settings, automation_kill_switch: st().kill_switch };
    },
    async setSetting(key, value) {
      admin();
      if (!(key in DEFAULT_SETTINGS)) throw fail('Impostazione non modificabile da qui');
      if (typeof DEFAULT_SETTINGS[key] === 'number' && (typeof value !== 'number' || value < 1 || value > 1000)) throw fail('Valore non valido');
      if (key === 'growth_market_weights') {
        for (const [k, v] of Object.entries(value as R)) if (!MARKET_SCORE_KEYS.includes(k as MarketScoreKey) || typeof v !== 'number' || v < 0 || v > 100) throw fail(`Peso non valido: ${k}`);
      }
      st().settings[key] = value;
      a.save();
    },
    async backfill(from, to) {
      admin();
      if (to < from || diffDays(to, from) > 400) throw fail('Intervallo non valido');
      return { days: diffDays(to, from) + 1 };
    },

    async performance(rid) {
      if (!a.uid() || !(a.isAdmin() || a.canManage(rid))) throw deny();
      return perf(rid);
    },
    logSearch(p: SearchLogInput) {
      const city = p.city_slug && db().cities.some((c: R) => c.slug === p.city_slug) ? p.city_slug : null;
      const cat = p.category_slug && db().categories.some((c: R) => c.slug === p.category_slug) ? p.category_slug : null;
      const q = normalizeQuery(p.query);
      if (!q && !city && !cat) return;
      st().search_events.push({ source: p.source ?? 'explore', query_norm: q, city_slug: city, category_slug: cat, result_count: Math.max(0, p.result_count | 0),
        result_ids: (p.result_ids ?? []).filter((id) => db().restaurants.some((r: R) => r.id === id)).slice(0, 20),
        session_id: (() => { const sid = p.session_id ?? consentedSessionId(); return sid && /^[A-Za-z0-9_-]{8,64}$/.test(sid) ? sid : null; })(), created_at: nowIso() });
      const keep = Date.now() - Number(setting('growth_search_log_days')) * DAY;
      if (st().search_events.length > 5000 || ts(st().search_events[0]?.created_at) < keep) st().search_events = st().search_events.filter((s) => ts(s.created_at) >= keep).slice(-5000);
      a.save();
    },
    experimentAssign(key, variant, anon) {
      const e = L().experiments.find((x) => x.key === key && x.status === 'running');
      if (!e || !e.variants.includes(variant) || !/^[A-Za-z0-9_-]{8,64}$/.test(anon)) return;
      if (st().assignments.some((x) => x.experiment_id === e.id && x.anonymous_id === anon)) return;
      st().assignments.push({ experiment_id: e.id, variant, anonymous_id: anon, user_id: a.uid(), converted_at: null, created_at: nowIso() });
      a.save();
    },
    experimentGoal(metric, anon) {
      for (const x of st().assignments.filter((y) => y.anonymous_id === anon && !y.converted_at)) {
        const e = L().experiments.find((z) => z.id === x.experiment_id);
        if (e?.status === 'running' && e.primary_metric === metric) x.converted_at = nowIso();
      }
      a.save();
    },
  };
  return api;
}
