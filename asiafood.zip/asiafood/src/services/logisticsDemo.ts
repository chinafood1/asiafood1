// ─────────────────────────────────────────────────────────────
//  Fase 9 in modalità DEMO: stesse regole delle funzioni SQL lg_*
//  (candidatura, online, posizione, dispatch a raggi crescenti,
//  offerte con timeout, accettazione atomica, macchina a stati,
//  sincronizzazione ordine, compensi, tracking con privacy).
//  I "Rider flotta demo" sono SIMULATI: accettano e si muovono da soli
//  per far vedere il tracking anche senza usare l'app Rider.
// ─────────────────────────────────────────────────────────────
import type { AppNotification, Profile, Restaurant } from '@/types/domain';
import type { OrderStatus } from '@/types/orders';
import type {
  AdminJobDetail, AdminRiderDetail, AdminRiderRow, CompensationRule, DeliveryJobStatus, DispatchBoard, LocationInput, LocationResult, LogisticsAlert,
  LogisticsSettings, LogisticsStats, LogisticsTickResult, OrderDeliveryView, RestaurantDelivery, RiderApplyInput, RiderDocumentType, RiderEarningItem,
  RiderEarningsSummary, RiderHome, RiderJob, RiderJobAction, RiderStatus, ServiceZone, VehicleType,
} from '@/types/logistics';
import { LOGISTICS_DEFAULTS } from '@/types/logistics';
import { haversineKm } from '@/lib/geo';
import type { DemoOrder, LogisticsHooks, MarketState } from './ordersDemo';

type Row = Record<string, unknown>;
const now = () => new Date().toISOString();
const uuid = () => crypto.randomUUID();
const round2 = (n: number) => Math.round(n * 100) / 100;
const MIN = 60_000;
const code4 = () => String(crypto.getRandomValues(new Uint16Array(1))[0]! % 10000).padStart(4, '0');
const ACTIVE: DeliveryJobStatus[] = ['assigned', 'rider_to_restaurant', 'arrived_restaurant', 'picked_up', 'rider_to_customer', 'arrived_customer'];
const FINAL: DeliveryJobStatus[] = ['delivered', 'failed', 'cancelled'];

class DemoError extends Error {}
const fail = (m: string): never => {
  throw new DemoError(m);
};

export interface DemoRider {
  id: string;
  user_id: string;
  status: RiderStatus;
  first_name: string;
  last_name: string;
  phone: string;
  email: string;
  city: string;
  city_id: string | null;
  zone_id: string | null;
  vehicle_type: VehicleType;
  vehicle_details: string | null;
  profile_photo_url: string | null;
  terms_accepted_at: string;
  location_consent_at: string | null;
  approved_at: string | null;
  approved_by: string | null;
  suspended_at: string | null;
  suspension_reason: string | null;
  rejected_reason: string | null;
  admin_notes: string | null;
  rating_internal: number | null;
  total_deliveries: number;
  is_demo: boolean;
  /** Rider della flotta simulata (solo DEMO): risponde e si muove da solo. */
  bot?: boolean;
  created_at: string;
  // disponibilità
  is_online: boolean;
  online_since: string | null;
  offline_since: string | null;
  accepting_orders: boolean;
  current_capacity: number;
  max_concurrent_deliveries: number;
  last_latitude: number | null;
  last_longitude: number | null;
  last_accuracy: number | null;
  last_location_at: string | null;
  last_moved_at: string | null;
  last_offer_at: string | null;
  updated_at: string;
}

interface DemoJob {
  id: string;
  order_id: string;
  restaurant_id: string;
  rider_id: string | null;
  status: DeliveryJobStatus;
  pickup_latitude: number | null;
  pickup_longitude: number | null;
  delivery_latitude: number | null;
  delivery_longitude: number | null;
  pickup_address_snapshot: { name: string; address: string | null; city: string | null; phone: string | null };
  delivery_address_snapshot: Record<string, string | null>;
  estimated_distance_km: number | null;
  pickup_code: string | null;
  delivery_code: string | null;
  delivery_code_required: boolean;
  proof_type: 'confirmation' | 'otp' | 'photo';
  proof_photo_path: string | null;
  code_failures: number;
  dispatch_after: string;
  dispatch_attempts: number;
  search_radius_km: number | null;
  reassignment_count: number;
  flags: string[];
  restaurant_ready_at: string | null;
  offered_at: string | null;
  offer_expires_at: string | null;
  accepted_at: string | null;
  arrived_at_restaurant_at: string | null;
  picked_up_at: string | null;
  out_for_delivery_at: string | null;
  arrived_at_customer_at: string | null;
  customer_wait_started_at: string | null;
  delivered_at: string | null;
  failed_at: string | null;
  failure_reason: string | null;
  cancelled_at: string | null;
  cancel_reason: string | null;
  eta_pickup_at: string | null;
  eta_delivery_min_at: string | null;
  eta_delivery_max_at: string | null;
  eta_updated_at: string | null;
  eta_ref: [number, number] | null;
  last_rider_update_at: string | null;
  created_at: string;
  updated_at: string;
}

interface DemoAssignment {
  id: string;
  delivery_job_id: string;
  rider_id: string;
  status: 'offered' | 'accepted' | 'rejected' | 'expired' | 'cancelled';
  distance_to_pickup_km: number | null;
  estimated_earning: number | null;
  manual: boolean;
  offered_at: string;
  expires_at: string;
  responded_at: string | null;
  rejection_reason: string | null;
}

export interface LogisticsState {
  zones: ServiceZone[];
  rules: CompensationRule[];
  riders: DemoRider[];
  documents: { id: string; rider_id: string; document_type: RiderDocumentType; storage_path: string; status: 'pending' | 'approved' | 'rejected' | 'expired'; expires_at: string | null; uploaded_at: string; review_note: string | null }[];
  locations: { rider_id: string; latitude: number; longitude: number; accuracy: number | null; flags: string[]; recorded_at: string; received_at: string; job_id: string | null }[];
  jobs: DemoJob[];
  assignments: DemoAssignment[];
  earnings: (RiderEarningItem & { rider_id: string; delivery_job_id: string | null; approved_at: string | null })[];
  ratings: { id: string; delivery_job_id: string; rider_id: string | null; user_id: string; rating: number; comment: string | null; created_at: string }[];
  issues: { id: string; delivery_job_id: string; reported_by_type: string; reported_by_id: string | null; issue_type: string; description: string; status: string; created_at: string }[];
  events: { delivery_job_id: string; type: string; actor: string; actor_id: string | null; metadata: Row; created_at: string }[];
  alerts: (LogisticsAlert & { dedupe_key: string })[];
  audit: { action: string; entity_id: string; details: Row; created_at: string; admin_id: string | null }[];
}

export interface LogisticsAccess {
  db: {
    settings: Record<string, unknown>;
    profiles: Profile[];
    restaurants: Restaurant[];
    cities: { id: string; name: string; slug: string; latitude?: number | null; longitude?: number | null }[];
    notifications: AppNotification[];
    market?: MarketState;
    logistics?: LogisticsState;
  };
  market: {
    internal: {
      byId(id: string): DemoOrder;
      transition(o: DemoOrder, action: string, p: Row, actor: 'restaurant' | 'admin' | 'system' | 'customer' | 'rider'): unknown;
      notifyCustomer(o: DemoOrder, kind: string, title: string, body: string, email?: string): void;
      notifyRestaurant(o: DemoOrder, kind: string, title: string, body: string): void;
      access(num: string, token?: string | null): DemoOrder | null;
      logE(o: DemoOrder, type: string, actor: string, meta?: Row): void;
      processRefunds(o: DemoOrder): void;
      canView(rid: string): boolean;
    };
  };
  defaults(): LogisticsState;
  save(): void;
  uid(): string | null;
  isAdmin(): boolean;
  notify(user: string | null, type: string, title: string, body: string, link: string | null, o?: { dedupe?: string; meta?: Row }): unknown;
  notifyAdmins(type: string, title: string, body: string, link: string): void;
  logEvent(restaurantId: string | null, type: string): void;
}

export function createLogistics(a: LogisticsAccess) {
  const st = (): LogisticsState => (a.db.logistics ??= a.defaults());
  const num = (k: string, d: number) => (typeof a.db.settings[`logistics_${k}`] === 'number' ? (a.db.settings[`logistics_${k}`] as number) : d);
  const bool = (k: string, d: boolean) => (typeof a.db.settings[`logistics_${k}`] === 'boolean' ? (a.db.settings[`logistics_${k}`] as boolean) : d);
  const text = (k: string, d: string) => (typeof a.db.settings[`logistics_${k}`] === 'string' ? (a.db.settings[`logistics_${k}`] as string) : d);
  const km = (lat1: number | null, lng1: number | null, lat2: number | null, lng2: number | null) =>
    lat1 == null || lng1 == null || lat2 == null || lng2 == null ? null : Math.round(haversineKm({ lat: lat1, lng: lng1 }, { lat: lat2, lng: lng2 }) * 1000) / 1000;
  const speed = (v: VehicleType) => ({ bike: 14, 'e-bike': 18, scooter: 24, motorcycle: 28, car: 22, other: 15 })[v] ?? 15;
  const minutes = (d: number | null, v: VehicleType = 'scooter') => Math.max(1, Math.ceil(((d ?? 0) * 1.35) / speed(v) * 60) + 2);
  const riderOf = (user = a.uid()) => (user ? st().riders.find((r) => r.user_id === user) ?? null : null);
  const riderById = (id: string | null) => (id ? st().riders.find((r) => r.id === id) ?? null : null);
  const jobById = (id: string) => st().jobs.find((j) => j.id === id) ?? fail('Consegna non trovata.');
  const order = (j: DemoJob) => a.market.internal.byId(j.order_id);
  const restaurant = (id: string) => a.db.restaurants.find((r) => r.id === id);
  const isRider = (r: DemoRider | null) => !!r && ['approved', 'active'].includes(r.status);
  const radii = () => {
    const min = num('initial_search_radius', 3);
    const max = num('max_search_radius', 10);
    const list = text('search_radii', '3,5,8,10').split(',').map((x) => Number(x.trim())).filter((x) => Number.isFinite(x) && x >= min && x <= max);
    return list.length ? Array.from(new Set(list)).sort((x, y) => x - y) : [min, max];
  };

  // ─── Supporto ───────────────────────────────────────────────
  const log = (j: DemoJob, type: string, actor: string, meta: Row = {}) => {
    if (type === 'assigned') meta = { ...meta, eta_max: j.eta_delivery_max_at };
    st().events.push({ delivery_job_id: j.id, type, actor, actor_id: a.uid(), metadata: meta, created_at: now() });
  };
  const alert = (type: string, job: DemoJob | null, rider: string | null, message: string, dedupe?: string) => {
    const key = dedupe ?? `${type}:${job?.id ?? ''}:${rider ?? ''}`;
    if (st().alerts.some((x) => x.dedupe_key === key)) return false;
    st().alerts.unshift({ id: uuid(), alert_type: type, delivery_job_id: job?.id ?? null, rider_id: rider, message: message.slice(0, 300), status: 'open', created_at: now(), dedupe_key: key });
    a.notifyAdmins('logistics', `Logistica: ${type.replace(/_/g, ' ')}`, message.slice(0, 300), '/admin/dispatch');
    return true;
  };
  const notifyRider = (riderId: string, title: string, body: string, link: string, dedupe: string) => {
    const r = riderById(riderId);
    if (r) a.notify(r.user_id, 'rider', title, body, link, { dedupe });
  };
  const audit = (action: string, entity: string, details: Row = {}, admin: string | null = a.uid()) =>
    st().audit.unshift({ action, entity_id: entity, details, created_at: now(), admin_id: admin });
  const releaseCapacity = (riderId: string | null) => {
    const r = riderById(riderId);
    if (r) r.current_capacity = st().jobs.filter((j) => j.rider_id === r.id && ACTIVE.includes(j.status)).length;
  };
  const allowed = (from: DeliveryJobStatus, to: DeliveryJobStatus) => ({
    waiting_assignment: ['offered', 'assigned', 'cancelled', 'failed'], offered: ['assigned', 'waiting_assignment', 'cancelled'],
    assigned: ['rider_to_restaurant', 'arrived_restaurant', 'waiting_assignment', 'cancelled'], rider_to_restaurant: ['arrived_restaurant', 'waiting_assignment', 'cancelled'],
    arrived_restaurant: ['picked_up', 'waiting_assignment', 'cancelled'], picked_up: ['rider_to_customer', 'failed', 'cancelled'],
    rider_to_customer: ['arrived_customer', 'delivered', 'failed', 'cancelled'], arrived_customer: ['delivered', 'failed', 'rider_to_customer', 'cancelled'],
    delivered: [], failed: [], cancelled: [],
  } as Record<DeliveryJobStatus, DeliveryJobStatus[]>)[from].includes(to);
  const setStatus = (j: DemoJob, to: DeliveryJobStatus, actor: string, meta: Row = {}) => {
    if (!allowed(j.status, to)) fail(`Passaggio di stato non consentito (${j.status} → ${to}).`);
    j.status = to;
    const t = now();
    if (to === 'arrived_restaurant') j.arrived_at_restaurant_at = t;
    if (to === 'picked_up') j.picked_up_at = t;
    if (to === 'rider_to_customer' && !j.out_for_delivery_at) j.out_for_delivery_at = t;
    if (to === 'arrived_customer') j.arrived_at_customer_at = t;
    if (to === 'delivered') j.delivered_at = t;
    if (to === 'failed') j.failed_at = t;
    if (to === 'cancelled') j.cancelled_at = t;
    if (actor === 'rider') j.last_rider_update_at = t;
    j.updated_at = t;
    log(j, to, actor, meta);
  };
  const quoteEarning = (j: DemoJob) => {
    const r = restaurant(j.restaurant_id);
    const rule = st().rules.filter((k) => k.is_active && Date.parse(k.effective_from) <= Date.now() && (!k.effective_to || Date.parse(k.effective_to) > Date.now()) && (k.city_id === r?.city_id || k.city_id == null))
      .sort((x, y) => (x.city_id == null ? 1 : 0) - (y.city_id == null ? 1 : 0) || Date.parse(y.effective_from) - Date.parse(x.effective_from))[0];
    if (!rule) return { available: false as const };
    let distanceFee = round2(rule.per_km_fee * (j.estimated_distance_km ?? 0));
    if (rule.max_distance_fee != null) distanceFee = Math.min(distanceFee, rule.max_distance_fee);
    const total = round2(Math.max(rule.minimum_fee, rule.base_fee + distanceFee));
    return { available: true as const, rule_id: rule.id, base_fee: rule.base_fee, distance_fee: round2(total - rule.base_fee), bonus: 0, total, distance_km: j.estimated_distance_km };
  };
  const eta = (j: DemoJob) => {
    if (FINAL.includes(j.status)) return;
    const o = order(j);
    const rd = riderById(j.rider_id);
    const v = rd?.vehicle_type ?? 'scooter';
    const r2c = minutes(j.estimated_distance_km, v);
    const ready = o.estimated_ready_at ? Date.parse(o.estimated_ready_at) : Date.now();
    let t: number;
    if (['waiting_assignment', 'offered'].includes(j.status)) {
      t = Math.max(Date.now(), ready) + (r2c + 5) * MIN;
      j.eta_pickup_at = null;
    } else if (['assigned', 'rider_to_restaurant'].includes(j.status)) {
      const toPick = rd?.last_latitude != null ? minutes(km(rd.last_latitude, rd.last_longitude, j.pickup_latitude, j.pickup_longitude), v) : 10;
      j.eta_pickup_at = new Date(Date.now() + toPick * MIN).toISOString();
      t = Math.max(Date.now() + toPick * MIN, ready) + (r2c + 2) * MIN;
    } else if (j.status === 'arrived_restaurant') t = Math.max(Date.now(), ready) + (r2c + 2) * MIN;
    else if (['picked_up', 'rider_to_customer'].includes(j.status)) {
      t = Date.now() + (rd?.last_latitude != null ? minutes(km(rd.last_latitude, rd.last_longitude, j.delivery_latitude, j.delivery_longitude), v) : r2c) * MIN;
    } else t = Date.now();
    const span = (t - Date.now()) / MIN;
    j.eta_delivery_min_at = new Date(t - Math.max(2, Math.round(span * 0.1)) * MIN).toISOString();
    j.eta_delivery_max_at = new Date(t + Math.max(5, Math.round(span * 0.25)) * MIN).toISOString();
    j.eta_updated_at = now();
    j.eta_ref = rd?.last_latitude != null ? [rd.last_latitude, rd.last_longitude!] : null;
  };
  const serviceCheck = (rid: string, lat: number, lng: number): string | null => {
    const r = restaurant(rid);
    const s = a.db.market?.order_settings.find((x) => x.restaurant_id === rid);
    if (!bool('enabled', true) || !s?.asiafood_delivery_enabled) return 'Le consegne con Rider AsiaFood non sono disponibili in questo momento: scegli il ritiro al locale.';
    const inZone = (la: number | null, ln: number | null) => la != null && ln != null && st().zones.some((z) => z.is_active && haversineKm({ lat: z.center_latitude, lng: z.center_longitude }, { lat: la, lng: ln }) <= z.radius_km);
    if (!inZone(r?.latitude ?? null, r?.longitude ?? null)) return 'Il ristorante non è in una zona servita dai Rider AsiaFood.';
    if (!inZone(lat, lng)) return 'Questo ristorante non consegna ancora a questo indirizzo.';
    return null;
  };

  // ─── Dispatch ───────────────────────────────────────────────
  const candidates = (j: DemoJob, radius: number) => {
    const r = restaurant(j.restaurant_id);
    const fresh = Date.now() - num('location_fresh_minutes', 3) * MIN;
    return st().riders
      .filter((x) => x.is_online && x.accepting_orders && ['approved', 'active'].includes(x.status) && x.current_capacity < x.max_concurrent_deliveries
        && x.last_location_at && Date.parse(x.last_location_at) > fresh && x.last_latitude != null
        && !a.db.profiles.find((p) => p.id === x.user_id)?.is_blocked
        && (x.city_id == null || x.city_id === r?.city_id || st().zones.some((z) => z.is_active && z.city_id === x.city_id && j.pickup_latitude != null
          && haversineKm({ lat: z.center_latitude, lng: z.center_longitude }, { lat: j.pickup_latitude, lng: j.pickup_longitude! }) <= z.radius_km))
        && !st().assignments.some((y) => y.rider_id === x.id && (y.status === 'offered' || y.delivery_job_id === j.id)))
      .map((x) => ({ rider: x, d: km(x.last_latitude, x.last_longitude, j.pickup_latitude, j.pickup_longitude) ?? 999, free: x.max_concurrent_deliveries - x.current_capacity,
        same: st().jobs.some((y) => y.rider_id === x.id && y.restaurant_id === j.restaurant_id && ['assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(y.status)) }))
      .filter((c) => c.d <= radius)
      .sort((p, q) => q.free - p.free || Number(q.same) - Number(p.same) || p.d - q.d);
  };
  function dispatch(j: DemoJob, manualRetry = false): { ok: boolean; reason?: string } {
    if (j.status !== 'waiting_assignment') return { ok: false, reason: 'NOT_WAITING' };
    if (!manualRetry && (!bool('auto_dispatch_enabled', true) || !bool('enabled', true))) return { ok: false, reason: 'AUTO_DISPATCH_DISABLED' };
    if (!manualRetry && j.flags.includes('dispatch_exhausted')) return { ok: false, reason: 'EXHAUSTED' };
    const first = j.dispatch_attempts === 0;
    j.dispatch_attempts += 1;
    const timeout = Math.max(10, num('offer_timeout_seconds', 30));
    for (const radius of radii()) {
      const c = candidates(j, radius)[0];
      if (!c) continue;
      const q = quoteEarning(j);
      const asg: DemoAssignment = { id: uuid(), delivery_job_id: j.id, rider_id: c.rider.id, status: 'offered', distance_to_pickup_km: round2(c.d),
        estimated_earning: q.available ? q.total : null, manual: false, offered_at: now(), expires_at: new Date(Date.now() + timeout * 1000).toISOString(), responded_at: null, rejection_reason: null };
      st().assignments.push(asg);
      Object.assign(j, { status: 'offered' as DeliveryJobStatus, offered_at: now(), offer_expires_at: asg.expires_at, search_radius_km: radius });
      c.rider.last_offer_at = now();
      log(j, 'offer_sent', 'system', { assignment_id: asg.id, rider_id: c.rider.id, radius_km: radius, distance_to_pickup_km: asg.distance_to_pickup_km });
      a.logEvent(j.restaurant_id, 'delivery_offer_sent');
      notifyRider(c.rider.id, 'Nuova consegna disponibile', `${j.pickup_address_snapshot.name} · ${j.estimated_distance_km ?? '?'} km · compenso stimato ${asg.estimated_earning?.toFixed(2) ?? '—'} €. Rispondi entro ${timeout} secondi.`, '/rider', `offer:${asg.id}`);
      return { ok: true };
    }
    log(j, 'no_rider_found', 'system', { attempt: j.dispatch_attempts });
    a.logEvent(j.restaurant_id, 'delivery_assignment_failed');
    const o = order(j);
    if (first) alert('no_rider', j, null, `Nessun Rider disponibile entro ${num('max_search_radius', 10)} km per l’ordine ${o.order_number} (${j.pickup_address_snapshot.name}).`);
    if (j.dispatch_attempts >= num('max_dispatch_attempts', 20) && !j.flags.includes('dispatch_exhausted')) {
      j.flags.push('dispatch_exhausted');
      alert('dispatch_exhausted', j, null, `Ordine ${o.order_number}: ricerca automatica terminata, serve assegnazione manuale.`);
    }
    return { ok: false, reason: 'NO_RIDER' };
  }
  function expireOffers() {
    let n = 0;
    for (const x of st().assignments.filter((y) => y.status === 'offered' && Date.parse(y.expires_at) < Date.now())) {
      Object.assign(x, { status: 'expired', responded_at: now() });
      const j = st().jobs.find((y) => y.id === x.delivery_job_id)!;
      log(j, 'offer_expired', 'system', { assignment_id: x.id, rider_id: x.rider_id });
      if (j.status === 'offered') {
        setStatus(j, 'waiting_assignment', 'system', { reason: 'offer_expired' });
        Object.assign(j, { offered_at: null, offer_expires_at: null });
        dispatch(j);
      }
      n++;
    }
    return n;
  }
  function expireRiderOffers(riderId: string, reason: string) {
    for (const x of st().assignments.filter((y) => y.rider_id === riderId && y.status === 'offered')) {
      Object.assign(x, { status: 'cancelled', responded_at: now(), rejection_reason: reason });
      const j = st().jobs.find((y) => y.id === x.delivery_job_id)!;
      if (j.status === 'offered') {
        setStatus(j, 'waiting_assignment', 'system', { reason });
        dispatch(j);
      }
    }
  }

  function createJob(o: DemoOrder) {
    if (o.order_type !== 'delivery' || o.delivery_provider_type !== 'asiafood') return null;
    const ex = st().jobs.find((j) => j.order_id === o.id);
    if (ex) return ex;
    const r = restaurant(o.restaurant_id)!;
    const lat = Number(o.delivery_address?.latitude);
    const lng = Number(o.delivery_address?.longitude);
    const dist = km(r.latitude, r.longitude, lat, lng);
    const strategy = text('dispatch_strategy', 'immediate');
    const after = strategy === 'before_ready' && o.estimated_ready_at ? Math.max(Date.now(), Date.parse(o.estimated_ready_at) - num('dispatch_before_ready_minutes', 10) * MIN) : Date.now();
    const proof = text('proof_of_delivery_type', 'confirmation') as DemoJob['proof_type'];
    const codeReq = bool('delivery_code_required', false) || proof === 'otp';
    const j: DemoJob = {
      id: uuid(), order_id: o.id, restaurant_id: r.id, rider_id: null, status: 'waiting_assignment', pickup_latitude: r.latitude, pickup_longitude: r.longitude,
      delivery_latitude: lat, delivery_longitude: lng,
      pickup_address_snapshot: { name: r.name, address: r.address, city: a.db.cities.find((c) => c.id === r.city_id)?.name ?? null, phone: r.phone },
      delivery_address_snapshot: { address_line_1: o.delivery_address?.address_line_1 ?? null, address_line_2: o.delivery_address?.address_line_2 ?? null,
        postal_code: o.delivery_address?.postal_code ?? null, city: o.delivery_address?.city ?? null, delivery_notes: o.delivery_address?.delivery_notes ?? null },
      estimated_distance_km: dist, pickup_code: code4(), delivery_code: codeReq ? code4() : null, delivery_code_required: codeReq,
      proof_type: ['confirmation', 'otp', 'photo'].includes(proof) ? proof : 'confirmation', proof_photo_path: null, code_failures: 0,
      dispatch_after: new Date(after).toISOString(), dispatch_attempts: 0, search_radius_km: null, reassignment_count: 0, flags: [],
      restaurant_ready_at: o.status === 'ready' ? now() : null, offered_at: null, offer_expires_at: null, accepted_at: null, arrived_at_restaurant_at: null,
      picked_up_at: null, out_for_delivery_at: null, arrived_at_customer_at: null, customer_wait_started_at: null, delivered_at: null, failed_at: null,
      failure_reason: null, cancelled_at: null, cancel_reason: null, eta_pickup_at: null, eta_delivery_min_at: null, eta_delivery_max_at: null, eta_updated_at: null,
      eta_ref: null, last_rider_update_at: null, created_at: now(), updated_at: now(),
    };
    st().jobs.unshift(j);
    log(j, 'created', 'system', { order_number: o.order_number, distance_km: dist });
    a.market.internal.logE(o, 'delivery_job_created', 'system', { delivery_job_id: j.id });
    if (!bool('enabled', true)) alert('no_rider', j, null, `Servizio Rider disattivato: consegna ${o.order_number} da gestire manualmente.`);
    eta(j);
    if (after <= Date.now()) dispatch(j);
    return j;
  }

  /** Sincronizza l'ordine: le transizioni "in consegna"/"consegnato" passano SOLO da qui. */
  const syncOrder = (j: DemoJob, event: 'picked_up' | 'delivered') => {
    const o = order(j);
    if (event === 'picked_up' && ['accepted', 'preparing', 'ready'].includes(o.status)) {
      Object.assign(o, { status: 'out_for_delivery', fulfillment_status: 'out_for_delivery', out_for_delivery_at: now(), picked_up_at: now(), ready_at: o.ready_at ?? now(), preparing_at: o.preparing_at ?? o.accepted_at });
      a.market.internal.logE(o, 'out_for_delivery', 'rider', { delivery_job_id: j.id });
    } else if (event === 'delivered' && ['out_for_delivery', 'ready'].includes(o.status)) {
      a.market.internal.transition(o, 'complete', {}, 'rider');
    }
  };

  const hooks: LogisticsHooks = {
    serviceCheck,
    hasActiveJob: (orderId) => st().jobs.some((j) => j.order_id === orderId && !['cancelled', 'failed'].includes(j.status)),
    onOrderStatus(o: DemoOrder, prev: OrderStatus) {
      if (o.order_type !== 'delivery' || o.delivery_provider_type !== 'asiafood') return;
      if (o.status === 'accepted' && prev === 'pending_restaurant') {
        createJob(o);
        return;
      }
      const j = st().jobs.find((x) => x.order_id === o.id);
      if (!j) return;
      if (o.status === 'ready') {
        j.restaurant_ready_at = now();
        if (j.status === 'waiting_assignment' && Date.parse(j.dispatch_after) > Date.now()) j.dispatch_after = now();
        log(j, 'restaurant_ready', 'restaurant');
        if (j.rider_id && ['assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(j.status)) {
          notifyRider(j.rider_id, 'Ordine pronto', `L’ordine ${o.order_number} è pronto per il ritiro.`, `/rider/delivery/${j.id}`, `ready:${j.id}`);
        } else if (j.status === 'waiting_assignment') dispatch(j);
      } else if (['cancelled', 'rejected', 'refunded'].includes(o.status) && !FINAL.includes(j.status)) {
        const rider = j.rider_id;
        const stage = j.status;
        st().assignments.filter((x) => x.delivery_job_id === j.id && x.status === 'offered').forEach((x) => Object.assign(x, { status: 'cancelled', responded_at: now() }));
        setStatus(j, 'cancelled', 'system', { reason: `order_${o.status}`, stage });
        j.cancel_reason = `Ordine ${o.status}${o.cancel_reason || o.reject_reason ? `: ${o.cancel_reason ?? o.reject_reason}` : ''}`;
        if (rider) {
          releaseCapacity(rider);
          const after = ['picked_up', 'rider_to_customer', 'arrived_customer'].includes(stage);
          notifyRider(rider, 'Consegna annullata', `L’ordine ${o.order_number} è stato annullato.${after ? ' Contatta il supporto per la restituzione.' : ' Non devi ritirarlo.'}`, '/rider', `cancel:${j.id}`);
          alert(after ? 'cancelled_after_pickup' : 'cancelled_with_rider', j, rider, `Ordine ${o.order_number} annullato con Rider già in ${stage}: valuta l’eventuale compenso.`);
        }
      }
    },
  };

  // ─── Flotta simulata (solo DEMO) ────────────────────────────
  /** Muove i Rider simulati verso la meta e fa avanzare le loro consegne: nessun effetto sui Rider reali. */
  let lastSim = 0;
  /** Restituisce true se ha modificato lo stato (le letture salvano solo in quel caso). Al massimo ogni 1,5 s. */
  function simulateBots(): boolean {
    if (Date.now() - lastSim < 1500) return false;
    lastSim = Date.now();
    const before = JSON.stringify([st().jobs, st().assignments]);
    let moved = false;
    for (const b of st().riders.filter((x) => x.bot && x.is_online)) {
      const offer = st().assignments.find((x) => x.rider_id === b.id && x.status === 'offered');
      if (offer && Date.now() - Date.parse(offer.offered_at) > 4000) respondInternal(b, offer, true, null);
      const j = st().jobs.find((x) => x.rider_id === b.id && ACTIVE.includes(x.status));
      if (!j) {
        // In attesa: posizione "base" dichiarata (≈ 4 e 6 km dal centro di Taranto), sempre aggiornata
        const z = st().zones[0];
        const k = b.id.endsWith('3') ? 0.04 : -0.055;
        // Aggiornata solo quando sta per diventare "vecchia" (candidabile per 3 min), non a ogni lettura
        if (z && (!b.last_location_at || Date.parse(b.last_location_at) < Date.now() - 60_000)) {
          Object.assign(b, { last_latitude: z.center_latitude + k, last_longitude: z.center_longitude + k / 2, last_location_at: now() });
          moved = true;
        }
        continue;
      }
      const o = order(j);
      const step = (tLat: number, tLng: number, frac = 0.35) => {
        const la = b.last_latitude ?? tLat;
        const ln = b.last_longitude ?? tLng;
        const d = km(la, ln, tLat, tLng) ?? 0;
        const f = d < 0.15 ? 1 : frac;
        Object.assign(b, { last_latitude: la + (tLat - la) * f, last_longitude: ln + (tLng - ln) * f, last_location_at: now(), last_moved_at: now() });
        j.last_rider_update_at = now();
        return d < 0.15;
      };
      if (j.status === 'assigned') setStatus(j, 'rider_to_restaurant', 'rider');
      else if (j.status === 'rider_to_restaurant') { if (step(j.pickup_latitude!, j.pickup_longitude!)) setStatus(j, 'arrived_restaurant', 'rider'); }
      else if (j.status === 'arrived_restaurant') {
        if (o.status === 'ready' || (o.estimated_ready_at && Date.parse(o.estimated_ready_at) < Date.now())) {
          setStatus(j, 'picked_up', 'rider');
          syncOrder(j, 'picked_up');
          setStatus(j, 'rider_to_customer', 'rider');
          a.market.internal.notifyCustomer(o, 'order_picked_up', 'Ordine ritirato', `Il Rider ha ritirato il tuo ordine ${o.order_number} ed è in viaggio verso di te.`);
        }
      } else if (j.status === 'rider_to_customer') {
        if (step(j.delivery_latitude!, j.delivery_longitude!, 0.25)) setStatus(j, 'arrived_customer', 'rider');
      } else if (j.status === 'arrived_customer') completeDelivery(b, j, {});
      eta(j);
      moved = true;
    }
    return moved || JSON.stringify([st().jobs, st().assignments]) !== before;
  }
  /** Scadenza offerte + flotta simulata; salva solo se qualcosa è cambiato. */
  function refresh() {
    const n = expireOffers();
    const b = simulateBots();
    if (n > 0 || b) a.save();
  }

  // ─── Azioni Rider (interne) ─────────────────────────────────
  function respondInternal(r: DemoRider, x: DemoAssignment, accept: boolean, reason: string | null) {
    const j = jobById(x.delivery_job_id);
    if (x.status !== 'offered') fail('Questa offerta non è più disponibile.');
    if (Date.parse(x.expires_at) < Date.now()) {
      Object.assign(x, { status: 'expired', responded_at: now() });
      fail('L’offerta è scaduta.');
    }
    if (!accept) {
      Object.assign(x, { status: 'rejected', responded_at: now(), rejection_reason: reason && ['too_far', 'end_of_shift', 'vehicle_problem', 'not_available', 'other'].includes(reason) ? reason : 'other' });
      log(j, 'offer_rejected', 'rider', { assignment_id: x.id, reason });
      a.logEvent(j.restaurant_id, 'delivery_offer_rejected');
      if (j.status === 'offered' && !j.rider_id) {
        setStatus(j, 'waiting_assignment', 'rider', { reason: 'offer_rejected' });
        Object.assign(j, { offered_at: null, offer_expires_at: null });
        dispatch(j);
      }
      return { ok: true, status: 'rejected' };
    }
    if (j.rider_id || !['offered', 'waiting_assignment'].includes(j.status)) {
      Object.assign(x, { status: 'cancelled', responded_at: now(), rejection_reason: 'already_assigned' });
      fail('La consegna è già stata assegnata a un altro Rider.');
    }
    if (!r.is_online || r.current_capacity >= r.max_concurrent_deliveries) fail('Non puoi accettare altre consegne in questo momento.');
    Object.assign(x, { status: 'accepted', responded_at: now() });
    st().assignments.filter((y) => y.delivery_job_id === j.id && y.status === 'offered' && y.id !== x.id).forEach((y) => Object.assign(y, { status: 'cancelled', responded_at: now(), rejection_reason: 'assigned_to_other' }));
    Object.assign(j, { rider_id: r.id, accepted_at: now(), offer_expires_at: null });
    eta(j);
    setStatus(j, 'assigned', 'rider', { assignment_id: x.id });
    releaseCapacity(r.id);
    a.logEvent(j.restaurant_id, 'delivery_offer_accepted');
    const o = order(j);
    a.market.internal.logE(o, 'rider_assigned', 'rider', { delivery_job_id: j.id });
    a.market.internal.notifyCustomer(o, 'rider_assigned', 'Rider assegnato', `${r.first_name} ${r.last_name[0]}. porterà il tuo ordine ${o.order_number}.`);
    a.market.internal.notifyRestaurant(o, 'rider_assigned', `Rider assegnato · ${o.order_number}`, `${r.first_name} ${r.last_name[0]}. sta arrivando a ritirare l’ordine.`);
    return { ok: true, status: 'assigned', delivery_job_id: j.id };
  }
  function completeDelivery(r: DemoRider, j: DemoJob, p: Row) {
    if (j.delivery_code_required) {
      if (j.code_failures >= 5) fail('Troppi codici errati: contatta il supporto.');
      if (String(p.delivery_code ?? '') !== j.delivery_code && !r.bot) {
        j.code_failures += 1;
        log(j, 'delivery_code_wrong', 'rider');
        fail('Codice di consegna non corretto: chiedilo al cliente.');
      }
    }
    if (j.proof_type === 'photo' && !r.bot) {
      if (typeof p.photo_path !== 'string' || !p.photo_path) fail('Scatta una foto del pacco consegnato (non del cliente).');
      j.proof_photo_path = p.photo_path as string;
    }
    setStatus(j, 'delivered', 'rider', { proof: j.proof_type, code_verified: j.delivery_code_required });
    syncOrder(j, 'delivered');
    const q = quoteEarning(j);
    if (q.available && !st().earnings.some((e) => e.delivery_job_id === j.id && e.status !== 'cancelled')) {
      st().earnings.unshift({ id: uuid(), rider_id: r.id, delivery_job_id: j.id, total: q.total, base_fee: q.base_fee, distance_fee: q.distance_fee, bonus: 0, adjustment: 0,
        status: 'pending', note: null, created_at: now(), paid_at: null, approved_at: null, order_number: order(j).order_number });
    }
    r.total_deliveries += 1;
    releaseCapacity(r.id);
    a.logEvent(j.restaurant_id, 'delivery_completed');
    a.market.internal.logE(order(j), 'delivered', 'rider', { delivery_job_id: j.id });
    st().alerts.filter((x) => x.delivery_job_id === j.id && x.status === 'open' && ['rider_stale', 'rider_stationary', 'order_late'].includes(x.alert_type)).forEach((x) => (x.status = 'resolved'));
  }

  const riderJobView = (j: DemoJob): RiderJob => {
    const o = order(j);
    const e = st().earnings.find((x) => x.delivery_job_id === j.id && x.status !== 'cancelled');
    return {
      id: j.id, status: j.status, order_number: o.order_number, order_status: o.status,
      restaurant: { ...j.pickup_address_snapshot, latitude: j.pickup_latitude, longitude: j.pickup_longitude },
      restaurant_notes: o.restaurant_notes, ready: o.status === 'ready' || !!j.restaurant_ready_at, estimated_ready_at: o.estimated_ready_at,
      items: o.items.map((i) => ({ name: i.name, quantity: i.quantity, variant: i.variant })),
      customer: FINAL.includes(j.status) ? null : { name: o.customer_name.split(' ')[0] ?? o.customer_name, phone: o.customer_phone, address: j.delivery_address_snapshot,
        latitude: j.delivery_latitude, longitude: j.delivery_longitude, notes: o.customer_notes },
      pickup_code_required: bool('pickup_code_required', true), delivery_code_required: j.delivery_code_required, proof_type: j.proof_type,
      distance_km: j.estimated_distance_km, eta_pickup_at: j.eta_pickup_at, eta_delivery_min_at: j.eta_delivery_min_at, eta_delivery_max_at: j.eta_delivery_max_at,
      accepted_at: j.accepted_at, arrived_at_restaurant_at: j.arrived_at_restaurant_at, picked_up_at: j.picked_up_at, arrived_at_customer_at: j.arrived_at_customer_at,
      customer_wait_started_at: j.customer_wait_started_at, delivered_at: j.delivered_at, customer_wait_minutes: num('customer_wait_minutes', 10),
      earning: e ? { total: e.total, status: e.status, final: true } : { ...quoteEarning(j), final: false },
    };
  };
  const me = () => {
    const r = riderOf();
    if (!r || !isRider(r)) fail('Non autorizzato.');
    return r!;
  };
  const myJob = (id: string) => {
    const r = me();
    const j = jobById(id);
    if (j.rider_id !== r.id) fail('Consegna non trovata.');
    return { r, j };
  };
  const assertAdmin = () => {
    if (!a.isAdmin()) fail('Non autorizzato');
  };

  // ─── API ────────────────────────────────────────────────────
  return {
    hooks,
    tick(): LogisticsTickResult {
      const expired = expireOffers();
      lastSim = 0;
      simulateBots();
      let dispatched = 0;
      for (const j of st().jobs.filter((x) => x.status === 'waiting_assignment' && Date.parse(x.dispatch_after) <= Date.now() && !x.flags.includes('dispatch_exhausted'))) {
        if (dispatch(j).ok) dispatched++;
      }
      let alerts = 0;
      for (const j of st().jobs.filter((x) => ['waiting_assignment', 'offered'].includes(x.status) && Date.parse(x.created_at) < Date.now() - num('alert_unassigned_minutes', 10) * MIN)) {
        if (alert('unassigned_too_long', j, null, `Ordine ${order(j).order_number} senza Rider da oltre ${num('alert_unassigned_minutes', 10)} minuti.`)) alerts++;
      }
      for (const j of st().jobs.filter((x) => ['assigned', 'rider_to_restaurant', 'picked_up', 'rider_to_customer'].includes(x.status))) {
        const rd = riderById(j.rider_id);
        const last = Math.max(Date.parse(rd?.last_location_at ?? '') || 0, Date.parse(j.last_rider_update_at ?? '') || 0);
        if (last && last < Date.now() - num('rider_stale_minutes', 5) * MIN && alert('rider_stale', j, j.rider_id, `Ordine ${order(j).order_number}: il Rider non aggiorna posizione o stato da oltre ${num('rider_stale_minutes', 5)} minuti.`)) {
          if (!j.flags.includes('rider_no_response')) j.flags.push('rider_no_response');
          alerts++;
        }
      }
      const cutoff = Date.now() - num('location_retention_hours', 24) * 3600_000;
      const before = st().locations.length;
      st().locations = st().locations.filter((l) => Date.parse(l.received_at) >= cutoff);
      a.save();
      return { expired_offers: expired, dispatched, alerts, locations_purged: before - st().locations.length };
    },
    // Rider
    apply(p: RiderApplyInput) {
      const uid = a.uid() ?? fail('Accedi per candidarti come Rider.');
      const ex = riderOf(uid);
      if (ex && ex.status !== 'rejected') fail('Hai già inviato una candidatura.');
      if (!p.terms_accepted) fail('Devi accettare i termini del servizio Rider.');
      if (!['bike', 'e-bike', 'scooter', 'motorcycle', 'car', 'other'].includes(p.vehicle_type)) fail('Scegli il veicolo.');
      if (!p.first_name?.trim() || !p.last_name?.trim()) fail('Inserisci nome e cognome.');
      if (!/^\+?[0-9 ]{6,20}$/.test(p.phone ?? '')) fail('Numero di telefono non valido.');
      const prof = a.db.profiles.find((x) => x.id === uid);
      const email = (p.email?.trim() || prof?.email) ?? '';
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) fail('Email non valida.');
      const city = a.db.cities.find((c) => c.slug === p.city_slug);
      if (!city && (p.city ?? '').trim().length < 2) fail('Indica la zona operativa.');
      const base = { status: 'pending' as RiderStatus, first_name: p.first_name.trim().slice(0, 60), last_name: p.last_name.trim().slice(0, 60), phone: p.phone.trim(), email,
        city: city?.name ?? (p.city ?? '').trim(), city_id: city?.id ?? null, zone_id: p.zone_id && st().zones.some((z) => z.id === p.zone_id && z.is_active) ? p.zone_id : null,
        vehicle_type: p.vehicle_type, vehicle_details: p.vehicle_details?.trim().slice(0, 200) || null, terms_accepted_at: now(), rejected_reason: null };
      if (ex) Object.assign(ex, base);
      else st().riders.push({ id: uuid(), user_id: uid, ...base, profile_photo_url: null, location_consent_at: null, approved_at: null, approved_by: null, suspended_at: null,
        suspension_reason: null, admin_notes: null, rating_internal: null, total_deliveries: 0, is_demo: false, created_at: now(), is_online: false, online_since: null, offline_since: null,
        accepting_orders: true, current_capacity: 0, max_concurrent_deliveries: Math.max(1, Math.min(5, num('default_rider_capacity', 1))), last_latitude: null, last_longitude: null,
        last_accuracy: null, last_location_at: null, last_moved_at: null, last_offer_at: null, updated_at: now() });
      a.notifyAdmins('rider_application', 'Nuova candidatura Rider', `${base.first_name} ${base.last_name[0]}. · ${base.city}`, '/admin/riders?status=pending');
      a.save();
      return { ok: true, status: 'pending' as const };
    },
    addDocument(type: RiderDocumentType, fileName: string, expires: string | null) {
      const r = riderOf() ?? fail('Candidatura Rider non trovata.');
      if (st().documents.filter((d) => d.rider_id === r.id).length >= 20) fail('Troppi documenti caricati.');
      // DEMO: il file NON viene caricato né conservato (solo il nome, per mostrare il flusso)
      st().documents.push({ id: uuid(), rider_id: r.id, document_type: type, storage_path: `${r.user_id}/demo-${fileName.replace(/[^\w.-]/g, '_').slice(0, 60)}`, status: 'pending',
        expires_at: expires, uploaded_at: now(), review_note: null });
      a.save();
    },
    home(): RiderHome {
      const r = riderOf();
      if (!r) return { rider: null };
      refresh();
      const offer = st().assignments.find((x) => x.rider_id === r.id && x.status === 'offered' && Date.parse(x.expires_at) > Date.now());
      let offerView: RiderHome['offer'] = null;
      if (offer) {
        const j = jobById(offer.delivery_job_id);
        const o = order(j);
        offerView = { assignment_id: offer.id, expires_at: offer.expires_at, offered_at: offer.offered_at, order_number: o.order_number,
          restaurant: { name: j.pickup_address_snapshot.name, address: j.pickup_address_snapshot.address, city: j.pickup_address_snapshot.city },
          delivery_area: `${j.delivery_address_snapshot.postal_code ?? ''} ${j.delivery_address_snapshot.city ?? ''}`.trim(),
          distance_to_pickup_km: offer.distance_to_pickup_km, delivery_distance_km: j.estimated_distance_km,
          estimated_minutes: minutes((offer.distance_to_pickup_km ?? 0) + (j.estimated_distance_km ?? 0), r.vehicle_type), estimated_earning: offer.estimated_earning,
          ready_at: o.estimated_ready_at, scheduled_for: o.scheduled_for };
      }
      const mine = st().jobs.filter((j) => st().assignments.some((x) => x.delivery_job_id === j.id && x.rider_id === r.id && ['accepted', 'cancelled'].includes(x.status)));
      const done = mine.filter((j) => j.status === 'delivered' && j.rider_id === r.id).length;
      const failed = mine.filter((j) => j.status === 'failed' && j.rider_id === r.id).length;
      const cancels = st().assignments.filter((x) => x.rider_id === r.id && x.status === 'cancelled' && x.rejection_reason && !['assigned_to_other', 'already_assigned', 'offline', 'suspended', 'admin'].includes(x.rejection_reason)).length;
      const times = st().jobs.filter((j) => j.rider_id === r.id && j.status === 'delivered' && j.accepted_at && j.delivered_at).map((j) => (Date.parse(j.delivered_at!) - Date.parse(j.accepted_at!)) / MIN);
      return {
        rider: { id: r.id, status: r.status, first_name: r.first_name, last_name: r.last_name, city: r.city, vehicle_type: r.vehicle_type, vehicle_details: r.vehicle_details,
          suspension_reason: r.status === 'suspended' ? r.suspension_reason : null, rejected_reason: r.status === 'rejected' ? r.rejected_reason : null,
          location_consent: !!r.location_consent_at,
          documents: st().documents.filter((d) => d.rider_id === r.id).map((d) => ({ id: d.id, type: d.document_type, status: d.status, expires_at: d.expires_at, uploaded_at: d.uploaded_at })) },
        availability: { is_online: r.is_online, accepting_orders: r.accepting_orders, online_since: r.online_since, current_capacity: r.current_capacity,
          max_concurrent_deliveries: r.max_concurrent_deliveries, last_location_at: r.last_location_at },
        settings: { interval_active: num('location_interval_active', 15), interval_idle: num('location_interval_idle', 60), arrival_radius_m: num('arrival_radius_m', 100) },
        offer: offerView,
        active: st().jobs.filter((j) => j.rider_id === r.id && ACTIVE.includes(j.status)).map((j) => ({ id: j.id, status: j.status, order_number: order(j).order_number, restaurant: j.pickup_address_snapshot.name })),
        stats: { completed: done, failed, completion_rate: done + failed + cancels > 0 ? Math.round((done / (done + failed + cancels)) * 1000) / 1000 : null,
          avg_delivery_minutes: times.length ? Math.round((times.reduce((s, x) => s + x, 0) / times.length) * 10) / 10 : null, total_deliveries: r.total_deliveries },
      };
    },
    setOnline(online: boolean, consent: boolean) {
      const r = riderOf() ?? fail('Non sei un Rider.');
      if (online) {
        if (!isRider(r)) fail('Il tuo profilo Rider non è attivo.');
        if (!r.location_consent_at && !consent) fail('Per andare online devi autorizzare l’uso della posizione mentre sei online.');
        r.location_consent_at ??= now();
        if (r.status === 'approved') r.status = 'active';
        if (!r.is_online) r.online_since = now();
        Object.assign(r, { is_online: true, accepting_orders: true, updated_at: now() });
        a.logEvent(null, 'rider_online');
      } else {
        if (st().jobs.some((j) => j.rider_id === r.id && ACTIVE.includes(j.status))) fail('Hai una consegna in corso: completala o segnala un problema prima di andare offline.');
        Object.assign(r, { is_online: false, offline_since: now(), accepting_orders: false, last_latitude: null, last_longitude: null, last_accuracy: null, last_location_at: null, updated_at: now() });
        expireRiderOffers(r.id, 'offline');
        a.logEvent(null, 'rider_offline');
      }
      a.save();
      return { ok: true, is_online: r.is_online, accepting_orders: r.accepting_orders };
    },
    location(p: LocationInput): LocationResult {
      const r = riderOf();
      if (!r || !isRider(r)) fail('Non autorizzato.');
      if (!r!.is_online) return { accepted: false, reason: 'OFFLINE', tracking: false };
      const rd = r!;
      const j = st().jobs.find((x) => x.rider_id === rd.id && ACTIVE.includes(x.status));
      const interval = j ? num('location_interval_active', 15) : num('location_interval_idle', 60);
      const at = p.recorded_at ? Date.parse(p.recorded_at) : Date.now();
      if (!Number.isFinite(p.latitude) || !Number.isFinite(p.longitude) || Math.abs(p.latitude) > 90 || Math.abs(p.longitude) > 180) fail('Posizione non valida.');
      if (at < Date.now() - 2 * MIN) return { accepted: false, reason: 'STALE', interval_seconds: interval, tracking: true };
      const gap = Math.max(5, Math.floor(interval / 2)) * 1000;
      if (rd.last_location_at && at < Date.parse(rd.last_location_at) + gap) return { accepted: false, reason: 'TOO_FREQUENT', interval_seconds: interval, tracking: true, high_accuracy: !!j };
      const flags: string[] = [];
      if (p.accuracy != null && p.accuracy > num('max_accuracy_m', 150)) flags.push('low_accuracy');
      let moved: number | null = null;
      if (rd.last_latitude != null) {
        moved = km(rd.last_latitude, rd.last_longitude, p.latitude, p.longitude)!;
        const hours = Math.max((at - Date.parse(rd.last_location_at!)) / 3600_000, 1 / 3600);
        if (moved / hours > 150 && moved > 1) flags.push('impossible_jump');
      }
      if (p.speed != null && p.speed > 45) flags.push('speed_anomaly');
      st().locations.push({ rider_id: rd.id, latitude: p.latitude, longitude: p.longitude, accuracy: p.accuracy ?? null, flags, recorded_at: new Date(at).toISOString(), received_at: now(), job_id: j?.id ?? null });
      if (flags.includes('impossible_jump') || flags.includes('speed_anomaly')) {
        alert('location_anomaly', j ?? null, rd.id, `Posizione anomala del Rider ${rd.first_name} ${rd.last_name[0]}. (${flags.join(', ')}): da verificare.`, `location_anomaly:${rd.id}:${new Date().toISOString().slice(0, 13)}`);
        a.save();
        return { accepted: false, reason: 'ANOMALY', interval_seconds: interval, tracking: true, high_accuracy: !!j };
      }
      Object.assign(rd, { last_latitude: p.latitude, last_longitude: p.longitude, last_accuracy: p.accuracy ?? null, last_location_at: new Date(at).toISOString(),
        last_moved_at: moved == null || moved > 0.05 ? new Date(at).toISOString() : rd.last_moved_at, updated_at: now() });
      let hint: LocationResult['hint'] = null;
      if (j) {
        j.last_rider_update_at = now();
        if (!j.eta_ref || (km(j.eta_ref[0], j.eta_ref[1], p.latitude, p.longitude) ?? 0) > 0.25 || Date.parse(j.eta_updated_at ?? '') < Date.now() - 2 * MIN) eta(j);
        if (['assigned', 'rider_to_restaurant'].includes(j.status)) {
          if ((km(p.latitude, p.longitude, j.pickup_latitude, j.pickup_longitude) ?? 99) * 1000 <= num('arrival_radius_m', 100)) hint = 'near_restaurant';
        } else if (['picked_up', 'rider_to_customer'].includes(j.status)) {
          const d = (km(p.latitude, p.longitude, j.delivery_latitude, j.delivery_longitude) ?? 99) * 1000;
          if (d <= num('arrival_radius_m', 100)) hint = 'near_customer';
          if (d <= num('nearby_radius_m', 500)) a.market.internal.notifyCustomer(order(j), 'rider_nearby', 'Il Rider è vicino', 'Il tuo ordine sta arrivando: tieni il telefono a portata di mano.');
        }
      }
      a.save();
      return { accepted: true, flags, interval_seconds: interval, high_accuracy: !!j, tracking: true, hint };
    },
    respond(assignmentId: string, accept: boolean, reason: string | null) {
      const r = me();
      const x = st().assignments.find((y) => y.id === assignmentId && y.rider_id === r.id) ?? fail('Offerta non trovata.');
      try {
        return respondInternal(r, x, accept, reason);
      } finally {
        a.save();
      }
    },
    job(id: string) {
      const { j } = myJob(id);
      return riderJobView(j);
    },
    action(id: string, action: RiderJobAction, p: Row = {}): RiderJob | { id: string; status: string } {
      const { r, j } = myJob(id);
      const o = order(j);
      try {
        if (action === 'depart') setStatus(j, 'rider_to_restaurant', 'rider');
        else if (action === 'arrived_restaurant') {
          setStatus(j, 'arrived_restaurant', 'rider');
          a.logEvent(j.restaurant_id, 'rider_arrived_restaurant');
          a.market.internal.notifyRestaurant(o, 'rider_arrived', `Rider arrivato · ${o.order_number}`, `${r.first_name} ${r.last_name[0]}. è al locale per il ritiro.`);
          a.market.internal.notifyCustomer(o, 'rider_arriving_restaurant', 'Il Rider è al ristorante', `Il Rider sta ritirando il tuo ordine da ${j.pickup_address_snapshot.name}.`);
        } else if (action === 'not_ready') {
          if (j.status !== 'arrived_restaurant') fail('Segnala l’attesa quando sei al ristorante.');
          log(j, 'order_not_ready', 'rider');
          a.market.internal.notifyRestaurant(o, `rider_waiting:${Math.floor(Date.now() / 300_000)}`, `Il Rider sta aspettando · ${o.order_number}`, 'Il Rider è al locale e l’ordine non è ancora pronto.');
        } else if (action === 'picked_up') {
          if (j.status !== 'arrived_restaurant') fail('Conferma prima di essere arrivato al ristorante.');
          if (bool('pickup_code_required', true) && String(p.pickup_code ?? '') !== j.pickup_code) {
            j.code_failures += 1;
            log(j, 'pickup_code_wrong', 'rider');
            fail('Codice di ritiro non corretto: chiedilo al ristorante (è sullo scontrino dell’ordine).');
          }
          setStatus(j, 'picked_up', 'rider', { waiting_minutes: j.arrived_at_restaurant_at ? Math.round((Date.now() - Date.parse(j.arrived_at_restaurant_at)) / 6000) / 10 : 0 });
          syncOrder(j, 'picked_up');
          setStatus(j, 'rider_to_customer', 'rider');
          eta(j);
          a.logEvent(j.restaurant_id, 'order_picked_up');
          a.market.internal.notifyCustomer(o, 'order_picked_up', 'Ordine ritirato', `Il Rider ha ritirato il tuo ordine ${o.order_number} ed è in viaggio verso di te.`);
        } else if (action === 'arrived_customer') {
          setStatus(j, 'arrived_customer', 'rider');
          a.logEvent(j.restaurant_id, 'rider_arrived_customer');
        } else if (action === 'customer_unavailable') {
          if (!['arrived_customer', 'rider_to_customer'].includes(j.status)) fail('Azione disponibile solo all’indirizzo di consegna.');
          if (j.status === 'rider_to_customer') setStatus(j, 'arrived_customer', 'rider');
          j.customer_wait_started_at ??= now();
          log(j, 'customer_unavailable', 'rider', { step: p.step ?? 'waiting' });
          a.market.internal.notifyCustomer(o, 'rider_waiting', 'Il Rider è arrivato', 'Il Rider è al tuo indirizzo e non riesce a trovarti: rispondi al telefono.');
          if (p.step === 'support') alert('customer_unavailable', j, r.id, `Ordine ${o.order_number}: cliente non disponibile, il Rider chiede supporto.`);
        } else if (action === 'delivered') {
          if (!['arrived_customer', 'rider_to_customer'].includes(j.status)) fail('Non puoi ancora completare questa consegna.');
          completeDelivery(r, j, p);
        } else if (action === 'fail') {
          if (!['arrived_customer', 'rider_to_customer', 'picked_up'].includes(j.status)) fail('Azione non disponibile.');
          const wait = num('customer_wait_minutes', 10);
          if (p.reason === 'customer_unavailable' && (!j.customer_wait_started_at || Date.parse(j.customer_wait_started_at) > Date.now() - wait * MIN)) {
            fail(`Attendi almeno ${wait} minuti e prova a chiamare il cliente prima di chiudere la consegna.`);
          }
          setStatus(j, 'failed', 'rider', { reason: p.reason ?? 'other' });
          j.failure_reason = String(p.reason ?? 'other').slice(0, 60);
          st().issues.push({ id: uuid(), delivery_job_id: j.id, reported_by_type: 'rider', reported_by_id: a.uid(), issue_type: String(p.reason ?? 'cannot_complete'),
            description: String(p.description ?? '').slice(0, 1000), status: 'open', created_at: now() });
          releaseCapacity(r.id);
          a.logEvent(j.restaurant_id, 'delivery_failed');
          a.market.internal.logE(o, 'delivery_failed', 'rider', { reason: p.reason });
          alert('delivery_failed', j, r.id, `Consegna ${o.order_number} non completata (${p.reason ?? 'altro'}): serve una decisione del supporto su ordine e rimborso.`);
        } else if (action === 'cancel') {
          if (!['assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(j.status)) fail('Hai già ritirato l’ordine: usa «Ho un problema» per contattare il supporto.');
          st().assignments.filter((x) => x.delivery_job_id === j.id && x.rider_id === r.id && x.status === 'accepted')
            .forEach((x) => Object.assign(x, { status: 'cancelled', responded_at: now(), rejection_reason: String(p.reason ?? 'rider_cancelled').slice(0, 60) }));
          setStatus(j, 'waiting_assignment', 'rider', { reason: 'rider_cancelled', detail: p.reason });
          Object.assign(j, { rider_id: null, accepted_at: null, arrived_at_restaurant_at: null, reassignment_count: j.reassignment_count + 1, dispatch_after: now() });
          releaseCapacity(r.id);
          audit('delivery_reassignment', j.id, { by: 'rider', rider_id: r.id, reason: p.reason }, null);
          a.market.internal.notifyRestaurant(o, `rider_cancelled:${j.reassignment_count}`, `Nuovo Rider in ricerca · ${o.order_number}`, 'Il Rider precedente non può più ritirare l’ordine: ne stiamo cercando un altro.');
          dispatch(j);
          return { id: j.id, status: 'released' };
        } else if (action === 'problem') {
          const id2 = uuid();
          st().issues.push({ id: id2, delivery_job_id: j.id, reported_by_type: 'rider', reported_by_id: a.uid(), issue_type: String(p.type ?? 'other'), description: String(p.description ?? '').slice(0, 1000), status: 'open', created_at: now() });
          log(j, 'problem_reported', 'rider', { type: p.type });
          alert('issue', j, r.id, `Il Rider segnala un problema (${p.type ?? 'altro'}) sull’ordine ${o.order_number}.`, `issue:${id2}`);
        } else fail('Azione non valida.');
        return riderJobView(j);
      } finally {
        a.market.internal.processRefunds(o);
        a.save();
      }
    },
    earnings(): RiderEarningsSummary {
      const r = riderOf() ?? fail('Non sei un Rider.');
      const list = st().earnings.filter((e) => e.rider_id === r.id);
      const live = list.filter((e) => e.status !== 'cancelled');
      const d = new Date();
      const day = d.toDateString();
      const weekStart = new Date(d.getFullYear(), d.getMonth(), d.getDate() - ((d.getDay() + 6) % 7)).getTime();
      const monthStart = new Date(d.getFullYear(), d.getMonth(), 1).getTime();
      const sum = (xs: typeof list) => round2(xs.reduce((s, e) => s + e.total, 0));
      return {
        today: sum(live.filter((e) => new Date(e.created_at).toDateString() === day)), week: sum(live.filter((e) => Date.parse(e.created_at) >= weekStart)),
        month: sum(live.filter((e) => Date.parse(e.created_at) >= monthStart)), to_pay: sum(list.filter((e) => ['pending', 'approved'].includes(e.status))),
        paid: sum(list.filter((e) => e.status === 'paid')), items: list.slice(0, 100),
      };
    },
    // Cliente e ristorante
    orderDelivery(numOrder: string, token: string | null): OrderDeliveryView | null {
      const o = a.market.internal.access(numOrder, token);
      if (!o) return null;
      refresh();
      const j = st().jobs.find((x) => x.order_id === o.id);
      if (!j) return { provider: o.delivery_provider_type ?? 'restaurant', job: null };
      const rd = riderById(j.rider_id);
      const showPos = ['picked_up', 'rider_to_customer', 'arrived_customer'].includes(j.status) && rd?.last_location_at && Date.parse(rd.last_location_at) > Date.now() - 3 * MIN;
      const rated = st().ratings.some((x) => x.delivery_job_id === j.id);
      return { provider: 'asiafood', job: {
        status: j.status,
        rider: rd && !['waiting_assignment', 'offered', 'cancelled'].includes(j.status) ? { name: `${rd.first_name} ${rd.last_name[0]}.`, vehicle_type: rd.vehicle_type, photo_url: rd.profile_photo_url } : null,
        rider_position: showPos ? { latitude: Math.round(rd!.last_latitude! * 1e5) / 1e5, longitude: Math.round(rd!.last_longitude! * 1e5) / 1e5, at: rd!.last_location_at! } : null,
        restaurant: { latitude: j.pickup_latitude, longitude: j.pickup_longitude, name: j.pickup_address_snapshot.name },
        destination: { latitude: j.delivery_latitude, longitude: j.delivery_longitude },
        eta_min_at: j.eta_delivery_min_at, eta_max_at: j.eta_delivery_max_at, eta_source: 'estimate', eta_updated_at: j.eta_updated_at,
        delivery_code: j.delivery_code_required && !FINAL.includes(j.status) ? j.delivery_code : null,
        accepted_at: j.accepted_at, picked_up_at: j.picked_up_at, arrived_at_customer_at: j.arrived_at_customer_at, delivered_at: j.delivered_at,
        can_rate: j.status === 'delivered' && !!o.user_id && o.user_id === a.uid() && !rated, rated,
      } };
    },
    rate(numOrder: string, rating: number, comment: string | null) {
      const uid = a.uid() ?? fail('Accedi per valutare la consegna.');
      const o = a.market.internal.access(numOrder, null);
      if (!o || o.user_id !== uid) fail('Ordine non trovato.');
      const j = st().jobs.find((x) => x.order_id === o!.id);
      if (!j || j.status !== 'delivered') fail('Puoi valutare solo una consegna completata.');
      if (!(rating >= 1 && rating <= 5)) fail('Voto non valido.');
      if (st().ratings.some((x) => x.delivery_job_id === j!.id)) fail('Hai già valutato questa consegna.');
      st().ratings.push({ id: uuid(), delivery_job_id: j!.id, rider_id: j!.rider_id, user_id: uid, rating, comment: comment?.trim().slice(0, 500) || null, created_at: now() });
      const rd = riderById(j!.rider_id);
      if (rd) {
        const rs = st().ratings.filter((x) => x.rider_id === rd.id);
        rd.rating_internal = Math.round((rs.reduce((s, x) => s + x.rating, 0) / rs.length) * 100) / 100;
      }
      a.save();
    },
    restaurantDeliveries(rid: string): RestaurantDelivery[] {
      if (!a.market.internal.canView(rid)) fail('Non autorizzato');
      refresh();
      return st().jobs.filter((j) => j.restaurant_id === rid && (!FINAL.includes(j.status) || Date.parse(j.updated_at) > Date.now() - 12 * 3600_000)).map((j) => {
        const rd = riderById(j.rider_id);
        return { order_id: j.order_id, job_id: j.id, status: j.status, pickup_code: j.pickup_code, rider: rd ? { name: `${rd.first_name} ${rd.last_name[0]}.`, vehicle_type: rd.vehicle_type } : null,
          eta_pickup_at: j.eta_pickup_at, arrived_at_restaurant_at: j.arrived_at_restaurant_at, picked_up_at: j.picked_up_at,
          searching_since: ['waiting_assignment', 'offered'].includes(j.status) ? j.created_at : null };
      });
    },
    // Admin
    adminRiders(f: { status?: string; q?: string } = {}): AdminRiderRow[] {
      assertAdmin();
      return st().riders.filter((r) => (!f.status || r.status === f.status) && (!f.q || `${r.first_name} ${r.last_name} ${r.city}`.toLowerCase().includes(f.q.toLowerCase())))
        .map((r) => ({ id: r.id, user_id: r.user_id, name: `${r.first_name} ${r.last_name}`, city: r.city, vehicle_type: r.vehicle_type, status: r.status, is_online: r.is_online,
          busy: r.current_capacity > 0, total_deliveries: r.total_deliveries, rating_internal: r.rating_internal, is_demo: r.is_demo,
          documents: st().documents.filter((d) => d.rider_id === r.id).length, documents_pending: st().documents.filter((d) => d.rider_id === r.id && d.status === 'pending').length,
          last_activity: r.updated_at, created_at: r.created_at }))
        .sort((x, y) => Date.parse(y.created_at) - Date.parse(x.created_at));
    },
    adminRiderDetail(id: string): AdminRiderDetail {
      assertAdmin();
      const r = riderById(id) ?? fail('Rider non trovato.');
      return { id: r.id, user_id: r.user_id, status: r.status, first_name: r.first_name, last_name: r.last_name, phone: r.phone, email: r.email, city: r.city, vehicle_type: r.vehicle_type,
        vehicle_details: r.vehicle_details, admin_notes: r.admin_notes, suspension_reason: r.suspension_reason, rejected_reason: r.rejected_reason, approved_at: r.approved_at,
        total_deliveries: r.total_deliveries, rating_internal: r.rating_internal, created_at: r.created_at,
        availability: { is_online: r.is_online, accepting_orders: r.accepting_orders, current_capacity: r.current_capacity, max_concurrent_deliveries: r.max_concurrent_deliveries, last_location_at: r.last_location_at },
        documents: st().documents.filter((d) => d.rider_id === r.id),
        recent_jobs: st().jobs.filter((j) => j.rider_id === r.id).slice(0, 20).map((j) => ({ id: j.id, status: j.status, order_number: order(j).order_number, restaurant: j.pickup_address_snapshot.name, accepted_at: j.accepted_at, delivered_at: j.delivered_at })),
        earnings: { pending: round2(st().earnings.filter((e) => e.rider_id === r.id && ['pending', 'approved'].includes(e.status)).reduce((s, e) => s + e.total, 0)),
          paid: round2(st().earnings.filter((e) => e.rider_id === r.id && e.status === 'paid').reduce((s, e) => s + e.total, 0)) },
        ratings: { count: st().ratings.filter((x) => x.rider_id === r.id).length, average: r.rating_internal },
        flags: st().alerts.filter((x) => x.rider_id === r.id).slice(0, 20).map((x) => ({ type: x.alert_type, message: x.message, created_at: x.created_at })) };
    },
    adminRiderAction(id: string, action: string, reason: string | null) {
      assertAdmin();
      const r = riderById(id) ?? fail('Rider non trovato.');
      if (action === 'approve') {
        if (!['pending', 'rejected', 'inactive'].includes(r.status)) fail('Il Rider non è in attesa di approvazione.');
        Object.assign(r, { status: 'approved', approved_at: now(), approved_by: a.uid(), rejected_reason: null });
        const p = a.db.profiles.find((x) => x.id === r.user_id);
        if (p && p.role === 'customer') (p as { role: string }).role = 'rider';
        a.notify(r.user_id, 'rider', 'Candidatura Rider approvata', 'Benvenuto nel team AsiaFood! Vai online quando vuoi ricevere consegne.', '/rider', { dedupe: `rider_approved:${r.id}` });
      } else if (action === 'reject') {
        if (r.status !== 'pending') fail('Solo le candidature in attesa possono essere rifiutate.');
        Object.assign(r, { status: 'rejected', rejected_reason: reason?.trim().slice(0, 300) || null });
        a.notify(r.user_id, 'rider', 'Candidatura Rider non approvata', reason?.trim() || 'La candidatura non è stata approvata.', '/rider/apply');
      } else if (action === 'suspend') {
        if ((reason ?? '').trim().length < 3) fail('Indica il motivo della sospensione.');
        Object.assign(r, { status: 'suspended', suspended_at: now(), suspension_reason: reason!.trim().slice(0, 300), is_online: false, accepting_orders: false, offline_since: now(),
          last_latitude: null, last_longitude: null, last_location_at: null });
        expireRiderOffers(r.id, 'suspended');
        for (const j of st().jobs.filter((x) => x.rider_id === r.id && ['assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(x.status))) {
          setStatus(j, 'waiting_assignment', 'admin', { reason: 'rider_suspended' });
          Object.assign(j, { rider_id: null, accepted_at: null, reassignment_count: j.reassignment_count + 1, dispatch_after: now() });
          dispatch(j);
        }
        releaseCapacity(r.id);
        a.notify(r.user_id, 'rider', 'Profilo Rider sospeso', reason!.trim().slice(0, 300), '/rider');
      } else if (action === 'reactivate') {
        if (!['suspended', 'inactive'].includes(r.status)) fail('Il Rider non è sospeso.');
        Object.assign(r, { status: 'approved', suspended_at: null, suspension_reason: null });
        a.notify(r.user_id, 'rider', 'Profilo Rider riattivato', 'Puoi tornare online.', '/rider');
      } else if (action === 'note') r.admin_notes = (reason ?? '').trim().slice(0, 2000);
      else fail('Azione non valida.');
      audit(`rider_${action}`, r.id, { reason });
      a.save();
    },
    adminReviewDocument(id: string, status: 'approved' | 'rejected' | 'expired', note: string | null) {
      assertAdmin();
      const d = st().documents.find((x) => x.id === id) ?? fail('Documento non trovato.');
      Object.assign(d, { status, review_note: note?.trim() || null });
      audit(`rider_document_${status}`, d.id);
      a.save();
    },
    dispatchBoard(): DispatchBoard {
      assertAdmin();
      refresh();
      return {
        jobs: st().jobs.filter((j) => !FINAL.includes(j.status)).map((j) => {
          const o = order(j);
          const rd = riderById(j.rider_id);
          return { id: j.id, status: j.status, order_number: o.order_number, order_status: o.status, restaurant: j.pickup_address_snapshot.name, restaurant_id: j.restaurant_id,
            pickup: { latitude: j.pickup_latitude, longitude: j.pickup_longitude }, dropoff: { latitude: j.delivery_latitude, longitude: j.delivery_longitude, area: j.delivery_address_snapshot.city ?? null },
            rider: rd ? { id: rd.id, name: `${rd.first_name} ${rd.last_name[0]}.` } : null, distance_km: j.estimated_distance_km, created_at: j.created_at, accepted_at: j.accepted_at,
            dispatch_attempts: j.dispatch_attempts, offer_expires_at: j.offer_expires_at, eta_max_at: j.eta_delivery_max_at, flags: j.flags, ready: o.status === 'ready',
            waiting_minutes: Math.round((Date.now() - Date.parse(j.created_at)) / MIN) };
        }),
        riders: st().riders.filter((r) => r.is_online).map((r) => ({ id: r.id, name: `${r.first_name} ${r.last_name[0]}.${r.bot ? ' (simulato)' : ''}`, vehicle_type: r.vehicle_type, city: r.city,
          status: r.status, accepting_orders: r.accepting_orders, capacity: r.current_capacity, max: r.max_concurrent_deliveries, busy: r.current_capacity > 0,
          latitude: r.last_latitude, longitude: r.last_longitude, location_at: r.last_location_at, online_since: r.online_since })),
        alerts: st().alerts.filter((x) => x.status !== 'resolved').slice(0, 50),
        auto_dispatch: bool('auto_dispatch_enabled', true), service_enabled: bool('enabled', true),
      };
    },
    assign(jobId: string, riderId: string) {
      assertAdmin();
      const j = jobById(jobId);
      if (!['waiting_assignment', 'offered', 'assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(j.status)) fail(`Questa consegna non può essere riassegnata (stato ${j.status}).`);
      const r = riderById(riderId);
      if (!r || !isRider(r)) fail('Rider non attivo.');
      if (!r!.is_online) fail('Il Rider è offline.');
      if (r!.current_capacity >= r!.max_concurrent_deliveries && j.rider_id !== r!.id) fail('Il Rider non ha capacità disponibile.');
      const prev = j.rider_id;
      st().assignments.filter((x) => x.delivery_job_id === j.id && ['offered', 'accepted'].includes(x.status)).forEach((x) => Object.assign(x, { status: 'cancelled', responded_at: now(), rejection_reason: 'admin' }));
      if (j.status !== 'waiting_assignment') setStatus(j, 'waiting_assignment', 'admin', { reason: 'manual_reassignment' });
      const q = quoteEarning(j);
      st().assignments.push({ id: uuid(), delivery_job_id: j.id, rider_id: r!.id, status: 'accepted', distance_to_pickup_km: km(r!.last_latitude, r!.last_longitude, j.pickup_latitude, j.pickup_longitude),
        estimated_earning: q.available ? q.total : null, manual: true, offered_at: now(), expires_at: now(), responded_at: now(), rejection_reason: null });
      Object.assign(j, { rider_id: r!.id, accepted_at: now(), offer_expires_at: null, reassignment_count: j.reassignment_count + (prev ? 1 : 0), flags: j.flags.filter((f) => f !== 'dispatch_exhausted') });
      eta(j);
      setStatus(j, 'assigned', 'admin', { manual: true, rider_id: r!.id, previous_rider_id: prev });
      releaseCapacity(r!.id);
      if (prev && prev !== r!.id) {
        releaseCapacity(prev);
        notifyRider(prev, 'Consegna riassegnata', 'Lo staff ha riassegnato una tua consegna non ancora ritirata.', '/rider', `unassigned:${j.id}:${prev}`);
      }
      const o = order(j);
      notifyRider(r!.id, 'Consegna assegnata', `Lo staff ti ha assegnato l’ordine ${o.order_number} (${j.pickup_address_snapshot.name}).`, `/rider/delivery/${j.id}`, `assigned:${j.id}:${r!.id}`);
      a.market.internal.notifyCustomer(o, 'rider_assigned', 'Rider assegnato', `${r!.first_name} ${r!.last_name[0]}. porterà il tuo ordine ${o.order_number}.`);
      audit(prev ? 'delivery_reassignment' : 'delivery_manual_assignment', j.id, { rider_id: r!.id, previous_rider_id: prev });
      st().alerts.filter((x) => x.delivery_job_id === j.id && x.status !== 'resolved' && ['no_rider', 'unassigned_too_long', 'dispatch_exhausted'].includes(x.alert_type)).forEach((x) => (x.status = 'resolved'));
      a.save();
    },
    jobAction(jobId: string, action: string, p: Row = {}) {
      assertAdmin();
      const j = jobById(jobId);
      if (action === 'redispatch') {
        if (j.status === 'offered') {
          st().assignments.filter((x) => x.delivery_job_id === j.id && x.status === 'offered').forEach((x) => Object.assign(x, { status: 'cancelled', responded_at: now(), rejection_reason: 'admin' }));
          setStatus(j, 'waiting_assignment', 'admin', { reason: 'redispatch' });
        }
        Object.assign(j, { flags: j.flags.filter((f) => f !== 'dispatch_exhausted'), dispatch_attempts: 0, dispatch_after: now() });
        dispatch(j, true);
      } else if (action === 'release') {
        if (!['assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(j.status)) fail('Rilascio possibile solo prima del ritiro.');
        const prev = j.rider_id;
        st().assignments.filter((x) => x.delivery_job_id === j.id && x.status === 'accepted').forEach((x) => Object.assign(x, { status: 'cancelled', responded_at: now(), rejection_reason: 'admin' }));
        setStatus(j, 'waiting_assignment', 'admin', { reason: 'released' });
        Object.assign(j, { rider_id: null, accepted_at: null, reassignment_count: j.reassignment_count + 1, dispatch_after: now() });
        releaseCapacity(prev);
        dispatch(j, true);
      } else if (action === 'mark_failed') {
        setStatus(j, 'failed', 'admin', { reason: p.reason });
        j.failure_reason = String(p.reason ?? 'admin').slice(0, 60);
        releaseCapacity(j.rider_id);
      } else if (action === 'mark_delivered') {
        if (!['picked_up', 'rider_to_customer', 'arrived_customer'].includes(j.status)) fail('La consegna non è stata ritirata.');
        if (j.status === 'picked_up') setStatus(j, 'rider_to_customer', 'admin');
        setStatus(j, 'delivered', 'admin', { manual: true, reason: p.reason });
        syncOrder(j, 'delivered');
        releaseCapacity(j.rider_id);
      } else if (action === 'cancel') {
        st().assignments.filter((x) => x.delivery_job_id === j.id && x.status === 'offered').forEach((x) => Object.assign(x, { status: 'cancelled', responded_at: now(), rejection_reason: 'admin' }));
        setStatus(j, 'cancelled', 'admin', { reason: p.reason });
        j.cancel_reason = String(p.reason ?? 'Annullata dallo staff').slice(0, 200);
        releaseCapacity(j.rider_id);
      } else fail('Azione non valida.');
      audit(`delivery_${action}`, j.id, { reason: p.reason });
      a.save();
    },
    jobDetail(idOrOrder: string): AdminJobDetail {
      assertAdmin();
      const j = st().jobs.find((x) => x.id === idOrOrder || x.order_id === idOrOrder) ?? fail('Consegna non trovata.');
      const o = order(j);
      const rd = riderById(j.rider_id);
      return {
        id: j.id, order_id: j.order_id, order_number: o.order_number, order_status: o.status, status: j.status, restaurant_id: j.restaurant_id,
        pickup_address_snapshot: j.pickup_address_snapshot, delivery_address_snapshot: j.delivery_address_snapshot, estimated_distance_km: j.estimated_distance_km,
        pickup_code: j.pickup_code, delivery_code_required: j.delivery_code_required, proof_type: j.proof_type, proof_photo_path: j.proof_photo_path, flags: j.flags,
        dispatch_attempts: j.dispatch_attempts, reassignment_count: j.reassignment_count, created_at: j.created_at, accepted_at: j.accepted_at, picked_up_at: j.picked_up_at,
        delivered_at: j.delivered_at, failure_reason: j.failure_reason, cancel_reason: j.cancel_reason, eta_delivery_min_at: j.eta_delivery_min_at, eta_delivery_max_at: j.eta_delivery_max_at,
        rider: rd ? { id: rd.id, name: `${rd.first_name} ${rd.last_name}`, phone: rd.phone, vehicle_type: rd.vehicle_type } : null,
        waiting_minutes: j.picked_up_at && j.arrived_at_restaurant_at ? Math.round((Date.parse(j.picked_up_at) - Date.parse(j.arrived_at_restaurant_at)) / 6000) / 10 : null,
        events: st().events.filter((e) => e.delivery_job_id === j.id).map((e) => ({ type: e.type, actor: e.actor, metadata: e.metadata, created_at: e.created_at })),
        assignments: st().assignments.filter((x) => x.delivery_job_id === j.id).map((x) => {
          const rr = riderById(x.rider_id);
          return { id: x.id, rider: rr ? `${rr.first_name} ${rr.last_name[0]}.` : '—', status: x.status, manual: x.manual, distance_to_pickup_km: x.distance_to_pickup_km,
            estimated_earning: x.estimated_earning, offered_at: x.offered_at, responded_at: x.responded_at, rejection_reason: x.rejection_reason };
        }),
        earnings: st().earnings.filter((e) => e.delivery_job_id === j.id).map((e) => ({ id: e.id, total: e.total, status: e.status, note: e.note, base_fee: e.base_fee, distance_fee: e.distance_fee, bonus: e.bonus, adjustment: e.adjustment })),
        issues: st().issues.filter((x) => x.delivery_job_id === j.id).map((x) => ({ id: x.id, issue_type: x.issue_type, description: x.description, status: x.status, reported_by_type: x.reported_by_type, created_at: x.created_at })),
        rating: (() => { const x = st().ratings.find((y) => y.delivery_job_id === j.id); return x ? { rating: x.rating, comment: x.comment } : null; })(),
        location_points: st().locations.filter((l) => l.job_id === j.id).length,
      };
    },
    earningAction(id: string, action: string, amount: number | null, note: string | null) {
      assertAdmin();
      const e = st().earnings.find((x) => x.id === id) ?? fail('Compenso non trovato.');
      if (action === 'approve') {
        if (e.status !== 'pending') fail('Compenso non in attesa.');
        Object.assign(e, { status: 'approved', approved_at: now() });
      } else if (action === 'mark_paid') {
        if (!['approved', 'pending'].includes(e.status)) fail('Compenso non pagabile.');
        Object.assign(e, { status: 'paid', paid_at: now(), approved_at: e.approved_at ?? now() });
      } else if (action === 'adjust') {
        if (e.status === 'paid') fail('Compenso già pagato: registra una rettifica separata.');
        if (amount == null || Math.abs(amount) > 200) fail('Importo della rettifica non valido.');
        if ((note ?? '').trim().length < 3) fail('Indica il motivo della rettifica.');
        Object.assign(e, { adjustment: round2(amount!), total: Math.max(0, round2(e.base_fee + e.distance_fee + e.bonus + amount!)), note: note!.trim() });
      } else if (action === 'bonus') {
        if (e.status === 'paid') fail('Compenso già pagato.');
        if (amount == null || amount < 0 || amount > 50) fail('Bonus non valido.');
        Object.assign(e, { bonus: round2(amount!), total: Math.max(0, round2(e.base_fee + e.distance_fee + amount! + e.adjustment)), note: note?.trim() || e.note });
      } else if (action === 'cancel') {
        if (e.status === 'paid') fail('Compenso già pagato.');
        e.status = 'cancelled';
      } else fail('Azione non valida.');
      audit(`earning_${action}`, e.id, { amount, note });
      a.save();
    },
    earningCreate(jobId: string, amount: number, note: string) {
      assertAdmin();
      const j = jobById(jobId);
      const riderId = j.rider_id ?? st().assignments.filter((x) => x.delivery_job_id === j.id && ['accepted', 'cancelled'].includes(x.status)).sort((x, y) => Date.parse(y.offered_at) - Date.parse(x.offered_at))[0]?.rider_id;
      if (!riderId) fail('Nessun Rider collegato a questa consegna.');
      if (!(amount > 0 && amount <= 100)) fail('Importo non valido.');
      if (note.trim().length < 3) fail('Indica il motivo.');
      st().earnings.unshift({ id: uuid(), rider_id: riderId!, delivery_job_id: j.id, total: round2(amount), base_fee: 0, distance_fee: 0, bonus: 0, adjustment: round2(amount),
        status: 'pending', note: note.trim(), created_at: now(), paid_at: null, approved_at: null, order_number: order(j).order_number });
      audit('earning_adjustment', j.id, { amount, note });
      a.save();
    },
    allEarnings() {
      assertAdmin();
      return st().earnings.map((e) => ({ ...e, rider_name: (() => { const r = riderById(e.rider_id); return r ? `${r.first_name} ${r.last_name}` : '—'; })() }));
    },
    setRestaurantLogistics(rid: string, enabled: boolean) {
      assertAdmin();
      const s = a.db.market?.order_settings.find((x) => x.restaurant_id === rid) ?? fail('Configura prima gli ordini online del ristorante.');
      s.asiafood_delivery_enabled = enabled;
      if (!enabled && s.delivery_provider_type === 'asiafood') s.delivery_provider_type = 'restaurant';
      audit('restaurant_asiafood_delivery', rid, { enabled });
      a.save();
    },
    stats(days = 30): LogisticsStats {
      assertAdmin();
      const from = Date.now() - days * 86_400_000;
      const js = st().jobs.filter((j) => Date.parse(j.created_at) >= from);
      const avg = (xs: number[]) => (xs.length ? Math.round((xs.reduce((s, x) => s + x, 0) / xs.length) * 10) / 10 : null);
      const diff = (x: string | null, y: string | null) => (x && y ? (Date.parse(x) - Date.parse(y)) / MIN : null);
      const nums = (f: (j: DemoJob) => number | null) => js.map(f).filter((x): x is number => x != null);
      const delivered = js.filter((j) => j.status === 'delivered');
      const onTime = delivered.filter((j) => {
        const ev = st().events.find((e) => e.delivery_job_id === j.id && e.type === 'assigned');
        const max = ev?.metadata.eta_max as string | undefined;
        return !max || Date.parse(j.delivered_at!) <= Date.parse(max) + 5 * MIN;
      }).length;
      const online = st().riders.filter((r) => r.is_online);
      const busy = online.filter((r) => r.current_capacity > 0).length;
      const offers = st().assignments.filter((x) => Date.parse(x.offered_at) >= from);
      const byRest = new Map<string, DemoJob[]>();
      js.filter((j) => j.picked_up_at && j.arrived_at_restaurant_at).forEach((j) => byRest.set(j.restaurant_id, [...(byRest.get(j.restaurant_id) ?? []), j]));
      return {
        definitions: { assignment_time: 'Minuti tra creazione del job e accettazione del Rider', pickup_time: 'Minuti tra accettazione e ritiro al ristorante',
          delivery_time: 'Minuti tra ritiro e consegna', on_time_rate: 'Consegne completate entro l’ETA massima calcolata all’accettazione (+5 min di tolleranza)',
          utilization: 'Rider online con almeno una consegna attiva / Rider online (istantaneo)', wait_time: 'Minuti di attesa del Rider al ristorante (arrivo → ritiro)' },
        active: st().jobs.filter((j) => ACTIVE.includes(j.status)).length, waiting_assignment: st().jobs.filter((j) => ['waiting_assignment', 'offered'].includes(j.status)).length,
        jobs_period: js.length, delivered: delivered.length, failed: js.filter((j) => j.status === 'failed').length, cancelled: js.filter((j) => j.status === 'cancelled').length,
        avg_assignment_minutes: avg(nums((j) => diff(j.accepted_at, j.created_at))), avg_pickup_minutes: avg(nums((j) => diff(j.picked_up_at, j.accepted_at))),
        avg_delivery_minutes: avg(nums((j) => diff(j.delivered_at, j.picked_up_at))), avg_wait_minutes: avg(nums((j) => diff(j.picked_up_at, j.arrived_at_restaurant_at))),
        on_time_rate: delivered.length ? Math.round((onTime / delivered.length) * 1000) / 1000 : null,
        riders_online: online.length, riders_busy: busy, utilization: online.length ? Math.round((busy / online.length) * 1000) / 1000 : null,
        riders_total: st().riders.filter((r) => ['approved', 'active'].includes(r.status)).length, riders_pending: st().riders.filter((r) => r.status === 'pending').length,
        offers: { sent: offers.filter((x) => !x.manual).length, accepted: offers.filter((x) => !x.manual && x.status === 'accepted').length,
          rejected: offers.filter((x) => x.status === 'rejected').length, expired: offers.filter((x) => x.status === 'expired').length },
        slow_restaurants: [...byRest.entries()].map(([rid, xs]) => ({ restaurant: xs[0]!.pickup_address_snapshot.name, deliveries: xs.length,
          avg_wait_minutes: avg(xs.map((j) => diff(j.picked_up_at, j.arrived_at_restaurant_at)!)) ?? 0,
          not_ready_reports: st().events.filter((e) => e.type === 'order_not_ready' && st().jobs.find((y) => y.id === e.delivery_job_id)?.restaurant_id === rid).length }))
          .sort((x, y) => y.avg_wait_minutes - x.avg_wait_minutes).slice(0, 10),
        open_alerts: st().alerts.filter((x) => x.status === 'open').length,
        earnings: { pending: round2(st().earnings.filter((e) => ['pending', 'approved'].includes(e.status)).reduce((s, e) => s + e.total, 0)),
          paid_period: round2(st().earnings.filter((e) => e.status === 'paid' && e.paid_at && Date.parse(e.paid_at) >= from).reduce((s, e) => s + e.total, 0)) },
      };
    },
    zones: () => st().zones,
    saveZone(z: Partial<ServiceZone>) {
      assertAdmin();
      if (!z.name?.trim() || z.center_latitude == null || z.center_longitude == null || !(Number(z.radius_km) > 0 && Number(z.radius_km) <= 60)) fail('Dati della zona non validi.');
      const ex = z.id ? st().zones.find((x) => x.id === z.id) : undefined;
      const row: ServiceZone = { id: ex?.id ?? uuid(), name: z.name!.trim(), city_id: z.city_id ?? null, center_latitude: Number(z.center_latitude), center_longitude: Number(z.center_longitude),
        radius_km: Number(z.radius_km), is_active: z.is_active ?? true };
      if (ex) Object.assign(ex, row);
      else st().zones.push(row);
      a.save();
      return row;
    },
    deleteZone(id: string) {
      assertAdmin();
      st().zones = st().zones.filter((z) => z.id !== id);
      a.save();
    },
    rules: () => st().rules,
    saveRule(k: Partial<CompensationRule>) {
      assertAdmin();
      if ([k.base_fee, k.per_km_fee, k.minimum_fee].some((x) => x == null || Number(x) < 0)) fail('Importi non validi.');
      const ex = k.id ? st().rules.find((x) => x.id === k.id) : undefined;
      const row: CompensationRule = { id: ex?.id ?? uuid(), city_id: k.city_id ?? null, base_fee: Number(k.base_fee), per_km_fee: Number(k.per_km_fee), minimum_fee: Number(k.minimum_fee),
        max_distance_fee: k.max_distance_fee == null ? null : Number(k.max_distance_fee), weather_bonus: k.weather_bonus ?? null, peak_bonus: k.peak_bonus ?? null,
        is_active: k.is_active ?? true, effective_from: k.effective_from ?? now(), effective_to: k.effective_to ?? null, note: k.note ?? null };
      if (ex) Object.assign(ex, row);
      else st().rules.unshift(row);
      a.save();
      return row;
    },
    settings(): LogisticsSettings {
      const out = { ...LOGISTICS_DEFAULTS } as Record<string, unknown>;
      for (const k of Object.keys(LOGISTICS_DEFAULTS)) {
        const v = a.db.settings[`logistics_${k}`];
        if (v !== undefined) out[k] = v;
      }
      return out as unknown as LogisticsSettings;
    },
    saveSettings(patch: Partial<LogisticsSettings>) {
      assertAdmin();
      for (const [k, v] of Object.entries(patch)) if (k in LOGISTICS_DEFAULTS) a.db.settings[`logistics_${k}`] = v;
      a.save();
    },
    alertUpdate(id: string, status: 'acknowledged' | 'resolved') {
      assertAdmin();
      const x = st().alerts.find((y) => y.id === id);
      if (x) x.status = status;
      a.save();
    },
    /** Solo DEMO: posiziona i Rider della flotta simulata vicino a un ristorante (per provare il dispatch). */
    riderByUser: (user: string) => riderOf(user),
  };
}

/** Stato iniziale DEMO: zone di Taranto, regola compensi, un Rider demo (offline), un candidato, flotta simulata online. */
export function logisticsDefaults(p: { riderUser: string; candidateUser: string; cities: { id: string; slug: string; name: string; latitude?: number | null; longitude?: number | null }[] }): LogisticsState {
  const tar = p.cities.find((c) => c.slug === 'taranto');
  const mas = p.cities.find((c) => c.slug === 'massafra');
  const t = '2026-09-20T09:00:00.000Z';
  const baseRider = (id: string, user: string, first: string, last: string, vehicle: VehicleType, status: RiderStatus, extra: Partial<DemoRider> = {}): DemoRider => ({
    id, user_id: user, status, first_name: first, last_name: last, phone: '+39 320 000 0000', email: `${first.toLowerCase()}@demo.local`, city: 'Taranto', city_id: tar?.id ?? null, zone_id: null,
    vehicle_type: vehicle, vehicle_details: null, profile_photo_url: null, terms_accepted_at: t, location_consent_at: status === 'pending' ? null : t, approved_at: status === 'pending' ? null : t,
    approved_by: null, suspended_at: null, suspension_reason: null, rejected_reason: null, admin_notes: null, rating_internal: null, total_deliveries: 0, is_demo: true, created_at: t,
    is_online: false, online_since: null, offline_since: t, accepting_orders: false, current_capacity: 0, max_concurrent_deliveries: 1, last_latitude: null, last_longitude: null,
    last_accuracy: null, last_location_at: null, last_moved_at: null, last_offer_at: null, updated_at: t, ...extra,
  });
  const lat0 = tar?.latitude ?? 40.4644;
  const lng0 = tar?.longitude ?? 17.247;
  return {
    zones: [
      { id: '0b000000-0000-4000-8000-000000000001', name: 'Taranto città', city_id: tar?.id ?? null, center_latitude: lat0, center_longitude: lng0, radius_km: 9, is_active: true },
      { id: '0b000000-0000-4000-8000-000000000002', name: 'Provincia di Taranto (area ovest)', city_id: mas?.id ?? null, center_latitude: mas?.latitude ?? 40.5889, center_longitude: mas?.longitude ?? 17.117, radius_km: 12, is_active: true },
    ],
    rules: [{ id: '0c000000-0000-4000-8000-000000000001', city_id: null, base_fee: 3, per_km_fee: 0.6, minimum_fee: 4, max_distance_fee: 6, weather_bonus: null, peak_bonus: null, is_active: true,
      effective_from: '2026-09-01T00:00:00.000Z', effective_to: null, note: 'Regola base iniziale (tutte le città)' }],
    riders: [
      baseRider('0d000000-0000-4000-8000-000000000001', p.riderUser, 'Rider', 'Demo', 'scooter', 'approved', { email: 'rider@demo.local', phone: '+39 320 111 2233', location_consent_at: null }),
      baseRider('0d000000-0000-4000-8000-000000000002', p.candidateUser, 'Giulia', 'Candidata', 'e-bike', 'pending', { email: 'candidata@demo.local', location_consent_at: null }),
      // Flotta SIMULATA (dichiarata come tale ovunque): lontana dal centro, così il Rider demo reale viene servito per primo
      baseRider('0d000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-0000000b0701', 'Flotta', 'Simulata Uno', 'scooter', 'active', { bot: true, is_online: true, accepting_orders: true, online_since: t }),
      baseRider('0d000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-0000000b0702', 'Flotta', 'Simulata Due', 'e-bike', 'active', { bot: true, is_online: true, accepting_orders: true, online_since: t }),
    ],
    documents: [{ id: '0e000000-0000-4000-8000-000000000001', rider_id: '0d000000-0000-4000-8000-000000000002', document_type: 'identity', storage_path: `${p.candidateUser}/demo-carta-identita.pdf`,
      status: 'pending', expires_at: '2031-05-01', uploaded_at: t, review_note: null }],
    locations: [], jobs: [], assignments: [], earnings: [], ratings: [], issues: [], events: [], alerts: [], audit: [],
  };
}
