// ─────────────────────────────────────────────────────────────
//  Client dell'assistente (produzione): POST /api/ai/chat.
//  Il browser NON chiama mai il provider AI e non conosce chiavi:
//  invia solo il messaggio, un ID di sessione casuale, il JWT
//  (se l'utente ha fatto accesso) e, se consentita, la posizione.
// ─────────────────────────────────────────────────────────────
import { AI } from '@/config/app';
import { supabase } from '@/lib/supabase';
import { AiError } from '@/types/ai';
import { readApiError } from '@/lib/errors';

const DEFAULT_MESSAGE = 'L’assistente non è disponibile in questo momento. Puoi continuare a usare la ricerca.';

export async function aiCall<T>(body: Record<string, unknown>, signal?: AbortSignal): Promise<T> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) throw new AiError('OFFLINE', 'L’assistente richiede una connessione internet.');
  const token = supabase ? (await supabase.auth.getSession()).data.session?.access_token : null;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), AI.timeoutMs);
  signal?.addEventListener('abort', () => ctrl.abort(), { once: true });
  let res: Response;
  try {
    res = await fetch(AI.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
  } catch {
    if (signal?.aborted) throw new AiError('ABORTED', 'Richiesta annullata.');
    if (ctrl.signal.aborted) throw new AiError('TIMEOUT', 'La risposta sta impiegando troppo tempo.');
    throw new AiError(navigator.onLine === false ? 'OFFLINE' : 'NETWORK', navigator.onLine === false ? 'L’assistente richiede una connessione internet.' : 'Connessione non disponibile. Riprova.');
  } finally {
    clearTimeout(timer);
  }
  let json: unknown;
  try {
    json = await res.json();
  } catch {
    json = null;
  }
  if (!res.ok) {
    const e = readApiError(json, res.status, DEFAULT_MESSAGE);
    throw new AiError(res.status === 404 && e.code.startsWith('HTTP_') ? 'NOT_CONFIGURED' : e.code, e.message, res.status);
  }
  return json as T;
}
