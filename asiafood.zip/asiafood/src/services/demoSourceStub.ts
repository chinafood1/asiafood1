// ─────────────────────────────────────────────────────────────
//  Build di produzione/staging con Supabase: il database DEMO (dati di fantasia, motori simulati)
//  NON viene incluso nel bundle (vite.config.ts → alias). Stesse esportazioni, nessun dato.
// ─────────────────────────────────────────────────────────────
import type { DataSource } from './types';
import type { Profile } from '@/types/domain';

export const DEMO_USERS = {
  admin: '', owner: '', customer: '', rider: '', riderCandidate: '',
} as const;

const unavailable = () => {
  throw new Error('Modalità DEMO non disponibile in questa build.');
};
export const demoSource = new Proxy({ mode: 'demo' } as DataSource, {
  get: (t, k) => (k === 'mode' ? 'demo' : k in t ? (t as unknown as Record<string | symbol, unknown>)[k] : unavailable),
});
export const resetDemoData = unavailable;
export const getDemoProfile = (id: string): Profile | undefined => (void id, undefined);
export const upsertDemoProfile = (p: Profile) => void p;
export const setDemoPushHandler = (fn: unknown) => void fn;
