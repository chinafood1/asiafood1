// ─────────────────────────────────────────────────────────────
//  Fase 13 · Growth API su Supabase: RPC delle migrazioni 0025–0027.
//  Nessuna query libera: ogni dashboard chiama una RPC con controllo Admin nel database.
// ─────────────────────────────────────────────────────────────
import { supabase } from '@/lib/supabase';
import { fromDbMessage } from '@/lib/errors';
import type { GrowthApi } from '@/types/growth';
import { consentedSessionId } from '@/lib/trackContext';

async function call<T>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  if (!supabase) throw new Error('Supabase non configurato');
  const { data, error } = await supabase.rpc(fn, args);
  if (error) {
    const coded = fromDbMessage(error.message);
    if (coded) throw coded;
    if (error.code === '42501' || /permission denied/i.test(error.message)) throw new Error('Operazione non consentita.');
    throw new Error(error.message);
  }
  return data as T;
}
const quiet = (p: Promise<unknown>) => void p.then(() => undefined, () => undefined);
const mk = (m?: string | null) => m || null;

export const growthSupabase: GrowthApi = {
  overview: (from, to, market) => call('admin_growth_overview', { p_from: from, p_to: to, p_market: mk(market) }),
  funnels: (from, to, market) => call('admin_growth_funnels', { p_from: from, p_to: to, p_market: mk(market) }),
  retention: (weeks = 8) => call('admin_growth_retention', { p_weeks: weeks }),
  restaurants: (p) => call('admin_growth_restaurants', { p_from: p.from, p_to: p.to, p_market: mk(p.market), p_status: p.status || null, p_search: p.search || null,
    p_limit: p.limit ?? 50, p_offset: p.offset ?? 0 }),
  churn: (from, to) => call('admin_growth_churn', { p_from: from, p_to: to }),
  revenue: (from, to) => call('admin_growth_revenue', { p_from: from, p_to: to }),
  acquisition: (from, to) => call('admin_growth_acquisition', { p_from: from, p_to: to }),
  search: (from, to, market) => call('admin_growth_search', { p_from: from, p_to: to, p_market: mk(market) }),
  engagement: (from, to) => call('admin_growth_engagement', { p_from: from, p_to: to }),
  voice: (from, to) => call('admin_growth_voice', { p_from: from, p_to: to }),
  setFeedbackCategory: async (id, category) => void (await call('admin_feedback_set_category', { p_id: id, p_category: category })),
  segments: () => call('admin_growth_segments'),
  markets: () => call('admin_growth_markets'),
  startResearch: (slug) => call('admin_expansion_start_research', { p_slug: slug }),
  playbook: (market) => call('admin_market_playbook', { p_market: market }),
  setPlaybookItem: async (id, done) => void (await call('admin_playbook_item_set', { p_id: id, p_done: done })),
  marketReview: (market = 'taranto') => call('admin_growth_market_review', { p_market: market }),
  alerts: (status = 'open') => call('admin_growth_alerts', { p_status: status }),
  setAlert: async (id, status) => void (await call('admin_growth_alert_set', { p_id: id, p_status: status })),
  refreshAlerts: () => call('admin_growth_alerts_refresh'),
  automationRules: () => call('admin_automation_rules'),
  updateAutomationRule: async (id, patch) => void (await call('admin_automation_rule_update', { p_id: id, p: patch })),
  runAutomation: (id, dryRun = false) => call('admin_automation_run_now', { p_id: id, p_dry_run: dryRun }),
  setKillSwitch: async (on) => void (await call('admin_automation_kill_switch', { p_on: on })),
  automationRuns: (ruleId) => call('admin_automation_runs', { p_rule: ruleId ?? null, p_limit: 50 }),
  automationItems: (status = 'pending_approval') => call('admin_automation_items', { p_status: status, p_limit: 100 }),
  decideAutomationItem: (id, approve) => call('admin_automation_decide', { p_id: id, p_approve: approve }),
  experiments: () => call('admin_experiments'),
  upsertExperiment: (p) => call('admin_experiment_upsert', { p }),
  setExperimentStatus: async (id, status) => void (await call('admin_experiment_set_status', { p_id: id, p_status: status })),
  reviewExperiment: async (id, note) => void (await call('admin_experiment_review', { p_id: id, p_note: note })),
  experimentReport: (id) => call('admin_experiment_report', { p_id: id }),
  reports: () => call('admin_growth_reports', { p_limit: 20 }),
  generateReport: (type, from, to, market) => call('admin_growth_generate_report', { p_type: type, p_from: from, p_to: to, p_market: mk(market) }),
  today: () => call('admin_growth_today'),
  tasks: (status = 'open') => call('admin_growth_tasks', { p_status: status }),
  upsertTask: (p) => call('admin_growth_task_upsert', { p }),
  setTaskStatus: async (id, status) => void (await call('admin_growth_task_set_status', { p_id: id, p_status: status })),
  learnings: () => call('admin_growth_learnings'),
  learningEvidence: (market = 'taranto') => call('admin_growth_learning_evidence', { p_market: market }),
  upsertLearning: (p) => call('admin_growth_learning_upsert', { p }),
  deleteLearning: async (id) => void (await call('admin_growth_learning_delete', { p_id: id })),
  costs: (from, to) => call('admin_growth_costs', { p_from: from, p_to: to }),
  addCost: (p) => call('admin_operating_cost_add', { p }),
  deleteCost: async (id) => void (await call('admin_operating_cost_delete', { p_id: id })),
  settings: () => call('admin_growth_settings'),
  setSetting: async (key, value) => void (await call('admin_growth_setting_set', { p_key: key, p_value: value })),
  backfill: (from, to) => call('growth_backfill', { p_from: from, p_to: to }),
  performance: (restaurantId) => call('restaurant_performance', { p_restaurant: restaurantId }),
  logSearch: (p) => quiet(call('log_search', { p: { ...p, session_id: p.session_id ?? consentedSessionId() } })),
  experimentAssign: (key, variant, anon) => quiet(call('experiment_assign', { p_key: key, p_variant: variant, p_anon: anon })),
  experimentGoal: (metric, anon) => quiet(call('experiment_goal', { p_metric: metric, p_anon: anon })),
};
