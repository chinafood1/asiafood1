import { isSupabaseConfigured } from '@/config/app';
import { demoSource } from './demoSource';
import { supabaseSource } from './supabaseSource';
import type { DataSource } from './types';

/** Punto d'accesso unico ai dati. Il resto dell'app non sa quale backend c'è sotto. */
export const api: DataSource = isSupabaseConfigured ? supabaseSource : demoSource;
export const isDemoMode = api.mode === 'demo';

export * from './types';
