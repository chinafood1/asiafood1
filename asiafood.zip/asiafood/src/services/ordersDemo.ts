// ─────────────────────────────────────────────────────────────
//  Fase 8 in modalità DEMO: stesse regole delle funzioni SQL
//  (order_quote_core, order_create, order_transition, rimborsi,
//  tracking con token) applicate al database locale di prova.
//  Pagamento SIMULATO: nessun addebito, nessun dato di carta salvato.
// ─────────────────────────────────────────────────────────────
import type { AppNotification, Coupon, CouponClaim, Menu, MenuCategory, MenuItem, MenuItemAddon, MenuItemVariant, Profile, Restaurant, RestaurantClosure, RestaurantHour } from '@/types/domain';
import type {
  AddressInput, AdminOrderDetail, AdminOrderFilters, AdminOrderRow, CommissionSettings, CustomerAddress, DeliveryZone, MarketplaceStats, MenuOptionGroup,
  MyOrderSummary, OrderError, OrderPublicInfo, OrderStatus, OrderType, OrderView, OrderableRestaurant, OrdersTickResult, PaymentStatus, PayoutStatus,
  Quote, QuoteInput, QuoteLine, RestaurantOrder, RestaurantOrderSettings, RestaurantOrderStats, RestaurantOrdersPage, RestaurantOrderTab, Slot, CheckoutResult,
  IssueType, RejectReason,
} from '@/types/orders';
import { REJECT_REASONS } from '@/types/orders';
import { haversineKm } from '@/lib/geo';
import { openState } from '@/lib/hours';

type Row = Record<string, unknown>;
const now = () => new Date().toISOString();
const uuid = () => crypto.randomUUID();
const round2 = (n: number) => Math.round(n * 100) / 100;
const MIN = 60_000;
const DAY = 86_400_000;
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const code = (len: number) => Array.from(crypto.getRandomValues(new Uint8Array(len)), (b) => CODE_CHARS[b % 32]).join('');
const tz = 'Europe/Rome';
/** Hash non reversibile (demo, sincrono): come in Supabase, l'ordine conserva solo l'hash del token ospite. */
function demoHash(str: string): string {
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57, h3 = 0x9e3779b9, h4 = 0x85ebca6b;
  for (let i = 0; i < str.length; i++) {
    const c = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); h3 = Math.imul(h3 ^ c, 2246822507); h4 = Math.imul(h4 ^ c, 3266489909);
  }
  const mix = (a: number, b: number) => (Math.imul(a ^ (a >>> 16), 2246822507) ^ Math.imul(b ^ (b >>> 13), 3266489909)) >>> 0;
  return [mix(h1, h2), mix(h2, h3), mix(h3, h4), mix(h4, h1)].map((x) => x.toString(16).padStart(8, '0')).join('');
}
/** Token ospite derivato (come l'HMAC del server): segreto locale + id ordine, mai salvato in chiaro sull'ordine. */
const deriveToken = (secret: string, orderId: string) => {
  let out = '';
  for (let i = 0; out.length < 32; i++) out += demoHash(`${secret}:order:${orderId}:${i}`);
  return Array.from(out.slice(0, 32), (ch, i) => CODE_CHARS[(parseInt(ch, 16) + i * 7) % 32]).join('');
};
const romeDate = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(d);
/** "YYYY-MM-DDTHH:mm" ora locale di Roma → istante UTC. */
function romeLocalToUtc(date: string, time: string): Date {
  const guess = new Date(`${date}T${time}:00Z`);
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).formatToParts(guess);
  const g = (t: string) => Number(parts.find((p) => p.type === t)?.value);
  const asLocal = Date.UTC(g('year'), g('month') - 1, g('day'), g('hour') % 24, g('minute'));
  return new Date(guess.getTime() - (asLocal - guess.getTime()));
}
const hhmmRome = (d: Date) => new Intl.DateTimeFormat('it-IT', { timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false }).format(d);

export interface DemoOrder {
  id: string;
  order_number: string;
  restaurant_id: string;
  user_id: string | null;
  session_id: string | null;
  access_token_hash: string;
  idempotency_key: string | null;
  order_type: OrderType;
  status: OrderStatus;
  payment_status: PaymentStatus;
  fulfillment_status: OrderView['fulfillment_status'];
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  delivery_address_id: string | null;
  delivery_address: (AddressInput & Row) | null;
  delivery_distance_km: number | null;
  delivery_zone_id: string | null;
  subtotal: number;
  discount_total: number;
  coupon_discount: number;
  loyalty_discount: number;
  delivery_fee: number;
  service_fee: number;
  total: number;
  coupon_id: string | null;
  coupon_code: string | null;
  coupon_claim_id: string | null;
  reward_redemption_id: string | null;
  commission_percent: number;
  commission_fixed: number;
  platform_fee: number;
  restaurant_gross: number;
  restaurant_net_estimated: number;
  amount_paid: number;
  amount_refunded: number;
  payment_failures: number;
  paid_at: string | null;
  scheduled_for: string | null;
  slot_at: string | null;
  preparation_minutes: number | null;
  estimated_ready_at: string | null;
  estimated_delivery_at: string | null;
  customer_notes: string | null;
  restaurant_notes: string | null;
  internal_notes: string | null;
  /** Fase 9: chi consegna (snapshot dalle impostazioni al momento dell'ordine). */
  delivery_provider_type?: string;
  reject_reason: string | null;
  cancel_reason: string | null;
  risk_flags: string[];
  source: string;
  created_at: string;
  accepted_at: string | null;
  rejected_at: string | null;
  preparing_at: string | null;
  ready_at: string | null;
  picked_up_at: string | null;
  out_for_delivery_at: string | null;
  completed_at: string | null;
  cancelled_at: string | null;
  items: OrderView['items'];
  events: { type: string; actor: string; metadata: Row; created_at: string }[];
  refunds: { id: string; amount: number; reason: string; status: 'pending' | 'processing' | 'succeeded' | 'failed' | 'cancelled'; requested_by_type: string; created_at: string; processed_at: string | null; stripe_refund_id: string | null; error: string | null }[];
  issues: { id: string; type: IssueType; description: string; status: string; resolution: string | null; user_id: string | null; created_at: string }[];
}

export interface MarketState {
  order_settings: RestaurantOrderSettings[];
  delivery_zones: DeliveryZone[];
  option_groups: MenuOptionGroup[];
  orders: DemoOrder[];
  addresses: CustomerAddress[];
  carts: { user_id: string; restaurant_id: string; status: 'active' | 'converted' | 'abandoned' | 'cleared'; updated_at: string; payload: Row }[];
  payout_accounts: { restaurant_id: string; stripe_account_id: string; onboarding_completed: boolean; charges_enabled: boolean; payouts_enabled: boolean; details_submitted: boolean; requirements_due: string[]; updated_at: string }[];
  commissions: { id: string; restaurant_id: string; percentage_fee: number; fixed_fee: number; effective_from: string; note: string | null; created_at: string }[];
  track_failures: { order_number: string; at: number }[];
  /** Segreto locale per derivare i token ospite (equivalente di ORDER_TOKEN_SECRET). */
  token_secret?: string;
}

export interface MarketAccess {
  db: {
    settings: Record<string, unknown>;
    profiles: Profile[];
    restaurants: Restaurant[];
    restaurant_hours: RestaurantHour[];
    restaurant_closures: RestaurantClosure[];
    restaurant_members: { restaurant_id: string; user_id: string; role: string; status: string }[];
    restaurant_categories: { restaurant_id: string; category_id: string; is_primary?: boolean }[];
    categories: { id: string; name: string }[];
    cities: { id: string; name: string }[];
    menus: Menu[];
    menu_categories: MenuCategory[];
    menu_items: MenuItem[];
    menu_item_variants: MenuItemVariant[];
    menu_item_addons: MenuItemAddon[];
    coupons: Coupon[];
    coupon_claims: CouponClaim[];
    notifications: AppNotification[];
    analytics: { restaurant_id: string | null; event_type: string; source?: string | null; created_at: string; session_id?: string }[];
    engagement?: { reward_redemptions: { id: string; coupon_claim_id: string | null; status: string; redeemed_at: string | null }[] };
    market?: MarketState;
  };
  defaults(): MarketState;
  save(): void;
  uid(): string | null;
  isAdmin(): boolean;
  canManage(restaurantId: string): boolean;
  hasFeature(restaurantId: string, key: string): boolean;
  isPublic(restaurantId: string): boolean;
  notify(user: string | null, type: string, title: string, body: string, link: string | null, o?: { dedupe?: string; meta?: Row; restaurant?: string | null; email?: string; emailPayload?: Row }): unknown;
  notifyAdmins(type: string, title: string, body: string, link: string): void;
  enqueueEmail(event: string, recipient: string | null, payload: Row): void;
  logEvent(restaurantId: string, type: string): void;
  orderCompleted(o: { id: string; user_id: string | null; restaurant_id: string }): void;
  /** Fase 9: logistica Rider (collegata dopo la creazione del mercato). */
  logistics?: LogisticsHooks;
}

export interface LogisticsHooks {
  /** null = consegna AsiaFood disponibile, altrimenti il messaggio per il cliente. */
  serviceCheck(restaurantId: string, lat: number, lng: number): string | null;
  onOrderStatus(o: DemoOrder, prev: OrderStatus): void;
  hasActiveJob(orderId: string): boolean;
}

class DemoError extends Error {
  constructor(message: string, readonly errors?: OrderError[]) {
    super(message);
  }
}
const fail = (msg: string): never => {
  throw new DemoError(msg);
};
const err = (code: string, message: string, extra: Partial<OrderError> = {}): OrderError => ({ code, message, ...extra });
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const PHONE_RE = /^\+?[0-9 ().-]{6,20}$/;
const ACTIVE: OrderStatus[] = ['pending_restaurant', 'accepted', 'preparing', 'ready', 'out_for_delivery'];

export function createMarket(a: MarketAccess) {
  const st = (): MarketState => {
    const m = (a.db.market ??= a.defaults());
    if (!m.token_secret) {
      m.token_secret = code(32);
      // Dati salvati da versioni precedenti della demo: token in chiaro → solo hash
      for (const o of m.orders as (DemoOrder & { access_token?: string })[]) {
        if (o.access_token) { o.access_token_hash = demoHash(o.access_token); delete o.access_token; }
      }
    }
    return m;
  };
  const tokenFor = (orderId: string) => deriveToken(st().token_secret!, orderId);
  const setting = (k: string, d: number) => (typeof a.db.settings[k] === 'number' ? (a.db.settings[k] as number) : d);
  const flag = (k: string, d: boolean) => (typeof a.db.settings[k] === 'boolean' ? (a.db.settings[k] as boolean) : d);
  const rest = (id: string) => a.db.restaurants.find((r) => r.id === id);
  const settingsOf = (rid: string) => st().order_settings.find((s) => s.restaurant_id === rid) ?? null;
  const memberRole = (rid: string, user = a.uid()) =>
    a.db.restaurant_members.find((m) => m.restaurant_id === rid && m.user_id === user && m.status === 'active')?.role ?? null;
  const canView = (rid: string) => a.isAdmin() || ['owner', 'manager', 'staff'].includes(memberRole(rid) ?? '');
  const canRefund = (rid: string) => a.isAdmin() || ['owner', 'manager'].includes(memberRole(rid) ?? '');
  const prep = (s: RestaurantOrderSettings) => s.default_preparation_minutes + (s.busy_extra_minutes ?? 0);

  // ─── Orari ────────────────────────────────────────────────
  const openAt = (rid: string, at: Date): 'open' | 'closed' | 'unknown' => {
    const r = rest(rid);
    if (!r) return 'unknown';
    if (r.is_permanently_closed || r.is_temporarily_closed) return 'closed';
    const date = romeDate(at);
    const time = hhmmRome(at);
    if (a.db.restaurant_closures.some((c) => c.restaurant_id === rid && c.date === date && (!c.start_time || (time >= c.start_time.slice(0, 5) && time < (c.end_time ?? '').slice(0, 5))))) return 'closed';
    const hours = a.db.restaurant_hours.filter((h) => h.restaurant_id === rid);
    if (!hours.length) return 'unknown';
    return openState(hours, r.timezone || tz, at).kind === 'open' ? 'open' : 'closed';
  };
  const typeState = (s: RestaurantOrderSettings | null, t: OrderType, at = Date.now()): 'ok' | 'paused' | 'disabled' => {
    if (!s || !s.orders_enabled) return 'disabled';
    if (t === 'takeaway' && !s.takeaway_enabled) return 'disabled';
    if (t === 'delivery' && !s.delivery_enabled) return 'disabled';
    const paused = (v: string | null) => !!v && (v === 'infinity' || Date.parse(v) > at);
    if (paused(s.orders_paused_until) || (t === 'takeaway' && paused(s.takeaway_paused_until)) || (t === 'delivery' && paused(s.delivery_paused_until))) return 'paused';
    return 'ok';
  };
  const slotStart = (at: Date, interval: number) => new Date(Math.floor(at.getTime() / (interval * MIN)) * interval * MIN);
  const slotCount = (rid: string, slot: Date) =>
    st().orders.filter((o) => o.restaurant_id === rid && o.slot_at && Date.parse(o.slot_at) === slot.getTime() && !['rejected', 'cancelled'].includes(o.status)
      && (o.status !== 'pending_payment' || Date.parse(o.created_at) > Date.now() - 20 * MIN)).length;

  function slotsFor(rid: string, date: string, t: OrderType): Slot[] {
    const s = settingsOf(rid);
    if (!s || !a.isPublic(rid) || typeState(s, t) === 'disabled') return [];
    const today = romeDate();
    const last = romeDate(new Date(Date.now() + s.max_advance_days * DAY));
    if (date < today || date > last) return [];
    const delivery = t === 'delivery' ? s.delivery_estimated_minutes : 0;
    const earliest = Date.now() + (prep(s) + delivery) * MIN;
    const out: Slot[] = [];
    for (let m = 0; m < 24 * 60; m += s.slot_interval_minutes) {
      const at = romeLocalToUtc(date, `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`);
      if (at.getTime() < earliest) continue;
      if (openAt(rid, new Date(at.getTime() - delivery * MIN)) !== 'open') continue;
      if (typeState(s, t, at.getTime()) === 'paused') continue;
      const full = s.max_orders_per_slot != null && slotCount(rid, slotStart(at, s.slot_interval_minutes)) >= s.max_orders_per_slot;
      out.push({ at: at.toISOString(), time: hhmmRome(at), status: full ? 'full' : 'available' });
    }
    return out;
  }
  function nextSlot(rid: string, t: OrderType): Slot | null {
    const s = settingsOf(rid);
    if (!s) return null;
    for (let i = 0; i <= Math.min(s.max_advance_days, 7); i++) {
      const d = romeDate(new Date(Date.now() + i * DAY));
      const x = slotsFor(rid, d, t).find((y) => y.status === 'available');
      if (x) return { ...x, date: d };
    }
    return null;
  }

  // ─── Pagamenti (Connect simulato) e commissioni ───────────
  const paymentSetup = (rid: string) => {
    const acct = st().payout_accounts.find((p) => p.restaurant_id === rid && p.charges_enabled);
    return acct ? { ready: true, mode: 'demo' as const, destination: acct.stripe_account_id } : { ready: false, mode: null, destination: null };
  };
  const commissionFor = (rid: string) => {
    const o = [...st().commissions].filter((c) => c.restaurant_id === rid && Date.parse(c.effective_from) <= Date.now()).sort((x, y) => y.effective_from.localeCompare(x.effective_from))[0];
    return o ? { percent: o.percentage_fee, fixed: o.fixed_fee } : { percent: setting('platform_commission_percent', 10), fixed: setting('platform_commission_fixed', 0) };
  };

  // ─── Codici sconto ────────────────────────────────────────
  function validateCode(rid: string, raw: string, user: string | null, email: string | null, subtotal: number) {
    const c0 = raw.replace(/\s+/g, '').toUpperCase();
    if (!/^[A-Z0-9-]{3,40}$/.test(c0)) return { ok: false as const, code: c0, error: 'COUPON_INVALID', message: 'Codice non valido.' };
    const claim = a.db.coupon_claims.find((c) => c.claim_code === c0 && c.restaurant_id === rid);
    let coupon: Coupon | undefined;
    let reward: { id: string } | undefined;
    if (claim) {
      if (claim.status !== 'claimed') return { ok: false as const, code: c0, error: 'COUPON_USED', message: 'Questo codice è già stato utilizzato o è scaduto.' };
      if (!((user && claim.user_id === user) || (!claim.user_id && email && claim.email?.toLowerCase() === email.toLowerCase()))) {
        return { ok: false as const, code: c0, error: 'COUPON_NOT_YOURS', message: 'Questo codice personale appartiene a un altro account.' };
      }
      coupon = a.db.coupons.find((x) => x.id === claim.coupon_id);
      reward = a.db.engagement?.reward_redemptions.find((x) => x.coupon_claim_id === claim.id);
    } else {
      coupon = a.db.coupons.find((x) => x.restaurant_id === rid && x.code.toUpperCase() === c0);
    }
    if (!coupon) return { ok: false as const, code: c0, error: 'COUPON_INVALID', message: 'Codice sconto non valido per questo ristorante.' };
    const t = Date.now();
    if (!coupon.is_active || Date.parse(coupon.valid_from) > t || (coupon.valid_until && Date.parse(coupon.valid_until) <= t) || !a.hasFeature(rid, 'coupons_enabled')) {
      return { ok: false as const, code: c0, error: 'COUPON_EXPIRED', message: 'Il codice sconto non è attivo o è scaduto.' };
    }
    if (coupon.max_redemptions != null && coupon.redemptions_count >= coupon.max_redemptions) {
      return { ok: false as const, code: c0, error: 'COUPON_EXHAUSTED', message: 'Il codice sconto ha raggiunto il numero massimo di utilizzi.' };
    }
    if (!claim) {
      const used = st().orders.filter((o) => o.coupon_id === coupon!.id && ['paid', 'partially_refunded', 'refunded'].includes(o.payment_status) && !['rejected', 'cancelled'].includes(o.status)
        && ((user && o.user_id === user) || (email && o.customer_email.toLowerCase() === email.toLowerCase()))).length
        + a.db.coupon_claims.filter((y) => y.coupon_id === coupon!.id && y.status === 'redeemed' && ((user && y.user_id === user) || (email && y.email?.toLowerCase() === email.toLowerCase()))).length;
      if (used >= (coupon.max_redemptions_per_user ?? 1)) return { ok: false as const, code: c0, error: 'COUPON_USED', message: 'Hai già utilizzato questo codice sconto.' };
    }
    if (!['percent', 'amount'].includes(coupon.discount_type) || !coupon.discount_value || coupon.discount_value <= 0) {
      return { ok: false as const, code: c0, error: 'COUPON_IN_STORE_ONLY', message: 'Questo coupon è valido solo al ristorante, non per gli ordini online.' };
    }
    if (coupon.minimum_spend != null && subtotal < coupon.minimum_spend) {
      return { ok: false as const, code: c0, error: 'COUPON_MIN_SPEND', message: `Il codice è valido con una spesa minima di ${coupon.minimum_spend.toFixed(2)} €.` };
    }
    const discount = coupon.discount_type === 'percent' ? round2((subtotal * Math.min(coupon.discount_value, 100)) / 100) : Math.min(coupon.discount_value, subtotal);
    return { ok: true as const, code: c0, coupon_id: coupon.id, claim_id: claim?.id ?? null, reward_redemption_id: reward?.id ?? null, is_reward: !!reward, title: coupon.title, discount };
  }

  // ─── Preventivo (stesse regole di order_quote_core) ───────
  function quoteCore(p: QuoteInput, user: string | null, email: string | null): Quote & { _codes: ReturnType<typeof validateCode>[] } {
    const errors: OrderError[] = [];
    const r = rest(p.restaurant_id);
    const s = settingsOf(p.restaurant_id);
    if (!r || !a.isPublic(p.restaurant_id)) return { ok: false, errors: [err('RESTAURANT_NOT_FOUND', 'Ristorante non trovato.')], _codes: [] };
    if (!flag('orders_enabled', true) || !s || !s.orders_enabled || r.is_permanently_closed) {
      return { ok: false, errors: [err('ORDERS_DISABLED', 'Questo ristorante non accetta ordini online.')], _codes: [] };
    }
    if (r.is_temporarily_closed) errors.push(err('RESTAURANT_CLOSED', 'Il ristorante è chiuso temporaneamente.'));
    let type: OrderType = p.order_type === 'delivery' || p.order_type === 'takeaway' ? p.order_type : s.takeaway_enabled ? 'takeaway' : 'delivery';
    if (!['takeaway', 'delivery'].includes(type)) type = 'takeaway';
    const ts = typeState(s, type);
    if (ts === 'disabled') errors.push(err('TYPE_UNAVAILABLE', type === 'delivery' ? 'Questo ristorante non effettua consegne a domicilio.' : 'Questo ristorante non offre il ritiro al locale.'));
    else if (ts === 'paused') errors.push(err('RESTAURANT_PAUSED', type === 'delivery' ? 'Le consegne sono in pausa: riprova tra poco o scegli il ritiro.' : 'Il ristorante ha messo in pausa gli ordini: riprova tra poco.'));

    const lines: QuoteLine[] = [];
    let subtotal = 0;
    let totalQty = 0;
    const maxLines = setting('order_max_items', 50);
    if (!Array.isArray(p.items) || p.items.length === 0) errors.push(err('EMPTY_CART', 'Il carrello è vuoto.'));
    else if (p.items.length > maxLines) errors.push(err('TOO_MANY_ITEMS', `Puoi ordinare al massimo ${maxLines} prodotti diversi.`));
    else {
      p.items.forEach((e, index) => {
        const it = a.db.menu_items.find((x) => x.id === e.menu_item_id && x.restaurant_id === p.restaurant_id);
        if (!it) {
          errors.push(err('ITEM_NOT_FOUND', 'Un prodotto nel tuo carrello non esiste più.', { index }));
          lines.push({ index, menu_item_id: e.menu_item_id, name: null, variant_id: null, variant_name: null, base_price: 0, addons_total: 0, unit_price: 0, quantity: e.quantity, line_total: 0, options: [], notes: null, available: false });
          return;
        }
        let ok = true;
        let qty = Number.isInteger(e.quantity) ? e.quantity : 0;
        if (qty < 1 || qty > 20) {
          errors.push(err('QUANTITY_INVALID', 'Quantità non valida (1–20).', { index }));
          ok = false;
          qty = Math.max(Math.min(qty, 20), 1);
        }
        const cat = a.db.menu_categories.find((c) => c.id === it.menu_category_id);
        const menu = a.db.menus.find((m) => m.id === cat?.menu_id);
        const menuOk = !!cat && cat.is_active !== false && !!menu && menu.is_active && menu.is_public !== false && menu.menu_type !== 'all_you_can_eat';
        const inStock = it.is_available && (!it.unavailable_until || Date.parse(it.unavailable_until) <= Date.now());
        if (!menuOk || !inStock) {
          errors.push(err('ITEM_UNAVAILABLE', 'Un prodotto nel tuo carrello non è più disponibile.', { index }));
          ok = false;
        }
        const variants = a.db.menu_item_variants.filter((v) => v.menu_item_id === it.id && v.is_available);
        let variant: MenuItemVariant | undefined;
        if (e.variant_id) {
          variant = a.db.menu_item_variants.find((v) => v.id === e.variant_id && v.menu_item_id === it.id);
          if (!variant || !variant.is_available) {
            errors.push(err('OPTION_INVALID', `La variante scelta per «${it.name}» non è più disponibile.`, { index }));
            ok = false;
          }
        } else if (variants.length) {
          errors.push(err('OPTIONS_REQUIRED', `Scegli una variante per «${it.name}».`, { index }));
          ok = false;
        }
        let base = variant?.price ?? (it.discount_price != null && it.price != null && it.discount_price < it.price ? it.discount_price : it.price);
        if (base == null) {
          errors.push(err('PRICE_MISSING', `«${it.name}» non è ordinabile online.`, { index }));
          ok = false;
          base = 0;
        }
        let extras = 0;
        const opts: QuoteLine['options'] = [];
        for (const ad of e.addons ?? []) {
          const x = a.db.menu_item_addons.find((y) => y.id === ad.id && y.menu_item_id === it.id);
          if (!x || !x.is_available) {
            errors.push(err('OPTION_INVALID', `Un extra di «${it.name}» non è più disponibile.`, { index }));
            ok = false;
            continue;
          }
          const q = Math.max(Math.min(ad.quantity || 1, 5), 1);
          extras += (x.price ?? 0) * q;
          opts.push({ kind: 'addon', id: x.id, group: 'Extra', name: x.name, price: x.price ?? 0, quantity: q });
        }
        const groups = st().option_groups.filter((g) => g.menu_item_id === it.id && g.is_active);
        const counts: Record<string, number> = {};
        for (const oid of e.options ?? []) {
          const g = groups.find((gg) => gg.options.some((o) => o.id === oid));
          const o = g?.options.find((x) => x.id === oid);
          if (!g || !o || !o.is_available) {
            errors.push(err('OPTION_INVALID', `Una scelta per «${it.name}» non è più disponibile.`, { index }));
            ok = false;
            continue;
          }
          counts[g.id] = (counts[g.id] ?? 0) + 1;
          extras += o.price;
          opts.push({ kind: 'option', id: o.id, group: g.name, name: o.name, price: o.price, quantity: 1 });
        }
        for (const g of groups) {
          const n = counts[g.id] ?? 0;
          if (n < Math.max(g.min_select, g.required ? 1 : 0) || n > g.max_select) {
            errors.push(err('OPTIONS_REQUIRED', `Completa la scelta «${g.name}» per «${it.name}».`, { index }));
            ok = false;
          }
        }
        const unit = round2(base + extras);
        totalQty += qty;
        subtotal += round2(unit * qty);
        lines.push({ index, menu_item_id: it.id, name: it.name, variant_id: variant?.id ?? null, variant_name: variant?.name ?? null, base_price: round2(base), addons_total: round2(extras),
          unit_price: unit, quantity: qty, line_total: round2(unit * qty), options: opts, notes: e.notes?.trim().slice(0, 200) || null, available: ok });
      });
      if (totalQty > 100) errors.push(err('TOO_MANY_ITEMS', 'Quantità totale troppo alta per un ordine online.'));
    }
    subtotal = round2(subtotal);

    // Orario
    const p0 = prep(s);
    const deliveryMin = type === 'delivery' ? s.delivery_estimated_minutes : 0;
    let sched: Date | null = null;
    let ready: Date;
    if (p.scheduled_for) {
      sched = new Date(p.scheduled_for);
      if (Number.isNaN(sched.getTime())) {
        errors.push(err('SLOT_INVALID', 'Orario non valido.'));
        sched = null;
      }
    }
    if (sched) {
      if (!s.allow_scheduled_orders) errors.push(err('SLOT_INVALID', 'Questo ristorante non accetta ordini programmati.'));
      else if (sched.getTime() < Date.now() + (p0 + deliveryMin) * MIN - 2 * MIN) errors.push(err('SLOT_INVALID', 'L’orario scelto è troppo vicino: scegline uno successivo.'));
      else if (sched.getTime() > Date.now() + (s.max_advance_days + 1) * DAY) errors.push(err('SLOT_INVALID', `Puoi programmare al massimo ${s.max_advance_days} giorni prima.`));
      else if (openAt(p.restaurant_id, new Date(sched.getTime() - deliveryMin * MIN)) !== 'open') errors.push(err('SLOT_INVALID', 'Il ristorante è chiuso all’orario scelto.'));
      ready = new Date(sched.getTime() - deliveryMin * MIN);
    } else {
      const open = openAt(p.restaurant_id, new Date());
      ready = new Date(Date.now() + p0 * MIN);
      if (open !== 'open' || openAt(p.restaurant_id, ready) !== 'open') {
        errors.push(err('RESTAURANT_CLOSED',
          open === 'unknown' ? 'Orari del ristorante non disponibili: non è possibile ordinare ora.'
            : s.allow_scheduled_orders ? 'Il ristorante è chiuso in questo momento: programma l’ordine per più tardi.' : 'Il ristorante è chiuso in questo momento.',
          { next_slot: s.allow_scheduled_orders ? nextSlot(p.restaurant_id, type) : null }));
      }
    }
    const slot = slotStart(ready, s.slot_interval_minutes);
    if (s.max_orders_per_slot != null && slotCount(p.restaurant_id, slot) >= s.max_orders_per_slot) {
      errors.push(err('SLOT_FULL', 'La fascia oraria scelta è al completo: scegli un altro orario.', { next_slot: s.allow_scheduled_orders ? nextSlot(p.restaurant_id, type) : null }));
    }

    // Consegna
    let deliveryFee = 0;
    let min = 0;
    let dist: number | null = null;
    let zone: DeliveryZone | undefined;
    let eta = s.delivery_estimated_minutes;
    if (type === 'delivery') {
      const lat = Number(p.address?.latitude);
      const lng = Number(p.address?.longitude);
      if (!p.address || p.address.latitude == null || !Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
        errors.push(err('ADDRESS_REQUIRED', 'Inserisci un indirizzo di consegna verificato.'));
      } else if (r.latitude == null || r.longitude == null) {
        errors.push(err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.'));
      } else {
        dist = round2(haversineKm({ lat: r.latitude, lng: r.longitude }, { lat, lng }));
        if (s.delivery_provider_type === 'asiafood') {
          const m = a.logistics ? a.logistics.serviceCheck(r.id, lat, lng) : 'Le consegne con Rider AsiaFood non sono disponibili in questo momento: scegli il ritiro al locale.';
          if (m) errors.push(err('OUTSIDE_AREA', m));
        }
        if (s.delivery_radius_km != null && dist > s.delivery_radius_km) errors.push(err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.'));
        else if (s.delivery_fee_type === 'distance' || s.delivery_fee_type === 'zone') {
          zone = st().delivery_zones
            .filter((z) => z.restaurant_id === p.restaurant_id && z.is_active && ((z.zone_type === 'radius' && dist! <= (z.radius_km ?? 0)) || (z.zone_type === 'distance' && dist! >= (z.min_distance_km ?? 0) && dist! < (z.max_distance_km ?? 0))))
            .sort((x, y) => (x.max_distance_km ?? x.radius_km ?? 0) - (y.max_distance_km ?? y.radius_km ?? 0))[0];
          if (!zone) errors.push(err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.'));
          else {
            deliveryFee = zone.delivery_fee;
            eta = zone.estimated_delivery_minutes;
            min = Math.max(min, zone.minimum_order);
          }
        } else if (s.delivery_radius_km == null) errors.push(err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.'));
        else deliveryFee = s.delivery_fee_type === 'free' ? 0 : s.delivery_fee;
        if (s.free_delivery_threshold != null && subtotal >= s.free_delivery_threshold) deliveryFee = 0;
      }
      min = Math.max(min, s.delivery_minimum_order ?? s.minimum_order_amount ?? 0);
    } else {
      min = Math.max(min, s.takeaway_minimum_order ?? s.minimum_order_amount ?? 0);
    }
    if (subtotal > 0 && subtotal < min) {
      errors.push(err('MINIMUM_NOT_REACHED', `L’ordine minimo è ${min.toFixed(2)} €: aggiungi ancora ${(min - subtotal).toFixed(2)} €.`, { minimum: min, missing: round2(min - subtotal) }));
    }

    // Codici sconto
    const codes = [p.coupon_code, p.reward_code].filter((x): x is string => !!x?.trim()).map((c) => validateCode(p.restaurant_id, c, user, email, subtotal));
    codes.filter((c) => !c.ok).forEach((c) => errors.push(err((c as { error: string }).error, (c as { message: string }).message, { field: 'coupon' })));
    const okCodes = codes.filter((c) => c.ok) as Extract<ReturnType<typeof validateCode>, { ok: true }>[];
    if (okCodes.length > 1) {
      if (!flag('allow_coupon_stacking', false)) errors.push(err('COUPON_NOT_STACKABLE', 'I codici sconto non sono cumulabili: usane uno solo.', { field: 'coupon' }));
      else if (new Set(okCodes.map((c) => c.coupon_id)).size < 2) errors.push(err('COUPON_NOT_STACKABLE', 'Lo stesso coupon non può essere usato due volte.', { field: 'coupon' }));
    }
    let couponDisc = 0;
    let loyaltyDisc = 0;
    for (const c of okCodes) {
      const d = Math.min(c.discount, subtotal - couponDisc - loyaltyDisc);
      if (c.is_reward) loyaltyDisc += d;
      else couponDisc += d;
    }
    const service = flag('service_fee_enabled', false) && s.service_fee_enabled && subtotal > 0 ? setting('service_fee_amount', 0.99) : 0;
    const total = round2(subtotal - couponDisc - loyaltyDisc + deliveryFee + service);
    if (subtotal > 0 && total < 0.5) errors.push(err('TOTAL_TOO_LOW', 'L’importo minimo per il pagamento online è 0,50 €.'));
    const pay = paymentSetup(p.restaurant_id);
    if (!pay.ready) errors.push(err('PAYMENTS_NOT_READY', 'Questo ristorante non ha ancora attivato i pagamenti online.'));
    return {
      ok: errors.length === 0, errors, restaurant: { id: r.id, name: r.name, slug: r.slug }, order_type: type, lines,
      subtotal, coupon_discount: round2(couponDisc), loyalty_discount: round2(loyaltyDisc), discount_total: round2(couponDisc + loyaltyDisc),
      delivery_fee: round2(deliveryFee), service_fee: round2(service), tax_total: null, total: Math.max(total, 0), currency: 'EUR', minimum_order: min,
      codes: codes.map((c) => (c.ok ? { ok: true, code: c.code, title: c.title, discount: c.discount, is_reward: c.is_reward } : { ok: false, code: c.code, error: c.error, message: c.message })),
      delivery: type === 'delivery' ? { distance_km: dist, zone_id: zone?.id ?? null, zone_name: zone?.name ?? null, eta_minutes: eta } : null,
      scheduled_for: sched?.toISOString() ?? null, estimated_ready_at: ready.toISOString(),
      estimated_delivery_at: type === 'delivery' ? new Date(ready.getTime() + eta * MIN).toISOString() : null,
      preparation_minutes: p0, payment_mode: pay.mode, payments_ready: pay.ready,
      _codes: codes,
    };
  }

  // ─── Notifiche ─────────────────────────────────────────────
  const notifyCustomer = (o: DemoOrder, kind: string, title: string, body: string, email?: string) => {
    const r = rest(o.restaurant_id);
    const link = `/orders/${o.order_number}`;
    if (o.user_id) {
      a.notify(o.user_id, 'order', title, body, link, { dedupe: `order:${kind}:${o.id}`, meta: { order_id: o.id, order_number: o.order_number }, restaurant: o.restaurant_id, email, emailPayload: { order_number: o.order_number, restaurant: r?.name, total: o.total } });
    } else if (email) {
      a.enqueueEmail(email, o.customer_email, { order_number: o.order_number, restaurant: r?.name, total: o.total, title, body, link: `${link}?t=${tokenFor(o.id)}`, guest: true });
    }
  };
  const notifyRestaurant = (o: DemoOrder, kind: string, title: string, body: string) => {
    a.db.restaurant_members.filter((m) => m.restaurant_id === o.restaurant_id && m.status === 'active').forEach((m) =>
      a.notify(m.user_id, 'order', title, body, `/dashboard/restaurants/${o.restaurant_id}/orders`, { dedupe: `order_r:${kind}:${o.id}:${m.user_id}`, meta: { order_id: o.id, order_number: o.order_number, sound: kind === 'new' }, restaurant: o.restaurant_id }));
  };
  const logE = (o: DemoOrder, type: string, actor: string, meta: Row = {}) => o.events.push({ type, actor, metadata: meta, created_at: now() });

  // ─── Pagamento confermato, transizioni ─────────────────────
  function applyPaid(o: DemoOrder) {
    const r = rest(o.restaurant_id)!;
    if (o.coupon_id) {
      const c = a.db.coupons.find((x) => x.id === o.coupon_id);
      if (c) c.redemptions_count += 1;
    }
    if (o.coupon_claim_id) {
      const cl = a.db.coupon_claims.find((x) => x.id === o.coupon_claim_id);
      if (cl && cl.status === 'claimed') Object.assign(cl, { status: 'redeemed', redeemed_at: now() });
    }
    if (o.reward_redemption_id) {
      const rr = a.db.engagement?.reward_redemptions.find((x) => x.id === o.reward_redemption_id);
      if (rr && rr.status === 'claimed') Object.assign(rr, { status: 'used', redeemed_at: now() });
    }
    a.logEvent(o.restaurant_id, 'payment_success');
    notifyRestaurant(o, 'new', `Nuovo ordine ${o.order_number}`, `${o.order_type === 'delivery' ? 'Consegna' : 'Ritiro'} · ${o.total.toFixed(2)} € · ${o.scheduled_for ? `per le ${hhmmRome(new Date(o.scheduled_for))}` : 'il prima possibile'}`);
    notifyCustomer(o, 'paid', 'Pagamento confermato', `Ordine ${o.order_number} inviato a ${r.name}: ti avvisiamo appena viene accettato.`, 'order_payment_confirmed');
    const s = settingsOf(o.restaurant_id);
    if (s?.accept_orders_automatically) transition(o, 'accept', { preparation_minutes: prep(s) }, 'system');
  }

  function queueFullRefund(o: DemoOrder, reason: string, by: string) {
    const pending = o.refunds.filter((x) => ['pending', 'processing'].includes(x.status)).reduce((s, x) => s + x.amount, 0);
    const amount = round2(o.amount_paid - o.amount_refunded - pending);
    if (amount <= 0) return false;
    o.refunds.push({ id: uuid(), amount, reason, status: 'pending', requested_by_type: by, created_at: now(), processed_at: null, stripe_refund_id: null, error: null });
    logE(o, 'refund_requested', 'system', { reason });
    return true;
  }
  /** Rimborsi SIMULATI (in produzione li esegue il backend su Stripe). */
  function processRefunds(o: DemoOrder) {
    for (const f of o.refunds.filter((x) => x.status === 'pending')) {
      f.status = 'succeeded';
      f.processed_at = now();
      f.stripe_refund_id = `re_demo_${code(10)}`;
      o.amount_refunded = round2(Math.min(o.amount_paid, o.amount_refunded + f.amount));
      o.payment_status = o.amount_refunded >= o.amount_paid ? 'refunded' : 'partially_refunded';
      if (o.status === 'completed') o.status = o.amount_refunded >= o.amount_paid ? 'refunded' : 'partially_refunded';
      logE(o, 'refunded', 'stripe', { amount: f.amount });
      notifyCustomer(o, `refund:${f.id}`, 'Rimborso effettuato', `Abbiamo rimborsato ${f.amount.toFixed(2)} € per l’ordine ${o.order_number}. L’accredito sulla carta può richiedere alcuni giorni lavorativi.`, 'order_refunded');
    }
  }

  type Actor = 'restaurant' | 'admin' | 'system' | 'customer' | 'rider';
  function transition(o: DemoOrder, action: string, p: Row, actor: Actor) {
    // Consegne con Rider AsiaFood: "in consegna" e "consegnato" li imposta solo il Rider
    if (['out_for_delivery', 'complete'].includes(action) && o.order_type === 'delivery' && o.delivery_provider_type === 'asiafood' && actor !== 'rider' && a.logistics?.hasActiveJob(o.id)) {
      fail('Questa consegna è gestita da un Rider AsiaFood: lo stato «in consegna» e «consegnato» lo aggiorna il Rider.');
    }
    const prev = o.status;
    const res = transition0(o, action, p, actor);
    if (o.status !== prev) a.logistics?.onOrderStatus(o, prev);
    return res;
  }
  function transition0(o: DemoOrder, action: string, p: Row, actor: Actor) {
    const r = rest(o.restaurant_id)!;
    if (action === 'accept') {
      if (o.status !== 'pending_restaurant') fail('L’ordine non è in attesa di conferma.');
      const pm = Number(p.preparation_minutes);
      if (!Number.isInteger(pm) || pm < 5 || pm > 240) fail('Tempo di preparazione non valido (5–240 minuti).');
      const zoneEta = st().delivery_zones.find((z) => z.id === o.delivery_zone_id)?.estimated_delivery_minutes ?? settingsOf(o.restaurant_id)?.delivery_estimated_minutes ?? 25;
      const schedReady = o.scheduled_for ? Date.parse(o.scheduled_for) - (o.order_type === 'delivery' ? zoneEta : 0) * MIN : 0;
      const readyAt = Math.max(schedReady, Date.now() + pm * MIN);
      Object.assign(o, { status: 'accepted', accepted_at: now(), preparation_minutes: pm, estimated_ready_at: new Date(readyAt).toISOString(),
        estimated_delivery_at: o.order_type === 'delivery' ? new Date(readyAt + zoneEta * MIN).toISOString() : null,
        restaurant_notes: typeof p.note === 'string' && p.note.trim() ? p.note.trim().slice(0, 300) : o.restaurant_notes });
      logE(o, 'accepted', actor, { preparation_minutes: pm });
      a.logEvent(o.restaurant_id, 'order_accepted');
      notifyCustomer(o, 'accepted', 'Ordine accettato', `${r.name} ha accettato l’ordine ${o.order_number}. Pronto verso le ${hhmmRome(new Date(readyAt))}.`, 'order_accepted');
      return { ok: true, status: o.status };
    }
    if (action === 'reject') {
      if (!['pending_restaurant', 'accepted'].includes(o.status)) fail('Questo ordine non può più essere rifiutato.');
      const reason = (p.reason as RejectReason) ?? 'other';
      const lab = REJECT_REASONS.find((x) => x.value === reason) ?? fail('Motivo non valido.');
      const label = lab.label + (typeof p.note === 'string' && p.note.trim() ? `: ${p.note.trim().slice(0, 200)}` : '');
      Object.assign(o, { status: 'rejected', rejected_at: now(), fulfillment_status: 'cancelled', reject_reason: label });
      logE(o, 'rejected', actor, { reason });
      a.logEvent(o.restaurant_id, 'order_cancelled');
      const refund = ['paid', 'partially_refunded'].includes(o.payment_status) && flag('order_auto_refund_on_reject', true) && queueFullRefund(o, 'Ordine rifiutato dal ristorante', actor === 'admin' ? 'admin' : 'restaurant');
      notifyCustomer(o, 'rejected', 'Ordine non accettato', `${r.name} non può preparare l’ordine ${o.order_number} (${label}).${refund ? ' Il rimborso completo è in corso.' : ''}`, 'order_rejected');
      return { ok: true, status: o.status, refund_pending: !!refund };
    }
    if (['preparing', 'ready', 'out_for_delivery', 'complete'].includes(action)) {
      const to: OrderStatus | null =
        action === 'preparing' ? (o.status === 'accepted' ? 'preparing' : null)
          : action === 'ready' ? (['accepted', 'preparing'].includes(o.status) ? 'ready' : null)
            : action === 'out_for_delivery' ? (['ready', 'preparing', 'accepted'].includes(o.status) && o.order_type === 'delivery' ? 'out_for_delivery' : null)
              : (o.order_type === 'takeaway' && ['ready', 'preparing', 'accepted'].includes(o.status)) || (o.order_type === 'delivery' && ['out_for_delivery', 'ready'].includes(o.status)) ? 'completed' : null;
      if (!to) fail('Passaggio di stato non consentito.');
      o.status = to!;
      if (to === 'preparing') Object.assign(o, { preparing_at: now(), fulfillment_status: 'preparing' });
      if (to === 'ready') Object.assign(o, { ready_at: now(), fulfillment_status: 'ready' });
      if (to === 'out_for_delivery') Object.assign(o, { out_for_delivery_at: now(), fulfillment_status: 'out_for_delivery' });
      if (to === 'completed') Object.assign(o, { completed_at: now(), picked_up_at: o.order_type === 'takeaway' ? now() : o.picked_up_at, fulfillment_status: o.order_type === 'takeaway' ? 'picked_up' : 'delivered' });
      logE(o, to === 'completed' ? 'completed' : to!, actor);
      if (to === 'preparing') notifyCustomer(o, 'preparing', 'Ordine in preparazione', `${r.name} sta preparando il tuo ordine ${o.order_number}.`);
      if (to === 'ready') notifyCustomer(o, 'ready', o.order_type === 'takeaway' ? 'Ordine pronto per il ritiro' : 'Ordine pronto per la consegna',
        o.order_type === 'takeaway' ? `Il tuo ordine ${o.order_number} ti aspetta da ${r.name}.` : `Il tuo ordine ${o.order_number} sta per partire.`, 'order_ready');
      if (to === 'out_for_delivery') notifyCustomer(o, 'out', 'Il tuo ordine è in consegna', `${r.name} ha affidato l’ordine ${o.order_number} al fattorino.`);
      if (to === 'completed') {
        a.logEvent(o.restaurant_id, 'order_completed');
        notifyCustomer(o, 'completed', o.order_type === 'takeaway' ? 'Ordine ritirato' : 'Ordine consegnato', 'Grazie per aver ordinato con AsiaFood! Buon appetito.');
        a.orderCompleted(o);
      }
      return { ok: true, status: o.status };
    }
    if (action === 'cancel') {
      if (['completed', 'rejected', 'cancelled', 'refunded'].includes(o.status)) fail('L’ordine non può essere annullato.');
      const label = typeof p.reason === 'string' && p.reason.trim() ? p.reason.trim().slice(0, 200) : 'Annullato';
      Object.assign(o, { status: 'cancelled', cancelled_at: now(), fulfillment_status: 'cancelled', cancel_reason: label });
      logE(o, 'cancelled', actor, { reason: label });
      a.logEvent(o.restaurant_id, 'order_cancelled');
      const refund = ['paid', 'partially_refunded'].includes(o.payment_status) && p.refund !== false && queueFullRefund(o, `Ordine annullato: ${label}`, actor === 'restaurant' || actor === 'admin' || actor === 'customer' ? actor : 'system');
      if (actor !== 'customer') notifyCustomer(o, 'cancelled', 'Ordine annullato', `L’ordine ${o.order_number} è stato annullato (${label}).${refund ? ' Il rimborso completo è in corso.' : ''}`, 'order_cancelled');
      if (o.paid_at && actor !== 'restaurant') notifyRestaurant(o, 'cancelled', `Ordine annullato ${o.order_number}`, label);
      return { ok: true, status: o.status, refund_pending: !!refund };
    }
    return fail('Azione non valida.');
  }

  // ─── Accesso cliente ───────────────────────────────────────
  function access(num: string, token?: string | null): DemoOrder | null {
    if (!/^AF-\d{6}-[A-Z0-9]{4}$/.test(num)) return null;
    const recent = st().track_failures.filter((f) => f.order_number === num && f.at > Date.now() - 3600_000).length;
    if (recent >= 20) fail('Troppi tentativi: riprova più tardi.');
    const o = st().orders.find((x) => x.order_number === num);
    const uid = a.uid();
    if (o && ((uid && o.user_id === uid) || (uid && a.isAdmin()) || (token && demoHash(token) === o.access_token_hash))) return o;
    st().track_failures.push({ order_number: num, at: Date.now() });
    return null;
  }
  const view = (o: DemoOrder): OrderView => {
    const r = rest(o.restaurant_id)!;
    return {
      id: o.id, order_number: o.order_number, order_type: o.order_type, status: o.status, payment_status: o.payment_status, fulfillment_status: o.fulfillment_status,
      restaurant: { id: r.id, name: r.name, slug: r.slug, address: r.address, city: a.db.cities.find((c) => c.id === r.city_id)?.name ?? null, phone: r.phone, latitude: r.latitude, longitude: r.longitude,
        pickup_instructions: settingsOf(r.id)?.pickup_instructions ?? null },
      customer_name: o.customer_name, customer_phone: o.customer_phone, customer_email: o.customer_email, delivery_address: o.delivery_address,
      items: o.items, subtotal: o.subtotal, coupon_discount: o.coupon_discount, loyalty_discount: o.loyalty_discount, discount_total: o.discount_total, delivery_fee: o.delivery_fee,
      service_fee: o.service_fee, tax_total: null, total: o.total, currency: 'EUR', coupon_code: o.coupon_code, amount_paid: o.amount_paid, amount_refunded: o.amount_refunded,
      scheduled_for: o.scheduled_for, estimated_ready_at: o.estimated_ready_at, estimated_delivery_at: o.estimated_delivery_at, preparation_minutes: o.preparation_minutes,
      customer_notes: o.customer_notes, reject_reason: o.reject_reason, cancel_reason: o.cancel_reason, created_at: o.created_at, paid_at: o.paid_at, accepted_at: o.accepted_at,
      rejected_at: o.rejected_at, preparing_at: o.preparing_at, ready_at: o.ready_at, picked_up_at: o.picked_up_at, out_for_delivery_at: o.out_for_delivery_at, completed_at: o.completed_at,
      cancelled_at: o.cancelled_at, can_cancel: ['pending_payment', 'payment_authorized', 'pending_restaurant'].includes(o.status),
      can_pay: o.status === 'pending_payment' && ['unpaid', 'pending', 'failed'].includes(o.payment_status),
      refunds: o.refunds.filter((f) => f.status !== 'cancelled').map((f) => ({ amount: f.amount, status: f.status, created_at: f.created_at, processed_at: f.processed_at })),
      issues: o.issues.map((x) => ({ id: x.id, type: x.type, status: x.status, resolution: x.resolution, created_at: x.created_at })),
      reviewable: o.status === 'completed' && !!o.user_id, is_owner: !!o.user_id && o.user_id === a.uid(),
    };
  };
  const byId = (id: string) => st().orders.find((o) => o.id === id) ?? fail('Ordine non trovato.');
  const isValid = (o: DemoOrder) => ['paid', 'partially_refunded'].includes(o.payment_status) && !['rejected', 'cancelled', 'refunded', 'pending_payment'].includes(o.status);

  // ═══════════════════════════════════════════════════════════
  /** Accesso interno per la logistica DEMO (stesse regole delle funzioni SQL lg_*). */
  const internal = { byId, transition, notifyCustomer, notifyRestaurant, access, logE, processRefunds, settingsOf, rest, canView, memberRole };

  return {
    internal,
    optionGroupsFor: (rid: string) => st().option_groups.filter((g) => g.restaurant_id === rid && g.is_active).map((g) => ({ ...g, options: g.options.filter((o) => o.is_available) })),

    publicInfo(rid: string): OrderPublicInfo {
      const r = rest(rid);
      const s = settingsOf(rid);
      if (!r || !a.isPublic(rid) || !s || !s.orders_enabled || !flag('orders_enabled', true) || r.is_permanently_closed) return { enabled: false };
      const tk = typeState(s, 'takeaway');
      const dl = typeState(s, 'delivery');
      const paused = (v: string | null) => (v && (v === 'infinity' || Date.parse(v) > Date.now()) ? v : null);
      return {
        enabled: true, payments_ready: paymentSetup(rid).ready, open_now: openAt(rid, new Date()) === 'open' && !r.is_temporarily_closed, open_status: openAt(rid, new Date()),
        temporarily_closed: r.is_temporarily_closed, paused_until: paused(s.orders_paused_until), preparation_minutes: prep(s), busy: s.busy_extra_minutes > 0,
        allow_scheduled: s.allow_scheduled_orders, max_advance_days: s.max_advance_days, minimum_order: s.minimum_order_amount, pickup_instructions: s.pickup_instructions,
        service_fee: flag('service_fee_enabled', false) && s.service_fee_enabled ? setting('service_fee_amount', 0.99) : 0,
        takeaway: { enabled: tk !== 'disabled', state: tk, paused_until: paused(s.takeaway_paused_until), minimum_order: s.takeaway_minimum_order ?? s.minimum_order_amount, next_slot: tk === 'ok' ? nextSlot(rid, 'takeaway') : null },
        delivery: {
          enabled: dl !== 'disabled', state: dl, paused_until: paused(s.delivery_paused_until), minimum_order: s.delivery_minimum_order ?? s.minimum_order_amount, fee_type: s.delivery_fee_type,
          fee: s.delivery_fee, radius_km: s.delivery_radius_km, free_threshold: s.free_delivery_threshold, estimated_minutes: s.delivery_estimated_minutes, provider: s.delivery_provider_type,
          zones: st().delivery_zones.filter((z) => z.restaurant_id === rid && z.is_active && z.zone_type !== 'polygon')
            .map((z) => ({ name: z.name, type: z.zone_type, min_km: z.min_distance_km ?? 0, max_km: z.max_distance_km ?? z.radius_km ?? 0, fee: z.delivery_fee, minimum_order: z.minimum_order, eta_minutes: z.estimated_delivery_minutes }))
            .sort((x, y) => x.max_km - y.max_km),
          next_slot: dl === 'ok' ? nextSlot(rid, 'delivery') : null,
        },
      };
    },
    orderable(): OrderableRestaurant[] {
      return st().order_settings.filter((s) => s.orders_enabled && a.isPublic(s.restaurant_id) && !rest(s.restaurant_id)?.is_permanently_closed).map((s) => ({
        restaurant_id: s.restaurant_id, takeaway: typeState(s, 'takeaway') !== 'disabled', delivery: typeState(s, 'delivery') !== 'disabled',
        order_now: paymentSetup(s.restaurant_id).ready && openAt(s.restaurant_id, new Date()) === 'open' && (typeState(s, 'takeaway') === 'ok' || typeState(s, 'delivery') === 'ok'),
        payments_ready: paymentSetup(s.restaurant_id).ready,
        delivery_radius_km: s.delivery_radius_km ?? Math.max(0, ...st().delivery_zones.filter((z) => z.restaurant_id === s.restaurant_id && z.is_active).map((z) => z.max_distance_km ?? z.radius_km ?? 0)),
      }));
    },
    deliveringTo(lat: number, lng: number) {
      const out: { restaurant_id: string; distance_km: number; delivery_fee: number }[] = [];
      for (const s of st().order_settings.filter((x) => x.orders_enabled && x.delivery_enabled && a.isPublic(x.restaurant_id))) {
        const r = rest(s.restaurant_id);
        if (!r || r.latitude == null || r.longitude == null) continue;
        const d = Math.round(haversineKm({ lat: r.latitude, lng: r.longitude }, { lat: Math.round(lat * 1000) / 1000, lng: Math.round(lng * 1000) / 1000 }) * 10) / 10;
        let fee: number | null = null;
        if (s.delivery_fee_type === 'distance' || s.delivery_fee_type === 'zone') {
          const z = st().delivery_zones.filter((x) => x.restaurant_id === r.id && x.is_active && ((x.zone_type === 'radius' && d <= (x.radius_km ?? 0)) || (x.zone_type === 'distance' && d >= (x.min_distance_km ?? 0) && d < (x.max_distance_km ?? 0))))
            .sort((x, y) => (x.max_distance_km ?? x.radius_km ?? 0) - (y.max_distance_km ?? y.radius_km ?? 0))[0];
          if (z && (s.delivery_radius_km == null || d <= s.delivery_radius_km)) fee = z.delivery_fee;
        } else if (s.delivery_radius_km != null && d <= s.delivery_radius_km) fee = s.delivery_fee_type === 'free' ? 0 : s.delivery_fee;
        if (fee != null) out.push({ restaurant_id: r.id, distance_km: d, delivery_fee: fee });
      }
      return out;
    },
    slots: (rid: string, date: string, t: OrderType) => slotsFor(rid, date, t),

    quote(p: QuoteInput): Quote {
      const uid = a.uid();
      const email = uid ? a.db.profiles.find((x) => x.id === uid)?.email ?? null : p.contact?.email?.trim().toLowerCase() || null;
      const { _codes: _c, ...q } = quoteCore(p, uid, email);
      return q;
    },

    /** Crea l'ordine "in attesa di pagamento" (in produzione: endpoint server create-order). */
    create(p: QuoteInput & { idempotency_key: string; session_id: string | null }): CheckoutResult {
      const uid = a.uid();
      if (p.idempotency_key) {
        const ex = st().orders.find((o) => o.idempotency_key === p.idempotency_key);
        if (ex) {
          if (ex.user_id !== uid) return { ok: false, errors: [err('IDEMPOTENCY_CONFLICT', 'Richiesta duplicata: ricarica la pagina.')] };
          return { ok: true, order_id: ex.id, order_number: ex.order_number, access_token: tokenFor(ex.id), client_secret: null, total: ex.total, payment_mode: 'demo', simulated: true };
        }
      }
      const prof = uid ? a.db.profiles.find((x) => x.id === uid) : undefined;
      if (prof?.is_blocked) return { ok: false, errors: [err('FORBIDDEN', 'Account non abilitato agli ordini.')] };
      const name = (p.contact?.name ?? prof?.full_name ?? '').trim().slice(0, 80);
      const email = (p.contact?.email || prof?.email || '').trim().toLowerCase();
      const phone = (p.contact?.phone || prof?.phone || '').trim();
      if (name.length < 2) return { ok: false, errors: [err('CONTACT_INVALID', 'Inserisci nome e cognome.', { field: 'name' })] };
      if (!EMAIL_RE.test(email)) return { ok: false, errors: [err('CONTACT_INVALID', 'Inserisci un indirizzo email valido.', { field: 'email' })] };
      if (!PHONE_RE.test(phone)) return { ok: false, errors: [err('CONTACT_INVALID', 'Inserisci un numero di telefono valido.', { field: 'phone' })] };
      const openUnpaid = st().orders.filter((o) => o.status === 'pending_payment' && Date.parse(o.created_at) > Date.now() - 30 * MIN
        && ((uid && o.user_id === uid) || (p.session_id && o.session_id === p.session_id) || o.customer_email === email)).length;
      if (openUnpaid >= 5) return { ok: false, errors: [err('RATE_LIMITED', 'Hai troppi ordini in attesa di pagamento: completa o attendi qualche minuto.')] };
      const q = quoteCore(p, uid, email);
      if (!q.ok) return { ok: false, errors: q.errors };
      if (q.order_type === 'delivery') {
        const ad = p.address!;
        if ((ad.address_line_1 ?? '').trim().length < 3 || (ad.city ?? '').trim().length < 2 || !/^\d{5}$/.test(ad.postal_code ?? '')) {
          return { ok: false, errors: [err('ADDRESS_REQUIRED', 'Completa l’indirizzo di consegna (via, CAP e città).', { field: 'address' })] };
        }
      }
      const r = rest(p.restaurant_id)!;
      const com = commissionFor(r.id);
      const gross = round2(q.subtotal! - q.discount_total! + q.delivery_fee!);
      const fee = Math.min(round2((gross * com.percent) / 100 + com.fixed), gross);
      const okCodes = q._codes.filter((c) => c.ok) as Extract<ReturnType<typeof validateCode>, { ok: true }>[];
      let num = '';
      do num = `AF-${romeDate().slice(2).replace(/-/g, '')}-${code(4)}`;
      while (st().orders.some((o) => o.order_number === num));
      const o: DemoOrder = {
        id: uuid(), order_number: num, restaurant_id: r.id, user_id: uid, session_id: p.session_id, access_token_hash: '', idempotency_key: p.idempotency_key || null,
        order_type: q.order_type!, status: 'pending_payment', payment_status: 'unpaid', fulfillment_status: 'unfulfilled', customer_name: name, customer_email: email, customer_phone: phone,
        delivery_address_id: uid && p.address?.id && st().addresses.some((x) => x.id === p.address!.id && x.user_id === uid) ? p.address.id : null,
        delivery_address: q.order_type === 'delivery' ? {
          recipient_name: (p.address!.recipient_name || name).slice(0, 80), phone: (p.address!.phone || phone).slice(0, 20), address_line_1: p.address!.address_line_1.trim().slice(0, 120),
          address_line_2: p.address!.address_line_2?.trim().slice(0, 120) || null, city: p.address!.city.trim().slice(0, 80), province: p.address!.province?.trim() || null,
          postal_code: p.address!.postal_code, country: 'IT', latitude: p.address!.latitude, longitude: p.address!.longitude, geocode_source: p.address!.geocode_source ?? 'demo',
          delivery_notes: p.address!.delivery_notes?.trim().slice(0, 200) || null,
        } : null,
        delivery_distance_km: q.delivery?.distance_km ?? null, delivery_zone_id: q.delivery?.zone_id ?? null,
        subtotal: q.subtotal!, discount_total: q.discount_total!, coupon_discount: q.coupon_discount!, loyalty_discount: q.loyalty_discount!, delivery_fee: q.delivery_fee!, service_fee: q.service_fee!, total: q.total!,
        coupon_id: okCodes[0]?.coupon_id ?? null, coupon_code: okCodes[0]?.code ?? null, coupon_claim_id: okCodes.find((c) => c.claim_id)?.claim_id ?? null,
        reward_redemption_id: okCodes.find((c) => c.reward_redemption_id)?.reward_redemption_id ?? null,
        commission_percent: com.percent, commission_fixed: com.fixed, platform_fee: fee, restaurant_gross: gross, restaurant_net_estimated: round2(gross - fee),
        amount_paid: 0, amount_refunded: 0, payment_failures: 0, paid_at: null, scheduled_for: q.scheduled_for ?? null,
        slot_at: slotStart(new Date(q.estimated_ready_at!), settingsOf(r.id)!.slot_interval_minutes).toISOString(), preparation_minutes: q.preparation_minutes ?? null,
        estimated_ready_at: q.estimated_ready_at ?? null, estimated_delivery_at: q.estimated_delivery_at ?? null, customer_notes: p.notes?.trim().slice(0, 300) || null,
        restaurant_notes: null, internal_notes: null, reject_reason: null, cancel_reason: null,
        risk_flags: q.order_type === 'delivery' && p.address?.geocode_source === 'device' ? ['address_from_device'] : [],
        delivery_provider_type: settingsOf(r.id)?.delivery_provider_type ?? 'restaurant',
        source: p.source ?? 'web', created_at: now(), accepted_at: null, rejected_at: null, preparing_at: null, ready_at: null, picked_up_at: null, out_for_delivery_at: null,
        completed_at: null, cancelled_at: null,
        items: q.lines!.map((l) => ({ id: uuid(), menu_item_id: l.menu_item_id, name: l.name!, variant_id: l.variant_id, variant: l.variant_name, quantity: l.quantity, unit_price: l.unit_price,
          addons_total: l.addons_total, line_total: l.line_total, notes: l.notes, options: l.options.map((x) => ({ kind: x.kind, group: x.group, name: x.name, price: x.price, quantity: x.quantity })) })),
        events: [], refunds: [], issues: [],
      };
      logE(o, 'created', 'customer', { total: o.total, order_type: o.order_type });
      o.access_token_hash = demoHash(tokenFor(o.id));
      st().orders.unshift(o);
      a.logEvent(r.id, 'order_created');
      if (uid) st().carts.filter((c) => c.user_id === uid && c.status === 'active').forEach((c) => (c.status = 'converted'));
      a.save();
      return { ok: true, order_id: o.id, order_number: o.order_number, access_token: tokenFor(o.id), client_secret: null, total: o.total, payment_mode: 'demo', simulated: true };
    },

    /** Pagamento SIMULATO (DEMO): nessun addebito. Carte di prova: 4242… ok, 4000 0000 0000 0002 rifiutata. */
    demoPay(num: string, token: string | null, card: string) {
      const o = access(num, token) ?? fail('Ordine non trovato.');
      if (o.payment_status === 'paid') return view(o);
      if (o.status !== 'pending_payment') fail('Questo ordine non può più essere pagato.');
      const digits = card.replace(/\D/g, '');
      if (digits.length < 15) fail('Numero di carta non valido.');
      logE(o, 'payment_started', 'system');
      if (digits === '4000000000000002' || digits === '4000000000009995') {
        o.payment_status = 'failed';
        o.payment_failures += 1;
        if (o.payment_failures >= 5 && !o.risk_flags.includes('payment_failures')) o.risk_flags.push('payment_failures');
        logE(o, 'payment_failed', 'stripe', { code: digits.endsWith('9995') ? 'insufficient_funds' : 'card_declined' });
        a.logEvent(o.restaurant_id, 'payment_failed');
        a.save();
        throw new DemoError(digits.endsWith('9995') ? 'Fondi insufficienti: prova con un’altra carta.' : 'La carta è stata rifiutata: prova con un’altra carta.');
      }
      Object.assign(o, { payment_status: 'paid', paid_at: now(), amount_paid: o.total, status: 'pending_restaurant' });
      logE(o, 'payment_succeeded', 'stripe', { amount: o.total, source: 'demo' });
      applyPaid(o);
      a.save();
      return view(o);
    },

    track(num: string, token: string | null): OrderView | null {
      const o = access(num, token);
      a.save();
      return o ? view(o) : null;
    },
    customerCancel(num: string, token: string | null, reason: string | null) {
      const o = access(num, token) ?? fail('Ordine non trovato.');
      if (!['pending_payment', 'payment_authorized', 'pending_restaurant'].includes(o.status)) fail('Il ristorante ha già accettato l’ordine: per annullarlo usa «Segnala un problema».');
      const r = transition(o, 'cancel', { reason: reason?.trim() || 'Annullato dal cliente' }, 'customer');
      processRefunds(o);
      a.save();
      return r;
    },
    reportIssue(num: string, token: string | null, type: IssueType, description: string) {
      const o = access(num, token) ?? fail('Ordine non trovato.');
      if (o.status === 'pending_payment') fail('L’ordine non è ancora stato pagato.');
      if (description.trim().length < 5) fail('Descrivi il problema (almeno 5 caratteri).');
      if (o.issues.filter((x) => Date.parse(x.created_at) > Date.now() - DAY).length >= 3) fail('Hai già inviato diverse segnalazioni per questo ordine: ti risponderemo al più presto.');
      const id = uuid();
      o.issues.push({ id, type, description: description.trim().slice(0, 1000), status: 'open', resolution: null, user_id: a.uid(), created_at: now() });
      logE(o, 'issue_reported', 'customer', { type });
      a.notifyAdmins('order_issue', 'Problema segnalato su un ordine', o.order_number, `/admin/orders?q=${o.order_number}`);
      notifyRestaurant(o, `issue:${id}`, `Problema segnalato · ${o.order_number}`, 'Il cliente ha segnalato un problema: lo staff AsiaFood lo gestirà con te.');
      a.save();
      return id;
    },
    myOrders(limit = 20, offset = 0) {
      const uid = a.uid() ?? fail('Accedi per continuare.');
      const mine = st().orders.filter((o) => o.user_id === uid && !(o.status === 'pending_payment' && Date.parse(o.created_at) < Date.now() - DAY));
      const items: MyOrderSummary[] = mine.slice(offset, offset + limit).map((o) => {
        const r = rest(o.restaurant_id)!;
        return { id: o.id, order_number: o.order_number, status: o.status, payment_status: o.payment_status, order_type: o.order_type, total: o.total, created_at: o.created_at,
          scheduled_for: o.scheduled_for, estimated_ready_at: o.estimated_ready_at, restaurant: { id: r.id, name: r.name, slug: r.slug, logo_url: r.logo_url ?? null },
          items_count: o.items.reduce((s, i) => s + i.quantity, 0), summary: o.items.map((i) => `${i.quantity}× ${i.name}`).join(', ') };
      });
      return { total: mine.length, items };
    },

    // ─── Indirizzi e carrello ─────────────────────────────────
    addresses: () => st().addresses.filter((x) => x.user_id === (a.uid() ?? fail('Accedi per continuare.'))),
    saveAddress(input: AddressInput & { is_default?: boolean }) {
      const uid = a.uid() ?? fail('Accedi per continuare.');
      if ((input.recipient_name ?? '').trim().length < 2) fail('Inserisci il nome del destinatario.');
      if (!PHONE_RE.test(input.phone ?? '')) fail('Inserisci un numero di telefono valido.');
      if ((input.address_line_1 ?? '').trim().length < 3) fail('Inserisci via e numero civico.');
      if (!/^\d{5}$/.test(input.postal_code ?? '')) fail('CAP non valido.');
      if ((input.latitude == null) !== (input.longitude == null)) fail('Coordinate non valide.');
      const list = st().addresses;
      let x = input.id ? list.find((y) => y.id === input.id && y.user_id === uid) : undefined;
      if (!x) {
        if (list.filter((y) => y.user_id === uid).length >= 10) fail('Puoi salvare al massimo 10 indirizzi.');
        x = { ...input, id: uuid(), user_id: uid, is_default: false, created_at: now(), country: 'IT' } as CustomerAddress;
        list.push(x);
      } else Object.assign(x, input);
      if (input.is_default || list.filter((y) => y.user_id === uid).length === 1) list.filter((y) => y.user_id === uid).forEach((y) => (y.is_default = y.id === x!.id));
      a.save();
      return x;
    },
    deleteAddress(id: string) {
      const uid = a.uid() ?? fail('Accedi per continuare.');
      st().addresses = st().addresses.filter((x) => !(x.id === id && x.user_id === uid));
      a.save();
    },
    saveCart(payload: { restaurant_id: string; items: unknown[] } | null) {
      const uid = a.uid();
      if (!uid) return;
      st().carts.filter((c) => c.user_id === uid && c.status === 'active').forEach((c) => (c.status = 'cleared'));
      if (payload && payload.items.length) st().carts.push({ user_id: uid, restaurant_id: payload.restaurant_id, status: 'active', updated_at: now(), payload: payload as unknown as Row });
      a.save();
    },
    loadCart() {
      const uid = a.uid();
      return (uid && st().carts.find((c) => c.user_id === uid && c.status === 'active')?.payload) || null;
    },

    // ─── Ristorante ───────────────────────────────────────────
    restaurantOrders(rid: string, tab: RestaurantOrderTab): RestaurantOrdersPage {
      if (!canView(rid)) fail('Non autorizzato');
      const statuses: Record<RestaurantOrderTab, OrderStatus[]> = {
        new: ['pending_restaurant'], preparing: ['accepted', 'preparing'], ready: ['ready'], delivering: ['out_for_delivery'],
        completed: ['completed', 'refunded', 'partially_refunded'], cancelled: ['rejected', 'cancelled'],
      };
      const mine = st().orders.filter((o) => o.restaurant_id === rid && o.status !== 'pending_payment');
      const recent = (o: DemoOrder) => Date.parse(o.completed_at ?? o.rejected_at ?? o.cancelled_at ?? o.created_at) > Date.now() - DAY;
      const personal = (o: DemoOrder) => ACTIVE.includes(o.status) || recent(o);
      const list = mine.filter((o) => statuses[tab].includes(o.status) && (!['completed', 'cancelled'].includes(tab) || Date.parse(o.created_at) > Date.now() - 7 * DAY) && (tab !== 'cancelled' || !!o.paid_at))
        .sort((x, y) => (['completed', 'cancelled'].includes(tab) ? y.created_at.localeCompare(x.created_at)
          : Date.parse(x.scheduled_for ?? x.estimated_ready_at ?? x.created_at) - Date.parse(y.scheduled_for ?? y.estimated_ready_at ?? y.created_at)));
      const items: RestaurantOrder[] = list.map((o) => ({
        id: o.id, order_number: o.order_number, status: o.status, payment_status: o.payment_status, order_type: o.order_type, created_at: o.created_at, paid_at: o.paid_at,
        scheduled_for: o.scheduled_for, estimated_ready_at: o.estimated_ready_at, estimated_delivery_at: o.estimated_delivery_at, accepted_at: o.accepted_at, ready_at: o.ready_at,
        preparation_minutes: o.preparation_minutes, customer_name: personal(o) ? o.customer_name : o.customer_name.split(' ')[0]!, customer_phone: personal(o) ? o.customer_phone : null,
        delivery_address: o.order_type === 'delivery' && personal(o) && o.delivery_address ? (({ latitude: _a, longitude: _b, geocode_source: _c, ...rest0 }) => rest0)(o.delivery_address) : null,
        delivery_distance_km: o.delivery_distance_km, customer_notes: o.customer_notes, restaurant_notes: o.restaurant_notes, subtotal: o.subtotal, discount_total: o.discount_total,
        delivery_fee: o.delivery_fee, service_fee: o.service_fee, total: o.total, coupon_code: o.coupon_code, platform_fee: o.platform_fee, restaurant_gross: o.restaurant_gross,
        restaurant_net_estimated: o.restaurant_net_estimated, amount_paid: o.amount_paid, amount_refunded: o.amount_refunded, reject_reason: o.reject_reason, cancel_reason: o.cancel_reason,
        is_repeat_customer: !!o.user_id && st().orders.some((y) => y.user_id === o.user_id && y.restaurant_id === rid && y.id !== o.id && y.status === 'completed'),
        items: o.items.map((i) => ({ name: i.name, variant: i.variant, quantity: i.quantity, line_total: i.line_total, notes: i.notes, options: i.options.map((x) => ({ group: x.group, name: x.name, quantity: x.quantity })) })),
        refunds: o.refunds.map((f) => ({ amount: f.amount, status: f.status, reason: f.reason, created_at: f.created_at })),
        open_issues: o.issues.filter((x) => ['open', 'in_progress'].includes(x.status)).length,
      }));
      const count = (t: RestaurantOrderTab) => mine.filter((o) => statuses[t].includes(o.status) && (t !== 'completed' || recent(o)) && (t !== 'cancelled' || (!!o.paid_at && recent(o)))).length;
      return { counts: { new: count('new'), preparing: count('preparing'), ready: count('ready'), delivering: count('delivering'), completed: count('completed'), cancelled: count('cancelled') }, can_refund: canRefund(rid), items };
    },
    action(orderId: string, action: string, p: Row = {}) {
      const uid = a.uid() ?? fail('Accedi per continuare.');
      const o = byId(orderId);
      if (!canView(o.restaurant_id)) fail('Ordine non trovato.');
      void uid;
      if (action === 'note') {
        o.restaurant_notes = typeof p.note === 'string' && p.note.trim() ? p.note.trim().slice(0, 300) : null;
        a.save();
        return { ok: true, status: o.status };
      }
      if (action === 'cancel' && !a.isAdmin()) fail('Solo lo staff AsiaFood può annullare un ordine accettato.');
      const r = transition(o, action, p, a.isAdmin() && !memberRole(o.restaurant_id) ? 'admin' : 'restaurant');
      processRefunds(o);
      a.save();
      return r;
    },
    refund(orderId: string, amount: number, reason: string) {
      const o = byId(orderId);
      if (!canRefund(o.restaurant_id)) fail('Non hai i permessi per questa operazione.');
      if (!a.isAdmin() && o.paid_at && Date.parse(o.paid_at) < Date.now() - setting('order_restaurant_refund_days', 14) * DAY) fail('Il periodo per rimborsare questo ordine è scaduto: contatta il supporto AsiaFood.');
      if (!['paid', 'partially_refunded'].includes(o.payment_status)) fail('L’ordine non risulta pagato.');
      const pending = o.refunds.filter((x) => ['pending', 'processing'].includes(x.status)).reduce((s, x) => s + x.amount, 0);
      const avail = round2(o.amount_paid - o.amount_refunded - pending);
      const amt = round2(amount);
      if (!(amt > 0) || amt > avail) fail('Importo non valido: non può superare quanto pagato e non ancora rimborsato.');
      if (reason.trim().length < 3) fail('Indica il motivo del rimborso.');
      o.refunds.push({ id: uuid(), amount: amt, reason: reason.trim().slice(0, 300), status: 'pending', requested_by_type: a.isAdmin() ? 'admin' : 'restaurant', created_at: now(), processed_at: null, stripe_refund_id: null, error: null });
      logE(o, 'refund_requested', a.isAdmin() ? 'admin' : 'restaurant', { amount: amt });
      processRefunds(o);
      a.save();
      return { ok: true };
    },
    setPause(rid: string, kind: 'all' | 'delivery' | 'takeaway' | 'busy', minutes: number | null) {
      if (!canView(rid)) fail('Non autorizzato');
      const s = settingsOf(rid) ?? fail('Configura prima gli ordini online.');
      if (kind === 'busy') {
        if (minutes == null || minutes < 0 || minutes > 180) fail('Minuti non validi (0–180).');
        s.busy_extra_minutes = minutes!;
      } else {
        const until = minutes == null ? 'infinity' : minutes <= 0 ? null : new Date(Date.now() + minutes * MIN).toISOString();
        if (kind === 'all') s.orders_paused_until = until;
        if (kind === 'delivery') s.delivery_paused_until = until;
        if (kind === 'takeaway') s.takeaway_paused_until = until;
      }
      a.save();
      return { ...s };
    },
    setItemAvailability(itemId: string, mode: 'today' | 'off' | 'on') {
      const it = a.db.menu_items.find((x) => x.id === itemId) ?? fail('Piatto non trovato.');
      if (!canView(it.restaurant_id)) fail('Non autorizzato');
      if (mode === 'today') it.unavailable_until = romeLocalToUtc(romeDate(new Date(Date.now() + DAY)), '00:00').toISOString();
      else if (mode === 'off') Object.assign(it, { is_available: false, unavailable_until: null });
      else Object.assign(it, { is_available: true, unavailable_until: null });
      a.save();
      return { id: it.id, is_available: it.is_available, unavailable_until: it.unavailable_until ?? null };
    },
    getSettings(rid: string) {
      if (!canView(rid)) fail('Non autorizzato');
      return { settings: settingsOf(rid), zones: st().delivery_zones.filter((z) => z.restaurant_id === rid) };
    },
    saveSettings(rid: string, patch: Partial<RestaurantOrderSettings>) {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      let s = settingsOf(rid);
      if (!s) {
        s = { id: uuid(), restaurant_id: rid, orders_enabled: false, takeaway_enabled: true, delivery_enabled: false, minimum_order_amount: 0, takeaway_minimum_order: null, delivery_minimum_order: null,
          default_preparation_minutes: 20, busy_extra_minutes: 0, delivery_estimated_minutes: 25, slot_interval_minutes: 15, max_orders_per_slot: null, accept_orders_automatically: false,
          allow_scheduled_orders: true, max_advance_days: 2, delivery_radius_km: null, free_delivery_threshold: null, delivery_fee_type: 'fixed', delivery_fee: 0, delivery_provider_type: 'restaurant',
          service_fee_enabled: true, orders_paused_until: null, delivery_paused_until: null, takeaway_paused_until: null, pickup_instructions: null };
        st().order_settings.push(s);
      }
      const { id: _i, restaurant_id: _r, ...rest0 } = patch;
      // Solo l'Admin abilita i Rider AsiaFood; il ristorante li sceglie solo se abilitato
      if (!a.isAdmin()) delete rest0.asiafood_delivery_enabled;
      if ((rest0.delivery_provider_type ?? s.delivery_provider_type) === 'asiafood' && !(rest0.asiafood_delivery_enabled ?? s.asiafood_delivery_enabled)) {
        fail('Le consegne con Rider AsiaFood non sono ancora attive per questo ristorante.');
      }
      if (rest0.default_preparation_minutes != null && (rest0.default_preparation_minutes < 5 || rest0.default_preparation_minutes > 240)) fail('Tempo di preparazione non valido (5–240).');
      if (rest0.minimum_order_amount != null && (rest0.minimum_order_amount < 0 || rest0.minimum_order_amount > 1000)) fail('Ordine minimo non valido.');
      if (rest0.max_advance_days != null && (rest0.max_advance_days < 0 || rest0.max_advance_days > 14)) fail('Giorni di anticipo non validi (0–14).');
      if (rest0.delivery_radius_km != null && (rest0.delivery_radius_km < 0.5 || rest0.delivery_radius_km > 50)) fail('Raggio di consegna non valido (0,5–50 km).');
      Object.assign(s, rest0);
      a.save();
      return { ...s };
    },
    saveZone(rid: string, z: Partial<DeliveryZone>) {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      if (!z.name?.trim()) return fail('Nome zona obbligatorio.');
      if ((z.max_distance_km ?? 0) <= (z.min_distance_km ?? 0)) fail('La distanza massima deve superare la minima.');
      const list = st().delivery_zones;
      const ex = z.id ? list.find((x) => x.id === z.id && x.restaurant_id === rid) : undefined;
      const row: DeliveryZone = { id: ex?.id ?? uuid(), restaurant_id: rid, name: (z.name ?? "").trim(), zone_type: 'distance', radius_km: null, min_distance_km: z.min_distance_km ?? 0,
        max_distance_km: z.max_distance_km ?? 3, delivery_fee: z.delivery_fee ?? 0, minimum_order: z.minimum_order ?? 0, estimated_delivery_minutes: z.estimated_delivery_minutes ?? 30, is_active: z.is_active ?? true };
      if (ex) Object.assign(ex, row);
      else list.push(row);
      a.save();
      return row;
    },
    deleteZone(rid: string, id: string) {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      st().delivery_zones = st().delivery_zones.filter((z) => !(z.id === id && z.restaurant_id === rid));
      a.save();
    },
    saveOptionGroup(rid: string, g: Omit<Partial<MenuOptionGroup>, 'options'> & { menu_item_id: string; options: { id?: string; name: string; price: number; is_available?: boolean }[] }) {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      if (!a.db.menu_items.some((i) => i.id === g.menu_item_id && i.restaurant_id === rid)) fail('Piatto non valido.');
      if (!g.name?.trim()) return fail('Nome del gruppo obbligatorio.');
      const max = g.max_select ?? 1;
      const min = g.min_select ?? 0;
      if (max < 1 || min < 0 || max < min) fail('Minimo/massimo non validi.');
      if (!g.options.length || g.options.some((o) => !o.name.trim() || o.price < 0)) fail('Aggiungi almeno un’opzione con nome e prezzo validi.');
      const list = st().option_groups;
      const ex = g.id ? list.find((x) => x.id === g.id && x.restaurant_id === rid) : undefined;
      const id = ex?.id ?? uuid();
      const row: MenuOptionGroup = { id, menu_item_id: g.menu_item_id, restaurant_id: rid, name: (g.name ?? "").trim().slice(0, 60), min_select: min, max_select: max, required: g.required ?? min > 0,
        display_order: g.display_order ?? list.filter((x) => x.menu_item_id === g.menu_item_id).length, is_active: g.is_active ?? true,
        options: g.options.map((o, i) => ({ id: o.id ?? uuid(), option_group_id: id, restaurant_id: rid, name: o.name.trim().slice(0, 60), price: round2(o.price), is_available: o.is_available ?? true, display_order: i })) };
      if (ex) Object.assign(ex, row);
      else list.push(row);
      a.save();
      return row;
    },
    deleteOptionGroup(rid: string, id: string) {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      st().option_groups = st().option_groups.filter((g) => !(g.id === id && g.restaurant_id === rid));
      a.save();
    },
    allOptionGroups(rid: string) {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      return st().option_groups.filter((g) => g.restaurant_id === rid);
    },

    // ─── Stripe Connect (SIMULATO in DEMO) ────────────────────
    payoutStatus(rid: string): PayoutStatus {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      const acct = st().payout_accounts.find((p) => p.restaurant_id === rid);
      return { configured: true, environment: 'test', simulated: true, account: acct ? { ...acct, stripe_environment: 'test' } : null };
    },
    payoutOnboard(rid: string) {
      const isOwner = memberRole(rid) === 'owner' || a.isAdmin();
      if (!isOwner) fail('Solo il titolare può configurare i pagamenti.');
      let acct = st().payout_accounts.find((p) => p.restaurant_id === rid);
      if (!acct) {
        acct = { restaurant_id: rid, stripe_account_id: `acct_demo_${code(10)}`, onboarding_completed: false, charges_enabled: false, payouts_enabled: false, details_submitted: false, requirements_due: ['external_account'], updated_at: now() };
        st().payout_accounts.push(acct);
      }
      // Simulazione dell'onboarding Stripe: in produzione i dati (IBAN, documenti) li raccoglie Stripe
      Object.assign(acct, { onboarding_completed: true, charges_enabled: true, payouts_enabled: true, details_submitted: true, requirements_due: [], updated_at: now() });
      a.save();
      return { url: null as string | null, simulated: true };
    },
    restaurantStats(rid: string, days = 30): RestaurantOrderStats {
      if (!a.canManage(rid)) fail('Non autorizzato');
      const since = Date.now() - days * DAY;
      const list = st().orders.filter((o) => o.restaurant_id === rid && Date.parse(o.created_at) >= since);
      const valid = list.filter(isValid);
      const byUser = new Map<string, number>();
      st().orders.filter((o) => o.restaurant_id === rid && o.user_id && isValid(o)).forEach((o) => byUser.set(o.user_id!, (byUser.get(o.user_id!) ?? 0) + 1));
      const top = new Map<string, { quantity: number; revenue: number }>();
      valid.forEach((o) => o.items.forEach((i) => {
        const t = top.get(i.name) ?? { quantity: 0, revenue: 0 };
        t.quantity += i.quantity;
        t.revenue = round2(t.revenue + i.line_total);
        top.set(i.name, t);
      }));
      const paid = list.filter((o) => o.paid_at);
      const prepTimes = list.filter((o) => o.ready_at && o.accepted_at).map((o) => (Date.parse(o.ready_at!) - Date.parse(o.accepted_at!)) / MIN);
      return {
        orders: valid.length, gross: round2(valid.reduce((s, o) => s + o.restaurant_gross, 0)), commission: round2(valid.reduce((s, o) => s + o.platform_fee, 0)),
        net_estimated: round2(valid.reduce((s, o) => s + o.restaurant_net_estimated, 0)), aov: valid.length ? round2(valid.reduce((s, o) => s + o.total, 0) / valid.length) : 0,
        takeaway: valid.filter((o) => o.order_type === 'takeaway').length, delivery: valid.filter((o) => o.order_type === 'delivery').length,
        cancel_rate: paid.length ? Math.round((paid.filter((o) => ['rejected', 'cancelled'].includes(o.status)).length * 1000) / paid.length) / 10 : 0,
        repeat_customers: [...byUser.values()].filter((n) => n >= 2).length, customers: byUser.size, coupon_orders: valid.filter((o) => o.coupon_id).length,
        refunded: round2(list.reduce((s, o) => s + o.amount_refunded, 0)),
        top_items: [...top.entries()].map(([name, v]) => ({ name, ...v })).sort((x, y) => y.quantity - x.quantity).slice(0, 8),
        avg_prep_minutes: prepTimes.length ? Math.round(prepTimes.reduce((s, x) => s + x, 0) / prepTimes.length) : null,
      };
    },

    // ─── Admin ────────────────────────────────────────────────
    adminList(f: AdminOrderFilters = {}) {
      if (!a.isAdmin()) fail('Non autorizzato');
      const q = f.q?.trim().toLowerCase();
      const list = st().orders.filter((o) => {
        const r = rest(o.restaurant_id);
        return (!f.status || o.status === f.status) && (!f.payment_status || o.payment_status === f.payment_status) && (!f.order_type || o.order_type === f.order_type)
          && (!f.restaurant_id || o.restaurant_id === f.restaurant_id) && (!f.city_id || r?.city_id === f.city_id)
          && (!f.from || o.created_at >= f.from) && (!f.to || o.created_at.slice(0, 10) <= f.to)
          && (!f.issues || o.issues.some((x) => ['open', 'in_progress'].includes(x.status)) || o.risk_flags.length > 0)
          && (!q || o.order_number.toLowerCase().includes(q) || r?.name.toLowerCase().includes(q) || o.customer_email.includes(q));
      });
      const off = f.offset ?? 0;
      const items: AdminOrderRow[] = list.slice(off, off + (f.limit ?? 50)).map((o) => {
        const r = rest(o.restaurant_id)!;
        return { id: o.id, order_number: o.order_number, restaurant: { id: r.id, name: r.name, slug: r.slug }, city: a.db.cities.find((c) => c.id === r.city_id)?.name ?? null,
          customer_name: o.customer_name, order_type: o.order_type, total: o.total, status: o.status, payment_status: o.payment_status, platform_fee: o.platform_fee, service_fee: o.service_fee,
          amount_refunded: o.amount_refunded, risk_flags: o.risk_flags, created_at: o.created_at, open_issues: o.issues.filter((x) => ['open', 'in_progress'].includes(x.status)).length };
      });
      return { total: list.length, items };
    },
    adminDetail(id: string): AdminOrderDetail {
      if (!a.isAdmin()) fail('Non autorizzato');
      const o = byId(id);
      return { ...view(o), internal: { commission_percent: o.commission_percent, commission_fixed: o.commission_fixed, platform_fee: o.platform_fee, restaurant_gross: o.restaurant_gross,
        restaurant_net_estimated: o.restaurant_net_estimated, payment_processing_fee: null, payment_mode: 'demo', payout_destination: st().payout_accounts.find((p) => p.restaurant_id === o.restaurant_id)?.stripe_account_id ?? null,
        stripe_environment: null, stripe_payment_intent_id: null, stripe_charge_id: null, payment_failures: o.payment_failures, risk_flags: o.risk_flags, internal_notes: o.internal_notes,
        restaurant_notes: o.restaurant_notes, source: o.source, user_id: o.user_id, delivery_distance_km: o.delivery_distance_km },
        events: o.events, refunds_admin: o.refunds.map((f) => ({ id: f.id, amount: f.amount, status: f.status, reason: f.reason, stripe_refund_id: f.stripe_refund_id, error: f.error, requested_by_type: f.requested_by_type, created_at: f.created_at, processed_at: f.processed_at })),
        issues_admin: o.issues.map((x) => ({ id: x.id, type: x.type, description: x.description, status: x.status, resolution: x.resolution, created_at: x.created_at })) };
    },
    adminUpdate(id: string, p: { internal_notes?: string; issue_id?: string; issue_status?: string; resolution?: string }) {
      if (!a.isAdmin()) fail('Non autorizzato');
      const o = byId(id);
      if (p.internal_notes !== undefined) {
        o.internal_notes = p.internal_notes.trim().slice(0, 1000) || null;
        logE(o, 'internal_note', 'admin');
      }
      if (p.issue_id) {
        const x = o.issues.find((y) => y.id === p.issue_id);
        if (x) Object.assign(x, { status: p.issue_status ?? x.status, resolution: p.resolution?.trim() || x.resolution });
        logE(o, 'issue_updated', 'admin', { status: p.issue_status });
      }
      a.save();
    },
    commissions(): CommissionSettings {
      if (!a.isAdmin()) fail('Non autorizzato');
      return { global_percent: setting('platform_commission_percent', 10), global_fixed: setting('platform_commission_fixed', 0), service_fee_enabled: flag('service_fee_enabled', false),
        service_fee_amount: setting('service_fee_amount', 0.99),
        overrides: st().commissions.map((c) => ({ ...c, restaurant_name: rest(c.restaurant_id)?.name ?? '' })).sort((x, y) => y.effective_from.localeCompare(x.effective_from)) };
    },
    saveGlobalCommission(p: { percent: number; fixed: number; service_fee_enabled: boolean; service_fee_amount: number }) {
      if (!a.isAdmin()) fail('Non autorizzato');
      if (p.percent < 0 || p.percent > 50 || p.fixed < 0 || p.fixed > 20 || p.service_fee_amount < 0 || p.service_fee_amount > 10) fail('Valori non validi.');
      Object.assign(a.db.settings, { platform_commission_percent: p.percent, platform_commission_fixed: p.fixed, service_fee_enabled: p.service_fee_enabled, service_fee_amount: p.service_fee_amount });
      a.save();
    },
    addCommissionOverride(p: { restaurant_id: string; percentage_fee: number; fixed_fee: number; note?: string | null }) {
      if (!a.isAdmin()) fail('Non autorizzato');
      if (p.percentage_fee < 0 || p.percentage_fee > 50 || p.fixed_fee < 0 || p.fixed_fee > 20) fail('Valori non validi.');
      st().commissions.push({ id: uuid(), restaurant_id: p.restaurant_id, percentage_fee: p.percentage_fee, fixed_fee: p.fixed_fee, effective_from: now(), note: p.note ?? null, created_at: now() });
      a.save();
    },
    marketplaceStats(days = 30): MarketplaceStats {
      if (!a.isAdmin()) fail('Non autorizzato');
      const since = Date.now() - days * DAY;
      const today = romeLocalToUtc(romeDate(), '00:00').getTime();
      const month = romeLocalToUtc(`${romeDate().slice(0, 7)}-01`, '00:00').getTime();
      const all = st().orders;
      const period = all.filter((o) => Date.parse(o.created_at) >= since);
      const valid = period.filter(isValid);
      const paid = period.filter((o) => o.paid_at);
      const sum = (xs: DemoOrder[], f: (o: DemoOrder) => number) => round2(xs.reduce((s, o) => s + f(o), 0));
      const catOf = (rid: string) => {
        const rc = a.db.restaurant_categories.find((x) => x.restaurant_id === rid && x.is_primary) ?? a.db.restaurant_categories.find((x) => x.restaurant_id === rid);
        return a.db.categories.find((c) => c.id === rc?.category_id)?.name ?? '—';
      };
      const group = (key: (o: DemoOrder) => string) => {
        const m = new Map<string, { orders: number; gmv: number }>();
        valid.forEach((o) => {
          const k = key(o);
          const v = m.get(k) ?? { orders: 0, gmv: 0 };
          v.orders++;
          v.gmv = round2(v.gmv + o.total);
          m.set(k, v);
        });
        return [...m.entries()].map(([name, v]) => ({ name, ...v })).sort((x, y) => y.orders - x.orders).slice(0, 8);
      };
      const ev = a.db.analytics.filter((e) => Date.parse(e.created_at) >= since);
      const step = (t: string, label: string) => ({ step: t, label, events: ev.filter((e) => e.event_type === t).length, sessions: new Set(ev.filter((e) => e.event_type === t && e.session_id).map((e) => e.session_id)).size || null });
      const daily: MarketplaceStats['daily'] = [];
      for (let i = Math.min(days, 60) - 1; i >= 0; i--) {
        const d = romeDate(new Date(Date.now() - i * DAY));
        const xs = all.filter((o) => isValid(o) && romeDate(new Date(o.created_at)) === d);
        daily.push({ day: d, orders: xs.length, gmv: sum(xs, (o) => o.total) });
      }
      return {
        definitions: {
          gmv: 'Valore lordo degli ordini validi (totale pagato dal cliente, incluse consegna e costo di servizio) prima delle commissioni. Validi = pagamento incassato e ordine non rifiutato, annullato o rimborsato per intero.',
          revenue: 'Commissioni AsiaFood + costi di servizio maturati sugli ordini completati, al netto della quota rimborsata.',
          aov: 'GMV diviso numero di ordini validi.',
          refund_rate: 'Ordini pagati con almeno un rimborso riuscito, sul totale degli ordini pagati.',
          funnel: 'Passi 1–4: eventi anonimi (una sessione può generarne più di uno). Passi 5–6: ordini reali.',
        },
        orders_today: all.filter((o) => o.paid_at && Date.parse(o.created_at) >= today).length,
        orders_month: all.filter((o) => o.paid_at && Date.parse(o.created_at) >= month).length,
        orders_period: paid.length, valid_orders: valid.length, gmv: sum(valid, (o) => o.total), gmv_net_of_refunds: sum(valid, (o) => o.total - o.amount_refunded),
        aov: valid.length ? round2(sum(valid, (o) => o.total) / valid.length) : 0,
        completed: period.filter((o) => ['completed', 'partially_refunded', 'refunded'].includes(o.status)).length,
        cancelled: period.filter((o) => ['cancelled', 'rejected'].includes(o.status) && o.paid_at).length,
        unpaid_expired: period.filter((o) => !o.paid_at && o.status === 'cancelled').length,
        refund_rate: paid.length ? Math.round((paid.filter((o) => o.amount_refunded > 0).length * 1000) / paid.length) / 10 : 0,
        refunded_amount: sum(period, (o) => o.amount_refunded),
        takeaway: valid.filter((o) => o.order_type === 'takeaway').length, delivery: valid.filter((o) => o.order_type === 'delivery').length,
        platform_revenue: sum(period.filter((o) => ['completed', 'partially_refunded'].includes(o.status)), (o) => (o.platform_fee + o.service_fee) * (o.amount_paid > 0 ? 1 - o.amount_refunded / o.amount_paid : 0)),
        platform_fees_pending: sum(valid.filter((o) => !['completed', 'partially_refunded'].includes(o.status)), (o) => o.platform_fee + o.service_fee),
        payments: {
          failed_attempts: period.reduce((s, o) => s + o.payment_failures, 0), awaiting_payment: all.filter((o) => o.status === 'pending_payment' && Date.parse(o.created_at) > Date.now() - 3600_000).length,
          awaiting_restaurant: all.filter((o) => o.status === 'pending_restaurant').length, refunds_pending: all.reduce((s, o) => s + o.refunds.filter((f) => ['pending', 'processing'].includes(f.status)).length, 0),
          refunds_failed: period.reduce((s, o) => s + o.refunds.filter((f) => f.status === 'failed').length, 0), disputes: period.filter((o) => o.risk_flags.includes('dispute')).length,
          risk_flagged: period.filter((o) => o.risk_flags.length > 0).length, open_issues: all.reduce((s, o) => s + o.issues.filter((x) => ['open', 'in_progress'].includes(x.status)).length, 0), webhook_failures: 0,
        },
        top_categories: group((o) => catOf(o.restaurant_id)),
        top_cities: group((o) => a.db.cities.find((c) => c.id === rest(o.restaurant_id)?.city_id)?.name ?? '—'),
        daily,
        funnel: [
          step('restaurant_view', 'Visite scheda'), step('menu_view', 'Menu visti'), step('add_to_cart', 'Aggiunte al carrello'), step('checkout_started', 'Checkout avviati'),
          { step: 'paid', label: 'Ordini pagati', events: paid.length, sessions: null },
          { step: 'completed', label: 'Ordini completati', events: period.filter((o) => ['completed', 'partially_refunded', 'refunded'].includes(o.status)).length, sessions: null },
        ],
        abandoned_carts: ev.filter((e) => e.event_type === 'abandoned_cart').length,
      };
    },

    /** Scheduler (in produzione: orders-cron ogni 5 minuti). */
    tick(): OrdersTickResult {
      const out: OrdersTickResult = { expired: 0, accept_timeouts: 0, reminders: 0, abandoned_carts: 0, refunds_processed: 0 };
      const unpaid = setting('order_unpaid_expiry_minutes', 30);
      const accept = setting('order_accept_timeout_minutes', 20);
      for (const o of st().orders) {
        if (o.status === 'pending_payment' && Date.parse(o.created_at) < Date.now() - unpaid * MIN) {
          Object.assign(o, { status: 'cancelled', cancelled_at: now(), fulfillment_status: 'cancelled', cancel_reason: 'Pagamento non completato in tempo', payment_status: o.payment_status === 'pending' ? 'failed' : o.payment_status });
          logE(o, 'cancelled', 'system', { reason: 'payment_timeout' });
          out.expired++;
        }
        if (accept > 0 && o.status === 'pending_restaurant' && o.paid_at && (!o.scheduled_for || Date.parse(o.scheduled_for) <= Date.now() + 2 * 3600_000)) {
          const age = Date.now() - Date.parse(o.paid_at);
          if (age > accept * MIN) {
            transition(o, 'cancel', { reason: 'Il ristorante non ha confermato in tempo' }, 'system');
            const before = o.refunds.filter((f) => f.status === 'succeeded').length;
            processRefunds(o);
            out.refunds_processed! += o.refunds.filter((f) => f.status === 'succeeded').length - before;
            out.accept_timeouts++;
          } else if (age > (accept / 2) * MIN) {
            notifyRestaurant(o, 'reminder', `Ordine in attesa ${o.order_number}`, 'Il cliente sta aspettando la conferma.');
            out.reminders++;
          }
        }
      }
      for (const c of st().carts.filter((x) => x.status === 'active' && Date.parse(x.updated_at) < Date.now() - setting('order_abandoned_cart_hours', 2) * 3600_000)) {
        c.status = 'abandoned';
        a.logEvent(c.restaurant_id, 'abandoned_cart');
        out.abandoned_carts++;
      }
      a.save();
      return out;
    },
    /** Solo per il motore del carrello: prezzi indicativi dal menu locale. */
    completedOrders: () => st().orders.map((o) => ({ id: o.id, user_id: o.user_id, restaurant_id: o.restaurant_id, status: o.status, completed_at: o.completed_at })),
  };
}

export { DemoError as MarketDemoError };
export type { OrderType };
