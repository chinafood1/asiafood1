// ─────────────────────────────────────────────────────────────
//  Fase 12 · API di lancio su Supabase: RPC della migrazione 0024.
//  Ogni controllo di permesso è nel database (is_admin / can_manage_restaurant).
// ─────────────────────────────────────────────────────────────
import { supabase } from '@/lib/supabase';
import { fromDbMessage } from '@/lib/errors';
import type { LaunchApi } from '@/types/launch';

async function call<T>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  if (!supabase) throw new Error('Supabase non configurato');
  const { data, error } = await supabase.rpc(fn, args);
  if (error) {
    const coded = fromDbMessage(error.message);
    if (coded) throw coded;
    if (error.code === '42501' || /permission denied/i.test(error.message)) throw new Error('Operazione non consentita.');
    throw new Error(error.message);
  }
  return data as T;
}
/** Eventi "fire and forget": mai un errore visibile all'utente per un tracciamento. */
const quiet = (p: Promise<unknown>) => p.then(() => undefined, () => undefined);

export const launchSupabase: LaunchApi = {
  marketLanding: (market = 'taranto') => call('market_landing', { p_market: market }),
  foundingBadge: (id) => call('founding_badge', { p_restaurant: id }),
  trackQrScan: (slug, kind) => quiet(call('track_qr_scan', { p_slug: slug, p_kind: kind })),
  recordVisit: (v) => quiet(call('record_visit', { p: v })),
  attributeSignup: (v) => call<boolean>('attribute_my_signup', { p: v }).catch(() => false),
  runningExperiments: () => call<{ key: string; variants: string[]; weights?: number[]; primary_metric?: string | null }[]>('running_experiments').catch(() => []),
  submitFeedback: async (input) => void (await call('submit_feedback', { p: input })),
  npsShouldAsk: () => call<boolean>('nps_should_ask').catch(() => false),
  ambassadorApply: (motivation) => call('ambassador_apply', { p_motivation: motivation }),
  myAmbassador: () => call('my_ambassador'),
  launchKit: (id) => call('launch_kit_status', { p_restaurant: id }),
  markLaunchKit: async (id, step) => void (await call('launch_kit_mark', { p_restaurant: id, p_step: step })),

  overview: (market = 'taranto') => call('admin_launch_overview', { p_market: market }),
  coverage: (market = 'taranto') => call('admin_launch_coverage', { p_market: market }),
  restaurants: (market, filter, search, limit, offset) =>
    call('admin_launch_restaurants', { p_market: market, p_filter: filter, p_search: search, p_limit: limit, p_offset: offset }),
  firstN: (market = 'taranto') => call('admin_launch_first_n', { p_market: market }),
  crmLeads: (market, kind, status, search, limit, offset) =>
    call('admin_crm_leads', { p_market: market, p_kind: kind, p_status: status, p_search: search, p_limit: limit, p_offset: offset }),
  crmLead: (id) => call('admin_crm_lead', { p_id: id }),
  crmUpsertLead: (patch) => call('admin_crm_upsert_lead', { p: patch }),
  crmLogActivity: (input) => call('admin_crm_log_activity', { p: input }),
  crmSyncRestaurantLeads: (market = 'taranto') => call('admin_crm_sync_restaurant_leads', { p_market: market }),
  crmTaskUpsert: (input) => call('admin_crm_task_upsert', { p: input }),
  crmTaskSetStatus: async (id, status) => void (await call('admin_crm_task_set_status', { p_id: id, p_status: status })),
  foundingActivate: (id, note) => call('admin_founding_activate', { p_restaurant: id, p_note: note }),
  foundingRevoke: async (id, reason) => void (await call('admin_founding_revoke', { p_restaurant: id, p_reason: reason })),
  foundingList: (market = 'taranto') => call('admin_founding_list', { p_market: market }),
  daily: (market = 'taranto') => call('admin_launch_daily', { p_market: market }),
  weekly: (market = 'taranto', weeks = 8) => call('admin_launch_weekly', { p_market: market, p_weeks: weeks }),
  partners: (market = 'taranto') => call('admin_launch_partners', { p_market: market }),
  generateFollowups: (market = 'taranto') => call('admin_launch_generate_followups', { p_market: market }),
  opsToday: () => call('admin_ops_today'),
  growth: (market = 'taranto', days = 30) => call('admin_launch_growth', { p_market: market, p_days: days }),
  setPhase: async (market, phase) => void (await call('admin_launch_set_phase', { p_market: market, p_phase: phase })),
  goalUpsert: (g) => call('admin_goal_upsert', { p: g }),
  goalDelete: async (id) => void (await call('admin_goal_delete', { p_id: id })),
  costAdd: (c) => call('admin_cost_add', { p: c }),
  costDelete: async (id) => void (await call('admin_cost_delete', { p_id: id })),
  experimentUpsert: (e) => call('admin_experiment_upsert', { p: e }),
  experimentSetStatus: async (id, status) => void (await call('admin_experiment_set_status', { p_id: id, p_status: status })),
  planItems: (market = 'taranto') => call('admin_plan_items', { p_market: market }),
  planItemUpdate: async (id, patch) => void (await call('admin_plan_item_update', { p_id: id, p: patch })),
  contentList: (market = 'taranto') => call('admin_content_list', { p_market: market }),
  contentUpsert: (c) => call('admin_content_upsert', { p: c }),
  contentDelete: async (id) => void (await call('admin_content_delete', { p_id: id })),
  seedSocialCalendar: (market = 'taranto', start = null) => call('admin_seed_social_calendar', { p_market: market, p_start: start }),
  codeUpsert: (c) => call('admin_code_upsert', { p: c }),
  feedbackList: (type, status, limit, offset) => call('admin_feedback_list', { p_type: type, p_status: status, p_limit: limit, p_offset: offset }),
  feedbackUpdate: async (id, status) => void (await call('admin_feedback_update', { p_id: id, p_status: status })),
  incidentUpsert: (i) => call('admin_incident_upsert', { p: i }),
  ambassadors: (market = 'taranto') => call('admin_ambassadors', { p_market: market }),
  ambassadorSetStatus: async (id, status, notes = null) => void (await call('admin_ambassador_set_status', { p_id: id, p_status: status, p_notes: notes })),
  expansionSignals: () => call('admin_expansion_signals'),
};
