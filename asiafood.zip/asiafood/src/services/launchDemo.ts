/* eslint-disable @typescript-eslint/no-explicit-any -- motore DEMO su un database locale eterogeneo (righe di più moduli) */
// ─────────────────────────────────────────────────────────────
//  Fase 12 in modalità DEMO: stesse regole della migrazione 0024 (launch.sql) su dati locali.
//  I numeri includono i locali DEMO solo se "show_demo_data" è attivo (sempre dichiarato in UI).
//  Nessun invio reale: CRM, contenuti, QR e attribuzione restano nel browser.
// ─────────────────────────────────────────────────────────────
import type {
  AmbassadorRow, Channel, ContentItem, CoverageRow, CrmActivity, CrmLead, CrmTask, DailyBoard, ExperimentRow, FeedbackRow, FoundingProgram,
  FoundingRow, Goal, GoalMetric, LaunchAlert, LaunchApi, LaunchIncident, LaunchOverview, LaunchPhase, LaunchRestaurantRow, LaunchRestaurantsPage, PartnerRow, PlanItem,
  ProgressItem, RestaurantFilter, Segment, TimeToValue, WeeklyReview, CostRow, AcquisitionCode,
} from '@/types/launch';
import { AppError } from '@/lib/errors';

type R = any;

export interface LaunchState {
  markets: { id: string; slug: string; name: string; province_code: string; status: LaunchPhase; launched_at: string | null }[];
  leads: (CrmLead & { created_by: string | null })[];
  activities: CrmActivity[];
  tasks: (CrmTask & { market_id: string | null })[];
  founding: (FoundingRow & { market_id: string; badge_visible: boolean; subscription_id: string | null })[];
  codes: AcquisitionCode[];
  visits: { channel: Channel; utm_source: string | null; utm_medium: string | null; utm_campaign: string | null; utm_content: string | null; landing_path: string | null; promo_code: string | null; created_at: string }[];
  user_acquisition: { user_id: string; channel: Channel; utm_source: string | null; utm_campaign: string | null; created_at: string }[];
  content: ContentItem[];
  ambassadors: Omit<AmbassadorRow, 'name' | 'email' | 'referrals' | 'qualified'>[];
  feedback: FeedbackRow[];
  incidents: LaunchIncident[];
  goals: Goal[];
  costs: CostRow[];
  experiments: ExperimentRow[];
  plan: PlanItem[];
  launch_progress: Record<string, { starter_kit_viewed_at: string | null; qr_kit_downloaded_at: string | null; materials_printed_at: string | null; social_launch_at: string | null }>;
  qr_scans: { restaurant_id: string; kind: string; created_at: string }[];
  audit: { action: string; entity_id: string; details: R; created_at: string }[];
  founding_foodies: Record<string, string>;
}

export interface LaunchAccess {
  db: R;
  save(): void;
  uid(): string | null;
  isAdmin(): boolean;
  canManage(restaurantId: string): boolean;
  demoVisible(): boolean;
  grantPlan(restaurantId: string, plan: string, expiresAt: string, note: string): Promise<string | null>;
  revokePlan(subscriptionId: string): Promise<void>;
  ensureReferralCode(uid: string): string;
  orders(): R[];
  reviews(): R[];
  referrals(): R[];
  businessReferrals(): R[];
  activityDays(): { user_id: string; day: string }[];
  pushUsers(): string[];
  supportTickets(): R[];
  deliveryIssues(): R[];
  orderIssues(): R[];
}

const now = () => new Date().toISOString();
const uuid = () => crypto.randomUUID();
const DAY = 86_400_000;
const ago = (days: number) => Date.now() - days * DAY;
const ts = (s: string | null | undefined) => (s ? Date.parse(s) : NaN);
const romeDay = (d: Date = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome' }).format(d);
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
const digits = (s: string | null | undefined) => (s ?? '').replace(/\D/g, '') || null;
function distKm(a: number, b: number, c: number, d: number) {
  const r = (x: number) => (x * Math.PI) / 180;
  const h = Math.sin(r(c - a) / 2) ** 2 + Math.cos(r(a)) * Math.cos(r(c)) * Math.sin(r(d - b) / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(Math.min(1, h)));
}
const deny = () => new AppError('FORBIDDEN', 'Operazione non consentita.');
const fail = (msg: string) => new Error(msg);

const PRIORITY_CITIES = ['taranto', 'massafra', 'martina-franca', 'grottaglie', 'manduria', 'castellaneta', 'ginosa', 'laterza', 'palagiano', 'mottola',
  'pulsano', 'leporano', 'san-giorgio-ionico', 'statte', 'crispiano', 'sava', 'lizzano', 'maruggio', 'avetrana'];
const LOCAL_QUERIES: [string, string, string][] = [
  ['sushi Taranto', 'sushi', 'taranto'], ['all you can eat Taranto', 'all-you-can-eat', 'taranto'], ['ristorante giapponese Taranto', 'giapponese', 'taranto'],
  ['ristorante cinese Taranto', 'cinese', 'taranto'], ['poke Taranto', 'poke', 'taranto'], ['ramen Taranto', 'ramen', 'taranto'],
  ['sushi Massafra', 'sushi', 'massafra'], ['sushi Martina Franca', 'sushi', 'martina-franca'], ['sushi Grottaglie', 'sushi', 'grottaglie'],
];
const OUTREACH: string[] = ['call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'claim_link_sent', 'follow_up'];
const RANK: Record<string, number> = { new: 0, researched: 1, contacted: 2, replied: 3, demo_scheduled: 4, demo_done: 5, claim_sent: 6, claimed: 7, trial: 8, activated: 9, paid: 10 };
const rank = (s: string | null | undefined) => (s != null && s in RANK ? RANK[s]! : -1);
const CLOSED = ['lost', 'not_interested', 'do_not_contact'];
const CHANNELS: Channel[] = ['organic_search', 'social', 'qr', 'direct', 'referral', 'restaurant_referral', 'paid_social', 'influencer', 'email', 'partner', 'offline', 'other'];
const cleanUtm = (v: unknown) => (typeof v === 'string' && v ? v.toLowerCase().replace(/[^a-z0-9_.-]/g, '').slice(0, 60) || null : null);

export const LAUNCH_SETTING_DEFAULTS: Record<string, unknown> = {
  launch_phase: 'private_beta', founding_program_enabled: true, founding_program_name: 'Partner Fondatore AsiaFood Taranto', founding_limit: 30,
  founding_plan: 'premium', founding_days: 30, founding_badge_enabled: true, founding_foodie_open: false, founding_foodie_limit: 500, launch_first_n: 50,
  launch_daily_target_research: 10, launch_daily_target_contacts: 10, launch_daily_target_demos: 3, launch_daily_target_claims: 2, launch_daily_target_trials: 1,
  sla_claim_review_hours: 48, sla_support_first_response_hours: 24, sla_order_issue_hours: 2, sla_data_report_hours: 72, data_stale_days: 180,
  partner_no_login_days: 14, partner_zero_activity_days: 30, nps_enabled: false, nps_min_actions: 3, nps_interval_days: 90, ambassador_program_enabled: false,
  experiments_max_running: 2, cac_min_conversions: 5, crm_lost_retention_days: 730, launch_forecast: null,
};

const PLAN_SEED: [PlanItem['horizon'], PlanItem['bucket'], string, string][] = [
  ['30d', 'week1', 'Beta privata aperta (inviti)', 'beta_invite_only attivo, 5–10 ristoranti e 50–100 utenti invitati.'],
  ['30d', 'week1', 'QA dei dati: coordinate, orari, telefoni', 'Launch Control → Qualità dati: azzerare coordinate mancanti e duplicati nei comuni prioritari.'],
  ['30d', 'week1', 'Sincronizzare i lead CRM dai ristoranti', 'Launch Control → CRM → "Crea lead dai ristoranti".'],
  ['30d', 'week1', 'Primi 5 Partner Fondatori', 'Dalla lista First 50: contatto, demo, rivendicazione, attivazione Partner Fondatore.'],
  ['30d', 'week1', 'Bug fixing dalla beta', 'Rivedere feedback e incidenti ogni giorno (Operations → Oggi).'],
  ['30d', 'week2', 'Outreach First 50 (10 contatti/giorno)', 'Script telefono/WhatsApp/email del Sales Playbook; registrare ogni contatto nel CRM.'],
  ['30d', 'week2', 'Distribuzione QR Kit ai partner', 'Table card A6 e counter card A5 stampate e consegnate; segnare nel kit di lancio.'],
  ['30d', 'week2', 'Contenuti organici (calendario social)', 'Generare il calendario 30 giorni (bozze) e approvare i primi post con dati reali.'],
  ['30d', 'week2', 'Prima offerta per ogni partner', 'Il ristoratore sceglie le condizioni; AsiaFood non inventa offerte.'],
  ['30d', 'week3', 'Lancio consumer: landing /taranto', 'Link della landing con UTM su social, QR e partner locali.'],
  ['30d', 'week3', 'Campagna referral "Invita un amico"', 'Verificare regole AsiaPoints e messaggi prima di promuoverla.'],
  ['30d', 'week3', 'Partnership locali (hotel, B&B, università)', 'CRM → Partner; QR "Dove mangiare sushi a Taranto?" tracciati per partner.'],
  ['30d', 'week3', 'Beta locale (pubblico limitato)', 'Passare la fase a local_beta quando i blocker critici sono chiusi.'],
  ['30d', 'week4', 'Conversione trial → abbonamento', 'Daily: piani in scadenza; follow-up con i dati ROI del partner (senza promettere risultati).'],
  ['30d', 'week4', 'Analisi retention (coorti)', 'Weekly → Coorti: ritorno in settimana 2, attivazione ristoranti.'],
  ['30d', 'week4', 'Preparazione espansione', 'Expansion signals: raccogliere dati, nessuna decisione senza numeri.'],
  ['90d', 'month1', 'Validazione Taranto', 'Prime connessioni reali (North Star), feedback, primi paganti.'],
  ['90d', 'month2', 'Saturazione provincia di Taranto', 'Copertura comuni prioritari ≥ target, qualità dati, SEO locale pronta.'],
  ['90d', 'month3', 'Preparazione secondo mercato', 'Scelta della seconda area basata sui segnali di espansione e sui costi di acquisizione reali.'],
];

const SOCIAL_SEED: [string, string, string, string][] = [
  ['instagram', 'launch', 'Annuncio: AsiaFood arriva a Taranto', 'Finalmente tutta la cucina asiatica di Taranto in un’unica app. Scopri, confronta, prenota. Link in bio.'],
  ['tiktok', 'map', 'Tour della mappa', 'Dove si mangia sushi a Taranto? Ti mostriamo la mappa di AsiaFood in 20 secondi. [inserire solo locali presenti]'],
  ['facebook', 'local', 'Taranto e provincia: i comuni coperti', 'Da Taranto a Martina Franca, da Massafra a Manduria: [N] locali asiatici già su AsiaFood. [aggiornare N dai dati]'],
  ['instagram', 'quiz', 'Sushi quiz: nigiri o uramaki?', 'Quiz del giorno: qual è la differenza tra nigiri e uramaki? Rispondi nei commenti!'],
  ['instagram', 'restaurant_spotlight', 'Scopri [Ristorante] (solo partner che ha dato il consenso)', 'Oggi vi portiamo da [Ristorante]. [descrizione approvata dal locale]. Se sponsorizzato: aggiungere #adv.'],
  ['tiktok', 'where_would_you_eat', 'Dove mangeresti stasera?', 'AYCE, poke o ramen? Dove mangeresti stasera a Taranto? Vota!'],
  ['instagram', 'ayce', 'Guida all’All You Can Eat', 'Come funziona l’All You Can Eat? Prezzi pranzo/cena sono sulle schede dei locali su AsiaFood. [solo dati reali]'],
  ['facebook', 'new_partners', 'Benvenuti ai primi Partner Fondatori', 'Diamo il benvenuto ai primi ristoranti Partner Fondatori di AsiaFood Taranto. [solo aderenti reali, con consenso]'],
  ['instagram', 'offers', 'Le offerte della settimana', 'Le offerte attive questa settimana su AsiaFood. Condizioni decise da ogni ristorante. [solo offerte attive]'],
  ['tiktok', 'behind_scenes', 'Dietro le quinte', 'Come verifichiamo le schede dei ristoranti: fonti, telefonate, foto. Nessuna recensione inventata.'],
  ['instagram', 'dish_of_day', 'Piatto del giorno: ramen', 'Il ramen: brodo, noodles, topping. Dove trovarlo a Taranto? Cerca "ramen" su AsiaFood.'],
  ['instagram', 'ugc', 'Tagga @AsiaFood', 'Hai provato un ristorante asiatico? Taggaci! Ripubblichiamo solo con il tuo permesso.'],
  ['facebook', 'map', 'Vicino a te', 'Attiva la posizione e trova i locali asiatici più vicini. La posizione non viene salvata.'],
  ['instagram', 'quiz', 'Quiz: cos’è il gyoza?', 'Ravioli giapponesi alla piastra: sai come si chiamano? Rispondi!'],
  ['tiktok', 'restaurant_spotlight', 'Ristorante della settimana', 'Ristorante della settimana: [Ristorante]. [contenuto approvato]. Se sponsorizzato: #adv obbligatorio.'],
  ['instagram', 'local', 'Sushi a Massafra, Martina Franca, Grottaglie', 'Non solo Taranto: i locali di sushi in provincia su AsiaFood. [solo comuni con locali]'],
  ['instagram', 'tips', 'Come prenotare in 3 tap', 'Prenota un tavolo in 3 tap dai locali che accettano prenotazioni su AsiaFood.'],
  ['facebook', 'offers', 'Coupon: come funzionano', 'Salva un coupon e mostralo in cassa. Le condizioni sono sempre indicate sul coupon.'],
  ['instagram', 'where_would_you_eat', 'Pranzo veloce: poke o bao?', 'Pausa pranzo a Taranto: poke o bao? Scegli e trova il locale su AsiaFood.'],
  ['tiktok', 'behind_scenes', 'Come nasce AsiaFood', 'Perché una piattaforma solo per la cucina asiatica? Ve lo raccontiamo.'],
  ['instagram', 'giveaway', 'Giveaway (SOLO dopo verifica legale)', 'BOZZA — non pubblicare senza checklist di conformità (regolamento, ministero se necessario, privacy).'],
  ['instagram', 'new_partners', 'Nuovi locali verificati', 'Nuovi locali verificati questa settimana su AsiaFood. [solo dati reali]'],
  ['facebook', 'tips', 'Invita un amico', 'Invita un amico su AsiaFood e ricevete AsiaPoints secondo il regolamento del programma.'],
  ['instagram', 'dish_of_day', 'Piatto del giorno: dim sum', 'Dim sum: piccoli bocconi al vapore. Dove trovarli? Cerca su AsiaFood.'],
  ['tiktok', 'map', 'Sfida: 3 locali in 3 comuni', 'Tre comuni, tre locali asiatici: la mappa di AsiaFood. [solo locali presenti]'],
  ['instagram', 'quiz', 'Quiz: wasabi vero o no?', 'Sapevi che il wasabi servito spesso è rafano colorato? Vero o falso?'],
  ['instagram', 'restaurant_spotlight', 'Scopri [Ristorante]', 'Scopri [Ristorante] su AsiaFood: menu, orari, prenotazione. Se sponsorizzato: #adv.'],
  ['facebook', 'local', 'Grazie Taranto', 'Grazie ai primi utenti e ristoranti di Taranto! [solo numeri reali]'],
  ['instagram', 'offers', 'Offerte del weekend', 'Le offerte del weekend dai locali su AsiaFood. [solo offerte attive]'],
  ['tiktok', 'tips', 'Aggiungi AsiaFood alla schermata Home', 'Aggiungi AsiaFood alla schermata Home in 2 passaggi: si apre come un’app.'],
];

export function launchDefaults(): LaunchState {
  const mid = uuid();
  const today = romeDay();
  const plus = (d: number) => romeDay(new Date(Date.now() + d * DAY));
  const goal = (k: GoalMetric, t: number): Goal => ({ id: uuid(), metric_key: k, target_value: t, period_start: today, period_end: plus(90), actual_value: null, status: 'not_started', refreshed_at: null });
  return {
    markets: [{ id: mid, slug: 'taranto', name: 'Taranto e provincia', province_code: 'TA', status: 'private_beta', launched_at: null }],
    leads: [], activities: [], tasks: [], founding: [], codes: [], visits: [], user_acquisition: [], content: [], ambassadors: [], feedback: [],
    incidents: [], costs: [], experiments: [], launch_progress: {}, qr_scans: [], audit: [], founding_foodies: {},
    goals: [goal('restaurants_listed', 100), goal('restaurants_claimed', 30), goal('restaurants_partner', 20), goal('restaurants_paying', 10),
      goal('users_registered', 1000), goal('users_active_30d', 500)],
    plan: PLAN_SEED.map(([horizon, bucket, title, description], i) => ({ id: uuid(), horizon, bucket, title, description, status: 'todo', owner_id: null, due_date: null, sort: i })),
  };
}

/** Completezza della scheda (specchio di public.restaurant_completion). Condivisa con la demo Growth (Fase 13). */
export function restaurantCompletion(dbv: R, r: R) {
  const db = () => dbv;
  const menu = db().menus.some((m: R) => m.restaurant_id === r.id && m.is_active) || db().menu_items.some((i: R) => i.restaurant_id === r.id);
  const hours = db().restaurant_hours.some((h: R) => h.restaurant_id === r.id);
  const cats = db().restaurant_categories.some((c: R) => c.restaurant_id === r.id);
  const imgs = db().restaurant_images.some((i: R) => i.restaurant_id === r.id);
  const resv = (db().reservation_settings ?? []).some((s: R) => s.restaurant_id === r.id && s.reservation_enabled);
  const known = r.is_verified || ['verified', 'claimed'].includes(r.data_status) || r.has_delivery || r.has_takeaway || r.has_reservation;
  const parts: [boolean, number, string][] = [
    [!!r.name?.trim(), 5, 'name'], [!!r.address?.trim(), 8, 'address'], [r.latitude != null && r.longitude != null, 10, 'coordinates'],
    [!!(r.phone ?? r.whatsapp), 8, 'phone'], [hours, 10, 'hours'], [cats, 8, 'categories'], [!!r.logo_url, 5, 'logo'], [!!r.cover_url || imgs, 8, 'cover'],
    [menu, 10, 'menu'], [!!(r.instagram ?? r.facebook ?? r.tiktok ?? r.website), 6, 'social'], [(r.services ?? []).length > 0, 5, 'services'],
    [r.price_range != null || r.average_price != null, 6, 'prices'],
    [!r.is_all_you_can_eat || (r.ayce_lunch_price ?? r.ayce_dinner_price ?? r.ayce_weekend_price) != null, 4, 'ayce'], [!!known, 3, 'delivery'],
    [(r.has_reservation && (!!r.reservation_url || resv)) || resv || (!!known && !r.has_reservation), 4, 'reservations'],
  ];
  return { score: parts.reduce((s, [ok, w]) => s + (ok ? w : 0), 0), missing: parts.filter(([ok]) => !ok).map(([, , k]) => k), has_menu: menu, has_hours: hours };
}

export function createLaunchDemo(a: LaunchAccess): LaunchApi {
  const db = () => a.db;
  const st = (): LaunchState => (db().launch ??= launchDefaults());
  const setting = <T>(k: string): T => (k in (db().settings ?? {}) ? db().settings[k] : LAUNCH_SETTING_DEFAULTS[k]) as T;
  const num = (k: string) => Number(setting<number>(k));
  const admin = () => {
    if (!a.isAdmin()) throw deny();
  };
  const market = (slug = 'taranto') => {
    const m = st().markets.find((x) => x.slug === slug);
    if (!m) throw fail('Mercato non trovato');
    return m;
  };
  const province = (code: string) => db().provinces.find((p: R) => p.code === code);
  const cityOf = (id: string) => db().cities.find((c: R) => c.id === id);
  const inMarket = (r: R, m = market()) => {
    const prov = province(m.province_code);
    const pid = r.province_id ?? cityOf(r.city_id)?.province_id;
    return prov && pid === prov.id && (!r.is_demo || a.demoVisible());
  };
  const marketRests = (m = market()) => db().restaurants.filter((r: R) => inMarket(r, m));
  const isPublicR = (r: R) => r.is_active && (!r.is_demo || a.demoVisible());
  const subs = (): R[] => db().subscriptions ?? [];
  const grants = (s: R) => (s.source !== 'stripe'
    ? ['active', 'trialing'].includes(s.status) && !s.revoked_at && (!s.expires_at || ts(s.expires_at) > Date.now())
    : ['active', 'trialing', 'past_due'].includes(s.status));
  const paying = (rid: string) => subs().some((s) => s.restaurant_id === rid && s.source === 'stripe' && s.paid_started_at && ['active', 'past_due'].includes(s.status));
  const hasPlan = (rid: string) => subs().some((s) => s.restaurant_id === rid && s.plan_code !== 'free' && grants(s));
  const founding = (rid: string) => st().founding.some((f) => f.restaurant_id === rid && f.status !== 'revoked');
  const events = (): R[] => db().analytics ?? [];
  const audit = (action: string, id: string, details: R = {}) => st().audit.push({ action, entity_id: id, details, created_at: now() });
  const profileName = (id: string | null) => {
    const p = db().profiles.find((x: R) => x.id === id);
    return p ? (p.display_name ?? p.full_name ?? p.email ?? null) : null;
  };

  const completion = (r: R) => restaurantCompletion(db(), r);

  function rows(m = market()): LaunchRestaurantRow[] {
    const list = marketRests(m);
    const stale = num('data_stale_days');
    const base = list.map((r: R) => ({ r, c: cityOf(r.city_id), comp: completion(r), n: norm(r.name ?? ''), p: digits(r.phone) }));
    return base.map(({ r, c, comp, n, p }: R) => {
      const prio = PRIORITY_CITIES.indexOf(c?.slug ?? '') + 1 || null;
      const views = events().filter((e) => e.restaurant_id === r.id && e.event_type === 'restaurant_view' && ts(e.created_at) > ago(30)).length;
      const multi = base.some((o: R) => o.r.id !== r.id && o.n === n && n.length > 3);
      const dup = base.some((o: R) => o.r.id !== r.id && ((o.n === n && o.r.city_id === r.city_id && n.length > 2) || (p && o.p === p)));
      const far = r.latitude != null && c?.latitude != null && distKm(r.latitude, r.longitude, c.latitude, c.longitude) > 25;
      const closed = !!(r.is_permanently_closed || r.is_temporarily_closed);
      const score = (r.is_all_you_can_eat ? 20 : 0) + (r.has_delivery || r.has_takeaway ? 10 : 0) + (comp.has_menu ? 10 : 0)
        + ((r.instagram ?? r.facebook ?? r.tiktok) ? 10 : 0) + (multi ? 15 : 0)
        + (prio === 1 ? 15 : prio && prio <= 4 ? 10 : prio && prio <= 10 ? 5 : 0) + (r.has_reservation ? 5 : 0) + Math.floor(comp.score / 10) + Math.min(10, Math.floor(views / 20));
      const sug: Segment = score >= 50 ? 'A' : score >= 30 ? 'B' : 'C';
      const lead = st().leads.find((l) => l.restaurant_id === r.id);
      const claimed = !!r.owner_id;
      return {
        id: r.id, name: r.name, slug: r.slug, city_id: r.city_id, city_name: c?.name ?? '', city_slug: c?.slug ?? '', city_priority: prio, is_demo: !!r.is_demo,
        is_active: !!r.is_active, closed, claimed, verified: !!r.is_verified || r.data_status === 'verified', partner: claimed && (founding(r.id) || hasPlan(r.id)),
        paying: paying(r.id), founding: founding(r.id), plan: r.subscription_plan ?? 'free', completion: comp.score, missing: comp.missing, has_menu: comp.has_menu,
        no_coords: r.latitude == null, no_hours: !comp.has_hours, no_phone: !(r.phone ?? r.whatsapp),
        stale: (!r.last_verified_at || ts(r.last_verified_at) < ago(stale)) && !r.owner_id, duplicate: dup, position_far: far,
        claimable: !r.owner_id && !closed && !!(r.phone ?? r.whatsapp ?? r.email ?? r.instagram ?? r.website), is_ayce: !!r.is_all_you_can_eat,
        has_delivery: !!(r.has_delivery || r.has_takeaway), priority_score: score, segment_suggested: sug, segment: lead?.segment_override ?? sug,
        lead_id: lead?.id ?? null, lead_status: lead?.status ?? null, assigned_to: lead?.assigned_to ?? null, next_action: lead?.next_action ?? null,
        next_action_at: lead?.next_action_at ?? null, last_contact_at: lead?.last_contact_at ?? null, potential_plan: lead?.potential_plan ?? null,
        contact_allowed: lead?.contact_allowed ?? true, phone: r.phone ?? null, whatsapp: r.whatsapp ?? null, email: r.email ?? null,
        instagram: r.instagram ?? null, website: r.website ?? null, last_verified_at: r.last_verified_at ?? null, views_30d: views,
      };
    });
  }

  function metric(key: GoalMetric | 'gmv' | 'visits' | 'coupon_redeemed', from: number, to: number, m = market()): number {
    const ids = new Set(marketRests(m).map((r: R) => r.id));
    const inR = (x: R) => ids.has(x.restaurant_id);
    const between = (s: string | null | undefined) => ts(s) >= from && ts(s) < to;
    const rs = marketRests(m);
    switch (key) {
      case 'restaurants_listed': return rs.filter((r: R) => r.is_active && !r.is_permanently_closed).length;
      case 'restaurants_verified': return rs.filter((r: R) => r.is_active && (r.is_verified || r.data_status === 'verified')).length;
      case 'restaurants_claimed': return rs.filter((r: R) => r.owner_id).length;
      case 'restaurants_partner': return rs.filter((r: R) => r.owner_id && (founding(r.id) || hasPlan(r.id))).length;
      case 'restaurants_paying': return rs.filter((r: R) => paying(r.id)).length;
      case 'mrr_cents': return Math.round(subs().filter((s) => ids.has(s.restaurant_id) && s.source === 'stripe' && ['active', 'past_due'].includes(s.status))
        .reduce((t, s) => t + (s.billing_interval === 'year' ? (s.unit_amount_cents ?? 0) / 12 : (s.unit_amount_cents ?? 0)), 0));
      case 'users_registered': return db().profiles.filter((p: R) => p.role === 'customer' && ts(p.created_at ?? now()) < to).length;
      case 'users_active_30d': return new Set(a.activityDays().filter((d) => Date.parse(d.day) > to - 30 * DAY).map((d) => d.user_id)).size;
      case 'reservations': return (db().reservations ?? []).filter((x: R) => inR(x) && between(x.created_at) && !['rejected', 'cancelled'].includes(x.status)).length;
      case 'orders_completed': return a.orders().filter((o) => inR(o) && o.status === 'completed' && between(o.completed_at)).length;
      case 'gmv': return a.orders().filter((o) => inR(o) && ['paid', 'partially_refunded'].includes(o.payment_status) && !['rejected', 'cancelled', 'refunded'].includes(o.status) && between(o.paid_at))
        .reduce((t, o) => t + Number(o.total ?? 0), 0);
      case 'coupon_claims': return (db().coupon_claims ?? []).filter((x: R) => inR(x) && between(x.claimed_at)).length;
      case 'coupon_redeemed': return (db().coupon_claims ?? []).filter((x: R) => inR(x) && x.status === 'redeemed' && between(x.redeemed_at)).length;
      case 'reviews_published': return a.reviews().filter((x) => inR(x) && x.status === 'published' && between(x.published_at ?? x.created_at)).length;
      case 'referrals_qualified': return a.referrals().filter((x) => between(x.qualified_at)).length;
      case 'sponsored_campaigns': return (db().sponsored_campaigns ?? []).filter((x: R) => inR(x) && x.status === 'active').length;
      case 'qr_scans': return st().qr_scans.filter((x) => ids.has(x.restaurant_id) && between(x.created_at)).length;
      case 'visits': return st().visits.filter((v) => between(v.created_at)).length;
      case 'food_connections': {
        const res = (db().reservations ?? []).filter((x: R) => inR(x) && x.status === 'completed' && Date.parse(x.reservation_date) >= from && Date.parse(x.reservation_date) < to).length;
        const ord = a.orders().filter((o) => inR(o) && o.status === 'completed' && between(o.completed_at)).length;
        const cou = (db().coupon_claims ?? []).filter((x: R) => inR(x) && x.status === 'redeemed' && between(x.redeemed_at)).length;
        const dir = new Set(events().filter((e) => ids.has(e.restaurant_id) && e.event_type === 'directions_click' && between(e.created_at))
          .map((e, i) => `${e.restaurant_id}|${String(e.created_at).slice(0, 10)}|${e.session_id ?? i}`)).size;
        return res + ord + cou + dir;
      }
      default: return 0;
    }
  }

  const STATE_METRICS = ['restaurants_listed', 'restaurants_verified', 'restaurants_claimed', 'restaurants_partner', 'restaurants_paying', 'users_registered', 'users_active_30d', 'sponsored_campaigns', 'mrr_cents'];
  function refreshGoals() {
    for (const g of st().goals) {
      const from = Date.parse(`${g.period_start}T00:00:00`);
      const to = Math.min(Date.now(), Date.parse(`${g.period_end}T00:00:00`) + DAY);
      const v = STATE_METRICS.includes(g.metric_key) ? metric(g.metric_key, from, Date.now()) : metric(g.metric_key, from, to);
      const elapsed = Math.max(0, Math.min(1, (Date.now() - from) / (Date.parse(`${g.period_end}T00:00:00`) + DAY - from)));
      const ratio = v / g.target_value;
      g.actual_value = v;
      g.refreshed_at = now();
      g.status = ratio >= 1 ? 'achieved' : Date.now() < from || elapsed < 0.1 ? 'not_started' : ratio >= elapsed * 0.9 ? 'on_track' : ratio >= elapsed * 0.6 ? 'at_risk' : 'behind';
    }
  }
  const target = (k: GoalMetric, fb: number) => st().goals.filter((g) => g.metric_key === k).sort((x, y) => y.period_start.localeCompare(x.period_start))[0]?.target_value ?? fb;
  const prog = (key: string, label: string, value: number, t: number): ProgressItem => ({ key, label, value, target: t, pct: t > 0 ? Math.min(100, Math.round((value * 100) / t)) : 0 });

  function localQueries(m = market()) {
    const min = num('seo_min_restaurants_category_city') || 2;
    const rs = marketRests(m).filter((r: R) => isPublicR(r) && !r.is_permanently_closed);
    return LOCAL_QUERIES.map(([query, cat, city]) => {
      const c = db().categories.find((x: R) => x.slug === cat);
      const count = rs.filter((r: R) => cityOf(r.city_id)?.slug === city && db().restaurant_categories.some((rc: R) => rc.restaurant_id === r.id && rc.category_id === c?.id)).length;
      return { query, path: `/${cat}/${city}`, count, ready: count >= min };
    });
  }

  function partnerRows(m = market()): PartnerRow[] {
    const nologin = num('partner_no_login_days');
    const zero = num('partner_zero_activity_days');
    const days = a.activityDays();
    return rows(m).filter((x) => x.claimed).map((x) => {
      const members = db().restaurant_members.filter((rm: R) => rm.restaurant_id === x.id && rm.status === 'active').map((rm: R) => rm.user_id);
      const last = days.filter((d) => members.includes(d.user_id)).map((d) => d.day).sort().reverse()[0] ?? null;
      const offers = db().offers.filter((o: R) => o.restaurant_id === x.id && o.is_active && (!o.ends_at || ts(o.ends_at) > Date.now())).length;
      const pend = (db().reservations ?? []).filter((r: R) => r.restaurant_id === x.id && r.status === 'pending' && ts(r.created_at) < ago(1)).length;
      const ev = events().filter((e) => e.restaurant_id === x.id && ts(e.created_at) > ago(zero));
      const acts = ev.filter((e) => ['phone_click', 'whatsapp_click', 'directions_click', 'reservation_start', 'website_click', 'coupon_claim'].includes(e.event_type)).length
        + (db().reservations ?? []).filter((r: R) => r.restaurant_id === x.id && ts(r.created_at) > ago(zero)).length;
      const tends = subs().filter((s) => s.restaurant_id === x.id && grants(s) && ((s.source !== 'stripe' && s.expires_at) || (s.source === 'stripe' && s.status === 'trialing')))
        .map((s) => s.expires_at ?? s.trial_end).sort()[0] ?? null;
      const lastOk = (d: number) => !!last && Date.parse(last) >= ago(d);
      const e30 = events().filter((e) => e.restaurant_id === x.id && ts(e.created_at) > ago(30));
      const health = Math.round(x.completion * 0.3) + (x.has_menu ? 15 : 0) + (lastOk(7) ? 20 : lastOk(nologin) ? 10 : 0) + (offers > 0 ? 15 : 0) + (pend === 0 ? 10 : 0) + (acts > 0 ? 10 : 0);
      const flags = [
        tends && ts(tends) < Date.now() + 7 * DAY ? 'trial_ending' : null, !lastOk(nologin) ? 'no_login' : null, x.completion < 60 ? 'profile_incomplete' : null,
        acts === 0 ? 'zero_activity' : null, pend > 0 ? 'reservations_waiting' : null,
      ].filter(Boolean) as PartnerRow['flags'];
      return {
        restaurant_id: x.id, name: x.name, slug: x.slug, city_name: x.city_name, plan: x.plan, founding: x.founding, paying: x.paying, completion: x.completion,
        has_menu: x.has_menu, active_offers: offers, last_owner_activity: last, pending_reservations_24h: pend, customer_actions_30d: acts, health, trial_ends_at: tends, flags,
        roi: {
          views: e30.filter((e) => e.event_type === 'restaurant_view').length, calls: e30.filter((e) => ['phone_click', 'whatsapp_click'].includes(e.event_type)).length,
          directions: e30.filter((e) => e.event_type === 'directions_click').length,
          bookings: (db().reservations ?? []).filter((r: R) => r.restaurant_id === x.id && !['rejected', 'cancelled'].includes(r.status) && ts(r.created_at) > ago(30)).length,
          orders: a.orders().filter((o) => o.restaurant_id === x.id && o.status === 'completed' && ts(o.completed_at) > ago(30)).length,
          coupon_uses: (db().coupon_claims ?? []).filter((c: R) => c.restaurant_id === x.id && c.status === 'redeemed' && ts(c.redeemed_at) > ago(30)).length,
          qr_scans: st().qr_scans.filter((q) => q.restaurant_id === x.id && ts(q.created_at) > ago(30)).length,
        },
      };
    });
  }

  function foundingProgram(m = market()): FoundingProgram {
    return {
      enabled: !!setting('founding_program_enabled'), name: String(setting('founding_program_name')), limit: num('founding_limit'), plan: String(setting('founding_plan')),
      days: num('founding_days'), badge_enabled: !!setting('founding_badge_enabled'),
      used: st().founding.filter((f) => f.market_id === m.id && f.status !== 'revoked').length,
      rows: st().founding.filter((f) => f.market_id === m.id).sort((x, y) => x.number - y.number).map((f) => {
        const r = db().restaurants.find((x: R) => x.id === f.restaurant_id);
        return { ...f, restaurant_name: r?.name, restaurant_slug: r?.slug, days_left: f.benefit_ends_at ? Math.max(0, Math.ceil((ts(f.benefit_ends_at) - Date.now()) / DAY)) : null, paying: paying(f.restaurant_id) };
      }),
    };
  }

  function timeToValue(m = market()): TimeToValue {
    const med = (xs: number[]) => {
      if (!xs.length) return null;
      const s = [...xs].sort((p, q) => p - q);
      const mid = Math.floor(s.length / 2);
      return Math.round((s.length % 2 ? s[mid]! : (s[mid - 1]! + s[mid]!) / 2) * 10) / 10;
    };
    const cl = marketRests(m).filter((r: R) => r.owner_id && r.claimed_at);
    const step = (pick: (r: R) => string | null | undefined) => {
      const hrs = cl.map((r: R) => { const t = ts(pick(r)); return t >= ts(r.claimed_at) ? (t - ts(r.claimed_at)) / 3600e3 : NaN; }).filter((h: number) => !Number.isNaN(h));
      return { n: hrs.length, median_hours: med(hrs) };
    };
    const minOf = (list: R[], rid: string, f = 'created_at') => list.filter((x) => x.restaurant_id === rid).map((x) => x[f]).filter(Boolean).sort()[0] ?? null;
    return {
      claimed: cl.length, profile: step((r) => r.onboarding_completed_at), menu: step((r) => minOf(db().menus, r.id)), offer: step((r) => minOf(db().offers, r.id)),
      reservation: step((r) => minOf((db().reservations ?? []).filter((x: R) => !['rejected', 'cancelled'].includes(x.status)), r.id)),
      paid: step((r) => minOf(subs().filter((s) => s.source === 'stripe'), r.id, 'paid_started_at')),
    };
  }

  const activated = (rid: string) => {
    const r = db().restaurants.find((x: R) => x.id === rid);
    if (!r) return false;
    const c = completion(r);
    return c.score >= 70 && (c.has_menu || db().offers.some((o: R) => o.restaurant_id === rid))
      && ((db().reservations ?? []).some((x: R) => x.restaurant_id === rid && !['rejected', 'cancelled'].includes(x.status))
        || a.orders().some((o) => o.restaurant_id === rid && o.status === 'completed') || (db().coupon_claims ?? []).some((x: R) => x.restaurant_id === rid)
        || events().some((e) => e.restaurant_id === rid && ['phone_click', 'whatsapp_click', 'directions_click', 'reservation_start', 'website_click'].includes(e.event_type)));
  };

  function advanceLead(rid: string, status: string) {
    const l = st().leads.find((x) => x.restaurant_id === rid);
    if (!l || CLOSED.includes(l.status) || rank(l.status) >= rank(status)) return;
    l.status = status as CrmLead['status'];
    l.updated_at = now();
    st().activities.push({ id: uuid(), lead_id: l.id, type: 'status_change', outcome: null, notes: `→ ${status}`, disclosure_required: null, created_by: null, created_at: now() });
  }

  function generateFollowups(m = market()) {
    let n = 0;
    for (const p of partnerRows(m)) {
      for (const f of p.flags) {
        if (f === 'reservations_waiting') continue;
        if (st().tasks.some((t) => t.restaurant_id === p.restaurant_id && t.reason === f && t.status === 'open' && t.source !== 'manual')) continue;
        const title = f === 'trial_ending' ? `Il piano gratuito di ${p.name} sta per terminare: proporre la continuazione`
          : f === 'no_login' ? `Nessun accesso recente di ${p.name}: chiamare e offrire aiuto`
            : f === 'profile_incomplete' ? `Aiutare ${p.name} a completare il profilo` : `Nessuna azione dei clienti per ${p.name}: verificare visibilità, QR e prima offerta`;
        st().tasks.push({ id: uuid(), market_id: m.id, lead_id: st().leads.find((l) => l.restaurant_id === p.restaurant_id)?.id ?? null, restaurant_id: p.restaurant_id, title, reason: f,
          due_at: new Date(Date.now() + DAY).toISOString(), assigned_to: null, status: 'open', source: f === 'trial_ending' ? 'trial_ending' : 'at_risk', created_at: now() });
        n++;
      }
    }
    return n;
  }

  /** Lazy maintenance (nel browser non girano cron): fine beneficio Fondatori. */
  function maintain() {
    for (const f of st().founding) if (f.status === 'active' && f.benefit_ends_at && ts(f.benefit_ends_at) < Date.now()) f.status = 'completed';
  }

  const weekStarts = (n: number) => {
    const d = new Date();
    const dow = (d.getDay() + 6) % 7;
    const monday = new Date(d.getFullYear(), d.getMonth(), d.getDate() - dow);
    return Array.from({ length: n }, (_, i) => new Date(monday.getTime() - (n - 1 - i) * 7 * DAY));
  };

  const api: LaunchApi = {
    // ─── Pubblico ───
    async marketLanding(slug = 'taranto') {
      const m = st().markets.find((x) => x.slug === slug);
      if (!m) return null;
      const min = num('seo_min_restaurants_category_city') || 2;
      const pub = marketRests(m).filter((r: R) => isPublicR(r) && !r.is_permanently_closed);
      const catCount = new Map<string, number>();
      const cityCount = new Map<string, number>();
      const pair = new Map<string, number>();
      for (const r of pub) {
        const c = cityOf(r.city_id);
        cityCount.set(c.slug, (cityCount.get(c.slug) ?? 0) + 1);
        for (const rc of db().restaurant_categories.filter((x: R) => x.restaurant_id === r.id)) {
          const k = db().categories.find((x: R) => x.id === rc.category_id);
          if (!k) continue;
          catCount.set(k.slug, (catCount.get(k.slug) ?? 0) + 1);
          pair.set(`${k.slug}|${c.slug}`, (pair.get(`${k.slug}|${c.slug}`) ?? 0) + 1);
        }
      }
      const cat = (s: string) => db().categories.find((x: R) => x.slug === s);
      const city = (s: string) => db().cities.find((x: R) => x.slug === s);
      return {
        market: { slug: m.slug, name: m.name, status: m.status }, min_per_page: min, total: pub.length, ayce: pub.filter((r: R) => r.is_all_you_can_eat).length,
        delivery: pub.filter((r: R) => r.has_delivery).length,
        with_offers: new Set(db().offers.filter((o: R) => o.is_active && ts(o.starts_at) <= Date.now() && (!o.ends_at || ts(o.ends_at) > Date.now()) && pub.some((r: R) => r.id === o.restaurant_id)).map((o: R) => o.restaurant_id)).size,
        categories: [...catCount].map(([s, count]) => ({ slug: s, name: cat(s)?.name, emoji: cat(s)?.emoji ?? null, count })).sort((x, y) => y.count - x.count || x.name.localeCompare(y.name)),
        cities: [...cityCount].map(([s, count]) => ({ slug: s, name: city(s)?.name, count })).sort((x, y) => y.count - x.count || x.name.localeCompare(y.name)),
        category_city: [...pair].filter(([, c]) => c >= min).map(([k, count]) => { const [c1, c2] = k.split('|') as [string, string]; return { category: c1, city: c2, city_name: city(c2)?.name, count }; }),
      };
    },
    async foundingBadge(rid) {
      maintain();
      const r = db().restaurants.find((x: R) => x.id === rid);
      if (!r || !isPublicR(r) || !setting('founding_badge_enabled')) return null;
      const f = st().founding.find((x) => x.restaurant_id === rid && x.status !== 'revoked' && x.badge_visible);
      return f ? { number: f.number, label: String(setting('founding_program_name')), since: f.activated_at } : null;
    },
    async trackQrScan(slug, kind) {
      if (!['profile', 'menu', 'review', 'booking', 'offer'].includes(kind)) return;
      const r = db().restaurants.find((x: R) => x.slug === slug && isPublicR(x));
      if (!r) return;
      st().qr_scans.push({ restaurant_id: r.id, kind, created_at: now() });
      events().push({ restaurant_id: r.id, event_type: 'qr_scan', source: 'qr', created_at: now() });
      a.save();
    },
    async recordVisit(v) {
      const code = (v.promo_code ?? '').replace(/[^A-Za-z0-9]/g, '').toUpperCase() || null;
      const valid = code && st().codes.find((c) => c.code === code && c.is_active);
      if (valid) valid.uses++;
      st().visits.push({ channel: CHANNELS.includes(v.channel) ? v.channel : 'other', utm_source: cleanUtm(v.utm_source), utm_medium: cleanUtm(v.utm_medium),
        utm_campaign: cleanUtm(v.utm_campaign), utm_content: cleanUtm(v.utm_content), landing_path: (v.landing_path ?? '').replace(/[?#].*$/, '').slice(0, 200) || null,
        promo_code: valid ? code : null, created_at: now() });
      a.save();
    },
    async attributeSignup(v) {
      const uid = a.uid();
      if (!uid || st().user_acquisition.some((x) => x.user_id === uid)) return false;
      const p = db().profiles.find((x: R) => x.id === uid);
      if (!p || ts(p.created_at ?? now()) < ago(7)) return false;
      const ch = CHANNELS.includes(v.channel) ? v.channel : 'other';
      st().user_acquisition.push({ user_id: uid, channel: ch, utm_source: cleanUtm(v.utm_source), utm_campaign: cleanUtm(v.utm_campaign), created_at: now(),
        last_channel: v.last_channel && CHANNELS.includes(v.last_channel) ? v.last_channel : ch, last_utm_source: cleanUtm(v.last_utm_source) ?? cleanUtm(v.utm_source) } as never);
      a.save();
      return true;
    },
    async runningExperiments() {
      // Fase 13: pesi delle varianti (tabella experiment_variants della demo Growth) e metrica primaria
      const vars = ((db().growth?.variants ?? []) as { experiment_id: string; name: string; allocation: number }[]);
      return st().experiments.filter((e) => e.status === 'running').map((e) => ({ key: e.key, variants: e.variants, primary_metric: e.primary_metric,
        weights: e.variants.map((n) => vars.find((v) => v.experiment_id === e.id && v.name === n)?.allocation ?? Math.floor(100 / e.variants.length)) }));
    },
    async submitFeedback(input) {
      const uid = a.uid();
      if (!uid && input.type !== 'user_general') throw deny();
      if (input.restaurant_id && !a.canManage(input.restaurant_id)) throw deny();
      if (['restaurant_dashboard', 'cancellation'].includes(input.type) && !input.restaurant_id) throw fail('Seleziona il locale');
      if (input.type === 'nps' && input.rating == null) throw fail('Valutazione mancante');
      if (!['nps', 'cancellation'].includes(input.type) && (input.message ?? '').trim().length < 3) throw fail('Scrivi almeno qualche parola');
      st().feedback.push({ id: uuid(), user_id: uid, restaurant_id: input.restaurant_id ?? null, type: input.type, rating: input.rating ?? null, reason: input.reason ?? null,
        message: input.message?.trim() || null, page: input.page ?? null, status: 'new', created_at: now() });
      a.save();
    },
    async npsShouldAsk() {
      const uid = a.uid();
      if (!uid || !setting('nps_enabled')) return false;
      const p = db().profiles.find((x: R) => x.id === uid);
      if (!p || p.role !== 'customer' || ts(p.created_at ?? now()) > ago(7)) return false;
      if (st().feedback.some((f) => f.user_id === uid && f.type === 'nps' && ts(f.created_at) > ago(num('nps_interval_days')))) return false;
      const acts = (db().reservations ?? []).filter((r: R) => r.user_id === uid && r.status === 'completed').length
        + a.orders().filter((o) => o.user_id === uid && o.status === 'completed').length + (db().coupon_claims ?? []).filter((c: R) => c.user_id === uid && c.status === 'redeemed').length;
      return acts >= num('nps_min_actions');
    },
    async ambassadorApply(motivation) {
      const uid = a.uid();
      if (!uid) throw deny();
      if (!setting('ambassador_program_enabled')) throw fail('Il programma Ambassador non è ancora aperto');
      let x = st().ambassadors.find((y) => y.user_id === uid);
      if (!x) {
        x = { id: uuid(), user_id: uid, status: 'applied', referral_code: a.ensureReferralCode(uid), motivation: motivation.trim().slice(0, 1000) || null, joined_at: now(), approved_at: null, notes: null };
        st().ambassadors.push(x);
      } else if (motivation.trim()) x.motivation = motivation.trim().slice(0, 1000);
      a.save();
      return { status: x.status, referral_code: x.referral_code ?? '' };
    },
    async myAmbassador() {
      const uid = a.uid();
      const x = st().ambassadors.find((y) => y.user_id === uid);
      return { enabled: !!setting('ambassador_program_enabled'), status: x?.status ?? null, referral_code: x?.referral_code ?? null, joined_at: x?.joined_at ?? null,
        founding_foodie_at: uid ? st().founding_foodies[uid] ?? null : null };
    },
    async launchKit(rid) {
      if (!a.canManage(rid)) throw deny();
      maintain();
      const r = db().restaurants.find((x: R) => x.id === rid);
      const c = completion(r);
      const pr = st().launch_progress[rid] ?? null;
      const f = st().founding.find((x) => x.restaurant_id === rid && x.status !== 'revoked');
      const members = db().restaurant_members.filter((m: R) => m.restaurant_id === rid && m.status === 'active').map((m: R) => m.user_id);
      return {
        completion: c, progress: pr, slug: r.slug, name: r.name,
        founding: f ? { number: f.number, status: f.status, plan: f.benefit_plan, benefit_ends_at: f.benefit_ends_at, label: String(setting('founding_program_name')) } : null,
        steps: [
          { key: 'profile', done: c.score >= 80 }, { key: 'menu', done: c.has_menu }, { key: 'hours', done: c.has_hours },
          { key: 'photos', done: !!(r.cover_url || r.logo_url || db().restaurant_images.some((i: R) => i.restaurant_id === rid)) },
          { key: 'qr', done: !!pr?.qr_kit_downloaded_at }, { key: 'first_offer', done: db().offers.some((o: R) => o.restaurant_id === rid) },
          { key: 'reservations', done: (db().reservation_settings ?? []).some((s: R) => s.restaurant_id === rid && s.reservation_enabled) || !!r.reservation_url },
          { key: 'notifications', done: members.some((u: string) => a.pushUsers().includes(u)) }, { key: 'social_launch', done: !!pr?.social_launch_at },
        ],
      };
    },
    async markLaunchKit(rid, step) {
      if (!a.canManage(rid)) throw deny();
      const p = (st().launch_progress[rid] ??= { starter_kit_viewed_at: null, qr_kit_downloaded_at: null, materials_printed_at: null, social_launch_at: null });
      if (step === 'starter_kit_viewed') p.starter_kit_viewed_at ??= now();
      if (step === 'qr_kit_downloaded') p.qr_kit_downloaded_at ??= now();
      if (step === 'materials_printed') p.materials_printed_at ??= now();
      if (step === 'social_launch') p.social_launch_at ??= now();
      if (step === 'social_launch_undo') p.social_launch_at = null;
      a.save();
    },

    // ─── Admin ───
    async overview(slug = 'taranto') {
      admin();
      maintain();
      const m = market(slug);
      refreshGoals();
      const rs = rows(m);
      const since = ago(30);
      const t = Date.now();
      const lq = localQueries(m);
      const ids = new Set(rs.map((r) => r.id));
      const kpis: LaunchOverview['kpis'] = {
        censused: rs.filter((x) => !x.closed || x.is_active).length, drafts: rs.filter((x) => !x.is_active).length, listed: rs.filter((x) => x.is_active && !x.closed).length,
        verified: rs.filter((x) => x.verified && x.is_active).length, claimed: rs.filter((x) => x.claimed).length, partner: rs.filter((x) => x.partner).length,
        paying: rs.filter((x) => x.paying).length, premium_top: rs.filter((x) => ['premium', 'top'].includes(x.plan)).length, founding: rs.filter((x) => x.founding).length,
        avg_completion: rs.length ? Math.round(rs.reduce((s, x) => s + x.completion, 0) / rs.length) : null, demo: rs.filter((x) => x.is_demo).length,
        users: metric('users_registered', since, t, m), users_active_30d: metric('users_active_30d', since, t, m), reservations_30d: metric('reservations', since, t, m),
        orders_30d: metric('orders_completed', since, t, m), gmv_30d: metric('gmv', since, t, m), orders_enabled: db().settings.orders_enabled !== false,
        coupon_claims_30d: metric('coupon_claims', since, t, m), coupon_redeemed_30d: metric('coupon_redeemed', since, t, m), reviews_30d: metric('reviews_published', since, t, m),
        mrr_cents: metric('mrr_cents', since, t, m), qr_scans_30d: metric('qr_scans', since, t, m), food_connections_30d: metric('food_connections', since, t, m),
        visits_30d: metric('visits', since, t, m),
        referrals: { invited: a.referrals().length, registered: a.referrals().filter((x) => x.registered_at).length, qualified: a.referrals().filter((x) => x.qualified_at).length, rewarded: a.referrals().filter((x) => x.rewarded_at).length },
        business_referrals: { invited: a.businessReferrals().length, qualified: a.businessReferrals().filter((x) => ['qualified', 'approved', 'rewarded'].includes(x.status)).length, rewarded: a.businessReferrals().filter((x) => x.status === 'rewarded').length },
        sponsored: { active: metric('sponsored_campaigns', since, t, m), impressions_30d: events().filter((e) => ids.has(e.restaurant_id) && e.event_type === 'sponsored_impression' && ts(e.created_at) > since).length,
          clicks_30d: events().filter((e) => ids.has(e.restaurant_id) && e.event_type === 'sponsored_click' && ts(e.created_at) > since).length },
        traffic_by_channel: st().visits.filter((v) => ts(v.created_at) > since).reduce<Record<string, number>>((o, v) => ((o[v.channel] = (o[v.channel] ?? 0) + 1), o), {}),
        seo: { restaurant_pages: rs.filter((x) => x.is_active && (!x.is_demo || a.demoVisible())).length, city_pages: new Set(rs.filter((x) => x.is_active).map((x) => x.city_id)).size,
          local_queries_ready: lq.filter((q) => q.ready).length, local_queries_total: lq.length },
      };
      const progress = [
        prog('database', 'Database locale', kpis.listed, target('restaurants_listed', 100)), prog('claims', 'Rivendicazioni', kpis.claimed, target('restaurants_claimed', 30)),
        prog('partners', 'Onboarding partner', kpis.partner, target('restaurants_partner', 20)), prog('paying', 'Ristoranti paganti', kpis.paying, target('restaurants_paying', 10)),
        prog('seo', 'SEO locale (query prioritarie pronte)', kpis.seo.local_queries_ready, kpis.seo.local_queries_total),
        prog('consumers', 'Acquisizione utenti', kpis.users, target('users_registered', 1000)),
      ];
      const alerts: LaunchAlert[] = [];
      const pending = db().restaurant_claims.filter((c: R) => ['pending', 'under_review', 'more_information_required'].includes(c.status));
      if (pending.length) {
        const overdue = pending.some((c: R) => ts(c.created_at) < Date.now() - num('sla_claim_review_hours') * 3600e3);
        alerts.push({ level: overdue ? 'high' : 'medium', key: 'claims_pending', link: '/admin/claims',
          text: `${pending.length} ${pending.length === 1 ? 'rivendicazione aspetta' : 'rivendicazioni aspettano'} revisione.` });
      }
      for (const p of partnerRows(m).filter((x) => x.trial_ends_at && ts(x.trial_ends_at) < Date.now() + 3 * DAY)) {
        const d = Math.max(0, Math.ceil((ts(p.trial_ends_at) - Date.now()) / DAY));
        alerts.push({ level: 'medium', key: 'trial_ending', link: '/admin/launch/taranto/partners', text: `Il piano ${p.plan[0]!.toUpperCase()}${p.plan.slice(1)} di ${p.name} termina tra ${d} ${d === 1 ? 'giorno' : 'giorni'}.` });
      }
      const noVerified = PRIORITY_CITIES.slice(0, 10).filter((s) => !rs.some((x) => x.city_slug === s && x.is_active && (x.verified || x.claimed)))
        .map((s) => db().cities.find((c: R) => c.slug === s)?.name).filter(Boolean);
      if (noVerified.length) alerts.push({ level: 'low', key: 'city_no_verified', link: '/admin/launch/taranto/coverage',
        text: `${noVerified.length} ${noVerified.length === 1 ? 'comune prioritario' : 'comuni prioritari'} con 0 ristoranti verificati: ${noVerified.join(', ')}.` });
      const reportsOver = db().restaurant_reports.filter((x: R) => ['open', 'in_progress'].includes(x.status) && ts(x.created_at) < Date.now() - num('sla_data_report_hours') * 3600e3).length;
      if (reportsOver) alerts.push({ level: 'medium', key: 'reports_overdue', link: '/admin/reports', text: `${reportsOver} segnalazioni di dati errati oltre lo SLA interno.` });
      const inc = st().incidents.filter((i) => i.status !== 'resolved' && ['high', 'critical'].includes(i.severity)).length;
      if (inc) alerts.push({ level: 'high', key: 'incidents', link: '/admin/launch/taranto/today', text: `${inc} incidenti di lancio gravi aperti.` });
      const late = st().tasks.filter((x) => x.status === 'open' && x.due_at && ts(x.due_at) < Date.now()).length;
      if (late) alerts.push({ level: 'low', key: 'tasks_overdue', link: '/admin/launch/taranto/daily', text: `${late} attività commerciali scadute.` });
      const behind = st().goals.filter((g) => g.status === 'behind').length;
      if (behind) alerts.push({ level: 'low', key: 'goals_behind', link: '/admin/launch/taranto/plan', text: `${behind} obiettivi in ritardo rispetto al periodo trascorso.` });
      a.save();
      return {
        market: { id: m.id, slug: m.slug, name: m.name, status: m.status, launched_at: m.launched_at }, phase: setting<LaunchPhase>('launch_phase'),
        include_demo: a.demoVisible(), kpis, progress, alerts, local_queries: lq,
        pipeline: st().leads.filter((l) => l.kind === 'restaurant').reduce<Record<string, number>>((o, l) => ((o[l.status] = (o[l.status] ?? 0) + 1), o), {}),
        goals: st().goals, north_star: weekStarts(8).map((w) => ({ week: romeDay(w), value: metric('food_connections', w.getTime(), w.getTime() + 7 * DAY, m) })), generated_at: now(),
      };
    },
    async coverage(slug = 'taranto') {
      admin();
      const m = market(slug);
      const rs = rows(m);
      const prov = province(m.province_code);
      const cities = db().cities.filter((c: R) => c.province_id === prov?.id && (PRIORITY_CITIES.includes(c.slug) || rs.some((x) => x.city_id === c.id)));
      const out: CoverageRow[] = cities.map((c: R) => {
        const x = rs.filter((r) => r.city_id === c.id);
        return {
          city_id: c.id, city: c.name, slug: c.slug, priority: PRIORITY_CITIES.indexOf(c.slug) + 1 || null, lat: c.latitude, lng: c.longitude,
          censused: x.filter((r) => r.is_active || !r.closed).length, listed: x.filter((r) => r.is_active && !r.closed).length, verified: x.filter((r) => r.verified && r.is_active).length,
          unclaimed: x.filter((r) => !r.claimed && !r.closed).length, claimed: x.filter((r) => r.claimed).length, partner: x.filter((r) => r.partner).length,
          premium_top: x.filter((r) => ['premium', 'top'].includes(r.plan)).length, avg_completion: x.length ? Math.round(x.reduce((s, r) => s + r.completion, 0) / x.length) : null,
        };
      });
      return { include_demo: a.demoVisible(), rows: out.sort((p, q) => (p.priority ?? 999) - (q.priority ?? 999) || p.city.localeCompare(q.city)) };
    },
    async restaurants(slug, filter, search, limit, offset) {
      admin();
      const rs = rows(market(slug));
      const test: Record<RestaurantFilter, (x: LaunchRestaurantRow) => boolean> = {
        incomplete: (x) => x.completion < 60 && !x.closed, no_coords: (x) => x.no_coords && !x.closed, no_hours: (x) => x.no_hours && !x.closed, no_phone: (x) => x.no_phone && !x.closed,
        no_menu: (x) => !x.has_menu && !x.closed, claimable: (x) => x.claimable, stale: (x) => x.stale && !x.closed, closed: (x) => x.closed, duplicates: (x) => x.duplicate,
        position: (x) => x.position_far, segment_a: (x) => x.segment === 'A' && !x.closed, segment_b: (x) => x.segment === 'B' && !x.closed, segment_c: (x) => x.segment === 'C' && !x.closed,
      };
      const q = search?.trim().toLowerCase();
      const f = rs.filter((x) => (!q || x.name.toLowerCase().includes(q)) && (!filter || test[filter](x))).sort((p, s) => s.priority_score - p.priority_score || p.name.localeCompare(s.name));
      const counts = Object.fromEntries([['all', rs.length], ...Object.entries(test).map(([k, fn]) => [k, rs.filter(fn).length])]) as LaunchRestaurantsPage['counts'];
      return {
        include_demo: a.demoVisible(), counts, total: f.length, rows: f.slice(offset, offset + limit),
        open_reports: db().restaurant_reports.filter((x: R) => ['open', 'in_progress'].includes(x.status) && rs.some((r) => r.id === x.restaurant_id)).length,
      };
    },
    async firstN(slug = 'taranto') {
      admin();
      const n = num('launch_first_n');
      const list = rows(market(slug)).filter((x) => !x.closed && !x.paying && x.contact_allowed && !['lost', 'not_interested', 'do_not_contact', 'paid'].includes(x.lead_status ?? 'new'))
        .sort((p, q) => p.segment.localeCompare(q.segment) || q.priority_score - p.priority_score || q.completion - p.completion || p.name.localeCompare(q.name))
        .slice(0, n).map((x, i) => ({ ...x, rank: i + 1, assigned_name: profileName(x.assigned_to),
          claim_status: db().restaurant_claims.filter((c: R) => c.restaurant_id === x.id).sort((p: R, q: R) => q.created_at.localeCompare(p.created_at))[0]?.status ?? null }));
      return { n, include_demo: a.demoVisible(), rows: list };
    },
    async crmLeads(slug, kind, status, search, limit, offset) {
      admin();
      const m = market(slug);
      const q = search?.trim().toLowerCase();
      const endToday = Date.parse(`${romeDay()}T23:59:59`);
      const f = st().leads.filter((l) => l.market_id === m.id && (!kind || l.kind === kind)
        && (!status || l.status === status || (status === 'open' && ![...CLOSED, 'paid', 'closed'].includes(l.status)) || (status === 'due' && !!l.next_action_at && ts(l.next_action_at) <= endToday))
        && (!q || l.name.toLowerCase().includes(q) || (l.contact_name ?? '').toLowerCase().includes(q)))
        .sort((p, s) => (ts(p.next_action_at) || Infinity) - (ts(s.next_action_at) || Infinity) || s.updated_at.localeCompare(p.updated_at));
      return { total: f.length, rows: f.slice(offset, offset + limit).map((l) => ({ ...l, city_name: cityOf(l.city_id ?? '')?.name ?? null,
        restaurant_slug: db().restaurants.find((r: R) => r.id === l.restaurant_id)?.slug ?? null, assigned_name: profileName(l.assigned_to),
        open_tasks: st().tasks.filter((t) => t.lead_id === l.id && t.status === 'open').length })) };
    },
    async crmLead(id) {
      admin();
      const l = st().leads.find((x) => x.id === id);
      if (!l) throw fail('Lead non trovato');
      const r = db().restaurants.find((x: R) => x.id === l.restaurant_id);
      return {
        lead: { ...l, city_name: cityOf(l.city_id ?? '')?.name ?? null },
        restaurant: r ? { id: r.id, name: r.name, slug: r.slug, phone: r.phone ?? null, whatsapp: r.whatsapp ?? null, email: r.email ?? null, website: r.website ?? null,
          instagram: r.instagram ?? null, facebook: r.facebook ?? null, claimed: !!r.owner_id, is_active: r.is_active, plan: r.subscription_plan, completion: completion(r),
          founding: st().founding.find((f) => f.restaurant_id === r.id) ?? null,
          claim_status: db().restaurant_claims.filter((c: R) => c.restaurant_id === r.id).sort((p: R, q: R) => q.created_at.localeCompare(p.created_at))[0]?.status ?? null } : null,
        activities: st().activities.filter((x) => x.lead_id === id).sort((p, q) => q.created_at.localeCompare(p.created_at)).map((x) => ({ ...x, by_name: profileName(x.created_by) })),
        tasks: st().tasks.filter((t) => t.lead_id === id || (l.restaurant_id && t.restaurant_id === l.restaurant_id)),
      };
    },
    async crmUpsertLead(p) {
      admin();
      if (p.assigned_to && db().profiles.find((x: R) => x.id === p.assigned_to)?.role !== 'admin') throw fail('Il lead si assegna solo a un membro dello staff');
      if (p.competitor_tools?.length && !(p.competitor_source ?? st().leads.find((x) => x.id === p.id)?.competitor_source)) throw fail('Indica se l’informazione è pubblica o dichiarata dal lead');
      let l = p.id ? st().leads.find((x) => x.id === p.id) : p.restaurant_id ? st().leads.find((x) => x.restaurant_id === p.restaurant_id) : undefined;
      if (!l) {
        const r = db().restaurants.find((x: R) => x.id === p.restaurant_id);
        const name = (p.name ?? r?.name ?? '').trim();
        if (name.length < 2) throw fail('Nome obbligatorio');
        l = { id: uuid(), market_id: market(p.market).id, kind: p.kind ?? 'restaurant', category: p.category ?? null, restaurant_id: p.restaurant_id ?? null, name,
          city_id: p.city_id ?? r?.city_id ?? null, contact_name: null, phone: null, email: null, instagram: null, tiktok: null, website: null, followers: null, status: 'new',
          segment_override: null, assigned_to: null, next_action: null, next_action_at: null, last_contact_at: null, potential_plan: null, competitor_tools: [],
          competitor_source: null, contact_allowed: true, lost_reason: null, notes: null, created_at: now(), updated_at: now(), created_by: a.uid() };
        st().leads.push(l);
      }
      const prev = l.status;
      const { id: _i, market: _m, ...rest } = p;
      Object.assign(l, Object.fromEntries(Object.entries(rest).filter(([, v]) => v !== undefined)), { updated_at: now() });
      if (l.status === 'do_not_contact') Object.assign(l, { contact_allowed: false, next_action: null, next_action_at: null });
      if (p.status && p.status !== prev) st().activities.push({ id: uuid(), lead_id: l.id, type: 'status_change', outcome: null, notes: `${prev} → ${p.status}`, disclosure_required: null, created_by: a.uid(), created_at: now() });
      a.save();
      return l.id;
    },
    async crmLogActivity(input) {
      admin();
      const l = st().leads.find((x) => x.id === input.lead_id);
      if (!l) throw fail('Lead non trovato');
      if (!l.contact_allowed && OUTREACH.includes(input.type)) throw fail('Questo contatto ha chiesto di non essere ricontattato');
      const id = uuid();
      st().activities.push({ id, lead_id: l.id, type: input.type, outcome: input.outcome ?? null, notes: input.notes?.trim() || null,
        disclosure_required: input.type === 'collaboration' ? input.disclosure_required ?? true : null, created_by: a.uid(), created_at: now() });
      if ([...OUTREACH, 'demo', 'collaboration'].includes(input.type)) {
        l.last_contact_at = now();
        const r = rank(l.status);
        if (input.type === 'claim_link_sent' && r >= 0 && r <= 5) l.status = 'claim_sent';
        else if (input.type === 'demo' && input.outcome === 'done' && r >= 0 && r <= 4) l.status = 'demo_done';
        else if (input.type === 'demo' && input.outcome === 'scheduled' && r >= 0 && r <= 3) l.status = 'demo_scheduled';
        else if (['replied', 'interested'].includes(input.outcome ?? '') && r >= 0 && r <= 2) l.status = 'replied';
        else if (['new', 'researched'].includes(l.status)) l.status = 'contacted';
      } else if (input.type === 'research' && l.status === 'new') l.status = 'researched';
      if (input.next_action !== undefined || input.next_action_at !== undefined) Object.assign(l, { next_action: input.next_action || null, next_action_at: input.next_action_at || null });
      if (input.outcome === 'not_interested' && !['claimed', 'trial', 'activated', 'paid'].includes(l.status)) Object.assign(l, { status: 'not_interested', next_action: null, next_action_at: null });
      l.updated_at = now();
      a.save();
      return id;
    },
    async crmSyncRestaurantLeads(slug = 'taranto') {
      admin();
      const m = market(slug);
      let n = 0;
      for (const x of rows(m).filter((r) => !r.closed && !r.lead_id)) {
        st().leads.push({ id: uuid(), market_id: m.id, kind: 'restaurant', category: null, restaurant_id: x.id, name: x.name, city_id: x.city_id, contact_name: null, phone: null,
          email: null, instagram: null, tiktok: null, website: null, followers: null, status: x.paying ? 'paid' : x.claimed ? 'claimed' : 'new', segment_override: null,
          assigned_to: null, next_action: null, next_action_at: null, last_contact_at: null, potential_plan: null, competitor_tools: [], competitor_source: null,
          contact_allowed: true, lost_reason: null, notes: null, created_at: now(), updated_at: now(), created_by: null });
        n++;
      }
      audit('crm_leads_synced', m.id, { created: n });
      a.save();
      return n;
    },
    async crmTaskUpsert(input) {
      admin();
      let t = input.id ? st().tasks.find((x) => x.id === input.id) : undefined;
      if (!t) {
        if ((input.title ?? '').trim().length < 3) throw fail('Titolo troppo corto');
        t = { id: uuid(), market_id: market().id, lead_id: input.lead_id ?? null, restaurant_id: input.restaurant_id ?? null, title: input.title.trim(), reason: null,
          due_at: input.due_at ?? null, assigned_to: input.assigned_to ?? null, status: 'open', source: 'manual', created_at: now() };
        st().tasks.push(t);
      } else Object.assign(t, { title: input.title?.trim() || t.title, due_at: input.due_at ?? t.due_at, assigned_to: input.assigned_to ?? t.assigned_to });
      a.save();
      return t.id;
    },
    async crmTaskSetStatus(id, status) {
      admin();
      const t = st().tasks.find((x) => x.id === id);
      if (t) t.status = status;
      a.save();
    },
    async foundingActivate(rid, note) {
      admin();
      if (!setting('founding_program_enabled')) throw fail('Il programma Partner Fondatori è disattivato');
      const r = db().restaurants.find((x: R) => x.id === rid);
      if (!r) throw fail('Locale non trovato');
      const m = market();
      if (!inMarket({ ...r, is_demo: false }, m)) throw fail('Il locale non appartiene a un mercato attivo');
      if (!r.owner_id || !db().restaurant_members.some((x: R) => x.restaurant_id === rid && x.role === 'owner' && x.status === 'active')) {
        throw fail('Il locale deve essere rivendicato da un titolare prima di aderire');
      }
      const existing = st().founding.find((f) => f.restaurant_id === rid);
      if (existing && existing.status !== 'revoked') throw fail('Il locale è già Partner Fondatore');
      if (st().founding.filter((f) => f.market_id === m.id && f.status !== 'revoked').length >= num('founding_limit')) throw fail('Posti da Partner Fondatore esauriti per questo mercato');
      const plan = String(setting('founding_plan'));
      const days = Math.max(0, num('founding_days'));
      const payingNow = subs().some((s) => s.restaurant_id === rid && s.source === 'stripe' && grants(s));
      const ends = new Date(Date.now() + days * DAY).toISOString();
      const subId = days > 0 && plan !== 'free' && !payingNow ? await a.grantPlan(rid, plan, ends, `Partner Fondatore — ${note ?? ''}`) : null;
      const number = existing?.number ?? Math.max(0, ...st().founding.filter((f) => f.market_id === m.id).map((f) => f.number)) + 1;
      const row = { id: existing?.id ?? uuid(), market_id: m.id, restaurant_id: rid, number, status: 'active' as const, benefit_plan: plan, benefit_days: subId ? days : 0,
        subscription_id: subId, badge_visible: true, activated_at: now(), benefit_ends_at: subId ? ends : null, revoked_reason: null, notes: note };
      if (existing) Object.assign(existing, row); else st().founding.push(row);
      advanceLead(rid, 'trial');
      audit('founding_activated', rid, { number, plan, days });
      a.save();
      return { number, plan, days: subId ? days : 0 };
    },
    async foundingRevoke(rid, reason) {
      admin();
      if (!reason.trim()) throw fail('Indica il motivo');
      const f = st().founding.find((x) => x.restaurant_id === rid && x.status !== 'revoked');
      if (!f) throw fail('Nessuna adesione attiva');
      Object.assign(f, { status: 'revoked', revoked_reason: reason.trim().slice(0, 300), badge_visible: false });
      if (f.subscription_id && subs().some((s) => s.id === f.subscription_id && !s.revoked_at)) await a.revokePlan(f.subscription_id);
      audit('founding_revoked', rid, { reason });
      a.save();
    },
    async foundingList(slug = 'taranto') {
      admin();
      maintain();
      return foundingProgram(market(slug));
    },
    async daily(slug = 'taranto') {
      admin();
      const m = market(slug);
      const start = Date.parse(`${romeDay()}T00:00:00`);
      const end = start + DAY;
      const acts = st().activities.filter((x) => ts(x.created_at) >= start && st().leads.find((l) => l.id === x.lead_id)?.market_id === m.id);
      const ids = new Set(marketRests(m).map((r: R) => r.id));
      const claims = db().restaurant_claims;
      const board: DailyBoard = {
        day: romeDay(),
        targets: { research: num('launch_daily_target_research'), contacts: num('launch_daily_target_contacts'), demos: num('launch_daily_target_demos'),
          claims: num('launch_daily_target_claims'), trials: num('launch_daily_target_trials') },
        actual: {
          research: acts.filter((x) => x.type === 'research').length + st().leads.filter((l) => l.market_id === m.id && ts(l.created_at) >= start && l.created_by).length,
          contacts: new Set(acts.filter((x) => OUTREACH.includes(x.type)).map((x) => x.lead_id)).size,
          demos: acts.filter((x) => x.type === 'demo' && x.outcome === 'done').length,
          claims: claims.filter((c: R) => c.status === 'approved' && ts(c.approved_at ?? c.updated_at) >= start && ids.has(c.restaurant_id)).length,
          trials: st().founding.filter((f) => f.market_id === m.id && ts(f.activated_at) >= start).length,
        },
        due_leads: st().leads.filter((l) => l.market_id === m.id && l.next_action_at && ts(l.next_action_at) < end && ![...CLOSED, 'closed'].includes(l.status))
          .sort((p, q) => ts(p.next_action_at) - ts(q.next_action_at)).slice(0, 50)
          .map((l) => ({ id: l.id, name: l.name, kind: l.kind, status: l.status, next_action: l.next_action, next_action_at: l.next_action_at, last_contact_at: l.last_contact_at,
            restaurant_id: l.restaurant_id, city_name: cityOf(l.city_id ?? '')?.name ?? null, assigned_name: profileName(l.assigned_to) })),
        follow_ups: st().leads.filter((l) => l.market_id === m.id && ['contacted', 'replied', 'demo_done', 'claim_sent'].includes(l.status) && !l.next_action_at && ts(l.last_contact_at) < ago(3))
          .map((l) => ({ id: l.id, name: l.name, status: l.status, last_contact_at: l.last_contact_at })),
        demos: st().leads.filter((l) => l.market_id === m.id && l.status === 'demo_scheduled').map((l) => ({ id: l.id, name: l.name, next_action: l.next_action, next_action_at: l.next_action_at })),
        claims_pending: claims.filter((c: R) => ['pending', 'under_review', 'more_information_required'].includes(c.status)).sort((p: R, q: R) => p.created_at.localeCompare(q.created_at))
          .map((c: R) => ({ id: c.id, status: c.status, created_at: c.created_at, restaurant_name: db().restaurants.find((r: R) => r.id === c.restaurant_id)?.name ?? '',
            age_hours: Math.round((Date.now() - ts(c.created_at)) / 3600e3), overdue: ts(c.created_at) < Date.now() - num('sla_claim_review_hours') * 3600e3 })),
        trials_expiring: subs().filter((s) => ids.has(s.restaurant_id) && grants(s) && ((s.source !== 'stripe' && s.expires_at && ts(s.expires_at) < Date.now() + 7 * DAY)
          || (s.source === 'stripe' && s.status === 'trialing' && ts(s.trial_end) < Date.now() + 7 * DAY)))
          .map((s) => ({ restaurant_id: s.restaurant_id, name: db().restaurants.find((r: R) => r.id === s.restaurant_id)?.name ?? '', plan_code: s.plan_code, source: s.source,
            ends_at: s.expires_at ?? s.trial_end, founding: st().founding.some((f) => f.restaurant_id === s.restaurant_id && f.status === 'active') })),
        new_paying: subs().filter((s) => ids.has(s.restaurant_id) && s.source === 'stripe' && ts(s.paid_started_at) > ago(7))
          .map((s) => ({ name: db().restaurants.find((r: R) => r.id === s.restaurant_id)?.name ?? '', plan_code: s.plan_code, paid_started_at: s.paid_started_at })),
        tasks: st().tasks.filter((t) => t.status === 'open' && (!t.due_at || ts(t.due_at) < end))
          .map((t) => ({ ...t, restaurant_name: db().restaurants.find((r: R) => r.id === t.restaurant_id)?.name ?? null, lead_name: st().leads.find((l) => l.id === t.lead_id)?.name ?? null })),
      };
      return board;
    },
    async weekly(slug = 'taranto', weeks = 8) {
      admin();
      const m = market(slug);
      const ids = new Set(marketRests(m).map((r: R) => r.id));
      const rs = rows(m);
      const users = db().profiles.filter((p: R) => p.role === 'customer');
      const days = a.activityDays();
      const fb7 = st().feedback.filter((f) => ts(f.created_at) > ago(7));
      const count = <T>(xs: T[], key: (x: T) => string) => xs.reduce<Record<string, number>>((o, x) => ((o[key(x)] = (o[key(x)] ?? 0) + 1), o), {});
      const nps = st().feedback.filter((f) => f.type === 'nps' && ts(f.created_at) > ago(90));
      const out: WeeklyReview = {
        weeks: weekStarts(Math.min(Math.max(weeks, 1), 26)).map((w) => {
          const s = w.getTime();
          const e = s + 7 * DAY;
          const acts = st().activities.filter((x) => ts(x.created_at) >= s && ts(x.created_at) < e && st().leads.find((l) => l.id === x.lead_id)?.market_id === m.id);
          return {
            week: romeDay(w), contacted: new Set(acts.filter((x) => OUTREACH.includes(x.type)).map((x) => x.lead_id)).size,
            replies: acts.filter((x) => ['replied', 'interested', 'scheduled'].includes(x.outcome ?? '')).length,
            claims: db().restaurant_claims.filter((c: R) => c.status === 'approved' && ts(c.approved_at ?? c.updated_at) >= s && ts(c.approved_at ?? c.updated_at) < e && ids.has(c.restaurant_id)).length,
            trials: st().founding.filter((f) => f.market_id === m.id && ts(f.activated_at) >= s && ts(f.activated_at) < e).length,
            paid: subs().filter((x) => ids.has(x.restaurant_id) && x.source === 'stripe' && ts(x.paid_started_at) >= s && ts(x.paid_started_at) < e).length,
            new_users: users.filter((p: R) => ts(p.created_at) >= s && ts(p.created_at) < e).length, visits: metric('visits', s, e, m), reservations: metric('reservations', s, e, m),
            orders: metric('orders_completed', s, e, m), food_connections: metric('food_connections', s, e, m),
          };
        }),
        mrr_cents: metric('mrr_cents', 0, Date.now(), m),
        feedback_loop: {
          support_by_category: count(a.supportTickets().filter((t) => ts(t.created_at) > ago(7)), (t) => t.category),
          incidents: count(st().incidents.filter((i) => ts(i.created_at) > ago(7)), (i) => i.severity),
          feedback_by_type: count(fb7, (f) => f.type),
          cancellation_reasons: count(st().feedback.filter((f) => f.type === 'cancellation' && ts(f.created_at) > ago(90)), (f) => f.reason ?? 'non_indicato'),
          nps: { responses: nps.length, score: nps.length ? Math.round(((nps.filter((f) => (f.rating ?? 0) >= 9).length - nps.filter((f) => (f.rating ?? 0) <= 6).length) * 100) / nps.length) : null },
          latest_user: st().feedback.filter((f) => ['user_general', 'bug', 'feature_request'].includes(f.type) && f.message).slice(-8).reverse()
            .map((f) => ({ message: f.message!, type: f.type, created_at: f.created_at })),
          latest_restaurant: st().feedback.filter((f) => f.type === 'restaurant_dashboard').slice(-8).reverse()
            .map((f) => ({ message: f.message ?? '', restaurant: db().restaurants.find((r: R) => r.id === f.restaurant_id)?.name ?? null, created_at: f.created_at })),
        },
        user_funnel: {
          visits: metric('visits', ago(30), Date.now(), m),
          searches: (db().app_events ?? []).filter((e: R) => ['search', 'near_me_search', 'map_area_search'].includes(e.event_type) && ts(e.created_at) > ago(30)).length,
          restaurant_views: events().filter((e) => ids.has(e.restaurant_id) && e.event_type === 'restaurant_view' && ts(e.created_at) > ago(30)).length,
          menu_views: events().filter((e) => ids.has(e.restaurant_id) && e.event_type === 'menu_view' && ts(e.created_at) > ago(30)).length,
          favorites: db().favorites.filter((f: R) => ids.has(f.restaurant_id) && ts(f.created_at) > ago(30)).length,
          reservations_orders: metric('reservations', ago(30), Date.now(), m) + metric('orders_completed', ago(30), Date.now(), m),
          reviews: metric('reviews_published', ago(30), Date.now(), m),
          returning_users: Object.values(count(days.filter((d) => Date.parse(d.day) > ago(30)), (d) => d.user_id)).filter((n) => n >= 2).length,
        },
        business_funnel: {
          discovered: rs.filter((x) => !x.closed).length, lead: rs.filter((x) => x.lead_id).length,
          contacted: rs.filter((x) => x.last_contact_at || rank(x.lead_status) >= 2).length, claimed: rs.filter((x) => x.claimed).length,
          trial: rs.filter((x) => x.founding || rank(x.lead_status) >= 8).length, activated: rs.filter((x) => x.claimed && activated(x.id)).length,
          paid: rs.filter((x) => x.paying).length,
          retained: rs.filter((x) => x.paying && subs().some((s) => s.restaurant_id === x.id && s.source === 'stripe' && ts(s.paid_started_at) < ago(60))).length,
        },
        activation: {
          users_signed_up_30_60d: users.filter((p: R) => ts(p.created_at) > ago(60) && ts(p.created_at) < ago(30)).length,
          users_activated_30_60d: users.filter((p: R) => ts(p.created_at) > ago(60) && ts(p.created_at) < ago(30)
            && (db().favorites.some((f: R) => f.user_id === p.id) || (db().coupon_claims ?? []).some((c: R) => c.user_id === p.id) || (db().reservations ?? []).some((r: R) => r.user_id === p.id))).length,
          restaurants_claimed: rs.filter((x) => x.claimed).length, restaurants_activated: rs.filter((x) => x.claimed && activated(x.id)).length,
        },
        cohorts: {
          users: weekStarts(8).map((w) => {
            const c = users.filter((p: R) => ts(p.created_at) >= w.getTime() && ts(p.created_at) < w.getTime() + 7 * DAY);
            const back = (p: R, from: number, to: number) => days.some((d) => d.user_id === p.id && Date.parse(d.day) >= ts(p.created_at) + from * DAY && Date.parse(d.day) < ts(p.created_at) + to * DAY);
            return { week: romeDay(w), size: c.length, returned_week2: c.filter((p: R) => back(p, 7, 14)).length, returned_after: c.filter((p: R) => back(p, 7, 3650)).length };
          }),
          restaurants: weekStarts(8).map((w) => {
            const c = marketRests(m).filter((r: R) => r.owner_id && ts(r.claimed_at) >= w.getTime() && ts(r.claimed_at) < w.getTime() + 7 * DAY);
            return { week: romeDay(w), claimed: c.length, activated: c.filter((r: R) => activated(r.id)).length, paid: c.filter((r: R) => paying(r.id)).length };
          }),
          trial_conversion: {
            founding_completed: st().founding.filter((f) => f.status === 'completed').length,
            founding_converted: st().founding.filter((f) => f.status === 'completed' && paying(f.restaurant_id)).length,
            stripe_trials_ended: (db().billing_trials ?? []).filter((t: R) => (t.ends_at && ts(t.ends_at) <= Date.now()) || t.converted_at).length,
            stripe_trials_converted: (db().billing_trials ?? []).filter((t: R) => t.converted_at).length,
          },
        },
        time_to_value: timeToValue(m),
      };
      return out;
    },
    async partners(slug = 'taranto') {
      admin();
      maintain();
      const m = market(slug);
      const p = partnerRows(m).sort((x, y) => y.flags.length - x.flags.length || x.health - y.health);
      return { rows: p, at_risk: p.filter((x) => x.flags.some((f) => f !== 'reservations_waiting')).length, founding: foundingProgram(m), time_to_value: timeToValue(m) };
    },
    async generateFollowups(slug = 'taranto') {
      admin();
      const n = generateFollowups(market(slug));
      a.save();
      return n;
    },
    async opsToday() {
      admin();
      const h = (k: string) => num(k) * 3600e3;
      const claims = db().restaurant_claims.filter((c: R) => ['pending', 'under_review', 'more_information_required'].includes(c.status));
      const tickets = a.supportTickets().filter((t) => ['open', 'in_progress', 'waiting_customer'].includes(t.status));
      const rest = ['restaurant', 'business', 'claim', 'menu', 'subscription', 'ads', 'billing'];
      const over = (t: R) => t.status === 'open' && ts(t.created_at) < Date.now() - h('sla_support_first_response_hours');
      const reports = db().restaurant_reports.filter((x: R) => ['open', 'in_progress'].includes(x.status));
      const issues = a.orderIssues().filter((x) => ['open', 'in_progress'].includes(x.status));
      return {
        sla: { claim_hours: num('sla_claim_review_hours'), support_hours: num('sla_support_first_response_hours'), order_issue_hours: num('sla_order_issue_hours'), data_report_hours: num('sla_data_report_hours') },
        claims_pending: { count: claims.length, overdue: claims.filter((c: R) => ts(c.created_at) < Date.now() - h('sla_claim_review_hours')).length },
        order_issues: { count: issues.length, overdue: issues.filter((x) => ts(x.created_at) < Date.now() - h('sla_order_issue_hours')).length },
        restaurant_support: { count: tickets.filter((t) => rest.includes(t.category)).length, overdue: tickets.filter((t) => rest.includes(t.category) && over(t)).length },
        customer_support: { count: tickets.filter((t) => !rest.includes(t.category)).length, overdue: tickets.filter((t) => !rest.includes(t.category) && over(t)).length },
        rider_issues: db().settings.logistics_enabled === false ? null : { count: a.deliveryIssues().filter((x) => ['open', 'in_review'].includes(x.status)).length },
        payments_failed_24h: a.orders().filter((o) => o.payment_status === 'failed' && ts(o.updated_at ?? o.created_at) > ago(1)).length,
        data_reports: { count: reports.length, overdue: reports.filter((x: R) => ts(x.created_at) < Date.now() - h('sla_data_report_hours')).length,
          rows: reports.map((x: R) => { const r = db().restaurants.find((y: R) => y.id === x.restaurant_id); return { id: x.id, type: x.report_type, restaurant: r?.name ?? '', slug: r?.slug ?? '', created_at: x.created_at }; }) },
        sales_followups: st().leads.filter((l) => l.next_action_at && ts(l.next_action_at) < Date.now() + DAY && ![...CLOSED, 'closed'].includes(l.status)).length
          + st().tasks.filter((t) => t.status === 'open' && (!t.due_at || ts(t.due_at) < Date.now() + DAY)).length,
        incidents: st().incidents.filter((i) => i.status !== 'resolved').sort((x, y) => ['critical', 'high', 'medium', 'low'].indexOf(x.severity) - ['critical', 'high', 'medium', 'low'].indexOf(y.severity)),
        feedback_new: st().feedback.filter((f) => f.status === 'new').length,
      };
    },
    async growth(slug = 'taranto', days = 30) {
      admin();
      const m = market(slug);
      const from = ago(Math.min(Math.max(days, 1), 365));
      const ids = new Set(marketRests(m).map((r: R) => r.id));
      const minC = num('cac_min_conversions');
      const costs = st().costs.filter((c) => Date.parse(c.spent_on) >= from - DAY);
      const restCost = costs.filter((c) => c.audience === 'restaurants').reduce((s, c) => s + c.amount_cents, 0);
      const userCost = costs.filter((c) => c.audience === 'users').reduce((s, c) => s + c.amount_cents, 0);
      const newPaying = new Set(subs().filter((s) => ids.has(s.restaurant_id) && s.source === 'stripe' && ts(s.paid_started_at) >= from).map((s) => s.restaurant_id)).size;
      const newUsers = db().profiles.filter((p: R) => p.role === 'customer' && ts(p.created_at) >= from).length;
      const vis = st().visits.filter((v) => ts(v.created_at) >= from);
      const by = <T>(xs: T[], k: (x: T) => string) => xs.reduce<Record<string, number>>((o, x) => ((o[k(x)] = (o[k(x)] ?? 0) + 1), o), {});
      const camp = by(vis.filter((v) => v.utm_campaign), (v) => `${v.utm_source ?? ''}|${v.utm_medium ?? ''}|${v.utm_campaign}`);
      const refs = a.referrals();
      const brefs = a.businessReferrals();
      return {
        days, visits_by_channel: by(vis, (v) => v.channel),
        campaigns: Object.entries(camp).map(([k, visits]) => { const [s, md, c] = k.split('|'); return { utm_source: s || null, utm_medium: md || null, utm_campaign: c!, visits }; }).sort((x, y) => y.visits - x.visits).slice(0, 30),
        signups_by_channel: by(st().user_acquisition.filter((u) => ts(u.created_at) >= from), (u) => u.channel), signups_total: newUsers,
        signups_attributed: st().user_acquisition.filter((u) => ts(u.created_at) >= from).length, codes: [...st().codes].sort((x, y) => y.uses - x.uses),
        qr_by_kind: by(st().qr_scans.filter((q) => ids.has(q.restaurant_id) && ts(q.created_at) >= from), (q) => q.kind),
        referral_funnel: { invited: refs.filter((r) => ts(r.created_at) >= from).length, registered: refs.filter((r) => ts(r.registered_at) >= from).length,
          qualified: refs.filter((r) => ts(r.qualified_at) >= from).length, rewarded: refs.filter((r) => ts(r.rewarded_at) >= from).length },
        restaurant_referral_funnel: { invited: brefs.filter((r) => ts(r.created_at) >= from).length, qualified: brefs.filter((r) => ts(r.qualified_at) >= from).length,
          rewarded: brefs.filter((r) => r.status === 'rewarded' && ts(r.created_at) >= from).length },
        ambassadors: { applied: st().ambassadors.filter((x) => x.status === 'applied').length, approved: st().ambassadors.filter((x) => x.status === 'approved').length },
        experiments: st().experiments.map((e) => ({ ...e, exposures: by((db().app_events ?? []).filter((x: R) => x.event_type === 'experiment_exposure' && x.metadata?.experiment === e.key), (x: R) => String(x.metadata?.variant)) })),
        costs: { restaurants_cents: restCost, users_cents: userCost, rows: costs },
        cac: {
          restaurant_cents: restCost > 0 && newPaying >= minC ? Math.round(restCost / newPaying) : null,
          restaurant_reason: restCost === 0 ? 'no_costs' : newPaying < minC ? 'too_few_conversions' : null, restaurant_conversions: newPaying,
          user_cents: userCost > 0 && newUsers >= minC ? Math.round(userCost / newUsers) : null,
          user_reason: userCost === 0 ? 'no_costs' : newUsers < minC ? 'too_few_conversions' : null, user_conversions: newUsers, min_conversions: minC,
        },
        revenue_per_restaurant: marketRests(m).filter((r: R) => r.owner_id).map((r: R) => {
          const sub = (db().billing_invoices ?? []).filter((i: R) => i.restaurant_id === r.id && i.status === 'paid').reduce((s: number, i: R) => s + (i.amount_paid_cents ?? 0), 0);
          const fees = Math.round(a.orders().filter((o) => o.restaurant_id === r.id && o.status === 'completed').reduce((s, o) => s + Number(o.platform_fee ?? 0) + Number(o.service_fee ?? 0), 0) * 100);
          return { id: r.id, name: r.name, subscription_cents: sub, order_fees_cents: fees, ads_cents: 0, total_cents: sub + fees };
        }).filter((x: R) => x.total_cents > 0).sort((x: R, y: R) => y.total_cents - x.total_cents),
      };
    },
    async setPhase(slug, phase) {
      admin();
      const m = market(slug);
      const from = m.status;
      m.status = phase;
      if (phase === 'public_launch') m.launched_at ??= now();
      if (['private_beta', 'local_beta', 'public_launch'].includes(phase)) db().settings.launch_phase = phase;
      audit('launch_phase_changed', m.id, { from, to: phase });
      a.save();
    },
    async goalUpsert(g) {
      admin();
      let row = g.id ? st().goals.find((x) => x.id === g.id) : undefined;
      if (!row) {
        if (!g.metric_key || !g.target_value || !g.period_start || !g.period_end) throw fail('Compila metrica, target e periodo');
        if (g.period_end <= g.period_start) throw fail('Il periodo deve terminare dopo l’inizio');
        row = { id: uuid(), metric_key: g.metric_key, target_value: g.target_value, period_start: g.period_start, period_end: g.period_end, actual_value: null, status: 'not_started', refreshed_at: null };
        st().goals.push(row);
      } else Object.assign(row, Object.fromEntries(Object.entries(g).filter(([k, v]) => v !== undefined && k !== 'id' && k !== 'metric_key')));
      refreshGoals();
      a.save();
      return row.id;
    },
    async goalDelete(id) {
      admin();
      st().goals = st().goals.filter((g) => g.id !== id);
      a.save();
    },
    async costAdd(c) {
      admin();
      if (!(c.amount_cents > 0)) throw fail('Importo non valido');
      const id = uuid();
      st().costs.push({ ...c, id });
      a.save();
      return id;
    },
    async costDelete(id) {
      admin();
      st().costs = st().costs.filter((c) => c.id !== id);
      a.save();
    },
    async experimentUpsert(e) {
      admin();
      let row = e.id ? st().experiments.find((x) => x.id === e.id) : undefined;
      const variants = e.variants?.map((v) => v.toLowerCase().replace(/[^a-z0-9_]/g, '')).filter(Boolean);
      if (variants && (variants.length < 2 || variants.length > 3)) throw fail('Da 2 a 3 varianti');
      if (!row) {
        if (!/^[a-z0-9_]{3,40}$/.test(e.key ?? '')) throw fail('Chiave: 3–40 caratteri minuscoli, numeri o _');
        if (st().experiments.some((x) => x.key === e.key)) throw fail('Esiste già un esperimento con questa chiave');
        row = { id: uuid(), key: e.key!, name: e.name ?? e.key!, hypothesis: e.hypothesis ?? null, primary_metric: e.primary_metric ?? null, variants: variants ?? ['control', 'variant_b'],
          status: 'draft', started_at: null, stopped_at: null, created_at: now() };
        st().experiments.push(row);
      } else Object.assign(row, { name: e.name ?? row.name, hypothesis: e.hypothesis ?? row.hypothesis, primary_metric: e.primary_metric ?? row.primary_metric,
        variants: row.status === 'draft' && variants ? variants : row.variants });
      a.save();
      return row.id;
    },
    async experimentSetStatus(id, status) {
      admin();
      if (status === 'running' && st().experiments.filter((e) => e.status === 'running' && e.id !== id).length >= num('experiments_max_running')) {
        throw fail('Troppi esperimenti attivi: fermane uno prima di avviarne un altro');
      }
      const e = st().experiments.find((x) => x.id === id);
      if (e) Object.assign(e, { status, started_at: status === 'running' ? e.started_at ?? now() : e.started_at, stopped_at: status === 'stopped' ? now() : null });
      a.save();
    },
    async planItems() {
      admin();
      return [...st().plan].sort((x, y) => x.horizon.localeCompare(y.horizon) || x.bucket.localeCompare(y.bucket) || x.sort - y.sort).map((i) => ({ ...i, owner_name: profileName(i.owner_id) }));
    },
    async planItemUpdate(id, patch) {
      admin();
      const i = st().plan.find((x) => x.id === id);
      if (i) Object.assign(i, patch);
      a.save();
    },
    async contentList() {
      admin();
      return [...st().content].sort((x, y) => (x.scheduled_for ?? x.created_at).localeCompare(y.scheduled_for ?? y.created_at))
        .map((c) => ({ ...c, restaurant_name: db().restaurants.find((r: R) => r.id === c.restaurant_id)?.name ?? null }));
    },
    async contentUpsert(c) {
      admin();
      let row = c.id ? st().content.find((x) => x.id === c.id) : undefined;
      const next = { ...(row ?? { id: uuid(), platform: 'instagram', content_type: 'local', restaurant_id: null, title: null, caption: null, media_url: null, status: 'idea',
        scheduled_for: null, published_at: null, is_sponsored: false, rights_confirmed: false, compliance_checked: false, notes: null, created_at: now() }), ...Object.fromEntries(Object.entries(c).filter(([, v]) => v !== undefined)) } as ContentItem;
      const beyondDraft = !['idea', 'draft'].includes(next.status);
      if (next.is_sponsored && beyondDraft && !/(#adv|#ad\b|sponsorizzat|pubblicit|in collaborazione con)/i.test(next.caption ?? '')) throw fail('Contenuto sponsorizzato: aggiungi #adv o "Sponsorizzato" nella didascalia');
      if (next.content_type === 'ugc' && beyondDraft && !next.rights_confirmed) throw fail('Contenuto degli utenti: conferma di avere il permesso dell’autore');
      if (next.content_type === 'giveaway' && beyondDraft && !next.compliance_checked) throw fail('Giveaway: completa la checklist di conformità');
      if (next.status === 'scheduled' && !next.scheduled_for) throw fail('Indica la data di pubblicazione');
      if (next.status === 'published') next.published_at ??= now(); else next.published_at = null;
      if (row) Object.assign(row, next); else { row = next; st().content.push(row); }
      a.save();
      return row.id;
    },
    async contentDelete(id) {
      admin();
      st().content = st().content.filter((c) => c.id !== id);
      a.save();
    },
    async seedSocialCalendar(_slug = 'taranto', start = null) {
      admin();
      const base = start ? Date.parse(start) : Date.now() + DAY;
      let n = 0;
      SOCIAL_SEED.forEach(([platform, type, title, caption], i) => {
        if (st().content.some((c) => c.title === title)) return;
        st().content.push({ id: uuid(), platform: platform as ContentItem['platform'], content_type: type as ContentItem['content_type'], restaurant_id: null, title, caption, media_url: null,
          status: 'idea', scheduled_for: null, published_at: null, is_sponsored: false, rights_confirmed: false, compliance_checked: false,
          notes: `Giorno ${i + 1} — data suggerita ${new Date(base + i * DAY).toLocaleDateString('it-IT')}`, created_at: new Date(Date.now() + i).toISOString() });
        n++;
      });
      a.save();
      return n;
    },
    async codeUpsert(c) {
      admin();
      const code = c.code.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
      if (!/^[A-Z0-9]{3,20}$/.test(code)) throw fail('Codice: 3–20 lettere o numeri');
      const ex = st().codes.find((x) => x.code === code);
      if (ex) Object.assign(ex, { kind: c.kind ?? ex.kind, description: c.description ?? ex.description, is_active: c.is_active ?? ex.is_active });
      else st().codes.push({ code, kind: c.kind ?? 'campaign', description: c.description ?? null, is_active: c.is_active ?? true, uses: 0, restaurant_id: c.restaurant_id ?? null, created_at: now() });
      a.save();
      return code;
    },
    async feedbackList(type, status, limit, offset) {
      admin();
      const f = st().feedback.filter((x) => (!type || x.type === type) && (!status || x.status === status)).sort((x, y) => y.created_at.localeCompare(x.created_at));
      return { total: f.length, rows: f.slice(offset, offset + limit).map((x) => ({ ...x, restaurant_name: db().restaurants.find((r: R) => r.id === x.restaurant_id)?.name ?? null })) };
    },
    async feedbackUpdate(id, status) {
      admin();
      const f = st().feedback.find((x) => x.id === id);
      if (f) f.status = status;
      a.save();
    },
    async incidentUpsert(i) {
      admin();
      let row = i.id ? st().incidents.find((x) => x.id === i.id) : undefined;
      if (!row) {
        if ((i.title ?? '').trim().length < 3 || !i.severity) throw fail('Titolo e gravità obbligatori');
        row = { id: uuid(), title: i.title!.trim(), description: i.description ?? null, area: i.area ?? 'other', severity: i.severity, status: 'open', created_at: now(), resolved_at: null };
        st().incidents.push(row);
        audit('launch_incident_opened', row.id, { severity: i.severity });
      } else Object.assign(row, { status: i.status ?? row.status, severity: i.severity ?? row.severity, description: i.description ?? row.description,
        resolved_at: i.status === 'resolved' ? row.resolved_at ?? now() : i.status ? null : row.resolved_at });
      a.save();
      return row.id;
    },
    async ambassadors() {
      admin();
      return st().ambassadors.map((x) => {
        const p = db().profiles.find((y: R) => y.id === x.user_id);
        const refs = a.referrals().filter((r) => r.referrer_user_id === x.user_id);
        return { ...x, name: p?.display_name ?? p?.full_name ?? null, email: p?.email ?? null, referrals: refs.length, qualified: refs.filter((r) => r.qualified_at).length };
      });
    },
    async ambassadorSetStatus(id, status, notes = null) {
      admin();
      const x = st().ambassadors.find((y) => y.id === id);
      if (x) Object.assign(x, { status, approved_at: status === 'approved' ? x.approved_at ?? now() : x.approved_at, notes: notes ?? x.notes });
      audit(`ambassador_${status}`, id);
      a.save();
    },
    async expansionSignals() {
      admin();
      return db().provinces.filter((p: R) => !st().markets.some((m) => m.province_code === p.code)).map((p: R) => {
        const rs = db().restaurants.filter((r: R) => r.province_id === p.id && !r.is_demo);
        const claims = db().restaurant_claims.filter((c: R) => rs.some((r: R) => r.id === c.restaurant_id)).length;
        const favs = db().favorites.filter((f: R) => rs.some((r: R) => r.id === f.restaurant_id)).length;
        const leads = st().leads.filter((l) => cityOf(l.city_id ?? '')?.province_id === p.id).length;
        return { province: p.name, code: p.code, restaurants: rs.length, claims, leads, favorites: favs, score: rs.length + 3 * claims + favs };
      }).filter((x: R) => x.score > 0).sort((x: R, y: R) => y.score - x.score);
    },
  };
  return api;
}

