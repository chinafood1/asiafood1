// ─────────────────────────────────────────────────────────────
//  Fase 7 in modalità DEMO: stesse regole delle funzioni SQL
//  (idempotenza, limiti, verifica recensioni, referral, campagne,
//  promemoria) applicate al database locale di prova. Nessun
//  invio reale: le push diventano notifiche locali del browser.
// ─────────────────────────────────────────────────────────────
import type { AppNotification, Coupon, CouponClaim, Offer, Profile, Reservation, Restaurant } from '@/types/domain';
import type {
  Achievement, AdminReferral, AdminReview, BusinessReferral, Campaign, CampaignInput, CampaignTarget, EngagementTickResult, LoyaltyTransaction,
  LoyaltyWallet, ManagedReview, NotificationPrefs, PushCampaignStats, RedeemResult, ReferralSummary, RestaurantEngagementStats, RestaurantRating,
  RetentionStats, Reward, ReviewFilter, ReviewFormStatus, ReviewInput, ReviewItem, ReviewReportReason, ReviewSort, ReviewStatus,
} from '@/types/engagement';
import { DEFAULT_PREFS } from '@/types/engagement';

type Row = Record<string, unknown>;
const now = () => new Date().toISOString();
const uuid = () => crypto.randomUUID();
const DAY = 86_400_000;
const romeDate = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome' }).format(d);

export interface DemoReview {
  id: string;
  restaurant_id: string;
  user_id: string;
  reservation_id: string | null;
  coupon_claim_id: string | null;
  order_id?: string | null;
  rating_overall: number;
  rating_food: number | null;
  rating_service: number | null;
  rating_value: number | null;
  rating_atmosphere: number | null;
  title: string | null;
  content: string;
  is_verified: boolean;
  verification_source: 'reservation' | 'coupon' | 'order' | null;
  status: ReviewStatus;
  moderation_flags: string[];
  moderation_note: string | null;
  is_edited: boolean;
  helpful_count: number;
  restaurant_response_count: number;
  created_at: string;
  updated_at: string;
  published_at: string | null;
  moderated_at: string | null;
  moderated_by: string | null;
}

/** Stato della Fase 7 dentro il database DEMO (campi facoltativi: nessun reset dei dati esistenti). */
export interface EngagementState {
  reviews: DemoReview[];
  review_versions: { id: string; review_id: string; previous_title: string | null; previous_content: string; previous_rating: number; created_at: string }[];
  review_responses: { id: string; review_id: string; restaurant_id: string; user_id: string | null; content: string; status: 'published' | 'hidden'; created_at: string; updated_at: string }[];
  review_votes: { review_id: string; user_id: string; created_at: string }[];
  review_reports: { id: string; review_id: string; reporter_user_id: string; reason: ReviewReportReason; details: string | null; status: 'open' | 'upheld' | 'dismissed'; created_at: string; reviewed_at: string | null }[];
  loyalty_accounts: { user_id: string; points_balance: number; lifetime_points: number; level: string; created_at: string }[];
  loyalty_transactions: (LoyaltyTransaction & { user_id: string; source_id: string | null; points_remaining: number })[];
  loyalty_rules: { id: string; event_key: string; points: number; daily_limit: number | null; monthly_limit: number | null; enabled: boolean; description: string | null }[];
  loyalty_levels: { id: string; name: string; min_lifetime_points: number; benefits_json: unknown[]; display_order: number; is_active: boolean }[];
  rewards: Reward[];
  reward_redemptions: { id: string; reward_id: string; user_id: string; points_spent: number; redemption_code: string; coupon_claim_id: string | null; status: 'claimed' | 'used' | 'expired' | 'cancelled'; created_at: string; redeemed_at: string | null; expires_at: string | null }[];
  achievements: { id: string; key: string; name: string; description: string | null; icon: string | null; criteria_json: Row; points_bonus: number; is_active: boolean }[];
  user_achievements: { user_id: string; achievement_id: string; earned_at: string }[];
  referral_codes: { user_id: string; code: string }[];
  referrals: { id: string; referrer_user_id: string; referred_user_id: string | null; referral_code: string; status: AdminReferral['status']; invalid_reason: string | null; registered_at: string | null; qualified_at: string | null; rewarded_at: string | null; created_at: string }[];
  business_referrals: BusinessReferral[];
  notification_preferences: (NotificationPrefs & { user_id: string })[];
  push_subscriptions: { id: string; user_id: string; endpoint: string; device_name: string | null; platform: string | null; is_active: boolean; created_at: string }[];
  campaigns: (Campaign & { created_by: string | null })[];
  campaign_deliveries: { id: string; campaign_id: string; user_id: string; channel: string; status: string; notification_id: string | null; sent_at: string | null; delivered_at: string | null; opened_at: string | null; clicked_at: string | null; error: string | null }[];
  delivery_log: string[];
  activity_days: { user_id: string; day: string }[];
  audit_logs: { admin_id: string | null; action: string; entity_type: string; entity_id: string | null; details: Row; created_at: string }[];
}

/** Valori iniziali (stessi della migrazione): regole, livelli, badge. Nessun premio o recensione inventati. */
export function engagementDefaults(): EngagementState {
  const rule = (event_key: string, points: number, daily_limit: number | null, monthly_limit: number | null, description: string) =>
    ({ id: uuid(), event_key, points, daily_limit, monthly_limit, enabled: true, description });
  const ach = (key: string, name: string, description: string, icon: string, criteria_json: Row) =>
    ({ id: uuid(), key, name, description, icon, criteria_json, points_bonus: 0, is_active: true });
  return {
    reviews: [], review_versions: [], review_responses: [], review_votes: [], review_reports: [],
    loyalty_accounts: [], loyalty_transactions: [],
    loyalty_rules: [
      rule('account_created', 50, null, null, 'Registrazione'),
      rule('profile_completed', 50, null, null, 'Profilo completo (nome e cognome, telefono, comune)'),
      rule('reservation_completed', 100, 3, 20, 'Prenotazione completata presso un ristorante'),
      rule('verified_review', 50, 3, 10, 'Recensione con visita verificata pubblicata (mai in base al voto)'),
      rule('coupon_redeemed', 20, 3, 20, 'Coupon utilizzato in cassa'),
      rule('referral_completed', 150, null, 10, 'Amico invitato che completa la prima visita'),
      rule('referral_welcome', 50, null, null, 'Benvenuto per chi si registra con un invito, dopo la prima visita'),
    ],
    loyalty_levels: [
      { id: uuid(), name: 'Explorer', min_lifetime_points: 0, benefits_json: [], display_order: 1, is_active: true },
      { id: uuid(), name: 'Foodie', min_lifetime_points: 500, benefits_json: [], display_order: 2, is_active: true },
      { id: uuid(), name: 'Insider', min_lifetime_points: 1500, benefits_json: [], display_order: 3, is_active: true },
      { id: uuid(), name: 'Master', min_lifetime_points: 4000, benefits_json: [], display_order: 4, is_active: true },
    ],
    // Solo per la modalità demo: premio dimostrativo senza valore reale, chiaramente etichettato.
    rewards: [{
      id: uuid(), title: 'Premio dimostrativo (DEMO)', description: 'Serve a provare il riscatto in modalità demo: non ha alcun valore reale.',
      points_cost: 100, reward_type: 'other', restaurant_id: null, coupon_id: null, stock: null, per_user_limit: 3,
      starts_at: new Date(0).toISOString(), ends_at: null, is_active: true, image_url: null, terms: 'Modalità demo. Nessun valore economico.',
    }],
    reward_redemptions: [],
    achievements: [
      ach('first_sushi', 'Primo sushi', 'Prima visita completata in un ristorante di sushi', '🍣', { type: 'reservations_completed', count: 1, category: 'sushi' }),
      ach('five_reservations', '5 prenotazioni', 'Cinque visite completate con AsiaFood', '🥢', { type: 'reservations_completed', count: 5 }),
      ach('food_explorer', 'Food Explorer', 'Visite completate in 3 cucine diverse', '🧭', { type: 'distinct_categories', count: 3 }),
      ach('reviewer', 'Reviewer', 'Tre recensioni pubblicate', '✍️', { type: 'reviews_published', count: 3 }),
      ach('taranto_foodie', 'Taranto Foodie', 'Cinque visite completate a Taranto', '⭐', { type: 'reservations_completed', count: 5, city: 'taranto' }),
    ],
    user_achievements: [], referral_codes: [], referrals: [], business_referrals: [], notification_preferences: [], push_subscriptions: [],
    campaigns: [], campaign_deliveries: [], delivery_log: [], activity_days: [], audit_logs: [],
  };
}

/** Accesso al database DEMO (fornito da demoSource). */
export interface EngagementAccess {
  db: {
    settings: Record<string, unknown>;
    profiles: Profile[];
    restaurants: Restaurant[];
    restaurant_members: { restaurant_id: string; user_id: string; role: string; status: string }[];
    restaurant_categories: { restaurant_id: string; category_id: string }[];
    categories: { id: string; slug: string }[];
    cities: { id: string; slug: string }[];
    favorites: { user_id: string; restaurant_id: string; created_at: string; notifications_enabled?: boolean }[];
    reservations: Reservation[];
    coupon_claims: CouponClaim[];
    coupons: Coupon[];
    offers: Offer[];
    notifications: AppNotification[];
    engagement?: EngagementState;
  };
  save(): void;
  uid(): string | null;
  isAdmin(): boolean;
  canManage(restaurantId: string): boolean;
  hasFeature(restaurantId: string, key: string): boolean;
  featureLimit(restaurantId: string, key: string): number | null;
  isPublic(restaurantId: string): boolean;
  notifyAdmins(type: string, title: string, body: string, link: string): void;
  notifyRestaurant(restaurantId: string, type: string, title: string, body: string, link: string): void;
  enqueueEmail(event: string, recipient: string | null, payload: Row): void;
  /** Coupon reale del ristorante (flusso esistente) per i premi "coupon ristorante". */
  claimCoupon(couponId: string): Promise<{ claim_code: string }>;
  /** Fase 8: ordini completati (recensione verificata, invito qualificato). */
  orders?(): { id: string; user_id: string | null; restaurant_id: string; status: string; completed_at: string | null }[];
}

class DemoError extends Error {}
const fail = (msg: string): never => {
  throw new DemoError(msg);
};

export function createEngagement(a: EngagementAccess) {
  const st = (): EngagementState => {
    if (!a.db.engagement) a.db.engagement = engagementDefaults();
    // Fase 8: regola "ordine completato" anche per i database DEMO già esistenti
    if (!a.db.engagement.loyalty_rules.some((r) => r.event_key === 'order_completed')) {
      a.db.engagement.loyalty_rules.push({ id: uuid(), event_key: 'order_completed', points: 50, daily_limit: 3, monthly_limit: 20, enabled: true, description: 'Ordine takeaway o delivery completato' });
    }
    return a.db.engagement;
  };
  const setting = <T,>(key: string, fallback: T): T => (a.db.settings[key] ?? fallback) as T;
  const flag = (key: string, fallback: boolean): boolean => {
    const v = a.db.settings[key];
    return typeof v === 'boolean' ? v : fallback;
  };
  const numSetting = (key: string, fallback: number) => {
    const v = a.db.settings[key];
    return typeof v === 'number' ? v : fallback;
  };
  const programName = () => String(setting('loyalty_program_name', 'AsiaPoints'));
  const need = () => a.uid() ?? fail('Accedi per continuare.');
  const profile = (id: string | null) => a.db.profiles.find((p) => p.id === id);
  const restaurant = (id: string) => a.db.restaurants.find((r) => r.id === id);

  const displayName = (id: string | null) => {
    const p = profile(id);
    if (!p) return null;
    if (p.display_name?.trim()) return p.display_name.trim();
    const parts = (p.full_name ?? '').trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return 'Utente';
    return parts[1] ? `${parts[0]} ${parts[1][0]!.toUpperCase()}.` : parts[0]!;
  };
  const insider = (user: string, rid: string) =>
    a.db.restaurant_members.some((m) => m.restaurant_id === rid && m.user_id === user) || restaurant(rid)?.owner_id === user || restaurant(rid)?.claimed_by === user;

  // ─── Attività, audit ───────────────────────────────────────
  const touch = (user: string | null) => {
    if (!user) return;
    const day = romeDate();
    if (!st().activity_days.some((x) => x.user_id === user && x.day === day)) st().activity_days.push({ user_id: user, day });
  };
  const audit = (action: string, entity_type: string, entity_id: string | null, details: Row = {}) =>
    st().audit_logs.push({ admin_id: a.uid(), action, entity_type, entity_id, details, created_at: now() });

  // ─── Notifiche ─────────────────────────────────────────────
  const prefs = (user: string) => {
    let p = st().notification_preferences.find((x) => x.user_id === user);
    if (!p) {
      p = { ...DEFAULT_PREFS, user_id: user, marketing: !!profile(user)?.marketing_opt_in };
      st().notification_preferences.push(p);
    }
    return p;
  };
  let pushLocal: ((title: string, body: string, url: string | null) => void) | null = null;

  function notifyUser(user: string | null, type: string, title: string, body: string, link: string | null, o: { pref?: keyof NotificationPrefs; dedupe?: string; meta?: Row; restaurant?: string | null; email?: string; emailPayload?: Row } = {}) {
    if (!user || profile(user)?.is_blocked) return null;
    if (o.dedupe) {
      if (st().delivery_log.includes(o.dedupe)) return null;
      st().delivery_log.push(o.dedupe);
    }
    const p = prefs(user);
    if (o.pref && !p[o.pref]) return null;
    const n: AppNotification = { id: uuid(), user_id: user, restaurant_id: o.restaurant ?? null, type, title: title.slice(0, 140), body: body.slice(0, 500), link, read_at: null, created_at: now(), metadata: o.meta ?? {} };
    a.db.notifications.unshift(n);
    if (p.push_enabled && st().push_subscriptions.some((s) => s.user_id === user && s.is_active) && user === a.uid()) pushLocal?.(n.title, n.body ?? '', link);
    if (o.email && p.email_enabled) a.enqueueEmail(o.email, profile(user)?.email ?? null, { ...(o.emailPayload ?? {}), title, body, link });
    return n.id;
  }

  // ─── AsiaPoints ────────────────────────────────────────────
  const levelFor = (lifetime: number) =>
    [...st().loyalty_levels].filter((l) => l.is_active && l.min_lifetime_points <= lifetime).sort((x, y) => y.min_lifetime_points - x.min_lifetime_points)[0]?.name ?? 'Explorer';
  const account = (user: string) => {
    let acc = st().loyalty_accounts.find((x) => x.user_id === user);
    if (!acc) {
      acc = { user_id: user, points_balance: 0, lifetime_points: 0, level: 'Explorer', created_at: now() };
      st().loyalty_accounts.push(acc);
    }
    return acc;
  };
  const startOfDay = () => new Date(`${romeDate()}T00:00:00`).getTime();
  const startOfMonth = () => new Date(`${romeDate().slice(0, 7)}-01T00:00:00`).getTime();

  function award(user: string | null, event: string, source_type: string, source_id: string | null, description: string, points?: number) {
    if (!user || !flag('loyalty_enabled', true) || profile(user)?.is_blocked) return 0;
    let pts = points ?? 0;
    if (points === undefined) {
      const r = st().loyalty_rules.find((x) => x.event_key === event);
      if (!r || !r.enabled) return 0;
      pts = r.points;
      const mine = st().loyalty_transactions.filter((t) => t.user_id === user && t.event_key === event);
      if (r.daily_limit != null && mine.filter((t) => Date.parse(t.created_at) >= startOfDay()).length >= r.daily_limit) return 0;
      if (r.monthly_limit != null && mine.filter((t) => Date.parse(t.created_at) >= startOfMonth()).length >= r.monthly_limit) return 0;
    }
    if (pts <= 0) return 0;
    if (source_id && st().loyalty_transactions.some((t) => t.user_id === user && t.event_key === event && t.source_type === source_type && t.source_id === source_id)) return 0;
    const acc = account(user);
    const months = numSetting('points_expire_after_months', 0);
    acc.points_balance += pts;
    acc.lifetime_points += pts;
    acc.level = levelFor(acc.lifetime_points);
    st().loyalty_transactions.unshift({
      id: uuid(), user_id: user, type: event.startsWith('referral') ? 'referral' : source_type === 'achievement' ? 'bonus' : 'earn', points: pts,
      balance_after: acc.points_balance, event_key: event, source_type, source_id, description, created_at: now(), points_remaining: pts,
      expires_at: months > 0 ? new Date(Date.now() + months * 30 * DAY).toISOString() : null,
    });
    notifyUser(user, 'loyalty', `+${pts} ${programName()}`, description, '/profile/loyalty', { pref: 'loyalty_updates' });
    return pts;
  }
  const consume = (user: string, points: number) => {
    let left = points;
    for (const t of [...st().loyalty_transactions].filter((x) => x.user_id === user && x.points_remaining > 0).sort((x, y) => (x.expires_at ?? '9999').localeCompare(y.expires_at ?? '9999') || x.created_at.localeCompare(y.created_at))) {
      if (left <= 0) break;
      const take = Math.min(left, t.points_remaining);
      t.points_remaining -= take;
      left -= take;
    }
  };

  function checkAchievements(user: string | null) {
    if (!user) return 0;
    let n = 0;
    const completed = a.db.reservations.filter((r) => r.user_id === user && r.status === 'completed');
    const catsOf = (rid: string) => a.db.restaurant_categories.filter((rc) => rc.restaurant_id === rid).map((rc) => a.db.categories.find((c) => c.id === rc.category_id)?.slug).filter(Boolean) as string[];
    for (const ac of st().achievements.filter((x) => x.is_active && !st().user_achievements.some((u) => u.user_id === user && u.achievement_id === x.id))) {
      const c = ac.criteria_json as { type?: string; count?: number; category?: string; city?: string };
      const needN = c.count ?? 1;
      const got =
        c.type === 'reservations_completed'
          ? completed.filter((r) => (!c.category || catsOf(r.restaurant_id).includes(c.category)) && (!c.city || a.db.cities.find((ci) => ci.id === restaurant(r.restaurant_id)?.city_id)?.slug === c.city)).length
          : c.type === 'distinct_categories'
            ? new Set(completed.flatMap((r) => catsOf(r.restaurant_id)).filter((s) => s !== 'all-you-can-eat')).size
            : c.type === 'reviews_published'
              ? st().reviews.filter((r) => r.user_id === user && r.status === 'published').length
              : c.type === 'coupons_redeemed'
                ? a.db.coupon_claims.filter((x) => x.user_id === user && x.status === 'redeemed').length
                : 0;
      if (got >= needN) {
        st().user_achievements.push({ user_id: user, achievement_id: ac.id, earned_at: now() });
        n++;
        notifyUser(user, 'loyalty', `Nuovo badge: ${ac.name}`, ac.description ?? '', '/profile/loyalty', { pref: 'loyalty_updates', dedupe: `achievement:${ac.id}:${user}` });
        if (ac.points_bonus > 0) award(user, 'achievement_bonus', 'achievement', ac.id, `Badge: ${ac.name}`, ac.points_bonus);
      }
    }
    return n;
  }

  // ─── Referral ──────────────────────────────────────────────
  const genCode = (len: number) => Array.from({ length: len }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
  const ensureCode = (user: string) => {
    let c = st().referral_codes.find((x) => x.user_id === user);
    if (!c) {
      let code = '';
      do code = `${genCode(4)}-${genCode(4)}`;
      while (st().referral_codes.some((x) => x.code === code));
      c = { user_id: user, code };
      st().referral_codes.push(c);
    }
    return c.code;
  };
  function referralQualify(user: string, force = false) {
    const x = st().referrals.find((r) => r.referred_user_id === user && r.status === 'registered');
    if (!x) return false;
    // In DEMO non c'è verifica email reale: gli account di prova sono considerati verificati
    const action = a.db.reservations.some((r) => r.user_id === user && r.status === 'completed') || a.db.coupon_claims.some((c) => c.user_id === user && c.status === 'redeemed')
      || (a.orders?.() ?? []).some((o) => o.user_id === user && ['completed', 'partially_refunded'].includes(o.status));
    if (!force && !action) return false;
    x.status = 'qualified';
    x.qualified_at = now();
    const p1 = award(x.referrer_user_id, 'referral_completed', 'referral', x.id, 'Amico invitato: prima visita completata');
    award(user, 'referral_welcome', 'referral', x.id, 'Bonus di benvenuto per l’invito');
    x.status = 'rewarded';
    x.rewarded_at = now();
    notifyUser(x.referrer_user_id, 'referral', 'Invito completato', p1 > 0 ? `Il tuo amico ha completato la prima visita: +${p1} punti.` : 'Il tuo amico ha completato la prima visita.', '/profile/referrals', { pref: 'referral_updates', dedupe: `referral_done:${x.id}`, email: 'referral_completed' });
    return true;
  }

  // ─── Recensioni ────────────────────────────────────────────
  const reviewFlags = (text: string) => {
    const f: string[] = [];
    if (/(https?:\/\/|www\.[a-z0-9-]+\.)/i.test(text)) f.push('link');
    if (/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i.test(text)) f.push('email');
    if (/\+?[0-9][0-9 .-]{8,}[0-9]/.test(text)) f.push('phone');
    return f;
  };
  const verificationFor = (user: string, rid: string, reservationId?: string | null) => {
    const days = numSetting('review_verification_window_days', 180);
    const since = new Date(Date.now() - days * DAY).toISOString().slice(0, 10);
    const res = a.db.reservations
      .filter((r) => r.user_id === user && r.restaurant_id === rid && r.status === 'completed' && (!reservationId || r.id === reservationId) && r.reservation_date >= since && !st().reviews.some((v) => v.reservation_id === r.id))
      .sort((x, y) => y.reservation_date.localeCompare(x.reservation_date))[0];
    if (res) return { source: 'reservation' as const, id: res.id, date: res.reservation_date };
    if (reservationId) return null;
    const ord = (a.orders?.() ?? [])
      .filter((o) => o.user_id === user && o.restaurant_id === rid && ['completed', 'partially_refunded'].includes(o.status) && o.completed_at && Date.parse(o.completed_at) >= Date.now() - days * DAY && !st().reviews.some((v) => v.order_id === o.id))
      .sort((x, y) => (y.completed_at ?? '').localeCompare(x.completed_at ?? ''))[0];
    if (ord) return { source: 'order' as const, id: ord.id, date: (ord.completed_at ?? '').slice(0, 10) };
    const cl = a.db.coupon_claims
      .filter((c) => c.user_id === user && c.restaurant_id === rid && c.status === 'redeemed' && c.redeemed_at && Date.parse(c.redeemed_at) >= Date.now() - days * DAY && !st().reviews.some((v) => v.coupon_claim_id === c.id))
      .sort((x, y) => (y.redeemed_at ?? '').localeCompare(x.redeemed_at ?? ''))[0];
    if (cl) return { source: 'coupon' as const, id: cl.id, date: (cl.redeemed_at ?? '').slice(0, 10) };
    return null;
  };
  const recentOwn = (user: string, rid: string) =>
    st().reviews.find((v) => v.user_id === user && v.restaurant_id === rid && ['published', 'pending', 'flagged'].includes(v.status) && Date.parse(v.created_at) > Date.now() - numSetting('review_cooldown_days', 90) * DAY);
  const rating = (v: unknown, required: boolean) => {
    if (v === null || v === undefined || v === '') {
      if (required) fail('La valutazione generale è obbligatoria.');
      return null;
    }
    const n = Number(v);
    if (!Number.isInteger(n) || n < 1 || n > 5) fail('Valutazione non valida (1–5).');
    return n;
  };
  function afterPublish(v: DemoReview) {
    if (v.is_verified) award(v.user_id, 'verified_review', 'review', v.id, 'Recensione verificata pubblicata');
    checkAchievements(v.user_id);
    a.notifyRestaurant(v.restaurant_id, 'review', 'Nuova recensione', `${v.rating_overall}/5${v.is_verified ? ' · visita verificata' : ''}`, `/dashboard/restaurants/${v.restaurant_id}/reviews`);
  }
  const ratingOf = (rid: string): RestaurantRating => {
    const list = st().reviews.filter((v) => v.restaurant_id === rid && v.status === 'published');
    const avg = (k: keyof DemoReview) => {
      const xs = list.map((v) => v[k]).filter((x): x is number => typeof x === 'number');
      return xs.length ? Math.round((xs.reduce((s, x) => s + x, 0) / xs.length) * 10) / 10 : null;
    };
    const dist = { '1': 0, '2': 0, '3': 0, '4': 0, '5': 0 } as RestaurantRating['distribution'];
    list.forEach((v) => (dist[String(v.rating_overall) as '1'] += 1));
    return { count: list.length, average: avg('rating_overall'), verified_count: list.filter((v) => v.is_verified).length, distribution: dist, food: avg('rating_food'), service: avg('rating_service'), value: avg('rating_value'), atmosphere: avg('rating_atmosphere') };
  };
  const responseOf = (id: string) => {
    const r = st().review_responses.find((x) => x.review_id === id && x.status === 'published');
    return r ? { content: r.content, updated_at: r.updated_at } : null;
  };

  // ─── Campagne ──────────────────────────────────────────────
  function audience(scope: 'platform' | 'restaurant', rid: string | null, target: CampaignTarget, targeting: Record<string, string> = {}) {
    const ids = new Set<string>();
    const today = romeDate();
    if (scope === 'restaurant' && rid) {
      if (target === 'followers' || target === 'all_eligible') a.db.favorites.filter((f) => f.restaurant_id === rid && f.notifications_enabled).forEach((f) => ids.add(f.user_id));
      if (target === 'coupon_users' || target === 'all_eligible') a.db.coupon_claims.filter((c) => c.restaurant_id === rid && c.user_id).forEach((c) => ids.add(c.user_id!));
      if (target === 'past_customers' || target === 'all_eligible') a.db.reservations.filter((r) => r.restaurant_id === rid && r.user_id && r.status === 'completed').forEach((r) => ids.add(r.user_id!));
    } else {
      if (target === 'all_users') a.db.profiles.forEach((p) => ids.add(p.id));
      if (target === 'city') {
        const c = a.db.cities.find((x) => x.slug === targeting.city_slug);
        a.db.profiles.filter((p) => c && p.city_id === c.id).forEach((p) => ids.add(p.id));
      }
      if (target === 'favorite_category') {
        const k = a.db.categories.find((x) => x.slug === targeting.category_slug);
        a.db.favorites.filter((f) => k && a.db.restaurant_categories.some((rc) => rc.restaurant_id === f.restaurant_id && rc.category_id === k.id)).forEach((f) => ids.add(f.user_id));
      }
      if (target === 'upcoming_reservation') {
        const to = new Date(Date.now() + 7 * DAY).toISOString().slice(0, 10);
        a.db.reservations.filter((r) => r.user_id && ['pending', 'confirmed'].includes(r.status) && r.reservation_date >= today && r.reservation_date <= to).forEach((r) => ids.add(r.user_id!));
      }
      if (target === 'active_users') {
        const from = new Date(Date.now() - 30 * DAY).toISOString().slice(0, 10);
        st().activity_days.filter((d) => d.day >= from).forEach((d) => ids.add(d.user_id));
      }
      if (target === 'loyalty_level') st().loyalty_accounts.filter((x) => x.level === targeting.level).forEach((x) => ids.add(x.user_id));
    }
    return [...ids].filter((u) => {
      const p = profile(u);
      if (!p || p.is_blocked) return false;
      if (scope === 'restaurant' && rid && insider(u, rid)) return false;
      const pr = prefs(u);
      return pr.marketing || (scope === 'restaurant' && pr.favorite_restaurants && a.db.favorites.some((f) => f.user_id === u && f.restaurant_id === rid && f.notifications_enabled));
    });
  }
  function dispatch(c: Campaign & { created_by: string | null }) {
    if (c.status !== 'scheduled' || Date.parse(c.send_at) > Date.now()) return 0;
    if (c.scope === 'restaurant' && c.restaurant_id && !a.hasFeature(c.restaurant_id, 'push_campaigns_enabled')) {
      Object.assign(c, { status: 'failed', error: 'Funzione non inclusa nel piano attuale' });
      return 0;
    }
    const cap = numSetting('campaign_max_per_user_week', 3);
    let n = 0;
    for (const u of audience(c.scope, c.restaurant_id, c.target, c.targeting).slice(0, numSetting('campaign_max_recipients', 5000))) {
      const recent = new Set(st().campaign_deliveries.filter((d) => d.user_id === u && ['sent', 'delivered', 'queued'].includes(d.status) && d.sent_at && Date.parse(d.sent_at) > Date.now() - 7 * DAY).map((d) => d.campaign_id));
      if (recent.size >= cap) {
        st().campaign_deliveries.push({ id: uuid(), campaign_id: c.id, user_id: u, channel: c.channels[0]!, status: 'skipped', notification_id: null, sent_at: null, delivered_at: null, opened_at: null, clicked_at: null, error: 'frequency_cap' });
        continue;
      }
      const pr = prefs(u);
      for (const ch of c.channels) {
        const d = { id: uuid(), campaign_id: c.id, user_id: u, channel: ch, status: 'queued', notification_id: null as string | null, sent_at: now(), delivered_at: null as string | null, opened_at: null, clicked_at: null, error: null as string | null };
        const link = `${c.action_url ?? '/'}${(c.action_url ?? '/').includes('?') ? '&' : '?'}cd=${d.id}`;
        if (ch === 'in_app') {
          const nt: AppNotification = { id: uuid(), user_id: u, restaurant_id: c.restaurant_id, type: 'promotion', title: c.title, body: c.message, link, read_at: null, created_at: now(), metadata: { campaign_id: c.id, delivery_id: d.id } };
          a.db.notifications.unshift(nt);
          Object.assign(d, { status: 'delivered', notification_id: nt.id, delivered_at: now() });
        } else if (ch === 'push') {
          if (pr.push_enabled && st().push_subscriptions.some((s) => s.user_id === u && s.is_active)) {
            // In DEMO il "push service" è il browser stesso: accettata ma consegna non confermata
            d.status = 'sent';
            if (u === a.uid()) pushLocal?.(c.title, c.message, link);
          } else Object.assign(d, { status: 'skipped', error: 'no_push_subscription' });
        } else if (ch === 'email') {
          if (pr.email_enabled) {
            a.enqueueEmail('marketing_campaign', profile(u)?.email ?? null, { title: c.title, body: c.message, link });
            d.status = 'sent';
          } else Object.assign(d, { status: 'skipped', error: 'email_disabled' });
        }
        st().campaign_deliveries.push(d);
      }
      n++;
    }
    Object.assign(c, { status: 'sent', sent_at: now(), recipients_count: n });
    return n;
  }

  // ─── Scheduler ─────────────────────────────────────────────
  function tick(at = new Date()): EngagementTickResult {
    const out: EngagementTickResult = { reservation_reminders: 0, guest_reminders: 0, coupon_reminders: 0, review_requests: 0, referrals_qualified: 0, campaigns: 0, points_expired: 0 };
    const hours = ((setting('reservation_reminder_hours', [24, 2]) as number[]) ?? [24, 2]).filter((h) => h >= 1 && h <= 168).sort((x, y) => y - x);
    const today = romeDate(at);
    const tomorrow = romeDate(new Date(at.getTime() + DAY));
    for (const x of a.db.reservations.filter((r) => ['pending', 'confirmed'].includes(r.status))) {
      const start = new Date(`${x.reservation_date}T${x.reservation_time.slice(0, 5)}:00`).getTime();
      const r = restaurant(x.restaurant_id);
      hours.forEach((h, i) => {
        const next = hours[i + 1] ?? 0;
        const diff = start - at.getTime();
        if (!(diff <= h * 3600_000 && diff > next * 3600_000)) return;
        const when = x.reservation_date === today ? 'Oggi' : x.reservation_date === tomorrow ? 'Domani' : `Il ${x.reservation_date.slice(8)}/${x.reservation_date.slice(5, 7)}`;
        const text = `${when} alle ${x.reservation_time.slice(0, 5)} hai una prenotazione da ${r?.name ?? 'un ristorante'}.${x.status === 'pending' ? ' È ancora in attesa di conferma.' : ''}`;
        if (x.user_id) {
          if (notifyUser(x.user_id, 'reservation', 'Promemoria prenotazione', text, '/dashboard/reservations', { pref: 'reservation_reminders', dedupe: `reservation_reminder:${h}:${x.id}`, restaurant: x.restaurant_id, email: i === 0 ? 'reservation_reminder' : undefined, emailPayload: { code: x.confirmation_code } })) out.reservation_reminders++;
        } else if (i === 0 && x.guest_email && !st().delivery_log.includes(`reservation_reminder:${h}:${x.id}`)) {
          st().delivery_log.push(`reservation_reminder:${h}:${x.id}`);
          a.enqueueEmail('reservation_reminder', x.guest_email, { body: text, code: x.confirmation_code });
          out.guest_reminders++;
        }
      });
    }
    const cpnH = numSetting('coupon_expiry_reminder_hours', 24);
    for (const cl of a.db.coupon_claims.filter((c) => c.status === 'claimed' && c.user_id)) {
      const c = a.db.coupons.find((y) => y.id === cl.coupon_id);
      if (!c?.is_active || !c.valid_until) continue;
      const until = Date.parse(c.valid_until);
      if (!(until > at.getTime() && until <= at.getTime() + cpnH * 3600_000)) continue;
      const r = restaurant(cl.restaurant_id);
      const text = `Il tuo coupon “${c.title}” di ${r?.name ?? ''} scade ${romeDate(new Date(until)) === today ? `oggi alle ${new Date(until).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Rome' })}` : 'domani'}.`;
      if (notifyUser(cl.user_id, 'coupon', 'Coupon in scadenza', text, '/dashboard/coupons', { pref: 'coupon_expiry', dedupe: `coupon_expiry:${cl.id}`, restaurant: cl.restaurant_id, email: 'coupon_expiring' })) out.coupon_reminders++;
    }
    const delay = numSetting('review_request_delay_hours', 2) * 3600_000;
    for (const x of a.db.reservations.filter((r) => r.status === 'completed' && r.user_id && r.completed_at)) {
      const done = Date.parse(x.completed_at!);
      if (done > at.getTime() - delay || done < at.getTime() - 14 * DAY) continue;
      if (st().reviews.some((v) => v.reservation_id === x.id) || recentOwn(x.user_id!, x.restaurant_id) || insider(x.user_id!, x.restaurant_id)) continue;
      const r = restaurant(x.restaurant_id);
      if (notifyUser(x.user_id, 'review', `Com’è andata da ${r?.name}?`, 'Racconta la tua esperienza: la tua recensione aiuta altre persone a scegliere.', `/ristorante/${r?.slug}?review=1#recensioni`, { pref: 'reservation_updates', dedupe: `review_request:${x.id}`, restaurant: x.restaurant_id, email: 'review_request' })) out.review_requests++;
    }
    for (const r of st().referrals.filter((x) => x.status === 'registered' && x.referred_user_id)) if (referralQualify(r.referred_user_id!)) out.referrals_qualified++;
    for (const c of st().campaigns.filter((x) => x.status === 'scheduled' && Date.parse(x.send_at) <= at.getTime())) {
      dispatch(c);
      out.campaigns++;
    }
    for (const t of st().loyalty_transactions.filter((x) => x.points_remaining > 0 && x.expires_at && Date.parse(x.expires_at) <= at.getTime())) {
      const acc = account(t.user_id);
      const take = Math.min(t.points_remaining, acc.points_balance);
      t.points_remaining = 0;
      if (take > 0) {
        acc.points_balance -= take;
        st().loyalty_transactions.unshift({ id: uuid(), user_id: t.user_id, type: 'expire', points: -take, balance_after: acc.points_balance, event_key: 'points_expired', source_type: 'other', source_id: t.id, description: 'Punti scaduti', created_at: now(), expires_at: null, points_remaining: 0 });
        out.points_expired++;
      }
    }
    st().reward_redemptions.filter((x) => x.status === 'claimed' && x.expires_at && Date.parse(x.expires_at) <= at.getTime()).forEach((x) => (x.status = 'expired'));
    a.save();
    return out;
  }

  // ═══════════════════════════════════════════════════════════
  return {
    tick,
    /** Codice invito personale (creato se manca), usato anche dal programma Ambassador. */
    ensureReferralCode: ensureCode,
    /** Dispatcher notifiche (in-app + push locale + email secondo preferenze), usato anche dagli ordini DEMO. */
    notify: notifyUser,
    setPushLocal(fn: typeof pushLocal) {
      pushLocal = fn;
    },

    // ─── Hook dagli eventi reali del database DEMO ──────────
    hooks: {
      profileCreated(p: Profile) {
        account(p.id);
        prefs(p.id);
        ensureCode(p.id);
        award(p.id, 'account_created', 'profile', p.id, 'Benvenuto in AsiaFood');
        a.save();
      },
      profileUpdated(p: Profile) {
        if ((p.full_name ?? '').trim().split(/\s+/).length >= 2 && p.phone?.trim() && p.city_id) award(p.id, 'profile_completed', 'profile', p.id, 'Profilo completato');
        a.save();
      },
      reservationCreated(x: Reservation) {
        touch(x.user_id);
      },
      reservationStatus(x: Reservation, prev: string) {
        if (!x.user_id || x.status === prev) return;
        const r = restaurant(x.restaurant_id);
        const when = `${x.reservation_date.slice(8)}/${x.reservation_date.slice(5, 7)} alle ${x.reservation_time.slice(0, 5)}`;
        if (x.status === 'completed') {
          x.completed_at = now();
          award(x.user_id, 'reservation_completed', 'reservation', x.id, `Visita da ${r?.name ?? ''}`);
          referralQualify(x.user_id);
          checkAchievements(x.user_id);
        } else if (x.status === 'confirmed' || x.status === 'rejected') {
          notifyUser(x.user_id, 'reservation', x.status === 'confirmed' ? 'Prenotazione confermata' : 'Prenotazione non accettata', `${r?.name} · ${when}`, '/dashboard/reservations', { pref: 'reservation_updates', dedupe: `reservation_status:${x.id}:${x.status}`, restaurant: x.restaurant_id });
        } else if (x.status === 'cancelled' && a.uid() !== x.user_id) {
          notifyUser(x.user_id, 'reservation', 'Prenotazione cancellata dal ristorante', `${r?.name} · ${when}`, '/dashboard/reservations', { pref: 'reservation_updates', dedupe: `reservation_status:${x.id}:cancelled`, restaurant: x.restaurant_id });
        }
        a.save();
      },
      couponClaimed(c: CouponClaim) {
        touch(c.user_id);
      },
      couponRedeemed(c: CouponClaim) {
        if (!c.user_id) return;
        const cp = a.db.coupons.find((x) => x.id === c.coupon_id);
        award(c.user_id, 'coupon_redeemed', 'coupon', c.id, `Coupon utilizzato: ${cp?.title ?? ''}`);
        referralQualify(c.user_id);
        checkAchievements(c.user_id);
        a.save();
      },
      /** Fase 8: ordine completato → punti, invito qualificato, badge, richiesta di recensione (max 1 ogni 7 giorni). */
      orderCompleted(o: { id: string; user_id: string | null; restaurant_id: string }) {
        if (!o.user_id) return;
        const r = restaurant(o.restaurant_id);
        award(o.user_id, 'order_completed', 'order', o.id, `Ordine completato da ${r?.name ?? ''}`);
        referralQualify(o.user_id);
        checkAchievements(o.user_id);
        touch(o.user_id);
        const recentAsk = a.db.notifications.some((n) => n.user_id === o.user_id && n.restaurant_id === o.restaurant_id && n.type === 'review' && Date.parse(n.created_at) > Date.now() - 7 * DAY);
        if (r && !insider(o.user_id, o.restaurant_id) && !recentOwn(o.user_id, o.restaurant_id) && !recentAsk) {
          notifyUser(o.user_id, 'review', `Com’è andato il tuo ordine da ${r.name}?`, 'Racconta la tua esperienza: la tua recensione aiuta altre persone a scegliere.',
            `/ristorante/${r.slug}?review=1#recensioni`, { pref: 'reservation_updates', dedupe: `review_request_order:${o.id}`, restaurant: r.id, email: 'review_request', emailPayload: { restaurant: r.name, restaurant_slug: r.slug } });
        }
        a.save();
      },
      offerActivated(kind: 'offer' | 'coupon', restaurantId: string, title: string) {
        const r = restaurant(restaurantId);
        if (!r || !a.isPublic(restaurantId)) return;
        const day = romeDate().replace(/-/g, '');
        a.db.favorites.filter((f) => f.restaurant_id === restaurantId && f.notifications_enabled).forEach((f) =>
          notifyUser(f.user_id, 'restaurant', `${kind === 'offer' ? 'Nuova offerta' : 'Nuovo coupon'} da ${r.name}`, title, `/ristorante/${r.slug}#offerte`, { pref: 'favorite_restaurants', dedupe: `follow:${restaurantId}:${f.user_id}:${day}`, restaurant: restaurantId }),
        );
        a.save();
      },
    },

    // ─── Recensioni ─────────────────────────────────────────
    getRestaurantRating: (rid: string) => ratingOf(rid),
    getRestaurantsRating(ids: string[]) {
      const out: Record<string, { average: number; count: number }> = {};
      ids.forEach((id) => {
        const r = ratingOf(id);
        if (r.count) out[id] = { average: r.average!, count: r.count };
      });
      return out;
    },
    listReviews(rid: string, o: { sort?: ReviewSort; filter?: ReviewFilter; limit?: number; offset?: number } = {}) {
      const uid = a.uid();
      let list = st().reviews.filter((v) => v.restaurant_id === rid && v.status === 'published');
      if (o.filter === 'verified') list = list.filter((v) => v.is_verified);
      else if (o.filter) list = list.filter((v) => v.rating_overall === Number(o.filter));
      list = [...list].sort((x, y) =>
        (o.sort === 'helpful' ? y.helpful_count - x.helpful_count : 0) ||
        (o.sort === 'high' ? y.rating_overall - x.rating_overall : 0) ||
        (o.sort === 'low' ? x.rating_overall - y.rating_overall : 0) ||
        (y.published_at ?? '').localeCompare(x.published_at ?? ''));
      const off = Math.max(o.offset ?? 0, 0);
      const lim = Math.min(Math.max(o.limit ?? 10, 1), 20);
      const items: ReviewItem[] = list.slice(off, off + lim).map((v) => ({
        id: v.id, author: displayName(v.user_id) ?? 'Utente', is_verified: v.is_verified, verification_source: v.verification_source,
        rating_overall: v.rating_overall, rating_food: v.rating_food, rating_service: v.rating_service, rating_value: v.rating_value, rating_atmosphere: v.rating_atmosphere,
        title: v.title, content: v.content, is_edited: v.is_edited, helpful_count: v.helpful_count, published_at: v.published_at, created_at: v.created_at,
        is_mine: v.user_id === uid, my_vote: st().review_votes.some((x) => x.review_id === v.id && x.user_id === uid), response: responseOf(v.id),
      }));
      return { total: list.length, items };
    },
    getReviewFormStatus(rid: string): ReviewFormStatus {
      const uid = a.uid();
      if (!uid) return { authenticated: false };
      const ex = recentOwn(uid, rid);
      const ver = verificationFor(uid, rid);
      return {
        authenticated: true,
        blocked: insider(uid, rid) ? 'insider' : profile(uid)?.is_blocked ? 'blocked' : ex ? 'cooldown' : !ver && !flag('allow_unverified_reviews', true) ? 'unverified_not_allowed' : null,
        verification: ver, allow_unverified: flag('allow_unverified_reviews', true), cooldown_days: numSetting('review_cooldown_days', 90),
        min_length: numSetting('review_min_length', 20), display_name: displayName(uid) ?? 'Utente',
        existing: ex ? { id: ex.id, status: ex.status, is_verified: ex.is_verified, created_at: ex.created_at, rating_overall: ex.rating_overall, rating_food: ex.rating_food, rating_service: ex.rating_service, rating_value: ex.rating_value, rating_atmosphere: ex.rating_atmosphere, title: ex.title, content: ex.content } : null,
      };
    },
    submitReview(rid: string, input: ReviewInput) {
      const uid = need();
      if (profile(uid)?.is_blocked) fail('Account non abilitato.');
      if (!a.isPublic(rid)) fail('Ristorante non trovato.');
      if (insider(uid, rid)) fail('Chi gestisce o lavora nel ristorante non può recensirlo.');
      const content = (input.content ?? '').trim();
      const title = input.title?.trim() || null;
      const min = numSetting('review_min_length', 20);
      if (content.length < min) fail(`La recensione deve avere almeno ${min} caratteri.`);
      if (content.length > 2000) fail('Massimo 2000 caratteri.');
      if (title && title.length > 100) fail('Titolo troppo lungo (max 100).');
      const overall = rating(input.rating_overall, true)!;
      if (recentOwn(uid, rid)) fail('Hai già recensito questo ristorante di recente: puoi modificare la tua recensione.');
      if (st().reviews.filter((v) => v.user_id === uid && Date.parse(v.created_at) > Date.now() - DAY).length >= numSetting('review_daily_limit', 5)) fail('Hai raggiunto il numero massimo di recensioni per oggi.');
      const ver = verificationFor(uid, rid, input.reservation_id);
      if (!ver && !flag('allow_unverified_reviews', true)) fail('Puoi recensire dopo una visita verificata (prenotazione completata o coupon utilizzato).');
      const flags = reviewFlags(`${title ?? ''} ${content}`);
      const status: ReviewStatus = flags.length ? 'pending' : ver ? (flag('auto_publish_verified_reviews', true) ? 'published' : 'pending') : flag('auto_publish_unverified_reviews', false) ? 'published' : 'pending';
      const v: DemoReview = {
        id: uuid(), restaurant_id: rid, user_id: uid, reservation_id: ver?.source === 'reservation' ? ver.id : null, coupon_claim_id: ver?.source === 'coupon' ? ver.id : null,
        order_id: ver?.source === 'order' ? ver.id : null,
        rating_overall: overall, rating_food: rating(input.rating_food, false), rating_service: rating(input.rating_service, false), rating_value: rating(input.rating_value, false),
        rating_atmosphere: rating(input.rating_atmosphere, false), title, content, is_verified: !!ver, verification_source: ver?.source ?? null, status, moderation_flags: flags,
        moderation_note: null, is_edited: false, helpful_count: 0, restaurant_response_count: 0, created_at: now(), updated_at: now(), published_at: status === 'published' ? now() : null,
        moderated_at: null, moderated_by: null,
      };
      st().reviews.unshift(v);
      touch(uid);
      if (status === 'published') afterPublish(v);
      else a.notifyAdmins('review_pending', 'Recensione da moderare', content.slice(0, 120), '/admin/reviews');
      a.save();
      return { id: v.id, status, is_verified: !!ver };
    },
    updateReview(id: string, input: ReviewInput) {
      const uid = need();
      const v = st().reviews.find((x) => x.id === id && x.user_id === uid) ?? fail('Recensione non trovata.');
      if (v.status === 'rejected' || v.status === 'hidden') fail('Questa recensione non è più modificabile.');
      const content = (input.content ?? '').trim();
      const min = numSetting('review_min_length', 20);
      if (content.length < min || content.length > 2000) fail(`La recensione deve avere tra ${min} e 2000 caratteri.`);
      if (st().review_versions.filter((x) => x.review_id === id).length >= 10) fail('Hai raggiunto il numero massimo di modifiche.');
      st().review_versions.push({ id: uuid(), review_id: id, previous_title: v.title, previous_content: v.content, previous_rating: v.rating_overall, created_at: now() });
      const flags = reviewFlags(`${input.title ?? ''} ${content}`);
      Object.assign(v, {
        rating_overall: rating(input.rating_overall, true), rating_food: rating(input.rating_food, false), rating_service: rating(input.rating_service, false),
        rating_value: rating(input.rating_value, false), rating_atmosphere: rating(input.rating_atmosphere, false), title: input.title?.trim() || null, content,
        is_edited: true, status: flags.length ? 'pending' : v.status, moderation_flags: flags, updated_at: now(),
      });
      a.save();
      return { id, status: v.status };
    },
    voteReview(id: string, on: boolean) {
      const uid = need();
      const v = st().reviews.find((x) => x.id === id && x.status === 'published') ?? fail('Recensione non trovata.');
      if (v.user_id === uid) fail('Non puoi votare la tua recensione.');
      const has = st().review_votes.some((x) => x.review_id === id && x.user_id === uid);
      if (on && !has) st().review_votes.push({ review_id: id, user_id: uid, created_at: now() });
      if (!on) st().review_votes = st().review_votes.filter((x) => !(x.review_id === id && x.user_id === uid));
      v.helpful_count = st().review_votes.filter((x) => x.review_id === id).length;
      a.save();
      return v.helpful_count;
    },
    reportReview(id: string, reason: ReviewReportReason, details?: string | null) {
      const uid = need();
      const v = st().reviews.find((x) => x.id === id && (x.status === 'published' || x.status === 'flagged')) ?? fail('Recensione non trovata.');
      if (v.user_id === uid) fail('Non puoi segnalare la tua recensione.');
      if (st().review_reports.filter((x) => x.reporter_user_id === uid && Date.parse(x.created_at) > Date.now() - DAY).length >= 10) fail('Troppe segnalazioni in poco tempo.');
      if (!st().review_reports.some((x) => x.review_id === id && x.reporter_user_id === uid)) {
        st().review_reports.push({ id: uuid(), review_id: id, reporter_user_id: uid, reason, details: details?.trim().slice(0, 500) || null, status: 'open', created_at: now(), reviewed_at: null });
      }
      if (v.status === 'published' && st().review_reports.filter((x) => x.review_id === id && x.status === 'open').length >= numSetting('review_flag_threshold', 3)) {
        v.status = 'flagged';
        a.notifyAdmins('review_flagged', 'Recensione segnalata più volte', v.content.slice(0, 120), '/admin/reviews');
      }
      a.save();
    },
    respondToReview(reviewId: string, content: string) {
      const v = st().reviews.find((x) => x.id === reviewId && (x.status === 'published' || x.status === 'flagged')) ?? fail('Recensione non trovata.');
      if (!a.canManage(v.restaurant_id)) fail('Operazione non consentita.');
      const text = content.trim();
      if (text.length < 2 || text.length > 1000) fail('La risposta deve avere tra 2 e 1000 caratteri.');
      const ex = st().review_responses.find((x) => x.review_id === reviewId);
      if (ex) Object.assign(ex, { content: text, updated_at: now(), status: 'published', user_id: a.uid() });
      else st().review_responses.push({ id: uuid(), review_id: reviewId, restaurant_id: v.restaurant_id, user_id: a.uid(), content: text, status: 'published', created_at: now(), updated_at: now() });
      v.restaurant_response_count = 1;
      const r = restaurant(v.restaurant_id);
      notifyUser(v.user_id, 'review', 'Il ristorante ha risposto alla tua recensione', r?.name ?? '', `/ristorante/${r?.slug}#recensioni`, { dedupe: `review_response:${v.id}:${romeDate()}`, restaurant: v.restaurant_id });
      a.save();
    },
    listManagedReviews(rid: string) {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      const uid = a.uid();
      const items: ManagedReview[] = st().reviews.filter((v) => v.restaurant_id === rid && (v.status === 'published' || v.status === 'flagged')).map((v) => ({
        id: v.id, author: displayName(v.user_id) ?? 'Utente', is_verified: v.is_verified, rating_overall: v.rating_overall, title: v.title, content: v.content,
        status: v.status, is_edited: v.is_edited, published_at: v.published_at, helpful_count: v.helpful_count,
        my_report: st().review_reports.some((x) => x.review_id === v.id && x.reporter_user_id === uid),
        response: (() => { const r = st().review_responses.find((x) => x.review_id === v.id); return r ? { content: r.content, updated_at: r.updated_at } : null; })(),
      }));
      return { rating: ratingOf(rid), items };
    },
    adminListReviews(status?: string | null): AdminReview[] {
      if (!a.isAdmin()) fail('Non autorizzato');
      const order: Record<string, number> = { flagged: 0, pending: 1 };
      return st().reviews
        .filter((v) => !status || v.status === status || (status === 'queue' && (v.status === 'pending' || v.status === 'flagged')) || ((status === 'reported' || status === 'queue') && st().review_reports.some((x) => x.review_id === v.id && x.status === 'open')))
        .sort((x, y) => (order[x.status] ?? 2) - (order[y.status] ?? 2) || y.created_at.localeCompare(x.created_at))
        .map((v) => {
          const r = restaurant(v.restaurant_id);
          const reps = st().review_reports.filter((x) => x.review_id === v.id);
          return {
            id: v.id, restaurant: { id: v.restaurant_id, name: r?.name ?? '', slug: r?.slug ?? '' }, author: displayName(v.user_id) ?? 'Utente', user_id: v.user_id,
            rating_overall: v.rating_overall, title: v.title, content: v.content, is_verified: v.is_verified, verification_source: v.verification_source, status: v.status,
            moderation_flags: v.moderation_flags, moderation_note: v.moderation_note, is_edited: v.is_edited, created_at: v.created_at, published_at: v.published_at,
            reports_open: reps.filter((x) => x.status === 'open').length, reports: reps.map((x) => ({ reason: x.reason, details: x.details, status: x.status, created_at: x.created_at })),
          };
        });
    },
    moderateReview(id: string, action: 'publish' | 'hide' | 'reject' | 'restore', note?: string | null) {
      if (!a.isAdmin()) fail('Non autorizzato');
      const v = st().reviews.find((x) => x.id === id) ?? fail('Recensione non trovata.');
      const to: ReviewStatus = action === 'publish' || action === 'restore' ? 'published' : action === 'hide' ? 'hidden' : 'rejected';
      const from = v.status;
      Object.assign(v, { status: to, moderated_at: now(), moderated_by: a.uid(), moderation_note: note?.trim() || null, published_at: to === 'published' ? v.published_at ?? now() : v.published_at });
      st().review_reports.filter((x) => x.review_id === id && x.status === 'open').forEach((x) => Object.assign(x, { status: to === 'published' ? 'dismissed' : 'upheld', reviewed_at: now() }));
      audit(`review_${action}`, 'review', id, { from, to, note });
      if (to === 'published' && from !== 'published') afterPublish(v);
      if ((to === 'rejected' || to === 'hidden') && from !== to) {
        notifyUser(v.user_id, 'review', 'La tua recensione non è stata pubblicata', note?.trim() || 'Non rispetta le linee guida delle recensioni.', `/ristorante/${restaurant(v.restaurant_id)?.slug}#recensioni`);
      }
      a.save();
    },

    // ─── AsiaPoints ─────────────────────────────────────────
    getLoyaltyWallet(o: { limit?: number; offset?: number } = {}): LoyaltyWallet {
      const uid = need();
      tick();
      const acc = account(uid);
      const next = [...st().loyalty_levels].filter((l) => l.is_active && l.min_lifetime_points > acc.lifetime_points).sort((x, y) => x.min_lifetime_points - y.min_lifetime_points)[0];
      const mine = st().loyalty_transactions.filter((t) => t.user_id === uid);
      const off = Math.max(o.offset ?? 0, 0);
      const lim = Math.min(Math.max(o.limit ?? 20, 1), 50);
      return {
        program_name: programName(), enabled: flag('loyalty_enabled', true), balance: acc.points_balance, lifetime: acc.lifetime_points, level: acc.level,
        level_min: st().loyalty_levels.find((l) => l.name === acc.level)?.min_lifetime_points ?? 0,
        next_level: next ? { name: next.name, min: next.min_lifetime_points, missing: next.min_lifetime_points - acc.lifetime_points } : null,
        expire_months: numSetting('points_expire_after_months', 0) || null,
        expiring_soon: mine.filter((t) => t.points_remaining > 0 && t.expires_at && Date.parse(t.expires_at) < Date.now() + 30 * DAY).reduce((s, t) => s + t.points_remaining, 0),
        transactions: mine.slice(off, off + lim).map(({ user_id: _u, source_id: _s, points_remaining: _p, ...t }) => t),
        transactions_total: mine.length,
        redemptions: st().reward_redemptions.filter((x) => x.user_id === uid).slice(0, 10).map((x) => {
          const rw = st().rewards.find((r) => r.id === x.reward_id);
          return { id: x.id, redemption_code: x.redemption_code, status: x.status, points_spent: x.points_spent, created_at: x.created_at, expires_at: x.expires_at, title: rw?.title ?? '', reward_type: rw?.reward_type ?? 'other', restaurant_slug: rw?.restaurant_id ? restaurant(rw.restaurant_id)?.slug ?? null : null };
        }),
        rules: st().loyalty_rules.filter((r) => r.enabled && r.points > 0).sort((x, y) => y.points - x.points).map((r) => ({ event_key: r.event_key, points: r.points, description: r.description })),
      };
    },
    listRewards(): Reward[] {
      return st().rewards.filter((r) => a.isAdmin() || (r.is_active && Date.parse(r.starts_at) <= Date.now() && (!r.ends_at || Date.parse(r.ends_at) > Date.now()))).sort((x, y) => x.points_cost - y.points_cost);
    },
    async redeemReward(id: string): Promise<RedeemResult> {
      const uid = need();
      if (profile(uid)?.is_blocked) fail('Account non abilitato.');
      if (!flag('loyalty_enabled', true)) fail('Il programma punti non è attivo.');
      const rw = st().rewards.find((r) => r.id === id);
      if (!rw || !rw.is_active || Date.parse(rw.starts_at) > Date.now() || (rw.ends_at && Date.parse(rw.ends_at) <= Date.now())) fail('Questo premio non è disponibile.');
      if (rw!.stock != null && rw!.stock <= 0) fail('Premio esaurito.');
      if (rw!.per_user_limit != null && st().reward_redemptions.filter((x) => x.reward_id === id && x.user_id === uid && x.status !== 'cancelled').length >= rw!.per_user_limit) fail('Hai già riscattato questo premio il numero massimo di volte.');
      const acc = account(uid);
      if (acc.points_balance < rw!.points_cost) fail(`Punti insufficienti: ti mancano ${rw!.points_cost - acc.points_balance} ${programName()}.`);
      // Tutto o niente: il coupon reale si ottiene prima di scalare i punti
      let code = '';
      let claimId: string | null = null;
      if (rw!.reward_type === 'restaurant_coupon' && rw!.coupon_id) {
        code = (await a.claimCoupon(rw!.coupon_id)).claim_code;
        claimId = a.db.coupon_claims.find((c) => c.claim_code === code)?.id ?? null;
      } else {
        do code = `AP-${genCode(6)}`;
        while (st().reward_redemptions.some((x) => x.redemption_code === code));
      }
      consume(uid, rw!.points_cost);
      acc.points_balance -= rw!.points_cost;
      const red = { id: uuid(), reward_id: rw!.id, user_id: uid, points_spent: rw!.points_cost, redemption_code: code, coupon_claim_id: claimId, status: 'claimed' as const, created_at: now(), redeemed_at: null, expires_at: rw!.ends_at ?? new Date(Date.now() + 30 * DAY).toISOString() };
      st().reward_redemptions.unshift(red);
      st().loyalty_transactions.unshift({ id: uuid(), user_id: uid, type: 'redeem', points: -rw!.points_cost, balance_after: acc.points_balance, event_key: 'reward_redeemed', source_type: 'reward', source_id: red.id, description: `Premio: ${rw!.title}`, created_at: now(), expires_at: null, points_remaining: 0 });
      if (rw!.stock != null) rw!.stock -= 1;
      touch(uid);
      notifyUser(uid, 'loyalty', 'Premio riscattato', `${rw!.title} · codice ${code}`, '/profile/loyalty', { dedupe: `reward_redeemed:${red.id}`, email: 'reward_redeemed', emailPayload: { reward: rw!.title, code } });
      a.save();
      return { redemption_id: red.id, code, title: rw!.title, points_spent: rw!.points_cost, balance: acc.points_balance, expires_at: red.expires_at };
    },
    getMyAchievements(): Achievement[] {
      const uid = a.uid();
      return st().achievements.filter((x) => x.is_active).map((x) => ({ id: x.id, key: x.key, name: x.name, description: x.description, icon: x.icon, points_bonus: x.points_bonus, earned_at: st().user_achievements.find((u) => u.user_id === uid && u.achievement_id === x.id)?.earned_at ?? null }));
    },
    adminLoyaltyAdjust(user: string, points: number, reason: string) {
      if (!a.isAdmin()) fail('Non autorizzato');
      if (!points || Math.abs(points) > 100000) fail('Valore non valido.');
      if (reason.trim().length < 3) fail('Indica il motivo della rettifica.');
      const acc = account(user);
      if (acc.points_balance + points < 0) fail(`Il saldo non può diventare negativo (saldo attuale ${acc.points_balance}).`);
      if (points < 0) consume(user, -points);
      acc.points_balance += points;
      if (points > 0) {
        acc.lifetime_points += points;
        acc.level = levelFor(acc.lifetime_points);
      }
      st().loyalty_transactions.unshift({ id: uuid(), user_id: user, type: 'adjustment', points, balance_after: acc.points_balance, event_key: 'admin_adjustment', source_type: 'admin', source_id: null, description: reason.trim().slice(0, 200), created_at: now(), expires_at: null, points_remaining: Math.max(points, 0) });
      audit('loyalty_adjustment', 'user', user, { points, reason });
      a.save();
      return acc.points_balance;
    },
    adminListRedemptions() {
      if (!a.isAdmin()) fail('Non autorizzato');
      return st().reward_redemptions.map((x) => ({ ...x, reward_title: st().rewards.find((r) => r.id === x.reward_id)?.title ?? '', user_name: displayName(x.user_id) ?? '' })) as unknown as (Row & { reward_title: string; user_name: string })[];
    },
    adminUpdateRedemption(id: string, status: 'used' | 'cancelled') {
      if (!a.isAdmin()) fail('Non autorizzato');
      const x = st().reward_redemptions.find((r) => r.id === id);
      if (!x || x.status !== 'claimed') fail('Riscatto non modificabile.');
      x!.status = status;
      if (status === 'used') x!.redeemed_at = now();
      else if (!st().loyalty_transactions.some((t) => t.event_key === 'redemption_refund' && t.source_id === id)) {
        const acc = account(x!.user_id);
        acc.points_balance += x!.points_spent;
        st().loyalty_transactions.unshift({ id: uuid(), user_id: x!.user_id, type: 'adjustment', points: x!.points_spent, balance_after: acc.points_balance, event_key: 'redemption_refund', source_type: 'reward', source_id: id, description: 'Premio annullato: punti restituiti', created_at: now(), expires_at: null, points_remaining: x!.points_spent });
        const rw = st().rewards.find((r) => r.id === x!.reward_id);
        if (rw && rw.stock != null) rw.stock += 1;
      }
      audit(`redemption_${status}`, 'reward_redemption', id);
      a.save();
    },

    // ─── Inviti ─────────────────────────────────────────────
    getMyReferrals(): ReferralSummary {
      const uid = need();
      tick();
      const mine = st().referrals.filter((r) => r.referrer_user_id === uid);
      const rule = (k: string) => st().loyalty_rules.find((r) => r.event_key === k && r.enabled)?.points ?? null;
      const code = ensureCode(uid);
      a.save();
      return {
        code, enabled: flag('referral_enabled', true),
        registered: mine.filter((r) => ['registered', 'qualified', 'rewarded'].includes(r.status)).length,
        qualified: mine.filter((r) => ['qualified', 'rewarded'].includes(r.status)).length,
        points: st().loyalty_transactions.filter((t) => t.user_id === uid && t.event_key === 'referral_completed').reduce((s, t) => s + t.points, 0),
        reward_points: rule('referral_completed'), welcome_points: rule('referral_welcome'),
        referred_by_me: st().referrals.some((r) => r.referred_user_id === uid),
        items: mine.slice(0, 50).map((r) => ({ status: r.status, registered_at: r.registered_at, qualified_at: r.qualified_at, name: displayName(r.referred_user_id) })),
      };
    },
    applyReferralCode(raw: string) {
      const uid = need();
      if (!flag('referral_enabled', true)) fail('Il programma inviti non è attivo.');
      const code = raw.toUpperCase().replace(/[^A-Z0-9-]/g, '');
      const owner = st().referral_codes.find((c) => c.code === code)?.user_id ?? fail('Codice invito non valido.');
      if (owner === uid) fail('Non puoi usare il tuo codice invito.');
      if (st().referrals.some((r) => r.referred_user_id === uid)) fail('Hai già usato un codice invito.');
      const created = Date.parse(profile(uid)?.created_at ?? now());
      if (created < Date.now() - numSetting('referral_signup_window_days', 14) * DAY) fail('Il codice invito si può usare solo nei primi giorni dopo la registrazione.');
      if (st().referrals.some((r) => r.referrer_user_id === uid && r.referred_user_id === owner)) fail('Codice invito non valido.');
      if (st().referrals.filter((r) => r.referrer_user_id === owner && r.registered_at && Date.parse(r.registered_at) >= startOfMonth()).length >= numSetting('referral_max_per_month', 20)) fail('Questo codice ha raggiunto il limite di inviti del mese.');
      st().referrals.unshift({ id: uuid(), referrer_user_id: owner, referred_user_id: uid, referral_code: code, status: 'registered', invalid_reason: null, registered_at: now(), qualified_at: null, rewarded_at: null, created_at: now() });
      notifyUser(owner, 'referral', 'Un amico si è registrato con il tuo invito', 'Riceverai i punti quando completerà la prima visita.', '/profile/referrals', { pref: 'referral_updates' });
      a.save();
      return { status: 'registered' };
    },
    createBusinessReferral(rid: string, email: string, name?: string | null) {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) fail('Email non valida.');
      const mail = email.trim().toLowerCase();
      if (st().business_referrals.filter((b) => b.referrer_restaurant_id === rid && Date.parse(b.created_at) > Date.now() - 30 * DAY).length >= 10) fail('Hai raggiunto il limite di segnalazioni del mese.');
      if (st().business_referrals.some((b) => b.referrer_restaurant_id === rid && b.referred_business_email === mail)) fail('Hai già segnalato questo locale.');
      const b: BusinessReferral = { id: uuid(), referrer_restaurant_id: rid, referred_business_email: mail, referred_business_name: name?.trim() || null, referred_restaurant_id: null, code: `B-${genCode(6)}`, status: 'invited', qualified_at: null, reward_type: null, reward_value: null, admin_note: null, created_at: now() };
      st().business_referrals.unshift(b);
      a.notifyAdmins('business_referral', 'Nuova segnalazione di un ristorante', mail, '/admin/referrals');
      a.save();
      return { id: b.id, code: b.code };
    },
    listBusinessReferrals(rid?: string | null) {
      return st().business_referrals.filter((b) => (rid ? b.referrer_restaurant_id === rid && a.canManage(rid) : a.isAdmin()));
    },
    adminListReferrals(status?: string | null): AdminReferral[] {
      if (!a.isAdmin()) fail('Non autorizzato');
      return st().referrals.filter((r) => !status || r.status === status).map((r) => ({
        id: r.id, status: r.status, code: r.referral_code, created_at: r.created_at, registered_at: r.registered_at, qualified_at: r.qualified_at, rewarded_at: r.rewarded_at,
        invalid_reason: r.invalid_reason, referrer: displayName(r.referrer_user_id) ?? '', referrer_id: r.referrer_user_id, referred: displayName(r.referred_user_id), referred_id: r.referred_user_id, email_verified: true,
      }));
    },
    adminReferralAction(id: string, action: 'invalidate' | 'qualify', reason?: string | null) {
      if (!a.isAdmin()) fail('Non autorizzato');
      const r = st().referrals.find((x) => x.id === id) ?? fail('Invito non trovato.');
      if (action === 'invalidate') {
        if (r.status === 'rewarded') fail('Invito già premiato: rettifica i punti dalla sezione loyalty.');
        Object.assign(r, { status: 'invalid', invalid_reason: reason?.trim() || 'Annullato dall’amministrazione' });
      } else {
        if (r.status !== 'registered' || !r.referred_user_id) fail('Solo gli inviti registrati possono essere qualificati.');
        referralQualify(r.referred_user_id!, true);
      }
      audit(`referral_${action}`, 'referral', id, { reason });
      a.save();
    },
    adminBusinessReferralUpdate(id: string, patch: { status: BusinessReferral['status']; reward_type?: BusinessReferral['reward_type']; reward_value?: number | null; note?: string | null }) {
      if (!a.isAdmin()) fail('Non autorizzato');
      const b = st().business_referrals.find((x) => x.id === id) ?? fail('Segnalazione non trovata.');
      Object.assign(b, { status: patch.status, reward_type: patch.reward_type ?? b.reward_type, reward_value: patch.reward_value ?? b.reward_value, admin_note: patch.note?.trim() || b.admin_note, qualified_at: ['qualified', 'approved', 'rewarded'].includes(patch.status) ? b.qualified_at ?? now() : b.qualified_at });
      audit(`business_referral_${patch.status}`, 'business_referral', id, { reward_type: patch.reward_type, reward_value: patch.reward_value });
      a.save();
    },

    // ─── Notifiche e push ───────────────────────────────────
    listNotificationsPage(o: { limit: number; offset: number; unreadOnly?: boolean }) {
      const uid = a.uid();
      if (!uid) return { items: [], unread: 0 };
      tick();
      const mine = a.db.notifications.filter((n) => n.user_id === uid);
      const list = o.unreadOnly ? mine.filter((n) => !n.read_at) : mine;
      return { items: list.slice(o.offset, o.offset + o.limit), unread: mine.filter((n) => !n.read_at).length };
    },
    markRead(ids: string[] | null) {
      const uid = a.uid();
      a.db.notifications.filter((n) => n.user_id === uid && !n.read_at && (!ids || ids.includes(n.id))).forEach((n) => {
        n.read_at = now();
        const d = (n.metadata as { delivery_id?: string } | undefined)?.delivery_id;
        if (d) {
          const del = st().campaign_deliveries.find((x) => x.id === d);
          if (del && !del.opened_at) del.opened_at = n.read_at;
        }
      });
    },
    getNotificationPrefs(): NotificationPrefs {
      const uid = a.uid();
      if (!uid) return DEFAULT_PREFS;
      const { user_id: _u, ...p } = prefs(uid);
      return p;
    },
    saveNotificationPrefs(patch: Partial<NotificationPrefs>): NotificationPrefs {
      const uid = need();
      const p = prefs(uid);
      for (const [k, v] of Object.entries(patch)) if (k in DEFAULT_PREFS) (p as unknown as Row)[k] = v;
      a.save();
      const { user_id: _u, ...rest } = p;
      return rest;
    },
    savePushSubscription(endpoint: string, device?: string | null, platform?: string | null) {
      const uid = need();
      if (!/^https:\/\//.test(endpoint) && !endpoint.startsWith('demo:')) fail('Endpoint non valido.');
      const ex = st().push_subscriptions.find((s) => s.endpoint === endpoint);
      if (ex) Object.assign(ex, { user_id: uid, is_active: true, device_name: device ?? null, platform: platform ?? null });
      else st().push_subscriptions.push({ id: uuid(), user_id: uid, endpoint, device_name: device ?? null, platform: platform ?? null, is_active: true, created_at: now() });
      prefs(uid).push_enabled = true;
      a.save();
    },
    removePushSubscription(endpoint: string) {
      const uid = a.uid();
      if (!uid) return;
      st().push_subscriptions.filter((s) => s.endpoint === endpoint && s.user_id === uid).forEach((s) => (s.is_active = false));
      if (!st().push_subscriptions.some((s) => s.user_id === uid && s.is_active)) prefs(uid).push_enabled = false;
      a.save();
    },
    recordActivity() {
      touch(a.uid());
      a.save();
    },
    trackCampaignClick(deliveryId: string) {
      const d = st().campaign_deliveries.find((x) => x.id === deliveryId && ['sent', 'delivered'].includes(x.status));
      if (d) {
        d.clicked_at = d.clicked_at ?? now();
        d.opened_at = d.opened_at ?? now();
        a.save();
      }
    },
    getFollowState(rid: string) {
      const uid = a.uid();
      const f = a.db.favorites.find((x) => x.user_id === uid && x.restaurant_id === rid);
      return { favorite: !!f, following: !!f?.notifications_enabled };
    },
    setFollow(rid: string, on: boolean) {
      const uid = need();
      if (on && !a.isPublic(rid)) fail('Ristorante non trovato.');
      let f = a.db.favorites.find((x) => x.user_id === uid && x.restaurant_id === rid);
      if (on) {
        if (!f) {
          f = { user_id: uid, restaurant_id: rid, created_at: now() };
          a.db.favorites.push(f);
        }
        f.notifications_enabled = true;
        prefs(uid).favorite_restaurants = true;
      } else if (f) f.notifications_enabled = false;
      touch(uid);
      a.save();
      return on;
    },

    // ─── Campagne ───────────────────────────────────────────
    campaignAudienceCount(scope: 'platform' | 'restaurant', rid: string | null, target: CampaignTarget, targeting?: Record<string, string>) {
      if (scope === 'restaurant' ? !rid || !a.canManage(rid) : !a.isAdmin()) fail('Operazione non consentita.');
      return audience(scope, rid, target, targeting).length;
    },
    createCampaign(input: CampaignInput) {
      const uid = need();
      const channels = [...new Set(input.channels.filter((c) => ['in_app', 'push', 'email'].includes(c)))];
      if (!channels.length) fail('Scegli almeno un canale.');
      const sendAt = input.send_at ? new Date(input.send_at).getTime() : Date.now();
      if (!Number.isFinite(sendAt) || sendAt < Date.now() - 5 * 60_000 || sendAt > Date.now() + 60 * DAY) fail('Data di invio non valida.');
      if ((input.title ?? '').trim().length < 3 || (input.title ?? '').trim().length > 80) fail('Titolo: tra 3 e 80 caratteri.');
      if ((input.message ?? '').trim().length < 3 || (input.message ?? '').trim().length > 240) fail('Messaggio: tra 3 e 240 caratteri.');
      let url = input.action_url?.trim() || null;
      let ch = channels;
      if (input.scope === 'restaurant') {
        const rid = input.restaurant_id ?? fail('Operazione non consentita.');
        if (!a.canManage(rid)) fail('Operazione non consentita.');
        if (!a.isAdmin() && !a.db.restaurant_members.some((m) => m.restaurant_id === rid && m.user_id === uid && m.status === 'active' && ['owner', 'manager'].includes(m.role))) fail('Solo titolari e manager possono creare campagne.');
        if (!a.hasFeature(rid, 'push_campaigns_enabled')) throw Object.assign(new Error('PLAN_FEATURE:push_campaigns_enabled'), { planFeature: 'push_campaigns_enabled' });
        const limit = a.featureLimit(rid, 'monthly_campaign_limit');
        const used = st().campaigns.filter((c) => c.restaurant_id === rid && ['scheduled', 'sending', 'sent'].includes(c.status) && Date.parse(c.created_at) >= startOfMonth()).length;
        if (limit != null && used >= limit) fail(`Hai raggiunto il limite di campagne del mese (${limit}).`);
        if (st().campaigns.some((c) => c.restaurant_id === rid && ['scheduled', 'sending', 'sent'].includes(c.status) && Date.parse(c.created_at) > Date.now() - DAY)) fail('Puoi creare al massimo una campagna al giorno.');
        if (!['followers', 'coupon_users', 'past_customers', 'all_eligible'].includes(input.target)) fail('Destinatari non validi.');
        url = `/ristorante/${restaurant(rid)?.slug}${url && /^#(offerte|menu|prenota|recensioni)$/.test(url) ? url : ''}`;
        ch = channels.filter((c) => c !== 'email');
        if (!ch.length) ch = ['in_app'];
      } else {
        if (!a.isAdmin()) fail('Non autorizzato');
        if (!['all_users', 'city', 'favorite_category', 'upcoming_reservation', 'active_users', 'loyalty_level'].includes(input.target)) fail('Destinatari non validi.');
        if (url && !/^\/[A-Za-z0-9/_#?=&.-]*$/.test(url)) fail('Link non valido: usa un percorso interno (es. /offers).');
      }
      const c: Campaign & { created_by: string | null } = {
        id: uuid(), scope: input.scope, restaurant_id: input.scope === 'restaurant' ? input.restaurant_id ?? null : null, title: input.title.trim(), message: input.message.trim(),
        action_url: url, target: input.target, targeting: input.targeting ?? {}, channels: ch as Campaign['channels'], send_at: new Date(sendAt).toISOString(),
        status: input.status === 'draft' ? 'draft' : 'scheduled', recipients_count: 0, error: null, created_at: now(), sent_at: null, created_by: uid,
      };
      st().campaigns.unshift(c);
      if (c.scope === 'platform') audit('campaign_created', 'campaign', c.id, { target: c.target });
      a.save();
      return { id: c.id, status: c.status, audience: audience(c.scope, c.restaurant_id, c.target, c.targeting).length };
    },
    cancelCampaign(id: string) {
      const c = st().campaigns.find((x) => x.id === id) ?? fail('Campagna non trovata.');
      if (c.scope === 'restaurant' ? !a.canManage(c.restaurant_id!) : !a.isAdmin()) fail('Operazione non consentita.');
      if (!['draft', 'scheduled'].includes(c.status)) fail('La campagna è già stata inviata.');
      c.status = 'cancelled';
      if (a.isAdmin()) audit('campaign_cancelled', 'campaign', id, { scope: c.scope });
      a.save();
    },
    listCampaigns(f: { scope: 'platform' | 'restaurant'; restaurantId?: string | null }) {
      tick();
      return st().campaigns.filter((c) => c.scope === f.scope && (!f.restaurantId || c.restaurant_id === f.restaurantId) && (a.isAdmin() || (c.restaurant_id && a.canManage(c.restaurant_id)))).map(({ created_by: _c, ...c }) => c);
    },
    getPushCampaignStats(id: string): PushCampaignStats {
      const c = st().campaigns.find((x) => x.id === id) ?? fail('Campagna non trovata.');
      if (!(a.isAdmin() || (c.scope === 'restaurant' && a.canManage(c.restaurant_id!)))) fail('Operazione non consentita.');
      const d = st().campaign_deliveries.filter((x) => x.campaign_id === id);
      const sent = d.filter((x) => x.status === 'sent' || x.status === 'delivered');
      const byChannel: Record<string, number> = {};
      sent.forEach((x) => (byChannel[x.channel] = (byChannel[x.channel] ?? 0) + 1));
      const clicked = d.filter((x) => x.clicked_at).length;
      return { recipients: c.recipients_count, sent: sent.length, delivered: d.filter((x) => x.status === 'delivered').length, opened: d.filter((x) => x.opened_at).length, clicked, skipped: d.filter((x) => x.status === 'skipped').length, failed: d.filter((x) => x.status === 'failed').length, ctr: sent.length ? Math.round((clicked * 1000) / sent.length) / 10 : 0, by_channel: byChannel };
    },

    // ─── Statistiche ────────────────────────────────────────
    getRetentionStats(days = 30): RetentionStats {
      if (!a.isAdmin()) fail('Non autorizzato');
      const d = Math.min(Math.max(days, 7), 365);
      const today = romeDate();
      const dayMinus = (n: number) => romeDate(new Date(Date.now() - n * DAY));
      const since = Date.now() - d * DAY;
      const act = st().activity_days;
      const distinct = (xs: { user_id: string }[]) => new Set(xs.map((x) => x.user_id)).size;
      const inPeriod = act.filter((x) => x.day > dayMinus(d));
      const prev = act.filter((x) => x.day <= dayMinus(d) && x.day > dayMinus(2 * d));
      const prevUsers = new Set(prev.map((x) => x.user_id));
      const groupCount = <T,>(xs: T[], key: (x: T) => string | null | undefined) => {
        const m = new Map<string, number>();
        xs.forEach((x) => {
          const k = key(x);
          if (k) m.set(k, (m.get(k) ?? 0) + 1);
        });
        return m;
      };
      const resUsers = groupCount(a.db.reservations.filter((r) => r.status === 'completed'), (r) => r.user_id);
      const cpnUsers = groupCount(a.db.coupon_claims.filter((c) => c.status === 'redeemed'), (c) => c.user_id);
      const tx = st().loyalty_transactions.filter((t) => Date.parse(t.created_at) >= since);
      return {
        definitions: {
          active: 'Utente registrato con almeno un evento significativo nel giorno: accesso all’app, prenotazione, recensione, coupon, premio o follow.',
          dau: 'Utenti attivi oggi', wau: 'Utenti attivi negli ultimi 7 giorni', mau: 'Utenti attivi negli ultimi 30 giorni',
          returning: 'Attivi nel periodo che erano già stati attivi nel periodo precedente di pari durata',
        },
        dau: distinct(act.filter((x) => x.day === today)), wau: distinct(act.filter((x) => x.day > dayMinus(7))), mau: distinct(act.filter((x) => x.day > dayMinus(30))),
        returning_users: new Set(inPeriod.filter((x) => prevUsers.has(x.user_id)).map((x) => x.user_id)).size, previous_period_users: prevUsers.size,
        repeat_reservation_users: [...resUsers.values()].filter((n) => n >= 2).length, reservation_users: resUsers.size,
        completed_reservations: a.db.reservations.filter((r) => r.status === 'completed' && r.completed_at && Date.parse(r.completed_at) >= since).length,
        reviews_published: st().reviews.filter((v) => v.status === 'published' && v.published_at && Date.parse(v.published_at) >= since).length,
        reviews_verified: st().reviews.filter((v) => v.status === 'published' && v.is_verified && v.published_at && Date.parse(v.published_at) >= since).length,
        reviews_pending: st().reviews.filter((v) => v.status === 'pending' || v.status === 'flagged').length,
        referral_signups: st().referrals.filter((r) => r.registered_at && Date.parse(r.registered_at) >= since).length,
        referral_qualified: st().referrals.filter((r) => r.qualified_at && Date.parse(r.qualified_at) >= since).length,
        points_issued: tx.filter((t) => t.points > 0 && t.type !== 'adjustment').reduce((s, t) => s + t.points, 0),
        points_redeemed: -tx.filter((t) => t.type === 'redeem').reduce((s, t) => s + t.points, 0),
        rewards_redeemed: st().reward_redemptions.filter((x) => Date.parse(x.created_at) >= since).length,
        push_subscribers: new Set(st().push_subscriptions.filter((s) => s.is_active).map((s) => s.user_id)).size,
        coupon_users: cpnUsers.size, coupon_repeat_users: [...cpnUsers.values()].filter((n) => n >= 2).length,
        followers: a.db.favorites.filter((f) => f.notifications_enabled).length,
        daily: Array.from({ length: Math.min(d, 60) }, (_, i) => {
          const day = dayMinus(Math.min(d, 60) - 1 - i);
          return { day, active: act.filter((x) => x.day === day).length };
        }),
      };
    },
    getRestaurantEngagementStats(rid: string, days = 30): RestaurantEngagementStats {
      if (!a.canManage(rid)) fail('Operazione non consentita.');
      const since = Date.now() - days * DAY;
      const done = a.db.reservations.filter((r) => r.restaurant_id === rid && r.user_id && r.status === 'completed');
      const per = new Map<string, number>();
      done.forEach((r) => per.set(r.user_id!, (per.get(r.user_id!) ?? 0) + 1));
      const camps = new Set(st().campaigns.filter((c) => c.restaurant_id === rid).map((c) => c.id));
      const dels = st().campaign_deliveries.filter((x) => camps.has(x.campaign_id));
      return {
        rating: ratingOf(rid), followers: a.db.favorites.filter((f) => f.restaurant_id === rid && f.notifications_enabled).length, favorites: a.db.favorites.filter((f) => f.restaurant_id === rid).length,
        customers: per.size, returning_customers: [...per.values()].filter((n) => n >= 2).length,
        coupon_redemptions: a.db.coupon_claims.filter((c) => c.restaurant_id === rid && c.status === 'redeemed' && c.redeemed_at && Date.parse(c.redeemed_at) >= since).length,
        campaign_sends: dels.filter((x) => (x.status === 'sent' || x.status === 'delivered') && x.sent_at && Date.parse(x.sent_at) >= since).length,
        campaign_clicks: dels.filter((x) => x.clicked_at && Date.parse(x.clicked_at) >= since).length,
      };
    },
    runTick() {
      if (!a.isAdmin()) fail('Non autorizzato');
      return tick();
    },
  };
}

export type EngagementDemo = ReturnType<typeof createEngagement>;
