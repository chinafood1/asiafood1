import type { LaunchApi } from '@/types/launch';
import type { GrowthApi } from '@/types/growth';
import type {
  AdminSubscriptionRow,
  BillingAccount,
  BillingAccountInput,
  BillingInterval,
  BillingOverview,
  CampaignStats,
  ChangePreview,
  CheckoutConfirmation,
  ProfileCompletion,
  RevenueStats,
  SponsoredSlot,
  StripeEventLog,
  AnalyticsEventType,
  AppEventType,
  AppNotification,
  Availability,
  ClaimCouponResult,
  CouponCheck,
  CouponClaimView,
  OfferType,
  PlanUpgradeRequest,
  PlanWithFeatures,
  Reservation,
  ReservationInput,
  ReservationResult,
  ReservationSettings,
  ReservationSlot,
  ReservationStatus,
  ReservationWithRestaurant,
  RestaurantAnalytics,
  RestaurantClosure,
  Category,
  ChangeRequest,
  ChangeRequestStatus,
  City,
  ClaimMessage,
  ClaimStatus,
  ClaimWithRestaurant,
  DataStatus,
  ImportBatch,
  MemberRole,
  MemberWithProfile,
  OfferWithRestaurant,
  PlanCode,
  Profile,
  ReportStatus,
  ReportType,
  ReportWithRestaurant,
  Restaurant,
  RestaurantClaim,
  RestaurantDetail,
  RestaurantHour,
  RestaurantSummary,
  SponsoredPlacement,
  VerificationMethod,
} from '@/types/domain';
import type { ExistingRestaurant, ImportOperation } from '@/lib/import/plan';
import type { AiAdminStats, AiChatInput, AiChatReply, AiPreferences, RestaurantAiStats } from '@/types/ai';
import type {
  Achievement, AdminReferral, AdminReview, BusinessReferral, Campaign, CampaignInput, PushCampaignStats, CampaignTarget, EngagementTickResult,
  LoyaltyWallet, ManagedReview, NotificationPrefs, PushSubscriptionInput, RedeemResult, ReferralSummary, RestaurantEngagementStats,
  RestaurantRating, RetentionStats, Reward, ReviewFilter, ReviewFormStatus, ReviewInput, ReviewItem, ReviewReportReason, ReviewSort,
} from '@/types/engagement';
import type { GeoBounds } from '@/lib/maps/types';

export type SortKey = 'relevance' | 'distance' | 'popular' | 'price_asc' | 'price_desc' | 'newest';

export interface RestaurantFilters {
  /** Ricerca libera: "Sushi Taranto" viene scomposta in categoria + comune + testo. */
  q?: string;
  /** Testo residuo già interpretato (uso interno dei data source). */
  text?: string;
  categorySlug?: string;
  citySlug?: string;
  priceRanges?: number[];
  ayce?: boolean;
  delivery?: boolean;
  takeaway?: boolean;
  reservation?: boolean;
  openNow?: boolean;
  hasOffers?: boolean;
  featured?: boolean;
  newOpenings?: boolean;
  near?: { lat: number; lng: number; radiusKm?: number };
  sort?: SortKey;
  limit?: number;
  /** Include i locali chiusi definitivamente (default: esclusi). */
  includeClosed?: boolean;
  /** Solo locali nel riquadro geografico (mappa, "Cerca in questa zona"). Esclude quelli senza coordinate. */
  bounds?: GeoBounds;
  /** Solo profili verificati dal titolare. */
  verified?: boolean;
  /** Fase 8: ordini online (filtrato lato client con getOrderableRestaurants). */
  orderMode?: 'now' | 'takeaway' | 'delivery';
}

export interface Paged<T> {
  rows: T[];
  total: number;
}

export type YesNo = 'yes' | 'no';

export interface AdminRestaurantQuery {
  q?: string;
  cityId?: string;
  categoryId?: string;
  verified?: YesNo;
  claimed?: YesNo;
  active?: YesNo;
  sponsored?: YesNo;
  demo?: YesNo;
  closed?: 'temporary' | 'permanent' | 'open';
  coords?: 'missing' | 'present';
  dataStatus?: DataStatus;
  plan?: PlanCode;
  sort?: 'name' | 'updated' | 'last_verified';
  page?: number;
  pageSize?: number;
}

export interface ClaimInput {
  restaurant_id: string;
  user_id: string;
  first_name: string;
  last_name: string;
  role: string;
  business_name: string | null;
  vat_number: string | null;
  tax_code: string | null;
  business_email: string;
  phone: string;
  website: string | null;
  verification_method: VerificationMethod;
  verification_document_url: string | null;
  message: string | null;
}

export interface ClaimFilter {
  status?: ClaimStatus | 'open';
  restaurantId?: string;
}

export interface ReportInput {
  restaurant_id: string;
  user_id: string | null;
  report_type: ReportType;
  description: string;
  email: string | null;
}

export type AdminStats = Record<string, number | boolean>;

export interface ManagedRestaurant extends RestaurantSummary {
  member_role: MemberRole;
}

/** Tabelle gestibili dal CRUD generico dell'Admin e dal gestore del ristorante. */
export type TableName =
  | 'regions'
  | 'provinces'
  | 'cities'
  | 'categories'
  | 'subscription_plans'
  | 'plan_features'
  | 'sponsored_campaigns'
  | 'billing_promotions'
  | 'offers'
  | 'coupons'
  | 'menus'
  | 'menu_categories'
  | 'menu_items'
  | 'menu_item_variants'
  | 'menu_item_addons'
  | 'reservation_settings'
  | 'reservation_slots'
  | 'restaurant_closures'
  | 'restaurant_images'
  | 'restaurant_sources'
  | 'restaurant_reports'
  | 'import_batches'
  | 'subscriptions'
  | 'loyalty_rules'
  | 'loyalty_levels'
  | 'rewards'
  | 'achievements';

export type Row = Record<string, unknown>;

/** Filtri della pagina Offerte. */
export interface OfferFilters {
  citySlug?: string;
  categorySlug?: string;
  /** Solo offerte valide in questa data (YYYY-MM-DD), incluso il giorno della settimana. */
  date?: string;
  /** Scorciatoia: valide oggi. */
  today?: boolean;
  offerType?: OfferType;
  ayce?: boolean;
  near?: { lat: number; lng: number; radiusKm?: number };
  limit?: number;
}

/** Riga di import menu (CSV/JSON già normalizzato). */
export interface MenuImportRow {
  menu?: string;
  menu_type?: string;
  category: string;
  name: string;
  description?: string | null;
  price?: number | null;
  discount_price?: number | null;
  allergens?: string[];
  ingredients?: string[];
  is_vegetarian?: boolean;
  is_vegan?: boolean;
  is_gluten_free?: boolean;
  is_spicy?: boolean;
  is_available?: boolean;
  is_featured?: boolean;
  variants?: { name: string; price: number | null }[];
  addons?: { name: string; price: number | null }[];
}

export interface ReservationRange {
  from?: string; // YYYY-MM-DD incluso
  to?: string; // YYYY-MM-DD incluso
  statuses?: ReservationStatus[];
  limit?: number;
  ascending?: boolean;
}

export type DemoBillingAction = 'complete_checkout' | 'end_trial' | 'fail_payment' | 'pay_invoice' | 'reach_period_end' | 'update_card';

export interface AdminSubscriptionFilter {
  plan?: PlanCode;
  status?: string;
  source?: string;
  /** trial = in prova; expired = scadute/terminate; past_due = pagamento in ritardo */
  view?: 'all' | 'trial' | 'expired' | 'past_due' | 'active';
  q?: string;
}

export interface ImportResult {
  id: string;
  slug: string;
  action: 'created' | 'updated';
}

/**
 * Contratto unico del data layer. Due implementazioni:
 *  - supabaseSource: produzione (RLS lato DB)
 *  - demoSource: dati locali, persistiti nel browser, per sviluppo/demo
 */
export interface DataSource {
  readonly mode: 'supabase' | 'demo';
  /** Fase 12 · go-to-market: Launch Control, CRM, Partner Fondatori, QR, attribuzione, feedback. */
  readonly launch: LaunchApi;
  /** Fase 13 · Business Intelligence & Growth Automation (dashboard Admin, performance ristoratore, ricerche, esperimenti). */
  readonly growth: GrowthApi;

  // ─── Pubblico ──────────────────────────────────────────────
  getCategories(): Promise<Category[]>;
  getCities(): Promise<City[]>;
  searchRestaurants(filters: RestaurantFilters): Promise<RestaurantSummary[]>;
  getRestaurantBySlug(slug: string): Promise<RestaurantDetail | null>;
  getRestaurantsByIds(ids: string[]): Promise<RestaurantSummary[]>;
  getActiveOffers(opts?: OfferFilters): Promise<OfferWithRestaurant[]>;
  getCityCounts(): Promise<Record<string, number>>;
  getCategoryCounts(): Promise<Record<string, number>>;
  track(restaurantId: string | null, type: AnalyticsEventType, source?: string, metadata?: Row): Promise<void>;
  /** Eventi di prodotto (mappa, geolocalizzazione). Mai coordinate nei metadati. */
  trackAppEvent(type: AppEventType, opts?: { restaurantId?: string | null; source?: string; metadata?: Row }): void;
  createReport(input: ReportInput): Promise<void>;
  /** Piani attivi con le feature (letti da tutti: servono a mostrare le funzioni disponibili). */
  getPlans(): Promise<PlanWithFeatures[]>;

  // ─── Prenotazioni (pubblico) ───────────────────────────────
  getReservationAvailability(restaurantId: string, date: string, partySize: number): Promise<Availability>;
  createReservation(input: ReservationInput): Promise<ReservationResult>;
  cancelReservationByCode(code: string, email: string): Promise<void>;
  /** Locali con almeno un orario libero nella data (solo disponibilità reali). */
  getRestaurantsAvailableOn(opts: { date?: string; partySize?: number; from?: string; limit?: number }): Promise<{ restaurant: RestaurantSummary; first_slot: string; slots_count: number }[]>;

  // ─── Coupon (pubblico) ─────────────────────────────────────
  /** source = 'ai' quando il coupon viene ottenuto partendo dall'assistente (attribuzione). */
  claimCoupon(couponId: string, email?: string | null, source?: 'web' | 'ai'): Promise<ClaimCouponResult>;

  // ─── Utente ────────────────────────────────────────────────
  getFavoriteIds(userId: string): Promise<string[]>;
  setFavorite(userId: string, restaurantId: string, on: boolean): Promise<void>;
  updateMyProfile(userId: string, patch: Partial<Profile>): Promise<void>;
  getMyReservations(): Promise<ReservationWithRestaurant[]>;
  getMyCouponClaims(): Promise<CouponClaimView[]>;
  listNotifications(limit?: number): Promise<AppNotification[]>;
  markNotificationsRead(ids?: string[]): Promise<void>;

  // ─── Rivendicazioni (richiedente) ──────────────────────────
  uploadClaimDocument(userId: string, file: File): Promise<string>;
  createClaim(input: ClaimInput): Promise<string>;
  getMyClaims(userId: string): Promise<ClaimWithRestaurant[]>;
  getClaim(id: string): Promise<ClaimWithRestaurant | null>;
  getClaimMessages(claimId: string): Promise<ClaimMessage[]>;
  respondToClaim(claimId: string, message: string, attachmentPath?: string | null): Promise<void>;
  getClaimDocumentUrl(path: string): Promise<string>;

  // ─── Ristoratore (e Admin) ─────────────────────────────────
  getManagedRestaurants(userId: string): Promise<ManagedRestaurant[]>;
  getRestaurantForEdit(id: string): Promise<RestaurantDetail | null>;
  updateRestaurant(id: string, patch: Partial<Restaurant>): Promise<void>;
  setRestaurantCategories(id: string, categoryIds: string[], primaryId: string | null): Promise<void>;
  replaceHours(id: string, hours: Omit<RestaurantHour, 'id' | 'restaurant_id'>[]): Promise<void>;
  uploadImage(restaurantId: string, file: File, folder: 'logo' | 'cover' | 'gallery' | 'menu'): Promise<{ url: string; path: string | null }>;
  getRestaurantStats(id: string, days?: number): Promise<Partial<Record<AnalyticsEventType, number>>>;
  getRestaurantAnalytics(id: string, days: number): Promise<RestaurantAnalytics>;

  // ─── Menu (gestione) ───────────────────────────────────────
  duplicateMenu(menuId: string): Promise<string>;
  duplicateMenuItem(itemId: string): Promise<string>;
  reorderMenuRows(table: 'menus' | 'menu_categories' | 'menu_items' | 'menu_item_variants' | 'menu_item_addons', ids: string[]): Promise<void>;
  /** Sostituisce varianti ed extra di un piatto. */
  replaceItemOptions(itemId: string, variants: { name: string; price: number | null; is_available?: boolean }[], addons: { name: string; price: number | null; is_available?: boolean }[]): Promise<void>;
  importMenu(restaurantId: string, rows: MenuImportRow[]): Promise<{ menus: number; categories: number; items: number }>;

  // ─── Prenotazioni (gestione) ───────────────────────────────
  getReservationConfig(restaurantId: string): Promise<{ settings: ReservationSettings | null; slots: ReservationSlot[]; closures: RestaurantClosure[] }>;
  saveReservationSettings(settings: ReservationSettings): Promise<void>;
  listReservations(restaurantId: string, range?: ReservationRange): Promise<Reservation[]>;
  setReservationStatus(id: string, status: ReservationStatus, note?: string | null): Promise<void>;

  // ─── Coupon (gestione) ─────────────────────────────────────
  checkCouponClaim(restaurantId: string, code: string): Promise<CouponCheck>;
  redeemCoupon(restaurantId: string, code: string): Promise<CouponCheck>;
  listCouponClaims(restaurantId: string, limit?: number): Promise<CouponClaimView[]>;

  // ─── Piani (ristoratore) ───────────────────────────────────
  requestPlanUpgrade(input: { restaurant_id: string; plan_code: PlanCode; billing_interval: 'month' | 'year'; message?: string | null }): Promise<void>;
  listUpgradeRequests(filter?: { status?: PlanUpgradeRequest['status']; restaurantId?: string }): Promise<PlanUpgradeRequest[]>;
  listMembers(restaurantId: string): Promise<MemberWithProfile[]>;
  createChangeRequest(input: { restaurant_id: string; user_id: string; payload: ChangeRequest['payload']; note?: string | null }): Promise<void>;
  listChangeRequests(filter?: { status?: ChangeRequestStatus; restaurantId?: string }): Promise<ChangeRequest[]>;

  // ─── CRUD generico (protetto da RLS) ───────────────────────
  list<T = Row>(table: TableName, opts?: { match?: Row; orderBy?: string; ascending?: boolean; limit?: number }): Promise<T[]>;
  upsert<T = Row>(table: TableName, row: Row, primaryKey?: string): Promise<T>;
  remove(table: TableName, value: string, primaryKey?: string): Promise<void>;

  // ─── Admin ─────────────────────────────────────────────────
  getAdminStats(): Promise<AdminStats>;
  getSetting<T = unknown>(key: string): Promise<T | null>;
  setSetting(key: string, value: unknown): Promise<void>;
  adminListRestaurants(q: AdminRestaurantQuery): Promise<Paged<RestaurantSummary>>;
  createRestaurant(input: Pick<Restaurant, 'name' | 'city_id'> & Partial<Restaurant>, categoryIds: string[]): Promise<Restaurant>;
  duplicateRestaurant(id: string): Promise<string>;
  deleteRestaurant(id: string): Promise<void>;
  listClaims(filter?: ClaimFilter): Promise<ClaimWithRestaurant[]>;
  approveClaim(id: string, notes?: string): Promise<void>;
  rejectClaim(id: string, notes?: string): Promise<void>;
  requestClaimInfo(id: string, message: string): Promise<void>;
  setClaimUnderReview(id: string, notes?: string): Promise<void>;
  transferOwnership(restaurantId: string, userId: string, notes?: string): Promise<void>;
  revokeOwnership(restaurantId: string, notes?: string): Promise<void>;
  setMember(restaurantId: string, userId: string, role: MemberRole): Promise<void>;
  removeMember(memberId: string): Promise<void>;
  listReports(filter?: { status?: ReportStatus | 'open_all'; restaurantId?: string }): Promise<ReportWithRestaurant[]>;
  updateReport(id: string, patch: { status?: ReportStatus; admin_notes?: string | null }): Promise<void>;
  reviewChangeRequest(id: string, approve: boolean, notes?: string): Promise<void>;
  setPlanFeature(planCode: PlanCode, featureKey: string, patch: { enabled: boolean; limit_value: number | null }): Promise<void>;
  updateUpgradeRequest(id: string, status: PlanUpgradeRequest['status']): Promise<void>;
  listProfiles(q?: string): Promise<Profile[]>;
  updateProfile(id: string, patch: Partial<Profile>): Promise<void>;

  // ─── Fatturazione (Fase 5) ─────────────────────────────────
  /** Stato abbonamento del locale letto dal DB sincronizzato (nessuna chiamata a Stripe). */
  getBillingOverview(restaurantId: string): Promise<BillingOverview>;
  getBillingAccount(): Promise<BillingAccount | null>;
  saveBillingAccount(input: BillingAccountInput): Promise<BillingAccount>;
  /** Azioni che passano dal backend (Netlify Functions → Stripe). */
  startCheckout(input: { restaurant_id: string; plan: PlanCode; billing_interval: BillingInterval; promotion_code?: string | null }): Promise<{ url: string; trial_days: number }>;
  openBillingPortal(restaurantId: string, flow?: 'payment_method_update' | 'subscription_cancel' | null): Promise<{ url: string }>;
  confirmCheckout(sessionId: string): Promise<CheckoutConfirmation>;
  previewPlanChange(restaurantId: string, plan: PlanCode, interval: BillingInterval): Promise<ChangePreview>;
  changePlan(restaurantId: string, plan: PlanCode, interval: BillingInterval): Promise<{ status: 'updated' | 'scheduled'; effective_at: string | null }>;
  cancelSubscription(restaurantId: string): Promise<{ until: string | null }>;
  resumeSubscription(restaurantId: string): Promise<void>;
  cancelScheduledChange(restaurantId: string): Promise<void>;
  refreshInvoices(restaurantId: string): Promise<void>;
  /** Solo modalità DEMO: simula ciò che in produzione fanno l'utente su Stripe o il tempo. */
  simulateBilling?(action: DemoBillingAction, payload: { sessionId?: string; restaurantId?: string; card?: boolean }): Promise<void>;

  // ─── Onboarding ────────────────────────────────────────────
  getProfileCompletion(restaurantId: string): Promise<ProfileCompletion>;
  completeOnboarding(restaurantId: string): Promise<void>;
  requestPublication(restaurantId: string): Promise<'requested' | 'already_public' | 'already_requested'>;

  // ─── Sponsorizzazioni ──────────────────────────────────────
  getSponsoredSlots(placement: SponsoredPlacement, ctx?: { citySlug?: string | null; categorySlug?: string | null; limit?: number }): Promise<SponsoredSlot[]>;
  trackSponsored(campaignId: string, type: 'sponsored_impression' | 'sponsored_click', placement: SponsoredPlacement): void;
  getCampaignStats(restaurantId: string | null, days?: number): Promise<CampaignStats[]>;

  // ─── Admin fatturazione ────────────────────────────────────
  adminListSubscriptions(filter?: AdminSubscriptionFilter): Promise<AdminSubscriptionRow[]>;
  adminGrantPlan(restaurantId: string, plan: PlanCode, expiresAt: string | null, source: 'manual' | 'admin' | 'promo', note?: string | null): Promise<void>;
  adminRevokePlan(subscriptionId: string): Promise<void>;
  adminExtendManualPlan(subscriptionId: string, expiresAt: string | null): Promise<void>;
  adminBilling<T = Row>(action: 'status' | 'sync' | 'sync_all' | 'extend_trial' | 'provision_prices' | 'refresh_plans', payload?: Row): Promise<T>;
  getRevenueStats(): Promise<RevenueStats>;
  listStripeEvents(limit?: number): Promise<StripeEventLog[]>;

  // ─── Assistente AI (Fase 6) ────────────────────────────────
  /** Produzione: POST /api/ai/chat (Netlify Function). DEMO: stesso motore nel browser, senza modello. */
  aiChat(input: AiChatInput, signal?: AbortSignal): Promise<AiChatReply>;
  aiHistory(sessionId: string, restaurantId?: string | null): Promise<{ role: 'user' | 'assistant'; content: string }[]>;
  aiDeleteSession(sessionId: string): Promise<void>;
  getAiPreferences(): Promise<AiPreferences | null>;
  saveAiPreferences(prefs: AiPreferences): Promise<void>;
  deleteAiPreferences(): Promise<void>;
  getAdminAiStats(days?: number): Promise<AiAdminStats>;
  /** "Clienti arrivati dall'AI" (Premium/Top). */
  getRestaurantAiStats(restaurantId: string, days?: number): Promise<RestaurantAiStats>;

  // ─── Fase 7: recensioni ─────────────────────────────────────
  getRestaurantRating(restaurantId: string): Promise<RestaurantRating>;
  /** Media e numero di recensioni pubblicate per più locali (solo quelli che ne hanno). */
  getRestaurantsRating(ids: string[]): Promise<Record<string, { average: number; count: number }>>;
  listReviews(restaurantId: string, opts?: { sort?: ReviewSort; filter?: ReviewFilter; limit?: number; offset?: number }): Promise<{ total: number; items: ReviewItem[] }>;
  getReviewFormStatus(restaurantId: string): Promise<ReviewFormStatus>;
  submitReview(restaurantId: string, input: ReviewInput): Promise<{ id: string; status: string; is_verified: boolean }>;
  updateReview(id: string, input: ReviewInput): Promise<{ id: string; status: string }>;
  voteReview(id: string, on: boolean): Promise<number>;
  reportReview(id: string, reason: ReviewReportReason, details?: string | null): Promise<void>;
  respondToReview(reviewId: string, content: string): Promise<void>;
  listManagedReviews(restaurantId: string, opts?: { limit?: number; offset?: number }): Promise<{ rating: RestaurantRating; items: ManagedReview[] }>;
  adminListReviews(status?: string | null): Promise<AdminReview[]>;
  moderateReview(id: string, action: 'publish' | 'hide' | 'reject' | 'restore', note?: string | null): Promise<void>;

  // ─── Fase 7: AsiaPoints, premi, badge ──────────────────────
  getLoyaltyWallet(opts?: { limit?: number; offset?: number }): Promise<LoyaltyWallet>;
  listRewards(): Promise<Reward[]>;
  redeemReward(rewardId: string): Promise<RedeemResult>;
  getMyAchievements(): Promise<Achievement[]>;
  adminLoyaltyAdjust(userId: string, points: number, reason: string): Promise<number>;
  adminListRedemptions(): Promise<(Row & { reward_title: string; user_name: string })[]>;
  adminUpdateRedemption(id: string, status: 'used' | 'cancelled'): Promise<void>;

  // ─── Fase 7: inviti ────────────────────────────────────────
  getMyReferrals(): Promise<ReferralSummary>;
  applyReferralCode(code: string): Promise<{ status: string }>;
  createBusinessReferral(restaurantId: string, email: string, name?: string | null): Promise<{ id: string; code: string }>;
  listBusinessReferrals(restaurantId?: string | null): Promise<BusinessReferral[]>;
  adminListReferrals(status?: string | null): Promise<AdminReferral[]>;
  adminReferralAction(id: string, action: 'invalidate' | 'qualify', reason?: string | null): Promise<void>;
  adminBusinessReferralUpdate(id: string, patch: { status: BusinessReferral['status']; reward_type?: BusinessReferral['reward_type']; reward_value?: number | null; note?: string | null }): Promise<void>;

  // ─── Fase 7: notifiche, push, follow ───────────────────────
  listNotificationsPage(opts: { limit: number; offset: number; unreadOnly?: boolean }): Promise<{ items: AppNotification[]; unread: number }>;
  getNotificationPrefs(): Promise<NotificationPrefs>;
  saveNotificationPrefs(patch: Partial<NotificationPrefs>): Promise<NotificationPrefs>;
  savePushSubscription(sub: PushSubscriptionInput): Promise<void>;
  removePushSubscription(endpoint: string): Promise<void>;
  /** Evento significativo di accesso (DAU/WAU/MAU): uno al giorno, lato server. */
  recordActivity(): Promise<void>;
  trackCampaignClick(deliveryId: string): Promise<void>;
  getFollowState(restaurantId: string): Promise<{ favorite: boolean; following: boolean }>;
  setFollow(restaurantId: string, on: boolean): Promise<boolean>;

  // ─── Fase 7: campagne ──────────────────────────────────────
  campaignAudienceCount(scope: 'platform' | 'restaurant', restaurantId: string | null, target: CampaignTarget, targeting?: Record<string, string>): Promise<number>;
  createCampaign(input: CampaignInput): Promise<{ id: string; status: string; audience: number }>;
  cancelCampaign(id: string): Promise<void>;
  listCampaigns(filter: { scope: 'platform' | 'restaurant'; restaurantId?: string | null }): Promise<Campaign[]>;
  getPushCampaignStats(id: string): Promise<PushCampaignStats>;

  // ─── Fase 7: statistiche e scheduler ───────────────────────
  getRetentionStats(days?: number): Promise<RetentionStats>;
  getRestaurantEngagementStats(restaurantId: string, days?: number): Promise<RestaurantEngagementStats>;
  /** Solo Admin: esegue subito il giro dello scheduler (promemoria, richieste recensione, campagne). */
  runEngagementTick(): Promise<EngagementTickResult>;

  // ─── Fase 8: ordini (takeaway e delivery) ──────────────────
  /** Info pubbliche sugli ordini online del ristorante (tipi attivi, pausa, zone, primo orario). */
  getOrderInfo(restaurantId: string): Promise<OrderPublicInfo>;
  getOrderableRestaurants(): Promise<OrderableRestaurant[]>;
  getRestaurantsDeliveringTo(lat: number, lng: number): Promise<{ restaurant_id: string; distance_km: number; delivery_fee: number }[]>;
  getMenuOptionGroups(restaurantId: string): Promise<MenuOptionGroup[]>;
  getOrderSlots(restaurantId: string, date: string, type: OrderType): Promise<Slot[]>;
  /** Preventivo calcolato dal server (prezzi, sconti, consegna, totale). */
  quoteOrder(input: QuoteInput): Promise<Quote>;
  /** Crea l'ordine "in attesa di pagamento" (server) e prepara il pagamento. */
  placeOrder(input: QuoteInput & { idempotency_key: string }): Promise<CheckoutResult>;
  /** Riprende un pagamento non completato (client_secret del PaymentIntent esistente; null in DEMO). */
  resumeOrderPayment(orderId: string, token: string | null): Promise<{ client_secret: string | null }>;
  /** Solo DEMO: pagamento simulato (nessun addebito). */
  demoPayOrder(orderNumber: string, token: string | null, card: string): Promise<OrderView>;
  trackOrder(orderNumber: string, token: string | null): Promise<OrderView | null>;
  cancelOrderAsCustomer(orderNumber: string, token: string | null, reason?: string | null): Promise<{ refund_pending: boolean }>;
  reportOrderIssue(orderNumber: string, token: string | null, type: IssueType, description: string): Promise<void>;
  listMyOrders(limit?: number, offset?: number): Promise<{ total: number; items: MyOrderSummary[] }>;
  listAddresses(): Promise<CustomerAddress[]>;
  saveAddress(input: AddressInput & { is_default?: boolean }): Promise<CustomerAddress>;
  deleteAddress(id: string): Promise<void>;
  saveCart(payload: { restaurant_id: string; items: unknown[] } | null): Promise<void>;
  loadCart(): Promise<{ restaurant_id: string; items: unknown[] } | null>;
  /** Terminale ordini del ristorante (dati personali minimizzati). */
  listRestaurantOrders(restaurantId: string, tab: RestaurantOrderTab): Promise<RestaurantOrdersPage>;
  orderAction(orderId: string, action: 'accept' | 'reject' | 'preparing' | 'ready' | 'out_for_delivery' | 'complete' | 'cancel' | 'note', payload?: Record<string, unknown>): Promise<{ status: string; refund_pending?: boolean }>;
  refundOrder(orderId: string, amount: number, reason: string): Promise<void>;
  setOrderPause(restaurantId: string, kind: 'all' | 'delivery' | 'takeaway' | 'busy', minutes: number | null): Promise<void>;
  setMenuItemAvailability(itemId: string, mode: 'today' | 'off' | 'on'): Promise<void>;
  getOrderSettings(restaurantId: string): Promise<{ settings: RestaurantOrderSettings | null; zones: DeliveryZone[] }>;
  saveOrderSettings(restaurantId: string, patch: Partial<RestaurantOrderSettings>): Promise<RestaurantOrderSettings>;
  saveDeliveryZone(restaurantId: string, zone: Partial<DeliveryZone>): Promise<DeliveryZone>;
  deleteDeliveryZone(restaurantId: string, id: string): Promise<void>;
  listAllOptionGroups(restaurantId: string): Promise<MenuOptionGroup[]>;
  saveOptionGroup(restaurantId: string, group: Omit<Partial<MenuOptionGroup>, 'options'> & { menu_item_id: string; options: { id?: string; name: string; price: number; is_available?: boolean }[] }): Promise<MenuOptionGroup>;
  deleteOptionGroup(restaurantId: string, id: string): Promise<void>;
  getPayoutStatus(restaurantId: string): Promise<PayoutStatus>;
  /** Stripe Connect: URL di onboarding (null in DEMO: onboarding simulato). */
  startPayoutOnboarding(restaurantId: string): Promise<{ url: string | null; simulated?: boolean }>;
  refreshPayoutStatus(restaurantId: string): Promise<PayoutStatus>;
  openPayoutDashboard(restaurantId: string): Promise<{ url: string | null }>;
  getRestaurantOrderStats(restaurantId: string, days?: number): Promise<RestaurantOrderStats>;
  // Admin
  adminListOrders(filters: AdminOrderFilters): Promise<{ total: number; items: AdminOrderRow[] }>;
  adminOrderDetail(orderId: string): Promise<AdminOrderDetail>;
  adminOrderUpdate(orderId: string, patch: { internal_notes?: string; issue_id?: string; issue_status?: string; resolution?: string }): Promise<void>;
  adminResyncPayment(orderId: string): Promise<string>;
  getMarketplaceStats(days?: number): Promise<MarketplaceStats>;
  getCommissionSettings(): Promise<CommissionSettings>;
  saveGlobalCommission(p: { percent: number; fixed: number; service_fee_enabled: boolean; service_fee_amount: number }): Promise<void>;
  addCommissionOverride(p: { restaurant_id: string; percentage_fee: number; fixed_fee: number; note?: string | null }): Promise<void>;
  runOrdersTick(): Promise<OrdersTickResult>;

  // ─── Fase 9: logistica Rider AsiaFood ──────────────────────
  riderApply(input: RiderApplyInput): Promise<{ status: string }>;
  /** Documento nello storage PRIVATO (solo il Rider e l'Admin possono leggerlo). */
  riderUploadDocument(type: RiderDocumentType, file: File, expiresAt: string | null): Promise<void>;
  getRiderHome(): Promise<RiderHome>;
  riderSetOnline(online: boolean, locationConsent: boolean): Promise<{ is_online: boolean }>;
  riderSendLocation(p: LocationInput): Promise<LocationResult>;
  riderRespondOffer(assignmentId: string, accept: boolean, reason?: string | null): Promise<{ status: string; delivery_job_id?: string }>;
  getRiderJob(id: string): Promise<RiderJob>;
  riderJobAction(id: string, action: RiderJobAction, payload?: Record<string, unknown>): Promise<RiderJob | { id: string; status: string }>;
  /** Foto del pacco consegnato (mai del cliente), storage privato. */
  riderUploadProof(jobId: string, file: File): Promise<string>;
  getRiderEarnings(): Promise<RiderEarningsSummary>;
  /** ETA con provider di percorsi (backend, facoltativo). */
  refreshDeliveryEta(jobId: string): Promise<void>;
  getOrderDelivery(orderNumber: string, token: string | null): Promise<OrderDeliveryView | null>;
  rateDelivery(orderNumber: string, rating: number, comment?: string | null): Promise<void>;
  getRestaurantDeliveries(restaurantId: string): Promise<RestaurantDelivery[]>;
  adminListRiders(f?: { status?: string; q?: string }): Promise<AdminRiderRow[]>;
  adminRiderDetail(id: string): Promise<AdminRiderDetail>;
  adminRiderAction(id: string, action: 'approve' | 'reject' | 'suspend' | 'reactivate' | 'deactivate' | 'note', reason?: string | null): Promise<void>;
  adminReviewRiderDocument(id: string, status: 'approved' | 'rejected' | 'expired', note?: string | null): Promise<void>;
  /** URL temporaneo (firmato) per visualizzare un documento: null in DEMO (nessun file reale). */
  adminRiderDocumentUrl(path: string): Promise<string | null>;
  getDispatchBoard(): Promise<DispatchBoard>;
  adminAssignDelivery(jobId: string, riderId: string): Promise<void>;
  adminDeliveryAction(jobId: string, action: 'redispatch' | 'release' | 'mark_failed' | 'mark_delivered' | 'cancel', payload?: Record<string, unknown>): Promise<void>;
  adminDeliveryDetail(idOrOrderId: string): Promise<AdminJobDetail>;
  adminListEarnings(): Promise<(RiderEarningItem & { rider_id: string; rider_name: string })[]>;
  adminEarningAction(id: string, action: 'approve' | 'mark_paid' | 'adjust' | 'bonus' | 'cancel', amount?: number | null, note?: string | null): Promise<void>;
  adminEarningCreate(jobId: string, amount: number, note: string): Promise<void>;
  adminSetRestaurantLogistics(restaurantId: string, enabled: boolean): Promise<void>;
  getLogisticsStats(days?: number): Promise<LogisticsStats>;
  runLogisticsTick(): Promise<LogisticsTickResult>;
  getLogisticsSettings(): Promise<LogisticsSettings>;
  saveLogisticsSettings(patch: Partial<LogisticsSettings>): Promise<void>;
  listServiceZones(): Promise<ServiceZone[]>;
  saveServiceZone(z: Partial<ServiceZone>): Promise<ServiceZone>;
  deleteServiceZone(id: string): Promise<void>;
  listCompensationRules(): Promise<CompensationRule[]>;
  saveCompensationRule(k: Partial<CompensationRule>): Promise<CompensationRule>;
  updateLogisticsAlert(id: string, status: 'acknowledged' | 'resolved'): Promise<void>;

  // ─── Fase 11: piattaforma, privacy, supporto, monitoraggio ───
  /** Impostazioni pubbliche a runtime (manutenzione, beta, feature flag, dati legali, versioni informative). */
  getRuntimeConfig(): Promise<RuntimeConfig>;
  recordConsent(choices: ConsentChoices, anonymousId: string | null, source: 'banner' | 'settings' | 'signup'): Promise<ConsentState>;
  getMyConsents(): Promise<ConsentState>;
  exportMyData(): Promise<DataExportResult>;
  getPrivacyStatus(): Promise<PrivacyStatus>;
  /** Richiede la password (ri-autenticazione) prima di programmare la cancellazione. */
  requestAccountDeletion(password: string, reason?: string | null): Promise<DeletionRequest>;
  cancelAccountDeletion(): Promise<boolean>;
  createSupportTicket(input: SupportTicketInput): Promise<{ reference: string }>;
  getMySupportTickets(): Promise<SupportTicket[]>;
  reportClientError(e: ClientErrorReport): void;
  recordWebVital(v: WebVitalReport): void;
  /** Slug storico → slug attuale (redirect 301 lato client/di build). */
  getSlugRedirect(slug: string): Promise<string | null>;
  redeemBetaInvite(token: string): Promise<boolean>;
  recordAdminSession(): void;
  getSystemStatus(): Promise<SystemStatus>;
  adminSetFlag(flag: string, value: boolean): Promise<void>;
  getLaunchChecklist(): Promise<LaunchChecklist>;
  setLaunchCheck(key: string, status: CheckStatus, notes?: string | null): Promise<void>;
  adminSupportTickets(filter: SupportFilter, limit?: number, offset?: number): Promise<{ total: number; rows: AdminSupportTicket[] }>;
  adminSupportUpdate(id: string, patch: Partial<Pick<AdminSupportTicket, 'status' | 'priority' | 'admin_notes' | 'resolution' | 'assigned_to'>>): Promise<void>;
  adminPrivacyRequests(): Promise<PrivacyRequests>;
  adminDeletionAction(id: string, action: 'retry' | 'cancel'): Promise<void>;
  adminRetryJob(id: string): Promise<void>;
  adminAuditList(kind: 'admin' | 'security', limit?: number, offset?: number, action?: string | null): Promise<{ total: number; rows: AuditRow[] }>;
  getConsistencyReport(): Promise<ConsistencyReport>;
  adminCreateBetaInvite(email: string | null, role: string, days: number): Promise<{ id: string; token: string }>;
  adminCreateLegalVersion(type: LegalDocumentType, version: string, url: string, isDraft: boolean): Promise<void>;

  // ─── Import ────────────────────────────────────────────────
  getRestaurantsForMatching(cityIds: string[]): Promise<ExistingRestaurant[]>;
  importRestaurant(op: ImportOperation, batchId?: string | null): Promise<ImportResult>;
  createImportBatch(batch: Partial<ImportBatch>): Promise<ImportBatch>;
  listImportBatches(): Promise<ImportBatch[]>;
}

export type { RestaurantClaim };
import type {
  AddressInput, AdminOrderDetail, AdminOrderFilters, AdminOrderRow, CheckoutResult, CommissionSettings, CustomerAddress, DeliveryZone, IssueType, MarketplaceStats,
  MenuOptionGroup, MyOrderSummary, OrderPublicInfo, OrderType, OrderView, OrderableRestaurant, OrdersTickResult, PayoutStatus, Quote, QuoteInput,
  RestaurantOrderSettings, RestaurantOrderStats, RestaurantOrdersPage, RestaurantOrderTab, Slot,
} from '@/types/orders';
import type {
  AdminJobDetail, AdminRiderDetail, AdminRiderRow, CompensationRule, DispatchBoard, LocationInput, LocationResult, LogisticsSettings, LogisticsStats,
  LogisticsTickResult, OrderDeliveryView, RestaurantDelivery, RiderApplyInput, RiderDocumentType, RiderEarningItem, RiderEarningsSummary, RiderHome, RiderJob,
  RiderJobAction, ServiceZone,
} from '@/types/logistics';
import type {
  AdminSupportTicket, AuditRow, CheckStatus, ClientErrorReport, ConsentChoices, ConsentState, ConsistencyReport, DataExportResult, DeletionRequest,
  LaunchChecklist, LegalDocumentType, PrivacyRequests, PrivacyStatus, RuntimeConfig, SupportFilter, SupportTicket, SupportTicketInput, SystemStatus,
  WebVitalReport,
} from '@/types/platform';
