// ─────────────────────────────────────────────────────────────
//  Client degli endpoint di fatturazione (Netlify Functions).
//  Il browser invia solo il JWT Supabase e identificativi interni
//  (restaurant_id, codice piano, intervallo): prezzi, clienti e
//  abbonamenti Stripe li risolve il server dal database.
// ─────────────────────────────────────────────────────────────
import { BILLING } from '@/config/app';
import { supabase } from '@/lib/supabase';
import { readApiError } from '@/lib/errors';

export class BillingApiError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly status: number,
    readonly requestId?: string,
  ) {
    super(message);
    this.name = 'BillingApiError';
  }
}

export async function billingCall<T>(endpoint: 'checkout' | 'portal' | 'actions' | 'admin', body: Record<string, unknown>): Promise<T> {
  if (!BILLING.enabled) throw new BillingApiError('NOT_CONFIGURED', 'I pagamenti online non sono ancora attivi.', 503);
  const token = supabase ? (await supabase.auth.getSession()).data.session?.access_token : null;
  if (!token) throw new BillingApiError('UNAUTHORIZED', 'Accedi per continuare.', 401);
  let res: Response;
  try {
    res = await fetch(`${BILLING.apiBase}/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
  } catch {
    throw new BillingApiError('NETWORK', 'Connessione non disponibile. Controlla la rete e riprova.', 0);
  }
  let json: unknown;
  try {
    json = await res.json();
  } catch {
    json = null;
  }
  if (!res.ok) {
    const fallback = res.status === 404 ? 'Il servizio di pagamento non è disponibile su questo ambiente.' : 'Si è verificato un errore. Riprova tra poco.';
    const e = readApiError(json, res.status, fallback);
    throw new BillingApiError(e.code, e.message, res.status, e.requestId);
  }
  return json as T;
}
