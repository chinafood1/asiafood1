// ─────────────────────────────────────────────────────────────
//  Sorgente DEMO: database in memoria inizializzato dai dati in
//  src/data, persistito in localStorage. Usata quando Supabase
//  non è configurato. Stesso contratto di supabaseSource e stesse
//  regole di business (claim, membri, import) in forma semplificata.
// ─────────────────────────────────────────────────────────────
import * as demo from '@/data/demo';
import * as ref from '@/data/reference';
import type { ExistingRestaurant } from '@/lib/import/plan';
import type {
  AnalyticsEventType,
  AppEventType,
  AppNotification,
  CouponClaim,
  CouponClaimView,
  MenuItemAddon,
  MenuItemVariant,
  PlanFeature,
  PlanUpgradeRequest,
  Reservation,
  ReservationSettings,
  ReservationSlot,
  ReservationStatus,
  RestaurantClosure,
  Category,
  ChangeRequest,
  City,
  ClaimMessage,
  ClaimWithRestaurant,
  Coupon,
  ImportBatch,
  Menu,
  MenuCategory,
  MenuItem,
  Offer,
  Profile,
  Province,
  Region,
  Restaurant,
  RestaurantCategory,
  RestaurantClaim,
  RestaurantDetail,
  RestaurantHour,
  RestaurantImage,
  RestaurantMember,
  RestaurantReport,
  RestaurantSource,
  RestaurantSummary,
  SponsoredCampaign,
  BillingAccount,
  BillingInvoice,
  BillingActivity,
  BillingPromotion,
  StripeEventLog,
  SponsoredSlot,
  RevenueStats,
  ProfileCompletion,
  BillingOverview,
  AdminSubscriptionRow,
  CampaignStats,
  ChangePreview,
  PlanCode,
  BillingInterval,
  Subscription,
  SubscriptionPlan,
} from '@/types/domain';
import { OPEN_CLAIM_STATUSES } from '@/types/domain';
import { slugify } from '@/lib/format';
import { applyFilters, filterOffers, isOfferActiveNow, resolveQuery } from './filters';
import { PlanError, type FeatureKey } from '@/lib/entitlements';
import { isMenuPublicToday, normalizeAllergens } from '@/lib/menu';
import { ACTIVE_STATUSES, NEXT_STATUSES, addDays, computeAvailability, EMAIL_RE, hhmm, localNow, PHONE_RE, randomCode } from '@/lib/reservations';
import { haversineKm } from '@/lib/geo';
import type { DataSource, ImportResult, Row, TableName } from './types';
// Il motore dell'assistente si carica solo quando serve (bundle iniziale leggero)
import type { DemoAiAccess, DemoUsageRow } from './aiDemo';
const aiDemo = () => import('./aiDemo');
import type { AiPreferences, RestaurantAiStats } from '@/types/ai';
import { createEngagement, type EngagementState } from './engagementDemo';
import { createMarket, type MarketState } from './ordersDemo';
import { createLogistics, logisticsDefaults, type LogisticsState } from './logisticsDemo';
import { createPlatform, type PlatformState, type PlatformAccess } from './platformDemo';
import { createLaunchDemo, launchDefaults, restaurantCompletion, type LaunchState } from './launchDemo';
import { createGrowthDemo, type GrowthState } from './growthDemo';
import { DEFAULT_PREFS } from '@/types/engagement';
import { prepareUpload } from '@/lib/uploads';
import { hasConsent } from '@/lib/consent';
import { AppError } from '@/lib/errors';

export const DEMO_USERS = {
  admin: '00000000-0000-4000-8000-00000000ad01',
  owner: '00000000-0000-4000-8000-00000000ad02',
  customer: '00000000-0000-4000-8000-00000000ad03',
  rider: '00000000-0000-4000-8000-00000000ad04',
  riderCandidate: '00000000-0000-4000-8000-00000000ad05',
} as const;

interface DemoDB {
  version: number;
  settings: Record<string, unknown>;
  regions: Region[];
  provinces: Province[];
  cities: City[];
  categories: Category[];
  subscription_plans: SubscriptionPlan[];
  restaurants: Restaurant[];
  restaurant_categories: RestaurantCategory[];
  restaurant_images: RestaurantImage[];
  restaurant_hours: RestaurantHour[];
  restaurant_members: RestaurantMember[];
  restaurant_sources: RestaurantSource[];
  menus: Menu[];
  menu_categories: MenuCategory[];
  menu_items: MenuItem[];
  offers: Offer[];
  coupons: Coupon[];
  sponsored_campaigns: SponsoredCampaign[];
  subscriptions: Subscription[];
  profiles: Profile[];
  favorites: { user_id: string; restaurant_id: string; created_at: string; notifications_enabled?: boolean }[];
  restaurant_claims: RestaurantClaim[];
  claim_messages: ClaimMessage[];
  restaurant_reports: RestaurantReport[];
  import_batches: ImportBatch[];
  change_requests: ChangeRequest[];
  app_events: { event_type: AppEventType; restaurant_id: string | null; source: string | null; metadata: Row; created_at: string; session_id?: string }[];
  analytics: { restaurant_id: string | null; event_type: AnalyticsEventType; source?: string | null; created_at: string; campaign_id?: string; session_id?: string }[];
  // ─── Fase 4 ───
  plan_features: PlanFeature[];
  menu_item_variants: MenuItemVariant[];
  menu_item_addons: MenuItemAddon[];
  reservation_settings: ReservationSettings[];
  reservation_slots: ReservationSlot[];
  restaurant_closures: RestaurantClosure[];
  reservations: Reservation[];
  coupon_claims: CouponClaim[];
  notifications: AppNotification[];
  email_outbox: { id: number; event_type: string; recipient: string; payload: Row; status: 'pending'; created_at: string }[];
  plan_upgrade_requests: PlanUpgradeRequest[];
  // ─── Fase 5 (fatturazione simulata: nessun addebito, nessun dato Stripe reale) ───
  billing_accounts: BillingAccount[];
  billing_invoices: BillingInvoice[];
  billing_activity: (BillingActivity & { id: number; restaurant_id: string | null; subscription_id: string | null })[];
  billing_trials: { restaurant_id: string; user_id: string | null; vat_number: string | null; plan_code: PlanCode; started_at: string; ends_at: string | null; converted_at: string | null }[];
  billing_promotions: BillingPromotion[];
  billing_promotion_redemptions: { promotion_id: string; restaurant_id: string; created_at: string }[];
  stripe_events: StripeEventLog[];
  demo_checkouts: DemoCheckout[];
  // ─── Fase 6 (facoltativi: non richiedono di azzerare i dati demo) ───
  ai_user_preferences?: Record<string, AiPreferences>;
  ai_usage?: DemoUsageRow[];
  // ─── Fase 7 (facoltativo) ───
  engagement?: EngagementState;
  // ─── Fase 8: ordini (facoltativo, inizializzato alla prima lettura) ───
  market?: MarketState;
  logistics?: LogisticsState;
  // ─── Fase 11 (facoltativo) ───
  platform?: PlatformState;
  // ─── Fase 12 (facoltativo) ───
  launch?: LaunchState;
  // ─── Fase 13 (facoltativo) ───
  growth?: GrowthState;
}

/** Sessione di checkout simulata (modalità DEMO). */
interface DemoCheckout {
  id: string;
  restaurant_id: string;
  user_id: string;
  plan: PlanCode;
  interval: BillingInterval;
  trial_days: number;
  require_payment_method: boolean;
  promotion_id: string | null;
  status: 'open' | 'complete' | 'expired';
  subscription_id: string | null;
  created_at: string;
}

const STORAGE_KEY = 'asiafood-demo-db';
const VERSION = 10;
const now = () => new Date().toISOString();
const clone = <T,>(v: T): T => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
const uuid = () => crypto.randomUUID();

function initialDb(): DemoDB {
  const restaurants = clone(demo.demoRestaurants);
  // Il ristoratore demo possiede "Ramen Kōen" (Business) e "Seoul Grill House" (Premium, con prenotazioni)
  const owned = restaurants[1]!;
  const owned2 = restaurants[4]!;
  [owned, owned2].forEach((o) =>
    Object.assign(o, { owner_id: DEMO_USERS.owner, is_verified: true, data_status: 'claimed', claimed_by: DEMO_USERS.owner, claimed_at: '2026-09-05T10:00:00.000Z' }),
  );
  const today = localNow().date;
  const rid = (n: number) => restaurants[n - 1]!.id;
  const reservations: Reservation[] = demo.demoReservationSeeds.map((x, i) => ({
    id: `f7000000-0000-4000-8000-${String(i + 1).padStart(12, '0')}`,
    restaurant_id: rid(x.restaurant),
    user_id: x.customer ? DEMO_USERS.customer : null,
    guest_name: x.name,
    guest_surname: x.surname,
    guest_email: x.customer ? 'cliente@demo.local' : `${x.name}.${x.surname}@example.com`.toLowerCase(),
    guest_phone: `+39 000 111 ${1000 + i}`,
    reservation_date: addDays(today, x.dayOffset),
    reservation_time: x.time,
    party_size: x.party,
    notes: x.notes ?? null,
    status: x.status,
    source: x.source ?? 'web',
    confirmation_code: x.code,
    internal_notes: null,
    created_at: now(),
    confirmed_at: ['confirmed', 'completed', 'no_show'].includes(x.status) ? now() : null,
    cancelled_at: ['cancelled', 'rejected'].includes(x.status) ? now() : null,
  }));
  const coupons = clone(demo.demoCoupons);
  const daysAgo = (d: number) => new Date(Date.now() - d * 86_400_000).toISOString();
  const couponClaims: CouponClaim[] = demo.demoCouponClaims.map((c, i) => {
    const coupon = coupons[c.coupon - 1]!;
    const redeemed = c.redeemedDaysAgo !== undefined;
    coupon.claims_count += 1;
    if (redeemed) coupon.redemptions_count += 1;
    return {
      id: `f8000000-0000-4000-8000-${String(i + 1).padStart(12, '0')}`, coupon_id: coupon.id, restaurant_id: coupon.restaurant_id,
      user_id: c.customer ? DEMO_USERS.customer : null, email: c.customer ? null : c.email!, claim_code: c.code,
      status: redeemed ? 'redeemed' : 'claimed', claimed_at: daysAgo(c.claimedDaysAgo), redeemed_at: redeemed ? daysAgo(c.redeemedDaysAgo!) : null,
    };
  });

  return {
    version: VERSION,
    settings: {
      show_demo_data: true,
      billing_trial_days: 30,
      billing_require_payment_method_for_trial: false,
      billing_payment_grace_period_days: 3,
      billing_trial_expiring_days: 3,
      billing_proration_behavior: 'always_invoice',
      billing_downgrade_timing: 'period_end',
      billing_stripe_environment: 'test',
    },
    regions: clone(ref.regions),
    provinces: clone(ref.provinces),
    cities: clone(ref.cities),
    categories: clone(ref.categories),
    subscription_plans: clone(ref.subscriptionPlans),
    restaurants,
    restaurant_categories: clone(demo.demoRestaurantCategories),
    restaurant_images: clone(demo.demoImages),
    restaurant_hours: clone(demo.demoHours),
    restaurant_members: [owned, owned2].map((o) => ({ id: uuid(), restaurant_id: o.id, user_id: DEMO_USERS.owner, role: 'owner' as const, status: 'active' as const, created_at: '2026-09-05T10:00:00.000Z' })),
    restaurant_sources: [],
    menus: clone(demo.demoMenus),
    menu_categories: clone(demo.demoMenuCategories),
    menu_items: clone(demo.demoMenuItems),
    offers: clone(demo.demoOffers),
    coupons,
    sponsored_campaigns: clone(demo.demoCampaigns),
    subscriptions: clone(demo.demoSubscriptions),
    profiles: [
      { id: DEMO_USERS.admin, role: 'admin', full_name: 'Admin Demo', email: 'admin@demo.local', phone: null, avatar_url: null, city_id: null, is_blocked: false, created_at: '2026-09-01T09:00:00.000Z' },
      { id: DEMO_USERS.owner, role: 'restaurant_owner', full_name: 'Ristoratore Demo', email: 'ristoratore@demo.local', phone: null, avatar_url: null, city_id: null, is_blocked: false, created_at: '2026-09-02T09:00:00.000Z' },
      { id: DEMO_USERS.customer, role: 'customer', full_name: 'Cliente Demo', email: 'cliente@demo.local', phone: null, avatar_url: null, city_id: null, is_blocked: false, created_at: '2026-09-03T09:00:00.000Z' },
      { id: DEMO_USERS.rider, role: 'rider', full_name: 'Rider Demo', email: 'rider@demo.local', phone: null, avatar_url: null, city_id: null, is_blocked: false, created_at: '2026-09-04T09:00:00.000Z' },
      { id: DEMO_USERS.riderCandidate, role: 'customer', full_name: 'Giulia Candidata', email: 'candidata@demo.local', phone: null, avatar_url: null, city_id: null, is_blocked: false, created_at: '2026-09-04T10:00:00.000Z' },
    ],
    favorites: [],
    restaurant_claims: [
      {
        id: uuid(),
        restaurant_id: restaurants[4]!.id,
        user_id: DEMO_USERS.customer,
        status: 'pending',
        first_name: 'Cliente',
        last_name: 'Demo',
        role: 'Titolare',
        business_name: 'Demo S.r.l.',
        vat_number: 'IT00000000000',
        tax_code: null,
        business_email: 'cliente@demo.local',
        phone: '+39 000 000 0000',
        website: null,
        verification_method: 'phone',
        verification_document_url: null,
        message: 'Richiesta dimostrativa: sono il titolare del locale.',
        admin_notes: null,
        submitted_at: '2026-09-20T10:00:00.000Z',
        reviewed_at: null,
        reviewed_by: null,
        approved_at: null,
        rejected_at: null,
        info_requested_at: null,
        created_at: '2026-09-20T10:00:00.000Z',
      },
    ],
    claim_messages: [],
    restaurant_reports: [
      {
        id: uuid(), restaurant_id: restaurants[2]!.id, user_id: null, report_type: 'wrong_hours',
        description: 'Segnalazione dimostrativa: la domenica a pranzo risulta chiuso.', email: null, status: 'open',
        admin_notes: null, resolved_by: null, resolved_at: null, created_at: '2026-09-22T18:00:00.000Z',
      },
    ],
    import_batches: [],
    change_requests: [],
    app_events: [],
    analytics: [],
    plan_features: clone(ref.planFeatures),
    menu_item_variants: clone(demo.demoMenuItemVariants),
    menu_item_addons: clone(demo.demoMenuItemAddons),
    reservation_settings: demo.demoReservationSettings.map((x) => ({
      restaurant_id: rid(x.restaurant), reservation_enabled: true, min_party_size: 1, max_party_size: x.max_party, slot_duration_minutes: 90,
      booking_notice_minutes: x.notice, max_advance_days: 60, auto_confirm: x.auto_confirm, guest_message: x.message,
    })),
    reservation_slots: demo.demoReservationSlots.map((x, i) => ({
      id: `f5000000-0000-4000-8000-${String(i + 1).padStart(12, '0')}`, restaurant_id: rid(x.restaurant), day_of_week: x.day, start_time: x.start,
      end_time: x.end, slot_interval_minutes: x.interval, max_reservations: x.maxRes, max_guests: x.maxGuests, is_active: true, label: x.label,
    })),
    restaurant_closures: demo.demoClosures.map((c, i) => ({
      id: `f6000000-0000-4000-8000-${String(i + 1).padStart(12, '0')}`, restaurant_id: rid(c.restaurant), date: addDays(today, c.dayOffset),
      start_time: c.start, end_time: c.end, reason: c.reason,
    })),
    reservations,
    coupon_claims: couponClaims,
    notifications: reservations
      .filter((x) => x.status === 'pending' && x.restaurant_id === owned2.id)
      .slice(0, 2)
      .map((x) => ({
        id: uuid(), user_id: DEMO_USERS.owner, restaurant_id: x.restaurant_id, type: 'reservation_new', title: 'Nuova prenotazione da confermare',
        body: `${x.guest_name} ${x.guest_surname[0]}. · ${x.party_size} persone · ${x.reservation_date.slice(8, 10)}/${x.reservation_date.slice(5, 7)} alle ${x.reservation_time}`,
        link: `/dashboard/restaurants/${x.restaurant_id}/reservations`, read_at: null, created_at: now(),
      })),
    email_outbox: [],
    plan_upgrade_requests: [],
    billing_accounts: [],
    billing_invoices: [],
    billing_activity: [],
    billing_trials: [],
    billing_promotions: [
      {
        id: 'fa000000-0000-4000-8000-000000000001', code: 'ASIA30', description: 'DEMO — 30 giorni gratis sui piani a pagamento', discount_type: 'free_days',
        discount_value: null, duration: 'once', duration_in_months: null, free_days: 30, applicable_plans: [], max_redemptions: 100, redemptions_count: 0,
        starts_at: '2026-09-01T00:00:00.000Z', ends_at: null, is_active: true, created_at: '2026-09-01T00:00:00.000Z',
      },
    ],
    billing_promotion_redemptions: [],
    stripe_events: [],
    demo_checkouts: [],
  };
}

let db: DemoDB = load();

function load(): DemoDB {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DemoDB;
      if (parsed.version === VERSION) {
        // Nuove funzioni di piano (Fase 7) su database demo già salvati
        for (const f of ref.planFeatures) {
          if (!parsed.plan_features.some((x) => x.plan_code === f.plan_code && x.feature_key === f.feature_key)) parsed.plan_features.push(clone(f));
        }
        return parsed;
      }
    }
  } catch {
    /* storage non disponibile */
  }
  return initialDb();
}

function save() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch {
    /* quota o private mode: si resta in memoria */
  }
}

export function resetDemoData() {
  db = initialDb();
  save();
}

export function getDemoProfile(id: string): Profile | undefined {
  return db.profiles.find((p) => p.id === id);
}

export function upsertDemoProfile(p: Profile) {
  const i = db.profiles.findIndex((x) => x.id === p.id);
  if (i >= 0) db.profiles[i] = { ...db.profiles[i]!, ...p };
  else {
    db.profiles.push(p);
    eng.hooks.profileCreated(p);
    // Fase 12: badge "Founding Foodie" solo mentre è aperto (nessun valore economico)
    const ls = db.launch;
    if (ls && db.settings.founding_foodie_open === true && p.role === 'customer'
        && Object.keys(ls.founding_foodies).length < Number(db.settings.founding_foodie_limit ?? 500)) ls.founding_foodies[p.id] = new Date().toISOString();
  }
  save();
}

/** Utente "loggato" nella demo (per simulare auth.uid() nelle regole). */
const currentUser = () => {
  try {
    return localStorage.getItem('asiafood-demo-session');
  } catch {
    return null;
  }
};
const isAdminUser = () => getDemoProfile(currentUser() ?? '')?.role === 'admin';
const requireAdmin = () => {
  if (!isAdminUser()) throw new Error('Operazione non consentita.');
};

const delay = <T,>(v: T, ms = 120) => new Promise<T>((res) => setTimeout(() => res(clone(v)), ms));
const demoVisible = () => db.settings.show_demo_data !== false;
const isPublic = (r: Restaurant) => r.is_active && (!r.is_demo || demoVisible());

// ─── Piani (specchio di restaurant_has_feature / assert_feature / assert_limit) ───
const planOf = (restaurantId: string) => effectivePlan(restaurantId);
const featureRow = (restaurantId: string, key: FeatureKey) => db.plan_features.find((f) => f.plan_code === planOf(restaurantId) && f.feature_key === key);
const restHasFeature = (restaurantId: string, key: FeatureKey) => !!featureRow(restaurantId, key)?.enabled;
const restLimit = (restaurantId: string, key: FeatureKey): number | null => {
  const f = featureRow(restaurantId, key);
  return !f || !f.enabled ? 0 : f.limit_value;
};
/** Le regole di piano valgono per i ristoratori, non per l'Admin (come nel DB). */
const planRulesApply = () => !!currentUser() && !isAdminUser();
const assertFeature = (restaurantId: string, key: FeatureKey) => {
  if (planRulesApply() && !restHasFeature(restaurantId, key)) throw new PlanError('feature', key);
};
const assertLimit = (restaurantId: string, key: FeatureKey, current: number) => {
  if (!planRulesApply()) return;
  const l = restLimit(restaurantId, key);
  if (l !== null && current >= l) throw new PlanError('limit', key);
};
const canManage = (restaurantId: string) =>
  isAdminUser() || db.restaurant_members.some((m) => m.restaurant_id === restaurantId && m.user_id === currentUser() && m.status === 'active' && m.role !== 'staff');
const requireManage = (restaurantId: string) => {
  if (!canManage(restaurantId)) throw new Error('Operazione non consentita.');
};
// ═══ Fatturazione DEMO: specchio di subscription_grants_access / restaurant_effective_plan ═══
// Nessun addebito e nessun dato Stripe reale: ID con prefisso "demo", fatture senza PDF.
const DAY_MS = 86_400_000;
const LIVE_STATUSES = ['trialing', 'active', 'past_due', 'unpaid', 'paused'];
const setting = <T,>(key: string, fallback: T): T => (db.settings[key] ?? fallback) as T;
const planSort = (code: string | null | undefined) => db.subscription_plans.find((p) => p.code === code)?.sort_order ?? -1;
const demoId = (prefix: string) => `${prefix}_demo${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

function grantsAccess(s: Subscription, t = Date.now()): boolean {
  if (s.source !== 'stripe') return (s.status === 'active' || s.status === 'trialing') && !s.revoked_at && (!s.expires_at || Date.parse(s.expires_at) > t);
  switch (s.status) {
    case 'active':
      return true;
    case 'trialing':
      return !s.trial_end || Date.parse(s.trial_end) > t - DAY_MS;
    case 'past_due':
      return t < Date.parse(s.payment_failed_at ?? s.current_period_end ?? new Date(t).toISOString()) + setting('billing_payment_grace_period_days', 3) * DAY_MS;
    case 'canceled':
      return !s.payment_failed_at && !!s.current_period_end && Date.parse(s.current_period_end) > t;
    default:
      return false;
  }
}
function effectiveSub(rid: string): Subscription | null {
  return (
    db.subscriptions
      .filter((s) => s.restaurant_id === rid && grantsAccess(s))
      .sort((a, b) => planSort(b.plan_code) - planSort(a.plan_code) || Number(b.source === 'stripe') - Number(a.source === 'stripe') || b.created_at.localeCompare(a.created_at))[0] ?? null
  );
}
function effectivePlan(rid: string): PlanCode {
  return effectiveSub(rid)?.plan_code ?? 'free';
}
function refreshPlan(rid: string): PlanCode {
  const r = db.restaurants.find((x) => x.id === rid);
  const p = effectivePlan(rid);
  if (r && r.subscription_plan !== p) r.subscription_plan = p;
  return p;
}
function refreshAllPlans(): number {
  let n = 0;
  db.restaurants.forEach((r) => {
    const before = r.subscription_plan;
    if (refreshPlan(r.id) !== before) n++;
  });
  return n;
}

function campaignLive(c: SponsoredCampaign) {
  const t = localNow().date;
  return (c.status === 'active' || c.status === 'scheduled') && c.start_date <= t && (!c.end_date || c.end_date >= t) && (c.total_budget == null || c.spend < c.total_budget);
}
function campaignDisplayStatus(c: SponsoredCampaign): SponsoredCampaign['status'] {
  const t = localNow().date;
  if ((c.status === 'active' || c.status === 'scheduled') && c.end_date && c.end_date < t) return 'ended';
  if ((c.status === 'active' || c.status === 'scheduled') && c.start_date > t) return 'scheduled';
  return c.status === 'scheduled' ? 'active' : c.status;
}

function billingLog(rid: string | null, subId: string | null, event: BillingActivity['event'], data: Row = {}) {
  db.billing_activity.unshift({ id: db.billing_activity.length + 1, restaurant_id: rid, subscription_id: subId, event, data, created_at: now() });
}
function ownerEmail(rid: string) {
  const m = db.restaurant_members.find((x) => x.restaurant_id === rid && x.role === 'owner' && x.status === 'active');
  const acc = m ? db.billing_accounts.find((a) => a.owner_user_id === m.user_id) : undefined;
  return acc?.billing_email ?? (m ? getDemoProfile(m.user_id)?.email ?? null : null);
}
function billingNotify(rid: string, title: string, body: string, emailEvent?: string) {
  notifyRestaurant(rid, 'billing', title, body, `/dashboard/restaurants/${rid}/billing`);
  if (emailEvent) enqueueEmail(emailEvent, ownerEmail(rid), { title, body, restaurant_id: rid });
}
/** Registro "webhook" simulato: mostra in Admin → Sistema cosa avrebbe inviato Stripe. */
function demoEvent(type: string, objectId: string | null, rid: string | null) {
  db.stripe_events.unshift({
    id: uuid(), stripe_event_id: demoId('evt'), event_type: type, stripe_environment: 'test', object_id: objectId, restaurant_id: rid,
    processing_status: 'processed', error_message: null, attempts: 1, created_at: now(), processed_at: now(),
  });
  db.stripe_events = db.stripe_events.slice(0, 200);
}
const canBill = (rid: string) =>
  isAdminUser() || db.restaurant_members.some((m) => m.restaurant_id === rid && m.user_id === currentUser() && m.status === 'active' && m.role === 'owner');
function requireBill(rid: string) {
  if (!currentUser()) throw new Error('Accedi per continuare.');
  if (!db.restaurants.some((r) => r.id === rid)) throw new Error('Locale non trovato.');
  if (!canBill(rid)) throw new Error('Non hai i permessi per gestire la fatturazione di questo locale. Serve il ruolo di titolare.');
}
function stripeSubOf(rid: string): Subscription | null {
  return (
    db.subscriptions
      .filter((s) => s.restaurant_id === rid && s.source === 'stripe')
      .sort((a, b) => Number(LIVE_STATUSES.includes(b.status)) - Number(LIVE_STATUSES.includes(a.status)) || b.created_at.localeCompare(a.created_at))[0] ?? null
  );
}
function liveStripeSub(rid: string) {
  const s = stripeSubOf(rid);
  if (!s || !['trialing', 'active', 'past_due'].includes(s.status)) throw new Error('Nessun abbonamento attivo da modificare.');
  return s;
}
function planPriceCents(code: PlanCode, interval: BillingInterval) {
  const p = db.subscription_plans.find((x) => x.code === code);
  return Math.round(((interval === 'year' ? p?.yearly_price : p?.monthly_price) ?? 0) * 100);
}
function trialEligible(rid: string, uid: string | null) {
  return !db.billing_trials.some((t) => t.restaurant_id === rid || (uid && t.user_id === uid)) && !db.subscriptions.some((s) => s.restaurant_id === rid && s.source === 'stripe' && s.trial_start);
}
function ensureAccount(uid: string): BillingAccount {
  let a = db.billing_accounts.find((x) => x.owner_user_id === uid);
  if (!a) {
    a = {
      id: uuid(), owner_user_id: uid, stripe_customer_id: null, stripe_environment: null, business_name: null, vat_number: null, tax_code: null,
      billing_email: getDemoProfile(uid)?.email ?? null, pec: null, recipient_code: null, address_line: null, postal_code: null, city: null, province: null,
      country: 'IT', created_at: now(), updated_at: now(),
    };
    db.billing_accounts.push(a);
  }
  return a;
}
function demoInvoice(sub: Subscription, amountCents: number, status: 'paid' | 'open' = 'paid'): BillingInvoice {
  const inv: BillingInvoice = {
    id: uuid(), stripe_invoice_id: demoId('in'), subscription_id: sub.id, restaurant_id: sub.restaurant_id, billing_account_id: sub.billing_account_id,
    number: `DEMO-${String(db.billing_invoices.length + 1).padStart(4, '0')}`, status, amount_due_cents: amountCents, amount_paid_cents: status === 'paid' ? amountCents : 0,
    currency: 'EUR', hosted_invoice_url: null, invoice_pdf: null, period_start: sub.current_period_start, period_end: sub.current_period_end,
    stripe_created_at: now(), stripe_environment: 'test',
  };
  db.billing_invoices.unshift(inv);
  sub.latest_invoice_id = inv.stripe_invoice_id;
  sub.latest_invoice_status = status;
  demoEvent(status === 'paid' ? 'invoice.paid' : 'invoice.payment_failed', inv.stripe_invoice_id, sub.restaurant_id);
  return inv;
}
const addPeriod = (from: number, interval: BillingInterval) => new Date(from + (interval === 'year' ? 365 : 30) * DAY_MS).toISOString();
const planName = (code: string) => db.subscription_plans.find((p) => p.code === code)?.name ?? code;
const itDate = (iso: string | null) => (iso ? new Date(iso).toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' }) : '');
function demoSessionId() {
  try {
    let id = sessionStorage.getItem('af_sid');
    if (!id) {
      id = crypto.randomUUID();
      sessionStorage.setItem('af_sid', id);
    }
    return id;
  } catch {
    return 'no-session';
  }
}
function findPromotion(code: string | null | undefined, plan: PlanCode, rid: string): BillingPromotion | null {
  if (!code?.trim()) return null;
  const p = db.billing_promotions.find((x) => x.code === code.trim().toUpperCase());
  const t = Date.now();
  if (
    !p || !p.is_active || Date.parse(p.starts_at) > t || (p.ends_at && Date.parse(p.ends_at) <= t) ||
    (p.max_redemptions != null && p.redemptions_count >= p.max_redemptions) ||
    (p.applicable_plans.length && !p.applicable_plans.includes(plan)) ||
    db.billing_promotion_redemptions.some((r) => r.promotion_id === p.id && r.restaurant_id === rid)
  ) {
    throw new Error('Codice promozionale non valido, scaduto o già utilizzato.');
  }
  return p;
}

const offerLive = (o: Offer) => isOfferActiveNow(o);
const couponLive = (c: Coupon) => c.is_active && new Date(c.valid_from) <= new Date() && (!c.valid_until || new Date(c.valid_until) > new Date());

function notifyRestaurant(restaurantId: string, type: string, title: string, body: string, link: string) {
  db.restaurant_members
    .filter((m) => m.restaurant_id === restaurantId && m.status === 'active' && m.role !== 'staff')
    .forEach((m) => db.notifications.unshift({ id: uuid(), user_id: m.user_id, restaurant_id: restaurantId, type, title, body, link, read_at: null, created_at: now() }));
}
function notifyAdmins(type: string, title: string, body: string, link: string) {
  db.profiles.filter((p) => p.role === 'admin').forEach((p) => db.notifications.unshift({ id: uuid(), user_id: p.id, restaurant_id: null, type, title, body, link, read_at: null, created_at: now() }));
}
function enqueueEmail(event: string, recipient: string | null, payload: Row) {
  if (!recipient) return;
  db.email_outbox.push({ id: db.email_outbox.length + 1, event_type: event, recipient: recipient.toLowerCase(), payload, status: 'pending', created_at: now() });
}
const logEvent = (restaurantId: string, type: AnalyticsEventType, source = 'web') => db.analytics.push({ restaurant_id: restaurantId, event_type: type, source, created_at: now() });

/** Blocca dal client le conversioni (le registra solo il "server") e rimappa i nomi della Fase 1. */
const LEGACY_EVENTS: Record<string, AnalyticsEventType> = {
  view: 'restaurant_view', click_phone: 'phone_click', click_whatsapp: 'whatsapp_click', click_directions: 'directions_click',
  click_menu: 'menu_view', click_reservation: 'reservation_start', click_website: 'website_click', click_social: 'social_click', coupon_reveal: 'offer_view',
};

// Documenti di verifica: solo in memoria (mai in localStorage)
const claimDocs = new Map<string, string>();

// ─── Composizione modelli ────────────────────────────────────
function summary(r: Restaurant): RestaurantSummary {
  const city = db.cities.find((c) => c.id === r.city_id);
  const links = db.restaurant_categories.filter((rc) => rc.restaurant_id === r.id).sort((a, b) => Number(b.is_primary) - Number(a.is_primary));
  return {
    ...r,
    city: city ? { id: city.id, name: city.name, slug: city.slug } : null,
    categories: links
      .map((l) => db.categories.find((c) => c.id === l.category_id))
      .filter((c): c is Category => !!c)
      .map(({ id, name, slug, emoji }) => ({ id, name, slug, emoji })),
    hours: db.restaurant_hours.filter((h) => h.restaurant_id === r.id),
    active_offers_count: restHasFeature(r.id, 'offers_enabled') ? db.offers.filter((o) => o.restaurant_id === r.id && isOfferActiveNow(o)).length : 0,
    sponsored_now: r.is_sponsored || db.sponsored_campaigns.some((c) => c.restaurant_id === r.id && campaignLive(c)),
  };
}

function detail(r: Restaurant, includeInactive = false): RestaurantDetail {
  const byOrder = <T extends { display_order: number }>(a: T, b: T) => a.display_order - b.display_order;
  const menus = db.menus
    .filter((m) => m.restaurant_id === r.id && (includeInactive || isMenuPublicToday(m)))
    .sort((a, b) => a.sort_order - b.sort_order)
    .map((m) => ({
      ...m,
      sections: db.menu_categories
        .filter((s) => s.menu_id === m.id && (includeInactive || s.is_active))
        .sort((a, b) => a.sort_order - b.sort_order)
        .map((s) => ({
          ...s,
          items: db.menu_items
            .filter((i) => i.menu_category_id === s.id)
            .sort((a, b) => a.sort_order - b.sort_order)
            .map((i) => ({
              ...i,
              variants: db.menu_item_variants.filter((v) => v.menu_item_id === i.id).sort(byOrder),
              addons: db.menu_item_addons.filter((v) => v.menu_item_id === i.id).sort(byOrder),
            })),
        })),
    }));
  const province = db.provinces.find((p) => p.id === r.province_id);
  const offersOn = restHasFeature(r.id, 'offers_enabled');
  const couponsOn = restHasFeature(r.id, 'coupons_enabled');
  return {
    ...summary(r),
    images: db.restaurant_images.filter((i) => i.restaurant_id === r.id).sort((a, b) => a.sort_order - b.sort_order),
    menus,
    offers: db.offers.filter((o) => o.restaurant_id === r.id && (includeInactive || (offersOn && offerLive(o)))),
    coupons: db.coupons.filter((c) => c.restaurant_id === r.id && (includeInactive || (couponsOn && couponLive(c)))),
    province: province ? { id: province.id, name: province.name, code: province.code } : null,
    sources: db.restaurant_sources.filter((s) => s.restaurant_id === r.id).sort((a, b) => Number(b.is_primary) - Number(a.is_primary)),
    reservation_settings: db.reservation_settings.find((x) => x.restaurant_id === r.id) ?? null,
  };
}

function couponClaimView(x: CouponClaim): CouponClaimView {
  const c = db.coupons.find((y) => y.id === x.coupon_id);
  const r = db.restaurants.find((y) => y.id === x.restaurant_id);
  const expired = x.status === 'claimed' && !!c?.valid_until && new Date(c.valid_until) <= new Date();
  return {
    ...x,
    status: expired ? 'expired' : x.status,
    coupon: c ? { id: c.id, title: c.title, description: c.description, discount_type: c.discount_type, discount_value: c.discount_value, minimum_spend: c.minimum_spend, valid_until: c.valid_until, terms: c.terms } : null,
    restaurant: r ? { id: r.id, name: r.name, slug: r.slug } : null,
  };
}

function claimView(c: RestaurantClaim): ClaimWithRestaurant {
  const r = db.restaurants.find((x) => x.id === c.restaurant_id);
  const p = db.profiles.find((x) => x.id === c.user_id);
  return {
    ...c,
    restaurant: r
      ? { id: r.id, name: r.name, slug: r.slug, address: r.address, phone: r.phone, logo_url: r.logo_url, owner_id: r.owner_id, city_name: db.cities.find((x) => x.id === r.city_id)?.name ?? null }
      : null,
    claimant: p ? { id: p.id, full_name: p.full_name, email: p.email } : null,
  };
}

const TABLE_KEY: Partial<Record<TableName, keyof DemoDB>> = { restaurant_reports: 'restaurant_reports' };
const ENG_TABLES = new Set<TableName>(['loyalty_rules', 'loyalty_levels', 'rewards', 'achievements']);
const table = (name: TableName) =>
  (ENG_TABLES.has(name) ? (engState() as unknown as Record<string, Row[]>)[name] : db[(TABLE_KEY[name] ?? name) as keyof DemoDB]) as unknown as Row[];

// ─── Regole di proprietà (specchio dei trigger SQL) ──────────
function refreshRole(userId: string | null) {
  if (!userId) return;
  const p = db.profiles.find((x) => x.id === userId);
  if (!p || p.role === 'admin') return;
  p.role = db.restaurant_members.some((m) => m.user_id === userId && m.status === 'active') ? 'restaurant_owner' : 'customer';
}

function setOwner(r: Restaurant, userId: string | null) {
  const previous = db.restaurant_members.filter((m) => m.restaurant_id === r.id && m.role === 'owner' && m.status === 'active' && m.user_id !== userId);
  previous.forEach((m) => (m.status = 'revoked'));
  r.owner_id = userId;
  if (userId) {
    const m = db.restaurant_members.find((x) => x.restaurant_id === r.id && x.user_id === userId);
    if (m) Object.assign(m, { role: 'owner', status: 'active' });
    else db.restaurant_members.push({ id: uuid(), restaurant_id: r.id, user_id: userId, role: 'owner', status: 'active', created_at: now() });
  }
  previous.forEach((m) => refreshRole(m.user_id));
  refreshRole(userId);
}

function uniqueSlug(base: string, exclude?: string) {
  const b = slugify(base) || 'ristorante';
  let slug = b;
  let n = 2;
  while (db.restaurants.some((r) => r.slug === slug && r.id !== exclude)) slug = `${b}-${n++}`;
  return slug;
}

function blankRestaurant(): Restaurant {
  return {
    ...clone(demo.demoRestaurants[0]!),
    id: uuid(), owner_id: null, name: '', slug: '', short_description: null, description: null, address: null,
    city_id: '', province_id: null, region_id: null, postal_code: null, latitude: null, longitude: null,
    phone: null, whatsapp: null, email: null, website: null, instagram: null, facebook: null, tiktok: null,
    logo_url: null, cover_url: null, price_range: null, average_price: null,
    is_all_you_can_eat: false, ayce_lunch_price: null, ayce_dinner_price: null, ayce_weekend_price: null,
    has_delivery: false, has_takeaway: false, has_reservation: false, reservation_url: null, services: [],
    is_verified: false, is_active: false, is_featured: false, is_sponsored: false, is_demo: false,
    subscription_plan: 'free', popularity_score: 0, opened_at: null, meta_title: null, meta_description: null,
    source_name: null, source_url: null, external_id: null, google_place_id: null, data_status: 'unverified',
    last_verified_at: null, claimed_at: null, claimed_by: null, verification_notes: null,
    menu_last_verified_at: null, opening_hours_last_verified_at: null, is_temporarily_closed: false, is_permanently_closed: false,
    created_at: now(), updated_at: now(),
  };
}

const IMPORT_FIELDS = new Set([
  'name', 'slug', 'short_description', 'description', 'address', 'city_id', 'postal_code', 'latitude', 'longitude',
  'phone', 'whatsapp', 'email', 'website', 'instagram', 'facebook', 'tiktok', 'logo_url', 'cover_url',
  'price_range', 'average_price', 'is_all_you_can_eat', 'ayce_lunch_price', 'ayce_dinner_price', 'ayce_weekend_price',
  'has_delivery', 'has_takeaway', 'has_reservation', 'reservation_url', 'services',
  'source_name', 'source_url', 'external_id', 'google_place_id', 'data_status', 'last_verified_at',
  'verification_notes', 'opening_hours_last_verified_at', 'menu_last_verified_at',
  'is_active', 'is_temporarily_closed', 'is_permanently_closed', 'opened_at',
]);

/** Regole di scrittura del CRUD generico: specchio delle RLS e dei trigger di piano del DB. */
const COMMERCE_TABLES = new Set<TableName>(['menus', 'menu_categories', 'menu_items', 'menu_item_variants', 'menu_item_addons', 'offers', 'coupons', 'restaurant_images', 'reservation_settings', 'reservation_slots', 'restaurant_closures']);
function guardWrite(name: TableName, data: Row, old: Row | undefined) {
  if (ENG_TABLES.has(name)) {
    requireAdmin();
    return;
  }
  if (name === 'plan_features' || name === 'subscription_plans' || name === 'sponsored_campaigns' || name === 'billing_promotions') {
    requireAdmin();
    if (name === 'billing_promotions') {
      data.code = String(data.code ?? old?.code ?? '').trim().toUpperCase();
      data.redemptions_count = old?.redemptions_count ?? 0;
    }
    return;
  }
  if (!COMMERCE_TABLES.has(name)) return;
  const rid = String(data.restaurant_id ?? old?.restaurant_id ?? '');
  requireManage(rid);
  data.restaurant_id = rid;
  if (['menus', 'menu_categories', 'menu_items', 'menu_item_variants', 'menu_item_addons'].includes(name)) {
    assertFeature(rid, 'menu_enabled');
    if (name === 'menu_items') {
      if (!old) assertLimit(rid, 'max_menu_items', db.menu_items.filter((i) => i.restaurant_id === rid).length);
      if (Array.isArray(data.allergens)) data.allergens = normalizeAllergens(data.allergens as string[]);
      if (data.is_vegan) data.is_vegetarian = true;
    }
  }
  if (name === 'restaurant_images' && !old) assertLimit(rid, 'max_images', db.restaurant_images.filter((i) => i.restaurant_id === rid).length);
  if (name === 'reservation_slots') assertFeature(rid, 'reservations_enabled');
  if (name === 'offers' || name === 'coupons') {
    const isOffer = name === 'offers';
    assertFeature(rid, isOffer ? 'offers_enabled' : 'coupons_enabled');
    const merged = { ...old, ...data } as Row;
    const endKey = isOffer ? 'ends_at' : 'valid_until';
    const live = (x: Row) => !!x.is_active && (!x[endKey] || new Date(String(x[endKey])) > new Date());
    if (live(merged) && (!old || !live(old))) {
      const list = (isOffer ? db.offers : db.coupons) as unknown as Row[];
      assertLimit(rid, isOffer ? 'max_active_offers' : 'max_active_coupons', list.filter((x) => x.restaurant_id === rid && x.id !== merged.id && live(x)).length);
    }
    if (planRulesApply()) {
      data.redemptions_count = old?.redemptions_count ?? 0;
      if (!isOffer) data.claims_count = old?.claims_count ?? 0;
      if (isOffer && data.is_featured && !restHasFeature(rid, 'featured_listing')) data.is_featured = false;
    }
    if (!isOffer && typeof data.code === 'string') data.code = data.code.replace(/\s+/g, '').toUpperCase();
  }
}

// ─── Implementazione ─────────────────────────────────────────
export const demoSource: DataSource = {
  mode: 'demo',
  get launch() {
    return launch;
  },
  get growth() {
    return growth;
  },

  getCategories: () => delay(db.categories.filter((c) => c.is_active).sort((a, b) => a.sort_order - b.sort_order), 0),
  getCities: () => delay(db.cities.filter((c) => c.is_active).sort((a, b) => a.name.localeCompare(b.name)), 0),

  async searchRestaurants(filters) {
    const list = db.restaurants.filter(isPublic).map(summary);
    const { primary, fallback } = resolveQuery(filters, db.categories, db.cities);
    const opts = { categories: db.categories, planBoost: (r: RestaurantSummary) => restLimit(r.id, 'search_boost') ?? 0 };
    let out = applyFilters(list, primary, opts);
    if (!out.length && fallback) out = applyFilters(list, fallback, opts);
    return delay(out);
  },

  async getRestaurantBySlug(slug) {
    const r = db.restaurants.find((x) => x.slug === slug && isPublic(x));
    return delay(r ? detail(r) : null);
  },

  async getRestaurantsByIds(ids) {
    return delay(db.restaurants.filter((r) => ids.includes(r.id) && isPublic(r)).map(summary));
  },

  async getActiveOffers(opts = {}) {
    const rows = db.offers
      .filter((o) => offerLive(o) && restHasFeature(o.restaurant_id, 'offers_enabled'))
      .map((o) => {
        const r = db.restaurants.find((x) => x.id === o.restaurant_id && isPublic(x) && !x.is_permanently_closed);
        if (!r) return null;
        const city = db.cities.find((c) => c.id === r.city_id);
        const category_slugs = db.restaurant_categories
          .filter((rc) => rc.restaurant_id === r.id)
          .map((rc) => db.categories.find((c) => c.id === rc.category_id)?.slug)
          .filter((x): x is string => !!x);
        return {
          ...o,
          restaurant: {
            id: r.id, name: r.name, slug: r.slug, cover_url: r.cover_url, latitude: r.latitude, longitude: r.longitude,
            is_all_you_can_eat: r.is_all_you_can_eat, city_name: city?.name ?? null, city_slug: city?.slug ?? null, category_slugs,
          },
        };
      })
      .filter((x): x is NonNullable<typeof x> => !!x);
    return delay(filterOffers(rows, opts));
  },

  async getCityCounts() {
    const counts: Record<string, number> = {};
    db.restaurants.filter((r) => isPublic(r) && !r.is_permanently_closed).forEach((r) => {
      const slug = db.cities.find((c) => c.id === r.city_id)?.slug;
      if (slug) counts[slug] = (counts[slug] ?? 0) + 1;
    });
    return delay(counts, 0);
  },

  async getCategoryCounts() {
    const counts: Record<string, number> = {};
    const active = new Set(db.restaurants.filter((r) => isPublic(r) && !r.is_permanently_closed).map((r) => r.id));
    db.restaurant_categories.filter((rc) => active.has(rc.restaurant_id)).forEach((rc) => {
      const slug = db.categories.find((c) => c.id === rc.category_id)?.slug;
      if (slug) counts[slug] = (counts[slug] ?? 0) + 1;
    });
    counts['all-you-can-eat'] = db.restaurants.filter((r) => active.has(r.id) && r.is_all_you_can_eat).length;
    return delay(counts, 0);
  },

  async track(restaurantId, type, source) {
    const t = LEGACY_EVENTS[type] ?? type;
    // Le conversioni le registra solo il "server" (create_reservation, claim/redeem coupon)
    if (t === 'reservation_completed' || t === 'coupon_claim' || t === 'coupon_redeem') return;
    if (t === 'sponsored_impression' || t === 'sponsored_click') return;
    // Pagamenti e stati dell'ordine: solo lato "server" (motore ordini)
    if (['payment_success', 'payment_failed', 'order_created', 'order_accepted', 'order_completed', 'order_cancelled', 'abandoned_cart'].includes(t)) return;
    if (!restaurantId && !t.startsWith('ai_')) return;
    db.analytics.push({ restaurant_id: restaurantId, event_type: t, source: source ?? null, created_at: now(), ...(hasConsent('analytics') ? { session_id: demoSessionId() } : {}) });
    if (db.analytics.length > 5000) db.analytics = db.analytics.slice(-5000);
    save();
  },

  trackAppEvent(type, opts = {}) {
    // Mai coordinate nei metadati (specchio della RPC track_app_event)
    let metadata: Row = Object.fromEntries(Object.entries(opts.metadata ?? {}).filter(([k]) => !/(lat|lng|lon|coord|position|location|address|email|phone|name|message|text|query)/i.test(k)));
    const session = hasConsent('analytics') ? demoSessionId() : undefined;
    // Fase 13: "conversion" serve solo al funnel per sessione (tipi ammessi, sessione obbligatoria)
    if (type === 'conversion') {
      if (!session || !['reservation_completed', 'order_completed', 'coupon_claimed'].includes(String(metadata.kind))) return;
      metadata = { kind: metadata.kind };
    }
    db.app_events.push({ event_type: type, restaurant_id: opts.restaurantId ?? null, source: opts.source ?? null, metadata, created_at: now(), ...(session ? { session_id: session } : {}) });
    if (type === 'map_open') db.analytics.push({ restaurant_id: null, event_type: 'map_view', source: opts.source ?? null, created_at: now() });
    if (type === 'restaurant_marker_click' && opts.restaurantId) db.analytics.push({ restaurant_id: opts.restaurantId, event_type: 'map_marker_click', source: opts.source ?? null, created_at: now() });
    if (db.app_events.length > 2000) db.app_events = db.app_events.slice(-2000);
    save();
  },

  async createReport(input) {
    const r = db.restaurants.find((x) => x.id === input.restaurant_id);
    if (!r || !isPublic(r)) throw new Error('Locale non trovato');
    if (input.description.trim().length < 5) throw new Error('Descrivi il problema (almeno 5 caratteri).');
    db.restaurant_reports.push({ ...input, id: uuid(), status: 'open', admin_notes: null, resolved_by: null, resolved_at: null, created_at: now() });
    save();
  },

  // ─── Utente ────────────────────────────────────────────────
  async getFavoriteIds(userId) {
    return delay(db.favorites.filter((f) => f.user_id === userId).map((f) => f.restaurant_id), 0);
  },
  async setFavorite(userId, restaurantId, on) {
    db.favorites = db.favorites.filter((f) => !(f.user_id === userId && f.restaurant_id === restaurantId));
    if (on) db.favorites.push({ user_id: userId, restaurant_id: restaurantId, created_at: now() });
    save();
  },
  async updateMyProfile(userId, patch) {
    const p = db.profiles.find((x) => x.id === userId);
    if (p) {
      Object.assign(p, { full_name: patch.full_name ?? p.full_name, phone: patch.phone ?? p.phone, city_id: patch.city_id ?? p.city_id });
      if (patch.display_name !== undefined) {
        const dn = patch.display_name?.trim() || null;
        if (dn && (dn.length < 2 || dn.length > 40 || dn.includes('@'))) throw new Error('Nome pubblico non valido (2–40 caratteri, niente email).');
        p.display_name = dn;
      }
      eng.hooks.profileUpdated(p);
    }
    save();
  },

  // ─── Rivendicazioni ────────────────────────────────────────
  async uploadClaimDocument(userId, file) {
    const up = await prepareUpload(file, 'document');
    const url = await new Promise<string>((res, rej) => {
      const fr = new FileReader();
      fr.onload = () => res(String(fr.result));
      fr.onerror = () => rej(fr.error);
      fr.readAsDataURL(up.file);
    });
    const path = `${userId}/${up.name}`;
    claimDocs.set(path, url);
    return path;
  },

  async createClaim(input) {
    const r = db.restaurants.find((x) => x.id === input.restaurant_id);
    if (!r || !isPublic(r) || r.owner_id || r.is_permanently_closed) throw new Error('Questo locale non può essere rivendicato.');
    if (db.restaurant_claims.some((c) => c.restaurant_id === input.restaurant_id && c.user_id === input.user_id && OPEN_CLAIM_STATUSES.includes(c.status))) {
      throw new Error('Hai già una richiesta aperta per questo locale.');
    }
    const id = uuid();
    db.restaurant_claims.push({
      ...input, id, status: 'pending', admin_notes: null, submitted_at: now(), reviewed_at: null, reviewed_by: null,
      approved_at: null, rejected_at: null, info_requested_at: null, created_at: now(),
    });
    save();
    return id;
  },

  async getMyClaims(userId) {
    return delay(db.restaurant_claims.filter((c) => c.user_id === userId).sort((a, b) => b.submitted_at.localeCompare(a.submitted_at)).map(claimView));
  },

  async getClaim(id) {
    const c = db.restaurant_claims.find((x) => x.id === id);
    if (!c || (c.user_id !== currentUser() && !isAdminUser())) return delay(null);
    return delay(claimView(c));
  },

  async getClaimMessages(claimId) {
    return delay(db.claim_messages.filter((m) => m.claim_id === claimId).sort((a, b) => a.created_at.localeCompare(b.created_at)));
  },

  async respondToClaim(claimId, message, attachmentPath) {
    const c = db.restaurant_claims.find((x) => x.id === claimId && x.user_id === currentUser());
    if (!c) throw new Error('Richiesta non trovata');
    if (!OPEN_CLAIM_STATUSES.includes(c.status)) throw new Error('La richiesta è chiusa');
    if (!message.trim()) throw new Error('Il messaggio è vuoto');
    db.claim_messages.push({ id: uuid(), claim_id: claimId, author_id: c.user_id, author_role: 'claimant', body: message, attachment_path: attachmentPath ?? null, created_at: now() });
    if (c.status === 'more_information_required') c.status = 'under_review';
    save();
  },

  async getClaimDocumentUrl(path) {
    const url = claimDocs.get(path);
    if (!url) throw new Error('In modalità demo i documenti restano solo nella sessione in cui sono stati caricati.');
    return url;
  },

  // ─── Ristoratore ───────────────────────────────────────────
  async getManagedRestaurants(userId) {
    const mem = db.restaurant_members.filter((m) => m.user_id === userId && m.status === 'active');
    return delay(
      mem
        .map((m) => {
          const r = db.restaurants.find((x) => x.id === m.restaurant_id);
          return r ? { ...summary(r), member_role: m.role } : null;
        })
        .filter((x): x is NonNullable<typeof x> => !!x)
        .sort((a, b) => a.name.localeCompare(b.name)),
    );
  },

  async getRestaurantForEdit(id) {
    const r = db.restaurants.find((x) => x.id === id);
    return delay(r ? detail(r, true) : null);
  },

  async updateRestaurant(id, patch) {
    const r = db.restaurants.find((x) => x.id === id);
    if (!r) throw new Error('Ristorante non trovato');
    const clean: Row = { ...(patch as Row) };
    ['city', 'categories', 'hours', 'images', 'menus', 'offers', 'coupons', 'province', 'sources', 'sponsored_now', 'active_offers_count', 'member_role'].forEach((k) => delete clean[k]);
    // Il piano deriva dagli abbonamenti (Stripe o concessioni Admin): mai impostabile a mano
    delete clean.subscription_plan;
    if (!isAdminUser()) {
      // Specchio del trigger protect_restaurant_admin_fields
      ['owner_id', 'is_verified', 'is_active', 'is_featured', 'is_sponsored', 'is_demo', 'subscription_plan', 'popularity_score', 'slug', 'city_id',
        'data_status', 'source_name', 'source_url', 'external_id', 'google_place_id', 'last_verified_at', 'claimed_at', 'claimed_by',
        'verification_notes', 'is_permanently_closed', 'address', 'postal_code'].forEach((k) => delete clean[k]);
      // Posizione: solo piccole correzioni (≤ 300 m) sul punto esistente
      if ('latitude' in clean || 'longitude' in clean) {
        const lat = (clean.latitude ?? r.latitude) as number | null;
        const lng = (clean.longitude ?? r.longitude) as number | null;
        const ok = r.latitude != null && r.longitude != null && lat != null && lng != null && haversineKm({ lat: r.latitude, lng: r.longitude }, { lat, lng }) <= 0.3;
        if (!ok) {
          delete clean.latitude;
          delete clean.longitude;
        }
      }
    }
    const newOwner = 'owner_id' in clean ? (clean.owner_id as string | null) : undefined;
    delete clean.owner_id;
    // Storico slug (redirect verso il nuovo URL, come il trigger restaurants_slug_history)
    if (typeof clean.slug === 'string' && clean.slug && clean.slug !== r.slug) platform.recordSlugChange(r.id, r.slug, clean.slug);
    Object.assign(r, clean, { updated_at: now() });
    if (newOwner !== undefined && newOwner !== r.owner_id) setOwner(r, newOwner);
    if (clean.city_id) {
      const c = db.cities.find((x) => x.id === clean.city_id);
      if (c) Object.assign(r, { province_id: c.province_id, region_id: c.region_id });
    }
    save();
  },

  async setRestaurantCategories(id, categoryIds, primaryId) {
    db.restaurant_categories = db.restaurant_categories.filter((rc) => rc.restaurant_id !== id);
    categoryIds.forEach((cid) => db.restaurant_categories.push({ restaurant_id: id, category_id: cid, is_primary: cid === primaryId }));
    save();
  },

  async replaceHours(id, hours) {
    db.restaurant_hours = db.restaurant_hours.filter((h) => h.restaurant_id !== id);
    hours.forEach((h) => db.restaurant_hours.push({ ...h, id: uuid(), restaurant_id: id }));
    save();
  },

  async uploadImage(_restaurantId, file) {
    // In demo l'immagine vive solo in questo browser (stessa validazione e compressione della produzione).
    const up = await prepareUpload(file, 'image');
    const url = await new Promise<string>((res, rej) => {
      const fr = new FileReader();
      fr.onload = () => res(String(fr.result));
      fr.onerror = () => rej(fr.error);
      fr.readAsDataURL(up.file);
    });
    return { url, path: null };
  },

  async getRestaurantStats(id, days = 30) {
    const since = Date.now() - days * 86_400_000;
    const out: Partial<Record<AnalyticsEventType, number>> = {};
    db.analytics
      .filter((e) => e.restaurant_id === id && new Date(e.created_at).getTime() >= since)
      .forEach((e) => (out[e.event_type] = (out[e.event_type] ?? 0) + 1));
    return delay(out, 0);
  },

  async listMembers(restaurantId) {
    return delay(
      db.restaurant_members
        .filter((m) => m.restaurant_id === restaurantId)
        .map((m) => {
          const p = db.profiles.find((x) => x.id === m.user_id);
          return { ...m, profile: p ? { id: p.id, full_name: p.full_name, email: p.email } : null };
        }),
    );
  },

  async createChangeRequest(input) {
    const m = db.restaurant_members.find((x) => x.restaurant_id === input.restaurant_id && x.user_id === input.user_id && x.status === 'active' && x.role !== 'staff');
    if (!m || input.user_id !== currentUser()) throw new Error('Operazione non consentita.');
    db.change_requests.unshift({ id: uuid(), restaurant_id: input.restaurant_id, user_id: input.user_id, kind: 'location', payload: input.payload, note: input.note ?? null, status: 'pending', admin_notes: null, reviewed_by: null, reviewed_at: null, created_at: now() });
    save();
  },

  async listChangeRequests(filter = {}) {
    const uid = currentUser();
    return delay(
      db.change_requests
        .filter((c) => isAdminUser() || c.user_id === uid || db.restaurant_members.some((m) => m.restaurant_id === c.restaurant_id && m.user_id === uid && m.status === 'active'))
        .filter((c) => (!filter.status || c.status === filter.status) && (!filter.restaurantId || c.restaurant_id === filter.restaurantId))
        .map((c) => {
          const r = db.restaurants.find((x) => x.id === c.restaurant_id);
          return { ...c, restaurant: r ? { id: r.id, name: r.name, slug: r.slug, address: r.address, latitude: r.latitude, longitude: r.longitude } : null };
        }),
    );
  },

  async reviewChangeRequest(id, approve, notes) {
    requireAdmin();
    const c = db.change_requests.find((x) => x.id === id);
    if (!c || c.status !== 'pending') throw new Error('Richiesta non trovata o già gestita');
    if (approve) {
      const r = db.restaurants.find((x) => x.id === c.restaurant_id);
      if (r) {
        const p = c.payload;
        if ('address' in p) r.address = p.address ?? null;
        if ('postal_code' in p) r.postal_code = p.postal_code ?? null;
        if ('latitude' in p && 'longitude' in p) Object.assign(r, { latitude: p.latitude ?? null, longitude: p.longitude ?? null });
        r.updated_at = now();
      }
    }
    Object.assign(c, { status: approve ? 'approved' : 'rejected', admin_notes: notes ?? null, reviewed_at: now(), reviewed_by: currentUser() });
    save();
  },

  // ─── Fase 4: piani ─────────────────────────────────────────
  async getPlans() {
    return delay(
      [...db.subscription_plans]
        .sort((a, b) => a.sort_order - b.sort_order)
        .map((p) => ({ ...p, plan_features: db.plan_features.filter((f) => f.plan_code === p.code) })),
      0,
    );
  },

  async setPlanFeature(planCode, featureKey, patch) {
    requireAdmin();
    const f = db.plan_features.find((x) => x.plan_code === planCode && x.feature_key === featureKey);
    if (f) Object.assign(f, patch);
    else db.plan_features.push({ id: uuid(), plan_code: planCode, feature_key: featureKey, ...patch });
    const plan = db.subscription_plans.find((p) => p.code === planCode);
    if (plan) {
      plan.features = Object.fromEntries(
        db.plan_features.filter((x) => x.plan_code === planCode).map((x) => [x.feature_key, !x.enabled ? false : x.limit_value ?? true]),
      );
    }
    save();
  },

  async requestPlanUpgrade(input) {
    const uid = currentUser();
    const m = db.restaurant_members.find((x) => x.restaurant_id === input.restaurant_id && x.user_id === uid && x.status === 'active' && x.role !== 'staff');
    if (!uid || !m) throw new Error('Operazione non consentita.');
    if (db.plan_upgrade_requests.some((x) => x.restaurant_id === input.restaurant_id && x.plan_code === input.plan_code && x.status === 'open')) {
      throw new Error('Hai già una richiesta aperta per questo piano: ti ricontatteremo a breve.');
    }
    db.plan_upgrade_requests.unshift({ id: uuid(), restaurant_id: input.restaurant_id, user_id: uid, plan_code: input.plan_code, billing_interval: input.billing_interval, message: input.message ?? null, status: 'open', created_at: now() });
    const r = db.restaurants.find((x) => x.id === input.restaurant_id);
    notifyAdmins('plan_upgrade', 'Richiesta di upgrade piano', `${r?.name ?? ''} chiede il piano ${input.plan_code.toUpperCase()}`, '/admin/plans');
    save();
  },

  async listUpgradeRequests(filter = {}) {
    const uid = currentUser();
    return delay(
      db.plan_upgrade_requests
        .filter((x) => isAdminUser() || x.user_id === uid)
        .filter((x) => (!filter.status || x.status === filter.status) && (!filter.restaurantId || x.restaurant_id === filter.restaurantId))
        .map((x) => {
          const r = db.restaurants.find((y) => y.id === x.restaurant_id);
          const p = db.profiles.find((y) => y.id === x.user_id);
          return {
            ...x,
            restaurant: r ? { id: r.id, name: r.name, slug: r.slug, subscription_plan: r.subscription_plan } : null,
            requester: p ? { id: p.id, full_name: p.full_name, email: p.email } : null,
          };
        }),
    );
  },

  async updateUpgradeRequest(id, status) {
    requireAdmin();
    const x = db.plan_upgrade_requests.find((y) => y.id === id);
    if (x) x.status = status;
    save();
  },

  // ─── Fase 4: prenotazioni ──────────────────────────────────
  async getReservationAvailability(restaurantId, date, partySize) {
    const r = db.restaurants.find((x) => x.id === restaurantId);
    if (!r) return delay({ ok: false, reason: 'Ristorante non trovato.', slots: [] });
    return delay(
      computeAvailability(
        {
          isPublic: isPublic(r) || canManage(r.id),
          closedNow: r.is_temporarily_closed || r.is_permanently_closed,
          hasReservation: r.has_reservation,
          planAllows: restHasFeature(r.id, 'reservations_enabled'),
          settings: db.reservation_settings.find((x) => x.restaurant_id === r.id) ?? null,
          slots: db.reservation_slots.filter((x) => x.restaurant_id === r.id),
          closures: db.restaurant_closures.filter((x) => x.restaurant_id === r.id),
          reservations: db.reservations.filter((x) => x.restaurant_id === r.id),
          tz: r.timezone,
        },
        date,
        partySize,
      ),
    );
  },

  async createReservation(input) {
    const r = db.restaurants.find((x) => x.id === input.restaurant_id);
    if (!r) throw new Error('Ristorante non trovato.');
    const email = input.guest_email.trim().toLowerCase() || null;
    const phone = input.guest_phone.trim();
    const name = input.guest_name.trim();
    const surname = input.guest_surname.trim();
    if (!name || name.length > 60) throw new Error('Inserisci il nome.');
    if (!surname || surname.length > 60) throw new Error('Inserisci il cognome.');
    const source = input.source ?? 'web';
    const manager = source === 'restaurant' || source === 'admin';
    if ((!email && !manager) || (email && (!EMAIL_RE.test(email) || email.length > 254))) throw new Error('Inserisci un indirizzo email valido.');
    if (!PHONE_RE.test(phone)) throw new Error('Inserisci un numero di telefono valido.');
    if ((input.notes ?? '').length > 500) throw new Error('Le note possono contenere al massimo 500 caratteri.');
    if (!input.party_size || input.party_size < 1 || input.party_size > 100) throw new Error('Numero di persone non valido.');
    if (!input.date || !input.time) throw new Error('Scegli data e orario.');
    const st = db.reservation_settings.find((x) => x.restaurant_id === r.id);
    if (manager) {
      requireManage(r.id);
      assertFeature(r.id, 'reservations_enabled');
      if (input.date < localNow(r.timezone).date) throw new Error('Non puoi inserire prenotazioni nel passato.');
    } else {
      const hourAgo = Date.now() - 3_600_000;
      const recent = db.reservations.filter((x) => new Date(x.created_at).getTime() > hourAgo);
      if (recent.filter((x) => x.guest_email === email).length >= 5 || recent.filter((x) => x.guest_phone === phone).length >= 5) {
        throw new Error('Troppe richieste in poco tempo. Riprova più tardi.');
      }
      if (db.reservations.some((x) => x.restaurant_id === r.id && x.reservation_date === input.date && x.guest_email === email && ACTIVE_STATUSES.includes(x.status))) {
        throw new Error('Hai già una prenotazione presso questo ristorante per questa data.');
      }
      const av = await this.getReservationAvailability(r.id, input.date, input.party_size);
      if (!av.ok) throw new Error(av.reason ?? 'Prenotazione non disponibile.');
      const slot = av.slots.find((x) => x.time === hhmm(input.time));
      if (!slot) throw new Error('Orario non valido per questa data.');
      if (slot.status !== 'available') throw new Error('Questo orario non è più disponibile. Scegli un altro orario.');
    }
    const status: ReservationStatus = manager || st?.auto_confirm ? 'confirmed' : 'pending';
    let code = '';
    do code = `ASF-${randomCode(5)}`;
    while (db.reservations.some((x) => x.confirmation_code === code));
    const res: Reservation = {
      id: uuid(), restaurant_id: r.id, user_id: manager ? null : currentUser(), guest_name: name, guest_surname: surname, guest_email: email,
      guest_phone: phone, reservation_date: input.date, reservation_time: hhmm(input.time), party_size: input.party_size,
      notes: input.notes?.trim() || null, status, source, confirmation_code: code, internal_notes: null, created_at: now(),
      confirmed_at: status === 'confirmed' ? now() : null, cancelled_at: null,
    };
    db.reservations.push(res);
    eng.hooks.reservationCreated(res);
    const when = `${input.date.slice(8, 10)}/${input.date.slice(5, 7)} alle ${res.reservation_time}`;
    if (!manager) {
      logEvent(r.id, 'reservation_completed', source);
      notifyRestaurant(r.id, 'reservation_new', status === 'confirmed' ? 'Nuova prenotazione confermata' : 'Nuova prenotazione da confermare',
        `${name} ${surname[0]}. · ${input.party_size} persone · ${when}`, `/dashboard/restaurants/${r.id}/reservations`);
      enqueueEmail('reservation_new_for_restaurant', r.email, { restaurant: r.name, code, date: input.date, time: res.reservation_time });
    }
    enqueueEmail(status === 'confirmed' ? 'reservation_confirmed' : 'reservation_created', email, { restaurant: r.name, code, date: input.date, time: res.reservation_time, party_size: input.party_size });
    save();
    return delay({ id: res.id, code, status, reservation_date: input.date, reservation_time: res.reservation_time, party_size: input.party_size, restaurant_name: r.name, restaurant_slug: r.slug, guest_name: name });
  },

  async cancelReservationByCode(code, email) {
    const x = db.reservations.find((y) => y.confirmation_code === code.trim().toUpperCase() && y.guest_email === email.trim().toLowerCase());
    if (!x) throw new Error('Prenotazione non trovata: controlla codice ed email.');
    if (!ACTIVE_STATUSES.includes(x.status)) throw new Error('Questa prenotazione non può più essere cancellata.');
    if (x.reservation_date < localNow().date) throw new Error('Non puoi cancellare una prenotazione passata.');
    Object.assign(x, { status: 'cancelled', cancelled_at: now() });
    notifyRestaurant(x.restaurant_id, 'reservation_cancelled', 'Prenotazione cancellata dal cliente', `${x.confirmation_code} · ${x.party_size} persone`, `/dashboard/restaurants/${x.restaurant_id}/reservations`);
    enqueueEmail('reservation_cancelled', x.guest_email, { code: x.confirmation_code });
    save();
  },

  async getRestaurantsAvailableOn(opts) {
    const out: { restaurant: RestaurantSummary; first_slot: string; slots_count: number }[] = [];
    const from = opts.from ?? '18:00';
    const candidates = db.restaurants
      .filter((r) => isPublic(r) && r.has_reservation && !r.is_temporarily_closed && !r.is_permanently_closed && restHasFeature(r.id, 'reservations_enabled'))
      .filter((r) => db.reservation_settings.some((x) => x.restaurant_id === r.id && x.reservation_enabled))
      .sort((a, b) => b.popularity_score - a.popularity_score);
    for (const r of candidates) {
      const av = await this.getReservationAvailability(r.id, opts.date ?? localNow(r.timezone).date, opts.partySize ?? 2);
      const free = av.ok ? av.slots.filter((x) => x.status === 'available' && x.time >= from) : [];
      if (free.length) out.push({ restaurant: summary(r), first_slot: free[0]!.time, slots_count: free.length });
      if (out.length >= (opts.limit ?? 12)) break;
    }
    return delay(out);
  },

  async getReservationConfig(restaurantId) {
    requireManage(restaurantId);
    return delay({
      settings: db.reservation_settings.find((x) => x.restaurant_id === restaurantId) ?? null,
      slots: db.reservation_slots.filter((x) => x.restaurant_id === restaurantId).sort((a, b) => a.day_of_week - b.day_of_week || a.start_time.localeCompare(b.start_time)),
      closures: db.restaurant_closures.filter((x) => x.restaurant_id === restaurantId).sort((a, b) => a.date.localeCompare(b.date)),
    });
  },

  async saveReservationSettings(settings) {
    requireManage(settings.restaurant_id);
    if (settings.reservation_enabled) assertFeature(settings.restaurant_id, 'reservations_enabled');
    if (settings.max_party_size < settings.min_party_size) throw new Error('Il massimo di persone deve essere almeno pari al minimo.');
    const i = db.reservation_settings.findIndex((x) => x.restaurant_id === settings.restaurant_id);
    if (i >= 0) db.reservation_settings[i] = { ...settings };
    else db.reservation_settings.push({ ...settings });
    save();
  },

  async listReservations(restaurantId, range = {}) {
    requireManage(restaurantId);
    const rows = db.reservations
      .filter((x) => x.restaurant_id === restaurantId)
      .filter((x) => (!range.from || x.reservation_date >= range.from) && (!range.to || x.reservation_date <= range.to))
      .filter((x) => !range.statuses?.length || range.statuses.includes(x.status))
      .sort((a, b) => (a.reservation_date + a.reservation_time).localeCompare(b.reservation_date + b.reservation_time) * (range.ascending === false ? -1 : 1));
    return delay(range.limit ? rows.slice(0, range.limit) : rows);
  },

  async setReservationStatus(id, status, note) {
    const x = db.reservations.find((y) => y.id === id);
    if (!x) throw new Error('Prenotazione non trovata.');
    const manager = canManage(x.restaurant_id);
    const today = localNow().date;
    if (!manager) {
      if (!x.user_id || x.user_id !== currentUser() || status !== 'cancelled') throw new Error('Operazione non consentita.');
      if (x.reservation_date < today) throw new Error('Non puoi cancellare una prenotazione passata.');
    }
    if (!NEXT_STATUSES[x.status].includes(status)) throw new Error('Questa prenotazione non può passare a questo stato.');
    if ((status === 'completed' || status === 'no_show') && x.reservation_date > today) throw new Error('Puoi segnarla come completata o no show dal giorno della prenotazione.');
    const prevStatus = x.status;
    Object.assign(x, {
      status,
      confirmed_at: status === 'confirmed' ? now() : x.confirmed_at,
      cancelled_at: status === 'cancelled' || status === 'rejected' ? now() : x.cancelled_at,
      internal_notes: manager && note?.trim() ? note.trim().slice(0, 500) : x.internal_notes,
    });
    if (status === 'confirmed' || status === 'rejected' || status === 'cancelled') enqueueEmail(`reservation_${status}`, x.guest_email, { code: x.confirmation_code });
    if (!manager) notifyRestaurant(x.restaurant_id, 'reservation_cancelled', 'Prenotazione cancellata dal cliente', `${x.confirmation_code} · ${x.party_size} persone`, `/dashboard/restaurants/${x.restaurant_id}/reservations`);
    eng.hooks.reservationStatus(x, prevStatus);
    save();
  },

  async getMyReservations() {
    const uid = currentUser();
    return delay(
      db.reservations
        .filter((x) => uid && x.user_id === uid)
        .sort((a, b) => (b.reservation_date + b.reservation_time).localeCompare(a.reservation_date + a.reservation_time))
        .map((x) => {
          const r = db.restaurants.find((y) => y.id === x.restaurant_id);
          return { ...x, restaurant: r ? { id: r.id, name: r.name, slug: r.slug, phone: r.phone } : null };
        }),
    );
  },

  // ─── Fase 4: coupon ────────────────────────────────────────
  async claimCoupon(couponId, emailInput, source = 'web') {
    const c = db.coupons.find((x) => x.id === couponId);
    if (!c) throw new Error('Coupon non trovato.');
    const r = db.restaurants.find((x) => x.id === c.restaurant_id);
    if (!r || !isPublic(r) || r.is_permanently_closed || !restHasFeature(r.id, 'coupons_enabled')) throw new Error('Coupon non disponibile.');
    if (!c.is_active || new Date(c.valid_from) > new Date()) throw new Error('Questo coupon non è attivo.');
    if (c.valid_until && new Date(c.valid_until) <= new Date()) throw new Error('Questo coupon è scaduto.');
    const uid = currentUser();
    let email = emailInput?.trim().toLowerCase() || null;
    if (!uid) {
      if (!email) throw new Error('Inserisci la tua email per ottenere il coupon.');
      if (!EMAIL_RE.test(email)) throw new Error('Inserisci un indirizzo email valido.');
      if (db.coupon_claims.filter((x) => x.email === email && Date.now() - new Date(x.claimed_at).getTime() < 86_400_000).length >= 10) {
        throw new Error('Troppe richieste in poco tempo. Riprova domani.');
      }
    } else email = null;
    const mine = db.coupon_claims.filter((x) => x.coupon_id === c.id && (x.status === 'claimed' || x.status === 'redeemed') && (uid ? x.user_id === uid : x.email === email));
    const base = { valid_until: c.valid_until, title: c.title, restaurant_name: r.name, restaurant_slug: r.slug };
    if (mine.length >= c.max_redemptions_per_user) {
      const existing = uid ? mine.find((x) => x.status === 'claimed') : undefined;
      if (existing) return delay({ ...base, claim_code: existing.claim_code, status: existing.status, already: true, claimed_at: existing.claimed_at });
      throw new Error('Hai già ottenuto questo coupon.');
    }
    if (c.max_redemptions != null && c.claims_count >= c.max_redemptions) throw new Error('Coupon esaurito: sono stati già distribuiti tutti i codici.');
    const prefix = c.code.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10);
    let code = '';
    do code = `${prefix}-${randomCode(4)}`;
    while (db.coupon_claims.some((x) => x.claim_code === code));
    const claim: CouponClaim = { id: uuid(), coupon_id: c.id, restaurant_id: r.id, user_id: uid, email, claim_code: code, status: 'claimed', claimed_at: now(), redeemed_at: null, source: source === 'ai' ? 'ai' : 'web' };
    db.coupon_claims.push(claim);
    eng.hooks.couponClaimed(claim);
    c.claims_count += 1;
    logEvent(r.id, 'coupon_claim');
    save();
    return delay({ ...base, claim_code: code, status: 'claimed' as const, already: false, claimed_at: claim.claimed_at });
  },

  async checkCouponClaim(restaurantId, code) {
    requireManage(restaurantId);
    const x = db.coupon_claims.find((y) => y.claim_code === code.replace(/\s+/g, '').toUpperCase() && y.restaurant_id === restaurantId);
    if (!x) return delay({ found: false });
    const c = db.coupons.find((y) => y.id === x.coupon_id)!;
    const expired = x.status === 'claimed' && !!c.valid_until && new Date(c.valid_until) <= new Date();
    return delay({
      found: true, claim_code: x.claim_code, status: expired ? 'expired' : x.status, claimed_at: x.claimed_at, redeemed_at: x.redeemed_at,
      title: c.title, description: c.description, discount_type: c.discount_type, discount_value: c.discount_value, minimum_spend: c.minimum_spend,
      valid_until: c.valid_until, coupon_active: c.is_active,
    });
  },

  async redeemCoupon(restaurantId, code) {
    requireManage(restaurantId);
    const x = db.coupon_claims.find((y) => y.claim_code === code.replace(/\s+/g, '').toUpperCase() && y.restaurant_id === restaurantId);
    if (!x) throw new Error('Codice non trovato per questo ristorante.');
    const c = db.coupons.find((y) => y.id === x.coupon_id)!;
    if (x.status === 'redeemed') throw new Error(`Coupon già utilizzato il ${new Date(x.redeemed_at!).toLocaleString('it-IT', { dateStyle: 'short', timeStyle: 'short' })}.`);
    if (x.status !== 'claimed') throw new Error('Coupon non valido.');
    if (c.valid_until && new Date(c.valid_until) <= new Date()) throw new Error('Coupon scaduto.');
    if (!c.is_active) throw new Error('Il coupon è stato disattivato.');
    Object.assign(x, { status: 'redeemed', redeemed_at: now() });
    eng.hooks.couponRedeemed(x);
    c.redemptions_count += 1;
    logEvent(restaurantId, 'coupon_redeem', 'dashboard');
    save();
    return this.checkCouponClaim(restaurantId, x.claim_code);
  },

  async listCouponClaims(restaurantId, limit = 50) {
    requireManage(restaurantId);
    return delay(
      db.coupon_claims
        .filter((x) => x.restaurant_id === restaurantId)
        .sort((a, b) => (b.redeemed_at ?? b.claimed_at).localeCompare(a.redeemed_at ?? a.claimed_at))
        .slice(0, limit)
        .map((x) => couponClaimView(x)),
    );
  },

  async getMyCouponClaims() {
    const uid = currentUser();
    return delay(db.coupon_claims.filter((x) => uid && x.user_id === uid).sort((a, b) => b.claimed_at.localeCompare(a.claimed_at)).map((x) => couponClaimView(x)));
  },

  // ─── Fase 4: notifiche ─────────────────────────────────────
  async listNotifications(limit = 30) {
    const uid = currentUser();
    return delay(db.notifications.filter((n) => n.user_id === uid).slice(0, limit), 0);
  },

  async markNotificationsRead(ids) {
    eng.markRead(ids ?? null);
    save();
  },

  // ─── Fase 4: statistiche ───────────────────────────────────
  async getRestaurantAnalytics(id, days) {
    requireManage(id);
    assertFeature(id, 'analytics_enabled');
    const d = Math.min(Math.max(days, 1), 365);
    const since = Date.now() - d * 86_400_000;
    const inRange = (iso: string | null) => !!iso && new Date(iso).getTime() >= since;
    const events: Partial<Record<AnalyticsEventType, number>> = {};
    const evs = db.analytics.filter((e) => e.restaurant_id === id && inRange(e.created_at));
    evs.forEach((e) => (events[e.event_type] = (events[e.event_type] ?? 0) + 1));
    const res = db.reservations.filter((x) => x.restaurant_id === id && inRange(x.created_at));
    const count = (f: (x: Reservation) => boolean) => res.filter(f).length;
    const advanced = isAdminUser() || restHasFeature(id, 'advanced_analytics');
    const daily: { date: string; views: number; contacts: number }[] = [];
    const sources: Record<string, number> = {};
    if (advanced) {
      const today = new Date().toISOString().slice(0, 10);
      for (let k = d - 1; k >= 0; k--) {
        const date = addDays(today, -k);
        const dayEvs = evs.filter((e) => e.created_at.slice(0, 10) === date);
        daily.push({
          date,
          views: dayEvs.filter((e) => e.event_type === 'restaurant_view').length,
          contacts: dayEvs.filter((e) => ['phone_click', 'whatsapp_click', 'directions_click', 'reservation_start'].includes(e.event_type)).length,
        });
      }
      evs.filter((e) => e.event_type === 'restaurant_view').forEach((e) => (sources[e.source ?? 'direct'] = (sources[e.source ?? 'direct'] ?? 0) + 1));
    }
    return delay({
      days: d, advanced, events, daily, sources,
      reservations: {
        total: count((x) => x.source === 'web' || x.source === 'app'),
        manual: count((x) => x.source === 'restaurant' || x.source === 'admin'),
        pending: count((x) => x.status === 'pending'),
        confirmed: count((x) => x.status === 'confirmed'),
        completed: count((x) => x.status === 'completed'),
        no_show: count((x) => x.status === 'no_show'),
        cancelled: count((x) => x.status === 'cancelled' || x.status === 'rejected'),
        covers: res.filter((x) => x.status === 'confirmed' || x.status === 'completed').reduce((a, x) => a + x.party_size, 0),
      },
      coupons: {
        claimed: db.coupon_claims.filter((x) => x.restaurant_id === id && inRange(x.claimed_at)).length,
        redeemed: db.coupon_claims.filter((x) => x.restaurant_id === id && inRange(x.redeemed_at)).length,
      },
    });
  },

  // ─── Fase 4: menu ──────────────────────────────────────────
  async duplicateMenuItem(itemId) {
    const it = db.menu_items.find((x) => x.id === itemId);
    if (!it) throw new Error('Piatto non trovato.');
    requireManage(it.restaurant_id);
    assertFeature(it.restaurant_id, 'menu_enabled');
    assertLimit(it.restaurant_id, 'max_menu_items', db.menu_items.filter((x) => x.restaurant_id === it.restaurant_id).length);
    const copy = { ...clone(it), id: uuid(), name: `${it.name} (copia)`.slice(0, 120), sort_order: it.sort_order + 1 };
    db.menu_items.push(copy);
    db.menu_item_variants.filter((v) => v.menu_item_id === itemId).forEach((v) => db.menu_item_variants.push({ ...v, id: uuid(), menu_item_id: copy.id }));
    db.menu_item_addons.filter((v) => v.menu_item_id === itemId).forEach((v) => db.menu_item_addons.push({ ...v, id: uuid(), menu_item_id: copy.id }));
    save();
    return copy.id;
  },

  async duplicateMenu(menuId) {
    const m = db.menus.find((x) => x.id === menuId);
    if (!m) throw new Error('Menu non trovato.');
    requireManage(m.restaurant_id);
    assertFeature(m.restaurant_id, 'menu_enabled');
    const items = db.menu_items.filter((i) => db.menu_categories.some((c) => c.menu_id === menuId && c.id === i.menu_category_id));
    assertLimit(m.restaurant_id, 'max_menu_items', db.menu_items.filter((x) => x.restaurant_id === m.restaurant_id).length + items.length - 1);
    const copy = { ...clone(m), id: uuid(), name: `${m.name} (copia)`.slice(0, 80), is_public: false, sort_order: Math.max(0, ...db.menus.filter((x) => x.restaurant_id === m.restaurant_id).map((x) => x.sort_order)) + 1 };
    db.menus.push(copy);
    db.menu_categories.filter((c) => c.menu_id === menuId).forEach((c) => {
      const nc = { ...clone(c), id: uuid(), menu_id: copy.id };
      db.menu_categories.push(nc);
      db.menu_items.filter((i) => i.menu_category_id === c.id).forEach((i) => {
        const ni = { ...clone(i), id: uuid(), menu_category_id: nc.id };
        db.menu_items.push(ni);
        db.menu_item_variants.filter((v) => v.menu_item_id === i.id).forEach((v) => db.menu_item_variants.push({ ...v, id: uuid(), menu_item_id: ni.id }));
        db.menu_item_addons.filter((v) => v.menu_item_id === i.id).forEach((v) => db.menu_item_addons.push({ ...v, id: uuid(), menu_item_id: ni.id }));
      });
    });
    save();
    return copy.id;
  },

  async reorderMenuRows(tableName, ids) {
    const rows = table(tableName) as (Row & { id: string; restaurant_id: string })[];
    const first = rows.find((x) => x.id === ids[0]);
    if (!first) return;
    requireManage(first.restaurant_id);
    const col = tableName === 'menu_item_variants' || tableName === 'menu_item_addons' ? 'display_order' : 'sort_order';
    ids.forEach((id, i) => {
      const row = rows.find((x) => x.id === id && x.restaurant_id === first.restaurant_id);
      if (row) row[col] = i;
    });
    save();
  },

  async replaceItemOptions(itemId, variants, addons) {
    const it = db.menu_items.find((x) => x.id === itemId);
    if (!it) throw new Error('Piatto non trovato.');
    requireManage(it.restaurant_id);
    assertFeature(it.restaurant_id, 'menu_enabled');
    const clean = (xs: { name: string; price: number | null; is_available?: boolean }[]) =>
      xs.filter((x) => x.name.trim()).map((x, i) => ({ id: uuid(), menu_item_id: itemId, restaurant_id: it.restaurant_id, name: x.name.trim().slice(0, 60), price: x.price != null && x.price >= 0 ? x.price : null, is_available: x.is_available ?? true, display_order: i }));
    db.menu_item_variants = [...db.menu_item_variants.filter((v) => v.menu_item_id !== itemId), ...clean(variants)];
    db.menu_item_addons = [...db.menu_item_addons.filter((v) => v.menu_item_id !== itemId), ...clean(addons)];
    save();
  },

  async importMenu(restaurantId, rows) {
    requireManage(restaurantId);
    assertFeature(restaurantId, 'menu_enabled');
    if (!rows.length) throw new Error('Nessuna riga da importare.');
    if (rows.length > 1000) throw new Error('Massimo 1000 piatti per importazione.');
    rows.forEach((x, i) => {
      if (!x.name?.trim()) throw new Error(`Riga ${i + 1}: il nome del piatto è obbligatorio.`);
      if (!x.category?.trim()) throw new Error(`Riga ${i + 1}: la categoria è obbligatoria.`);
      if (x.price != null && (!Number.isFinite(x.price) || x.price < 0 || x.price > 10000)) throw new Error(`Riga ${i + 1}: prezzo non valido.`);
    });
    assertLimit(restaurantId, 'max_menu_items', db.menu_items.filter((x) => x.restaurant_id === restaurantId).length + rows.length - 1);
    let menus = 0;
    let categories = 0;
    rows.forEach((x) => {
      const menuName = (x.menu?.trim() || 'Menu principale').slice(0, 80);
      let m = db.menus.find((y) => y.restaurant_id === restaurantId && y.name.toLowerCase() === menuName.toLowerCase());
      if (!m) {
        m = { id: uuid(), restaurant_id: restaurantId, name: menuName, description: null, menu_type: (x.menu_type as Menu['menu_type']) || 'a_la_carte', price: null, is_active: true, is_public: true, valid_from: null, valid_until: null, sort_order: db.menus.filter((y) => y.restaurant_id === restaurantId).length };
        db.menus.push(m);
        menus++;
      }
      let c = db.menu_categories.find((y) => y.menu_id === m!.id && y.name.toLowerCase() === x.category.trim().toLowerCase());
      if (!c) {
        c = { id: uuid(), menu_id: m.id, restaurant_id: restaurantId, name: x.category.trim().slice(0, 80), description: null, is_active: true, sort_order: db.menu_categories.filter((y) => y.menu_id === m!.id).length };
        db.menu_categories.push(c);
        categories++;
      }
      const itemId = uuid();
      db.menu_items.push({
        id: itemId, menu_category_id: c.id, restaurant_id: restaurantId, name: x.name.trim().slice(0, 120), description: x.description?.trim().slice(0, 500) || null,
        price: x.price ?? null, discount_price: x.discount_price ?? null, image_url: null, pieces: null, allergens: normalizeAllergens(x.allergens),
        ingredients: (x.ingredients ?? []).map((i) => i.trim()).filter(Boolean).slice(0, 40), tags: [], is_available: x.is_available ?? true,
        is_featured: !!x.is_featured, is_spicy: !!x.is_spicy, is_vegan: !!x.is_vegan, is_vegetarian: !!x.is_vegetarian || !!x.is_vegan,
        is_gluten_free: !!x.is_gluten_free, is_ayce_included: false, ayce_limit: null, sort_order: db.menu_items.filter((y) => y.menu_category_id === c!.id).length,
      });
      (x.variants ?? []).forEach((v, i) => db.menu_item_variants.push({ id: uuid(), menu_item_id: itemId, restaurant_id: restaurantId, name: v.name, price: v.price, is_available: true, display_order: i }));
      (x.addons ?? []).forEach((v, i) => db.menu_item_addons.push({ id: uuid(), menu_item_id: itemId, restaurant_id: restaurantId, name: v.name, price: v.price, is_available: true, display_order: i }));
    });
    const r = db.restaurants.find((y) => y.id === restaurantId);
    if (r) r.menu_last_verified_at = now();
    save();
    return { menus, categories, items: rows.length };
  },

  // ─── CRUD generico ─────────────────────────────────────────
  async list<T>(name: TableName, opts: { match?: Row; orderBy?: string; ascending?: boolean; limit?: number } = {}) {
    let rows = [...table(name)];
    if (opts.match) rows = rows.filter((r) => Object.entries(opts.match!).every(([k, v]) => r[k] === v));
    if (opts.orderBy) {
      const k = opts.orderBy;
      const dir = opts.ascending === false ? -1 : 1;
      rows.sort((a, b) => String(a[k] ?? '').localeCompare(String(b[k] ?? ''), undefined, { numeric: true }) * dir);
    }
    return delay((opts.limit ? rows.slice(0, opts.limit) : rows) as T[], 0);
  },

  async upsert<T>(name: TableName, row: Row, pk = 'id') {
    const rows = table(name);
    const data: Row = { ...row };
    if (!data[pk]) data[pk] = uuid();
    if (name === 'menu_categories') data.restaurant_id = db.menus.find((m) => m.id === data.menu_id)?.restaurant_id;
    if (name === 'menu_items') data.restaurant_id = db.menu_categories.find((m) => m.id === data.menu_category_id)?.restaurant_id;
    if (name === 'menu_item_variants' || name === 'menu_item_addons') data.restaurant_id = db.menu_items.find((m) => m.id === data.menu_item_id)?.restaurant_id;
    guardWrite(name, data, rows.find((x) => x[pk] === data[pk]));
    if (name === 'restaurant_sources' && data.is_primary) {
      db.restaurant_sources.filter((s) => s.restaurant_id === data.restaurant_id && s.id !== data.id).forEach((s) => (s.is_primary = false));
    }
    const i = rows.findIndex((r) => r[pk] === data[pk]);
    const wasActive = i >= 0 && !!rows[i]!.is_active;
    if (i >= 0) rows[i] = { ...rows[i], ...data, updated_at: now() };
    else rows.push({ created_at: now(), updated_at: now(), ...data });
    // Avviso ai follower quando un'offerta o un coupon diventa attivo (una volta al giorno per locale)
    const saved = (i >= 0 ? rows[i] : rows[rows.length - 1])!;
    if ((name === 'offers' || name === 'coupons') && saved.is_active && !wasActive) {
      eng.hooks.offerActivated(name === 'offers' ? 'offer' : 'coupon', String(saved.restaurant_id), String(saved.title ?? ''));
    }
    save();
    return delay((i >= 0 ? rows[i] : rows[rows.length - 1]) as T, 0);
  },

  async remove(name, value, pk = 'id') {
    const arr = table(name);
    const idx = arr.findIndex((r) => r[pk] === value);
    if (idx >= 0) arr.splice(idx, 1);
    // cascata minima per coerenza
    if (name === 'menus') {
      const secIds = db.menu_categories.filter((s) => s.menu_id === value).map((s) => s.id);
      db.menu_categories = db.menu_categories.filter((s) => s.menu_id !== value);
      db.menu_items = db.menu_items.filter((i) => !secIds.includes(i.menu_category_id));
    }
    if (name === 'menu_categories') db.menu_items = db.menu_items.filter((i) => i.menu_category_id !== value);
    const itemIds = new Set(db.menu_items.map((i) => i.id));
    db.menu_item_variants = db.menu_item_variants.filter((v) => itemIds.has(v.menu_item_id));
    db.menu_item_addons = db.menu_item_addons.filter((v) => itemIds.has(v.menu_item_id));
    save();
  },

  // ─── Admin ─────────────────────────────────────────────────
  async getAdminStats() {
    const active = (o: { is_active: boolean; starts_at: string; ends_at: string | null }) => isOfferActiveNow(o);
    const since = Date.now() - 30 * 86_400_000;
    const R = db.restaurants;
    return delay({
      restaurants_total: R.length,
      restaurants_active: R.filter((r) => r.is_active).length,
      restaurants_draft: R.filter((r) => !r.is_active).length,
      restaurants_claimed: R.filter((r) => r.owner_id).length,
      restaurants_demo: R.filter((r) => r.is_demo).length,
      restaurants_real: R.filter((r) => !r.is_demo).length,
      restaurants_verified: R.filter((r) => r.data_status === 'verified' || r.data_status === 'claimed').length,
      restaurants_unverified: R.filter((r) => r.data_status === 'unverified' || r.data_status === 'outdated').length,
      claims_pending: db.restaurant_claims.filter((c) => c.status === 'pending' || c.status === 'under_review').length,
      claims_more_info: db.restaurant_claims.filter((c) => c.status === 'more_information_required').length,
      restaurants_no_coords: R.filter((r) => r.latitude == null || r.longitude == null).length,
      change_requests_pending: db.change_requests.filter((c) => c.status === 'pending').length,
      map_opens_30d: db.app_events.filter((e) => e.event_type === 'map_open').length,
      near_me_30d: db.app_events.filter((e) => e.event_type === 'near_me_search').length,
      reports_open: db.restaurant_reports.filter((r) => r.status === 'open' || r.status === 'in_progress').length,
      users_total: db.profiles.length,
      owners_total: new Set(db.restaurant_members.filter((m) => m.status === 'active').map((m) => m.user_id)).size,
      offers_active: db.offers.filter(active).length,
      coupons_active: db.coupons.filter((c) => c.is_active).length,
      sponsored_active: db.sponsored_campaigns.filter(campaignLive).length,
      webhook_failed_7d: db.stripe_events.filter((e) => e.processing_status === 'failed').length,
      publication_requests: R.filter((r) => !r.is_active && r.publication_requested_at).length,
      events_30d: db.analytics.filter((e) => new Date(e.created_at).getTime() >= since).length,
      views_30d: db.analytics.filter((e) => e.event_type === 'restaurant_view' && new Date(e.created_at).getTime() >= since).length,
      restaurants_paid: R.filter((r) => r.subscription_plan !== 'free').length,
      upgrade_requests_open: db.plan_upgrade_requests.filter((x) => x.status === 'open').length,
      reservations_30d: db.reservations.filter((x) => new Date(x.created_at).getTime() >= since).length,
      reservations_pending: db.reservations.filter((x) => x.status === 'pending').length,
      coupons_claimed_30d: db.coupon_claims.filter((x) => new Date(x.claimed_at).getTime() >= since).length,
      coupons_redeemed_30d: db.coupon_claims.filter((x) => x.redeemed_at && new Date(x.redeemed_at).getTime() >= since).length,
      emails_pending: db.email_outbox.length,
      show_demo_data: demoVisible(),
    });
  },

  // ─── Assistente AI (Fase 6): stesso motore del server, senza modello ───
  async aiChat(input) {
    return (await aiDemo()).demoAiChat(input, aiAccess);
  },

  async aiHistory(sessionId) {
    return delay((await aiDemo()).demoAiHistory(sessionId, aiAccess), 0);
  },

  async aiDeleteSession(sessionId) {
    (await aiDemo()).demoAiDelete(sessionId, aiAccess);
  },

  async getAiPreferences() {
    const uid = currentUser();
    return delay(uid ? db.ai_user_preferences?.[uid] ?? null : null, 0);
  },

  async saveAiPreferences(prefs) {
    const uid = currentUser();
    if (!uid) throw new Error('Accedi per salvare le preferenze.');
    const ok = ['vegetarian', 'vegan', 'gluten_free', 'no_spicy'];
    if (prefs.dietary_preferences.some((d) => !ok.includes(d))) throw new Error('Preferenza non valida.');
    db.ai_user_preferences = { ...(db.ai_user_preferences ?? {}), [uid]: { ...prefs, favorite_categories: prefs.favorite_categories.slice(0, 10), favorite_cities: prefs.favorite_cities.slice(0, 10) } };
    save();
  },

  async deleteAiPreferences() {
    const uid = currentUser();
    if (!uid || !db.ai_user_preferences) return;
    delete db.ai_user_preferences[uid];
    save();
  },

  async getAdminAiStats(days = 30) {
    requireAdmin();
    const since = Date.now() - days * DAY_MS;
    const inRange = (iso: string | null) => !!iso && Date.parse(iso) >= since;
    const { demoAiStats } = await aiDemo();
    return delay(
      demoAiStats(aiAccess, days, {
        result_clicks: db.analytics.filter((e) => e.event_type === 'ai_result_click' && inRange(e.created_at)).length,
        reservations: db.reservations.filter((x) => x.source === 'ai' && inRange(x.created_at)).length,
        coupon_claims: db.coupon_claims.filter((x) => x.source === 'ai' && inRange(x.claimed_at)).length,
        map_opens: db.analytics.filter((e) => e.event_type === 'ai_map_open' && inRange(e.created_at)).length,
      }),
    );
  },

  async getRestaurantAiStats(restaurantId, days = 30) {
    requireManage(restaurantId);
    if (!isAdminUser()) assertFeature(restaurantId, 'advanced_analytics');
    const since = Date.now() - days * DAY_MS;
    const evs = db.analytics.filter((e) => e.restaurant_id === restaurantId && Date.parse(e.created_at) >= since);
    const bySrc = (t: AnalyticsEventType) => evs.filter((e) => e.event_type === t && e.source === 'ai').length;
    const out: RestaurantAiStats = {
      profile_views: bySrc('restaurant_view'),
      result_clicks: evs.filter((e) => e.event_type === 'ai_result_click').length,
      directions_clicks: bySrc('directions_click'),
      phone_clicks: bySrc('phone_click'),
      reservations: db.reservations.filter((x) => x.restaurant_id === restaurantId && x.source === 'ai' && Date.parse(x.created_at) >= since).length,
      coupon_claims: db.coupon_claims.filter((x) => x.restaurant_id === restaurantId && x.source === 'ai' && Date.parse(x.claimed_at) >= since).length,
    };
    return delay(out);
  },

  // ─── Fase 7: recensioni, punti, inviti, notifiche, campagne (stesse regole delle funzioni SQL) ───
  getRestaurantRating: async (id) => delay(eng.getRestaurantRating(id), 0),
  getRestaurantsRating: async (ids) => delay(eng.getRestaurantsRating(ids), 0),
  listReviews: async (id, opts) => delay(eng.listReviews(id, opts), 60),
  getReviewFormStatus: async (id) => delay(eng.getReviewFormStatus(id), 0),
  submitReview: async (id, input) => {
    if (db.settings.reviews_enabled === false) throw new Error('Le recensioni sono temporaneamente disattivate.');
    return delay(eng.submitReview(id, input));
  },
  updateReview: async (id, input) => delay(eng.updateReview(id, input)),
  voteReview: async (id, on) => delay(eng.voteReview(id, on), 0),
  reportReview: async (id, reason, details) => delay(eng.reportReview(id, reason, details), 0),
  respondToReview: async (id, content) => delay(eng.respondToReview(id, content)),
  listManagedReviews: async (id) => delay(eng.listManagedReviews(id)),
  adminListReviews: async (status) => delay(eng.adminListReviews(status)),
  moderateReview: async (id, action, note) => delay(eng.moderateReview(id, action, note)),
  getLoyaltyWallet: async (opts) => delay(eng.getLoyaltyWallet(opts)),
  listRewards: async () => delay(eng.listRewards()),
  redeemReward: async (id) => delay(await eng.redeemReward(id)),
  getMyAchievements: async () => delay(eng.getMyAchievements(), 0),
  adminLoyaltyAdjust: async (u, p, r) => delay(eng.adminLoyaltyAdjust(u, p, r)),
  adminListRedemptions: async () => delay(eng.adminListRedemptions()),
  adminUpdateRedemption: async (id, st) => delay(eng.adminUpdateRedemption(id, st)),
  getMyReferrals: async () => delay(eng.getMyReferrals()),
  applyReferralCode: async (code) => delay(eng.applyReferralCode(code)),
  createBusinessReferral: async (id, email, name) => delay(eng.createBusinessReferral(id, email, name)),
  listBusinessReferrals: async (id) => delay(eng.listBusinessReferrals(id)),
  adminListReferrals: async (status) => delay(eng.adminListReferrals(status)),
  adminReferralAction: async (id, action, reason) => delay(eng.adminReferralAction(id, action, reason)),
  adminBusinessReferralUpdate: async (id, patch) => delay(eng.adminBusinessReferralUpdate(id, patch)),
  listNotificationsPage: async (opts) => delay(eng.listNotificationsPage(opts), 0),
  getNotificationPrefs: async () => delay(currentUser() ? eng.getNotificationPrefs() : DEFAULT_PREFS, 0),
  saveNotificationPrefs: async (patch) => delay(eng.saveNotificationPrefs(patch), 0),
  savePushSubscription: async (sub) => delay(eng.savePushSubscription(sub.endpoint, sub.device, sub.platform), 0),
  removePushSubscription: async (endpoint) => delay(eng.removePushSubscription(endpoint), 0),
  recordActivity: async () => eng.recordActivity(),
  trackCampaignClick: async (id) => eng.trackCampaignClick(id),
  getFollowState: async (id) => delay(eng.getFollowState(id), 0),
  setFollow: async (id, on) => delay(eng.setFollow(id, on), 0),
  campaignAudienceCount: async (scope, id, target, targeting) => delay(eng.campaignAudienceCount(scope, id, target, targeting), 0),
  createCampaign: async (input) => delay(eng.createCampaign(input)),
  cancelCampaign: async (id) => delay(eng.cancelCampaign(id)),
  listCampaigns: async (f) => delay(eng.listCampaigns(f)),
  getPushCampaignStats: async (id) => delay(eng.getPushCampaignStats(id), 0),
  getRetentionStats: async (days) => delay(eng.getRetentionStats(days)),
  getRestaurantEngagementStats: async (id, days) => {
    requireManage(id);
    assertFeature(id, 'analytics_enabled');
    return delay(eng.getRestaurantEngagementStats(id, days));
  },
  runEngagementTick: async () => delay(eng.runTick()),

  // ─── Fase 8: ordini (stesse regole delle funzioni SQL; pagamento SIMULATO, nessun addebito) ───
  getOrderInfo: async (id) => delay(market.publicInfo(id), 0),
  getOrderableRestaurants: async () => delay(market.orderable(), 0),
  getRestaurantsDeliveringTo: async (lat, lng) => delay(market.deliveringTo(lat, lng), 0),
  getMenuOptionGroups: async (id) => delay(market.optionGroupsFor(id), 0),
  getOrderSlots: async (id, date, type) => delay(market.slots(id, date, type), 0),
  quoteOrder: async (input) => delay(market.quote(input), 80),
  placeOrder: async (input) => {
    // Come il backend: in manutenzione nessun nuovo ordine (503 MAINTENANCE)
    if (db.settings.maintenance_mode === true) throw new AppError('MAINTENANCE', 'Stiamo effettuando un aggiornamento. Riprova tra qualche minuto.');
    return delay(market.create({ ...input, session_id: demoSessionId() }), 200);
  },
  demoPayOrder: async (num, token, card) => delay(market.demoPay(num, token, card), 400),
  resumeOrderPayment: async () => ({ client_secret: null }),
  trackOrder: async (num, token) => delay(market.track(num, token), 0),
  cancelOrderAsCustomer: async (num, token, reason) => delay(market.customerCancel(num, token, reason ?? null)).then((r) => ({ refund_pending: !!r.refund_pending })),
  reportOrderIssue: async (num, token, type, description) => {
    market.reportIssue(num, token, type, description);
  },
  listMyOrders: async (limit, offset) => delay(market.myOrders(limit, offset)),
  listAddresses: async () => delay(market.addresses(), 0),
  saveAddress: async (input) => delay(market.saveAddress(input)),
  deleteAddress: async (id) => delay(market.deleteAddress(id), 0),
  saveCart: async (payload) => market.saveCart(payload),
  loadCart: async () => delay(market.loadCart() as { restaurant_id: string; items: unknown[] } | null, 0),
  listRestaurantOrders: async (id, tab) => delay(market.restaurantOrders(id, tab), 0),
  orderAction: async (id, action, payload) => delay(market.action(id, action, payload ?? {})),
  refundOrder: async (id, amount, reason) => {
    await delay(market.refund(id, amount, reason));
  },
  setOrderPause: async (id, kind, minutes) => {
    await delay(market.setPause(id, kind, minutes), 0);
  },
  setMenuItemAvailability: async (id, mode) => {
    await delay(market.setItemAvailability(id, mode), 0);
  },
  getOrderSettings: async (id) => delay(market.getSettings(id), 0),
  saveOrderSettings: async (id, patch) => delay(market.saveSettings(id, patch)),
  saveDeliveryZone: async (id, zone) => delay(market.saveZone(id, zone)),
  deleteDeliveryZone: async (id, zoneId) => delay(market.deleteZone(id, zoneId), 0),
  listAllOptionGroups: async (id) => delay(market.allOptionGroups(id), 0),
  saveOptionGroup: async (id, g) => delay(market.saveOptionGroup(id, g)),
  deleteOptionGroup: async (id, gid) => delay(market.deleteOptionGroup(id, gid), 0),
  getPayoutStatus: async (id) => delay(market.payoutStatus(id), 0),
  startPayoutOnboarding: async (id) => delay(market.payoutOnboard(id), 600),
  refreshPayoutStatus: async (id) => delay(market.payoutStatus(id), 0),
  openPayoutDashboard: async () => ({ url: null }),
  getRestaurantOrderStats: async (id, days) => delay(market.restaurantStats(id, days)),
  adminListOrders: async (f) => delay(market.adminList(f)),
  adminOrderDetail: async (id) => delay(market.adminDetail(id)),
  adminOrderUpdate: async (id, patch) => delay(market.adminUpdate(id, patch), 0),
  adminResyncPayment: async () => {
    requireAdmin();
    return 'Modalità DEMO: nessun pagamento Stripe reale da sincronizzare.';
  },
  getMarketplaceStats: async (days) => delay(market.marketplaceStats(days)),
  getCommissionSettings: async () => delay(market.commissions(), 0),
  saveGlobalCommission: async (p) => delay(market.saveGlobalCommission(p), 0),
  addCommissionOverride: async (p) => delay(market.addCommissionOverride(p), 0),
  runOrdersTick: async () => {
    requireAdmin();
    return delay(market.tick());
  },

  async getSetting(key) {
    return delay((db.settings[key] ?? null) as never, 0);
  },

  async setSetting(key, value) {
    requireAdmin();
    db.settings[key] = value;
    save();
  },

  async adminListRestaurants(q) {
    const { page = 1, pageSize = 20 } = q;
    let rows = db.restaurants.map(summary);
    const n = q.q?.toLowerCase();
    if (n) rows = rows.filter((r) => `${r.name} ${r.slug} ${r.address ?? ''}`.toLowerCase().includes(n));
    if (q.cityId) rows = rows.filter((r) => r.city_id === q.cityId);
    if (q.categoryId) rows = rows.filter((r) => r.categories.some((c) => c.id === q.categoryId));
    const yn = (v: boolean, f?: 'yes' | 'no') => !f || v === (f === 'yes');
    rows = rows.filter(
      (r) =>
        yn(r.is_verified, q.verified) && yn(!!r.owner_id, q.claimed) && yn(r.is_active, q.active) && yn(r.is_sponsored, q.sponsored) && yn(r.is_demo, q.demo) &&
        (!q.dataStatus || r.data_status === q.dataStatus) && (!q.plan || r.subscription_plan === q.plan) &&
        (!q.closed || (q.closed === 'temporary' ? r.is_temporarily_closed : q.closed === 'permanent' ? r.is_permanently_closed : !r.is_temporarily_closed && !r.is_permanently_closed)) &&
        (!q.coords || (q.coords === 'missing') === (r.latitude == null || r.longitude == null)),
    );
    rows.sort(
      q.sort === 'updated'
        ? (a, b) => b.updated_at.localeCompare(a.updated_at)
        : q.sort === 'last_verified'
          ? (a, b) => (a.last_verified_at ?? '').localeCompare(b.last_verified_at ?? '')
          : (a, b) => a.name.localeCompare(b.name),
    );
    return delay({ rows: rows.slice((page - 1) * pageSize, page * pageSize), total: rows.length });
  },

  async createRestaurant(input, categoryIds) {
    requireAdmin();
    const city = db.cities.find((c) => c.id === input.city_id);
    const r: Restaurant = {
      ...blankRestaurant(),
      name: input.name,
      slug: uniqueSlug(input.slug || `${input.name}-${city?.slug ?? ''}`),
      short_description: input.short_description ?? null,
      address: input.address ?? null,
      city_id: input.city_id,
      province_id: city?.province_id ?? null,
      region_id: city?.region_id ?? null,
      postal_code: city?.postal_code ?? null,
      is_active: input.is_active ?? false,
    };
    db.restaurants.push(r);
    categoryIds.forEach((cid, i) => db.restaurant_categories.push({ restaurant_id: r.id, category_id: cid, is_primary: i === 0 }));
    db.restaurant_sources.push({ id: uuid(), restaurant_id: r.id, source_type: 'admin', source_name: 'Inserimento manuale Admin', source_url: null, external_id: null, is_primary: true, notes: null, last_checked_at: now(), import_batch_id: null, created_at: now(), updated_at: now() });
    save();
    return delay(r);
  },

  async duplicateRestaurant(id) {
    requireAdmin();
    const src = db.restaurants.find((r) => r.id === id);
    if (!src) throw new Error('Ristorante non trovato');
    const copy: Restaurant = {
      ...clone(src), id: uuid(), name: `${src.name} (copia)`, slug: uniqueSlug(`${src.slug}-copia`), owner_id: null, claimed_by: null, claimed_at: null,
      is_verified: false, is_active: false, is_featured: false, is_sponsored: false, data_status: 'unverified', google_place_id: null, external_id: null,
      source_url: null, source_name: null, last_verified_at: null, popularity_score: 0, created_at: now(), updated_at: now(),
    };
    db.restaurants.push(copy);
    db.restaurant_categories.filter((x) => x.restaurant_id === id).forEach((x) => db.restaurant_categories.push({ ...x, restaurant_id: copy.id }));
    db.restaurant_hours.filter((x) => x.restaurant_id === id).forEach((x) => db.restaurant_hours.push({ ...x, id: uuid(), restaurant_id: copy.id }));
    save();
    return copy.id;
  },

  async deleteRestaurant(id) {
    requireAdmin();
    db.restaurants = db.restaurants.filter((r) => r.id !== id);
    db.restaurant_categories = db.restaurant_categories.filter((x) => x.restaurant_id !== id);
    db.restaurant_members = db.restaurant_members.filter((x) => x.restaurant_id !== id);
    db.restaurant_sources = db.restaurant_sources.filter((x) => x.restaurant_id !== id);
    save();
  },

  async listClaims(filter = {}) {
    return delay(
      db.restaurant_claims
        .filter((c) => (filter.status === 'open' ? OPEN_CLAIM_STATUSES.includes(c.status) : !filter.status || c.status === filter.status))
        .filter((c) => !filter.restaurantId || c.restaurant_id === filter.restaurantId)
        .sort((a, b) => b.submitted_at.localeCompare(a.submitted_at))
        .map(claimView),
    );
  },

  async approveClaim(id, notes) {
    requireAdmin();
    const c = db.restaurant_claims.find((x) => x.id === id);
    if (!c || !OPEN_CLAIM_STATUSES.includes(c.status)) throw new Error('Richiesta non trovata o già gestita');
    const r = db.restaurants.find((x) => x.id === c.restaurant_id);
    if (!r) throw new Error('Ristorante non trovato');
    if (r.owner_id && r.owner_id !== c.user_id) throw new Error('Il locale ha già un titolare: usa "Trasferisci proprietà"');
    setOwner(r, c.user_id);
    Object.assign(r, { claimed_by: c.user_id, claimed_at: now(), is_verified: true, data_status: 'claimed' });
    Object.assign(c, { status: 'approved', admin_notes: notes ?? c.admin_notes, reviewed_at: now(), reviewed_by: currentUser(), approved_at: now() });
    db.restaurant_claims
      .filter((x) => x.restaurant_id === c.restaurant_id && x.id !== id && OPEN_CLAIM_STATUSES.includes(x.status))
      .forEach((x) => Object.assign(x, { status: 'rejected', rejected_at: now(), reviewed_at: now(), admin_notes: x.admin_notes ?? 'Rivendicazione assegnata ad altro richiedente' }));
    save();
  },

  async rejectClaim(id, notes) {
    requireAdmin();
    const c = db.restaurant_claims.find((x) => x.id === id);
    if (!c || !OPEN_CLAIM_STATUSES.includes(c.status)) throw new Error('Richiesta non trovata o già gestita');
    Object.assign(c, { status: 'rejected', admin_notes: notes ?? c.admin_notes, reviewed_at: now(), reviewed_by: currentUser(), rejected_at: now() });
    save();
  },

  async requestClaimInfo(id, message) {
    requireAdmin();
    const c = db.restaurant_claims.find((x) => x.id === id);
    if (!c || !OPEN_CLAIM_STATUSES.includes(c.status)) throw new Error('Richiesta non trovata o già gestita');
    if (!message.trim()) throw new Error('Scrivi quali informazioni servono');
    Object.assign(c, { status: 'more_information_required', info_requested_at: now(), admin_notes: message, reviewed_at: now(), reviewed_by: currentUser() });
    db.claim_messages.push({ id: uuid(), claim_id: id, author_id: currentUser(), author_role: 'admin', body: message, attachment_path: null, created_at: now() });
    save();
  },

  async setClaimUnderReview(id, notes) {
    requireAdmin();
    const c = db.restaurant_claims.find((x) => x.id === id);
    if (!c || !OPEN_CLAIM_STATUSES.includes(c.status)) throw new Error('Richiesta non trovata o già gestita');
    Object.assign(c, { status: 'under_review', admin_notes: notes ?? c.admin_notes, reviewed_at: now(), reviewed_by: currentUser() });
    save();
  },

  async transferOwnership(restaurantId, userId, notes) {
    requireAdmin();
    const r = db.restaurants.find((x) => x.id === restaurantId);
    if (!r) throw new Error('Ristorante non trovato');
    if (!db.profiles.some((p) => p.id === userId)) throw new Error('Utente non trovato');
    setOwner(r, userId);
    Object.assign(r, { claimed_by: userId, claimed_at: now(), is_verified: true, data_status: 'claimed', verification_notes: notes ?? r.verification_notes });
    save();
  },

  async revokeOwnership(restaurantId, notes) {
    requireAdmin();
    const r = db.restaurants.find((x) => x.id === restaurantId);
    if (!r) throw new Error('Ristorante non trovato');
    const users = db.restaurant_members.filter((m) => m.restaurant_id === restaurantId && m.status === 'active').map((m) => m.user_id);
    db.restaurant_members.filter((m) => m.restaurant_id === restaurantId).forEach((m) => (m.status = 'revoked'));
    Object.assign(r, {
      owner_id: null, claimed_by: null, claimed_at: null, is_verified: false,
      data_status: r.last_verified_at ? 'partially_verified' : 'unverified', verification_notes: notes ?? r.verification_notes,
    });
    users.forEach(refreshRole);
    save();
  },

  async setMember(restaurantId, userId, role) {
    requireAdmin();
    const r = db.restaurants.find((x) => x.id === restaurantId);
    if (!r) throw new Error('Ristorante non trovato');
    if (role === 'owner') return this.transferOwnership(restaurantId, userId);
    const m = db.restaurant_members.find((x) => x.restaurant_id === restaurantId && x.user_id === userId);
    if (m) Object.assign(m, { role, status: 'active' });
    else db.restaurant_members.push({ id: uuid(), restaurant_id: restaurantId, user_id: userId, role, status: 'active', created_at: now() });
    refreshRole(userId);
    save();
  },

  async removeMember(memberId) {
    requireAdmin();
    const m = db.restaurant_members.find((x) => x.id === memberId);
    if (!m) throw new Error('Membro non trovato');
    if (m.role === 'owner' && m.status === 'active') return this.revokeOwnership(m.restaurant_id);
    m.status = 'revoked';
    refreshRole(m.user_id);
    save();
  },

  async listReports(filter = {}) {
    return delay(
      db.restaurant_reports
        .filter((r) => (filter.status === 'open_all' ? r.status === 'open' || r.status === 'in_progress' : !filter.status || r.status === filter.status))
        .filter((r) => !filter.restaurantId || r.restaurant_id === filter.restaurantId)
        .sort((a, b) => b.created_at.localeCompare(a.created_at))
        .map((r) => {
          const x = db.restaurants.find((y) => y.id === r.restaurant_id);
          return { ...r, restaurant: x ? { id: x.id, name: x.name, slug: x.slug } : null };
        }),
    );
  },

  async updateReport(id, patch) {
    requireAdmin();
    const r = db.restaurant_reports.find((x) => x.id === id);
    if (!r) throw new Error('Segnalazione non trovata');
    const done = patch.status === 'resolved' || patch.status === 'dismissed';
    Object.assign(r, patch, done ? { resolved_at: now(), resolved_by: currentUser() } : {});
    save();
  },

  async listProfiles(q) {
    const n = q?.toLowerCase();
    return delay(db.profiles.filter((p) => !n || `${p.full_name} ${p.email}`.toLowerCase().includes(n)));
  },

  async updateProfile(id, patch) {
    requireAdmin();
    const p = db.profiles.find((x) => x.id === id);
    if (p) Object.assign(p, patch);
    save();
  },

  // ─── Fase 9: logistica Rider (DEMO: nessun file reale caricato, flotta simulata dichiarata) ───
  riderApply: async (input) => {
    if (db.settings.rider_signup_enabled === false) throw new Error('Le candidature Rider sono momentaneamente chiuse.');
    return delay(logistics.apply(input));
  },
  riderUploadDocument: async (type, file, expires) => {
    const up = await prepareUpload(file, 'document');
    await delay(null);
    logistics.addDocument(type, up.name, expires);
  },
  getRiderHome: async () => delay(logistics.home(), 0),
  riderSetOnline: async (online, consent) => delay(logistics.setOnline(online, consent)),
  riderSendLocation: async (p) => delay(logistics.location(p), 0),
  riderRespondOffer: async (id, accept, reason) => delay(logistics.respond(id, accept, reason ?? null)),
  getRiderJob: async (id) => delay(logistics.job(id), 0),
  riderJobAction: async (id, action, payload) => delay(logistics.action(id, action, payload ?? {})),
  riderUploadProof: async (jobId, file) => {
    const up = await prepareUpload(file, 'proof');
    return delay(`${currentUser() ?? 'x'}/${jobId}-${up.name}`);
  },
  getRiderEarnings: async () => delay(logistics.earnings(), 0),
  refreshDeliveryEta: async () => undefined,
  getOrderDelivery: async (num, token) => delay(logistics.orderDelivery(num, token), 0),
  rateDelivery: async (num, rating, comment) => {
    await delay(null);
    logistics.rate(num, rating, comment ?? null);
  },
  getRestaurantDeliveries: async (id) => delay(logistics.restaurantDeliveries(id), 0),
  adminListRiders: async (f) => delay(logistics.adminRiders(f ?? {}), 0),
  adminRiderDetail: async (id) => delay(logistics.adminRiderDetail(id), 0),
  adminRiderAction: async (id, action, reason) => {
    await delay(null);
    logistics.adminRiderAction(id, action, reason ?? null);
  },
  adminReviewRiderDocument: async (id, status, note) => {
    await delay(null);
    logistics.adminReviewDocument(id, status, note ?? null);
  },
  adminRiderDocumentUrl: async () => null,
  getDispatchBoard: async () => delay(logistics.dispatchBoard(), 0),
  adminAssignDelivery: async (job, rider) => {
    await delay(null);
    logistics.assign(job, rider);
  },
  adminDeliveryAction: async (job, action, payload) => {
    await delay(null);
    logistics.jobAction(job, action, payload ?? {});
  },
  adminDeliveryDetail: async (id) => delay(logistics.jobDetail(id), 0),
  adminListEarnings: async () => delay(logistics.allEarnings(), 0),
  adminEarningAction: async (id, action, amount, note) => {
    await delay(null);
    logistics.earningAction(id, action, amount ?? null, note ?? null);
  },
  adminEarningCreate: async (job, amount, note) => {
    await delay(null);
    logistics.earningCreate(job, amount, note);
  },
  adminSetRestaurantLogistics: async (id, enabled) => {
    await delay(null);
    logistics.setRestaurantLogistics(id, enabled);
  },
  getLogisticsStats: async (days) => delay(logistics.stats(days ?? 30), 0),
  runLogisticsTick: async () => delay(logistics.tick(), 0),
  getLogisticsSettings: async () => delay(logistics.settings(), 0),
  saveLogisticsSettings: async (patch) => {
    await delay(null);
    logistics.saveSettings(patch);
  },
  listServiceZones: async () => delay(clone(logistics.zones()), 0),
  saveServiceZone: async (z) => delay(logistics.saveZone(z)),
  deleteServiceZone: async (id) => {
    await delay(null);
    logistics.deleteZone(id);
  },
  listCompensationRules: async () => delay(clone(logistics.rules()), 0),
  saveCompensationRule: async (k) => delay(logistics.saveRule(k)),
  updateLogisticsAlert: async (id, status) => {
    await delay(null);
    logistics.alertUpdate(id, status);
  },

  // ─── Fase 11: piattaforma, privacy, supporto, monitoraggio (DEMO) ───
  getRuntimeConfig: async () => delay(platform.runtimeConfig(), 0),
  recordConsent: async (choices, anon, source) => delay(platform.recordConsent(choices, anon, source), 0),
  getMyConsents: async () => delay(platform.myConsents(), 0),
  exportMyData: async () => delay(platform.exportMyData(), 200),
  getPrivacyStatus: async () => delay(platform.privacyStatus(), 0),
  requestAccountDeletion: async (password, reason) => delay(platform.requestDeletion(password, reason ?? null)),
  cancelAccountDeletion: async () => delay(platform.cancelDeletion()),
  createSupportTicket: async (input) => delay(platform.createTicket(input)),
  getMySupportTickets: async () => delay(platform.myTickets(), 0),
  reportClientError: (e) => platform.clientError(e),
  recordWebVital: (v) => platform.webVital(v),
  getSlugRedirect: async (slug) => delay(platform.slugRedirect(slug), 0),
  redeemBetaInvite: async (token) => delay(platform.redeemInvite(token)),
  recordAdminSession: () => platform.adminSession(),
  getSystemStatus: async () => delay(platform.systemStatus(), 0),
  adminSetFlag: async (flag, value) => delay(platform.setFlag(flag, value)),
  getLaunchChecklist: async () => delay(platform.checklist(), 0),
  setLaunchCheck: async (key, status, notes) => delay(platform.setCheck(key, status, notes ?? null)),
  adminSupportTickets: async (filter, limit, offset) => delay(platform.adminTickets(filter, limit, offset), 0),
  adminSupportUpdate: async (id, patch) => delay(platform.adminUpdateTicket(id, patch)),
  adminPrivacyRequests: async () => delay(platform.privacyRequests(), 0),
  adminDeletionAction: async (id, action) => delay(platform.deletionAction(id, action)),
  adminRetryJob: async () => {
    throw new Error('In modalità DEMO non ci sono job in background.');
  },
  adminAuditList: async (kind, limit, offset, action) => delay(platform.auditList(kind, limit, offset, action ?? null), 0),
  getConsistencyReport: async () => delay(platform.consistency(), 0),
  adminCreateBetaInvite: async (email, role, days) => delay(platform.createInvite(email, role, days)),
  adminCreateLegalVersion: async (type, version, url, isDraft) => delay(platform.createLegalVersion(type, version, url, isDraft)),

  // ─── Import ────────────────────────────────────────────────
  async getRestaurantsForMatching(cityIds) {
    return delay(
      db.restaurants
        .filter((r) => cityIds.includes(r.city_id))
        .map((r) => ({
          ...(r as unknown as ExistingRestaurant),
          category_slugs: db.restaurant_categories.filter((rc) => rc.restaurant_id === r.id).map((rc) => db.categories.find((c) => c.id === rc.category_id)?.slug).filter((s): s is string => !!s),
        })),
      0,
    );
  },

  async importRestaurant(op, batchId): Promise<ImportResult> {
    requireAdmin();
    const data = Object.fromEntries(Object.entries(op.data).filter(([k]) => IMPORT_FIELDS.has(k)));
    let r: Restaurant | undefined;
    let action: ImportResult['action'];
    if (!op.restaurantId) {
      if (!data.name || !data.city_id) throw new Error('name e city_id sono obbligatori');
      const city = db.cities.find((c) => c.id === data.city_id);
      r = { ...blankRestaurant(), ...(data as Partial<Restaurant>), slug: uniqueSlug(String(data.slug || data.name)) } as Restaurant;
      Object.assign(r, { province_id: city?.province_id ?? null, region_id: city?.region_id ?? null });
      db.restaurants.push(r);
      action = 'created';
    } else {
      r = db.restaurants.find((x) => x.id === op.restaurantId);
      if (!r) throw new Error('Ristorante non trovato');
      delete data.slug;
      Object.assign(r, data, { updated_at: now() });
      action = 'updated';
    }
    const id = r.id;
    if (op.categorySlugs) {
      if (op.replaceCategories) db.restaurant_categories = db.restaurant_categories.filter((x) => x.restaurant_id !== id);
      const hasPrimary = () => db.restaurant_categories.some((x) => x.restaurant_id === id && x.is_primary);
      op.categorySlugs.forEach((slug) => {
        const c = db.categories.find((x) => x.slug === slug);
        if (c && !db.restaurant_categories.some((x) => x.restaurant_id === id && x.category_id === c.id)) {
          db.restaurant_categories.push({ restaurant_id: id, category_id: c.id, is_primary: !hasPrimary() });
        }
      });
    }
    if (op.source && (op.source.source_url || op.source.source_name)) {
      const existing = db.restaurant_sources.find((s) => s.restaurant_id === id && (op.source!.source_url ? s.source_url === op.source!.source_url : !s.source_url && s.source_name === op.source!.source_name));
      if (existing) Object.assign(existing, { last_checked_at: op.source.last_checked_at ?? now(), updated_at: now() });
      else {
        db.restaurant_sources.push({
          id: uuid(), restaurant_id: id, source_type: op.source.source_type, source_name: op.source.source_name, source_url: op.source.source_url,
          external_id: op.source.external_id, is_primary: !db.restaurant_sources.some((s) => s.restaurant_id === id && s.is_primary), notes: null,
          last_checked_at: op.source.last_checked_at ?? now(), import_batch_id: batchId ?? null, created_at: now(), updated_at: now(),
        });
      }
    }
    save();
    return { id, slug: r.slug, action };
  },

  async createImportBatch(batch) {
    requireAdmin();
    const b: ImportBatch = {
      id: uuid(), created_by: currentUser(), file_name: null, format: null, total_rows: 0, created_count: 0, updated_count: 0,
      merged_count: 0, skipped_count: 0, error_count: 0, errors: [], options: {}, created_at: now(), ...batch,
    };
    db.import_batches.unshift(b);
    save();
    return delay(b, 0);
  },

  async listImportBatches() {
    return delay(db.import_batches.slice(0, 20));
  },
  // ═══ Fatturazione (DEMO: flussi simulati, nessun addebito) ═══
  async getBillingOverview(restaurantId) {
    requireManage(restaurantId);
    const plan = refreshPlan(restaurantId);
    save();
    const uid = currentUser();
    const out: BillingOverview = {
      effective_plan: plan,
      effective: effectiveSub(restaurantId),
      stripe: stripeSubOf(restaurantId),
      can_manage_billing: canBill(restaurantId),
      trial_eligible: trialEligible(restaurantId, uid),
      trial_days: setting('billing_trial_days', 30),
      require_payment_method_for_trial: setting('billing_require_payment_method_for_trial', false),
      grace_days: setting('billing_payment_grace_period_days', 3),
      trial_expiring_days: setting('billing_trial_expiring_days', 3),
      invoices: db.billing_invoices.filter((i) => i.restaurant_id === restaurantId).slice(0, 24),
      activity: db.billing_activity.filter((a) => a.restaurant_id === restaurantId && a.event !== 'email_error').slice(0, 20).map(({ event, data, created_at }) => ({ event, data, created_at })),
    };
    return delay(out);
  },

  async getBillingAccount() {
    const uid = currentUser();
    return delay(uid ? db.billing_accounts.find((a) => a.owner_user_id === uid) ?? null : null, 0);
  },

  async saveBillingAccount(input) {
    const uid = currentUser();
    if (!uid) throw new Error('Accedi per continuare.');
    const clean = (v: string | null | undefined) => (v ?? '').trim() || null;
    const up = (v: string | null | undefined) => clean(v)?.replace(/\s+/g, '').toUpperCase() ?? null;
    const data = {
      business_name: clean(input.business_name), vat_number: up(input.vat_number), tax_code: up(input.tax_code),
      billing_email: clean(input.billing_email)?.toLowerCase() ?? null, pec: clean(input.pec)?.toLowerCase() ?? null,
      recipient_code: up(input.recipient_code), address_line: clean(input.address_line), postal_code: clean(input.postal_code),
      city: clean(input.city), province: clean(input.province), country: (clean(input.country) ?? 'IT').toUpperCase(),
    };
    if (data.vat_number && !/^[A-Z]{0,2}[0-9A-Z]{8,14}$/.test(data.vat_number)) throw new Error('Partita IVA non valida.');
    if (data.tax_code && !/^[0-9A-Z]{11,16}$/.test(data.tax_code)) throw new Error('Codice fiscale non valido.');
    if (data.recipient_code && !/^[0-9A-Z]{6,7}$/.test(data.recipient_code)) throw new Error('Codice destinatario non valido (7 caratteri).');
    const a = ensureAccount(uid);
    Object.assign(a, data, { updated_at: now() });
    save();
    return delay(a, 0);
  },

  async startCheckout(input) {
    requireBill(input.restaurant_id);
    const uid = currentUser()!;
    const plan = db.subscription_plans.find((p) => p.code === input.plan && p.is_active);
    if (!plan || plan.code === 'free' || !(plan.monthly_price > 0)) throw new Error('Piano non valido o non più disponibile.');
    if (!planPriceCents(plan.code, input.billing_interval)) throw new Error('Questo piano non è ancora acquistabile online (prezzo non configurato).');
    const existing = stripeSubOf(input.restaurant_id);
    if (existing && LIVE_STATUSES.includes(existing.status)) throw new Error('Il locale ha già un abbonamento attivo: usa «Cambia piano» dalla pagina Fatturazione.');
    const promo = findPromotion(input.promotion_code, plan.code, input.restaurant_id);
    let trial = plan.trial_enabled !== false && trialEligible(input.restaurant_id, uid) ? setting('billing_trial_days', 30) : 0;
    if (promo?.discount_type === 'free_days') trial = Math.max(trial, promo.free_days ?? 0);
    const c: DemoCheckout = {
      id: `cs_test_demo${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`, restaurant_id: input.restaurant_id, user_id: uid,
      plan: plan.code, interval: input.billing_interval, trial_days: trial, require_payment_method: setting('billing_require_payment_method_for_trial', false),
      promotion_id: promo?.id ?? null, status: 'open', subscription_id: null, created_at: now(),
    };
    db.demo_checkouts.push(c);
    save();
    return delay({ url: `/dashboard/billing/demo-checkout?session=${c.id}`, trial_days: trial });
  },

  async openBillingPortal(restaurantId, flow) {
    requireBill(restaurantId);
    const s = stripeSubOf(restaurantId);
    if (!s) throw new Error('Non c’è ancora un profilo di pagamento per questo locale: attiva prima un piano.');
    return delay({ url: `/dashboard/billing/demo-portal?restaurant=${restaurantId}${flow ? `&flow=${flow}` : ''}` });
  },

  async confirmCheckout(sessionId) {
    const c = db.demo_checkouts.find((x) => x.id === sessionId);
    if (!c) throw new Error('Sessione di pagamento non trovata.');
    requireBill(c.restaurant_id);
    const sub = db.subscriptions.find((s) => s.id === c.subscription_id);
    return delay({
      status: c.status, payment_status: c.status === 'complete' ? (c.trial_days ? 'no_payment_required' : 'paid') : 'unpaid', restaurant_id: c.restaurant_id,
      plan_code: c.plan, billing_interval: c.interval, subscription_status: sub?.status ?? null, effective_plan: sub ? refreshPlan(c.restaurant_id) : null,
      trial_days: c.trial_days, require_payment_method: c.require_payment_method,
    });
  },

  async previewPlanChange(restaurantId, plan, interval) {
    requireBill(restaurantId);
    const s = liveStripeSub(restaurantId);
    const target = db.subscription_plans.find((p) => p.code === plan && p.is_active && p.code !== 'free');
    if (!target) throw new Error('Piano non valido o non più disponibile.');
    if (s.plan_code === plan && s.billing_interval === interval) throw new Error('Hai già questo piano con questo periodo di fatturazione.');
    const kind: ChangePreview['kind'] =
      planSort(plan) > planSort(s.plan_code) ? 'upgrade' : planSort(plan) < planSort(s.plan_code) ? 'downgrade' : interval === 'year' ? 'interval_up' : 'interval_down';
    const immediate = kind === 'upgrade' || kind === 'interval_up' || s.status === 'trialing' || setting<string>('billing_downgrade_timing', 'period_end') === 'immediate';
    const newCents = planPriceCents(plan, interval);
    const oldCents = s.unit_amount_cents ?? planPriceCents(s.plan_code, s.billing_interval);
    const start = Date.parse(s.current_period_start);
    const end = s.current_period_end ? Date.parse(s.current_period_end) : start + 30 * DAY_MS;
    const frac = Math.max(0, Math.min(1, (end - Date.now()) / (end - start || 1)));
    let amount = 0;
    if (immediate && s.status !== 'trialing' && setting<string>('billing_proration_behavior', 'always_invoice') !== 'none') {
      amount = interval !== s.billing_interval ? Math.max(0, newCents - Math.round(oldCents * frac)) : Math.max(0, Math.round((newCents - oldCents) * frac));
    }
    const out: ChangePreview = {
      kind, immediate, trialing: s.status === 'trialing', amount_due_cents: amount, currency: 'EUR', charged_now: immediate && amount > 0,
      effective_at: immediate ? now() : s.current_period_end,
      target: { plan_code: plan, plan_name: target.name, interval, amount: newCents / 100 },
    };
    return delay(out);
  },

  async changePlan(restaurantId, plan, interval) {
    const p = await demoSource.previewPlanChange(restaurantId, plan, interval);
    const s = liveStripeSub(restaurantId);
    if (p.immediate) {
      const from = s.plan_code;
      const intervalChanged = s.billing_interval !== interval;
      Object.assign(s, {
        plan_code: plan, billing_interval: interval, unit_amount_cents: planPriceCents(plan, interval), stripe_price_id: `price_demo_${plan}_${interval}`,
        scheduled_plan_code: null, scheduled_interval: null, scheduled_change_at: null, stripe_schedule_id: null, updated_at: now(),
      });
      if (intervalChanged && s.status !== 'trialing') Object.assign(s, { current_period_start: now(), current_period_end: addPeriod(Date.now(), interval) });
      if (p.amount_due_cents > 0) demoInvoice(s, p.amount_due_cents);
      if (from !== plan) {
        billingLog(restaurantId, s.id, planSort(plan) > planSort(from) ? 'subscription_upgraded' : 'subscription_downgraded', { from, to: plan });
        billingNotify(restaurantId, `Piano aggiornato: ${planName(plan)}`, `Il locale è passato dal piano ${planName(from)} al piano ${planName(plan)}.`);
      } else billingLog(restaurantId, s.id, 'interval_changed', { to: interval });
      demoEvent('customer.subscription.updated', s.stripe_subscription_id, restaurantId);
      refreshPlan(restaurantId);
      save();
      return delay({ status: 'updated' as const, effective_at: now() });
    }
    Object.assign(s, { scheduled_plan_code: plan, scheduled_interval: interval, scheduled_change_at: s.current_period_end, stripe_schedule_id: demoId('sub_sched'), cancel_at_period_end: false, updated_at: now() });
    billingLog(restaurantId, s.id, 'change_scheduled', { plan, interval, at: s.current_period_end });
    demoEvent('subscription_schedule.created', s.stripe_schedule_id, restaurantId);
    save();
    return delay({ status: 'scheduled' as const, effective_at: s.current_period_end });
  },

  async cancelSubscription(restaurantId) {
    requireBill(restaurantId);
    const s = stripeSubOf(restaurantId);
    if (!s || !LIVE_STATUSES.includes(s.status)) throw new Error('Nessun abbonamento attivo da modificare.');
    Object.assign(s, { cancel_at_period_end: true, scheduled_plan_code: null, scheduled_interval: null, scheduled_change_at: null, stripe_schedule_id: null, updated_at: now() });
    const until = s.status === 'trialing' ? s.trial_end : s.current_period_end;
    billingLog(restaurantId, s.id, 'subscription_cancelled', { until });
    billingNotify(restaurantId, 'Abbonamento cancellato', `Potrai continuare a usare ${planName(s.plan_code)} fino al ${itDate(until)}.`, 'billing_subscription_cancelled');
    demoEvent('customer.subscription.updated', s.stripe_subscription_id, restaurantId);
    save();
    return delay({ until });
  },

  async resumeSubscription(restaurantId) {
    requireBill(restaurantId);
    const s = stripeSubOf(restaurantId);
    if (!s || !LIVE_STATUSES.includes(s.status)) throw new Error('Nessun abbonamento attivo da modificare.');
    s.cancel_at_period_end = false;
    billingLog(restaurantId, s.id, 'subscription_resumed');
    billingNotify(restaurantId, 'Abbonamento riattivato', `Il piano ${planName(s.plan_code)} si rinnoverà regolarmente.`);
    demoEvent('customer.subscription.updated', s.stripe_subscription_id, restaurantId);
    save();
  },

  async cancelScheduledChange(restaurantId) {
    requireBill(restaurantId);
    const s = liveStripeSub(restaurantId);
    Object.assign(s, { scheduled_plan_code: null, scheduled_interval: null, scheduled_change_at: null, stripe_schedule_id: null });
    billingLog(restaurantId, s.id, 'change_cancelled');
    save();
  },

  async refreshInvoices(restaurantId) {
    requireBill(restaurantId);
  },

  async simulateBilling(action, payload) {
    if (action === 'complete_checkout') {
      const c = db.demo_checkouts.find((x) => x.id === payload.sessionId);
      if (!c || c.status !== 'open') throw new Error('Sessione di pagamento non trovata o già completata.');
      requireBill(c.restaurant_id);
      const card = payload.card !== false;
      if (!card && (!c.trial_days || c.require_payment_method)) throw new Error('Per questo pagamento serve una carta.');
      const acc = ensureAccount(c.user_id);
      acc.stripe_customer_id ??= demoId('cus');
      acc.stripe_environment = 'test';
      const t = Date.now();
      const trial = c.trial_days > 0;
      const periodEnd = new Date(t + (trial ? c.trial_days : c.interval === 'year' ? 365 : 30) * DAY_MS).toISOString();
      const sub: Subscription = {
        ...clone(demo.demoSubscriptions[0]!),
        id: uuid(), restaurant_id: c.restaurant_id, user_id: c.user_id, billing_account_id: acc.id, plan_id: null, plan_code: c.plan,
        status: trial ? 'trialing' : 'active', source: 'stripe', billing_interval: c.interval, stripe_customer_id: acc.stripe_customer_id,
        stripe_subscription_id: demoId('sub'), stripe_price_id: `price_demo_${c.plan}_${c.interval}`, stripe_environment: 'test',
        trial_start: trial ? now() : null, trial_end: trial ? periodEnd : null, current_period_start: now(), current_period_end: periodEnd,
        unit_amount_cents: planPriceCents(c.plan, c.interval), paid_started_at: trial ? null : now(),
        pm_brand: card ? 'visa' : null, pm_last4: card ? '4242' : null, pm_exp_month: card ? 12 : null, pm_exp_year: card ? 2030 : null,
        notes: 'DEMO — abbonamento simulato, nessun addebito', created_at: now(), updated_at: now(),
      };
      db.subscriptions.push(sub);
      Object.assign(c, { status: 'complete', subscription_id: sub.id });
      if (trial) {
        db.billing_trials.push({ restaurant_id: c.restaurant_id, user_id: c.user_id, vat_number: acc.vat_number, plan_code: c.plan, started_at: now(), ends_at: periodEnd, converted_at: null });
        billingLog(c.restaurant_id, sub.id, 'trial_started', { plan: c.plan, trial_end: periodEnd });
        billingNotify(c.restaurant_id, `Prova ${planName(c.plan)} attivata`, `La prova gratuita del piano ${planName(c.plan)} è attiva fino al ${itDate(periodEnd)}.`, 'billing_trial_started');
      } else {
        demoInvoice(sub, sub.unit_amount_cents ?? 0);
        billingLog(c.restaurant_id, sub.id, 'subscription_started', { plan: c.plan, interval: c.interval });
        billingNotify(c.restaurant_id, `Abbonamento ${planName(c.plan)} attivato`, `Il piano ${planName(c.plan)} è attivo.`, 'billing_subscription_activated');
      }
      if (c.promotion_id) {
        db.billing_promotion_redemptions.push({ promotion_id: c.promotion_id, restaurant_id: c.restaurant_id, created_at: now() });
        const promo = db.billing_promotions.find((p) => p.id === c.promotion_id);
        if (promo) promo.redemptions_count += 1;
      }
      demoEvent('customer.subscription.created', sub.stripe_subscription_id, c.restaurant_id);
      demoEvent('checkout.session.completed', c.id, c.restaurant_id);
      refreshPlan(c.restaurant_id);
      save();
      return;
    }
    const rid = payload.restaurantId ?? '';
    if (!(isAdminUser() || canBill(rid))) throw new Error('Operazione non consentita.');
    const s = stripeSubOf(rid);
    if (!s) throw new Error('Nessun abbonamento Stripe (simulato) per questo locale.');
    const t = Date.now();
    if (action === 'update_card') {
      Object.assign(s, { pm_brand: 'visa', pm_last4: '4242', pm_exp_month: 12, pm_exp_year: 2030 });
      demoEvent('payment_method.attached', null, rid);
    } else if (action === 'end_trial') {
      if (s.status !== 'trialing') throw new Error('L’abbonamento non è in prova.');
      const trialRow = db.billing_trials.find((x) => x.restaurant_id === rid);
      if (trialRow) trialRow.ends_at = now();
      if (s.pm_last4) {
        Object.assign(s, { status: 'active', trial_end: new Date(t - 1000).toISOString(), current_period_start: now(), current_period_end: addPeriod(t, s.billing_interval), paid_started_at: s.paid_started_at ?? now() });
        demoInvoice(s, s.unit_amount_cents ?? 0);
        if (trialRow) trialRow.converted_at = now();
        billingLog(rid, s.id, 'trial_ended', { converted: true });
        billingLog(rid, s.id, 'subscription_started', { plan: s.plan_code });
        billingNotify(rid, `Abbonamento ${planName(s.plan_code)} attivato`, `La prova è terminata e il piano ${planName(s.plan_code)} è ora attivo.`, 'billing_subscription_activated');
      } else {
        Object.assign(s, { status: 'canceled', trial_end: new Date(t - 1000).toISOString(), current_period_end: new Date(t - 1000).toISOString(), ended_at: now(), cancelled_at: now() });
        billingLog(rid, s.id, 'trial_ended', { converted: false });
        billingNotify(rid, 'Prova gratuita terminata', 'La prova è terminata: il locale è tornato al piano Free. Puoi attivare un piano in qualsiasi momento.');
      }
      demoEvent('customer.subscription.updated', s.stripe_subscription_id, rid);
    } else if (action === 'fail_payment') {
      if (s.status !== 'active') throw new Error('Serve un abbonamento attivo.');
      Object.assign(s, { status: 'past_due', payment_failed_at: now() });
      demoInvoice(s, s.unit_amount_cents ?? 0, 'open');
      billingLog(rid, s.id, 'payment_failed');
      billingNotify(rid, 'Problema con il pagamento del tuo abbonamento',
        `Non siamo riusciti ad addebitare il piano ${planName(s.plan_code)}. Aggiorna il metodo di pagamento: le funzioni restano attive per ${setting('billing_payment_grace_period_days', 3)} giorni.`, 'billing_payment_failed');
    } else if (action === 'pay_invoice') {
      const inv = db.billing_invoices.find((i) => i.subscription_id === s.id && i.status === 'open');
      if (inv) Object.assign(inv, { status: 'paid', amount_paid_cents: inv.amount_due_cents });
      const wasFailed = !!s.payment_failed_at;
      Object.assign(s, { status: 'active', payment_failed_at: null, latest_invoice_status: 'paid' });
      billingLog(rid, s.id, wasFailed ? 'payment_recovered' : 'payment_succeeded');
      billingNotify(rid, 'Pagamento ricevuto', `Il pagamento del piano ${planName(s.plan_code)} è andato a buon fine. Grazie!`, 'billing_payment_succeeded');
      demoEvent('invoice.paid', inv?.stripe_invoice_id ?? null, rid);
    } else if (action === 'reach_period_end') {
      if (s.cancel_at_period_end || s.status === 'canceled') {
        Object.assign(s, { status: 'canceled', current_period_end: new Date(t - 1000).toISOString(), ended_at: now(), cancelled_at: s.cancelled_at ?? now() });
        billingLog(rid, s.id, 'subscription_ended', { plan: s.plan_code });
        demoEvent('customer.subscription.deleted', s.stripe_subscription_id, rid);
      } else {
        if (s.scheduled_plan_code) {
          const from = s.plan_code;
          const to = s.scheduled_plan_code;
          Object.assign(s, { plan_code: to, billing_interval: s.scheduled_interval ?? s.billing_interval, unit_amount_cents: planPriceCents(to, s.scheduled_interval ?? s.billing_interval), scheduled_plan_code: null, scheduled_interval: null, scheduled_change_at: null, stripe_schedule_id: null });
          if (from !== to) billingLog(rid, s.id, planSort(to) > planSort(from) ? 'subscription_upgraded' : 'subscription_downgraded', { from, to });
          else billingLog(rid, s.id, 'interval_changed', { to: s.billing_interval });
        }
        Object.assign(s, { current_period_start: now(), current_period_end: addPeriod(t, s.billing_interval), status: 'active', trial_end: s.status === 'trialing' ? now() : s.trial_end });
        demoInvoice(s, s.unit_amount_cents ?? 0);
        demoEvent('customer.subscription.updated', s.stripe_subscription_id, rid);
      }
    }
    s.updated_at = now();
    refreshPlan(rid);
    save();
  },

  // ─── Onboarding ────────────────────────────────────────────
  async getProfileCompletion(restaurantId) {
    requireManage(restaurantId);
    const r = db.restaurants.find((x) => x.id === restaurantId)!;
    const has = (k: FeatureKey) => restHasFeature(restaurantId, k);
    const items: ProfileCompletion['items'] = [
      { key: 'name', done: !!r.name.trim(), available: true },
      { key: 'phone', done: !!r.phone?.trim(), available: true },
      { key: 'address', done: !!r.address?.trim(), available: true },
      { key: 'logo', done: !!r.logo_url, available: true },
      { key: 'cover', done: !!r.cover_url, available: true },
      { key: 'hours', done: db.restaurant_hours.some((h) => h.restaurant_id === r.id), available: true },
      { key: 'categories', done: db.restaurant_categories.some((c) => c.restaurant_id === r.id), available: true },
      { key: 'menu', done: db.menu_items.some((i) => i.restaurant_id === r.id), available: has('menu_enabled'), feature: 'menu_enabled' },
      { key: 'photos', done: db.restaurant_images.some((i) => i.restaurant_id === r.id), available: true },
      { key: 'offer', done: db.offers.some((o) => o.restaurant_id === r.id && o.is_active), available: has('offers_enabled'), feature: 'offers_enabled' },
      { key: 'reservations', done: db.reservation_settings.some((x) => x.restaurant_id === r.id && x.reservation_enabled), available: has('reservations_enabled'), feature: 'reservations_enabled' },
    ];
    const avail = items.filter((i) => i.available);
    const done = avail.filter((i) => i.done).length;
    return delay({
      items, done, total: avail.length, profile_completion_percentage: avail.length ? Math.round((done * 100) / avail.length) : 0,
      onboarding_completed_at: r.onboarding_completed_at ?? null, is_active: r.is_active, publication_requested_at: r.publication_requested_at ?? null,
    });
  },

  async completeOnboarding(restaurantId) {
    requireManage(restaurantId);
    const r = db.restaurants.find((x) => x.id === restaurantId)!;
    r.onboarding_completed_at ??= now();
    save();
  },

  async requestPublication(restaurantId) {
    requireManage(restaurantId);
    const r = db.restaurants.find((x) => x.id === restaurantId)!;
    if (r.is_active) return 'already_public';
    if (r.publication_requested_at && Date.now() - Date.parse(r.publication_requested_at) < DAY_MS) return 'already_requested';
    if (!r.phone?.trim() || !r.address?.trim()) throw new Error('Completa telefono e indirizzo prima di pubblicare');
    r.publication_requested_at = now();
    notifyAdmins('publication', 'Richiesta di pubblicazione', `${r.name} chiede di essere pubblicato`, `/admin/restaurants/${r.id}`);
    save();
    return 'requested';
  },

  // ─── Sponsorizzazioni ──────────────────────────────────────
  async getSponsoredSlots(placement, ctx = {}) {
    const city = ctx.citySlug ? db.cities.find((c) => c.slug === ctx.citySlug) : null;
    const cat = ctx.categorySlug ? db.categories.find((c) => c.slug === ctx.categorySlug) : null;
    if ((ctx.citySlug && !city) || (ctx.categorySlug && !cat)) return [];
    const day = localNow().date;
    const hash = (s: string) => [...s].reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) >>> 0, 7);
    const seen = new Set<string>();
    const rows = db.sponsored_campaigns
      .filter((c) => c.placement === placement && campaignLive(c))
      .filter((c) => {
        const r = db.restaurants.find((x) => x.id === c.restaurant_id);
        if (!r || !isPublic(r)) return false;
        if (city && ((c.target_cities.length && !c.target_cities.includes(city.id)) || r.city_id !== city.id)) return false;
        if (cat && ((c.target_categories.length && !c.target_categories.includes(cat.id)) || !db.restaurant_categories.some((x) => x.restaurant_id === r.id && x.category_id === cat.id))) return false;
        return true;
      })
      .sort((a, b) => b.priority - a.priority || hash(a.id + day) - hash(b.id + day))
      .filter((c) => (seen.has(c.restaurant_id) ? false : (seen.add(c.restaurant_id), true)))
      .slice(0, Math.min(Math.max(ctx.limit ?? 2, 1), 6));
    const out: SponsoredSlot[] = rows.map((c) => ({ campaign_id: c.id, placement: c.placement, restaurant: summary(db.restaurants.find((x) => x.id === c.restaurant_id)!) }));
    return delay(out, 0);
  },

  trackSponsored(campaignId, type, placement) {
    const c = db.sponsored_campaigns.find((x) => x.id === campaignId);
    if (!c || !campaignLive(c) || c.placement !== placement) return;
    const sid = demoSessionId();
    const windowMs = type === 'sponsored_impression' ? 30 * 60_000 : 10_000;
    if (db.analytics.some((e) => e.campaign_id === campaignId && e.session_id === sid && e.event_type === type && Date.now() - Date.parse(e.created_at) < windowMs)) return;
    db.analytics.push({ restaurant_id: c.restaurant_id, event_type: type, source: placement, created_at: now(), campaign_id: campaignId, session_id: sid });
    save();
  },

  async getCampaignStats(restaurantId, days = 30) {
    if (restaurantId === null) requireAdmin();
    else {
      requireManage(restaurantId);
      if (!isAdminUser() && !restHasFeature(restaurantId, 'sponsored_ads')) throw new PlanError('feature', 'sponsored_ads');
    }
    const since = Date.now() - Math.min(Math.max(days, 1), 365) * DAY_MS;
    const rows: CampaignStats[] = db.sponsored_campaigns
      .filter((c) => restaurantId === null || c.restaurant_id === restaurantId)
      .map((c) => {
        const ev = db.analytics.filter((e) => e.campaign_id === c.id && Date.parse(e.created_at) >= since);
        const impressions = ev.filter((e) => e.event_type === 'sponsored_impression').length;
        const clicks = ev.filter((e) => e.event_type === 'sponsored_click').length;
        return {
          campaign_id: c.id, restaurant_id: c.restaurant_id, restaurant_name: db.restaurants.find((r) => r.id === c.restaurant_id)?.name ?? '', name: c.name,
          placement: c.placement, status: c.status, display_status: campaignDisplayStatus(c), start_date: c.start_date, end_date: c.end_date, priority: c.priority,
          daily_budget: c.daily_budget, total_budget: c.total_budget, spend: c.spend, impressions, clicks, ctr: impressions ? Math.round((clicks * 10000) / impressions) / 100 : 0,
        };
      })
      .sort((a, b) => Number(['active', 'scheduled'].includes(b.status)) - Number(['active', 'scheduled'].includes(a.status)) || b.start_date.localeCompare(a.start_date));
    return delay(rows);
  },

  // ─── Admin fatturazione ────────────────────────────────────
  async adminListSubscriptions(filter = {}) {
    requireAdmin();
    const t = Date.now();
    let rows = db.subscriptions.filter((s) => {
      if (filter.plan && s.plan_code !== filter.plan) return false;
      if (filter.source && s.source !== filter.source) return false;
      if (filter.status && s.status !== filter.status) return false;
      if (filter.view === 'trial') return s.status === 'trialing';
      if (filter.view === 'past_due') return s.status === 'past_due' || s.status === 'unpaid';
      if (filter.view === 'active') return ['active', 'trialing', 'past_due'].includes(s.status);
      if (filter.view === 'expired') return ['canceled', 'incomplete_expired'].includes(s.status) || !!s.revoked_at || (!!s.expires_at && Date.parse(s.expires_at) < t);
      return true;
    });
    const out: AdminSubscriptionRow[] = rows.map((s) => {
      const r = db.restaurants.find((x) => x.id === s.restaurant_id);
      const ownerId = s.user_id ?? db.restaurant_members.find((m) => m.restaurant_id === s.restaurant_id && m.role === 'owner' && m.status === 'active')?.user_id;
      const p = ownerId ? getDemoProfile(ownerId) : undefined;
      const inv = db.billing_invoices.find((i) => i.subscription_id === s.id);
      return {
        ...s,
        restaurant: r ? { id: r.id, name: r.name, slug: r.slug, subscription_plan: r.subscription_plan } : null,
        owner: p ? { id: p.id, full_name: p.full_name, email: p.email } : null,
        last_invoice: inv ? { number: inv.number, status: inv.status, amount_paid_cents: inv.amount_paid_cents, amount_due_cents: inv.amount_due_cents, hosted_invoice_url: inv.hosted_invoice_url, stripe_created_at: inv.stripe_created_at } : null,
      };
    });
    if (filter.q) {
      const n = filter.q.toLowerCase();
      rows = [];
      return delay(out.filter((x) => `${x.restaurant?.name ?? ''} ${x.owner?.email ?? ''} ${x.stripe_subscription_id ?? ''}`.toLowerCase().includes(n)));
    }
    return delay(out.sort((a, b) => b.created_at.localeCompare(a.created_at)));
  },

  async adminGrantPlan(restaurantId, plan, expiresAt, source, note) {
    requireAdmin();
    if (expiresAt && Date.parse(expiresAt) <= Date.now()) throw new Error('La scadenza deve essere futura');
    db.subscriptions
      .filter((s) => s.restaurant_id === restaurantId && s.source !== 'stripe' && !s.revoked_at)
      .forEach((s) => Object.assign(s, { revoked_at: now(), status: 'canceled', ended_at: now() }));
    if (plan === 'free') {
      billingLog(restaurantId, null, 'plan_revoked', {});
    } else {
      const sub: Subscription = {
        ...clone(demo.demoSubscriptions[0]!), id: uuid(), restaurant_id: restaurantId, plan_code: plan, status: 'active', source,
        current_period_start: now(), current_period_end: expiresAt, expires_at: expiresAt, notes: note ?? null, created_at: now(), updated_at: now(),
        user_id: db.restaurant_members.find((m) => m.restaurant_id === restaurantId && m.role === 'owner' && m.status === 'active')?.user_id ?? null,
      };
      db.subscriptions.push(sub);
      billingLog(restaurantId, sub.id, 'plan_granted', { plan, source, expires_at: expiresAt });
      billingNotify(restaurantId, `Piano ${planName(plan)} attivato`, expiresAt ? `Il piano è stato attivato dallo staff fino al ${itDate(expiresAt)}.` : 'Il piano è stato attivato dallo staff.');
    }
    refreshPlan(restaurantId);
    save();
  },

  async adminRevokePlan(subscriptionId) {
    requireAdmin();
    const s = db.subscriptions.find((x) => x.id === subscriptionId);
    if (!s) throw new Error('Abbonamento non trovato');
    if (s.source === 'stripe') throw new Error('Gli abbonamenti Stripe si cancellano da Stripe');
    Object.assign(s, { revoked_at: now(), status: 'canceled', ended_at: now() });
    billingLog(s.restaurant_id, s.id, 'plan_revoked', { plan: s.plan_code });
    refreshPlan(s.restaurant_id);
    save();
  },

  async adminExtendManualPlan(subscriptionId, expiresAt) {
    requireAdmin();
    const s = db.subscriptions.find((x) => x.id === subscriptionId);
    if (!s || s.source === 'stripe') throw new Error('Solo piani manuali o promozionali');
    if (expiresAt && Date.parse(expiresAt) <= Date.now()) throw new Error('La scadenza deve essere futura');
    Object.assign(s, { expires_at: expiresAt, current_period_end: expiresAt, status: 'active', revoked_at: null, ended_at: null });
    billingLog(s.restaurant_id, s.id, 'trial_extended', { expires_at: expiresAt });
    refreshPlan(s.restaurant_id);
    save();
  },

  async adminBilling<T>(action: string, payload: Row = {}) {
    requireAdmin();
    let out: unknown;
    if (action === 'status') {
      out = { configured: false, simulated: true, environment: 'test', tax_enabled: false, webhook_secret_configured: false, portal_configuration: 'default', allow_promotion_codes: false, app_url: location.origin };
    } else if (action === 'sync' || action === 'sync_all' || action === 'refresh_plans') {
      const changed = refreshAllPlans();
      out = action === 'sync_all' ? { synced: db.subscriptions.filter((s) => s.source === 'stripe').length, errors: [], plans_changed: changed } : { ok: true, changed };
    } else if (action === 'extend_trial') {
      const s = db.subscriptions.find((x) => x.id === payload.subscription_id);
      const days = Number(payload.days);
      if (!s || s.source !== 'stripe' || s.status !== 'trialing') throw new Error('Solo abbonamenti in prova');
      if (!Number.isInteger(days) || days < 1 || days > 60) throw new Error('Giorni non validi (1–60)');
      s.trial_end = new Date(Math.max(Date.parse(s.trial_end ?? now()), Date.now()) + days * DAY_MS).toISOString();
      s.current_period_end = s.trial_end;
      const tr = db.billing_trials.find((x) => x.restaurant_id === s.restaurant_id);
      if (tr) tr.ends_at = s.trial_end;
      billingLog(s.restaurant_id, s.id, 'trial_extended', { days });
      out = { ok: true };
    } else if (action === 'provision_prices') {
      const plans: Row = {};
      db.subscription_plans.filter((p) => p.code !== 'free' && p.is_active).forEach((p) => {
        p.stripe_product_id ??= `prod_demo${p.code}`;
        p.stripe_monthly_price_id = `price_demo${p.code}month${Math.round(p.monthly_price * 100)}`;
        p.stripe_yearly_price_id = p.yearly_price ? `price_demo${p.code}year${Math.round(p.yearly_price * 100)}` : null;
        plans[p.code] = { product: p.stripe_product_id, monthly: p.stripe_monthly_price_id, yearly: p.stripe_yearly_price_id };
      });
      out = { environment: 'test', plans };
    }
    save();
    return delay(out as T);
  },

  async getRevenueStats() {
    requireAdmin();
    const t = Date.now();
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime();
    const stripeSubs = db.subscriptions.filter((s) => s.source === 'stripe');
    const mrr = (s: Subscription) => (s.billing_interval === 'year' ? (s.unit_amount_cents ?? 0) / 12 : s.unit_amount_cents ?? 0);
    const paying = stripeSubs.filter((s) => (s.status === 'active' || s.status === 'past_due') && grantsAccess(s));
    const sum = (list: Subscription[]) => list.reduce((a, s) => a + mrr(s), 0);
    const ended = db.billing_trials.filter((x) => (x.ends_at && Date.parse(x.ends_at) <= t) || x.converted_at);
    const series = Array.from({ length: 12 }, (_, i) => {
      const d = new Date(new Date().getFullYear(), new Date().getMonth() - 11 + i, 1);
      const next = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime();
      const inMonth = stripeSubs.filter((s) => s.paid_started_at && Date.parse(s.paid_started_at) < next && (next > t ? paying.includes(s) : !s.ended_at || Date.parse(s.ended_at) >= next));
      return { month: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`, mrr_cents: Math.round(sum(inMonth)) };
    });
    const out: RevenueStats = {
      environment: 'test',
      restaurants_total: db.restaurants.length,
      restaurants_claimed: db.restaurants.filter((r) => r.owner_id).length,
      plans: Object.fromEntries(db.subscription_plans.map((p) => [p.code, db.restaurants.filter((r) => r.subscription_plan === p.code).length])),
      paying_customers: new Set(paying.map((s) => s.billing_account_id ?? s.restaurant_id)).size,
      paying_subscriptions: paying.length,
      mrr_cents: Math.round(sum(paying)),
      arr_cents: Math.round(sum(paying) * 12),
      new_mrr_cents: Math.round(sum(stripeSubs.filter((s) => s.paid_started_at && Date.parse(s.paid_started_at) >= monthStart))),
      churned_mrr_cents: Math.round(sum(stripeSubs.filter((s) => s.ended_at && Date.parse(s.ended_at) >= monthStart && s.paid_started_at))),
      trials_active: stripeSubs.filter((s) => s.status === 'trialing' && grantsAccess(s)).length,
      trials_ended: db.billing_trials.filter((x) => x.ends_at && Date.parse(x.ends_at) <= t).length,
      trials_converted: db.billing_trials.filter((x) => x.converted_at).length,
      trial_conversion_rate: ended.length ? Math.round((db.billing_trials.filter((x) => x.converted_at).length * 1000) / ended.length) / 10 : null,
      cancel_scheduled: stripeSubs.filter((s) => s.cancel_at_period_end && ['active', 'trialing', 'past_due'].includes(s.status)).length,
      cancelled_30d: stripeSubs.filter((s) => s.status === 'canceled' && Date.parse(s.ended_at ?? s.cancelled_at ?? '1970-01-01') >= t - 30 * DAY_MS).length,
      past_due: stripeSubs.filter((s) => s.status === 'past_due' || s.status === 'unpaid').length,
      manual_active: db.subscriptions.filter((s) => s.source !== 'stripe' && grantsAccess(s)).length,
      mrr_series: series,
    };
    return delay(out);
  },

  async listStripeEvents(limit = 50) {
    requireAdmin();
    return delay(db.stripe_events.slice(0, limit));
  },
};

// Il tempo passa anche in demo: allinea i piani (fine prove, scadenze) all'avvio
if (refreshAllPlans()) save();



// ─── Accesso in sola lettura per l'assistente DEMO (stesse regole di visibilità pubblica) ───
const aiAccess: DemoAiAccess = {
  details: () => db.restaurants.filter((r) => isPublic(r) && !r.is_permanently_closed).map((r) => detail(r)),
  categories: () => db.categories,
  cities: () => db.cities,
  closures: (rid) => db.restaurant_closures.filter((x) => x.restaurant_id === rid),
  offers: () => db.offers,
  coupons: () => db.coupons,
  hasFeature: (rid, key) => restHasFeature(rid, key),
  reservationsOnline: (rid) => {
    const r = db.restaurants.find((x) => x.id === rid);
    return !!r && r.has_reservation && !r.is_temporarily_closed && restHasFeature(rid, 'reservations_enabled') && !!db.reservation_settings.find((x) => x.restaurant_id === rid)?.reservation_enabled;
  },
  availability: (rid, date, party) => demoSource.getReservationAvailability(rid, date, party),
  orderable: () => market.orderable(),
  sponsored: (placement, city, category) => {
    const c = city ? db.cities.find((x) => x.slug === city) : null;
    const k = category ? db.categories.find((x) => x.slug === category) : null;
    if ((city && !c) || (category && !k)) return [];
    const seen = new Set<string>();
    return db.sponsored_campaigns
      .filter((x) => x.placement === placement && campaignLive(x))
      .filter((x) => {
        const r = db.restaurants.find((y) => y.id === x.restaurant_id);
        if (!r || !isPublic(r)) return false;
        if (c && ((x.target_cities.length && !x.target_cities.includes(c.id)) || r.city_id !== c.id)) return false;
        if (k && ((x.target_categories.length && !x.target_categories.includes(k.id)) || !db.restaurant_categories.some((y) => y.restaurant_id === r.id && y.category_id === k.id))) return false;
        return true;
      })
      .sort((x, y) => y.priority - x.priority)
      .filter((x) => (seen.has(x.restaurant_id) ? false : (seen.add(x.restaurant_id), true)))
      .slice(0, 2)
      .map((x) => ({ campaign_id: x.id, restaurant_id: x.restaurant_id }));
  },
  setting: (key, fallback) => setting(key, fallback),
  userId: () => currentUser() ?? null,
  isPremiumOwner: (uid) => db.restaurants.some((r) => r.owner_id === uid && ['premium', 'top'].includes(planOf(r.id))),
  favorites: (uid) => db.favorites.filter((f) => f.user_id === uid).map((f) => f.restaurant_id),
  preferences: (uid) => db.ai_user_preferences?.[uid] ?? null,
  get usage() {
    return (db.ai_usage ??= []);
  },
  saveUsage: () => save(),
};

/** Solo test/diagnostica: porta dati DEMO dell'assistente. */
export const createDemoAiPort = async () => (await aiDemo()).createDemoPort(aiAccess);

// ─── Fase 7: motore di fidelizzazione DEMO (stesse regole delle funzioni SQL) ───
function engState() {
  return (db.engagement ??= engagementDefaultsLazy());
}
function engagementDefaultsLazy() {
  // import statico già presente: createEngagement inizializza lo stato alla prima lettura
  eng.getMyAchievements();
  return db.engagement!;
}
const eng = createEngagement({
  get db() {
    return db as unknown as Parameters<typeof createEngagement>[0]['db'];
  },
  save,
  uid: () => currentUser() ?? null,
  isAdmin: () => isAdminUser(),
  canManage: (rid) => canManage(rid),
  hasFeature: (rid, key) => restHasFeature(rid, key as FeatureKey),
  featureLimit: (rid, key) => {
    const f = featureRow(rid, key as FeatureKey);
    if (!f || !f.enabled) return 0;
    return f.limit_value;
  },
  isPublic: (rid) => {
    const r = db.restaurants.find((x) => x.id === rid);
    return !!r && isPublic(r) && !r.is_permanently_closed;
  },
  notifyAdmins,
  notifyRestaurant,
  enqueueEmail,
  claimCoupon: (couponId) => demoSource.claimCoupon(couponId, null, 'web'),
  orders: () => market.completedOrders(),
});

// ─── Fase 8: motore ordini DEMO ───
const marketAccess: Parameters<typeof createMarket>[0] = {
  get db() {
    return db as unknown as Parameters<typeof createMarket>[0]['db'];
  },
  defaults: () => ({
    // Seoul Grill House: abilitata dall'Admin ai Rider AsiaFood (il ristorante sceglie in "Impostazioni ordini"; di default consegna con i propri mezzi)
    order_settings: clone(demo.demoOrderSettings).map((x) => (x.restaurant_id === demo.demoOrderSettings[0]!.restaurant_id ? { ...x, asiafood_delivery_enabled: true } : x)),
    delivery_zones: clone(demo.demoDeliveryZones),
    option_groups: clone(demo.demoOptionGroups),
    orders: [],
    addresses: [],
    carts: [],
    // Seoul Grill House ha già completato l'onboarding (SIMULATO); Ramen Kōen deve ancora configurare i pagamenti
    payout_accounts: [{ restaurant_id: demo.demoOrderSettings[0]!.restaurant_id, stripe_account_id: 'acct_demo_seoul', onboarding_completed: true, charges_enabled: true, payouts_enabled: true,
      details_submitted: true, requirements_due: [], updated_at: '2026-09-20T10:00:00.000Z' }],
    commissions: [],
    track_failures: [],
  }),
  save,
  uid: () => currentUser() ?? null,
  isAdmin: () => isAdminUser(),
  canManage: (rid) => canManage(rid),
  hasFeature: (rid, key) => restHasFeature(rid, key as FeatureKey),
  isPublic: (rid) => {
    const r = db.restaurants.find((x) => x.id === rid);
    return !!r && isPublic(r) && !r.is_permanently_closed;
  },
  notify: (user, type, title, body, link, o) => eng.notify(user, type, title, body, link, o ?? {}),
  notifyAdmins,
  enqueueEmail,
  logEvent: (rid, type) => logEvent(rid, type as AnalyticsEventType, 'server'),
  orderCompleted: (o) => eng.hooks.orderCompleted(o),
};
const market = createMarket(marketAccess);

// ─── Fase 9: logistica Rider (DEMO) ───
const logistics = createLogistics({
  get db() {
    return db as unknown as Parameters<typeof createLogistics>[0]['db'];
  },
  market,
  defaults: () => logisticsDefaults({ riderUser: DEMO_USERS.rider, candidateUser: DEMO_USERS.riderCandidate, cities: db.cities }),
  save,
  uid: () => currentUser() ?? null,
  isAdmin: () => isAdminUser(),
  notify: (user, type, title, body, link, o) => eng.notify(user, type, title, body, link, o ?? {}),
  notifyAdmins,
  logEvent: (rid, type) => db.analytics.push({ restaurant_id: rid, event_type: type as AnalyticsEventType, source: 'server', created_at: now() }),
});
marketAccess.logistics = logistics.hooks;

// ─── Fase 11: privacy, supporto, monitoraggio, launch checklist (DEMO) ───
const platform = createPlatform({
  get db() {
    return db as unknown as PlatformAccess['db'];
  },
  save,
  uid: () => currentUser() ?? null,
  isAdmin: () => isAdminUser(),
  notify: (user, type, title, body, link) => eng.notify(user, type, title, body, link, {}),
  ordersOf: (uid) => (db.market?.orders ?? []).filter((o) => o.user_id === uid) as unknown as Row[],
  orderAccess: (num, token) => {
    const o = market.internal.access(num, token);
    return o ? (o as unknown as Row) : null;
  },
  engagementExport: (uid) => {
    const e = db.engagement;
    if (!e) return {};
    return {
      loyalty: { account: e.loyalty_accounts.find((x) => x.user_id === uid) ?? null, transactions: e.loyalty_transactions.filter((x) => x.user_id === uid).map((x) => ({ type: x.type, points: x.points, description: x.description, at: x.created_at })) },
      referrals: { code: e.referral_codes.find((x) => x.user_id === uid)?.code ?? null, invited: e.referrals.filter((x) => x.referrer_user_id === uid).map((x) => ({ status: x.status, registered_at: x.registered_at })) },
      reviews: e.reviews.filter((x) => x.user_id === uid).map((x) => ({ restaurant_id: x.restaurant_id, rating: x.rating_overall, title: x.title, content: x.content, status: x.status, created_at: x.created_at })),
      notification_preferences: e.notification_preferences.find((x) => x.user_id === uid) ?? null,
      push_devices: e.push_subscriptions.filter((x) => x.user_id === uid && x.is_active).length,
    };
  },
  anonymizeOrders: (uid) => {
    for (const o of (db.market?.orders ?? []).filter((x) => x.user_id === uid)) {
      Object.assign(o, { customer_name: 'Cliente eliminato', customer_email: `eliminato+${o.id.slice(0, 8)}@invalid.local`, customer_phone: '000000', customer_notes: null, user_id: null, session_id: null });
    }
  },
});

// ─── Fase 12: go-to-market (Launch Control, CRM, Fondatori, QR, attribuzione) ───
const launch = createLaunchDemo({
  get db() {
    return db;
  },
  save,
  uid: () => currentUser() ?? null,
  isAdmin: () => isAdminUser(),
  canManage: (rid) => canManage(rid),
  demoVisible: () => demoVisible(),
  async grantPlan(rid, plan, expiresAt, note) {
    await demoSource.adminGrantPlan(rid, plan as PlanCode, expiresAt, 'promo', note);
    return db.subscriptions.filter((s) => s.restaurant_id === rid && s.source === 'promo' && !s.revoked_at).sort((x, y) => y.created_at.localeCompare(x.created_at))[0]?.id ?? null;
  },
  revokePlan: (id) => demoSource.adminRevokePlan(id),
  ensureReferralCode: (uid) => eng.ensureReferralCode(uid),
  orders: () => (db.market?.orders ?? []) as unknown as Row[],
  reviews: () => (db.engagement?.reviews ?? []) as unknown as Row[],
  referrals: () => (db.engagement?.referrals ?? []) as unknown as Row[],
  businessReferrals: () => (db.engagement?.business_referrals ?? []) as unknown as Row[],
  activityDays: () => db.engagement?.activity_days ?? [],
  pushUsers: () => (db.engagement?.push_subscriptions ?? []).filter((x) => x.is_active).map((x) => x.user_id),
  supportTickets: () => (db.platform?.tickets ?? []) as unknown as Row[],
  deliveryIssues: () => ((db.logistics as unknown as { issues?: Row[] } | undefined)?.issues ?? []),
  orderIssues: () => (db.market?.orders ?? []).flatMap((o) => o.issues as unknown as Row[]),
});

/** Solo DEMO: le "push" diventano notifiche locali del browser (nessun servizio esterno). */
export const setDemoPushHandler = (fn: ((title: string, body: string, url: string | null) => void) | null) => eng.setPushLocal(fn);

// ─── Fase 13: Business Intelligence & Growth Automation (DEMO: aggregati calcolati al volo) ───
const growth = createGrowthDemo({
  get db() {
    return db;
  },
  save,
  uid: () => currentUser() ?? null,
  isAdmin: () => isAdminUser(),
  canManage: (rid) => canManage(rid),
  demoVisible: () => demoVisible(),
  launch: () => (db.launch ??= launchDefaults()),
  launchOverview: (slug) => launch.overview(slug),
  completion: (r) => restaurantCompletion(db, r),
  orders: () => (db.market?.orders ?? []) as unknown as Row[],
  carts: () => (db.market?.carts ?? []) as unknown as Row[],
  reviews: () => (db.engagement?.reviews ?? []) as unknown as Row[],
  referrals: () => (db.engagement?.referrals ?? []) as unknown as Row[],
  loyaltyTx: () => (db.engagement?.loyalty_transactions ?? []) as unknown as Row[],
  loyaltyAccounts: () => (db.engagement?.loyalty_accounts ?? []) as unknown as Row[],
  rewardRedemptions: () => (db.engagement?.reward_redemptions ?? []) as unknown as Row[],
  activityDays: () => db.engagement?.activity_days ?? [],
  marketingOk: (uid) => {
    const p = db.engagement?.notification_preferences.find((x) => x.user_id === uid);
    return p ? !!p.marketing : !!getDemoProfile(uid)?.marketing_opt_in;
  },
  notify: (user, type, title, body, link) => eng.notify(user, type, title, body, link ?? '/', {}),
  supportTickets: () => (db.platform?.tickets ?? []) as unknown as Row[],
  aiUsage: () => (db.ai_usage ?? []) as unknown as Row[],
});
