// ─────────────────────────────────────────────────────────────
//  Assistente in modalità DEMO: stesso orchestratore del server
//  (shared/ai/engine), dati letti dal database locale di demo,
//  NESSUN modello linguistico (risposte deterministiche dai dati).
//  Gli strumenti replicano le funzioni SQL ai_search_* e le regole
//  deterministiche (aperto ora, prezzi, disponibilità reali).
// ─────────────────────────────────────────────────────────────
import { runAssistant, type SessionFilters } from '@shared/ai/engine';
import { localParts } from '@shared/ai/dates';
import { MAX_MESSAGE_LENGTH, sanitizeUserMessage } from '@shared/ai/parse';
import type {
  AiCatalog, AiCoupon, AiDataPort, AiMenuItem, AiOffer, AiRestaurant, AiRestaurantDetail, MenuQuery, OfferQuery, OpenStatus, RestaurantQuery,
} from '@shared/ai/types';
import { haversineKm } from '@/lib/geo';
import { AiError, type AiAdminStats, type AiChatInput, type AiChatReply, type AiPreferences } from '@/types/ai';
import type { Availability, Category, City, Coupon, Offer, Restaurant, RestaurantClosure, RestaurantDetail, RestaurantHour } from '@/types/domain';

/** Accesso in sola lettura al database DEMO (fornito da demoSource). */
export interface DemoAiAccess {
  details(): RestaurantDetail[];
  categories(): Category[];
  cities(): City[];
  closures(restaurantId: string): RestaurantClosure[];
  offers(): Offer[];
  coupons(): Coupon[];
  hasFeature(restaurantId: string, key: 'offers_enabled' | 'coupons_enabled' | 'reservations_enabled'): boolean;
  reservationsOnline(restaurantId: string): boolean;
  availability(restaurantId: string, date: string, party: number): Promise<Availability>;
  sponsored(placement: string, city?: string, category?: string): { campaign_id: string; restaurant_id: string }[];
  setting<T>(key: string, fallback: T): T;
  userId(): string | null;
  /** Fase 8: ristoranti con ordini online (facoltativo). */
  orderable?(): { restaurant_id: string; takeaway: boolean; delivery: boolean; order_now: boolean; payments_ready: boolean }[];
  isPremiumOwner(userId: string): boolean;
  favorites(userId: string): string[];
  preferences(userId: string): AiPreferences | null;
  usage: DemoUsageRow[];
  saveUsage(): void;
}

export interface DemoUsageRow {
  user_id: string | null;
  session: string;
  intent: string | null;
  status: 'ok' | 'fallback' | 'error' | 'rate_limited' | 'cached' | 'disabled';
  result_count: number;
  no_results: boolean;
  latency_ms: number;
  created_at: string;
  /** Fase 13: filtri strutturati (mai il testo libero) per domanda di ricerca / supply gap. */
  search_city?: string | null;
  search_category?: string | null;
  search_term?: string | null;
}

// ─── Regole deterministiche (specchio delle funzioni SQL) ───
const toMin = (t: string) => {
  const [h, m] = t.split(':').map(Number);
  return (h ?? 0) * 60 + (m ?? 0);
};
const openHours = (hours: RestaurantHour[]) => hours.filter((h) => !h.is_closed && h.opens_at && h.closes_at);

export function openStatusAt(r: Restaurant & { hours: RestaurantHour[] }, closures: RestaurantClosure[], at: Date): OpenStatus {
  if (r.is_permanently_closed || r.is_temporarily_closed) return 'closed';
  const p = localParts(at, r.timezone || 'Europe/Rome');
  if (closures.some((x) => x.date === p.date && (!x.start_time || (p.minutes >= toMin(x.start_time) && p.minutes < toMin(x.end_time ?? '24:00'))))) return 'closed';
  if (!r.hours.length) return 'unknown';
  const prev = p.isoDay === 1 ? 7 : p.isoDay - 1;
  for (const h of openHours(r.hours)) {
    const o = toMin(h.opens_at!);
    const c = toMin(h.closes_at!);
    if (h.day_of_week === p.isoDay && ((c > o && p.minutes >= o && p.minutes < c) || (c <= o && p.minutes >= o))) return 'open';
    if (c <= o && h.day_of_week === prev && p.minutes < c) return 'open';
  }
  return 'closed';
}

export function openInWindow(r: Restaurant & { hours: RestaurantHour[] }, closures: RestaurantClosure[], date: string, from: string, to: string): OpenStatus {
  if (r.is_permanently_closed || r.is_temporarily_closed) return 'closed';
  const f = toMin(from);
  let t = toMin(to);
  if (t <= f) t = 24 * 60;
  if (closures.some((x) => x.date === date && (!x.start_time || (toMin(x.start_time) <= f && toMin(x.end_time ?? '24:00') >= t)))) return 'closed';
  if (!r.hours.length) return 'unknown';
  const day = ((new Date(`${date}T12:00:00Z`).getUTCDay() + 6) % 7) + 1;
  const prev = day === 1 ? 7 : day - 1;
  for (const h of openHours(r.hours)) {
    const o = toMin(h.opens_at!);
    const c = toMin(h.closes_at!);
    if (h.day_of_week === day && o < t && (c <= o ? 24 * 60 : c) > f) return 'open';
    if (c <= o && h.day_of_week === prev && f < c) return 'open';
  }
  return 'closed';
}

/** Prezzo indicativo a persona: AYCE del pasto (weekend se previsto) o prezzo medio. Mai dalla fascia €€. */
export function pricePerPerson(r: Restaurant, meal: 'lunch' | 'dinner', date: string, basis: 'ayce' | 'auto'): number | null {
  let ayce: number | null = null;
  if (r.is_all_you_can_eat) {
    const d = ((new Date(`${date}T12:00:00Z`).getUTCDay() + 6) % 7) + 1;
    if ((d === 6 || d === 7) && r.ayce_weekend_price != null) ayce = r.ayce_weekend_price;
    else ayce = meal === 'lunch' ? r.ayce_lunch_price ?? r.ayce_dinner_price : r.ayce_dinner_price ?? r.ayce_lunch_price;
  }
  return basis === 'ayce' ? ayce : r.average_price ?? ayce;
}

const has = (hay: string | null | undefined, needle: string) => (hay ?? '').toLowerCase().includes(needle.toLowerCase());
const offerLiveAt = (o: Offer, at: number) => o.is_active && Date.parse(o.starts_at) <= at && (!o.ends_at || Date.parse(o.ends_at) > at);

export function createDemoPort(a: DemoAiAccess): AiDataPort {
  const all = a.details();
  const cats = a.categories();
  const catName = (slug: string) => cats.find((c) => c.slug === slug)?.name ?? slug;
  const menuItems = (r: RestaurantDetail) => r.menus.flatMap((m) => m.sections.flatMap((s) => s.items.filter((i) => i.is_available).map((i) => ({ ...i, section: s.name }))));
  const dist = (r: Restaurant, q: { lat?: number; lng?: number }) =>
    q.lat != null && q.lng != null && r.latitude != null && r.longitude != null ? haversineKm({ lat: q.lat, lng: q.lng }, { lat: r.latitude, lng: r.longitude }) : null;
  const liveOffers = (rid: string, at = Date.now()) => (a.hasFeature(rid, 'offers_enabled') ? a.offers().filter((o) => o.restaurant_id === rid && offerLiveAt(o, at)) : []);

  const card = (r: RestaurantDetail, extra: { distance: number | null; pp: number | null; open: OpenStatus }): AiRestaurant => {
    const offers = liveOffers(r.id).sort((x, y) => Number(y.is_featured) - Number(x.is_featured) || Date.parse(y.starts_at) - Date.parse(x.starts_at));
    return {
      id: r.id, slug: r.slug, name: r.name, city: r.city?.name ?? null, city_slug: r.city?.slug ?? null, categories: r.categories.map((c) => c.name),
      distance_km: extra.distance != null ? Math.round(extra.distance * 10) / 10 : null, price_per_person: extra.pp, average_price: r.average_price,
      price_range: r.price_range, is_all_you_can_eat: r.is_all_you_can_eat, ayce_lunch_price: r.ayce_lunch_price, ayce_dinner_price: r.ayce_dinner_price,
      ayce_weekend_price: r.ayce_weekend_price, services: r.services, has_delivery: r.has_delivery, has_takeaway: r.has_takeaway,
      reservations_online: a.reservationsOnline(r.id), open_status: extra.open, has_hours: r.hours.length > 0, cover_url: r.cover_url,
      latitude: r.latitude, longitude: r.longitude, phone: r.phone, is_demo: r.is_demo,
      offer: offers[0] ? { id: offers[0].id, title: offers[0].title } : null, offers_count: offers.length,
    };
  };

  const catalog: AiCatalog = {
    categories: cats.filter((c) => c.is_active).sort((x, y) => x.sort_order - y.sort_order).map((c) => ({ slug: c.slug, name: c.name })),
    cities: a
      .cities()
      .filter((c) => c.is_active)
      .map((c) => ({ c, n: all.filter((r) => r.city_id === c.id).length }))
      .sort((x, y) => y.n - x.n || x.c.name.localeCompare(y.c.name))
      .map(({ c }) => ({ slug: c.slug, name: c.name })),
  };

  return {
    orderable: a.orderable ? async () => a.orderable!() : undefined,
    catalog: async () => catalog,

    async searchRestaurants(q: RestaurantQuery) {
      const text = q.text?.trim().toLowerCase();
      const at = q.open_at ? new Date(q.open_at) : new Date();
      const priceDate = q.window_date ?? localParts(at).date;
      const ayce = !!q.ayce || !!q.categories?.includes('all-you-can-eat');
      const catsQ = (q.categories ?? []).filter((c) => c !== 'all-you-can-eat');
      const radius = Math.min(Math.max(q.radius_km ?? 10, 0.5), 100);
      const hasLoc = q.lat != null && q.lng != null;
      if (q.city && !a.cities().some((c) => c.slug === q.city)) return { items: [], total: 0, excluded_no_price: 0, unknown_hours: 0 };
      const itemsOf = (r: RestaurantDetail) => menuItems(r);
      let rows = all
        .filter((r) => !q.ids?.length || q.ids.includes(r.id))
        .filter((r) => !q.city || r.city?.slug === q.city)
        .filter((r) => !catsQ.length || r.categories.some((c) => catsQ.includes(c.slug)))
        .filter((r) => !ayce || r.is_all_you_can_eat)
        .filter((r) => !q.delivery || r.has_delivery)
        .filter((r) => !q.takeaway || r.has_takeaway)
        .filter((r) => !q.reservation || a.reservationsOnline(r.id))
        .filter((r) => !q.services?.length || q.services.every((s) => r.services.includes(s)))
        .filter((r) => !text || has(r.name, text) || has(r.short_description, text))
        .filter((r) => !q.vegetarian || r.services.includes('vegetariano') || itemsOf(r).some((i) => i.is_vegetarian || i.is_vegan))
        .filter((r) => !q.vegan || r.services.includes('vegano') || itemsOf(r).some((i) => i.is_vegan))
        .filter((r) => !q.gluten_free || r.services.includes('senza_glutine') || itemsOf(r).some((i) => i.is_gluten_free))
        .filter((r) => !q.spicy || itemsOf(r).some((i) => i.is_spicy))
        .filter((r) => !q.has_offers || liveOffers(r.id).length > 0)
        .map((r) => {
          const d = dist(r, q);
          const open =
            q.window_date && q.window_from && q.window_to
              ? openInWindow(r, a.closures(r.id), q.window_date, q.window_from, q.window_to)
              : openStatusAt(r, a.closures(r.id), at);
          return { r, d, open, pp: pricePerPerson(r, q.meal ?? 'dinner', priceDate, ayce ? 'ayce' : 'auto') };
        })
        .filter((x) => !hasLoc || (x.d != null && x.d <= radius));
      const priceFilter = q.max_price != null || q.min_price != null;
      const excludedNoPrice = priceFilter ? rows.filter((x) => x.pp == null).length : 0;
      const unknownHours = q.open_required ? rows.filter((x) => x.open === 'unknown').length : 0;
      rows = rows
        .filter((x) => !priceFilter || x.pp != null)
        .filter((x) => (q.max_price == null || x.pp! <= q.max_price) && (q.min_price == null || x.pp! >= q.min_price))
        .filter((x) => !q.open_required || x.open === 'open');
      const byNum = (u: number | null, v: number | null) => (u == null ? (v == null ? 0 : 1) : v == null ? -1 : u - v);
      rows.sort((x, y) =>
        (q.sort === 'distance' ? byNum(x.d, y.d) : 0) ||
        (q.sort === 'price' ? byNum(x.pp, y.pp) : 0) ||
        Number(!!text && has(y.r.name, text)) - Number(!!text && has(x.r.name, text)) ||
        (q.open_at || q.window_date ? Number(y.open === 'open') - Number(x.open === 'open') : 0) ||
        (hasLoc ? byNum(x.d, y.d) : 0) ||
        Number(['verified', 'claimed'].includes(y.r.data_status)) - Number(['verified', 'claimed'].includes(x.r.data_status)) ||
        y.r.popularity_score - x.r.popularity_score ||
        x.r.name.localeCompare(y.r.name),
      );
      const limit = Math.min(Math.max(q.limit ?? 5, 1), 20);
      return { items: rows.slice(0, limit).map((x) => card(x.r, { distance: x.d, pp: x.pp, open: x.open })), total: rows.length, excluded_no_price: excludedNoPrice, unknown_hours: unknownHours };
    },

    async searchMenu(q: MenuQuery) {
      const terms = (q.terms ?? []).map((t) => t.toLowerCase()).filter(Boolean);
      const radius = Math.min(Math.max(q.radius_km ?? 10, 0.5), 100);
      if (q.city && !a.cities().some((c) => c.slug === q.city)) return [];
      const out: (AiMenuItem & { _d: number | null })[] = [];
      for (const r of all) {
        if (q.restaurant_id && r.id !== q.restaurant_id) continue;
        if (q.city && r.city?.slug !== q.city) continue;
        if (q.categories?.length && !r.categories.some((c) => q.categories!.includes(c.slug))) continue;
        const d = dist(r, q);
        if (q.lat != null && (d == null || d > radius)) continue;
        for (const i of menuItems(r)) {
          const hay = [i.name, i.description ?? '', ...(i.ingredients ?? []), ...(i.tags ?? [])];
          const hit = (t: string) => hay.some((h) => has(h, t));
          if (terms.length && !(q.match === 'any' ? terms.some(hit) : terms.every(hit))) continue;
          if (q.vegetarian && !(i.is_vegetarian || i.is_vegan)) continue;
          if (q.vegan && !i.is_vegan) continue;
          if (q.gluten_free && !i.is_gluten_free) continue;
          if (q.spicy && !i.is_spicy) continue;
          if (q.max_price != null && (i.discount_price ?? i.price) != null && (i.discount_price ?? i.price)! > q.max_price) continue;
          out.push({
            id: i.id, name: i.name, description: i.description?.slice(0, 140) ?? null, price: i.price, discount_price: i.discount_price, allergens: i.allergens,
            is_vegetarian: i.is_vegetarian, is_vegan: i.is_vegan, is_gluten_free: i.is_gluten_free, is_spicy: i.is_spicy, menu_category: i.section,
            restaurant: { id: r.id, slug: r.slug, name: r.name, city: r.city?.name ?? null, distance_km: d != null ? Math.round(d * 10) / 10 : null }, _d: d,
          });
        }
      }
      out.sort((x, y) => (x._d ?? 1e9) - (y._d ?? 1e9) || ((x.discount_price ?? x.price ?? 1e9) - (y.discount_price ?? y.price ?? 1e9)) || x.name.localeCompare(y.name));
      return out.slice(0, Math.min(Math.max(q.limit ?? 6, 1), 20)).map(({ _d, ...m }) => m);
    },

    async searchOffers(q: OfferQuery) {
      const date = q.date ?? localParts(new Date()).date;
      const day = ((new Date(`${date}T12:00:00Z`).getUTCDay() + 6) % 7) + 1;
      const dayStart = Date.parse(`${date}T00:00:00`);
      const radius = Math.min(Math.max(q.radius_km ?? 10, 0.5), 100);
      const limit = Math.min(Math.max(q.limit ?? 6, 1), 20);
      if (q.city && !a.cities().some((c) => c.slug === q.city)) return { offers: [], coupons: [], date };
      const okRest = (r: RestaurantDetail) =>
        (!q.restaurant_id || r.id === q.restaurant_id) &&
        (!q.city || r.city?.slug === q.city) &&
        (!q.categories?.length || r.categories.some((c) => q.categories!.includes(c.slug))) &&
        (q.lat == null || ((dist(r, q) ?? 1e9) <= radius));
      const byId = new Map(all.map((r) => [r.id, r]));
      const offers: AiOffer[] = a
        .offers()
        .filter((o) => o.is_active && a.hasFeature(o.restaurant_id, 'offers_enabled'))
        .filter((o) => Date.parse(o.starts_at) < dayStart + 86_400_000 && (!o.ends_at || Date.parse(o.ends_at) > dayStart))
        .filter((o) => !o.days_of_week.length || o.days_of_week.includes(day))
        .flatMap((o) => {
          const r = byId.get(o.restaurant_id);
          if (!r || !okRest(r)) return [];
          const d = dist(r, q);
          return [{
            id: o.id, title: o.title, description: o.description?.slice(0, 160) ?? null, offer_type: o.offer_type, discount_type: o.discount_type,
            discount_value: o.discount_value, minimum_spend: o.minimum_spend, days_of_week: o.days_of_week, start_time: o.start_time?.slice(0, 5) ?? null,
            end_time: o.end_time?.slice(0, 5) ?? null, ends_at: o.ends_at, terms: o.terms?.slice(0, 160) ?? null,
            restaurant: { id: r.id, slug: r.slug, name: r.name, city: r.city?.name ?? null, distance_km: d != null ? Math.round(d * 10) / 10 : null },
          }];
        })
        .sort((x, y) => (x.restaurant.distance_km ?? 1e9) - (y.restaurant.distance_km ?? 1e9))
        .slice(0, limit);
      const nowMs = Date.now();
      const coupons: AiCoupon[] = a
        .coupons()
        .filter((c) => c.is_active && Date.parse(c.valid_from) <= nowMs && (!c.valid_until || Date.parse(c.valid_until) > nowMs))
        .filter((c) => c.max_redemptions == null || c.claims_count < c.max_redemptions)
        .filter((c) => a.hasFeature(c.restaurant_id, 'coupons_enabled'))
        .flatMap((c) => {
          const r = byId.get(c.restaurant_id);
          if (!r || !okRest(r)) return [];
          return [{ id: c.id, title: c.title, discount_type: c.discount_type, discount_value: c.discount_value, minimum_spend: c.minimum_spend, valid_until: c.valid_until, restaurant: { id: r.id, slug: r.slug, name: r.name, city: r.city?.name ?? null } }];
        })
        .slice(0, limit);
      return { offers, coupons, date };
    },

    async restaurantDetail(ref: string) {
      const r = all.find((x) => x.id === ref || x.slug === ref);
      if (!r) return null;
      const items = menuItems(r);
      const today = localParts(new Date()).date;
      const in14 = new Date(Date.now() + 14 * 86_400_000).toISOString().slice(0, 10);
      const d: AiRestaurantDetail = {
        id: r.id, slug: r.slug, name: r.name, city: r.city?.name ?? null, short_description: r.short_description?.slice(0, 200) ?? null,
        description: r.description?.slice(0, 400) ?? null, address: r.address, phone: r.phone, average_price: r.average_price, price_range: r.price_range,
        is_all_you_can_eat: r.is_all_you_can_eat, ayce_lunch_price: r.ayce_lunch_price, ayce_dinner_price: r.ayce_dinner_price,
        ayce_weekend_price: r.ayce_weekend_price, services: r.services, has_delivery: r.has_delivery, has_takeaway: r.has_takeaway,
        is_temporarily_closed: r.is_temporarily_closed, cover_url: r.cover_url, latitude: r.latitude, longitude: r.longitude,
        categories: r.categories.map((c) => catName(c.slug)), open_status: openStatusAt(r, a.closures(r.id), new Date()),
        hours: [...r.hours].sort((x, y) => x.day_of_week - y.day_of_week || (x.opens_at ?? '').localeCompare(y.opens_at ?? '')).map((h) => ({
          day: h.day_of_week, opens: h.opens_at?.slice(0, 5) ?? null, closes: h.closes_at?.slice(0, 5) ?? null, is_closed: h.is_closed, label: h.label ?? null,
        })),
        closures: a.closures(r.id).filter((x) => x.date >= today && x.date <= in14).map((x) => ({ date: x.date, from: x.start_time, to: x.end_time })),
        menu_summary: {
          items: items.length, vegetarian: items.filter((i) => i.is_vegetarian || i.is_vegan).length, vegan: items.filter((i) => i.is_vegan).length,
          gluten_free: items.filter((i) => i.is_gluten_free).length, spicy: items.filter((i) => i.is_spicy).length,
        },
        reservations_online: a.reservationsOnline(r.id),
        has_offers: liveOffers(r.id).length > 0,
      };
      return d;
    },

    availability: (id, date, party) => a.availability(id, date, party),

    async sponsoredIds(placement, ctx) {
      return a.sponsored(placement, ctx.city, ctx.category);
    },
  };
}

// ─── Sessioni in memoria (temporanee), limiti e utilizzo ───
const sessions = new Map<string, { user: string | null; filters: SessionFilters | null; history: { role: 'user' | 'assistant'; content: string }[]; restaurant: string | null }>();

export async function demoAiChat(input: AiChatInput, a: DemoAiAccess): Promise<AiChatReply> {
  const started = Date.now();
  const user = a.userId();
  const log = (row: Omit<DemoUsageRow, 'user_id' | 'session' | 'created_at' | 'latency_ms'>) => {
    a.usage.push({ ...row, user_id: user, session: input.session_id, latency_ms: Date.now() - started, created_at: new Date().toISOString() });
    if (a.usage.length > 2000) a.usage.splice(0, a.usage.length - 2000);
    a.saveUsage();
  };
  if (!/^[A-Za-z0-9_-]{16,64}$/.test(input.session_id)) throw new AiError('BAD_SESSION', 'Richiesta non valida.', 400);
  if (a.setting<unknown>('ai_enabled', true) === false) {
    log({ intent: null, status: 'disabled', result_count: 0, no_results: false });
    throw new AiError('AI_DISABLED', 'L’assistente AI è momentaneamente disattivato. Puoi continuare a usare la ricerca.', 503);
  }
  if ((input.message ?? '').length > 2000) throw new AiError('TOO_LONG', `Il messaggio è troppo lungo: scrivi al massimo ${MAX_MESSAGE_LENGTH} caratteri.`, 413);
  const message = sanitizeUserMessage(input.message);
  if (message.length < 2) throw new AiError('EMPTY', 'Scrivi cosa hai voglia di mangiare.', 400);

  const s = sessions.get(input.session_id);
  if (s && s.user && s.user !== user) throw new AiError('FORBIDDEN', 'Questa conversazione non è disponibile.', 403);
  const session = s ?? { user, filters: null, history: [], restaurant: input.restaurant_id ?? null };
  if (!s) sessions.set(input.session_id, session);
  if (!session.user && user) session.user = user;
  if ((input.restaurant_id ?? null) !== session.restaurant) {
    session.restaurant = input.restaurant_id ?? null;
    session.filters = null;
  }

  const hour = Date.now() - 3_600_000;
  const limit = user
    ? a.isPremiumOwner(user) ? a.setting('ai_premium_limit_per_hour', 60) : a.setting('ai_user_limit_per_hour', 30)
    : a.setting('ai_guest_limit_per_hour', 10);
  const used = a.usage.filter((u) => u.status !== 'rate_limited' && Date.parse(u.created_at) > hour && (user ? u.user_id === user : !u.user_id && u.session === input.session_id)).length;
  if (used >= Number(limit)) {
    log({ intent: null, status: 'rate_limited', result_count: 0, no_results: false });
    throw new AiError('RATE_LIMITED', 'Hai raggiunto il limite di richieste all’assistente per quest’ora. Nel frattempo puoi usare la ricerca e la mappa.', 429);
  }

  try {
    const loc = input.location && Number.isFinite(input.location.lat) && Number.isFinite(input.location.lng)
      ? { lat: Math.round(input.location.lat * 1000) / 1000, lng: Math.round(input.location.lng * 1000) / 1000 }
      : null;
    const favIds = user ? a.favorites(user) : [];
    const details = a.details();
    const favCats = favIds.length
      ? Object.entries(
          details.filter((r) => favIds.includes(r.id)).flatMap((r) => r.categories.map((c) => c.slug)).filter((c) => c !== 'all-you-can-eat')
            .reduce<Record<string, number>>((acc, c) => ((acc[c] = (acc[c] ?? 0) + 1), acc), {}),
        ).sort((x, y) => y[1] - x[1]).slice(0, 3).map(([c]) => c)
      : [];
    const result = await runAssistant(message, {
      prev_filters: session.filters ?? undefined,
      history: session.history.slice(-6),
      restaurant_id: session.restaurant,
      location: loc,
      location_denied: !!input.location_denied,
      user: user ? { preferences: a.preferences(user), favorite_ids: favIds, favorite_categories: favCats } : null,
    }, {
      data: createDemoPort(a),
      llm: null,
      settings: { maxRestaurants: Number(a.setting('ai_max_restaurants', 5)), maxTokens: 600, temperature: 0.2 },
    });
    const r = result.response;
    session.filters = result.session_filters;
    // Conservazione 0 = non si conservano i messaggi (solo il contesto dei filtri, senza coordinate)
    if (Number(a.setting('ai_chat_retention_days', 7)) > 0) {
      session.history.push({ role: 'user', content: message }, { role: 'assistant', content: r.message });
      session.history = session.history.slice(-20);
    }
    const noResults = !r.restaurants.length && !r.offers.length && !r.coupons.length && !r.comparison && !r.needs_location && r.intent !== 'general_food_question';
    log({ intent: r.intent, status: 'ok', result_count: r.restaurants.length, no_results: noResults,
      search_city: r.filters?.city ?? null, search_category: r.filters?.categories?.[0] ?? null, search_term: r.filters?.dish_terms?.[0] ?? null });
    const remaining = Math.max(Number(limit) - used - 1, 0);
    return { response: { ...r, meta: { ...r.meta, provider: 'demo' } }, remaining };
  } catch (e) {
    log({ intent: null, status: 'error', result_count: 0, no_results: false });
    throw e instanceof AiError ? e : new AiError('AI_ERROR', 'L’assistente non è disponibile in questo momento. Puoi continuare a usare la ricerca.', 500);
  }
}

export function demoAiHistory(sessionId: string, a: DemoAiAccess) {
  const s = sessions.get(sessionId);
  if (!s) return [];
  if (s.user && s.user !== a.userId()) throw new AiError('FORBIDDEN', 'Questa conversazione non è disponibile.', 403);
  return s.history.slice(-6);
}

export function demoAiDelete(sessionId: string, a: DemoAiAccess) {
  const s = sessions.get(sessionId);
  if (s?.user && s.user !== a.userId()) throw new AiError('FORBIDDEN', 'Questa conversazione non è disponibile.', 403);
  sessions.delete(sessionId);
}

/** Statistiche Admin in DEMO: stesse metriche del server, calcolate dall'utilizzo locale (nessun costo: nessun modello). */
export function demoAiStats(a: DemoAiAccess, days: number, conv: AiAdminStats['conversions']): AiAdminStats {
  const since = Date.now() - days * 86_400_000;
  const rows = a.usage.filter((u) => Date.parse(u.created_at) >= since);
  const today = localParts(new Date()).date;
  const month = today.slice(0, 7);
  const dayOf = (iso: string) => localParts(new Date(iso)).date;
  const nonRl = rows.filter((u) => u.status !== 'rate_limited');
  const pct = (n: number, d: number) => (d ? Math.round((n * 1000) / d) / 10 : 0);
  const intents = Object.entries(nonRl.reduce<Record<string, number>>((acc, u) => ((acc[u.intent ?? 'unknown'] = (acc[u.intent ?? 'unknown'] ?? 0) + 1), acc), {}))
    .sort((x, y) => y[1] - x[1]).slice(0, 8).map(([intent, count]) => ({ intent, count }));
  const daily = Array.from({ length: Math.min(days, 60) }, (_, k) => {
    const d = new Date(Date.now() - (Math.min(days, 60) - 1 - k) * 86_400_000);
    const day = localParts(d).date;
    const inDay = a.usage.filter((u) => dayOf(u.created_at) === day);
    return { day, requests: inDay.length, errors: inDay.filter((u) => u.status === 'error').length };
  });
  const served = rows.filter((u) => ['ok', 'fallback', 'cached'].includes(u.status));
  return {
    requests_today: a.usage.filter((u) => dayOf(u.created_at) === today).length,
    requests_month: a.usage.filter((u) => dayOf(u.created_at).startsWith(month)).length,
    requests_period: rows.length,
    input_tokens: 0,
    output_tokens: 0,
    estimated_cost: 0,
    error_rate: pct(nonRl.filter((u) => u.status === 'error').length, nonRl.length),
    fallback_rate: pct(rows.filter((u) => u.status === 'fallback').length, rows.filter((u) => !['rate_limited', 'disabled'].includes(u.status)).length),
    no_results_rate: pct(served.filter((u) => u.no_results).length, served.length),
    rate_limited: rows.filter((u) => u.status === 'rate_limited').length,
    cache_hits: rows.filter((u) => u.status === 'cached').length,
    avg_latency_ms: nonRl.length ? Math.round(nonRl.reduce((s, u) => s + u.latency_ms, 0) / nonRl.length) : 0,
    intents,
    daily,
    conversions: conv,
    active_sessions: sessions.size,
  };
}

