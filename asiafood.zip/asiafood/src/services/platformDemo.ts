// ─────────────────────────────────────────────────────────────
//  Fase 11 in modalità DEMO: stesse regole della migrazione 0022
//  (consensi, export, cancellazione con periodo di sicurezza, ticket, flag,
//  stato di sistema, launch checklist, readiness Taranto) su dati locali.
//  Nessun cron gira nel browser: i controlli "di sistema" restano "in attesa".
// ─────────────────────────────────────────────────────────────
import type {
  AdminSupportTicket, AuditRow, CheckStatus, CityReadiness, ClientErrorReport, ConsentChoices, ConsentState, ConsentType, ConsistencyReport,
  DeletionRequest, FlagState, LaunchCheck, LaunchChecklist, LegalDocumentType, PrivacyRequests, PrivacyStatus, RuntimeConfig, SupportFilter,
  SupportTicket, SupportTicketInput, SystemStatus, WebVitalReport,
} from '@/types/platform';

type Row = Record<string, unknown>;

export interface PlatformState {
  consents: { id: string; user_id: string | null; anonymous_id: string | null; consent_type: ConsentType; granted: boolean; policy_version: string; source: string; created_at: string }[];
  exports: { id: string; user_id: string; status: string; requested_at: string; completed_at: string | null; expires_at: string | null; size_bytes: number }[];
  deletions: (DeletionRequest & { user_id: string | null })[];
  tickets: (AdminSupportTicket & { order_id: string | null })[];
  errors: { id: number; source: string; code: string | null; message: string; route: string | null; request_id: string | null; created_at: string }[];
  vitals: { metric: string; value: number; created_at: string }[];
  audit: (AuditRow & { kind: 'admin' | 'security' })[];
  launch_checks: Record<string, { status: CheckStatus; notes: string | null; last_checked_at: string; checked_by: string | null }>;
  slug_history: { restaurant_id: string; old_slug: string; created_at: string }[];
  invites: { id: string; email: string | null; token: string; role: string; expires_at: string; used_at: string | null }[];
  legal: { document_type: LegalDocumentType; version: string; url: string; effective_at: string; is_current: boolean; is_draft: boolean }[];
  rate: Record<string, number[]>;
}

export interface PlatformAccess {
  db: {
    settings: Record<string, unknown>;
    profiles: { id: string; full_name?: string | null; display_name?: string | null; email?: string | null; phone?: string | null; role: string; is_blocked?: boolean; created_at?: string; marketing_opt_in?: boolean }[];
    restaurants: { id: string; name: string; slug: string; is_active: boolean; is_demo?: boolean; is_permanently_closed?: boolean; latitude: number | null; longitude: number | null; city_id: string; province_id?: string | null;
      phone?: string | null; website?: string | null; whatsapp?: string | null; email?: string | null; owner_id?: string | null; source_name?: string | null; data_status?: string; is_verified?: boolean }[];
    provinces: { id: string; code: string }[];
    restaurant_categories: { restaurant_id: string; category_id: string }[];
    restaurant_hours: { restaurant_id: string }[];
    restaurant_sources: { restaurant_id: string }[];
    restaurant_members: { restaurant_id: string; user_id: string; role: string; status: string }[];
    menus: { restaurant_id: string; is_active: boolean }[];
    subscription_plans: { code: string; is_active: boolean; monthly_price: number; stripe_monthly_price_id?: string | null }[];
    favorites: { user_id: string; restaurant_id: string; created_at: string }[];
    reservations: Row[];
    coupon_claims: Row[];
    analytics: { created_at: string; event_type: string }[];
    stripe_events: { processing_status?: string; status?: string; created_at?: string; event_type?: string; id?: string; error_message?: string | null }[];
    email_outbox: { status: string; created_at: string }[];
    ai_usage?: { status?: string; created_at: string }[];
    platform?: PlatformState;
  };
  save(): void;
  uid(): string | null;
  isAdmin(): boolean;
  notify(user: string, type: string, title: string, body: string, link: string | null): void;
  /** Ordini del cliente (dal motore ordini demo). */
  ordersOf(uid: string): Row[];
  /** Ordine accessibile (numero + token o proprietario). */
  orderAccess(num: string, token: string | null): Row | null;
  /** Dati aggiuntivi dei moduli engagement (loyalty, referral, preferenze). */
  engagementExport(uid: string): Row;
  /** Anonimizzazione nei moduli che conservano dati (ordini). */
  anonymizeOrders(uid: string): void;
}

const now = () => new Date().toISOString();
const uuid = () => crypto.randomUUID();
const DAY = 86_400_000;
const code6 = () => Array.from(crypto.getRandomValues(new Uint8Array(6)), (b) => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 32]).join('');

export const PLATFORM_SETTING_DEFAULTS: Record<string, unknown> = {
  maintenance_mode: false, maintenance_message: null, beta_mode: true, beta_invite_only: false, reviews_enabled: true, campaigns_enabled: true,
  crm_agents_enabled: false, rider_signup_enabled: true, orders_enabled: true, ai_enabled: true, logistics_enabled: true, logistics_auto_dispatch_enabled: true,
  push_enabled: true, loyalty_enabled: true, referral_enabled: true, consent_policy_version: '2026-10-01', account_deletion_grace_days: 7,
  upload_max_image_mb: 5, upload_max_document_mb: 10, legal_company_name: null, legal_vat_number: null, legal_address: null, legal_email: null,
  legal_pec: null, support_email: null, seo_min_restaurants_category_city: 2,
  // Fase 12 (pubbliche)
  launch_phase: 'private_beta', founding_program_name: 'Partner Fondatore AsiaFood Taranto', founding_badge_enabled: true, ambassador_program_enabled: false, nps_enabled: false,
};
const PUBLIC_KEYS = new Set([...Object.keys(PLATFORM_SETTING_DEFAULTS), 'show_demo_data', 'billing_trial_days', 'loyalty_program_name', 'service_fee_enabled', 'service_fee_amount']);

const FLAGS: Omit<FlagState, 'value'>[] = [
  { flag: 'ai', key: 'ai_enabled', kind: 'feature', label: 'Assistente AI (chiamate al modello)' },
  { flag: 'orders', key: 'orders_enabled', kind: 'kill_switch', label: 'Nuovi ordini online' },
  { flag: 'delivery', key: 'logistics_enabled', kind: 'feature', label: 'Consegne con Rider AsiaFood' },
  { flag: 'rider_dispatch', key: 'logistics_auto_dispatch_enabled', kind: 'kill_switch', label: 'Dispatch automatico Rider' },
  { flag: 'riders', key: 'rider_signup_enabled', kind: 'feature', label: 'Candidature Rider' },
  { flag: 'crm_agents', key: 'crm_agents_enabled', kind: 'kill_switch', label: 'CRM / Sales Agent (modulo non presente)' },
  { flag: 'push', key: 'push_enabled', kind: 'feature', label: 'Notifiche push' },
  { flag: 'push_campaigns', key: 'campaigns_enabled', kind: 'kill_switch', label: 'Campagne push/in-app programmate' },
  { flag: 'reviews', key: 'reviews_enabled', kind: 'feature', label: 'Nuove recensioni' },
  { flag: 'loyalty', key: 'loyalty_enabled', kind: 'feature', label: 'AsiaPoints (loyalty)' },
  { flag: 'referral', key: 'referral_enabled', kind: 'feature', label: 'Invita un amico' },
  { flag: 'maintenance', key: 'maintenance_mode', kind: 'maintenance', label: 'Modalità manutenzione' },
  { flag: 'beta', key: 'beta_mode', kind: 'feature', label: 'Badge Beta' },
  { flag: 'beta_invite_only', key: 'beta_invite_only', kind: 'feature', label: 'Beta solo su invito' },
];

function initialState(): PlatformState {
  const t = '2026-10-01T00:00:00.000Z';
  return {
    consents: [], exports: [], deletions: [], tickets: [], errors: [], vitals: [], audit: [], launch_checks: {}, slug_history: [], invites: [], rate: {},
    legal: (['privacy', 'cookie', 'terms', 'business_terms', 'rider_privacy', 'rider_terms'] as LegalDocumentType[]).map((d) => ({
      document_type: d, version: '2026-10-01-bozza', url: `/${d.replace('_', '-').replace('cookie', 'cookie-policy')}`, effective_at: t, is_current: true, is_draft: true,
    })),
  };
}

const scrub = (s: string) => s
  .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '[email]')
  .replace(/(token|key|secret|signature|t)=([^&\s]+)/gi, '$1=[redacted]')
  .replace(/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+/g, '[jwt]')
  .replace(/\+?\d[\d .-]{7,}\d/g, '[number]')
  .slice(0, 400);

export function createPlatform(a: PlatformAccess) {
  const st = (): PlatformState => {
    a.db.platform ??= initialState();
    return a.db.platform;
  };
  const setting = (k: string) => (k in a.db.settings ? a.db.settings[k] : PLATFORM_SETTING_DEFAULTS[k]);
  const fail = (msg: string): never => {
    throw new Error(msg);
  };
  const requireUser = () => a.uid() ?? fail('Accedi per continuare.');
  const requireAdmin = () => {
    if (!a.isAdmin()) fail('Operazione non consentita.');
  };
  const profile = (id: string | null) => a.db.profiles.find((p) => p.id === id);
  /** Stesso comportamento di rate_limit_assert (finestra mobile in memoria). */
  const limit = (bucket: string, max: number, windowMs: number) => {
    const key = `${bucket}:${a.uid() ?? 'anon'}`;
    const list = (st().rate[key] ?? []).filter((t) => Date.now() - t < windowMs);
    if (list.length >= max) throw new Error('Troppe richieste in poco tempo. Riprova tra qualche minuto.');
    list.push(Date.now());
    st().rate[key] = list;
  };
  const audit = (kind: 'admin' | 'security', action: string, entity: string, id: string | null, metadata: Row = {}) => {
    const p = profile(a.uid());
    st().audit.unshift({ kind, id: Date.now() + Math.random(), action, entity_type: entity, entity_id: id, actor: p?.display_name ?? p?.full_name ?? (a.uid() ? a.uid()!.slice(0, 8) : 'sistema'),
      actor_role: p?.role ?? 'service', metadata, ua: null, created_at: now() });
    st().audit.splice(500);
  };
  const consentState = (uid: string | null, anon: string | null): ConsentState => {
    const rows = st().consents.filter((c) => (uid ? c.user_id === uid : anon && c.anonymous_id === anon));
    const choices: ConsentState['choices'] = {};
    for (const c of [...rows].sort((x, y) => x.created_at.localeCompare(y.created_at))) choices[c.consent_type] = { granted: c.granted, policy_version: c.policy_version, at: c.created_at };
    return { policy_version: String(setting('consent_policy_version')), choices };
  };

  function runtimeConfig(): RuntimeConfig {
    const settings: RuntimeConfig['settings'] = {};
    for (const k of PUBLIC_KEYS) settings[k] = setting(k) ?? null;
    const legal: RuntimeConfig['legal'] = {};
    for (const l of st().legal.filter((x) => x.is_current)) legal[l.document_type] = { version: l.version, url: l.url, effective_at: l.effective_at, draft: l.is_draft };
    return { settings, legal, server_time: now() };
  }

  /** Esecuzione "pigra" delle cancellazioni scadute (in produzione: cron di sistema). */
  function processDeletions() {
    for (const d of st().deletions.filter((x) => x.status === 'scheduled' && Date.parse(x.scheduled_for) <= Date.now() && x.user_id)) {
      const uid = d.user_id!;
      const owns = a.db.restaurant_members.some((m) => m.user_id === uid && m.status === 'active' && ['owner', 'manager'].includes(m.role))
        || a.db.restaurants.some((r) => r.owner_id === uid && r.is_active);
      if (owns) {
        Object.assign(d, { status: 'blocked', blocked_reason: 'owns_restaurant' });
        continue;
      }
      a.anonymizeOrders(uid);
      for (const r of a.db.reservations.filter((x) => x.user_id === uid)) Object.assign(r, { guest_name: 'Cliente', guest_surname: 'eliminato', guest_email: null, guest_phone: '000000', notes: null, user_id: null });
      a.db.favorites = a.db.favorites.filter((f) => f.user_id !== uid);
      for (const c of st().consents.filter((x) => x.user_id === uid)) Object.assign(c, { user_id: null, anonymous_id: c.anonymous_id ?? `deleted-${uid.slice(0, 8)}` });
      const p = profile(uid);
      if (p) Object.assign(p, { full_name: 'Utente eliminato', display_name: null, email: null, phone: null, is_blocked: true, marketing_opt_in: false });
      Object.assign(d, { status: 'anonymized' });
      audit('security', 'account_anonymized', 'profile', uid);
    }
  }

  function exportData(uid: string) {
    const p = profile(uid);
    const rest = (id: unknown) => a.db.restaurants.find((r) => r.id === id)?.name ?? null;
    return {
      generated_at: now(), format_version: 1, modalita: 'DEMO (dati locali di questo browser)',
      profile: p ? { id: p.id, full_name: p.full_name, display_name: p.display_name, email: p.email, phone: p.phone, role: p.role, created_at: p.created_at } : null,
      favorites: a.db.favorites.filter((f) => f.user_id === uid).map((f) => ({ restaurant: rest(f.restaurant_id), since: f.created_at })),
      reservations: a.db.reservations.filter((r) => r.user_id === uid).map((r) => ({ restaurant: rest(r.restaurant_id), date: r.reservation_date, time: r.reservation_time, party_size: r.party_size, status: r.status,
        name: `${r.guest_name} ${r.guest_surname}`, phone: r.guest_phone, email: r.guest_email, notes: r.notes })),
      orders: a.ordersOf(uid).map((o) => ({ order_number: o.order_number, restaurant: rest(o.restaurant_id), type: o.order_type, status: o.status, total: o.total, currency: 'EUR', created_at: o.created_at,
        customer: { name: o.customer_name, email: o.customer_email, phone: o.customer_phone }, delivery_address: o.delivery_address_snapshot ?? null,
        items: ((o.items as Row[] | undefined) ?? []).map((i) => ({ name: i.name ?? i.menu_item_name_snapshot, quantity: i.quantity, line_total: i.line_total })) })),
      coupons: a.db.coupon_claims.filter((c) => c.user_id === uid).map((c) => ({ restaurant: rest(c.restaurant_id), status: c.status, claimed_at: c.claimed_at })),
      consents: st().consents.filter((c) => c.user_id === uid).map((c) => ({ type: c.consent_type, granted: c.granted, policy_version: c.policy_version, source: c.source, at: c.created_at })),
      support_tickets: st().tickets.filter((t) => t.user_id === uid).map((t) => ({ reference: t.reference, category: t.category, subject: t.subject, status: t.status, created_at: t.created_at })),
      restaurant_roles: a.db.restaurant_members.filter((m) => m.user_id === uid).map((m) => ({ restaurant: rest(m.restaurant_id), role: m.role, status: m.status })),
      ...a.engagementExport(uid),
    };
  }

  function cityReadiness(code = 'TA'): CityReadiness {
    const prov = a.db.provinces.find((p) => p.code === code);
    const rr = a.db.restaurants.filter((r) => r.province_id === prov?.id && r.is_active && !r.is_demo && !r.is_permanently_closed);
    const n = rr.length;
    const pct = (k: number) => (n ? Math.round((k * 100) / n) : 0);
    const has = (list: { restaurant_id: string }[], r: { id: string }) => list.some((x) => x.restaurant_id === r.id);
    const min = Number(setting('seo_min_restaurants_category_city') ?? 2);
    const combos = new Map<string, number>();
    for (const r of rr) for (const c of a.db.restaurant_categories.filter((x) => x.restaurant_id === r.id)) combos.set(`${c.category_id}|${r.city_id}`, (combos.get(`${c.category_id}|${r.city_id}`) ?? 0) + 1);
    const seo = [...combos.values()].filter((v) => v >= min).length;
    const cities = new Set(rr.map((r) => r.city_id)).size;
    const ratio = (v: number, pass: number, warn: number): CheckStatus => (n === 0 ? 'fail' : v >= pass ? 'pass' : v >= warn ? 'warn' : 'fail');
    const legalOk = st().legal.filter((l) => l.is_current && !l.is_draft && ['privacy', 'cookie', 'terms'].includes(l.document_type)).length === 3;
    const lc = st().launch_checks;
    const checks: CityReadiness['checks'] = [
      { key: 'database', label: 'Database popolato (locali reali attivi)', critical: true, value: n, status: n >= 20 ? 'pass' : n >= 5 ? 'warn' : 'fail', target: '≥ 20 locali reali' },
      { key: 'coordinates', label: 'Coordinate (copertura mappa)', critical: true, value: pct(rr.filter((r) => r.latitude != null && r.longitude != null).length), status: ratio(pct(rr.filter((r) => r.latitude != null).length), 95, 80), target: '≥ 95%' },
      { key: 'hours', label: 'Orari di apertura', critical: false, value: pct(rr.filter((r) => has(a.db.restaurant_hours, r)).length), status: ratio(pct(rr.filter((r) => has(a.db.restaurant_hours, r)).length), 80, 50), target: '≥ 80%' },
      { key: 'categories', label: 'Categorie assegnate', critical: true, value: pct(rr.filter((r) => has(a.db.restaurant_categories, r)).length), status: ratio(pct(rr.filter((r) => has(a.db.restaurant_categories, r)).length), 95, 80), target: '≥ 95%' },
      { key: 'contacts', label: 'Contatti (telefono/sito/WhatsApp)', critical: false, value: pct(rr.filter((r) => r.phone || r.website || r.whatsapp || r.email).length), status: ratio(pct(rr.filter((r) => r.phone || r.website || r.whatsapp || r.email).length), 80, 50), target: '≥ 80%' },
      { key: 'sources', label: 'Fonti dei dati tracciate', critical: true, value: pct(rr.filter((r) => r.source_name || has(a.db.restaurant_sources, r)).length), status: ratio(pct(rr.filter((r) => r.source_name || has(a.db.restaurant_sources, r)).length), 90, 70), target: '≥ 90%' },
      { key: 'verified', label: 'Dati verificati o rivendicati', critical: false, value: pct(rr.filter((r) => r.is_verified || ['verified', 'claimed', 'partially_verified'].includes(r.data_status ?? '')).length), status: ratio(pct(rr.filter((r) => r.is_verified).length), 50, 20), target: '≥ 50%' },
      { key: 'menus', label: 'Locali con menu', critical: false, value: pct(rr.filter((r) => a.db.menus.some((m) => m.restaurant_id === r.id && m.is_active)).length), status: ratio(pct(rr.filter((r) => a.db.menus.some((m) => m.restaurant_id === r.id)).length), 40, 15), target: '≥ 40%' },
      { key: 'seo_pages', label: `Pagine SEO categoria×comune (≥ ${min} locali)`, critical: false, value: seo, status: seo >= 10 ? 'pass' : seo >= 3 ? 'warn' : 'fail', target: '≥ 10 pagine' },
      { key: 'city_pages', label: 'Comuni coperti', critical: false, value: cities, status: cities >= 5 ? 'pass' : cities >= 1 ? 'warn' : 'fail', target: '≥ 5 comuni' },
      { key: 'claim_flow', label: 'Flusso rivendicazione e piani business', critical: true, value: a.db.subscription_plans.filter((p) => p.is_active).length, status: a.db.subscription_plans.filter((p) => p.is_active).length >= 2 ? 'pass' : 'fail', target: 'piani attivi' },
      { key: 'business_pricing', label: 'Prezzi business collegati a Stripe', critical: false, value: 0, status: a.db.subscription_plans.some((p) => p.stripe_monthly_price_id) ? 'pass' : 'warn', target: 'price ID Stripe' },
      { key: 'support', label: 'Supporto (email e pagina /support)', critical: true, value: setting('support_email'), status: setting('support_email') ? 'pass' : 'fail', target: 'email impostata' },
      { key: 'legal', label: 'Privacy, cookie e termini (revisione legale)', critical: true, value: null, status: legalOk ? 'pass' : 'warn', target: 'documenti non in bozza' },
      { key: 'analytics', label: 'Analytics (eventi ultimi 7 giorni)', critical: false, value: a.db.analytics.filter((e) => Date.now() - Date.parse(e.created_at) < 7 * DAY).length, status: a.db.analytics.some((e) => Date.now() - Date.parse(e.created_at) < 7 * DAY) ? 'pass' : 'warn', target: 'eventi ricevuti' },
      { key: 'monitoring', label: 'Monitoring (health check recente)', critical: true, value: null, status: 'fail', target: 'cron di sistema attivo (non disponibile in DEMO)' },
      { key: 'backup', label: 'Backup verificato', critical: true, value: lc.backup_enabled?.notes ?? null, status: lc.backup_enabled?.status === 'pass' ? 'pass' : lc.backup_enabled?.status === 'fail' ? 'fail' : 'pending', target: 'conferma manuale' },
    ];
    const critFail = checks.filter((c) => c.critical && c.status !== 'pass').length;
    let score = Math.round((checks.filter((c) => c.status === 'pass').length * 100) / checks.length);
    if (critFail) score = Math.min(score, 99);
    return { province: code, generated_at: now(), restaurants: n, score, ready: critFail === 0, critical_failing: critFail, checks };
  }

  function consistency(): ConsistencyReport {
    const dupes = (arr: string[]) => [...new Set(arr.filter((x, i) => arr.indexOf(x) !== i))];
    const checks: ConsistencyReport['checks'] = [
      { key: 'duplicate_restaurant_slugs', label: 'Slug ristorante duplicati (maiuscole/minuscole)', severity: 'high', count: 0, sample: dupes(a.db.restaurants.map((r) => r.slug.toLowerCase())) },
      { key: 'owner_without_membership', label: 'Titolari senza membership attiva', severity: 'medium', count: 0,
        sample: a.db.restaurants.filter((r) => r.owner_id && !a.db.restaurant_members.some((m) => m.restaurant_id === r.id && m.user_id === r.owner_id && m.status === 'active')).map((r) => r.id).slice(0, 20) },
      { key: 'members_blocked_active', label: 'Membri attivi con profilo bloccato', severity: 'medium', count: 0,
        sample: a.db.restaurant_members.filter((m) => m.status === 'active' && profile(m.user_id)?.is_blocked).map((m) => m.user_id).slice(0, 20) },
      { key: 'active_restaurants_without_coordinates', label: 'Locali attivi senza coordinate', severity: 'low', count: 0,
        sample: a.db.restaurants.filter((r) => r.is_active && !r.is_demo && (r.latitude == null || r.longitude == null)).map((r) => r.id).slice(0, 20) },
    ].map((c) => ({ ...c, count: c.sample.length, sample: c.sample.slice(0, 5) })) as ConsistencyReport['checks'];
    return { generated_at: now(), total_issues: checks.reduce((s, c) => s + c.count, 0), checks };
  }

  function checklist(): LaunchChecklist {
    const lc = st().launch_checks;
    const city = cityReadiness('TA');
    const cons = consistency();
    const demoRest = a.db.restaurants.filter((r) => r.is_demo && r.is_active).length;
    const draft = st().legal.filter((l) => l.is_current && l.is_draft).length;
    const auto = (key: string, section: string, title: string, cb: boolean, cp: boolean, status: CheckStatus, detail?: string): LaunchCheck => ({ key, section, title, crit_beta: cb, crit_prod: cp, kind: 'auto', status, detail, last_checked_at: now() });
    const other = (key: string, section: string, title: string, cb: boolean, cp: boolean, kind: 'system' | 'manual'): LaunchCheck => ({
      key, section, title, crit_beta: cb, crit_prod: cp, kind, status: lc[key]?.status ?? 'pending',
      detail: lc[key]?.notes ?? (kind === 'system' ? 'Richiede il backend (cron di sistema): non disponibile in modalità DEMO' : 'Da confermare manualmente'),
      last_checked_at: lc[key]?.last_checked_at ?? null,
    });
    const checks: LaunchCheck[] = [
      auto('sec_rls', 'SECURITY', 'RLS attiva su tutte le tabelle', true, true, 'pending', 'Verificabile solo con Supabase (in DEMO nessun database)'),
      auto('sec_admin_rpc', 'SECURITY', 'Funzioni Admin non eseguibili da anonimi', true, true, 'pending', 'Verificabile solo con Supabase'),
      other('env_secrets', 'SECURITY', 'Secret server configurati (nessun valore mostrato)', true, true, 'system'),
      other('env_app_env', 'SECURITY', 'APP_ENV=production e chiavi coerenti con l\'ambiente', false, true, 'system'),
      other('sec_headers', 'SECURITY', 'Security headers e CSP verificati sul dominio (securityheaders.com)', false, true, 'manual'),
      other('sec_auth_captcha', 'SECURITY', 'Supabase Auth: rate limit, conferma email, Turnstile/CAPTCHA attivi', false, true, 'manual'),
      auto('priv_documents', 'PRIVACY', 'Informativa privacy e cookie pubblicate', true, true, 'pass', 'Template presenti: vanno completati con il consulente'),
      auto('priv_retention_job', 'PRIVACY', 'Job di retention eseguito nelle ultime 48 ore', false, true, 'pending', 'Nessun cron in DEMO'),
      other('priv_dpa', 'PRIVACY', 'Nomine responsabili (DPA) con Supabase, Netlify, Stripe, provider AI/email; registro trattamenti', false, true, 'manual'),
      auto('legal_review', 'LEGAL', 'Testi legali revisionati da un consulente (non più bozza)', false, true, draft ? 'pending' : 'pass', `${draft} documenti ancora in bozza`),
      auto('legal_company', 'LEGAL', 'Ragione sociale, P.IVA, sede e contatti nel footer', false, true, setting('legal_company_name') && setting('legal_vat_number') && setting('legal_address') ? 'pass' : 'pending'),
      auto('data_demo_hidden', 'DATA', 'Dati DEMO nascosti/eliminati', false, true, setting('show_demo_data') === false || demoRest === 0 ? 'pass' : 'fail', `show_demo_data=${setting('show_demo_data') !== false}, locali demo attivi=${demoRest}`),
      auto('data_consistency', 'DATA', 'Report di consistenza senza anomalie gravi', false, false, cons.total_issues === 0 ? 'pass' : 'warn', `${cons.total_issues} anomalie`),
      auto('data_taranto', 'DATA', 'Taranto Launch Readiness', false, true, city.ready ? 'pass' : 'pending', `score ${city.score}%, ${city.restaurants} locali reali`),
      other('env_sitemap', 'SEO', 'sitemap.xml e robots.txt raggiungibili sul dominio', false, true, 'system'),
      other('seo_search_console', 'SEO', 'Dominio verificato in Google Search Console e sitemap inviata', false, false, 'manual'),
      auto('perf_web_vitals', 'PERFORMANCE', 'Core Web Vitals p75 nei target (LCP < 2,5 s, INP < 200 ms, CLS < 0,1)', false, false, st().vitals.length >= 50 ? 'warn' : 'pending', 'Misure reali degli utenti che hanno accettato i cookie analytics'),
      other('env_stripe', 'PAYMENTS', 'Stripe configurato (chiave, webhook secret, modalità coerente)', false, true, 'system'),
      auto('pay_webhook', 'PAYMENTS', 'Webhook Stripe senza errori nelle ultime 24 ore', true, true, 'pending', 'In DEMO i pagamenti sono simulati'),
      other('pay_live_test', 'PAYMENTS', 'Pagamento reale di prova + rimborso eseguiti in LIVE', false, true, 'manual'),
      auto('orders_cron', 'ORDERS', 'Cron ordini attivo (ultima ora)', false, true, 'pending', 'Nessun cron in DEMO'),
      auto('delivery_zones', 'DELIVERY', 'Zone servite configurate', false, false, 'pass'),
      auto('rider_real', 'RIDER', 'Almeno un Rider reale approvato (se consegne AsiaFood attive)', false, false, 'warn', 'In DEMO solo Rider di prova'),
      other('env_ai', 'AI', 'Provider AI configurato o disattivato esplicitamente', false, false, 'system'),
      auto('crm_module', 'CRM', 'CRM / Sales Agent', false, false, 'na', 'Modulo non presente in questa versione: nessuna superficie da proteggere'),
      other('email_dns', 'EMAIL', 'Provider email + SPF, DKIM, DMARC sul dominio mittente', false, true, 'manual'),
      auto('email_outbox', 'EMAIL', 'Nessuna email fallita nelle ultime 24 ore', false, false, 'pass'),
      other('env_push', 'PUSH', 'Chiavi VAPID configurate', false, false, 'system'),
      auto('analytics_consent', 'ANALYTICS', 'Banner cookie con consensi registrati', true, true, st().consents.length ? 'pass' : 'pending', 'Almeno una scelta registrata dal banner'),
      other('backup_enabled', 'BACKUP', 'Backup giornalieri Supabase attivi (piano Pro o superiore / PITR)', true, true, 'manual'),
      other('backup_restore_test', 'BACKUP', 'Restore testato su staging (data e durata annotate)', false, true, 'manual'),
      other('mon_health', 'MONITORING', 'Health check del backend OK (ultime 2 ore)', true, true, 'system'),
      other('mon_uptime', 'MONITORING', 'Uptime monitor esterno su home, /api/health e checkout', false, true, 'manual'),
      other('env_error_tracking', 'MONITORING', 'Error tracking (Sentry o log errori interno)', false, false, 'system'),
      other('env_domain', 'MONITORING', 'Dominio personalizzato in HTTPS', false, true, 'system'),
      auto('support_contact', 'SUPPORT', 'Email di supporto impostata', true, true, setting('support_email') ? 'pass' : 'fail'),
      auto('support_backlog', 'SUPPORT', 'Nessun ticket urgente aperto da oltre 24 ore', false, false,
        st().tickets.some((t) => t.priority === 'urgent' && ['open', 'in_progress'].includes(t.status) && Date.now() - Date.parse(t.created_at) > DAY) ? 'warn' : 'pass'),
    ];
    const betaBlock = checks.filter((c) => c.crit_beta && c.status === 'fail').length;
    const betaOpen = checks.filter((c) => c.crit_beta && !['pass', 'na'].includes(c.status)).length;
    const prodOpen = checks.filter((c) => (c.crit_beta || c.crit_prod) && !['pass', 'na'].includes(c.status));
    const applicable = checks.filter((c) => c.status !== 'na');
    let score = Math.round((applicable.filter((c) => c.status === 'pass').length * 100) / applicable.length);
    if (prodOpen.length) score = Math.min(score, 99);
    return {
      status: betaBlock ? 'BLOCKED' : betaOpen ? 'NOT_READY' : prodOpen.length ? 'READY_FOR_BETA' : 'READY_FOR_PRODUCTION',
      score, generated_at: now(),
      blocking: prodOpen.map((c) => ({ key: c.key, title: c.title, status: c.status, stage: c.crit_beta ? 'beta' : 'production' })),
      checks, city,
    };
  }

  function systemStatus(): SystemStatus {
    const s = st();
    const day = (iso: string) => Date.now() - Date.parse(iso) < DAY;
    const vit: SystemStatus['web_vitals'] = {};
    for (const m of ['LCP', 'INP', 'CLS', 'FCP', 'TTFB'] as const) {
      const vals = s.vitals.filter((v) => v.metric === m && Date.now() - Date.parse(v.created_at) < 7 * DAY).map((v) => v.value).sort((x, y) => x - y);
      if (vals.length) vit[m] = { p75: vals[Math.min(vals.length - 1, Math.floor(vals.length * 0.75))]!, samples: vals.length };
    }
    const flags: FlagState[] = FLAGS.map((f) => ({ ...f, value: setting(f.key) === true }));
    const alerts: SystemStatus['alerts'] = [{ key: 'demo', level: 'info', message: 'Modalità DEMO: nessun backend, cron e webhook non attivi. I dati mostrati sono locali.' }];
    if (setting('maintenance_mode') === true) alerts.push({ key: 'maintenance', level: 'info', message: 'Modalità manutenzione attiva' });
    const tables = Object.entries(a.db).filter(([, v]) => Array.isArray(v)).map(([k, v]) => ({ table: k, rows: (v as unknown[]).length, dead: 0, seq_scans: 0, idx_scans: 0 }))
      .sort((x, y) => y.rows - x.rows).slice(0, 12);
    let size: number | null = null;
    try {
      size = (localStorage.getItem('asiafood-demo-db') ?? '').length * 2;
    } catch {
      size = null;
    }
    return {
      generated_at: now(), alerts, flags,
      errors: { last_10min: s.errors.filter((e) => Date.now() - Date.parse(e.created_at) < 600_000 && e.source !== 'client').length, last_24h: s.errors.filter((e) => day(e.created_at)).length,
        client_24h: s.errors.filter((e) => e.source === 'client' && day(e.created_at)).length, recent: s.errors.slice(0, 30) },
      webhooks: { failed_24h: 0, failed_7d: 0, stuck: 0, processed_24h: a.db.stripe_events.length, last_processed_at: null, recent_failed: [] },
      jobs: { last_runs: [], failed: [], running: 0, stuck: 0 },
      email: { pending: a.db.email_outbox.filter((e) => e.status === 'pending').length, failed_24h: 0, sent_24h: 0, oldest_pending_minutes: null },
      push: { enabled: setting('push_enabled') === true, pending: 0, failed_24h: 0, sent_24h: 0, active_devices: 0 },
      ai: { enabled: setting('ai_enabled') === true, requests_1h: (a.db.ai_usage ?? []).filter((u) => Date.now() - Date.parse(u.created_at) < 3600_000).length, errors_1h: 0, fallback_1h: 0, last_ok_at: null },
      payments: { failed_1h: 0, succeeded_24h: 0, refunds_pending: 0 },
      dispatch: { failed_1h: 0, open_alerts: 0, active_jobs: 0 },
      privacy: { deletions_scheduled: s.deletions.filter((d) => d.status === 'scheduled').length, deletions_blocked: s.deletions.filter((d) => d.status === 'blocked').length,
        deletions_anonymized: s.deletions.filter((d) => d.status === 'anonymized').length, exports_7d: s.exports.filter((e) => Date.now() - Date.parse(e.requested_at) < 7 * DAY).length },
      support: { open: s.tickets.filter((t) => ['open', 'in_progress', 'waiting_customer'].includes(t.status)).length, urgent: s.tickets.filter((t) => ['urgent', 'high'].includes(t.priority) && ['open', 'in_progress'].includes(t.status)).length },
      cleanup: { last_retention: null, rider_locations_overdue: 0, rate_limit_rows: Object.keys(s.rate).length, expired_ai_sessions: 0 },
      security: { rate_limited_24h: 0, rate_limited_buckets: {}, gps_flood_24h: 0, admin_sessions_24h: s.audit.filter((x) => x.action === 'admin_session' && day(x.created_at)).length },
      web_vitals: vit,
      system_checks: [],
      db: { size_bytes: size, tables },
    };
  }

  return {
    recordSlugChange(restaurantId: string, oldSlug: string, newSlug: string) {
      const h = st().slug_history.filter((x) => x.old_slug !== newSlug);
      st().slug_history = [...h.filter((x) => x.old_slug !== oldSlug), { restaurant_id: restaurantId, old_slug: oldSlug, created_at: now() }];
    },
    runtimeConfig,
    recordConsent(choices: ConsentChoices, anon: string | null, source: string): ConsentState {
      const uid = a.uid();
      if (!uid && (!anon || !/^[A-Za-z0-9_-]{8,64}$/.test(anon))) fail('Identificativo di consenso non valido');
      limit('consent', 30, 3600_000);
      const ver = String(setting('consent_policy_version'));
      const cur = consentState(uid, anon).choices;
      for (const t of ['necessary', 'analytics', 'marketing', 'personalization'] as ConsentType[]) {
        const v = t === 'necessary' ? true : !!choices[t as keyof ConsentChoices];
        if (cur[t]?.granted === v && cur[t]?.policy_version === ver) continue;
        st().consents.push({ id: uuid(), user_id: uid, anonymous_id: uid ? null : anon, consent_type: t, granted: v, policy_version: ver, source, created_at: now() });
      }
      if (uid) {
        const p = profile(uid);
        if (p) p.marketing_opt_in = !!choices.marketing;
      }
      a.save();
      return consentState(uid, anon);
    },
    myConsents(): ConsentState {
      const uid = requireUser();
      return { ...consentState(uid, null), history: st().consents.filter((c) => c.user_id === uid).reverse().slice(0, 50)
        .map((c) => ({ type: c.consent_type, granted: c.granted, policy_version: c.policy_version, source: c.source, at: c.created_at })) };
    },
    exportMyData() {
      const uid = requireUser();
      if (st().exports.filter((e) => e.user_id === uid && Date.now() - Date.parse(e.requested_at) < DAY).length >= 3) {
        fail('Hai già scaricato i tuoi dati più volte oggi. Riprova domani.');
      }
      const data = exportData(uid);
      const e = { id: uuid(), user_id: uid, status: 'completed', requested_at: now(), completed_at: now(), expires_at: new Date(Date.now() + 7 * DAY).toISOString(), size_bytes: JSON.stringify(data).length };
      st().exports.unshift(e);
      audit('security', 'data_export', 'profile', uid);
      a.save();
      return { request_id: e.id, data };
    },
    privacyStatus(): PrivacyStatus {
      const uid = requireUser();
      processDeletions();
      const d = st().deletions.filter((x) => x.user_id === uid).sort((x, y) => y.requested_at.localeCompare(x.requested_at))[0];
      return {
        deletion: d ? { ...d } : null,
        exports: st().exports.filter((e) => e.user_id === uid).slice(0, 5).map(({ id, status, requested_at, completed_at, expires_at }) => ({ id, status, requested_at, completed_at, expires_at })),
        grace_days: Number(setting('account_deletion_grace_days') ?? 7),
      };
    },
    requestDeletion(password: string, reason: string | null): DeletionRequest {
      const uid = requireUser();
      // DEMO: nessuna password reale, ma il passaggio di conferma resta obbligatorio
      if (!password || password.length < 1) fail('Per sicurezza inserisci di nuovo la password prima di eliminare l’account.');
      const open = st().deletions.find((d) => d.user_id === uid && ['scheduled', 'blocked'].includes(d.status));
      if (open) return { ...open };
      const grace = Number(setting('account_deletion_grace_days') ?? 7);
      const d = { id: uuid(), user_id: uid, status: 'scheduled' as const, reason: reason?.slice(0, 500) ?? null, requested_at: now(), scheduled_for: new Date(Date.now() + grace * DAY).toISOString(),
        completed_at: null, cancelled_at: null, blocked_reason: null };
      st().deletions.unshift(d);
      audit('security', 'account_deletion_requested', 'profile', uid);
      a.notify(uid, 'account', 'Richiesta di eliminazione ricevuta',
        `Il tuo account verrà eliminato il ${new Date(d.scheduled_for).toLocaleDateString('it-IT')}. Puoi annullare da Impostazioni → Privacy fino a quel momento.`, '/settings/privacy');
      a.save();
      return { ...d };
    },
    cancelDeletion(): boolean {
      const uid = requireUser();
      const d = st().deletions.find((x) => x.user_id === uid && x.status === 'scheduled' && Date.parse(x.scheduled_for) > Date.now());
      if (!d) return false;
      Object.assign(d, { status: 'cancelled', cancelled_at: now() });
      audit('security', 'account_deletion_cancelled', 'profile', uid);
      a.save();
      return true;
    },
    createTicket(input: SupportTicketInput): { reference: string } {
      const uid = a.uid();
      limit(uid ? 'support' : 'support_guest', uid ? 8 : 5, 3600_000);
      const email = input.email?.trim().toLowerCase() || profile(uid)?.email || null;
      if (!uid && !email) fail('Indica un’email per ricevere la risposta');
      if ((input.subject ?? '').trim().length < 3 || (input.description ?? '').trim().length < 10) fail('Compila oggetto e descrizione.');
      let order: Row | null = null;
      if (input.order_number) {
        order = a.orderAccess(input.order_number.toUpperCase(), input.order_token ?? null);
        if (!order) fail('Ordine non trovato o non accessibile');
      }
      const prio = input.category === 'privacy' || (order && ['order', 'rider', 'billing'].includes(input.category)) ? 'high' : 'normal';
      const t = {
        id: uuid(), reference: `T-${code6()}`, category: input.category, subject: input.subject.trim().slice(0, 140), description: input.description.trim().slice(0, 4000),
        status: 'open' as const, priority: prio as AdminSupportTicket['priority'], contact_email: email, contact_name: input.name?.slice(0, 80) ?? null, admin_notes: null, resolution: null,
        order_id: (order?.id as string) ?? null, order_number: (order?.order_number as string) ?? null, restaurant_name: order ? a.db.restaurants.find((r) => r.id === order!.restaurant_id)?.name ?? null : null,
        user_id: uid, assigned_to: null, created_at: now(), updated_at: now(),
      };
      st().tickets.unshift(t);
      a.save();
      return { reference: t.reference };
    },
    myTickets(): SupportTicket[] {
      const uid = requireUser();
      return st().tickets.filter((t) => t.user_id === uid).map(({ id, reference, category, subject, status, resolution, created_at, updated_at }) => ({ id, reference, category, subject, status, resolution, created_at, updated_at }));
    },
    clientError(e: ClientErrorReport) {
      try {
        limit('client_error', 20, 600_000);
      } catch {
        return;
      }
      st().errors.unshift({ id: Date.now(), source: 'client', code: e.code?.slice(0, 60) ?? null, message: scrub(e.message || 'Errore sconosciuto'), route: (e.route ?? '').replace(/[?#].*$/, '').slice(0, 120) || null, request_id: null, created_at: now() });
      st().errors.splice(200);
      a.save();
    },
    webVital(v: WebVitalReport) {
      if (!['LCP', 'INP', 'CLS', 'FCP', 'TTFB'].includes(v.metric)) return;
      st().vitals.push({ metric: v.metric, value: v.value, created_at: now() });
      st().vitals.splice(0, Math.max(0, st().vitals.length - 1000));
      a.save();
    },
    slugRedirect(slug: string): string | null {
      const h = st().slug_history.find((x) => x.old_slug === slug.toLowerCase());
      const r = h && a.db.restaurants.find((x) => x.id === h.restaurant_id && x.is_active);
      return r && r.slug !== slug ? r.slug : null;
    },
    redeemInvite(token: string) {
      requireUser();
      const inv = st().invites.find((x) => x.token === token && !x.used_at && Date.parse(x.expires_at) > Date.now());
      if (!inv) return false;
      inv.used_at = now();
      a.save();
      return true;
    },
    adminSession() {
      if (!a.isAdmin()) return;
      if (st().audit.some((x) => x.action === 'admin_session' && x.actor === (profile(a.uid())?.display_name ?? profile(a.uid())?.full_name) && Date.now() - Date.parse(x.created_at) < 3600_000)) return;
      audit('security', 'admin_session', 'profile', a.uid());
      a.save();
    },
    systemStatus() {
      requireAdmin();
      return systemStatus();
    },
    setFlag(flag: string, value: boolean) {
      requireAdmin();
      const f = FLAGS.find((x) => x.flag === flag) ?? fail('Flag sconosciuto');
      a.db.settings[f.key] = value;
      audit('admin', 'flag_change', 'feature_flag', flag, { value });
      a.save();
    },
    checklist() {
      requireAdmin();
      return checklist();
    },
    setCheck(key: string, status: CheckStatus, notes: string | null) {
      requireAdmin();
      st().launch_checks[key] = { status, notes, last_checked_at: now(), checked_by: a.uid() };
      audit('admin', 'launch_check', 'launch_check', key, { status });
      a.save();
    },
    adminTickets(filter: SupportFilter, lim = 50, offset = 0) {
      requireAdmin();
      const open = (t: AdminSupportTicket) => ['open', 'in_progress', 'waiting_customer'].includes(t.status);
      const match = (t: AdminSupportTicket) => {
        switch (filter) {
          case 'open': return open(t);
          case 'urgent': return open(t) && ['urgent', 'high'].includes(t.priority);
          case 'orders': return ['order', 'reservation'].includes(t.category);
          case 'restaurants': return ['restaurant', 'business'].includes(t.category);
          case 'riders': return t.category === 'rider';
          case 'billing': return t.category === 'billing';
          case 'closed': return ['resolved', 'closed'].includes(t.status);
          default: return true;
        }
      };
      const pr = { urgent: 0, high: 1, normal: 2, low: 3 } as const;
      const rows = st().tickets.filter(match).sort((x, y) => pr[x.priority] - pr[y.priority] || y.created_at.localeCompare(x.created_at));
      return { total: rows.length, rows: rows.slice(offset, offset + lim) };
    },
    adminUpdateTicket(id: string, patch: Partial<AdminSupportTicket>) {
      requireAdmin();
      const t = st().tickets.find((x) => x.id === id) ?? fail('Ticket non trovato');
      const clean: Partial<AdminSupportTicket> = {};
      for (const k of ['status', 'priority', 'admin_notes', 'resolution', 'assigned_to'] as const) if (k in patch) (clean as Row)[k] = patch[k];
      Object.assign(t, clean, { updated_at: now() });
      audit('admin', 'support_ticket_update', 'support_ticket', id, { status: clean.status ?? null });
      if (clean.status && ['resolved', 'closed'].includes(clean.status) && t.user_id) a.notify(t.user_id, 'support', 'Richiesta di supporto aggiornata', `La richiesta ${t.reference} è stata chiusa.`, '/support');
      a.save();
    },
    privacyRequests(): PrivacyRequests {
      requireAdmin();
      processDeletions();
      return {
        deletions: st().deletions.map((d) => {
          const p = profile(d.user_id);
          const email = p?.email ?? null;
          return { id: d.id, user_id: d.user_id, name: p?.display_name ?? p?.full_name ?? null, email_masked: email ? `${email.slice(0, 2)}•••@${email.split('@')[1]}` : null,
            status: d.status, requested_at: d.requested_at, scheduled_for: d.scheduled_for, blocked_reason: d.blocked_reason, completed_at: d.completed_at };
        }),
        exports: st().exports.map((e) => ({ id: e.id, user_id: e.user_id, status: e.status, requested_at: e.requested_at, size_bytes: e.size_bytes })),
      };
    },
    deletionAction(id: string, action: 'retry' | 'cancel') {
      requireAdmin();
      const d = st().deletions.find((x) => x.id === id) ?? fail('Richiesta non trovata');
      if (action === 'retry' && d.status === 'blocked') Object.assign(d, { status: 'scheduled', scheduled_for: now(), blocked_reason: null });
      if (action === 'cancel' && ['scheduled', 'blocked'].includes(d.status)) Object.assign(d, { status: 'cancelled', cancelled_at: now() });
      audit('admin', `deletion_${action}`, 'account_deletion', id);
      a.save();
    },
    auditList(kind: 'admin' | 'security', lim = 50, offset = 0, action: string | null = null) {
      requireAdmin();
      const rows = st().audit.filter((x) => x.kind === kind && (!action || x.action === action));
      return { total: rows.length, rows: rows.slice(offset, offset + lim).map(({ kind: _k, ...r }) => { void _k; return r; }) };
    },
    consistency() {
      requireAdmin();
      return consistency();
    },
    createInvite(email: string | null, role: string, days: number) {
      requireAdmin();
      const token = Array.from(crypto.getRandomValues(new Uint8Array(18)), (b) => b.toString(16).padStart(2, '0')).join('');
      const inv = { id: uuid(), email, token, role, expires_at: new Date(Date.now() + Math.min(Math.max(days, 1), 90) * DAY).toISOString(), used_at: null };
      st().invites.push(inv);
      audit('admin', 'beta_invite_created', 'beta_invite', inv.id, { role });
      a.save();
      return { id: inv.id, token };
    },
    createLegalVersion(type: LegalDocumentType, version: string, url: string, isDraft: boolean) {
      requireAdmin();
      for (const l of st().legal.filter((x) => x.document_type === type)) l.is_current = false;
      st().legal.push({ document_type: type, version, url, effective_at: now(), is_current: true, is_draft: isDraft });
      if (type === 'privacy' || type === 'cookie') a.db.settings.consent_policy_version = version;
      audit('admin', 'legal_version_created', 'legal_document', type, { version });
      a.save();
    },
  };
}
