// ─────────────────────────────────────────────────────────────
//  Client degli endpoint ordini (Netlify Functions, modulo separato
//  dalla fatturazione B2B). Il browser invia solo identificativi e
//  scelte: prezzi, sconti, consegna e totale li calcola il server.
// ─────────────────────────────────────────────────────────────
import { ORDERS } from '@/config/app';
import { supabase } from '@/lib/supabase';
import { readApiError } from '@/lib/errors';

export class OrdersApiError extends Error {
  constructor(
    readonly code: string,
    message: string,
    readonly status: number,
    readonly body: Record<string, unknown> | null = null,
    readonly requestId?: string,
  ) {
    super(message);
    this.name = 'OrdersApiError';
  }
}

export async function ordersCall<T>(endpoint: 'create' | 'action' | 'connect', body: Record<string, unknown>, opts: { auth?: 'optional' | 'required' } = {}): Promise<T> {
  const token = supabase ? (await supabase.auth.getSession()).data.session?.access_token : null;
  if (opts.auth === 'required' && !token) throw new OrdersApiError('UNAUTHORIZED', 'Accedi per continuare.', 401);
  let res: Response;
  try {
    res = await fetch(`${ORDERS.apiBase}/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(body),
    });
  } catch {
    throw new OrdersApiError('NETWORK', 'Connessione non disponibile. Controlla la rete e riprova.', 0);
  }
  let json: Record<string, unknown> | null;
  try {
    json = (await res.json()) as Record<string, unknown>;
  } catch {
    json = null;
  }
  if (!res.ok) {
    const fallback = res.status === 404 ? 'Il servizio ordini non è disponibile su questo ambiente.' : 'Si è verificato un errore. Riprova tra poco.';
    const e = readApiError(json, res.status, fallback);
    throw new OrdersApiError(e.code, e.message, res.status, json, e.requestId);
  }
  return json as T;
}
