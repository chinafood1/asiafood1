// ─────────────────────────────────────────────────────────────
//  Sorgente SUPABASE (produzione). La sicurezza è garantita dalle
//  policy RLS nel DB: qui nessun controllo è "di fiducia".
// ─────────────────────────────────────────────────────────────
import { SUPABASE } from '@/config/app';
import { slugify } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import type { ExistingRestaurant } from '@/lib/import/plan';
import type {
  Category,
  ChangeRequest,
  City,
  ClaimMessage,
  ClaimWithRestaurant,
  ImportBatch,
  MemberWithProfile,
  MenuWithSections,
  OfferWithRestaurant,
  Profile,
  ReportWithRestaurant,
  Restaurant,
  RestaurantDetail,
  RestaurantSummary,
} from '@/types/domain';
import { aiCall } from './aiApi';
import { launchSupabase } from './launchSupabase';
import { growthSupabase } from './growthSupabase';
import { trackContext } from '@/lib/trackContext';
import type { AiAdminStats, AiChatReply, AiPreferences, RestaurantAiStats } from '@/types/ai';
import { DEFAULT_PREFS, type Achievement, type AdminReferral, type AdminReview, type BusinessReferral, type Campaign, type PushCampaignStats,
  type EngagementTickResult, type LoyaltyWallet, type ManagedReview, type NotificationPrefs, type RedeemResult, type ReferralSummary,
  type RestaurantEngagementStats, type RestaurantRating, type RetentionStats, type Reward, type ReviewFormStatus, type ReviewItem } from '@/types/engagement';
import { applyFilters, filterOffers, isAyceCategory, isOfferActiveNow, resolveQuery } from './filters';
import { getFeatureLimit, toPlanError } from '@/lib/entitlements';
import { isMenuPublicToday } from '@/lib/menu';
import type {
  AppNotification,
  Availability,
  ClaimCouponResult,
  CouponCheck,
  CouponClaimView,
  PlanUpgradeRequest,
  PlanWithFeatures,
  Reservation,
  ReservationResult,
  ReservationSettings,
  ReservationSlot,
  ReservationWithRestaurant,
  RestaurantAnalytics,
  RestaurantClosure,
  AdminSubscriptionRow,
  BillingAccount,
  BillingOverview,
  CampaignStats,
  ChangePreview,
  CheckoutConfirmation,
  ProfileCompletion,
  RevenueStats,
  SponsoredPlacement,
  StripeEventLog,
} from '@/types/domain';
import { billingCall } from './billingApi';
import type { DataSource, ImportResult, ManagedRestaurant, RestaurantFilters, Row } from './types';
import type {
  AdminOrderDetail, AdminOrderRow, CommissionSettings, CustomerAddress, DeliveryZone, MarketplaceStats, MenuOptionGroup, MyOrderSummary, OrderError, OrderPublicInfo,
  OrderView, OrderableRestaurant, OrdersTickResult, PayoutStatus, Quote, RestaurantOrderSettings, RestaurantOrderStats, RestaurantOrdersPage, Slot,
} from '@/types/orders';
import { OrdersApiError, ordersCall } from './ordersApi';
import { ORDERS } from '@/config/app';

const CLAIM_BUCKET = 'claim-documents';

const sb = () => {
  if (!supabase) throw new Error('Supabase non configurato');
  return supabase;
};

function must<T>(res: { data: T; error: { message: string; code?: string } | null }): T {
  if (res.error) {
    // Limiti di piano: errore tipizzato → la UI mostra l'invito all'upgrade, non un errore tecnico
    const plan = toPlanError(res.error.message);
    if (plan) throw plan;
    // "RATE_LIMITED: …", "REAUTH_REQUIRED: …" → errore con codice (la UI mostra un messaggio chiaro)
    const coded = fromDbMessage(res.error.message);
    if (coded) throw coded;
    throw new Error(translateDbError(res.error));
  }
  return res.data;
}

function translateDbError(e: { message: string; code?: string }): string {
  if (/^permission denied for function/i.test(e.message)) return 'Operazione non consentita.';
  if (e.code === '42501' || /row-level security/i.test(e.message)) return 'Operazione non consentita.';
  if (e.code === '23505') return 'Esiste già un elemento con questi dati.';
  return e.message;
}

const SUMMARY_SELECT =
  '*, city:cities(id,name,slug), restaurant_categories(is_primary, category:categories(id,name,slug,emoji)), hours:restaurant_hours(*), offers(id,is_active,starts_at,ends_at), sponsored_now';

const DETAIL_SELECT = `${SUMMARY_SELECT.replace('offers(id,is_active,starts_at,ends_at)', 'offers(*)')}, images:restaurant_images(*), coupons(*), province:provinces(id,name,code), sources:restaurant_sources(*), reservation_settings(*), menus(*, sections:menu_categories(*, items:menu_items(*, variants:menu_item_variants(*), addons:menu_item_addons(*))))`;

const CLAIM_SELECT = '*, restaurant:restaurants(id,name,slug,address,phone,logo_url,owner_id, city:cities(name))';

type Window = { is_active: boolean; starts_at: string; ends_at: string | null };
type RawRow = Row & {
  city: RestaurantSummary['city'];
  restaurant_categories?: { is_primary: boolean; category: RestaurantSummary['categories'][number] | null }[];
  offers?: Window[];
  sponsored_now?: boolean;
};

const RELATION_KEYS = [
  'city', 'categories', 'hours', 'images', 'menus', 'offers', 'coupons', 'province', 'sources', 'sponsored', 'sponsored_now',
  'restaurant_categories', 'active_offers_count', 'distance_km', 'search_vector', 'member_role', 'category_slugs', 'created_at', 'updated_at', 'reservation_settings',
];

function toSummary(raw: RawRow): RestaurantSummary {
  const { restaurant_categories = [], offers = [], ...rest } = raw;
  delete (rest as Row).search_vector;
  return {
    ...(rest as unknown as Restaurant),
    city: raw.city ?? null,
    hours: (raw.hours as RestaurantSummary['hours']) ?? [],
    categories: [...restaurant_categories]
      .sort((a, b) => Number(b.is_primary) - Number(a.is_primary))
      .map((l) => l.category)
      .filter((c): c is NonNullable<typeof c> => !!c),
    active_offers_count: offers.filter((o) => isOfferActiveNow(o)).length,
    sponsored_now: !!raw.is_sponsored || !!raw.sponsored_now,
  };
}

function toDetail(raw: RawRow, includeInactive: boolean): RestaurantDetail {
  const s = toSummary(raw);
  const bySort = <T extends { sort_order: number }>(a: T, b: T) => a.sort_order - b.sort_order;
  const byOrder = <T extends { display_order: number }>(a: T, b: T) => a.display_order - b.display_order;
  const menus = ((raw.menus as MenuWithSections[]) ?? [])
    .filter((m) => includeInactive || isMenuPublicToday(m))
    .sort(bySort)
    .map((m) => ({
      ...m,
      sections: [...(m.sections ?? [])]
        .filter((sec) => includeInactive || sec.is_active)
        .sort(bySort)
        .map((sec) => ({
          ...sec,
          items: [...(sec.items ?? [])].sort(bySort).map((it) => ({ ...it, variants: [...(it.variants ?? [])].sort(byOrder), addons: [...(it.addons ?? [])].sort(byOrder) })),
        })),
    }));
  const rs = raw.reservation_settings as ReservationSettings | ReservationSettings[] | null | undefined;
  const offers = ((raw.offers as RestaurantDetail['offers']) ?? []).filter((o) => includeInactive || isOfferActiveNow(o));
  return {
    ...s,
    images: ((raw.images as RestaurantDetail['images']) ?? []).sort(bySort),
    menus,
    offers,
    coupons: (raw.coupons as RestaurantDetail['coupons']) ?? [],
    province: (raw.province as RestaurantDetail['province']) ?? null,
    sources: ((raw.sources as RestaurantDetail['sources']) ?? []).sort((a, b) => Number(b.is_primary) - Number(a.is_primary)),
    reservation_settings: (Array.isArray(rs) ? rs[0] : rs) ?? null,
  };
}

type RawClaim = Omit<ClaimWithRestaurant, 'restaurant'> & { restaurant: (NonNullable<ClaimWithRestaurant['restaurant']> & { city?: { name: string } | null }) | null };
const toClaim = (c: RawClaim): ClaimWithRestaurant => ({
  ...c,
  restaurant: c.restaurant ? { ...c.restaurant, city_name: c.restaurant.city?.name ?? null } : null,
});

function cleanPatch(patch: Row): Row {
  const out: Row = {};
  Object.entries(patch).forEach(([k, v]) => {
    if (!RELATION_KEYS.includes(k)) out[k] = v;
  });
  return out;
}

// Cache in memoria per dati di riferimento (cambiano raramente)
let categoriesCache: Promise<Category[]> | null = null;
let citiesCache: Promise<City[]> | null = null;

const getCategories = () =>
  (categoriesCache ??= (async () =>
    must(await sb().from('categories').select('*').eq('is_active', true).order('sort_order')) as Category[])());

let plansCache: Promise<PlanWithFeatures[]> | null = null;
const getPlans = () =>
  (plansCache ??= (async () =>
    must(await sb().from('subscription_plans').select('*, plan_features(*)').order('sort_order')) as PlanWithFeatures[])().catch((e) => {
    plansCache = null;
    throw e;
  }));

const getCities = () =>
  (citiesCache ??= (async () => must(await sb().from('cities').select('*').eq('is_active', true).order('name')) as City[])());

function sessionId(): string {
  try {
    let id = sessionStorage.getItem('af_sid');
    if (!id) {
      id = crypto.randomUUID();
      sessionStorage.setItem('af_sid', id);
    }
    return id;
  } catch {
    return 'no-session';
  }
}

/** ID di sessione per le statistiche: solo con consenso "Statistiche" (altrimenti conteggio anonimo senza identificativo). */
const analyticsSessionId = () => (hasConsent('analytics') ? sessionId() : null);

/** "Scaduto" è calcolato dalla validità del coupon (come check_coupon_claim). */
const withExpiry = (rows: CouponClaimView[]) =>
  rows.map((x) => (x.status === 'claimed' && x.coupon?.valid_until && new Date(x.coupon.valid_until) <= new Date() ? { ...x, status: 'expired' as const } : x));

const escapeLike = (s: string) => s.replace(/[%_,()*\\.]/g, ' ').trim();
const currentUserId = async () => (await sb().auth.getSession()).data.session?.user.id ?? null;

async function runSearch(f: RestaurantFilters, categories: Category[], cities: City[]): Promise<RestaurantSummary[]> {
  let query = sb().from('restaurants').select(SUMMARY_SELECT).eq('is_active', true);
  if (!f.includeClosed) query = query.eq('is_permanently_closed', false);

  if (f.categorySlug) {
    const cat = categories.find((c) => c.slug === f.categorySlug);
    if (!cat) return [];
    const links = must(await sb().from('restaurant_categories').select('restaurant_id').eq('category_id', cat.id)) as { restaurant_id: string }[];
    const ids = links.map((l) => l.restaurant_id);
    if (isAyceCategory(cat.slug)) query = ids.length ? query.or(`is_all_you_can_eat.eq.true,id.in.(${ids.join(',')})`) : query.eq('is_all_you_can_eat', true);
    else if (!ids.length) return [];
    else query = query.in('id', ids);
  }
  // Ogni parola del testo deve comparire in almeno un campo (AND tra parole)
  for (const w of (f.text ?? '').split(' ').map(escapeLike).filter((x) => x.length > 1).slice(0, 5)) {
    query = query.or(`name.ilike.%${w}%,short_description.ilike.%${w}%,description.ilike.%${w}%,address.ilike.%${w}%`);
  }
  if (f.citySlug) {
    const city = cities.find((c) => c.slug === f.citySlug);
    if (!city) return [];
    query = query.eq('city_id', city.id);
  }
  if (f.priceRanges?.length) query = query.in('price_range', f.priceRanges);
  if (f.ayce) query = query.eq('is_all_you_can_eat', true);
  if (f.delivery) query = query.eq('has_delivery', true);
  if (f.takeaway) query = query.eq('has_takeaway', true);
  if (f.reservation) query = query.eq('has_reservation', true);
  if (f.featured) query = query.eq('is_featured', true);
  if (f.verified) query = query.eq('is_verified', true).not('owner_id', 'is', null);
  // Area della mappa: usa l'indice (latitude, longitude); esclude i locali senza coordinate
  if (f.bounds) {
    query = query.gte('latitude', f.bounds.south).lte('latitude', f.bounds.north).gte('longitude', f.bounds.west).lte('longitude', f.bounds.east);
  }
  // Privacy: al server arriva al massimo un riquadro arrotondato (~11 km), mai le coordinate esatte.
  if (f.near?.radiusKm && !f.citySlug) {
    const pad = f.near.radiusKm / 111 + 0.1;
    const lngPad = pad / Math.max(Math.cos((f.near.lat * Math.PI) / 180), 0.2);
    const r1 = (x: number, up: boolean) => (up ? Math.ceil(x * 10) : Math.floor(x * 10)) / 10;
    query = query
      .gte('latitude', r1(f.near.lat - pad, false))
      .lte('latitude', r1(f.near.lat + pad, true))
      .gte('longitude', r1(f.near.lng - lngPad, false))
      .lte('longitude', r1(f.near.lng + lngPad, true));
  }

  const clientSide = f.openNow || f.hasOffers || f.newOpenings || f.near || (f.sort && f.sort !== 'popular');
  // Mai l'intero database sul client: tetto di 500 righe (la mappa lavora per area e cluster)
  query = query.order('popularity_score', { ascending: false }).order('name').limit(clientSide || !f.limit ? 500 : Math.min(f.limit + 10, 500));
  const rows = (must(await query) as RawRow[]).map(toSummary);

  const plans = await getPlans().catch(() => [] as PlanWithFeatures[]);
  return applyFilters(rows, f, { categories, skipServerSide: true, planBoost: (r) => getFeatureLimit(plans, r.subscription_plan, 'search_boost') ?? 0 });
}

export const supabaseSource: DataSource = {
  mode: 'supabase',
  launch: launchSupabase,
  growth: growthSupabase,

  getCategories,
  getCities,

  async searchRestaurants(f) {
    const [categories, cities] = await Promise.all([getCategories(), getCities()]);
    const { primary, fallback } = resolveQuery(f, categories, cities);
    const rows = await runSearch(primary, categories, cities);
    return rows.length || !fallback ? rows : runSearch(fallback, categories, cities);
  },

  async getRestaurantBySlug(slug) {
    const raw = must(await sb().from('restaurants').select(DETAIL_SELECT).eq('slug', slug).eq('is_active', true).maybeSingle()) as RawRow | null;
    return raw ? toDetail(raw, false) : null;
  },

  async getRestaurantsByIds(ids) {
    if (!ids.length) return [];
    const rows = must(await sb().from('restaurants').select(SUMMARY_SELECT).in('id', ids).eq('is_active', true)) as RawRow[];
    return rows.map(toSummary);
  },

  async getActiveOffers(opts = {}) {
    // Le RLS restituiscono solo offerte attive di locali pubblicati con piano che include le offerte
    const q = sb()
      .from('offers')
      .select('*, restaurant:restaurants!inner(id,name,slug,cover_url,latitude,longitude,is_all_you_can_eat,is_active,is_permanently_closed, city:cities(name,slug), restaurant_categories(category:categories(slug)))')
      .eq('restaurant.is_active', true)
      .eq('restaurant.is_permanently_closed', false)
      .order('is_featured', { ascending: false })
      .order('starts_at', { ascending: false })
      .limit(300);
    type R = OfferWithRestaurant & { restaurant: OfferWithRestaurant['restaurant'] & { city: { name: string; slug: string } | null; restaurant_categories?: { category: { slug: string } | null }[] } };
    const rows = (must(await q) as R[]).map((o) => {
      const { city, restaurant_categories = [], ...rest } = o.restaurant;
      return {
        ...o,
        restaurant: { ...rest, city_name: city?.name ?? null, city_slug: city?.slug ?? null, category_slugs: restaurant_categories.map((x) => x.category?.slug).filter((x): x is string => !!x) },
      };
    });
    return filterOffers(rows, opts);
  },

  async getCityCounts() {
    const rows = must(await sb().from('restaurants').select('city:cities(slug)').eq('is_active', true).eq('is_permanently_closed', false)) as unknown as { city: { slug: string } | null }[];
    const out: Record<string, number> = {};
    rows.forEach((r) => r.city && (out[r.city.slug] = (out[r.city.slug] ?? 0) + 1));
    return out;
  },

  async getCategoryCounts() {
    const rows = must(
      await sb().from('restaurant_categories').select('category:categories(slug), restaurant:restaurants!inner(is_active,is_permanently_closed)').eq('restaurant.is_active', true).eq('restaurant.is_permanently_closed', false),
    ) as unknown as { category: { slug: string } | null }[];
    const out: Record<string, number> = {};
    rows.forEach((r) => r.category && (out[r.category.slug] = (out[r.category.slug] ?? 0) + 1));
    const { count } = await sb().from('restaurants').select('id', { count: 'exact', head: true }).eq('is_active', true).eq('is_all_you_can_eat', true);
    out['all-you-can-eat'] = Math.max(count ?? 0, out['all-you-can-eat'] ?? 0);
    return out;
  },

  async track(restaurantId, type, source, metadata) {
    // "fire and forget": l'analytics non deve mai bloccare la UI
    await sb()
      .rpc('track_event', { p_restaurant_id: restaurantId, p_event_type: type, p_session_id: analyticsSessionId(), p_source: source ?? null, p_metadata: { ...trackContext(), ...(metadata ?? {}) } })
      .then(() => undefined, () => undefined);
  },

  trackAppEvent(type, opts = {}) {
    void sb()
      .rpc('track_app_event', { p_event_type: type, p_restaurant_id: opts.restaurantId ?? null, p_session_id: analyticsSessionId(), p_source: opts.source ?? null, p_metadata: { ...trackContext(), ...(opts.metadata ?? {}) } })
      .then(() => undefined, () => undefined);
  },

  async createReport(input) {
    // Nessun .select(): l'utente anonimo può inserire ma non leggere le segnalazioni
    must(await sb().from('restaurant_reports').insert(input));
  },

  // ─── Utente ────────────────────────────────────────────────
  async getFavoriteIds(userId) {
    const rows = must(await sb().from('favorites').select('restaurant_id').eq('user_id', userId)) as { restaurant_id: string }[];
    return rows.map((r) => r.restaurant_id);
  },
  async setFavorite(userId, restaurantId, on) {
    if (on) must(await sb().from('favorites').upsert({ user_id: userId, restaurant_id: restaurantId }));
    else must(await sb().from('favorites').delete().eq('user_id', userId).eq('restaurant_id', restaurantId));
  },
  async updateMyProfile(userId, patch) {
    const { full_name, phone, city_id } = patch;
    const row: Record<string, unknown> = { full_name, phone, city_id };
    if (patch.display_name !== undefined) row.display_name = patch.display_name?.trim() || null;
    must(await sb().from('profiles').update(row).eq('id', userId));
  },

  // ─── Rivendicazioni ────────────────────────────────────────
  async uploadClaimDocument(userId, file) {
    // Nome casuale (niente dati personali nel percorso), contenuto verificato dai primi byte
    const up = await prepareUpload(file, 'document');
    const path = `${userId}/${up.name}`;
    const { error } = await sb().storage.from(CLAIM_BUCKET).upload(path, up.file, { upsert: false, contentType: up.mime });
    if (error) throw new Error(error.message);
    return path;
  },

  async createClaim(input) {
    const res = await sb().from('restaurant_claims').insert(input).select('id').single();
    if (res.error) {
      if (res.error.code === '23505') throw new Error('Hai già una richiesta aperta per questo locale.');
      if (res.error.code === '42501') throw new Error('Questo locale non può essere rivendicato.');
      throw new Error(res.error.message);
    }
    return (res.data as { id: string }).id;
  },

  async getMyClaims(userId) {
    const rows = must(await sb().from('restaurant_claims').select(CLAIM_SELECT).eq('user_id', userId).order('submitted_at', { ascending: false })) as RawClaim[];
    return rows.map(toClaim);
  },

  async getClaim(id) {
    const raw = must(
      await sb().from('restaurant_claims').select(`${CLAIM_SELECT}, claimant:profiles!restaurant_claims_user_id_fkey(id,full_name,email)`).eq('id', id).maybeSingle(),
    ) as RawClaim | null;
    return raw ? toClaim(raw) : null;
  },

  async getClaimMessages(claimId) {
    return must(await sb().from('restaurant_claim_messages').select('*').eq('claim_id', claimId).order('created_at')) as ClaimMessage[];
  },

  async respondToClaim(claimId, message, attachmentPath) {
    must(await sb().rpc('respond_to_claim', { p_claim_id: claimId, p_message: message, p_attachment_path: attachmentPath ?? null }));
  },

  async getClaimDocumentUrl(path) {
    const { data, error } = await sb().storage.from(CLAIM_BUCKET).createSignedUrl(path, 120);
    if (error || !data) throw new Error(error?.message ?? 'Documento non disponibile');
    return data.signedUrl;
  },

  // ─── Ristoratore ───────────────────────────────────────────
  async getManagedRestaurants(userId) {
    const mem = must(await sb().from('restaurant_members').select('restaurant_id, role').eq('user_id', userId).eq('status', 'active')) as { restaurant_id: string; role: ManagedRestaurant['member_role'] }[];
    if (!mem.length) return [];
    const rows = must(await sb().from('restaurants').select(SUMMARY_SELECT).in('id', mem.map((m) => m.restaurant_id)).order('name')) as RawRow[];
    return rows.map((r) => ({ ...toSummary(r), member_role: mem.find((m) => m.restaurant_id === r.id)!.role }));
  },

  async getRestaurantForEdit(id) {
    const raw = must(await sb().from('restaurants').select(DETAIL_SELECT).eq('id', id).maybeSingle()) as RawRow | null;
    return raw ? toDetail(raw, true) : null;
  },

  async updateRestaurant(id, patch) {
    must(await sb().from('restaurants').update(cleanPatch(patch as Row)).eq('id', id));
  },

  async setRestaurantCategories(id, categoryIds, primaryId) {
    must(await sb().from('restaurant_categories').delete().eq('restaurant_id', id));
    if (categoryIds.length) {
      must(await sb().from('restaurant_categories').insert(categoryIds.map((cid) => ({ restaurant_id: id, category_id: cid, is_primary: cid === primaryId }))));
    }
  },

  async replaceHours(id, hours) {
    must(await sb().from('restaurant_hours').delete().eq('restaurant_id', id));
    if (hours.length) must(await sb().from('restaurant_hours').insert(hours.map((h) => ({ ...h, restaurant_id: id }))));
  },

  async uploadImage(restaurantId, file, folder) {
    // Validazione + ridimensionamento/WebP (senza EXIF) prima dell'upload pubblico
    const up = await prepareUpload(file, 'image');
    const path = `${restaurantId}/${folder}/${up.name}`;
    const bucket = sb().storage.from(SUPABASE.bucket);
    const { error } = await bucket.upload(path, up.file, { cacheControl: '31536000', upsert: false, contentType: up.mime });
    if (error) throw new Error(error.message);
    return { url: bucket.getPublicUrl(path).data.publicUrl, path };
  },

  async getRestaurantStats(id, days = 30) {
    const rows = must(await sb().rpc('restaurant_stats', { p_restaurant_id: id, p_days: days })) as { event_type: string; total: number }[];
    return Object.fromEntries(rows.map((r) => [r.event_type, Number(r.total)]));
  },

  async listMembers(restaurantId) {
    return must(
      await sb().from('restaurant_members').select('*, profile:profiles!restaurant_members_user_id_fkey(id,full_name,email)').eq('restaurant_id', restaurantId).order('created_at'),
    ) as MemberWithProfile[];
  },

  async createChangeRequest(input) {
    const res = await sb().from('restaurant_change_requests').insert({ ...input, kind: 'location' });
    if (res.error) throw new Error(translateDbError(res.error));
  },

  async listChangeRequests(filter = {}) {
    let q = sb().from('restaurant_change_requests').select('*, restaurant:restaurants(id,name,slug,address,latitude,longitude)').order('created_at', { ascending: false });
    if (filter.status) q = q.eq('status', filter.status);
    if (filter.restaurantId) q = q.eq('restaurant_id', filter.restaurantId);
    return must(await q.limit(200)) as ChangeRequest[];
  },

  // ─── Fase 4: piani ─────────────────────────────────────────
  getPlans,

  async setPlanFeature(planCode, featureKey, patch) {
    must(await sb().from('plan_features').upsert({ plan_code: planCode, feature_key: featureKey, ...patch }, { onConflict: 'plan_code,feature_key' }));
    plansCache = null;
  },

  async requestPlanUpgrade(input) {
    const res = await sb().from('plan_upgrade_requests').insert({ ...input, message: input.message ?? null });
    if (res.error?.code === '23505') throw new Error('Hai già una richiesta aperta per questo piano: ti ricontatteremo a breve.');
    must(res);
  },

  async listUpgradeRequests(filter = {}) {
    let q = sb()
      .from('plan_upgrade_requests')
      .select('*, restaurant:restaurants(id,name,slug,subscription_plan), requester:profiles!plan_upgrade_requests_user_id_fkey(id,full_name,email)')
      .order('created_at', { ascending: false });
    if (filter.status) q = q.eq('status', filter.status);
    if (filter.restaurantId) q = q.eq('restaurant_id', filter.restaurantId);
    return must(await q.limit(200)) as PlanUpgradeRequest[];
  },

  async updateUpgradeRequest(id, status) {
    must(await sb().from('plan_upgrade_requests').update({ status }).eq('id', id));
  },

  // ─── Fase 4: prenotazioni ──────────────────────────────────
  async getReservationAvailability(restaurantId, date, partySize) {
    return must(await sb().rpc('get_reservation_availability', { p_restaurant_id: restaurantId, p_date: date, p_party_size: partySize })) as Availability;
  },

  async createReservation(input) {
    return must(
      await sb().rpc('create_reservation', {
        p_restaurant_id: input.restaurant_id, p_date: input.date, p_time: input.time, p_party_size: input.party_size,
        p_guest_name: input.guest_name, p_guest_surname: input.guest_surname, p_guest_email: input.guest_email,
        p_guest_phone: input.guest_phone, p_notes: input.notes ?? null, p_source: input.source ?? 'web',
      }),
    ) as ReservationResult;
  },

  async cancelReservationByCode(code, email) {
    must(await sb().rpc('cancel_reservation_by_code', { p_code: code, p_email: email }));
  },

  async getRestaurantsAvailableOn(opts) {
    const rows = must(
      await sb().rpc('restaurants_available_on', { p_date: opts.date ?? null, p_party_size: opts.partySize ?? 2, p_from: opts.from ?? '18:00', p_limit: opts.limit ?? 12 }),
    ) as { restaurant_id: string; first_slot: string; slots_count: number }[];
    if (!rows.length) return [];
    const list = await this.getRestaurantsByIds(rows.map((x) => x.restaurant_id));
    return rows
      .map((x) => ({ restaurant: list.find((r) => r.id === x.restaurant_id)!, first_slot: x.first_slot, slots_count: x.slots_count }))
      .filter((x) => !!x.restaurant);
  },

  async getReservationConfig(restaurantId) {
    const [settings, slots, closures] = await Promise.all([
      sb().from('reservation_settings').select('*').eq('restaurant_id', restaurantId).maybeSingle(),
      sb().from('reservation_slots').select('*').eq('restaurant_id', restaurantId).order('day_of_week').order('start_time'),
      sb().from('restaurant_closures').select('*').eq('restaurant_id', restaurantId).gte('date', new Date(Date.now() - 86_400_000).toISOString().slice(0, 10)).order('date'),
    ]);
    const trim = <T extends { start_time: string | null; end_time: string | null }>(x: T): T => ({ ...x, start_time: x.start_time?.slice(0, 5) ?? null, end_time: x.end_time?.slice(0, 5) ?? null });
    return {
      settings: must(settings) as ReservationSettings | null,
      slots: (must(slots) as ReservationSlot[]).map((x) => trim(x) as ReservationSlot),
      closures: (must(closures) as RestaurantClosure[]).map(trim),
    };
  },

  async saveReservationSettings(settings) {
    must(await sb().from('reservation_settings').upsert(settings, { onConflict: 'restaurant_id' }));
  },

  async listReservations(restaurantId, range = {}) {
    let q = sb().from('reservations').select('*').eq('restaurant_id', restaurantId);
    if (range.from) q = q.gte('reservation_date', range.from);
    if (range.to) q = q.lte('reservation_date', range.to);
    if (range.statuses?.length) q = q.in('status', range.statuses);
    const asc = range.ascending !== false;
    const rows = must(await q.order('reservation_date', { ascending: asc }).order('reservation_time', { ascending: asc }).limit(range.limit ?? 500)) as Reservation[];
    return rows.map((x) => ({ ...x, reservation_time: x.reservation_time.slice(0, 5) }));
  },

  async setReservationStatus(id, status, note) {
    must(await sb().rpc('set_reservation_status', { p_id: id, p_status: status, p_note: note ?? null }));
  },

  async getMyReservations() {
    const uid = await currentUserId();
    if (!uid) return [];
    const rows = must(
      await sb().from('reservations').select('*, restaurant:restaurants(id,name,slug,phone)').eq('user_id', uid).order('reservation_date', { ascending: false }).limit(100),
    ) as ReservationWithRestaurant[];
    return rows.map((x) => ({ ...x, reservation_time: x.reservation_time.slice(0, 5) }));
  },

  // ─── Fase 4: coupon ────────────────────────────────────────
  async claimCoupon(couponId, email, source = 'web') {
    return must(await sb().rpc('claim_coupon', { p_coupon_id: couponId, p_email: email ?? null, p_source: source })) as ClaimCouponResult;
  },

  async checkCouponClaim(restaurantId, code) {
    return must(await sb().rpc('check_coupon_claim', { p_restaurant_id: restaurantId, p_code: code })) as CouponCheck;
  },

  async redeemCoupon(restaurantId, code) {
    must(await sb().rpc('redeem_coupon', { p_restaurant_id: restaurantId, p_code: code }));
    return must(await sb().rpc('check_coupon_claim', { p_restaurant_id: restaurantId, p_code: code })) as CouponCheck;
  },

  async listCouponClaims(restaurantId, limit = 50) {
    return withExpiry(
      must(
        await sb()
          .from('coupon_claims')
          .select('*, coupon:coupons(id,title,description,discount_type,discount_value,minimum_spend,valid_until,terms), restaurant:restaurants(id,name,slug)')
          .eq('restaurant_id', restaurantId)
          .order('claimed_at', { ascending: false })
          .limit(limit),
      ) as CouponClaimView[],
    );
  },

  async getMyCouponClaims() {
    const uid = await currentUserId();
    if (!uid) return [];
    return withExpiry(
      must(
        await sb()
          .from('coupon_claims')
          .select('*, coupon:coupons(id,title,description,discount_type,discount_value,minimum_spend,valid_until,terms), restaurant:restaurants(id,name,slug)')
          .eq('user_id', uid)
          .order('claimed_at', { ascending: false })
          .limit(100),
      ) as CouponClaimView[],
    );
  },

  // ─── Fase 4: notifiche ─────────────────────────────────────
  async listNotifications(limit = 30) {
    return must(await sb().from('notifications').select('*').order('created_at', { ascending: false }).limit(limit)) as AppNotification[];
  },

  async markNotificationsRead(ids) {
    must(await sb().rpc('mark_notifications_read', { p_ids: ids ?? null }));
  },

  // ─── Fase 4: statistiche ───────────────────────────────────
  async getRestaurantAnalytics(id, days) {
    return must(await sb().rpc('restaurant_analytics', { p_restaurant_id: id, p_days: days })) as RestaurantAnalytics;
  },

  // ─── Fase 4: menu ──────────────────────────────────────────
  async duplicateMenu(menuId) {
    return must(await sb().rpc('duplicate_menu', { p_menu_id: menuId })) as string;
  },

  async duplicateMenuItem(itemId) {
    return must(await sb().rpc('duplicate_menu_item', { p_item_id: itemId })) as string;
  },

  async reorderMenuRows(table, ids) {
    must(await sb().rpc('reorder_menu_rows', { p_table: table, p_ids: ids }));
  },

  async replaceItemOptions(itemId, variants, addons) {
    const clean = (xs: { name: string; price: number | null; is_available?: boolean }[]) =>
      xs.filter((x) => x.name.trim()).map((x, i) => ({ menu_item_id: itemId, restaurant_id: '00000000-0000-0000-0000-000000000000', name: x.name.trim().slice(0, 60), price: x.price, is_available: x.is_available ?? true, display_order: i }));
    must(await sb().from('menu_item_variants').delete().eq('menu_item_id', itemId));
    must(await sb().from('menu_item_addons').delete().eq('menu_item_id', itemId));
    const v = clean(variants);
    const a = clean(addons);
    if (v.length) must(await sb().from('menu_item_variants').insert(v));
    if (a.length) must(await sb().from('menu_item_addons').insert(a));
  },

  async importMenu(restaurantId, rows) {
    return must(await sb().rpc('import_menu', { p_restaurant_id: restaurantId, p_items: rows })) as { menus: number; categories: number; items: number };
  },

  // ─── CRUD generico ─────────────────────────────────────────
  async list(table, opts = {}) {
    let q = sb().from(table).select('*');
    if (opts.match) q = q.match(opts.match);
    if (opts.orderBy) q = q.order(opts.orderBy, { ascending: opts.ascending !== false });
    return must(await q.limit(opts.limit ?? 2000)) as never;
  },

  async upsert(table, row, pk = 'id') {
    const data = { ...row };
    delete data.created_at;
    delete data.updated_at;
    // restaurant_id su menu_categories/menu_items viene impostato dal trigger DB
    // Con chiave: UPDATE parziale (consente patch come { id, is_available }); se la riga non esiste, INSERT
    if (data[pk]) {
      const upd = must(await sb().from(table).update(data).eq(pk, data[pk] as string).select().maybeSingle());
      if (upd) return upd as never;
    }
    // restaurant_id su categorie/piatti/varianti viene impostato dal trigger DB
    if (['menu_categories', 'menu_items', 'menu_item_variants', 'menu_item_addons'].includes(table) && !data.restaurant_id) {
      data.restaurant_id = '00000000-0000-0000-0000-000000000000';
    }
    return must(await sb().from(table).insert(data).select().single()) as never;
  },

  async remove(table, value, pk = 'id') {
    must(await sb().from(table).delete().eq(pk, value));
  },

  // ─── Admin ─────────────────────────────────────────────────
  async getAdminStats() {
    return must(await sb().rpc('admin_dashboard_stats')) as Record<string, number>;
  },

  // ─── Assistente AI (Fase 6) ────────────────────────────────
  async aiChat(input, signal) {
    const r = await aiCall<{ ok: boolean } & AiChatReply>({ ...input, action: 'chat' }, signal);
    return { response: r.response, remaining: r.remaining };
  },

  async aiHistory(sessionId, restaurantId) {
    const r = await aiCall<{ history: { role: 'user' | 'assistant'; content: string }[] }>({ action: 'history', session_id: sessionId, restaurant_id: restaurantId ?? null });
    return r.history ?? [];
  },

  async aiDeleteSession(sessionId) {
    await aiCall({ action: 'delete', session_id: sessionId });
  },

  async getAiPreferences() {
    const uid = await currentUserId();
    if (!uid) return null;
    return must(await sb().from('ai_user_preferences').select('favorite_categories, preferred_price_range, dietary_preferences, favorite_cities').eq('user_id', uid).maybeSingle()) as AiPreferences | null;
  },

  async saveAiPreferences(prefs) {
    const uid = await currentUserId();
    if (!uid) throw new Error('Accedi per salvare le preferenze.');
    must(await sb().from('ai_user_preferences').upsert({ user_id: uid, ...prefs }, { onConflict: 'user_id' }));
  },

  async deleteAiPreferences() {
    const uid = await currentUserId();
    if (!uid) return;
    must(await sb().from('ai_user_preferences').delete().eq('user_id', uid));
  },

  async getAdminAiStats(days = 30) {
    return must(await sb().rpc('ai_admin_stats', { p_days: days })) as AiAdminStats;
  },

  async getRestaurantAiStats(restaurantId, days = 30) {
    return must(await sb().rpc('restaurant_ai_stats', { p_restaurant: restaurantId, p_days: days })) as RestaurantAiStats;
  },

  // ─── Fase 7: recensioni ─────────────────────────────────────
  async getRestaurantRating(restaurantId) {
    return must(await sb().rpc('restaurant_rating', { p_restaurant: restaurantId })) as RestaurantRating;
  },

  async getRestaurantsRating(ids) {
    if (!ids.length) return {};
    const rows = must(await sb().rpc('restaurants_rating', { p_ids: ids.slice(0, 200) })) as { restaurant_id: string; average: number; review_count: number }[];
    return Object.fromEntries((rows ?? []).map((r) => [r.restaurant_id, { average: Number(r.average), count: Number(r.review_count) }]));
  },

  async listReviews(restaurantId, opts = {}) {
    return must(await sb().rpc('list_reviews', { p_restaurant: restaurantId, p_sort: opts.sort ?? 'recent', p_filter: opts.filter ?? null, p_limit: opts.limit ?? 10, p_offset: opts.offset ?? 0 })) as { total: number; items: ReviewItem[] };
  },

  async getReviewFormStatus(restaurantId) {
    if (!(await currentUserId())) return { authenticated: false };
    return must(await sb().rpc('my_review_status', { p_restaurant: restaurantId })) as ReviewFormStatus;
  },

  async submitReview(restaurantId, input) {
    return must(await sb().rpc('submit_review', { p_restaurant: restaurantId, p: input })) as { id: string; status: string; is_verified: boolean };
  },

  async updateReview(id, input) {
    return must(await sb().rpc('update_review', { p_id: id, p: input })) as { id: string; status: string };
  },

  async voteReview(id, on) {
    return must(await sb().rpc('vote_review', { p_id: id, p_on: on })) as number;
  },

  async reportReview(id, reason, details) {
    must(await sb().rpc('report_review', { p_id: id, p_reason: reason, p_details: details ?? null }));
  },

  async respondToReview(reviewId, content) {
    must(await sb().rpc('respond_to_review', { p_review: reviewId, p_content: content }));
  },

  async listManagedReviews(restaurantId, opts = {}) {
    return must(await sb().rpc('restaurant_reviews_manage', { p_restaurant: restaurantId, p_limit: opts.limit ?? 20, p_offset: opts.offset ?? 0 })) as { rating: RestaurantRating; items: ManagedReview[] };
  },

  async adminListReviews(status) {
    return (must(await sb().rpc('admin_list_reviews', { p_status: status ?? null, p_limit: 100, p_offset: 0 })) ?? []) as AdminReview[];
  },

  async moderateReview(id, action, note) {
    must(await sb().rpc('moderate_review', { p_id: id, p_action: action, p_note: note ?? null }));
  },

  // ─── Fase 7: AsiaPoints ─────────────────────────────────────
  async getLoyaltyWallet(opts = {}) {
    return must(await sb().rpc('my_loyalty', { p_limit: opts.limit ?? 20, p_offset: opts.offset ?? 0 })) as LoyaltyWallet;
  },

  async listRewards() {
    return must(await sb().from('rewards').select('*').order('points_cost')) as Reward[];
  },

  async redeemReward(rewardId) {
    return must(await sb().rpc('redeem_reward', { p_reward: rewardId })) as RedeemResult;
  },

  async getMyAchievements() {
    const uid = await currentUserId();
    const all = must(await sb().from('achievements').select('id,key,name,description,icon,points_bonus').eq('is_active', true)) as Omit<Achievement, 'earned_at'>[];
    const earned = uid ? (must(await sb().from('user_achievements').select('achievement_id, earned_at').eq('user_id', uid)) as { achievement_id: string; earned_at: string }[]) : [];
    return all.map((a) => ({ ...a, earned_at: earned.find((e) => e.achievement_id === a.id)?.earned_at ?? null }));
  },

  async adminLoyaltyAdjust(userId, points, reason) {
    return must(await sb().rpc('admin_loyalty_adjust', { p_user: userId, p_points: points, p_reason: reason })) as number;
  },

  async adminListRedemptions() {
    const rows = must(await sb().from('reward_redemptions').select('*, reward:rewards(title)').order('created_at', { ascending: false }).limit(200)) as (Row & { reward: { title: string } | null; user_id: string })[];
    return rows.map((r) => ({ ...r, reward_title: r.reward?.title ?? '', user_name: String(r.user_id).slice(0, 8) }));
  },

  async adminUpdateRedemption(id, status) {
    must(await sb().rpc('admin_update_redemption', { p_id: id, p_status: status }));
  },

  // ─── Fase 7: inviti ────────────────────────────────────────
  async getMyReferrals() {
    return must(await sb().rpc('my_referrals')) as ReferralSummary;
  },

  async applyReferralCode(code) {
    return must(await sb().rpc('apply_referral_code', { p_code: code })) as { status: string };
  },

  async createBusinessReferral(restaurantId, email, name) {
    return must(await sb().rpc('create_business_referral', { p_restaurant: restaurantId, p_email: email, p_name: name ?? null })) as { id: string; code: string };
  },

  async listBusinessReferrals(restaurantId) {
    let q = sb().from('business_referrals').select('*').order('created_at', { ascending: false }).limit(200);
    if (restaurantId) q = q.eq('referrer_restaurant_id', restaurantId);
    return must(await q) as BusinessReferral[];
  },

  async adminListReferrals(status) {
    return (must(await sb().rpc('admin_list_referrals', { p_status: status ?? null, p_limit: 200 })) ?? []) as AdminReferral[];
  },

  async adminReferralAction(id, action, reason) {
    must(await sb().rpc('admin_referral_action', { p_id: id, p_action: action, p_reason: reason ?? null }));
  },

  async adminBusinessReferralUpdate(id, patch) {
    must(await sb().rpc('admin_business_referral_update', { p_id: id, p_status: patch.status, p_reward_type: patch.reward_type ?? null, p_reward_value: patch.reward_value ?? null, p_referred_restaurant: null, p_note: patch.note ?? null }));
  },

  // ─── Fase 7: notifiche, push, follow ───────────────────────
  async listNotificationsPage({ limit, offset, unreadOnly }) {
    let q = sb().from('notifications').select('*').order('created_at', { ascending: false }).range(offset, offset + limit - 1);
    if (unreadOnly) q = q.is('read_at', null);
    const items = must(await q) as AppNotification[];
    const { count } = await sb().from('notifications').select('id', { count: 'exact', head: true }).is('read_at', null);
    return { items, unread: count ?? 0 };
  },

  async getNotificationPrefs() {
    const uid = await currentUserId();
    if (!uid) return DEFAULT_PREFS;
    const row = must(await sb().from('notification_preferences').select('*').eq('user_id', uid).maybeSingle()) as NotificationPrefs | null;
    return { ...DEFAULT_PREFS, ...(row ?? {}) };
  },

  async saveNotificationPrefs(patch) {
    const uid = await currentUserId();
    if (!uid) throw new Error('Accedi per gestire le notifiche.');
    const clean = Object.fromEntries(Object.entries(patch).filter(([k]) => k in DEFAULT_PREFS));
    const row = must(await sb().from('notification_preferences').upsert({ user_id: uid, ...clean }, { onConflict: 'user_id' }).select('*').single()) as NotificationPrefs;
    return { ...DEFAULT_PREFS, ...row };
  },

  async savePushSubscription(sub) {
    must(await sb().rpc('save_push_subscription', { p_endpoint: sub.endpoint, p_p256dh: sub.p256dh, p_auth: sub.auth, p_device: sub.device ?? null, p_platform: sub.platform ?? null }));
  },

  async removePushSubscription(endpoint) {
    must(await sb().rpc('remove_push_subscription', { p_endpoint: endpoint }));
  },

  async recordActivity() {
    await sb().rpc('record_activity').then(() => undefined, () => undefined);
  },

  async trackCampaignClick(deliveryId) {
    await sb().rpc('track_campaign_click', { p_delivery: deliveryId }).then(() => undefined, () => undefined);
  },

  async getFollowState(restaurantId) {
    const uid = await currentUserId();
    if (!uid) return { favorite: false, following: false };
    const row = must(await sb().from('favorites').select('notifications_enabled').eq('user_id', uid).eq('restaurant_id', restaurantId).maybeSingle()) as { notifications_enabled: boolean } | null;
    return { favorite: !!row, following: !!row?.notifications_enabled };
  },

  async setFollow(restaurantId, on) {
    return must(await sb().rpc('set_follow', { p_restaurant: restaurantId, p_on: on })) as boolean;
  },

  // ─── Fase 7: campagne ──────────────────────────────────────
  async campaignAudienceCount(scope, restaurantId, target, targeting) {
    return must(await sb().rpc('campaign_audience_count', { p_scope: scope, p_restaurant: restaurantId, p_target: target, p_targeting: targeting ?? {} })) as number;
  },

  async createCampaign(input) {
    return must(await sb().rpc('create_campaign', { p: input })) as { id: string; status: string; audience: number };
  },

  async cancelCampaign(id) {
    must(await sb().rpc('cancel_campaign', { p_id: id }));
  },

  async listCampaigns({ scope, restaurantId }) {
    let q = sb().from('campaigns').select('*').eq('scope', scope).order('created_at', { ascending: false }).limit(100);
    if (restaurantId) q = q.eq('restaurant_id', restaurantId);
    return must(await q) as Campaign[];
  },

  async getPushCampaignStats(id) {
    return must(await sb().rpc('push_campaign_stats', { p_id: id })) as PushCampaignStats;
  },

  // ─── Fase 7: statistiche ───────────────────────────────────
  async getRetentionStats(days = 30) {
    return must(await sb().rpc('admin_retention_stats', { p_days: days })) as RetentionStats;
  },

  async getRestaurantEngagementStats(restaurantId, days = 30) {
    return must(await sb().rpc('restaurant_engagement_stats', { p_restaurant: restaurantId, p_days: days })) as RestaurantEngagementStats;
  },

  async runEngagementTick() {
    return must(await sb().rpc('engagement_tick', {})) as EngagementTickResult;
  },

  // ─── Fase 8: ordini (prezzi e stati SOLO dal server) ───────
  async getOrderInfo(id) {
    return must(await sb().rpc('order_public_info', { p_restaurant: id })) as OrderPublicInfo;
  },
  async getOrderableRestaurants() {
    return (must(await sb().rpc('orderable_restaurants')) ?? []) as OrderableRestaurant[];
  },
  async getRestaurantsDeliveringTo(lat, lng) {
    return (must(await sb().rpc('restaurants_delivering_to', { p_lat: lat, p_lng: lng })) ?? []) as { restaurant_id: string; distance_km: number; delivery_fee: number }[];
  },
  async getMenuOptionGroups(id) {
    const rows = must(await sb().from('menu_option_groups').select('*, options:menu_options(*)').eq('restaurant_id', id).eq('is_active', true).order('display_order')) as MenuOptionGroup[];
    return rows.map((g) => ({ ...g, options: (g.options ?? []).filter((o) => o.is_available).sort((a, b) => a.display_order - b.display_order) }));
  },
  async getOrderSlots(id, date, type) {
    return (must(await sb().rpc('order_slots', { p_restaurant: id, p_date: date, p_type: type })) ?? []) as Slot[];
  },
  async quoteOrder(input) {
    return must(await sb().rpc('order_quote', { p: input })) as Quote;
  },
  async placeOrder(input) {
    try {
      const r = await ordersCall<{ order_id: string; order_number: string; access_token: string; client_secret: string | null; total: number; payment_mode: 'connect' | 'platform_test'; already_paid?: boolean }>(
        'create', { ...input, session_id: sessionId() });
      return { ok: true, order_id: r.order_id, order_number: r.order_number, access_token: r.access_token, client_secret: r.client_secret, total: r.total, payment_mode: r.payment_mode, simulated: false };
    } catch (e) {
      if (e instanceof OrdersApiError && Array.isArray(e.body?.errors)) return { ok: false, errors: e.body!.errors as OrderError[] };
      if (e instanceof OrdersApiError) return { ok: false, errors: [{ code: e.code, message: e.message }] };
      throw e;
    }
  },
  async resumeOrderPayment(id, token) {
    return ordersCall<{ client_secret: string | null }>('action', { action: 'resume_payment', order_id: id, access_token: token });
  },
  async demoPayOrder() {
    throw new Error('Pagamento simulato disponibile solo in modalità DEMO.');
  },
  async trackOrder(num, token) {
    return (must(await sb().rpc('order_track', { p_number: num, p_token: token })) ?? null) as OrderView | null;
  },
  async cancelOrderAsCustomer(num, token, reason) {
    const r = must(await sb().rpc('order_customer_cancel', { p_number: num, p_token: token, p_reason: reason ?? null })) as { refund_pending: boolean; order_id: string };
    // Rimborso e annullamento del pagamento eseguiti dal server (Stripe)
    await ordersCall('action', { action: 'after_change', order_id: r.order_id }).catch(() => undefined);
    return { refund_pending: !!r.refund_pending };
  },
  async reportOrderIssue(num, token, type, description) {
    must(await sb().rpc('order_issue_create', { p_number: num, p_token: token, p_type: type, p_description: description }));
  },
  async listMyOrders(limit = 20, offset = 0) {
    return must(await sb().rpc('my_orders', { p_limit: limit, p_offset: offset })) as { total: number; items: MyOrderSummary[] };
  },
  async listAddresses() {
    return must(await sb().from('customer_addresses').select('*').order('is_default', { ascending: false }).order('created_at', { ascending: false })) as CustomerAddress[];
  },
  async saveAddress(input) {
    const { data: u } = await sb().auth.getUser();
    if (!u.user) throw new Error('Accedi per salvare l’indirizzo.');
    const row = {
      user_id: u.user.id, label: input.label ?? null, recipient_name: input.recipient_name, phone: input.phone, address_line_1: input.address_line_1,
      address_line_2: input.address_line_2 ?? null, city: input.city, province: input.province ?? null, postal_code: input.postal_code, country: 'IT',
      latitude: input.latitude, longitude: input.longitude, geocode_source: input.geocode_source ?? null, delivery_notes: input.delivery_notes ?? null, is_default: !!input.is_default,
    };
    const q = input.id ? sb().from('customer_addresses').update(row).eq('id', input.id) : sb().from('customer_addresses').insert(row);
    return must(await q.select('*').single()) as CustomerAddress;
  },
  async deleteAddress(id) {
    must(await sb().from('customer_addresses').delete().eq('id', id));
  },
  async saveCart(payload) {
    await sb().rpc('cart_save', { p: payload ?? {} }).then(() => undefined, () => undefined);
  },
  async loadCart() {
    return (must(await sb().rpc('cart_load')) ?? null) as { restaurant_id: string; items: unknown[] } | null;
  },
  async listRestaurantOrders(id, tab) {
    return must(await sb().rpc('restaurant_orders', { p_restaurant: id, p_tab: tab, p_limit: 100 })) as RestaurantOrdersPage;
  },
  async orderAction(id, action, payload) {
    const r = must(await sb().rpc('order_action', { p_order: id, p_action: action, p: payload ?? {} })) as { status: string; refund_pending?: boolean };
    if (r.refund_pending || action === 'reject' || action === 'cancel') await ordersCall('action', { action: 'after_change', order_id: id }).catch(() => undefined);
    return r;
  },
  async refundOrder(id, amount, reason) {
    await ordersCall('action', { action: 'refund', order_id: id, amount, reason }, { auth: 'required' });
  },
  async setOrderPause(id, kind, minutes) {
    must(await sb().rpc('order_set_pause', { p_restaurant: id, p_kind: kind, p_minutes: minutes }));
  },
  async setMenuItemAvailability(id, mode) {
    must(await sb().rpc('set_menu_item_availability', { p_item: id, p_mode: mode }));
  },
  async getOrderSettings(id) {
    const settings = must(await sb().from('restaurant_order_settings').select('*').eq('restaurant_id', id).maybeSingle()) as RestaurantOrderSettings | null;
    const zones = must(await sb().from('delivery_zones').select('*').eq('restaurant_id', id).order('max_distance_km')) as DeliveryZone[];
    return { settings, zones };
  },
  async saveOrderSettings(id, patch) {
    const { id: _i, restaurant_id: _r, created_at: _c, updated_at: _u, ...rest } = patch;
    return must(await sb().from('restaurant_order_settings').upsert({ ...rest, restaurant_id: id }, { onConflict: 'restaurant_id' }).select('*').single()) as RestaurantOrderSettings;
  },
  async saveDeliveryZone(id, z) {
    const row = { restaurant_id: id, name: z.name, zone_type: 'distance', min_distance_km: z.min_distance_km ?? 0, max_distance_km: z.max_distance_km, delivery_fee: z.delivery_fee ?? 0,
      minimum_order: z.minimum_order ?? 0, estimated_delivery_minutes: z.estimated_delivery_minutes ?? 30, is_active: z.is_active ?? true };
    const q = z.id ? sb().from('delivery_zones').update(row).eq('id', z.id).eq('restaurant_id', id) : sb().from('delivery_zones').insert(row);
    return must(await q.select('*').single()) as DeliveryZone;
  },
  async deleteDeliveryZone(id, zoneId) {
    must(await sb().from('delivery_zones').delete().eq('id', zoneId).eq('restaurant_id', id));
  },
  async listAllOptionGroups(id) {
    return must(await sb().from('menu_option_groups').select('*, options:menu_options(*)').eq('restaurant_id', id).order('display_order')) as MenuOptionGroup[];
  },
  async saveOptionGroup(id, g) {
    const row = { menu_item_id: g.menu_item_id, restaurant_id: id, name: g.name, min_select: g.min_select ?? 0, max_select: g.max_select ?? 1,
      required: g.required ?? (g.min_select ?? 0) > 0, display_order: g.display_order ?? 0, is_active: g.is_active ?? true };
    const saved = must(await (g.id ? sb().from('menu_option_groups').update(row).eq('id', g.id) : sb().from('menu_option_groups').insert(row)).select('*').single()) as MenuOptionGroup;
    const keep = g.options.filter((o) => o.id).map((o) => o.id!);
    const del = sb().from('menu_options').delete().eq('option_group_id', saved.id);
    must(await (keep.length ? del.not('id', 'in', `(${keep.join(',')})`) : del));
    for (const [i, o] of g.options.entries()) {
      const r = { option_group_id: saved.id, restaurant_id: id, name: o.name, price: o.price, is_available: o.is_available ?? true, display_order: i };
      must(await (o.id ? sb().from('menu_options').update(r).eq('id', o.id) : sb().from('menu_options').insert(r)));
    }
    return { ...saved, options: [] };
  },
  async deleteOptionGroup(id, gid) {
    must(await sb().from('menu_option_groups').delete().eq('id', gid).eq('restaurant_id', id));
  },
  async getPayoutStatus(id) {
    try {
      const r = await ordersCall<{ environment: 'test' | 'live'; account: PayoutStatus['account'] }>('connect', { restaurant_id: id, action: 'status' }, { auth: 'required' });
      return { configured: true, environment: r.environment, account: r.account };
    } catch (e) {
      if (e instanceof OrdersApiError && (e.status === 503 || e.status === 404)) return { configured: false, environment: ORDERS.mode, account: null };
      throw e;
    }
  },
  async startPayoutOnboarding(id) {
    return ordersCall<{ url: string }>('connect', { restaurant_id: id, action: 'onboard' }, { auth: 'required' });
  },
  async refreshPayoutStatus(id) {
    const r = await ordersCall<{ environment: 'test' | 'live'; account: PayoutStatus['account'] }>('connect', { restaurant_id: id, action: 'refresh' }, { auth: 'required' });
    return { configured: true, environment: r.environment, account: r.account };
  },
  async openPayoutDashboard(id) {
    return ordersCall<{ url: string }>('connect', { restaurant_id: id, action: 'dashboard' }, { auth: 'required' });
  },
  async getRestaurantOrderStats(id, days = 30) {
    return must(await sb().rpc('restaurant_order_stats', { p_restaurant: id, p_days: days })) as RestaurantOrderStats;
  },
  async adminListOrders(f) {
    return must(await sb().rpc('admin_orders', { p: f })) as { total: number; items: AdminOrderRow[] };
  },
  async adminOrderDetail(id) {
    return must(await sb().rpc('admin_order_detail', { p_order: id })) as AdminOrderDetail;
  },
  async adminOrderUpdate(id, patch) {
    must(await sb().rpc('admin_order_update', { p_order: id, p: patch }));
  },
  async adminResyncPayment(id) {
    const r = await ordersCall<{ payment_intent_status?: string; note?: string; refunds?: number }>('action', { action: 'resync', order_id: id }, { auth: 'required' });
    return r.note ?? `Stato Stripe: ${r.payment_intent_status ?? '—'} · rimborsi trovati: ${r.refunds ?? 0}`;
  },
  async getMarketplaceStats(days = 30) {
    return must(await sb().rpc('marketplace_stats', { p_days: days })) as MarketplaceStats;
  },
  async getCommissionSettings() {
    const rows = must(await sb().from('platform_settings').select('key, value').in('key', ['platform_commission_percent', 'platform_commission_fixed', 'service_fee_enabled', 'service_fee_amount'])) as { key: string; value: unknown }[];
    const v = (k: string) => rows.find((r) => r.key === k)?.value;
    const overrides = must(await sb().from('restaurant_commission_settings').select('*, restaurant:restaurants(name)').order('effective_from', { ascending: false }).limit(200)) as (CommissionSettings['overrides'][number] & { restaurant: { name: string } | null })[];
    return {
      global_percent: Number(v('platform_commission_percent') ?? 10), global_fixed: Number(v('platform_commission_fixed') ?? 0),
      service_fee_enabled: v('service_fee_enabled') === true, service_fee_amount: Number(v('service_fee_amount') ?? 0.99),
      overrides: overrides.map((o) => ({ ...o, restaurant_name: o.restaurant?.name ?? '' })),
    };
  },
  async saveGlobalCommission(p) {
    for (const [key, value] of Object.entries({ platform_commission_percent: p.percent, platform_commission_fixed: p.fixed, service_fee_enabled: p.service_fee_enabled, service_fee_amount: p.service_fee_amount })) {
      must(await sb().from('platform_settings').upsert({ key, value }, { onConflict: 'key' }));
    }
  },
  async addCommissionOverride(p) {
    must(await sb().from('restaurant_commission_settings').insert({ restaurant_id: p.restaurant_id, percentage_fee: p.percentage_fee, fixed_fee: p.fixed_fee, note: p.note ?? null }));
  },
  async runOrdersTick() {
    return must(await sb().rpc('orders_tick', {})) as OrdersTickResult;
  },

  // ─── Fase 9: logistica Rider (stati, dispatch e privacy nelle funzioni del database) ───
  async riderApply(input) {
    return must(await sb().rpc('rider_apply', { p: input })) as { status: string };
  },
  async riderUploadDocument(type, file, expiresAt) {
    const uid = (await sb().auth.getUser()).data.user?.id;
    if (!uid) throw new Error('Accedi per continuare.');
    const up = await prepareUpload(file, 'document');
    const path = `${uid}/${up.name}`;
    const { error } = await sb().storage.from('rider-documents').upload(path, up.file, { upsert: false, contentType: up.mime });
    if (error) throw new Error('Caricamento non riuscito. Usa PDF, JPG, PNG o WEBP.');
    must(await sb().rpc('rider_document_add', { p_type: type, p_path: path, p_expires: expiresAt }));
  },
  async getRiderHome() {
    return must(await sb().rpc('rider_home')) as RiderHome;
  },
  async riderSetOnline(online, consent) {
    return must(await sb().rpc('rider_set_online', { p_online: online, p_accepting: online, p_location_consent: consent })) as { is_online: boolean };
  },
  async riderSendLocation(p) {
    return must(await sb().rpc('rider_location', { p })) as LocationResult;
  },
  async riderRespondOffer(id, accept, reason) {
    return must(await sb().rpc('rider_offer_respond', { p_assignment: id, p_accept: accept, p_reason: reason ?? null })) as { status: string; delivery_job_id?: string };
  },
  async getRiderJob(id) {
    return must(await sb().rpc('rider_job', { p_job: id })) as RiderJob;
  },
  async riderJobAction(id, action, payload) {
    return must(await sb().rpc('rider_job_action', { p_job: id, p_action: action, p: payload ?? {} })) as RiderJob | { id: string; status: string };
  },
  async riderUploadProof(jobId, file) {
    const uid = (await sb().auth.getUser()).data.user?.id;
    if (!uid) throw new Error('Accedi per continuare.');
    const up = await prepareUpload(file, 'proof');
    const path = `${uid}/${jobId}-${up.name}`;
    const { error } = await sb().storage.from('delivery-proofs').upload(path, up.file, { upsert: false, contentType: up.mime });
    if (error) throw new Error('Caricamento della foto non riuscito.');
    return path;
  },
  async getRiderEarnings() {
    return must(await sb().rpc('rider_earnings_summary')) as RiderEarningsSummary;
  },
  async refreshDeliveryEta(jobId) {
    const token = (await sb().auth.getSession()).data.session?.access_token;
    if (!token) return;
    // Facoltativo: se il backend non è configurato resta la stima del database
    await fetch('/api/logistics/action', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ action: 'eta_refresh', job_id: jobId }) }).catch(() => undefined);
  },
  async getOrderDelivery(num, token) {
    return must(await sb().rpc('order_delivery', { p_number: num, p_token: token })) as OrderDeliveryView | null;
  },
  async rateDelivery(num, rating, comment) {
    must(await sb().rpc('delivery_rate', { p_number: num, p_rating: rating, p_comment: comment ?? null }));
  },
  async getRestaurantDeliveries(id) {
    return must(await sb().rpc('restaurant_deliveries', { p_restaurant: id })) as RestaurantDelivery[];
  },
  async adminListRiders(f) {
    return must(await sb().rpc('admin_riders', { p: f ?? {} })) as AdminRiderRow[];
  },
  async adminRiderDetail(id) {
    return must(await sb().rpc('admin_rider_detail', { p_rider: id })) as AdminRiderDetail;
  },
  async adminRiderAction(id, action, reason) {
    must(await sb().rpc('admin_rider_action', { p_rider: id, p_action: action, p_reason: reason ?? null }));
  },
  async adminReviewRiderDocument(id, status, note) {
    must(await sb().rpc('admin_document_review', { p_doc: id, p_status: status, p_note: note ?? null }));
  },
  async adminRiderDocumentUrl(path) {
    const { data, error } = await sb().storage.from('rider-documents').createSignedUrl(path, 120);
    if (error) throw new Error('Documento non disponibile.');
    return data.signedUrl;
  },
  async getDispatchBoard() {
    return must(await sb().rpc('admin_dispatch_board')) as DispatchBoard;
  },
  async adminAssignDelivery(job, rider) {
    must(await sb().rpc('admin_assign_job', { p_job: job, p_rider: rider }));
  },
  async adminDeliveryAction(job, action, payload) {
    must(await sb().rpc('admin_job_action', { p_job: job, p_action: action, p: payload ?? {} }));
  },
  async adminDeliveryDetail(id) {
    return must(await sb().rpc('admin_job_detail', { p_job: id })) as AdminJobDetail;
  },
  async adminListEarnings() {
    const rows = must(await sb().from('rider_earnings').select('*, rider:rider_profiles(first_name, last_name), job:delivery_jobs(order:orders(order_number))')
      .order('created_at', { ascending: false }).limit(200)) as (RiderEarningItem & { rider_id: string; rider: { first_name: string; last_name: string } | null; job: { order: { order_number: string } | null } | null })[];
    return rows.map(({ rider, job, ...e }) => ({ ...e, rider_name: rider ? `${rider.first_name} ${rider.last_name}` : '—', order_number: job?.order?.order_number ?? null }));
  },
  async adminEarningAction(id, action, amount, note) {
    must(await sb().rpc('admin_earning_action', { p_earning: id, p_action: action, p_amount: amount ?? null, p_note: note ?? null }));
  },
  async adminEarningCreate(job, amount, note) {
    must(await sb().rpc('admin_earning_create', { p_job: job, p_amount: amount, p_note: note }));
  },
  async adminSetRestaurantLogistics(id, enabled) {
    must(await sb().rpc('admin_restaurant_logistics', { p_restaurant: id, p_enabled: enabled }));
  },
  async getLogisticsStats(days = 30) {
    return must(await sb().rpc('logistics_stats', { p_days: days })) as LogisticsStats;
  },
  async runLogisticsTick() {
    return must(await sb().rpc('logistics_tick', {})) as LogisticsTickResult;
  },
  async getLogisticsSettings() {
    const rows = must(await sb().from('platform_settings').select('key, value').like('key', 'logistics_%')) as { key: string; value: unknown }[];
    const out = { ...LOGISTICS_DEFAULTS } as Record<string, unknown>;
    for (const r of rows) {
      const k = r.key.replace(/^logistics_/, '');
      if (k in LOGISTICS_DEFAULTS) out[k] = r.value;
    }
    return out as unknown as LogisticsSettings;
  },
  async saveLogisticsSettings(patch) {
    const rows = Object.entries(patch).filter(([k]) => k in LOGISTICS_DEFAULTS).map(([k, v]) => ({ key: `logistics_${k}`, value: v }));
    if (rows.length) must(await sb().from('platform_settings').upsert(rows, { onConflict: 'key' }));
  },
  async listServiceZones() {
    return must(await sb().from('delivery_service_zones').select('*').order('name')) as ServiceZone[];
  },
  async saveServiceZone(z) {
    const row = { name: z.name, city_id: z.city_id ?? null, center_latitude: z.center_latitude, center_longitude: z.center_longitude, radius_km: z.radius_km, is_active: z.is_active ?? true };
    const q = z.id ? sb().from('delivery_service_zones').update(row).eq('id', z.id) : sb().from('delivery_service_zones').insert(row);
    return must(await q.select('*').single()) as ServiceZone;
  },
  async deleteServiceZone(id) {
    must(await sb().from('delivery_service_zones').delete().eq('id', id));
  },
  async listCompensationRules() {
    return must(await sb().from('rider_compensation_rules').select('*').order('effective_from', { ascending: false })) as CompensationRule[];
  },
  async saveCompensationRule(k) {
    const { id, ...row } = k;
    const q = id ? sb().from('rider_compensation_rules').update(row).eq('id', id) : sb().from('rider_compensation_rules').insert(row);
    return must(await q.select('*').single()) as CompensationRule;
  },
  async updateLogisticsAlert(id, status) {
    must(await sb().from('logistics_alerts').update({ status, resolved_at: status === 'resolved' ? new Date().toISOString() : null }).eq('id', id));
  },

  async getSetting(key) {
    const row = must(await sb().from('platform_settings').select('value').eq('key', key).maybeSingle()) as { value: unknown } | null;
    return (row?.value ?? null) as never;
  },

  async setSetting(key, value) {
    must(await sb().from('platform_settings').upsert({ key, value }, { onConflict: 'key' }));
  },

  async adminListRestaurants(q) {
    const { page = 1, pageSize = 20 } = q;
    let query = sb().from('restaurants').select(SUMMARY_SELECT, { count: 'exact' });
    if (q.q) {
      const s = escapeLike(q.q);
      query = query.or(`name.ilike.%${s}%,slug.ilike.%${s}%,address.ilike.%${s}%`);
    }
    if (q.cityId) query = query.eq('city_id', q.cityId);
    if (q.categoryId) {
      const links = must(await sb().from('restaurant_categories').select('restaurant_id').eq('category_id', q.categoryId)) as { restaurant_id: string }[];
      if (!links.length) return { rows: [], total: 0 };
      query = query.in('id', links.map((l) => l.restaurant_id));
    }
    if (q.verified) query = query.eq('is_verified', q.verified === 'yes');
    if (q.claimed) query = q.claimed === 'yes' ? query.not('owner_id', 'is', null) : query.is('owner_id', null);
    if (q.active) query = query.eq('is_active', q.active === 'yes');
    if (q.sponsored) query = query.eq('is_sponsored', q.sponsored === 'yes');
    if (q.demo) query = query.eq('is_demo', q.demo === 'yes');
    if (q.dataStatus) query = query.eq('data_status', q.dataStatus);
    if (q.plan) query = query.eq('subscription_plan', q.plan);
    if (q.closed === 'temporary') query = query.eq('is_temporarily_closed', true);
    if (q.closed === 'permanent') query = query.eq('is_permanently_closed', true);
    if (q.closed === 'open') query = query.eq('is_temporarily_closed', false).eq('is_permanently_closed', false);
    if (q.coords === 'missing') query = query.or('latitude.is.null,longitude.is.null');
    if (q.coords === 'present') query = query.not('latitude', 'is', null).not('longitude', 'is', null);
    const from = (page - 1) * pageSize;
    const order =
      q.sort === 'updated' ? query.order('updated_at', { ascending: false }) : q.sort === 'last_verified' ? query.order('last_verified_at', { ascending: true, nullsFirst: true }) : query.order('name');
    const res = await order.range(from, from + pageSize - 1);
    if (res.error) throw new Error(res.error.message);
    return { rows: (res.data as RawRow[]).map(toSummary), total: res.count ?? 0 };
  },

  async createRestaurant(input, categoryIds) {
    const city = (await getCities()).find((c) => c.id === input.city_id);
    const res = must(
      await sb().rpc('admin_import_restaurant', {
        p_restaurant_id: null,
        p_data: {
          name: input.name,
          slug: input.slug || `${slugify(input.name)}-${city?.slug ?? ''}`.replace(/-$/, ''),
          city_id: input.city_id,
          short_description: input.short_description ?? null,
          address: input.address ?? null,
          data_status: 'unverified',
          is_active: input.is_active ?? false,
        },
        p_category_slugs: (await getCategories()).filter((c) => categoryIds.includes(c.id)).sort((a, b) => categoryIds.indexOf(a.id) - categoryIds.indexOf(b.id)).map((c) => c.slug),
        p_replace_categories: false,
        p_source: { source_type: 'admin', source_name: 'Inserimento manuale Admin' },
        p_batch_id: null,
      }),
    ) as ImportResult;
    return must(await sb().from('restaurants').select('*').eq('id', res.id).single()) as Restaurant;
  },

  async duplicateRestaurant(id) {
    return must(await sb().rpc('admin_duplicate_restaurant', { p_restaurant_id: id })) as string;
  },

  async deleteRestaurant(id) {
    must(await sb().from('restaurants').delete().eq('id', id));
  },

  async listClaims(filter = {}) {
    let q = sb().from('restaurant_claims').select(`${CLAIM_SELECT}, claimant:profiles!restaurant_claims_user_id_fkey(id,full_name,email)`).order('submitted_at', { ascending: false });
    if (filter.status === 'open') q = q.in('status', ['pending', 'under_review', 'more_information_required']);
    else if (filter.status) q = q.eq('status', filter.status);
    if (filter.restaurantId) q = q.eq('restaurant_id', filter.restaurantId);
    return (must(await q.limit(500)) as RawClaim[]).map(toClaim);
  },

  async approveClaim(id, notes) {
    must(await sb().rpc('approve_claim', { p_claim_id: id, p_notes: notes ?? null }));
  },
  async rejectClaim(id, notes) {
    must(await sb().rpc('reject_claim', { p_claim_id: id, p_notes: notes ?? null }));
  },
  async requestClaimInfo(id, message) {
    must(await sb().rpc('request_claim_info', { p_claim_id: id, p_message: message }));
  },
  async setClaimUnderReview(id, notes) {
    must(await sb().rpc('set_claim_under_review', { p_claim_id: id, p_notes: notes ?? null }));
  },
  async transferOwnership(restaurantId, userId, notes) {
    must(await sb().rpc('admin_transfer_ownership', { p_restaurant_id: restaurantId, p_user_id: userId, p_notes: notes ?? null }));
  },
  async revokeOwnership(restaurantId, notes) {
    must(await sb().rpc('admin_revoke_ownership', { p_restaurant_id: restaurantId, p_notes: notes ?? null }));
  },
  async setMember(restaurantId, userId, role) {
    must(await sb().rpc('admin_set_member', { p_restaurant_id: restaurantId, p_user_id: userId, p_role: role }));
  },
  async removeMember(memberId) {
    must(await sb().rpc('admin_remove_member', { p_member_id: memberId }));
  },

  async listReports(filter = {}) {
    let q = sb().from('restaurant_reports').select('*, restaurant:restaurants(id,name,slug)').order('created_at', { ascending: false });
    if (filter.status === 'open_all') q = q.in('status', ['open', 'in_progress']);
    else if (filter.status) q = q.eq('status', filter.status);
    if (filter.restaurantId) q = q.eq('restaurant_id', filter.restaurantId);
    return must(await q.limit(500)) as ReportWithRestaurant[];
  },

  async updateReport(id, patch) {
    const done = patch.status === 'resolved' || patch.status === 'dismissed';
    must(
      await sb()
        .from('restaurant_reports')
        .update({ ...patch, ...(done ? { resolved_at: new Date().toISOString(), resolved_by: await currentUserId() } : {}) })
        .eq('id', id),
    );
  },

  async reviewChangeRequest(id, approve, notes) {
    must(await sb().rpc('review_change_request', { p_id: id, p_approve: approve, p_notes: notes ?? null }));
  },

  async listProfiles(q) {
    let query = sb().from('profiles').select('*').order('created_at', { ascending: false }).limit(500);
    if (q) {
      const s = escapeLike(q);
      query = query.or(`full_name.ilike.%${s}%,email.ilike.%${s}%`);
    }
    return must(await query) as Profile[];
  },

  async updateProfile(id, patch) {
    must(await sb().from('profiles').update(patch).eq('id', id));
  },

  // ─── Fase 11: piattaforma, privacy, supporto, monitoraggio ───
  async getRuntimeConfig() {
    return must(await sb().rpc('public_runtime_config')) as RuntimeConfig;
  },
  async recordConsent(choices, anonymousId, source) {
    const uid = await currentUserId();
    return must(await sb().rpc('consent_record', { p_choices: choices, p_anonymous_id: uid ? null : anonymousId, p_policy_version: null, p_source: source })) as ConsentState;
  },
  async getMyConsents() {
    return must(await sb().rpc('my_consents')) as ConsentState;
  },
  async exportMyData() {
    return must(await sb().rpc('privacy_export')) as DataExportResult;
  },
  async getPrivacyStatus() {
    return must(await sb().rpc('my_privacy_status')) as PrivacyStatus;
  },
  async requestAccountDeletion(password, reason) {
    const email = (await sb().auth.getSession()).data.session?.user.email;
    if (!email) throw new AppError('UNAUTHORIZED', 'Accedi per continuare.');
    // Ri-autenticazione: il nuovo token contiene l'orario del login (claim "amr"), verificato dal database
    const { error } = await sb().auth.signInWithPassword({ email, password });
    if (error) throw new AppError('REAUTH_REQUIRED', 'Password non corretta.');
    return must(await sb().rpc('request_account_deletion', { p_reason: reason ?? null })) as DeletionRequest;
  },
  async cancelAccountDeletion() {
    return must(await sb().rpc('cancel_account_deletion')) as boolean;
  },
  async createSupportTicket(input) {
    const uid = await currentUserId();
    const { turnstile_token, ...p } = input;
    if (uid) return must(await sb().rpc('support_ticket_create', { p, p_ip_hash: null })) as { reference: string };
    // Ospite: passa dal backend (Turnstile + rate limit per IP)
    let res: Response;
    try {
      res = await fetch('/api/support', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...p, turnstile_token }) });
    } catch {
      throw new AppError('OFFLINE', 'Connessione non disponibile. Riprova.');
    }
    const json = await res.json().catch(() => null);
    if (!res.ok) {
      const e = readApiError(json, res.status, 'Invio non riuscito. Riprova tra poco.');
      throw new AppError(e.code, e.message, e.requestId, res.status);
    }
    return json as { reference: string };
  },
  async getMySupportTickets() {
    return must(await sb().rpc('my_support_tickets')) as SupportTicket[];
  },
  reportClientError(e) {
    void sb().rpc('client_error_record', { p: e }).then(undefined, () => undefined);
  },
  recordWebVital(v) {
    void sb().rpc('web_vital_record', { p: v }).then(undefined, () => undefined);
  },
  async getSlugRedirect(slug) {
    return (must(await sb().rpc('restaurant_slug_redirect', { p_slug: slug })) as string | null) ?? null;
  },
  async redeemBetaInvite(token) {
    return must(await sb().rpc('beta_invite_redeem', { p_token: token })) as boolean;
  },
  recordAdminSession() {
    void sb().rpc('record_admin_session').then(undefined, () => undefined);
  },
  async getSystemStatus() {
    return must(await sb().rpc('admin_system_status')) as SystemStatus;
  },
  async adminSetFlag(flag, value) {
    must(await sb().rpc('admin_set_flag', { p_flag: flag, p_value: value }));
  },
  async getLaunchChecklist() {
    return must(await sb().rpc('admin_launch_checklist')) as LaunchChecklist;
  },
  async setLaunchCheck(key, status, notes) {
    must(await sb().rpc('admin_set_launch_check', { p_key: key, p_status: status, p_notes: notes ?? null }));
  },
  async adminSupportTickets(filter, limit = 50, offset = 0) {
    return must(await sb().rpc('admin_support_tickets', { p_filter: filter, p_limit: limit, p_offset: offset })) as { total: number; rows: AdminSupportTicket[] };
  },
  async adminSupportUpdate(id, patch) {
    must(await sb().rpc('admin_support_update', { p_id: id, p: patch }));
  },
  async adminPrivacyRequests() {
    return must(await sb().rpc('admin_privacy_requests')) as PrivacyRequests;
  },
  async adminDeletionAction(id, action) {
    must(await sb().rpc('admin_deletion_action', { p_id: id, p_action: action }));
  },
  async adminRetryJob(id) {
    must(await sb().rpc('admin_retry_job', { p_id: id }));
  },
  async adminAuditList(kind, limit = 50, offset = 0, action = null) {
    return must(await sb().rpc('admin_audit_list', { p_kind: kind, p_limit: limit, p_offset: offset, p_action: action })) as { total: number; rows: AuditRow[] };
  },
  async getConsistencyReport() {
    return must(await sb().rpc('db_consistency_report')) as ConsistencyReport;
  },
  async adminCreateBetaInvite(email, role, days) {
    return must(await sb().rpc('admin_beta_invite_create', { p_email: email, p_role: role, p_days: days })) as { id: string; token: string };
  },
  async adminCreateLegalVersion(type, version, url, isDraft) {
    must(await sb().rpc('admin_legal_version_create', { p_type: type, p_version: version, p_url: url, p_effective_at: null, p_is_draft: isDraft }));
  },

  // ─── Import ────────────────────────────────────────────────
  async getRestaurantsForMatching(cityIds) {
    if (!cityIds.length) return [];
    const rows = must(
      await sb().from('restaurants').select('*, restaurant_categories(category:categories(slug))').in('city_id', cityIds).limit(10000),
    ) as (Row & { restaurant_categories: { category: { slug: string } | null }[] })[];
    return rows.map(({ restaurant_categories, ...r }) => ({
      ...(r as unknown as ExistingRestaurant),
      category_slugs: restaurant_categories.map((x) => x.category?.slug).filter((s): s is string => !!s),
    }));
  },

  async importRestaurant(op, batchId) {
    return must(
      await sb().rpc('admin_import_restaurant', {
        p_restaurant_id: op.restaurantId,
        p_data: op.data,
        p_category_slugs: op.categorySlugs,
        p_replace_categories: op.replaceCategories,
        p_source: op.source,
        p_batch_id: batchId ?? null,
      }),
    ) as ImportResult;
  },

  async createImportBatch(batch) {
    return must(await sb().from('import_batches').insert(batch).select().single()) as ImportBatch;
  },

  async listImportBatches() {
    return must(await sb().from('import_batches').select('*').order('created_at', { ascending: false }).limit(20)) as ImportBatch[];
  },

  // ─── Fatturazione (Fase 5) ─────────────────────────────────
  async getBillingOverview(restaurantId) {
    return must(await sb().rpc('get_billing_overview', { p_restaurant: restaurantId })) as BillingOverview;
  },

  async getBillingAccount() {
    const uid = (await sb().auth.getUser()).data.user?.id;
    if (!uid) return null;
    return must(await sb().from('billing_accounts').select('*').eq('owner_user_id', uid).maybeSingle()) as BillingAccount | null;
  },

  async saveBillingAccount(input) {
    const uid = (await sb().auth.getUser()).data.user?.id;
    if (!uid) throw new Error('Accedi per continuare.');
    const existing = must(await sb().from('billing_accounts').select('id').eq('owner_user_id', uid).maybeSingle()) as { id: string } | null;
    if (existing) return must(await sb().from('billing_accounts').update(input).eq('id', existing.id).select().single()) as BillingAccount;
    return must(await sb().from('billing_accounts').insert({ ...input, owner_user_id: uid }).select().single()) as BillingAccount;
  },

  async startCheckout(input) {
    return billingCall<{ url: string; trial_days: number }>('checkout', { ...input, promotion_code: input.promotion_code || null });
  },
  async openBillingPortal(restaurantId, flow) {
    return billingCall<{ url: string }>('portal', { restaurant_id: restaurantId, flow: flow ?? null });
  },
  async confirmCheckout(sessionId) {
    return billingCall<CheckoutConfirmation>('actions', { action: 'confirm_checkout', session_id: sessionId });
  },
  async previewPlanChange(restaurantId, plan, interval) {
    return billingCall<ChangePreview>('actions', { action: 'preview_change', restaurant_id: restaurantId, plan, billing_interval: interval });
  },
  async changePlan(restaurantId, plan, interval) {
    return billingCall<{ status: 'updated' | 'scheduled'; effective_at: string | null }>('actions', { action: 'change_plan', restaurant_id: restaurantId, plan, billing_interval: interval });
  },
  async cancelSubscription(restaurantId) {
    return billingCall<{ until: string | null }>('actions', { action: 'cancel', restaurant_id: restaurantId });
  },
  async resumeSubscription(restaurantId) {
    await billingCall('actions', { action: 'resume', restaurant_id: restaurantId });
  },
  async cancelScheduledChange(restaurantId) {
    await billingCall('actions', { action: 'cancel_scheduled_change', restaurant_id: restaurantId });
  },
  async refreshInvoices(restaurantId) {
    await billingCall('actions', { action: 'refresh_invoices', restaurant_id: restaurantId });
  },

  async getProfileCompletion(restaurantId) {
    return must(await sb().rpc('restaurant_profile_completion', { p_restaurant: restaurantId })) as ProfileCompletion;
  },
  async completeOnboarding(restaurantId) {
    must(await sb().rpc('complete_onboarding', { p_restaurant: restaurantId }));
  },
  async requestPublication(restaurantId) {
    return must(await sb().rpc('request_publication', { p_restaurant: restaurantId })) as 'requested' | 'already_public' | 'already_requested';
  },

  async getSponsoredSlots(placement, ctx = {}) {
    const rows = must(
      await sb().rpc('sponsored_slots', { p_placement: placement, p_city_slug: ctx.citySlug ?? null, p_category_slug: ctx.categorySlug ?? null, p_limit: ctx.limit ?? 2 }),
    ) as { campaign_id: string; restaurant_id: string; placement: SponsoredPlacement }[];
    if (!rows.length) return [];
    const list = await supabaseSource.getRestaurantsByIds(rows.map((x) => x.restaurant_id));
    return rows
      .map((x) => ({ campaign_id: x.campaign_id, placement: x.placement, restaurant: list.find((r) => r.id === x.restaurant_id)! }))
      .filter((x) => !!x.restaurant);
  },

  trackSponsored(campaignId, type, placement) {
    void sb()
      .rpc('track_sponsored_event', { p_campaign_id: campaignId, p_type: type, p_placement: placement, p_session_id: analyticsSessionId() })
      .then(() => undefined, () => undefined);
  },

  async getCampaignStats(restaurantId, days = 30) {
    return must(await sb().rpc('campaign_stats', { p_restaurant: restaurantId, p_days: days })) as CampaignStats[];
  },

  async adminListSubscriptions(filter = {}) {
    let q = sb()
      .from('subscriptions')
      .select('*, restaurant:restaurants(id,name,slug,subscription_plan), owner:profiles!subscriptions_user_id_fkey(id,full_name,email)')
      .order('created_at', { ascending: false })
      .limit(300);
    if (filter.plan) q = q.eq('plan_code', filter.plan);
    if (filter.source) q = q.eq('source', filter.source);
    if (filter.status) q = q.eq('status', filter.status);
    if (filter.view === 'trial') q = q.eq('status', 'trialing');
    if (filter.view === 'past_due') q = q.in('status', ['past_due', 'unpaid']);
    if (filter.view === 'active') q = q.in('status', ['active', 'trialing', 'past_due']);
    if (filter.view === 'expired') q = q.or(`status.in.(canceled,incomplete_expired),revoked_at.not.is.null,expires_at.lt.${new Date().toISOString()}`);
    let rows = must(await q) as AdminSubscriptionRow[];
    if (filter.q) {
      const n = filter.q.toLowerCase();
      rows = rows.filter((x) => `${x.restaurant?.name ?? ''} ${x.owner?.email ?? ''} ${x.stripe_subscription_id ?? ''} ${x.stripe_customer_id ?? ''}`.toLowerCase().includes(n));
    }
    const ids = rows.map((x) => x.id);
    if (ids.length) {
      const inv = must(
        await sb().from('billing_invoices').select('subscription_id,number,status,amount_paid_cents,amount_due_cents,hosted_invoice_url,stripe_created_at').in('subscription_id', ids).order('stripe_created_at', { ascending: false }),
      ) as (AdminSubscriptionRow['last_invoice'] & { subscription_id: string })[];
      rows.forEach((x) => (x.last_invoice = inv.find((i) => i!.subscription_id === x.id) ?? null));
    }
    return rows;
  },
  async adminGrantPlan(restaurantId, plan, expiresAt, source, note) {
    must(await sb().rpc('admin_grant_plan', { p_restaurant: restaurantId, p_plan: plan, p_expires_at: expiresAt, p_source: source, p_note: note ?? null }));
  },
  async adminRevokePlan(subscriptionId) {
    must(await sb().rpc('admin_revoke_plan', { p_subscription: subscriptionId }));
  },
  async adminExtendManualPlan(subscriptionId, expiresAt) {
    must(await sb().rpc('admin_extend_manual_plan', { p_subscription: subscriptionId, p_expires_at: expiresAt }));
  },
  async adminBilling<T>(action: string, payload: Row = {}) {
    return billingCall<T>('admin', { ...payload, action });
  },
  async getRevenueStats() {
    return must(await sb().rpc('admin_revenue_stats')) as RevenueStats;
  },
  async listStripeEvents(limit = 50) {
    return must(await sb().from('stripe_events').select('*').order('created_at', { ascending: false }).limit(limit)) as StripeEventLog[];
  },
};
import type {
  AdminJobDetail, AdminRiderDetail, AdminRiderRow, CompensationRule, DispatchBoard, LocationResult, LogisticsSettings, LogisticsStats, LogisticsTickResult,
  OrderDeliveryView, RestaurantDelivery, RiderEarningItem, RiderEarningsSummary, RiderHome, RiderJob, ServiceZone,
} from '@/types/logistics';
import { LOGISTICS_DEFAULTS } from '@/types/logistics';
import { prepareUpload } from '@/lib/uploads';
import { AppError, fromDbMessage, readApiError } from '@/lib/errors';
import type {
  AdminSupportTicket, AuditRow, ConsentState, ConsistencyReport, DataExportResult, DeletionRequest, LaunchChecklist, PrivacyRequests, PrivacyStatus,
  RuntimeConfig, SupportTicket, SystemStatus,
} from '@/types/platform';
import { hasConsent } from '@/lib/consent';
