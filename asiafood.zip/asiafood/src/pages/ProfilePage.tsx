import { FoundingFoodieBadge } from '@/components/launch/CommunityCard';
import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Heart, LayoutDashboard, LogOut, Shield, Store } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useFavorites } from '@/context/FavoritesContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { formatDate } from '@/lib/format';
import { api } from '@/services';
import { Badge, ClaimStatusBadge } from '@/components/ui/Badge';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Field, Input, Select } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { LoyaltyTeaser } from '@/pages/EngagementPages';
import { AiPreferencesSection } from '@/components/ai/AiPreferencesSection';

const ROLE_LABEL = { customer: 'Cliente', restaurant_owner: 'Ristoratore', admin: 'Amministratore', rider: 'Rider AsiaFood' } as const;

export default function ProfilePage() {
  const { user, profile, loading, isAdmin, isOwner, signOut, refreshProfile } = useAuth();
  const { ids } = useFavorites();
  const { cities } = useReferenceData();
  const navigate = useNavigate();
  const toast = useToast();
  const [form, setForm] = useState({ full_name: '', display_name: '', phone: '', city_id: '' });
  const [saving, setSaving] = useState(false);
  const claims = useAsync(() => (user ? api.getMyClaims(user.id) : Promise.resolve([])), [user?.id]);
  useSeo({ title: 'Il mio profilo', path: '/profilo', noindex: true });

  useEffect(() => {
    if (profile) setForm({ full_name: profile.full_name ?? '', display_name: profile.display_name ?? '', phone: profile.phone ?? '', city_id: profile.city_id ?? '' });
  }, [profile]);

  if (loading) return <PageLoader />;
  if (!user) {
    return (
      <div className="container-app py-12">
        <EmptyState
          icon="👋"
          title="Accedi al tuo profilo"
          text="Salva i preferiti, ricevi offerte e, se hai un locale, gestiscilo da qui."
          action={
            <div className="flex gap-3">
              <ButtonLink to="/accedi?next=/profilo">Accedi</ButtonLink>
              <ButtonLink to="/registrati" variant="outline">
                Registrati
              </ButtonLink>
            </div>
          }
        />
      </div>
    );
  }

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.updateMyProfile(user.id, { full_name: form.full_name, display_name: form.display_name.trim() || null, phone: form.phone || null, city_id: form.city_id || null });
      await refreshProfile();
      toast('Profilo aggiornato');
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="container-app max-w-3xl pb-16 pt-8">
      <div className="flex items-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-ink font-display text-2xl font-bold text-white">
          {(profile?.full_name || user.email || '?').slice(0, 1).toUpperCase()}
        </div>
        <div>
          <h1 className="text-2xl font-extrabold sm:text-3xl">{profile?.full_name || 'Il mio profilo'}</h1>
          <p className="text-ink-muted">
            {user.email} · <Badge>{profile ? ROLE_LABEL[profile.role] : '—'}</Badge>
          </p>
          <FoundingFoodieBadge />
        </div>
      </div>

      <div className="mt-8 grid gap-3 sm:grid-cols-3">
        <QuickLink to="/preferiti" icon={<Heart className="h-5 w-5 text-coral" />} title="Preferiti" text={`${ids.size} locali salvati`} />
        {(isOwner || (claims.data?.length ?? 0) > 0) && (
          <QuickLink to="/dashboard" icon={<LayoutDashboard className="h-5 w-5 text-coral" />} title="La mia area" text={isOwner ? 'Gestisci i tuoi locali' : 'Segui le tue richieste'} />
        )}
        {isAdmin && <QuickLink to="/admin" icon={<Shield className="h-5 w-5 text-coral" />} title="Admin" text="Pannello di controllo" />}
        {!isOwner && <QuickLink to="/per-ristoratori" icon={<Store className="h-5 w-5 text-coral" />} title="Hai un locale?" text="Rivendicalo gratis" />}
      </div>

      <section className="card mt-8 p-6">
        <h2 className="text-lg font-bold">Dati personali</h2>
        <form onSubmit={save} className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="Nome e cognome" className="sm:col-span-2">
            <Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
          </Field>
          <Field label="Nome pubblico (recensioni)" hint="Visibile sulle tue recensioni. Se vuoto mostriamo nome e iniziale del cognome. Niente email o numeri di telefono." className="sm:col-span-2">
            <Input value={form.display_name} maxLength={40} placeholder="Es. Giulia R." onChange={(e) => setForm({ ...form, display_name: e.target.value })} />
          </Field>
          <Field label="Telefono">
            <Input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
          <Field label="Il tuo comune">
            <Select value={form.city_id} onChange={(e) => setForm({ ...form, city_id: e.target.value })}>
              <option value="">—</option>
              {cities.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </Field>
          <div className="sm:col-span-2">
            <Button type="submit" loading={saving}>
              Salva modifiche
            </Button>
          </div>
        </form>
      </section>

      <div className="mt-6">
        <LoyaltyTeaser />
      </div>

      <AiPreferencesSection />

      {(claims.data?.length ?? 0) > 0 && (
        <section className="card mt-6 p-6">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-lg font-bold">Le mie richieste di rivendicazione</h2>
            <Link to="/dashboard/claims" className="text-sm font-semibold text-coral-700 hover:underline">Dettagli e messaggi</Link>
          </div>
          <ul className="mt-4 divide-y divide-line">
            {claims.data!.map((c) => (
              <li key={c.id} className="flex items-center justify-between gap-3 py-3">
                <div>
                  <Link to={`/ristorante/${c.restaurant?.slug}`} className="font-semibold hover:text-coral-700">
                    {c.restaurant?.name ?? 'Locale'}
                  </Link>
                  <p className="text-xs text-ink-muted">Inviata il {formatDate(c.submitted_at)}</p>
                </div>
                <ClaimStatusBadge status={c.status} />
              </li>
            ))}
          </ul>
        </section>
      )}

      <Button
        variant="ghost"
        className="mt-8"
        icon={<LogOut className="h-4 w-4" />}
        onClick={async () => {
          await signOut();
          navigate('/');
        }}
      >
        Esci
      </Button>
    </div>
  );
}

function QuickLink({ to, icon, title, text }: { to: string; icon: React.ReactNode; title: string; text: string }) {
  return (
    <Link to={to} className="flex items-center gap-3 rounded-3xl border border-line bg-white p-4 transition hover:shadow-card">
      <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-coral-50">{icon}</span>
      <span>
        <span className="block font-semibold">{title}</span>
        <span className="text-sm text-ink-muted">{text}</span>
      </span>
    </Link>
  );
}
