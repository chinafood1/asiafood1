// ─────────────────────────────────────────────────────────────
//  Fase 12 · /press (press kit) e /app (installazione PWA).
//  Nessun dato societario inventato: i campi mancanti restano segnaposto "[da completare]".
//  Nessuna menzione di App Store / Google Play finché l'app non è pubblicata.
// ─────────────────────────────────────────────────────────────
import { Download, Mail } from 'lucide-react';
import { InstallPrompt, useInstallState } from '@/components/launch/InstallPrompt';
import { ButtonLink } from '@/components/ui/Button';
import { APP } from '@/config/app';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';

const PLACEHOLDER = '[da completare]';

export function PressPage() {
  useSeo({ title: 'Press kit', description: `Informazioni per la stampa su ${APP.name}: descrizione, logo e contatti.`, path: '/press' });
  const { setting } = useRuntimeConfig();
  const land = useAsync(() => api.launch.marketLanding('taranto'), []);
  const company = setting<string | null>('legal_company_name', null);
  const contact = setting<string | null>('legal_email', null) ?? setting<string | null>('support_email', null);
  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6" data-testid="press-page">
      <h1 className="font-display text-3xl font-extrabold">Press kit</h1>
      <p className="mt-2 text-ink-muted">Materiali per giornalisti, blog e creator.</p>
      <section className="mt-8 space-y-3">
        <h2 className="text-xl font-bold">Cos’è {APP.name}</h2>
        <p>{APP.name} è una piattaforma dedicata esclusivamente alla cucina asiatica, lanciata a Taranto e provincia: aiuta a scoprire i ristoranti, consultare menu, orari e offerte, prenotare e ritrovare i propri locali preferiti. I ristoratori possono rivendicare gratuitamente la propria scheda e gestirla in autonomia.</p>
        {land.data && land.data.total > 0 && <p className="text-sm text-ink-muted">Oggi sulla piattaforma: {land.data.total} locali in {land.data.cities.length} comuni della provincia (dato aggiornato in tempo reale).</p>}
      </section>
      <section className="mt-8">
        <h2 className="text-xl font-bold">Logo</h2>
        <div className="mt-3 flex flex-wrap items-center gap-4">
          <img src="/icons/icon-512.png" alt={`Logo ${APP.name}`} width={96} height={96} className="rounded-2xl border border-line" />
          <a className="inline-flex items-center gap-2 font-semibold text-coral-700" href="/icons/icon-512.png" download><Download className="h-4 w-4" /> PNG 512 px</a>
          <a className="inline-flex items-center gap-2 font-semibold text-coral-700" href="/favicon.svg" download><Download className="h-4 w-4" /> SVG</a>
        </div>
      </section>
      <section className="mt-8">
        <h2 className="text-xl font-bold">Screenshot</h2>
        <p className="mt-1 text-sm text-ink-muted">{PLACEHOLDER}: da aggiungere con dati reali al lancio pubblico (mai schermate con dati personali).</p>
      </section>
      <section className="mt-8 grid gap-4 sm:grid-cols-2">
        <div className="rounded-3xl border border-line p-5"><h2 className="font-bold">Società e fondatori</h2><p className="mt-1 text-sm">{company ?? PLACEHOLDER}</p><p className="text-sm text-ink-muted">Fondatore/i: {PLACEHOLDER}</p></div>
        <div className="rounded-3xl border border-line p-5"><h2 className="font-bold">Contatti stampa</h2>
          <p className="mt-1 text-sm">{contact ? <a className="inline-flex items-center gap-1 font-semibold text-coral-700" href={`mailto:${contact}`}><Mail className="h-4 w-4" /> {contact}</a> : PLACEHOLDER}</p></div>
      </section>
    </div>
  );
}

export function AppInstallPage() {
  useSeo({ title: 'Installa l’app', description: `Aggiungi ${APP.name} alla schermata Home: si apre come un’app, senza passare dagli store.`, path: '/app' });
  const can = useInstallState();
  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6" data-testid="app-page">
      <h1 className="font-display text-3xl font-extrabold">{APP.name} sul tuo telefono</h1>
      <p className="mt-2 text-ink-muted">{APP.name} è una web app installabile: la aggiungi alla schermata Home e si apre come un’app, anche con connessione lenta. Non serve scaricarla da uno store.</p>
      <div className="mt-6"><InstallPrompt /></div>
      {!can && <p className="mt-6 text-sm text-ink-muted" data-testid="app-not-supported">Su questo browser l’installazione non è disponibile o l’app è già installata. Puoi usare {APP.name} direttamente dal browser.</p>}
      <ButtonLink to="/taranto" className="mt-8">Scopri i ristoranti di Taranto</ButtonLink>
    </div>
  );
}
