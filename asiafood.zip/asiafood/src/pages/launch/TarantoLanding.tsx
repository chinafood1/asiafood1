// ─────────────────────────────────────────────────────────────
//  Fase 12 · Landing di lancio /taranto (SEO locale + conversione).
//  Contenuti SOLO dai dati: categorie, comuni e pagine categoria×città compaiono se hanno locali;
//  sotto la soglia minima la pagina non è indicizzata (niente pagine vuote).
// ─────────────────────────────────────────────────────────────
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Gift, MapPinned, Search, Sparkles, Tag, UserPlus } from 'lucide-react';
import { InstallPrompt } from '@/components/launch/InstallPrompt';
import { ButtonLink } from '@/components/ui/Button';
import { PageLoader } from '@/components/ui/Layout';
import { APP } from '@/config/app';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { useAsync } from '@/hooks/useAsync';
import { useExperiment } from '@/lib/experiments';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';

const FOCUS = ['sushi', 'giapponese', 'cinese', 'poke', 'ramen', 'all-you-can-eat'];

export default function TarantoLanding() {
  const d = useAsync(() => api.launch.marketLanding('taranto'), []);
  const { setting } = useRuntimeConfig();
  const heroCta = useExperiment('hero_cta');
  const data = d.data;
  const min = data?.min_per_page ?? 2;
  const thin = !data || data.total < Math.max(min, 3);
  useSeo({
    title: 'Cucina asiatica a Taranto: sushi, giapponese, cinese, poke e ramen',
    description: data?.total
      ? `${data.total} ristoranti asiatici a Taranto e provincia su ${APP.name}: sushi, All You Can Eat, poke, ramen, cucina cinese e giapponese. Menu, orari, offerte e mappa.`
      : `La cucina asiatica di Taranto e provincia, tutta in un posto: sushi, poke, ramen e All You Can Eat su ${APP.name}.`,
    path: '/taranto',
    noindex: thin,
    jsonLd: data && !thin ? {
      '@context': 'https://schema.org', '@type': 'CollectionPage', name: 'Cucina asiatica a Taranto e provincia', url: `${APP.siteUrl}/taranto`,
      about: { '@type': 'Place', name: 'Taranto', address: { '@type': 'PostalAddress', addressLocality: 'Taranto', addressRegion: 'TA', addressCountry: 'IT' } },
      numberOfItems: data.total,
    } : undefined,
  });
  useEffect(() => api.trackAppEvent('landing_view', { source: 'taranto' }), []);
  if (d.loading && !data) return <PageLoader />;
  const pair = (cat: string, city: string) => data?.category_city.some((x) => x.category === cat && x.city === city);
  const sushiTa = pair('sushi', 'taranto');
  const cats = (data?.categories ?? []).filter((c) => c.count > 0);
  const focus = [...cats.filter((c) => FOCUS.includes(c.slug)), ...cats.filter((c) => !FOCUS.includes(c.slug))];
  return (
    <div data-testid="taranto-landing">
      <section className="bg-ink text-white">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-coral-400">{APP.name} · Taranto e provincia</p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-extrabold leading-tight sm:text-6xl">La cucina asiatica di Taranto, tutta in un posto.</h1>
          <p className="mt-4 max-w-2xl text-lg text-white/75">Scopri, confronta e prenota: sushi, All You Can Eat, poke, ramen, cucina cinese e giapponese{data?.total ? ` — ${data.total} locali in ${data.cities.length} ${data.cities.length === 1 ? 'comune' : 'comuni'}` : ''}.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonLink to="/restaurants?city=taranto" size="lg" data-testid="landing-cta-explore">{heroCta === 'variant_b' ? 'Esplora i ristoranti di Taranto' : 'Scopri i ristoranti'}</ButtonLink>
            <ButtonLink to={sushiTa ? '/map?category=sushi&near=1' : '/map?near=1'} size="lg" variant="outline" className="border-white/30 bg-transparent text-white hover:border-white" data-testid="landing-cta-sushi">
              Trova sushi vicino a te
            </ButtonLink>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-6xl space-y-12 px-4 py-12 sm:px-6">
        {focus.length > 0 && (
          <section aria-labelledby="cat-title">
            <h2 id="cat-title" className="font-display text-2xl font-extrabold">Cosa ti va oggi?</h2>
            <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6" data-testid="landing-categories">
              {focus.map((c) => (
                <li key={c.slug}>
                  <Link to={pair(c.slug, 'taranto') ? `/${c.slug}/taranto` : `/${c.slug}`} className="flex h-full flex-col rounded-3xl border border-line bg-white p-4 hover:shadow-card">
                    <span className="text-2xl" aria-hidden>{c.emoji}</span>
                    <span className="mt-2 font-bold">{c.name}</span>
                    <span className="text-sm text-ink-muted">{c.count} {c.count === 1 ? 'locale' : 'locali'}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="grid gap-4 md:grid-cols-3" aria-label="Cosa puoi fare">
          {[
            { icon: Search, title: 'Scopri e confronta', text: 'Menu, orari, prezzi e servizi dei locali asiatici, con filtri per AYCE, asporto e consegna.', to: '/restaurants?city=taranto' },
            { icon: MapPinned, title: 'Mappa', text: 'Trova i locali vicino a te o in un altro comune della provincia. La tua posizione non viene salvata.', to: '/map' },
            { icon: Tag, title: 'Offerte e coupon', text: data?.with_offers ? `${data.with_offers} locali con offerte attive, con condizioni decise dal ristorante.` : 'Le offerte dei locali, con condizioni sempre chiare.', to: '/offers' },
          ].map((x) => (
            <Link key={x.title} to={x.to} className="rounded-3xl border border-line bg-white p-5 hover:shadow-card">
              <x.icon className="h-6 w-6 text-coral" aria-hidden />
              <p className="mt-3 font-bold">{x.title}</p>
              <p className="mt-1 text-sm text-ink-muted">{x.text}</p>
            </Link>
          ))}
        </section>

        {(data?.ayce ?? 0) > 0 && (
          <section className="rounded-3xl bg-cream p-6 sm:p-8">
            <h2 className="font-display text-2xl font-extrabold">All You Can Eat a Taranto e provincia</h2>
            <p className="mt-2 text-ink-soft">{data!.ayce} {data!.ayce === 1 ? 'locale propone' : 'locali propongono'} la formula All You Can Eat: prezzi di pranzo e cena sulle schede, quando indicati dal ristorante.</p>
            <Link to={pair('all-you-can-eat', 'taranto') ? '/all-you-can-eat/taranto' : '/all-you-can-eat'} className="mt-3 inline-flex items-center gap-1 font-semibold text-coral-700">Vedi i locali AYCE <ArrowRight className="h-4 w-4" /></Link>
          </section>
        )}

        {(data?.cities.length ?? 0) > 0 && (
          <section aria-labelledby="cities-title">
            <h2 id="cities-title" className="font-display text-2xl font-extrabold">Città e provincia</h2>
            <ul className="mt-4 flex flex-wrap gap-2" data-testid="landing-cities">
              {data!.cities.map((c) => (
                <li key={c.slug}><Link to={`/ristoranti/${c.slug}`} className="inline-flex rounded-full border border-line bg-white px-4 py-2 text-sm font-semibold hover:border-ink">{c.name} <span className="ml-1 font-normal text-ink-muted">{c.count}</span></Link></li>
              ))}
            </ul>
            {data!.category_city.length > 0 && (
              <p className="mt-4 text-sm text-ink-muted">Ricerche frequenti: {data!.category_city.slice(0, 12).map((x, i) => (
                <span key={`${x.category}-${x.city}`}>{i > 0 && ' · '}<Link to={`/${x.category}/${x.city}`} className="text-ink hover:underline">{x.category.replace(/-/g, ' ')} {x.city_name}</Link></span>
              ))}</p>
            )}
          </section>
        )}

        <section className="grid gap-4 md:grid-cols-3">
          {setting<boolean>('referral_enabled', true) !== false && (
            <Link to="/profile/referrals" className="rounded-3xl border border-line bg-white p-5 hover:shadow-card">
              <UserPlus className="h-6 w-6 text-coral" aria-hidden /><p className="mt-3 font-bold">Invita un amico su {APP.name}</p>
              <p className="mt-1 text-sm text-ink-muted">Guadagnate AsiaPoints secondo il regolamento del programma.</p>
            </Link>
          )}
          {setting<boolean>('ai_enabled', true) !== false && (
            <Link to="/assistant" className="rounded-3xl border border-line bg-white p-5 hover:shadow-card">
              <Sparkles className="h-6 w-6 text-coral" aria-hidden /><p className="mt-3 font-bold">Chiedi all’assistente</p>
              <p className="mt-1 text-sm text-ink-muted">“Sushi per 4 stasera a Taranto?” Risponde solo con i locali presenti.</p>
            </Link>
          )}
          <Link to="/per-ristoratori" className="rounded-3xl border border-line bg-white p-5 hover:shadow-card">
            <Gift className="h-6 w-6 text-coral" aria-hidden /><p className="mt-3 font-bold">Hai un ristorante asiatico?</p>
            <p className="mt-1 text-sm text-ink-muted">Rivendica gratis la scheda e gestisci menu, orari e offerte.</p>
          </Link>
        </section>

        <InstallPrompt />
        {thin && <p className="text-sm text-ink-muted" data-testid="landing-thin">Stiamo aggiungendo i locali di Taranto e provincia: torna presto.</p>}
      </div>
    </div>
  );
}
