import { useState } from 'react';
import { Check, HelpCircle, Search } from 'lucide-react';
import { APP, BILLING } from '@/config/app';
import { useAuth } from '@/context/AuthContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { PLAN_HIGHLIGHTS, planPrice, yearlySaving } from '@/lib/billing';
import { cn, formatPrice } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import type { BillingInterval } from '@/types/domain';
import { Badge } from '@/components/ui/Badge';
import { ButtonLink } from '@/components/ui/Button';
import { PageLoader } from '@/components/ui/Layout';
import { IntervalToggle, PlanComparisonTable } from '@/components/billing/BillingUI';

const FAQ: [string, string][] = [
  ['Come funziona la prova gratuita?', 'Sui piani Business, Premium e Top puoi provare le funzioni gratuitamente per il periodo indicato. Una sola prova per attività. Se non aggiungi un metodo di pagamento, alla fine della prova il locale torna al piano Free senza addebiti.'],
  ['Posso cambiare piano o cancellare?', 'Sì, in qualsiasi momento dalla pagina Fatturazione. L’upgrade è immediato (paghi solo la differenza per i giorni restanti); il downgrade e la cancellazione valgono dal rinnovo successivo, senza perdere le funzioni già pagate.'],
  ['I prezzi includono l’IVA?', 'I prezzi sono IVA esclusa. L’imposta viene calcolata al pagamento in base ai dati di fatturazione.'],
  ['Riceverò le fatture?', 'Sì: le fatture sono generate da Stripe e scaricabili in PDF dalla dashboard. Puoi indicare ragione sociale, Partita IVA, PEC e codice destinatario.'],
  ['La scheda Free resta visibile?', 'Sì. Una scheda Free può essere pubblica e comparire nella ricerca e sulla mappa. I piani a pagamento aggiungono funzioni, non comprano posizioni nascoste.'],
  ['Cosa sono le sponsorizzazioni?', 'Spazi dedicati e sempre etichettati come “Sponsorizzato”, separati dai risultati organici. Non sostituiscono la pertinenza della ricerca.'],
];

/** /business/pricing — pagina prezzi pubblica (prezzi e funzioni letti dal database). */
export default function PricingPage() {
  const { plans, ready } = useReferenceData();
  const { user, isOwner } = useAuth();
  const [interval, setInterval] = useState<BillingInterval>('month');
  const trialDays = useAsync(() => api.getSetting<number>('billing_trial_days'), []);
  useSeo({
    title: `Prezzi per ristoratori — ${APP.name}`,
    description: 'Piani Free, Business, Premium e Top per ristoranti asiatici: menu digitale, prenotazioni, coupon, statistiche e visibilità. Prova gratuita, nessun vincolo.',
    path: '/business/pricing',
  });
  if (!ready && !plans.length) return <PageLoader />;
  const active = plans.filter((p) => p.is_active).sort((a, b) => a.sort_order - b.sort_order);
  const trial = typeof trialDays.data === 'number' ? trialDays.data : 30;
  const ctaFor = (code: string, name: string) => {
    if (code === 'free') return { to: '/restaurants', label: 'Trova e rivendica il tuo locale' };
    if (user && isOwner) {
      return { to: `/dashboard/plans?plan=${code}&interval=${interval}`, label: trial && BILLING.enabled ? `Prova ${name} gratis` : `Scegli ${name}` };
    }
    return { to: user ? '/restaurants' : `/registrati?next=${encodeURIComponent('/restaurants')}`, label: 'Inizia: rivendica il tuo locale' };
  };

  return (
    <div className="pb-16">
      <section className="container-app pt-10 text-center sm:pt-14">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-coral">Per i ristoratori</p>
        <h1 className="mx-auto mt-3 max-w-3xl text-balance text-4xl font-extrabold leading-tight sm:text-5xl">Prezzi semplici, senza vincoli</h1>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-ink-muted">
          La scheda base è gratuita. Aggiungi menu, prenotazioni, coupon e statistiche quando ti servono{trial && BILLING.enabled ? `, con ${trial} giorni di prova gratuita` : ''}.
        </p>
        <div className="mt-6 flex justify-center"><IntervalToggle value={interval} onChange={setInterval} plans={plans} /></div>
      </section>

      <section className="container-app mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4" aria-label="Piani">
        {active.map((p) => {
          const price = planPrice(plans, p.code, interval);
          const h = PLAN_HIGHLIGHTS[p.code] ?? { items: [] };
          const cta = ctaFor(p.code, p.name);
          const saving = interval === 'year' ? yearlySaving(plans, p.code) : 0;
          return (
            <article key={p.code} data-plan={p.code} className={cn('card flex flex-col p-6', p.code === 'premium' && 'border-coral ring-1 ring-coral')}>
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-xl font-bold">{p.name}</h2>
                {p.code === 'premium' && <Badge tone="coral">Più scelto</Badge>}
              </div>
              <p className="mt-3 font-display text-4xl font-extrabold tabular-nums">
                {price ? formatPrice(price) : 'Gratis'}
                {price ? <span className="text-base font-medium text-ink-muted">{interval === 'year' ? '/anno' : '/mese'}</span> : null}
              </p>
              <p className="min-h-5 text-xs text-ink-muted">
                {price ? (interval === 'year' ? `${formatPrice(price / 12)} al mese${saving ? ` · risparmi ${saving}%` : ''} · IVA esclusa` : 'IVA esclusa') : 'Per sempre'}
              </p>
              <p className="mt-3 text-sm text-ink-muted">{p.description}</p>
              {h.intro && <p className="mt-4 text-xs font-bold uppercase tracking-wider text-ink-faint">{h.intro}</p>}
              <ul className={cn('space-y-2 text-sm', h.intro ? 'mt-2' : 'mt-4')}>
                {h.items.map((f) => (
                  <li key={f} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-leaf" /> {f}</li>
                ))}
              </ul>
              <div className="mt-auto pt-6">
                <ButtonLink to={cta.to} variant={p.code === 'premium' ? 'primary' : 'outline'} className="w-full whitespace-normal text-center">{cta.label}</ButtonLink>
              </div>
            </article>
          );
        })}
      </section>
      <p className="container-app mt-3 text-center text-xs text-ink-muted">Prezzi IVA esclusa. Nessun risultato garantito: i piani offrono strumenti e visibilità, i clienti li conquisti tu.</p>

      <section className="container-app mt-14">
        <h2 className="text-2xl font-extrabold">Confronto completo</h2>
        <p className="mb-4 mt-1 text-ink-muted">Funzioni e limiti aggiornati in tempo reale dalla configurazione dei piani.</p>
        <PlanComparisonTable plans={plans} />
      </section>

      <section className="container-app mt-14 grid gap-4 md:grid-cols-2">
        <h2 className="text-2xl font-extrabold md:col-span-2">Domande frequenti</h2>
        {FAQ.map(([q, a]) => (
          <details key={q} className="card group p-5">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3 font-semibold">
              {q} <HelpCircle className="h-5 w-5 shrink-0 text-ink-faint" />
            </summary>
            <p className="mt-3 text-ink-soft">{a}</p>
          </details>
        ))}
      </section>

      <section className="container-app mt-14 rounded-[36px] bg-ink p-8 text-center text-white sm:p-12">
        <h2 className="text-3xl font-extrabold text-white">Il tuo locale è già su {APP.name}?</h2>
        <p className="mx-auto mt-2 max-w-xl text-white/70">Cercalo, rivendicalo gratuitamente e scegli il piano più adatto quando vuoi.</p>
        <div className="mt-6 flex justify-center"><ButtonLink to="/restaurants" size="lg" icon={<Search className="h-5 w-5" />}>Trova il tuo locale</ButtonLink></div>
      </section>
    </div>
  );
}
