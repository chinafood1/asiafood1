import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  AlertTriangle, ArrowRight, Bike, CalendarClock, Check, ChevronRight, Clock, LocateFixed, MapPin, Minus, Phone, Plus, Printer, Receipt, RotateCcw,
  ShoppingBag, Store, Tag, Trash2, TriangleAlert,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { requestPosition } from '@/hooks/useGeolocation';
import { canVerifyAddress, verifyAddress } from '@/lib/addressGeocode';
import { cn, formatPrice } from '@/lib/format';
import { getOrderToken, recentGuestOrders, saveOrderToken } from '@/lib/orderTokens';
import { cartFromOrder } from '@/lib/reorder';
import { useSeo } from '@/lib/seo';
import { supabase } from '@/lib/supabase';
import { api, isDemoMode } from '@/services';
import type { AddressInput, CheckoutResult, CustomerAddress, IssueType, MyOrderSummary, OrderError, OrderPublicInfo, OrderType, OrderView, Quote, Slot } from '@/types/orders';
import { ISSUE_TYPES } from '@/types/orders';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader, Spinner } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { OrderPayment } from '@/components/orders/Payment';
import { DeliveryTracking } from '@/components/logistics/DeliveryTracking';
import { OrderStatusBadge, OrderTimeline, PaymentBadge, PriceSummary, dayTimeOf, timeOf } from '@/components/orders/OrderParts';
import { friendlyError } from '@/lib/errors';

const LINE_ERRORS = ['ITEM_UNAVAILABLE', 'ITEM_NOT_FOUND', 'OPTION_INVALID', 'OPTIONS_REQUIRED', 'PRICE_MISSING', 'QUANTITY_INVALID'];
const romeToday = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome' }).format(new Date());
const addDaysStr = (d: string, n: number) => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome' }).format(new Date(Date.parse(`${d}T12:00:00Z`) + n * 86_400_000));

function Section({ n, title, children, id }: { n: number; title: string; children: ReactNode; id?: string }) {
  return (
    <section className="card p-5 sm:p-6" aria-labelledby={`step-${n}`} id={id}>
      <h2 id={`step-${n}`} className="mb-4 flex items-center gap-3 text-lg font-bold">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ink text-sm text-white">{n}</span> {title}
      </h2>
      {children}
    </section>
  );
}

// ═════════════════════════════════════════════════════════════
//  /cart
// ═════════════════════════════════════════════════════════════
export function CartPage() {
  useSeo({ title: 'Carrello', path: '/cart', noindex: true });
  const cart = useCart();
  const navigate = useNavigate();
  const c = cart.cart;
  const info = useAsync<OrderPublicInfo | null>(() => (c ? api.getOrderInfo(c.restaurant_id) : Promise.resolve(null)), [c?.restaurant_id]);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [changed, setChanged] = useState(false);
  const viewed = useRef(false);
  const itemsKey = JSON.stringify(c?.lines.map((l) => [l.key, l.quantity]) ?? []);

  useEffect(() => {
    if (!c || !info.data) return;
    if (!viewed.current) {
      viewed.current = true;
      void api.track(c.restaurant_id, 'cart_view', 'web');
    }
    let alive = true;
    const type: OrderType = info.data.takeaway?.enabled ? 'takeaway' : 'delivery';
    void api.quoteOrder({ restaurant_id: c.restaurant_id, order_type: type, items: cart.toQuoteItems() }).then((q) => {
      if (!alive) return;
      setQuote(q);
      // Prezzi SEMPRE dal server: se sono cambiati li aggiorniamo e lo diciamo
      const prices = (q.lines ?? []).filter((l) => l.available).map((l) => ({ key: c.lines[l.index]?.key ?? '', unit_price: l.unit_price })).filter((p) => p.key);
      if (prices.some((p) => Math.abs((c.lines.find((l) => l.key === p.key)?.unit_price ?? 0) - p.unit_price) > 0.001)) setChanged(true);
      cart.applyServerPrices(prices);
    }, () => undefined);
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsKey, info.data]);

  if (!c || !c.lines.length) {
    return (
      <div className="container-app py-12">
        <EmptyState icon={<ShoppingBag className="h-7 w-7" />} title="Il tuo carrello è vuoto." text="Scegli un ristorante che accetta ordini online e aggiungi i tuoi piatti preferiti."
          action={<ButtonLink to="/restaurants?order=now">Trova qualcosa da mangiare</ButtonLink>} />
      </div>
    );
  }
  const errs = quote?.errors ?? [];
  const lineErr = (i: number) => errs.find((e) => e.index === i && LINE_ERRORS.includes(e.code));
  const blocking = errs.some((e) => LINE_ERRORS.includes(e.code) || ['ORDERS_DISABLED', 'PAYMENTS_NOT_READY', 'EMPTY_CART', 'TOO_MANY_ITEMS'].includes(e.code));
  const minErr = errs.find((e) => e.code === 'MINIMUM_NOT_REACHED');
  const general = errs.filter((e) => ['ORDERS_DISABLED', 'PAYMENTS_NOT_READY', 'RESTAURANT_PAUSED', 'RESTAURANT_CLOSED', 'TYPE_UNAVAILABLE'].includes(e.code));

  return (
    <div className="container-app max-w-3xl pb-32 pt-6">
      <h1 className="text-3xl font-extrabold">Carrello</h1>
      <p className="mt-1 text-ink-muted">
        Da <Link to={`/ristorante/${c.restaurant_slug}#menu`} className="font-semibold text-ink hover:underline">{c.restaurant_name}</Link> · un ordine riguarda un solo ristorante.
      </p>
      {changed && <div className="mt-4"><Alert>Alcuni prezzi o disponibilità sono cambiati: il carrello mostra i valori aggiornati.</Alert></div>}
      {general.map((e) => (
        <p key={e.code} className="mt-3 flex items-start gap-2 rounded-2xl bg-amber-50 px-4 py-3 text-sm text-amber-900" role="status">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> {e.message}
          {e.next_slot && <span className="ml-1">Primo orario disponibile: {dayTimeOf(e.next_slot.at)}.</span>}
        </p>
      ))}
      <ul className="mt-5 divide-y divide-line overflow-hidden rounded-3xl border border-line bg-white" data-testid="cart-lines">
        {c.lines.map((l, i) => {
          const e = lineErr(i);
          return (
            <li key={l.key} className={cn('p-4', e && 'bg-coral-50/40')}>
              <div className="flex items-start gap-3">
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{l.name}{l.variant_name && <span className="font-normal text-ink-muted"> · {l.variant_name}</span>}</p>
                  {(l.options.length > 0 || l.addons.length > 0) && (
                    <p className="text-sm text-ink-muted">{[...l.options.map((o) => `${o.group}: ${o.name}`), ...l.addons.map((a) => `+ ${a.name}`)].join(' · ')}</p>
                  )}
                  {l.notes && <p className="text-sm italic text-ink-muted">“{l.notes}”</p>}
                  {e && <p role="alert" className="mt-1 text-sm font-medium text-coral-700">{e.code === 'ITEM_UNAVAILABLE' ? 'Un prodotto nel tuo carrello non è più disponibile.' : e.message}</p>}
                </div>
                <p className="shrink-0 font-semibold tabular-nums">{formatPrice(l.unit_price * l.quantity)}</p>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <div className="flex items-center rounded-full border border-line" role="group" aria-label={`Quantità di ${l.name}`}>
                  <button type="button" aria-label="Diminuisci" onClick={() => cart.setQuantity(l.key, l.quantity - 1)} className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-cream"><Minus className="h-4 w-4" /></button>
                  <span className="w-7 text-center text-sm font-semibold tabular-nums">{l.quantity}</span>
                  <button type="button" aria-label="Aumenta" onClick={() => cart.setQuantity(l.key, l.quantity + 1)} className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-cream"><Plus className="h-4 w-4" /></button>
                </div>
                <button type="button" onClick={() => cart.remove(l.key)} className="ml-auto inline-flex items-center gap-1 rounded-full px-3 py-2 text-sm font-semibold text-coral-700 hover:bg-coral-50">
                  <Trash2 className="h-4 w-4" /> Rimuovi
                </button>
              </div>
            </li>
          );
        })}
      </ul>
      <div className="mt-5 card p-5">
        {quote ? (
          <>
            <PriceSummary q={{ ...quote, order_type: 'takeaway' }} />
            {info.data?.delivery?.enabled && <p className="mt-2 text-xs text-ink-muted">Il costo di consegna si calcola al checkout in base all’indirizzo.</p>}
            {minErr && <p className="mt-3 rounded-2xl bg-cream px-4 py-3 text-sm">{minErr.message}</p>}
          </>
        ) : <div className="flex justify-center py-4"><Spinner /></div>}
      </div>
      <div className="mt-5 flex flex-wrap gap-2">
        <Button size="lg" className="flex-1" disabled={!quote || blocking} onClick={() => navigate('/checkout')} data-testid="go-checkout">Vai al checkout <ArrowRight className="h-4 w-4" /></Button>
        <ButtonLink to={`/ristorante/${c.restaurant_slug}#menu`} variant="outline" size="lg">Aggiungi altro</ButtonLink>
      </div>
      <button type="button" onClick={() => cart.clear()} className="mt-4 text-sm font-semibold text-ink-muted hover:underline">Svuota carrello</button>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
//  /checkout
// ═════════════════════════════════════════════════════════════
const emptyAddress = (): AddressInput => ({ recipient_name: '', phone: '', address_line_1: '', address_line_2: '', city: '', province: '', postal_code: '', latitude: null, longitude: null, geocode_source: null, delivery_notes: '' });

export function CheckoutPage() {
  useSeo({ title: 'Checkout', path: '/checkout', noindex: true });
  const { user, profile } = useAuth();
  const { cities } = useReferenceData();
  const cart = useCart();
  const navigate = useNavigate();
  const toast = useToast();
  const c = cart.cart;
  const info = useAsync<OrderPublicInfo | null>(() => (c ? api.getOrderInfo(c.restaurant_id) : Promise.resolve(null)), [c?.restaurant_id]);
  const saved = useAsync<CustomerAddress[]>(() => (user ? api.listAddresses().catch(() => []) : Promise.resolve([])), [user?.id]);
  const restaurant = useAsync(() => (c ? api.getRestaurantsByIds([c.restaurant_id]).then((x) => x[0] ?? null) : Promise.resolve(null)), [c?.restaurant_id]);

  const [type, setType] = useState<OrderType>('takeaway');
  const [addrId, setAddrId] = useState<string>('new');
  const [addr, setAddr] = useState<AddressInput>(emptyAddress);
  const [addrState, setAddrState] = useState<{ status: 'idle' | 'checking' | 'ok' | 'error'; message?: string; label?: string }>({ status: 'idle' });
  const [saveAddr, setSaveAddr] = useState(true);
  const [when, setWhen] = useState<'asap' | 'later'>('asap');
  const [date, setDate] = useState(romeToday());
  const [slot, setSlot] = useState<string>('');
  const [slots, setSlots] = useState<Slot[]>([]);
  const [contact, setContact] = useState({ name: '', email: '', phone: '' });
  const [couponInput, setCouponInput] = useState('');
  const [coupon, setCoupon] = useState('');
  const [notes, setNotes] = useState('');
  const [quote, setQuote] = useState<Quote | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [placed, setPlaced] = useState<CheckoutResult | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const started = useRef(false);
  const idem = useRef(`co-${crypto.randomUUID()}`);

  // Tipo d'ordine: se ne è disponibile uno solo viene selezionato automaticamente
  useEffect(() => {
    if (!info.data?.enabled) return;
    if (info.data.takeaway?.enabled && !info.data.delivery?.enabled) setType('takeaway');
    else if (!info.data.takeaway?.enabled && info.data.delivery?.enabled) setType('delivery');
    if (!info.data.open_now && info.data.allow_scheduled) setWhen('later');
  }, [info.data]);
  useEffect(() => {
    if (profile) setContact((x) => ({ name: x.name || profile.full_name || '', email: x.email || profile.email || '', phone: x.phone || profile.phone || '' }));
  }, [profile]);
  useEffect(() => {
    const def = saved.data?.find((a) => a.is_default) ?? saved.data?.[0];
    if (def && addrId === 'new' && !addr.address_line_1) {
      setAddrId(def.id);
      setAddr({ ...def });
      setAddrState(def.latitude != null ? { status: 'ok', label: `${def.address_line_1}, ${def.city}` } : { status: 'idle' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saved.data]);
  useEffect(() => {
    if (c && !started.current) {
      started.current = true;
      void api.track(c.restaurant_id, 'checkout_started', 'web');
    }
  }, [c]);
  // Fasce orarie reali (orari del locale + capacità)
  useEffect(() => {
    if (!c || when !== 'later') return;
    let alive = true;
    void api.getOrderSlots(c.restaurant_id, date, type).then((s) => {
      if (!alive) return;
      setSlots(s);
      if (!s.some((x) => x.at === slot && x.status === 'available')) setSlot(s.find((x) => x.status === 'available')?.at ?? '');
    });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [c?.restaurant_id, when, date, type]);

  const input = useMemo(() => (c ? {
    restaurant_id: c.restaurant_id, order_type: type, items: cart.toQuoteItems(),
    address: type === 'delivery' && addr.latitude != null ? { ...addr, id: addrId !== 'new' ? addrId : null } : null,
    scheduled_for: when === 'later' ? slot || null : null, coupon_code: coupon || null,
    contact: { name: contact.name.trim(), email: contact.email.trim(), phone: contact.phone.trim() }, notes: notes.trim() || null,
  } : null), [c, type, addr, addrId, when, slot, coupon, contact, notes, cart]);

  const quoteKey = JSON.stringify(input ? { ...input, contact: input.contact.email, notes: null } : null);
  useEffect(() => {
    if (!input || placed) return;
    let alive = true;
    setQuoting(true);
    const t = window.setTimeout(() => {
      void api.quoteOrder(input).then((q) => alive && setQuote(q), () => undefined).finally(() => alive && setQuoting(false));
    }, 250);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quoteKey, placed]);

  if (!c || !c.lines.length) {
    if (placed?.order_number) return <PageLoader />;
    return (
      <div className="container-app py-12">
        <EmptyState icon={<ShoppingBag className="h-7 w-7" />} title="Il tuo carrello è vuoto." action={<ButtonLink to="/restaurants?order=now">Trova qualcosa da mangiare</ButtonLink>} />
      </div>
    );
  }
  if (info.loading || !info.data) return <PageLoader />;
  if (!info.data.enabled) return <div className="container-app py-12"><EmptyState icon="🛑" title="Questo ristorante non accetta più ordini online." action={<ButtonLink to="/restaurants?order=now">Scopri altri ristoranti</ButtonLink>} /></div>;

  const errs = quote?.errors ?? [];
  const has = (code: string) => errs.some((e) => e.code === code);
  const outside = has('OUTSIDE_AREA');
  const couponErr = errs.find((e) => e.field === 'coupon');
  const couponOk = quote?.codes?.find((x) => x.ok);

  const verify = async () => {
    const miss: Record<string, string> = {};
    if (addr.address_line_1.trim().length < 3) miss.address_line_1 = 'Inserisci via e numero civico.';
    if (!/^\d{5}$/.test(addr.postal_code)) miss.postal_code = 'CAP di 5 cifre.';
    if (addr.city.trim().length < 2) miss.city = 'Inserisci il comune.';
    setFieldErrors(miss);
    if (Object.keys(miss).length) return;
    setAddrState({ status: 'checking' });
    try {
      const p = await verifyAddress(addr, cities);
      if (!p) {
        setAddr((a) => ({ ...a, latitude: null, longitude: null, geocode_source: null }));
        setAddrState({ status: 'error', message: 'Non riusciamo a verificare questo indirizzo. Controlla via, numero civico e CAP, oppure usa la tua posizione.' });
        return;
      }
      setAddr((a) => ({ ...a, latitude: p.latitude, longitude: p.longitude, geocode_source: p.source }));
      setAddrState({ status: 'ok', label: p.approximate ? `${p.label} (posizione approssimata DEMO)` : p.label });
      void api.track(c.restaurant_id, 'address_added', 'web');
    } catch (e) {
      setAddrState({ status: 'error', message: (e as Error).message });
    }
  };
  const locateDevice = async () => {
    setAddrState({ status: 'checking' });
    const pos = await requestPosition('checkout');
    if (!pos) return setAddrState({ status: 'error', message: 'Posizione non disponibile: inserisci l’indirizzo completo.' });
    setAddr((a) => ({ ...a, latitude: pos.lat, longitude: pos.lng, geocode_source: 'device' }));
    setAddrState({ status: 'ok', label: 'Posizione del dispositivo (conferma anche via e civico per il fattorino)' });
    void api.track(c.restaurant_id, 'address_added', 'web');
  };

  const applyCoupon = () => {
    setCoupon(couponInput.trim().toUpperCase());
    if (couponInput.trim()) void api.track(c.restaurant_id, 'coupon_applied', 'web');
  };

  const pay = async (e: FormEvent) => {
    e.preventDefault();
    if (!input || placing) return;
    // Offline: niente checkout né pagamenti (nessuna coda locale per operazioni economiche)
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      toast('Sei offline: per ordinare e pagare serve la connessione.', 'error');
      return;
    }
    const miss: Record<string, string> = {};
    if (contact.name.trim().length < 2) miss.name = 'Inserisci nome e cognome.';
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(contact.email.trim())) miss.email = 'Inserisci un indirizzo email valido.';
    if (!/^\+?[0-9 ().-]{6,20}$/.test(contact.phone.trim())) miss.phone = 'Inserisci un numero di telefono valido.';
    if (type === 'delivery' && addr.latitude == null) miss.address = 'Verifica l’indirizzo di consegna.';
    if (when === 'later' && !slot) miss.slot = 'Scegli un orario.';
    setFieldErrors(miss);
    if (Object.keys(miss).length) {
      document.querySelector('[aria-invalid="true"], [data-error="true"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    setPlacing(true);
    try {
      if (user && type === 'delivery' && addrId === 'new' && saveAddr) {
        const a = await api.saveAddress({ ...addr, recipient_name: addr.recipient_name || contact.name, phone: addr.phone || contact.phone, is_default: !saved.data?.length }).catch(() => null);
        if (a) setAddrId(a.id);
      }
      const res = await api.placeOrder({ ...input, address: input.address ? { ...input.address, recipient_name: addr.recipient_name || contact.name, phone: addr.phone || contact.phone } : null, idempotency_key: idem.current });
      if (!res.ok) {
        setQuote((q) => (q ? { ...q, ok: false, errors: res.errors ?? [] } : q));
        toast(res.errors?.[0]?.message ?? 'Controlla i dati dell’ordine.', 'error');
        // Un nuovo tentativo con dati diversi è un nuovo ordine
        idem.current = `co-${crypto.randomUUID()}`;
        return;
      }
      saveOrderToken(res.order_number!, res.access_token!);
      void api.track(c.restaurant_id, 'payment_started', 'web');
      setPlaced(res);
      window.setTimeout(() => document.getElementById('pagamento')?.scrollIntoView({ behavior: 'smooth' }), 50);
    } catch (err) {
      toast(friendlyError(err), 'error');
    } finally {
      setPlacing(false);
    }
  };

  const onPaid = () => {
    const num = placed!.order_number!;
    cart.clear();
    navigate(`/orders/${num}?new=1`, { replace: true });
  };

  const tk = info.data.takeaway;
  const dl = info.data.delivery;
  const days = Array.from({ length: (info.data.max_advance_days ?? 0) + 1 }, (_, i) => addDaysStr(romeToday(), i));

  return (
    <div className="container-app max-w-3xl pb-32 pt-6">
      <h1 className="text-3xl font-extrabold">Checkout</h1>
      <p className="mt-1 text-ink-muted">{c.restaurant_name} · {cart.count} {cart.count === 1 ? 'articolo' : 'articoli'}</p>
      <form onSubmit={pay} className="mt-6 space-y-4" noValidate>
        <fieldset disabled={!!placed} className="space-y-4">
          <Section n={1} title="Tipo di ordine">
            <div className="grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Tipo di ordine">
              {tk?.enabled && (
                <label className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border p-4', type === 'takeaway' ? 'border-ink bg-cream' : 'border-line')}>
                  <input type="radio" name="type" className="h-4 w-4 accent-coral" checked={type === 'takeaway'} onChange={() => setType('takeaway')} />
                  <Store className="h-5 w-5 text-coral" /><span><strong>Ritiro al locale</strong><span className="block text-xs text-ink-muted">Takeaway{tk.state === 'paused' ? ' · in pausa' : ''}</span></span>
                </label>
              )}
              {dl?.enabled && (
                <label className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border p-4', type === 'delivery' ? 'border-ink bg-cream' : 'border-line')}>
                  <input type="radio" name="type" className="h-4 w-4 accent-coral" checked={type === 'delivery'} onChange={() => setType('delivery')} />
                  <Bike className="h-5 w-5 text-coral" /><span><strong>Consegna a domicilio</strong><span className="block text-xs text-ink-muted">Gestita dal ristorante{dl.state === 'paused' ? ' · in pausa' : ''}</span></span>
                </label>
              )}
            </div>
          </Section>

          <Section n={2} title={type === 'delivery' ? 'Indirizzo di consegna' : 'Ritiro'}>
            {type === 'takeaway' ? (
              <div className="flex items-start gap-3 text-sm">
                <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-coral" />
                <div>
                  <p className="font-semibold">{c.restaurant_name}</p>
                  <p className="text-ink-muted">{restaurant.data?.address ?? ''}{restaurant.data?.city ? `, ${restaurant.data.city.name}` : ''}</p>
                  {info.data.pickup_instructions && <p className="mt-1">{info.data.pickup_instructions}</p>}
                </div>
              </div>
            ) : (
              <div className="space-y-3" data-error={fieldErrors.address ? 'true' : undefined}>
                {(saved.data?.length ?? 0) > 0 && (
                  <Field label="Indirizzo salvato">
                    <Select value={addrId} onChange={(e) => {
                      const v = e.target.value;
                      setAddrId(v);
                      const a = saved.data!.find((x) => x.id === v);
                      setAddr(a ? { ...a } : emptyAddress());
                      setAddrState(a?.latitude != null ? { status: 'ok', label: `${a.address_line_1}, ${a.city}` } : { status: 'idle' });
                    }}>
                      {saved.data!.map((a) => <option key={a.id} value={a.id}>{a.label ? `${a.label} · ` : ''}{a.address_line_1}, {a.city}</option>)}
                      <option value="new">Nuovo indirizzo…</option>
                    </Select>
                  </Field>
                )}
                {addrId === 'new' && (
                  <>
                    <div className="grid gap-3 sm:grid-cols-[1fr_120px]">
                      <Field label="Via e numero civico" error={fieldErrors.address_line_1}>
                        <Input autoComplete="address-line1" value={addr.address_line_1} aria-invalid={!!fieldErrors.address_line_1} onChange={(e) => { setAddr({ ...addr, address_line_1: e.target.value, latitude: null, longitude: null }); setAddrState({ status: 'idle' }); }} />
                      </Field>
                      <Field label="CAP" error={fieldErrors.postal_code}>
                        <Input autoComplete="postal-code" inputMode="numeric" maxLength={5} value={addr.postal_code} aria-invalid={!!fieldErrors.postal_code} onChange={(e) => { setAddr({ ...addr, postal_code: e.target.value.replace(/\D/g, ''), latitude: null, longitude: null }); setAddrState({ status: 'idle' }); }} />
                      </Field>
                    </div>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="Comune" error={fieldErrors.city}>
                        <Input autoComplete="address-level2" list="checkout-cities" value={addr.city} aria-invalid={!!fieldErrors.city} onChange={(e) => { setAddr({ ...addr, city: e.target.value, latitude: null, longitude: null }); setAddrState({ status: 'idle' }); }} />
                        <datalist id="checkout-cities">{cities.slice(0, 200).map((x) => <option key={x.id} value={x.name} />)}</datalist>
                      </Field>
                      <Field label="Scala, interno, citofono (facoltativo)">
                        <Input autoComplete="address-line2" value={addr.address_line_2 ?? ''} onChange={(e) => setAddr({ ...addr, address_line_2: e.target.value })} />
                      </Field>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {canVerifyAddress() && <Button type="button" variant="outline" size="sm" onClick={() => void verify()} loading={addrState.status === 'checking'} data-testid="verify-address"><Check className="h-4 w-4" /> Verifica indirizzo</Button>}
                      <Button type="button" variant="ghost" size="sm" onClick={() => void locateDevice()}><LocateFixed className="h-4 w-4" /> Usa la mia posizione</Button>
                    </div>
                    {user && <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-coral" checked={saveAddr} onChange={(e) => setSaveAddr(e.target.checked)} /> Salva questo indirizzo nel mio profilo</label>}
                  </>
                )}
                <Field label="Note per il fattorino (facoltative)">
                  <Input maxLength={200} value={addr.delivery_notes ?? ''} onChange={(e) => setAddr({ ...addr, delivery_notes: e.target.value })} placeholder="Es. terzo piano, cancello verde" />
                </Field>
                {addrState.status === 'ok' && !outside && <p className="flex items-center gap-2 text-sm text-emerald-700" role="status"><Check className="h-4 w-4" /> {addrState.label}{quote?.delivery?.distance_km != null && ` · ${quote.delivery.distance_km.toLocaleString('it-IT')} km`}{quote?.delivery?.zone_name && ` · ${quote.delivery.zone_name}`}</p>}
                {addrState.status === 'error' && <p role="alert" className="text-sm text-coral-700">{addrState.message}</p>}
                {fieldErrors.address && addrState.status !== 'error' && <p role="alert" className="text-sm text-coral-700">{fieldErrors.address}</p>}
                {outside && (
                  <div role="alert" className="rounded-2xl bg-coral-50 p-4 text-sm">
                    <p className="font-semibold text-coral-700">Questo ristorante non consegna ancora a questo indirizzo.</p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {tk?.enabled && <Button type="button" size="sm" variant="outline" onClick={() => setType('takeaway')}>Passa al ritiro</Button>}
                      <ButtonLink to="/restaurants?delivery=1&order=now" size="sm" variant="ghost">Altri ristoranti</ButtonLink>
                    </div>
                  </div>
                )}
              </div>
            )}
          </Section>

          <Section n={3} title="Orario">
            <div className="grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Quando">
              <label className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border p-4', when === 'asap' ? 'border-ink bg-cream' : 'border-line', !info.data.open_now && 'opacity-50')}>
                <input type="radio" name="when" className="h-4 w-4 accent-coral" checked={when === 'asap'} disabled={!info.data.open_now} onChange={() => setWhen('asap')} />
                <Clock className="h-5 w-5 text-coral" /><span><strong>Il prima possibile</strong><span className="block text-xs text-ink-muted">{info.data.open_now ? `Circa ${info.data.preparation_minutes} min${type === 'delivery' ? ' + consegna' : ''}` : 'Il ristorante ora è chiuso'}</span></span>
              </label>
              {info.data.allow_scheduled && (
                <label className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border p-4', when === 'later' ? 'border-ink bg-cream' : 'border-line')}>
                  <input type="radio" name="when" className="h-4 w-4 accent-coral" checked={when === 'later'} onChange={() => setWhen('later')} />
                  <CalendarClock className="h-5 w-5 text-coral" /><span><strong>Programma ordine</strong><span className="block text-xs text-ink-muted">Scegli giorno e orario</span></span>
                </label>
              )}
            </div>
            {when === 'later' && (
              <div className="mt-3 grid gap-3 sm:grid-cols-2" data-error={fieldErrors.slot ? 'true' : undefined}>
                <Field label="Giorno">
                  <Select value={date} onChange={(e) => setDate(e.target.value)}>
                    {days.map((d, i) => <option key={d} value={d}>{i === 0 ? 'Oggi' : i === 1 ? 'Domani' : new Date(`${d}T12:00:00Z`).toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' })}</option>)}
                  </Select>
                </Field>
                <Field label="Orario" error={fieldErrors.slot}>
                  <Select value={slot} onChange={(e) => setSlot(e.target.value)} aria-invalid={!!fieldErrors.slot} data-testid="slot-select">
                    {!slots.some((s) => s.status === 'available') && <option value="">Nessun orario disponibile</option>}
                    {slots.map((s) => <option key={s.at} value={s.at} disabled={s.status !== 'available'}>{s.time}{s.status === 'full' ? ' · al completo' : ''}</option>)}
                  </Select>
                </Field>
              </div>
            )}
          </Section>

          <Section n={4} title="Contatti">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Nome e cognome" error={fieldErrors.name} className="sm:col-span-2">
                <Input autoComplete="name" value={contact.name} aria-invalid={!!fieldErrors.name} onChange={(e) => setContact({ ...contact, name: e.target.value })} />
              </Field>
              <Field label="Email (per ricevuta e aggiornamenti)" error={fieldErrors.email}>
                <Input type="email" autoComplete="email" value={contact.email} aria-invalid={!!fieldErrors.email} onChange={(e) => setContact({ ...contact, email: e.target.value })} />
              </Field>
              <Field label="Telefono (per il ristorante)" error={fieldErrors.phone}>
                <Input type="tel" autoComplete="tel" value={contact.phone} aria-invalid={!!fieldErrors.phone} onChange={(e) => setContact({ ...contact, phone: e.target.value })} />
              </Field>
              <Field label="Note per il ristorante (facoltative)" className="sm:col-span-2">
                <Textarea rows={2} maxLength={300} value={notes} onChange={(e) => setNotes(e.target.value)} />
              </Field>
            </div>
            {!user && <p className="mt-2 text-xs text-ink-muted">Ordini come ospite: <Link to="/accedi?next=/checkout" className="font-semibold text-coral-700">accedi</Link> per ritrovare gli ordini e guadagnare AsiaPoints.</p>}
          </Section>

          <Section n={5} title="Codice sconto">
            <div className="flex gap-2">
              <Input aria-label="Codice sconto" placeholder="Coupon del ristorante o codice premio AsiaPoints" value={couponInput} onChange={(e) => setCouponInput(e.target.value)} aria-invalid={!!couponErr} aria-describedby={couponErr ? 'coupon-err' : undefined} />
              <Button type="button" variant="outline" onClick={applyCoupon}><Tag className="h-4 w-4" /> Applica</Button>
            </div>
            {couponOk && coupon && <p className="mt-2 flex items-center gap-2 text-sm text-emerald-700" role="status"><Check className="h-4 w-4" /> {couponOk.code}: {couponOk.title} (−{formatPrice(couponOk.discount)}) <button type="button" className="ml-2 text-xs font-semibold text-ink-muted underline" onClick={() => { setCoupon(''); setCouponInput(''); }}>Rimuovi</button></p>}
            {couponErr && coupon && <p id="coupon-err" role="alert" className="mt-2 text-sm text-coral-700">{couponErr.message} <button type="button" className="ml-1 text-xs font-semibold underline" onClick={() => { setCoupon(''); setCouponInput(''); }}>Rimuovi</button></p>}
            <p className="mt-2 text-xs text-ink-faint">Un solo codice per ordine. Gli AsiaPoints non si convertono in denaro: si usano solo i premi riscattati.</p>
          </Section>
        </fieldset>

        <Section n={6} title="Riepilogo">
          <ul className="mb-4 space-y-1 text-sm">
            {c.lines.map((l, i) => {
              const ql = quote?.lines?.[i];
              return (
                <li key={l.key} className="flex justify-between gap-3">
                  <span>{l.quantity}× {l.name}{l.variant_name ? ` (${l.variant_name})` : ''}</span>
                  <span className="tabular-nums">{formatPrice(ql?.line_total ?? l.unit_price * l.quantity)}</span>
                </li>
              );
            })}
          </ul>
          {quote ? <PriceSummary q={{ ...quote, order_type: type }} deliveryPending={type === 'delivery' && addr.latitude == null} /> : <Spinner />}
          {when === 'later' && slot && <p className="mt-3 text-sm"><strong>{type === 'delivery' ? 'Consegna' : 'Ritiro'}:</strong> {dayTimeOf(slot)}</p>}
          {when === 'asap' && quote?.estimated_ready_at && <p className="mt-3 text-sm text-ink-muted">{type === 'delivery' ? `Consegna stimata verso le ${timeOf(quote.estimated_delivery_at)}` : `Pronto verso le ${timeOf(quote.estimated_ready_at)}`} (conferma del ristorante).</p>}
          <ErrorList errors={errs.filter((e) => !['OUTSIDE_AREA', 'ADDRESS_REQUIRED'].includes(e.code) && e.field !== 'coupon')} />
          <p className="mt-3 text-xs text-ink-faint">Il totale è calcolato dal server. Riceverai una ricevuta di pagamento; per la documentazione fiscale fa fede il ristorante.</p>
        </Section>

        {!placed ? (
          <Button type="submit" size="lg" className="w-full" loading={placing} disabled={quoting || !quote || errs.some((e) => !['ADDRESS_REQUIRED'].includes(e.code))} data-testid="checkout-submit">
            Continua al pagamento · {formatPrice(quote?.total ?? 0)}
          </Button>
        ) : null}
      </form>

      {placed && (
        <section id="pagamento" className="card mt-4 p-5 sm:p-6" aria-labelledby="step-7">
          <h2 id="step-7" className="mb-4 flex items-center gap-3 text-lg font-bold"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-ink text-sm text-white">7</span> Pagamento</h2>
          <p className="mb-3 text-sm text-ink-muted">Ordine <strong className="font-mono">{placed.order_number}</strong> in attesa di pagamento.</p>
          <OrderPayment orderNumber={placed.order_number!} token={placed.access_token ?? null} total={placed.total ?? 0} clientSecret={placed.client_secret ?? null} onPaid={onPaid} />
        </section>
      )}
    </div>
  );
}

function ErrorList({ errors }: { errors: OrderError[] }) {
  if (!errors.length) return null;
  return (
    <ul className="mt-3 space-y-1.5" role="alert">
      {errors.map((e, i) => (
        <li key={`${e.code}-${i}`} className="flex items-start gap-2 rounded-2xl bg-coral-50 px-3 py-2 text-sm text-coral-700">
          <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" /> <span>{e.message}{e.next_slot ? ` Primo orario disponibile: ${dayTimeOf(e.next_slot.at)}.` : ''}</span>
        </li>
      ))}
    </ul>
  );
}

// ═════════════════════════════════════════════════════════════
//  /orders/:orderNumber — tracking in tempo reale
// ═════════════════════════════════════════════════════════════
const FINAL = ['completed', 'rejected', 'cancelled', 'refunded', 'partially_refunded'];

export function OrderPage() {
  const { orderNumber = '' } = useParams();
  const [params, setParams] = useSearchParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const cart = useCart();
  useSeo({ title: `Ordine ${orderNumber}`, path: '/orders', noindex: true });
  const [token] = useState(() => {
    const t = params.get('t');
    if (t) saveOrderToken(orderNumber, t);
    return t ?? getOrderToken(orderNumber);
  });
  const [o, setO] = useState<OrderView | null | undefined>(undefined);
  const [err, setErr] = useState<string | null>(null);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [issueOpen, setIssueOpen] = useState(false);
  const [paySecret, setPaySecret] = useState<string | null | undefined>(undefined);
  const justPlaced = params.get('new') === '1';

  // Il token non resta nella barra degli indirizzi (cronologia, condivisioni)
  useEffect(() => {
    if (params.get('t')) {
      params.delete('t');
      setParams(params, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const load = useCallback(async () => {
    try {
      setO(await api.trackOrder(orderNumber, token));
      setErr(null);
    } catch (e) {
      setErr((e as Error).message);
      setO(null);
    }
  }, [orderNumber, token]);
  useEffect(() => {
    void load();
  }, [load, user?.id]);

  // Aggiornamenti senza ricaricare: Realtime per gli utenti registrati, polling leggero per tutti
  const final = o ? FINAL.includes(o.status) : false;
  useEffect(() => {
    if (!o || final) return;
    const t = window.setInterval(() => void load(), user ? 20_000 : 8_000);
    let channel: ReturnType<NonNullable<typeof supabase>['channel']> | null = null;
    if (supabase && user && o.is_owner) {
      channel = supabase.channel(`order-${o.id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'order_realtime', filter: `order_id=eq.${o.id}` }, () => void load())
        .subscribe();
    }
    return () => {
      window.clearInterval(t);
      if (channel) void supabase?.removeChannel(channel);
    };
  }, [o?.id, final, user, load]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!o?.can_pay || paySecret !== undefined) return;
    void api.resumeOrderPayment(o.id, token).then((r) => setPaySecret(r.client_secret), () => setPaySecret(null));
  }, [o?.can_pay, o?.id, token, paySecret]);

  if (o === undefined) return <PageLoader />;
  if (!o) {
    return (
      <div className="container-app py-12">
        <EmptyState icon="🔒" title="Ordine non trovato" text={err ?? 'Apri il link ricevuto dopo l’ordine dallo stesso dispositivo, oppure accedi con l’account usato per ordinare.'}
          action={!user ? <ButtonLink to={`/accedi?next=/orders/${orderNumber}`}>Accedi</ButtonLink> : <ButtonLink to="/profile/orders">I miei ordini</ButtonLink>} />
      </div>
    );
  }

  const reorder = async () => {
    try {
      const { cart: c, skipped } = await cartFromOrder(o);
      if (!c.lines.length) return toast('Nessun prodotto di questo ordine è disponibile oggi.', 'error');
      cart.replace(c);
      void api.track(o.restaurant.id, 'reorder', 'web');
      toast(skipped.length ? `Carrello ricreato con i prezzi attuali. Non più disponibili: ${skipped.join(', ')}.` : 'Carrello ricreato con i prezzi e la disponibilità di oggi.');
      navigate('/cart');
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };

  const hero = (() => {
    switch (o.status) {
      case 'pending_payment': return { title: o.payment_status === 'failed' ? 'Pagamento non riuscito' : 'In attesa di pagamento', text: 'Completa il pagamento per inviare l’ordine al ristorante.' };
      case 'pending_restaurant': return { title: 'Ordine inviato', text: `Aspettiamo la conferma di ${o.restaurant.name}.` };
      case 'accepted': return { title: 'Ordine accettato', text: o.estimated_ready_at ? `Pronto verso le ${timeOf(o.estimated_ready_at)}.` : '' };
      case 'preparing': return { title: 'In preparazione', text: o.estimated_ready_at ? `Pronto verso le ${timeOf(o.estimated_ready_at)}.` : '' };
      case 'ready': return { title: o.order_type === 'takeaway' ? 'Ordine pronto per il ritiro' : 'Ordine pronto per la consegna', text: o.order_type === 'takeaway' ? 'Ti aspettiamo al locale.' : 'Sta per partire.' };
      case 'out_for_delivery': return { title: 'Il tuo ordine è in consegna.', text: o.estimated_delivery_at ? `Arrivo stimato verso le ${timeOf(o.estimated_delivery_at)}.` : '' };
      case 'completed': return { title: o.order_type === 'takeaway' ? 'Ordine ritirato' : 'Ordine consegnato', text: 'Buon appetito!' };
      case 'rejected': return { title: 'Ordine non accettato', text: o.reject_reason ?? '' };
      case 'cancelled': return { title: 'Ordine annullato', text: o.cancel_reason ?? '' };
      default: return { title: 'Ordine', text: '' };
    }
  })();
  const refundPending = o.refunds.some((f) => ['pending', 'processing'].includes(f.status));

  return (
    <div className="container-app max-w-3xl pb-32 pt-6 print:pb-0">
      {justPlaced && o.status !== 'pending_payment' && <div className="mb-4 print:hidden"><Alert tone="success">Grazie! Il tuo ordine {o.order_number} è stato inviato al ristorante.</Alert></div>}
      <header className="card p-5 sm:p-6" data-testid="order-hero">
        <div className="flex flex-wrap items-center gap-2">
          <OrderStatusBadge status={o.status} />
          <PaymentBadge status={o.payment_status} />
          <span className="ml-auto font-mono text-sm font-bold">{o.order_number}</span>
        </div>
        <h1 className="mt-3 text-2xl font-extrabold sm:text-3xl" aria-live="polite">{hero.title}</h1>
        {hero.text && <p className="mt-1 text-ink-muted">{hero.text}</p>}
        {refundPending && <p className="mt-2 text-sm font-medium text-amber-700">Rimborso in elaborazione.</p>}
        {o.refunds.some((f) => f.status === 'succeeded') && <p className="mt-2 text-sm font-medium text-emerald-700">Rimborsati {formatPrice(o.amount_refunded)}: l’accredito può richiedere alcuni giorni lavorativi.</p>}
      </header>

      {o.order_type === 'delivery' && o.status !== 'pending_payment' && <div className="print:hidden"><DeliveryTracking orderNumber={o.order_number} token={token} canRate={o.is_owner} /></div>}

      {o.can_pay && (
        <section className="card mt-4 p-5 print:hidden" aria-label="Pagamento">
          <h2 className="mb-3 text-lg font-bold">Completa il pagamento</h2>
          {paySecret === undefined && !isDemoMode ? <Spinner /> : <OrderPayment orderNumber={o.order_number} token={token} total={o.total} clientSecret={paySecret ?? null} onPaid={() => void load()} />}
        </section>
      )}

      <div className="mt-4 grid gap-4 md:grid-cols-[1fr_280px]">
        <section className="card p-5">
          <h2 className="mb-3 text-lg font-bold">Articoli</h2>
          <ul className="space-y-2 text-sm">
            {o.items.map((i) => (
              <li key={i.id} className="flex justify-between gap-3">
                <span>
                  <strong>{i.quantity}×</strong> {i.name}{i.variant ? ` (${i.variant})` : ''}
                  {i.options.length > 0 && <span className="block text-xs text-ink-muted">{i.options.map((x) => (x.kind === 'addon' ? `+ ${x.name}` : `${x.group}: ${x.name}`)).join(' · ')}</span>}
                  {i.notes && <span className="block text-xs italic text-ink-muted">“{i.notes}”</span>}
                </span>
                <span className="tabular-nums">{formatPrice(i.line_total)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-4 border-t border-line pt-3"><PriceSummary q={o} /></div>
          {o.coupon_code && <p className="mt-2 text-xs text-ink-muted">Codice usato: {o.coupon_code}</p>}
        </section>
        <aside className="space-y-4">
          <section className="card p-5">
            <h2 className="mb-3 text-lg font-bold">Stato</h2>
            <OrderTimeline o={o} />
          </section>
          <section className="card p-5 text-sm">
            <h2 className="mb-2 text-lg font-bold">{o.order_type === 'takeaway' ? 'Ritiro' : 'Consegna'}</h2>
            {o.scheduled_for && <p className="mb-2"><strong>Programmato:</strong> {dayTimeOf(o.scheduled_for)}</p>}
            {o.order_type === 'takeaway' ? (
              <>
                <p className="font-semibold">{o.restaurant.name}</p>
                <p className="text-ink-muted">{o.restaurant.address}{o.restaurant.city ? `, ${o.restaurant.city}` : ''}</p>
                {o.restaurant.pickup_instructions && <p className="mt-1">{o.restaurant.pickup_instructions}</p>}
              </>
            ) : o.delivery_address && (
              <p className="text-ink-muted">{o.delivery_address.address_line_1}{o.delivery_address.address_line_2 ? `, ${o.delivery_address.address_line_2}` : ''}, {o.delivery_address.postal_code} {o.delivery_address.city}</p>
            )}
            {o.restaurant.phone && <a href={`tel:${o.restaurant.phone.replace(/\s+/g, '')}`} className="mt-2 inline-flex items-center gap-1.5 font-semibold text-coral-700 print:hidden"><Phone className="h-4 w-4" /> Chiama il ristorante</a>}
          </section>
        </aside>
      </div>

      <div className="mt-4 flex flex-wrap gap-2 print:hidden">
        {o.can_cancel && <Button variant="outline" onClick={() => setCancelOpen(true)}>Annulla ordine</Button>}
        {!o.can_cancel && o.status !== 'pending_payment' && <Button variant="outline" onClick={() => setIssueOpen(true)}><TriangleAlert className="h-4 w-4" /> Segnala un problema</Button>}
        {o.reviewable && o.is_owner && <ButtonLink to={`/ristorante/${o.restaurant.slug}?review=1#recensioni`} variant="outline">Lascia una recensione</ButtonLink>}
        {FINAL.includes(o.status) && <Button variant="outline" onClick={() => void reorder()}><RotateCcw className="h-4 w-4" /> Ordina di nuovo</Button>}
        {o.paid_at && <Button variant="ghost" onClick={() => window.print()}><Printer className="h-4 w-4" /> Ricevuta di pagamento</Button>}
      </div>
      {o.paid_at && <p className="mt-3 text-xs text-ink-faint"><Receipt className="mr-1 inline h-3.5 w-3.5" />La ricevuta di pagamento non è un documento fiscale: lo scontrino o la fattura li emette il ristorante.</p>}
      {o.issues.length > 0 && (
        <section className="card mt-4 p-5 text-sm">
          <h2 className="mb-2 font-bold">Segnalazioni</h2>
          <ul className="space-y-1">{o.issues.map((x) => <li key={x.id}>{ISSUE_TYPES.find((t) => t.value === x.type)?.label} · {x.status === 'open' ? 'aperta' : x.status === 'resolved' ? 'risolta' : x.status}{x.resolution ? ` — ${x.resolution}` : ''}</li>)}</ul>
        </section>
      )}

      <CancelSheet open={cancelOpen} onClose={() => setCancelOpen(false)} paid={o.payment_status === 'paid'} onConfirm={async (reason) => {
        try {
          const r = await api.cancelOrderAsCustomer(o.order_number, token, reason);
          toast(r.refund_pending ? 'Ordine annullato: rimborso completo in corso.' : 'Ordine annullato.');
          setCancelOpen(false);
          void load();
        } catch (e) {
          toast((e as Error).message, 'error');
        }
      }} />
      <IssueSheet open={issueOpen} onClose={() => setIssueOpen(false)} onSubmit={async (type, desc) => {
        try {
          await api.reportOrderIssue(o.order_number, token, type, desc);
          toast('Segnalazione inviata: lo staff AsiaFood ti risponderà al più presto.');
          setIssueOpen(false);
          void load();
        } catch (e) {
          toast((e as Error).message, 'error');
        }
      }} />
    </div>
  );
}

function CancelSheet({ open, onClose, onConfirm, paid }: { open: boolean; onClose: () => void; onConfirm: (reason: string) => Promise<void>; paid: boolean }) {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  return (
    <Sheet open={open} onClose={onClose} title="Annullare l’ordine?">
      <div className="space-y-4">
        <p className="text-sm text-ink-muted">Puoi annullare finché il ristorante non ha accettato l’ordine.{paid ? ' Riceverai il rimborso completo sulla carta usata.' : ''}</p>
        <Field label="Motivo (facoltativo)"><Input value={reason} maxLength={150} onChange={(e) => setReason(e.target.value)} /></Field>
        <div className="grid gap-2 sm:grid-cols-2">
          <Button variant="outline" onClick={onClose}>Non annullare</Button>
          <Button loading={busy} onClick={async () => { setBusy(true); await onConfirm(reason); setBusy(false); }}>Annulla ordine</Button>
        </div>
      </div>
    </Sheet>
  );
}

function IssueSheet({ open, onClose, onSubmit }: { open: boolean; onClose: () => void; onSubmit: (t: IssueType, d: string) => Promise<void> }) {
  const [type, setType] = useState<IssueType>('missing_item');
  const [desc, setDesc] = useState('');
  const [busy, setBusy] = useState(false);
  return (
    <Sheet open={open} onClose={onClose} title="Segnala un problema">
      <form className="space-y-4" onSubmit={async (e) => { e.preventDefault(); setBusy(true); await onSubmit(type, desc); setBusy(false); }}>
        <Field label="Tipo di problema">
          <Select value={type} onChange={(e) => setType(e.target.value as IssueType)}>{ISSUE_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}</Select>
        </Field>
        <Field label="Descrizione" hint="Almeno 5 caratteri. Lo staff AsiaFood gestisce la segnalazione con il ristorante.">
          <Textarea required minLength={5} maxLength={1000} rows={4} value={desc} onChange={(e) => setDesc(e.target.value)} />
        </Field>
        <Button type="submit" className="w-full" loading={busy} disabled={desc.trim().length < 5}>Invia segnalazione</Button>
      </form>
    </Sheet>
  );
}

// ═════════════════════════════════════════════════════════════
//  /profile/orders — cronologia
// ═════════════════════════════════════════════════════════════
export function MyOrdersPage() {
  useSeo({ title: 'I miei ordini', path: '/profile/orders', noindex: true });
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const cart = useCart();
  const toast = useToast();
  const location = useLocation();
  const [page, setPage] = useState(0);
  const PAGE = 10;
  const mine = useAsync(() => (user ? api.listMyOrders(PAGE, page * PAGE) : Promise.resolve({ total: 0, items: [] as MyOrderSummary[] })), [user?.id, page]);
  const guest = useAsync(async () => {
    if (user) return [] as OrderView[];
    const list = recentGuestOrders().slice(0, 10);
    const out: OrderView[] = [];
    for (const g of list) {
      const v = await api.trackOrder(g.order_number, g.token).catch(() => null);
      if (v) out.push(v);
    }
    return out;
  }, [user?.id]);

  const reorder = async (num: string) => {
    try {
      const v = await api.trackOrder(num, getOrderToken(num));
      if (!v) throw new Error('Ordine non trovato.');
      const { cart: c, skipped } = await cartFromOrder(v);
      if (!c.lines.length) return toast('Nessun prodotto di questo ordine è disponibile oggi.', 'error');
      cart.replace(c);
      void api.track(v.restaurant.id, 'reorder', 'web');
      toast(skipped.length ? `Carrello ricreato. Non più disponibili: ${skipped.join(', ')}.` : 'Carrello ricreato con i prezzi di oggi.');
      navigate('/cart');
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };

  if (loading) return <PageLoader />;
  const items: MyOrderSummary[] = user ? mine.data?.items ?? [] : (guest.data ?? []).map((v) => ({
    id: v.id, order_number: v.order_number, status: v.status, payment_status: v.payment_status, order_type: v.order_type, total: v.total, created_at: v.created_at,
    scheduled_for: v.scheduled_for, estimated_ready_at: v.estimated_ready_at, restaurant: { id: v.restaurant.id, name: v.restaurant.name, slug: v.restaurant.slug, logo_url: null },
    items_count: v.items.reduce((s, i) => s + i.quantity, 0), summary: v.items.map((i) => `${i.quantity}× ${i.name}`).join(', '),
  }));
  const active = items.filter((x) => !FINAL.includes(x.status) && x.status !== 'pending_payment');
  const busy = user ? mine.loading : guest.loading;

  return (
    <div className="container-app max-w-3xl pb-24 pt-8">
      <h1 className="text-3xl font-extrabold">I miei ordini</h1>
      {!user && <p className="mt-1 text-sm text-ink-muted">Stai vedendo gli ordini fatti come ospite da questo dispositivo. <Link to={`/accedi?next=${encodeURIComponent(location.pathname)}`} className="font-semibold text-coral-700">Accedi</Link> per la cronologia completa.</p>}
      {busy ? <div className="py-10"><Spinner /></div> : (
        <>
          {active.length === 0 && <p className="mt-6 rounded-2xl bg-cream px-4 py-3 text-sm">Nessun ordine in corso.</p>}
          {items.length === 0 ? (
            <div className="mt-6"><EmptyState icon={<ShoppingBag className="h-7 w-7" />} title="Nessun ordine" action={<ButtonLink to="/restaurants?order=now">Trova qualcosa da mangiare</ButtonLink>} /></div>
          ) : (
            <ul className="mt-6 space-y-3" data-testid="my-orders">
              {items.map((x) => (
                <li key={x.id} className="card p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold">{x.restaurant.name}</span>
                    <OrderStatusBadge status={x.status} />
                    <span className="ml-auto font-bold tabular-nums">{formatPrice(x.total)}</span>
                  </div>
                  <p className="mt-1 text-sm text-ink-muted">{dayTimeOf(x.created_at)} · {x.order_type === 'delivery' ? 'Consegna' : 'Ritiro'} · <span className="font-mono">{x.order_number}</span></p>
                  {x.summary && <p className="mt-1 line-clamp-2 text-sm">{x.summary}</p>}
                  <div className="mt-3 flex flex-wrap gap-2">
                    <ButtonLink to={`/orders/${x.order_number}`} size="sm" variant="outline">Dettagli <ChevronRight className="h-4 w-4" /></ButtonLink>
                    {FINAL.includes(x.status) && <Button size="sm" variant="ghost" onClick={() => void reorder(x.order_number)}><RotateCcw className="h-4 w-4" /> Ordina di nuovo</Button>}
                  </div>
                </li>
              ))}
            </ul>
          )}
          {user && (mine.data?.total ?? 0) > PAGE && (
            <div className="mt-4 flex justify-between">
              <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Precedenti</Button>
              <Button size="sm" variant="outline" disabled={(page + 1) * PAGE >= (mine.data?.total ?? 0)} onClick={() => setPage((p) => p + 1)}>Successivi</Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
