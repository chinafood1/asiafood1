import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { LayoutGrid, List, LocateFixed, Map as MapIcon, Search, X } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { useGeolocation } from '@/hooks/useGeolocation';
import { matchesOrderMode, useOrderable, type OrderMode } from '@/hooks/useOrderable';
import { AskAiButton } from '@/components/ai/AiEntry';
import { useSeo } from '@/lib/seo';
import { cn } from '@/lib/format';
import { parseSearchQuery } from '@/lib/searchQuery';
import { filtersFromParams, filtersToParams, type ExploreView } from '@/lib/filterParams';
import { api, type SortKey } from '@/services';
import { Chip } from '@/components/ui/Badge';
import { Select } from '@/components/ui/Field';
import { EmptyState } from '@/components/ui/Layout';
import { CardSkeleton, RestaurantCard, RestaurantRow } from '@/components/restaurant/RestaurantCard';
import { SponsoredSlots } from '@/components/restaurant/SponsoredSlots';
import { FiltersPanel, SORT_OPTIONS, type FilterState } from '@/components/search/FiltersPanel';
import type { SponsoredSlot } from '@/types/domain';


type View = ExploreView;
const fromParams = filtersFromParams;
const toParams = (f: FilterState & { view?: View }) => filtersToParams(f);

export default function ExplorePage() {
  const [params, setParams] = useSearchParams();
  const state = useMemo(() => fromParams(params), [params]);
  const { view, ...filters } = state;
  const { categoryBySlug, cityBySlug, categories, cities } = useReferenceData();
  const geo = useGeolocation();
  const [q, setQ] = useState(filters.q ?? '');
  const navigate = useNavigate();

  useEffect(() => setQ(filters.q ?? ''), [filters.q]);

  // Se l'URL chiede "vicino a me", chiedi la posizione (azione esplicita dell'utente)
  useEffect(() => {
    if (filters.useLocation && geo.status === 'idle') geo.request();
  }, [filters.useLocation, geo]);

  const update = (next: FilterState & { view?: View }) => setParams(toParams({ view, ...next }), { replace: true });

  // Se l'utente ha già concesso la posizione, le distanze si calcolano nel browser (nessun invio al server)
  const near = geo.coords ? { ...geo.coords, radiusKm: filters.useLocation ? filters.radiusKm : undefined } : undefined;
  const defaultSort: SortKey = filters.useLocation && near ? 'distance' : 'relevance';
  const key = params.toString() + (near ? `${near.lat},${near.lng}` : '');
  // Risultati e slot sponsorizzati caricati insieme: niente spostamento della griglia quando arriva lo sponsor (CLS)
  const result = useAsync(async () => {
    const [rows, sponsored] = await Promise.all([
      api.searchRestaurants({ ...filters, near, sort: filters.sort ?? defaultSort }),
      api.getSponsoredSlots('search_top', { citySlug: filters.citySlug, categorySlug: filters.categorySlug, limit: 2 }).catch(() => [] as SponsoredSlot[]),
    ]);
    return Object.assign(rows, { sponsored, forKey: key });
  }, [key]);

  // Fase 13: ricerca registrata in forma anonima (testo normalizzato e filtrato sul server, filtri, numero di risultati).
  // Una sola volta per combinazione per sessione di pagina; niente utente, niente posizione.
  const logged = useRef(new Set<string>());
  useEffect(() => {
    // Solo risultati della ricerca corrente (mai quelli della ricerca precedente ancora a schermo)
    if (result.loading || !result.data || result.data.forKey !== key || (!filters.q && !filters.categorySlug && !filters.citySlug)) return;
    const k = [filters.q ?? '', filters.categorySlug ?? '', filters.citySlug ?? ''].join('|');
    if (logged.current.has(k)) return;
    logged.current.add(k);
    api.growth.logSearch({ query: filters.q ?? null, category_slug: filters.categorySlug ?? null, city_slug: filters.citySlug ?? null,
      result_count: result.data.length, result_ids: result.data.slice(0, 20).map((r) => r.id), source: 'explore' });
  }, [result.loading, result.data, key, filters.q, filters.categorySlug, filters.citySlug]);

  /** "Sushi Taranto" → category=sushi & city=taranto; resta in q solo il nome del locale. */
  const submitQuery = (raw: string) => {
    const text = raw.trim();
    if (!text) return update({ ...filters, q: undefined });
    const parsed = parseSearchQuery(text, categories, cities);
    update({
      ...filters,
      q: parsed.text ? text.replace(/\s+/g, ' ') : undefined,
      categorySlug: parsed.categorySlug ?? (parsed.text ? filters.categorySlug : undefined),
      citySlug: parsed.citySlug ?? (parsed.text ? filters.citySlug : undefined),
      ayce: parsed.ayce || filters.ayce,
    });
  };

  const cat = categoryBySlug(filters.categorySlug);
  const city = cityBySlug(filters.citySlug);
  const heading = [cat?.name ?? 'Ristoranti asiatici', city ? `a ${city.name}` : filters.useLocation && near ? 'vicino a te' : ''].filter(Boolean).join(' ');

  useSeo({
    title: filters.q ? `Risultati per "${filters.q}"` : heading,
    description: `${heading}: menu, prezzi, orari, All You Can Eat e offerte.`,
    path: '/restaurants',
    // Le combinazioni di filtri non vanno indicizzate: esistono le pagine SEO dedicate
    noindex: params.toString().length > 0,
  });

  const orderable = useOrderable();
  const rows = useMemo(() => {
    const list = result.data ?? [];
    const mode = filters.orderMode;
    return mode && orderable ? list.filter((r) => matchesOrderMode(orderable.get(r.id), mode)) : list;
  }, [result.data, filters.orderMode, orderable]);
  const sponsoredRow = (className: string) => (
    <SponsoredSlots placement="search_top" citySlug={filters.citySlug} categorySlug={filters.categorySlug} onlyIds={rows.map((r) => r.id)} variant="row" className={className} prefetched={result.data?.sponsored} />
  );
  const orderChips: { mode: OrderMode; label: string }[] = [
    { mode: 'now', label: 'Ordina ora' },
    { mode: 'delivery', label: 'Delivery disponibile' },
    { mode: 'takeaway', label: 'Takeaway disponibile' },
  ];

  const quick: { key: keyof FilterState; label: string }[] = [
    { key: 'openNow', label: 'Aperto ora' },
    { key: 'ayce', label: 'All You Can Eat' },
    { key: 'hasOffers', label: 'Offerte' },
    { key: 'delivery', label: 'Delivery' },
    { key: 'takeaway', label: 'Asporto' },
  ];

  // Vecchi link "?view=map": la mappa ora ha una pagina dedicata
  if (view === 'map') return <Navigate to={`/map?${toParams(filters).toString()}`} replace />;

  return (
    <div className="container-app pb-10 pt-4">
      {/* Barra ricerca sticky */}
      <div className="sticky top-16 z-30 -mx-4 bg-paper/90 px-4 pb-3 pt-2 backdrop-blur-xl sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
        <form
          role="search"
          onSubmit={(e) => {
            e.preventDefault();
            submitQuery(q);
          }}
          className="flex items-center gap-2 rounded-full border border-line bg-white p-1.5 pl-5 shadow-card focus-within:border-ink"
        >
          <Search className="h-5 w-5 shrink-0 text-ink-muted" />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Es. Sushi Taranto, Ramen, nome del locale…"
            aria-label="Cerca ristoranti"
            className="h-10 min-w-0 flex-1 bg-transparent text-[15px] focus:outline-none"
          />
          {q && (
            <button type="button" aria-label="Cancella" onClick={() => update({ ...filters, q: undefined })} className="rounded-full p-2 text-ink-muted hover:bg-cream">
              <X className="h-4 w-4" />
            </button>
          )}
          <button type="submit" className="h-10 rounded-full bg-coral px-5 text-sm font-semibold text-white transition hover:bg-coral-600">
            Cerca
          </button>
        </form>
        <div className="scrollbar-none -mx-4 mt-3 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:px-0">
          <FiltersPanel mode="button" value={filters} onChange={update} geoAvailable={!!geo.coords} onRequestLocation={geo.request} />
          {orderChips.map((oc) => (
            <Chip key={oc.mode} active={filters.orderMode === oc.mode} onClick={() => update({ ...filters, orderMode: filters.orderMode === oc.mode ? undefined : oc.mode })}>
              {oc.label}
            </Chip>
          ))}
          {quick.map((qf) => (
            <Chip key={qf.key} active={!!filters[qf.key]} onClick={() => update({ ...filters, [qf.key]: filters[qf.key] ? undefined : true })}>
              {qf.label}
            </Chip>
          ))}
          <Chip
            active={!!filters.useLocation}
            icon={<LocateFixed className="h-4 w-4" />}
            onClick={() => {
              if (!geo.coords) geo.request();
              update({ ...filters, useLocation: filters.useLocation ? undefined : true, radiusKm: filters.useLocation ? undefined : filters.radiusKm, sort: undefined });
            }}
          >
            {geo.status === 'loading' ? 'Localizzazione…' : 'Usa la mia posizione'}
          </Chip>
        </div>
      </div>

      <div className="mt-4 grid gap-8 lg:grid-cols-[300px_1fr]">
        <div className="hidden lg:block">
          <FiltersPanel mode="sidebar" value={filters} onChange={update} geoAvailable={!!geo.coords} onRequestLocation={geo.request} />
        </div>

        <div className="min-w-0">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
            <div>
              <h1 className="text-2xl font-extrabold sm:text-3xl">{filters.q ? `“${filters.q}”` : heading}</h1>
              <p className="mt-1 text-sm text-ink-muted" aria-live="polite">
                {result.loading ? 'Ricerca in corso…' : `${rows.length} ${rows.length === 1 ? 'locale trovato' : 'locali trovati'}`}
                {filters.useLocation && geo.status === 'denied' && ' · posizione non autorizzata'}
                {filters.useLocation && geo.status === 'unavailable' && ' · geolocalizzazione non supportata'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <AskAiButton from="explore" label="Chiedi all’assistente" className="hidden !h-10 sm:inline-flex" prompt={filters.q || undefined} />
              <Select
                value={filters.sort ?? defaultSort}
                onChange={(e) => update({ ...filters, sort: e.target.value as SortKey })}
                className="!h-10 !w-auto !rounded-full !py-0 text-sm"
                aria-label="Ordina"
              >
                {SORT_OPTIONS.filter((o) => o.value !== 'distance' || near).map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </Select>
              <div className="flex rounded-full border border-line bg-white p-1" role="group" aria-label="Vista">
                {(
                  [
                    ['card', LayoutGrid, 'Vista card'],
                    ['list', List, 'Vista lista'],
                    ['map', MapIcon, 'Vista mappa'],
                  ] as const
                ).map(([v, Icon, label]) => (
                  <button
                    key={v}
                    aria-label={label}
                    aria-pressed={view === v}
                    onClick={() => (v === 'map' ? navigate(`/map?${toParams(filters).toString()}`) : setParams(toParams({ ...filters, view: v }), { replace: true }))}
                    className={cn('flex h-8 w-9 items-center justify-center rounded-full transition', view === v ? 'bg-ink text-white' : 'text-ink-muted hover:text-ink')}
                  >
                    <Icon className="h-4 w-4" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {result.error && <EmptyState icon="⚠️" title="Qualcosa è andato storto" text={result.error.message} />}

          {!result.loading && !result.error && rows.length === 0 && (
            <EmptyState
              icon="🥢"
              title="Nessun locale trovato"
              text="Prova a rimuovere qualche filtro o a cercare in un altro comune."
              action={
                <button onClick={() => update({})} className="rounded-full bg-ink px-5 py-2.5 text-sm font-semibold text-white">
                  Azzera i filtri
                </button>
              }
            />
          )}

          {/* Slot sponsorizzati dopo la prima riga di risultati: mai sopra i contenuti già visibili (niente layout shift) */}

          {view === 'card' && (
            <div className="grid gap-x-5 gap-y-8 sm:grid-cols-2 xl:grid-cols-3">
              {result.loading ? Array.from({ length: 6 }, (_, i) => <CardSkeleton key={i} />) : rows.map((r, i) => (
                <Fragment key={r.id}>
                  <RestaurantCard r={r} eager={i < 3} source="explore" />
                  {i === Math.min(2, rows.length - 1) && sponsoredRow('col-span-full')}
                </Fragment>
              ))}
            </div>
          )}

          {view === 'list' && (
            <div className="space-y-3">
              {result.loading
                ? Array.from({ length: 5 }, (_, i) => <div key={i} className="skeleton h-32 rounded-3xl" />)
                : rows.map((r, i) => (
                  <Fragment key={r.id}>
                    <RestaurantRow r={r} />
                    {i === Math.min(2, rows.length - 1) && sponsoredRow('')}
                  </Fragment>
                ))}
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
