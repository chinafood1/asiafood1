import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { Link, NavLink, Navigate, Outlet, useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  AlertTriangle, ArrowLeft, Bike, Camera, Check, CheckCircle2, ChevronRight, Clock, FileText, Home, LifeBuoy, MapPin, Navigation, Package, Phone,
  Power, Radio, ShieldCheck, Store, Upload, Wallet, WifiOff,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { cn, formatPrice } from '@/lib/format';
import { navigationLinks, keepScreenOn, isAppleDevice } from '@/lib/rider/device';
import { enqueue, flushQueue, isSafeAction } from '@/lib/rider/offlineQueue';
import { RiderTracker } from '@/lib/rider/tracker';
import { useSeo } from '@/lib/seo';
import { api, isDemoMode } from '@/services';
import type { LocationResult, OfferRejectReason, RiderDocumentType, RiderHome, RiderJob, RiderJobAction, VehicleType } from '@/types/logistics';
import { DOCUMENT_TYPE_LABEL, JOB_STATUS_LABEL, LICENSE_VEHICLES, OFFER_REJECT_REASONS, RIDER_PROBLEM_TYPES, VEHICLE_LABEL } from '@/types/logistics';
import { Badge } from '@/components/ui/Badge';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader, Spinner } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { DeliveryMap, JobStatusBadge, RiderStatusBadge, etaRangeText, minutesUntil } from '@/components/logistics/LogisticsParts';

const LOCATION_NOTICE = 'AsiaFood utilizza la tua posizione mentre sei online per assegnarti e gestire le consegne.';
const errMsg = (e: unknown) => (e instanceof Error ? e.message : 'Operazione non riuscita.');

// ═════════════════════════════════════════════════════════════
//  Contesto Rider: stato, tracciamento GPS (solo online), connessione
// ═════════════════════════════════════════════════════════════
interface RiderCtx {
  home: RiderHome | null;
  loading: boolean;
  reload: () => Promise<void>;
  online: boolean;
  tracking: boolean;
  lastLocation: LocationResult | null;
  gpsError: string | null;
  networkOnline: boolean;
  setOnline: (v: boolean, consent: boolean) => Promise<void>;
}
const Ctx = createContext<RiderCtx | null>(null);
const useRider = () => useContext(Ctx)!;

function useNetworkStatus() {
  const [on, setOn] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));
  useEffect(() => {
    const up = () => setOn(true);
    const down = () => setOn(false);
    window.addEventListener('online', up);
    window.addEventListener('offline', down);
    return () => {
      window.removeEventListener('online', up);
      window.removeEventListener('offline', down);
    };
  }, []);
  return on;
}

/** Area Rider (/rider/*): mobile-first, con barra di stato sempre visibile. */
export function RiderArea() {
  const { user, loading: authLoading } = useAuth();
  const location = useLocation();
  const [home, setHome] = useState<RiderHome | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastLocation, setLastLocation] = useState<LocationResult | null>(null);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const networkOnline = useNetworkStatus();
  const trackerRef = useRef<RiderTracker | null>(null);
  useSeo({ title: 'App Rider', noindex: true });

  const reload = useCallback(async () => {
    try {
      setHome(await api.getRiderHome());
    } catch {
      /* rete assente: si mostra l'ultimo stato noto */
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    if (user) void reload();
  }, [user, reload]);

  const online = !!home?.availability?.is_online;
  const hasActive = (home?.active?.length ?? 0) > 0;
  // Polling leggero delle offerte solo quando online (ogni 5 s), altrimenti niente
  useEffect(() => {
    if (!online) return;
    const t = window.setInterval(() => void reload(), 5_000);
    return () => window.clearInterval(t);
  }, [online, reload]);
  // GPS: attivo SOLO online; alta precisione solo con consegna attiva
  useEffect(() => {
    if (!online) {
      trackerRef.current?.stop();
      return;
    }
    trackerRef.current ??= new RiderTracker({
      send: (p) => api.riderSendLocation(p),
      onResult: (r) => {
        setLastLocation(r);
        setGpsError(null);
      },
      onError: setGpsError,
    });
    const s = home?.settings;
    trackerRef.current.start({ intervalSeconds: hasActive ? s?.interval_active ?? 15 : s?.interval_idle ?? 60, highAccuracy: hasActive });
    void trackerRef.current.sendNow();
  }, [online, hasActive, home?.settings]);
  useEffect(() => () => trackerRef.current?.stop(), []);
  // Schermo acceso solo durante una consegna attiva
  useEffect(() => {
    void keepScreenOn(hasActive);
    return () => void keepScreenOn(false);
  }, [hasActive]);
  // Ritorno della rete: invio delle azioni sicure in coda
  useEffect(() => {
    if (!networkOnline) return;
    void flushQueue((job, action) => api.riderJobAction(job, action)).then((n) => { if (n > 0) void reload(); });
  }, [networkOnline, reload]);

  const setOnline = useCallback(async (v: boolean, consent: boolean) => {
    await api.riderSetOnline(v, consent);
    if (!v) trackerRef.current?.stop();
    await reload();
  }, [reload]);

  const value = useMemo<RiderCtx>(() => ({ home, loading, reload, online, tracking: online && !!trackerRef.current?.active, lastLocation, gpsError, networkOnline, setOnline }),
    [home, loading, reload, online, lastLocation, gpsError, networkOnline, setOnline]);

  if (authLoading) return <PageLoader />;
  if (!user) return <Navigate to={`/accedi?next=${encodeURIComponent(location.pathname)}`} replace />;
  return (
    <Ctx.Provider value={value}>
      <div className="min-h-dvh bg-paper pb-24">
        <header className="sticky top-0 z-30 border-b border-line bg-white/95 backdrop-blur">
          <div className="mx-auto flex max-w-xl items-center justify-between gap-3 px-4 py-3">
            <Link to="/" className="text-sm font-bold">AsiaFood <span className="text-coral">Rider</span></Link>
            <div className="flex items-center gap-2 text-xs font-semibold">
              {!networkOnline && <span className="inline-flex items-center gap-1 rounded-full bg-coral-50 px-2.5 py-1 text-coral-700" role="status"><WifiOff className="h-3.5 w-3.5" /> Offline</span>}
              {online ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-emerald-800" role="status" data-testid="location-active">
                  <Radio className="h-3.5 w-3.5" /> Posizione attiva
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 rounded-full bg-cream px-2.5 py-1 text-ink-muted" role="status">Tracciamento disattivato</span>
              )}
            </div>
          </div>
        </header>
        <main className="mx-auto max-w-xl px-4 pt-4">
          {loading && !home ? <PageLoader /> : <Outlet />}
        </main>
        {home?.rider && ['approved', 'active'].includes(home.rider.status) && (
          <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white" aria-label="Navigazione Rider">
            <div className="mx-auto grid max-w-xl grid-cols-2">
              {[{ to: '/rider', label: 'Consegne', icon: Home, end: true }, { to: '/rider/earnings', label: 'Guadagni', icon: Wallet }].map((x) => (
                <NavLink key={x.to} to={x.to} end={x.end} className={({ isActive }) => cn('flex flex-col items-center gap-0.5 py-2.5 text-xs font-semibold', isActive ? 'text-coral' : 'text-ink-muted')}>
                  <x.icon className="h-5 w-5" /> {x.label}
                </NavLink>
              ))}
            </div>
          </nav>
        )}
      </div>
    </Ctx.Provider>
  );
}

// ═════════════════════════════════════════════════════════════
//  /rider — Home
// ═════════════════════════════════════════════════════════════
export function RiderHomePage() {
  const { home, reload, online, setOnline, gpsError, lastLocation } = useRider();
  const toast = useToast();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [consentOpen, setConsentOpen] = useState(false);
  const [consent, setConsent] = useState(false);
  const [rejecting, setRejecting] = useState(false);
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const r = home?.rider;
  if (!r) {
    return (
      <EmptyState icon="🛵" title="Diventa Rider AsiaFood" text="Consegna i piatti dei ristoranti asiatici della tua città con i tuoi orari."
        action={<ButtonLink to="/rider/apply">Candidati</ButtonLink>} />
    );
  }
  if (!['approved', 'active'].includes(r.status)) return <RiderStatusScreen />;

  const toggle = async () => {
    if (!online && !r.location_consent) {
      setConsentOpen(true);
      return;
    }
    setBusy(true);
    try {
      await setOnline(!online, false);
      toast(online ? 'Sei offline: tracciamento disattivato.' : 'Sei online.');
    } catch (e) {
      toast(errMsg(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const goOnlineWithConsent = async () => {
    setBusy(true);
    try {
      await setOnline(true, true);
      setConsentOpen(false);
      toast('Sei online.');
    } catch (e) {
      toast(errMsg(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const respond = async (accept: boolean, reason?: OfferRejectReason) => {
    if (!home?.offer) return;
    setBusy(true);
    try {
      const res = await api.riderRespondOffer(home.offer.assignment_id, accept, reason ?? null);
      setRejecting(false);
      if (accept && res.delivery_job_id) {
        void api.refreshDeliveryEta(res.delivery_job_id);
        navigate(`/rider/delivery/${res.delivery_job_id}`);
      } else toast('Offerta rifiutata.');
      await reload();
    } catch (e) {
      toast(errMsg(e), 'error');
      await reload();
    } finally {
      setBusy(false);
    }
  };
  const offer = home?.offer;
  const secondsLeft = offer ? Math.max(0, Math.round((Date.parse(offer.expires_at) - now) / 1000)) : 0;

  return (
    <div className="space-y-4">
      <section className={cn('rounded-4xl p-5 text-white shadow-lift', online ? 'bg-emerald-600' : 'bg-ink')}>
        <p className="text-sm opacity-80">Ciao {r.first_name}</p>
        <div className="mt-2 flex items-center justify-between gap-3">
          <div>
            <p className="text-2xl font-extrabold">{online ? 'ONLINE' : 'OFFLINE'}</p>
            <p className="text-sm opacity-90">{online ? (home?.active?.length ? 'Consegna in corso' : 'Stai cercando consegne…') : 'Vai online per ricevere consegne.'}</p>
          </div>
          <button type="button" onClick={() => void toggle()} disabled={busy} role="switch" aria-checked={online} aria-label={online ? 'Vai offline' : 'Vai online'} data-testid="rider-online-toggle"
            className={cn('flex h-16 w-16 items-center justify-center rounded-full border-4 transition', online ? 'border-white bg-white text-emerald-700' : 'border-white/40 bg-white/10 text-white')}>
            {busy ? <Spinner className="h-6 w-6" /> : <Power className="h-7 w-7" />}
          </button>
        </div>
        {online && <p className="mt-3 flex items-start gap-2 text-xs opacity-90"><MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {LOCATION_NOTICE} Offline = posizione non condivisa.</p>}
      </section>

      {gpsError && <Alert tone="error">{gpsError}</Alert>}
      {lastLocation?.reason === 'ANOMALY' && <Alert tone="error">La posizione ricevuta sembra non valida: controlla il GPS del telefono.</Alert>}

      {offer && secondsLeft > 0 && (
        <section className="rounded-4xl border-2 border-coral bg-white p-5 shadow-lift" data-testid="rider-offer" aria-live="assertive">
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold uppercase tracking-wider text-coral">Nuova consegna</p>
            <span className={cn('rounded-full px-3 py-1 text-sm font-bold tabular-nums', secondsLeft <= 10 ? 'bg-coral text-white' : 'bg-cream')} aria-label={`${secondsLeft} secondi per rispondere`}>{secondsLeft}s</span>
          </div>
          <p className="mt-2 text-xl font-extrabold">{offer.restaurant.name}</p>
          <p className="text-sm text-ink-muted">{offer.restaurant.address}{offer.restaurant.city ? `, ${offer.restaurant.city}` : ''}</p>
          <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-2xl bg-cream/70 p-3"><dt className="text-ink-muted">Compenso stimato</dt><dd className="text-lg font-bold">{offer.estimated_earning != null ? formatPrice(offer.estimated_earning) : '—'}</dd></div>
            <div className="rounded-2xl bg-cream/70 p-3"><dt className="text-ink-muted">Distanza totale</dt><dd className="text-lg font-bold">{((offer.distance_to_pickup_km ?? 0) + (offer.delivery_distance_km ?? 0)).toFixed(1).replace('.', ',')} km</dd></div>
            <div className="rounded-2xl bg-cream/70 p-3"><dt className="text-ink-muted">Zona di consegna</dt><dd className="font-semibold">{offer.delivery_area || '—'}</dd></div>
            <div className="rounded-2xl bg-cream/70 p-3"><dt className="text-ink-muted">Tempo stimato</dt><dd className="font-semibold">~{offer.estimated_minutes} min</dd></div>
          </dl>
          <p className="mt-3 text-xs text-ink-muted">Ordine {offer.order_number}{offer.ready_at ? ` · pronto verso le ${new Date(offer.ready_at).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}` : ''}. L’indirizzo completo appare dopo l’accettazione.</p>
          <div className="mt-4 grid grid-cols-[1fr_auto] gap-2">
            <Button size="lg" onClick={() => void respond(true)} loading={busy} data-testid="accept-offer"><CheckCircle2 className="h-5 w-5" /> Accetta</Button>
            <Button size="lg" variant="outline" onClick={() => setRejecting(true)} disabled={busy} data-testid="reject-offer">Rifiuta</Button>
          </div>
        </section>
      )}

      {(home?.active ?? []).map((j) => (
        <Link key={j.id} to={`/rider/delivery/${j.id}`} className="flex items-center justify-between gap-3 rounded-3xl border border-line bg-white p-4" data-testid="active-delivery">
          <span>
            <span className="block font-bold">{j.restaurant}</span>
            <span className="text-sm text-ink-muted">{j.order_number} · {JOB_STATUS_LABEL[j.status]}</span>
          </span>
          <ChevronRight className="h-5 w-5 text-ink-muted" />
        </Link>
      ))}

      {online && !offer && !(home?.active ?? []).length && (
        <div className="flex flex-col items-center gap-3 rounded-4xl border border-dashed border-line bg-white p-8 text-center">
          <span className="relative flex h-12 w-12 items-center justify-center"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-300 opacity-60" /><Bike className="relative h-7 w-7 text-emerald-700" /></span>
          <p className="font-semibold">Stai cercando consegne…</p>
          <p className="text-sm text-ink-muted">Ti avvisiamo appena c’è un ordine vicino a te.</p>
        </div>
      )}

      {home?.stats && (
        <section className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-3xl bg-white p-3"><p className="text-xl font-extrabold">{home.stats.completed}</p><p className="text-xs text-ink-muted">Consegne</p></div>
          <div className="rounded-3xl bg-white p-3"><p className="text-xl font-extrabold">{home.stats.completion_rate != null ? `${Math.round(home.stats.completion_rate * 100)}%` : '—'}</p><p className="text-xs text-ink-muted">Completate</p></div>
          <div className="rounded-3xl bg-white p-3"><p className="text-xl font-extrabold">{home.stats.avg_delivery_minutes != null ? `${Math.round(home.stats.avg_delivery_minutes)}′` : '—'}</p><p className="text-xs text-ink-muted">Tempo medio</p></div>
        </section>
      )}
      <p className="text-center text-xs text-ink-faint">Le statistiche sono visibili solo a te. Nessuna classifica pubblica dei Rider.</p>

      <Sheet open={consentOpen} onClose={() => setConsentOpen(false)} title="Posizione durante i turni"
        footer={<Button className="w-full" size="lg" disabled={!consent} loading={busy} onClick={() => void goOnlineWithConsent()} data-testid="consent-go-online">Autorizza e vai online</Button>}>
        <p className="text-sm">{LOCATION_NOTICE}</p>
        <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-ink-muted">
          <li>La posizione è condivisa solo mentre sei online (indicatore “Posizione attiva”).</li>
          <li>Il cliente la vede solo dopo il ritiro del suo ordine; il ristorante solo per sapere quando arrivi.</li>
          <li>Lo storico preciso viene cancellato automaticamente dopo poche ore.</li>
        </ul>
        <label className="mt-4 flex items-start gap-3 text-sm font-medium">
          <input type="checkbox" className="mt-0.5 h-5 w-5 accent-coral" checked={consent} onChange={(e) => setConsent(e.target.checked)} data-testid="consent-check" />
          Ho capito e autorizzo l’uso della posizione mentre sono online.
        </label>
      </Sheet>

      <Sheet open={rejecting} onClose={() => setRejecting(false)} title="Perché rifiuti?">
        <div className="grid gap-2">
          {OFFER_REJECT_REASONS.map((x) => <Button key={x.value} variant="outline" onClick={() => void respond(false, x.value)} disabled={busy}>{x.label}</Button>)}
        </div>
        <p className="mt-3 text-xs text-ink-muted">Il motivo è facoltativo e non comporta penalità automatiche.</p>
      </Sheet>
    </div>
  );
}

function RiderStatusScreen() {
  const { home } = useRider();
  const r = home!.rider!;
  return (
    <div className="space-y-4">
      <section className="card p-6 text-center">
        <RiderStatusBadge status={r.status} />
        <h1 className="mt-3 text-xl font-extrabold">
          {r.status === 'pending' ? 'Candidatura in verifica' : r.status === 'suspended' ? 'Profilo sospeso' : r.status === 'rejected' ? 'Candidatura non approvata' : 'Profilo non attivo'}
        </h1>
        <p className="mt-2 text-sm text-ink-muted">
          {r.status === 'pending' ? 'Lo staff AsiaFood controlla dati e documenti: riceverai una notifica appena la candidatura sarà approvata.'
            : r.status === 'suspended' ? r.suspension_reason ?? 'Contatta il supporto per maggiori informazioni.'
              : r.status === 'rejected' ? r.rejected_reason ?? 'Puoi inviare una nuova candidatura con dati aggiornati.' : 'Contatta il supporto per riattivarlo.'}
        </p>
        {r.status === 'rejected' && <ButtonLink to="/rider/apply" className="mt-4">Nuova candidatura</ButtonLink>}
      </section>
      <DocumentsPanel />
    </div>
  );
}

function DocumentsPanel() {
  const { home, reload } = useRider();
  const toast = useToast();
  const [type, setType] = useState<RiderDocumentType>('identity');
  const [busy, setBusy] = useState(false);
  const docs = home?.rider?.documents ?? [];
  const upload = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    try {
      await api.riderUploadDocument(type, file, null);
      toast('Documento caricato: lo staff lo verificherà.');
      await reload();
    } catch (e) {
      toast(errMsg(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="card p-5">
      <h2 className="font-bold">Documenti</h2>
      <p className="text-xs text-ink-muted">Archivio privato: li vedono solo lo staff AsiaFood e tu.{isDemoMode ? ' (DEMO: il file non viene caricato.)' : ''}</p>
      <ul className="mt-3 space-y-1.5 text-sm">
        {docs.map((d) => <li key={d.id} className="flex items-center justify-between"><span><FileText className="mr-1 inline h-4 w-4" />{DOCUMENT_TYPE_LABEL[d.type]}</span><Badge tone={d.status === 'approved' ? 'green' : d.status === 'rejected' || d.status === 'expired' ? 'coral' : 'amber'}>{d.status === 'approved' ? 'Approvato' : d.status === 'rejected' ? 'Rifiutato' : d.status === 'expired' ? 'Scaduto' : 'In verifica'}</Badge></li>)}
        {!docs.length && <li className="text-ink-muted">Nessun documento caricato.</li>}
      </ul>
      <div className="mt-3 flex gap-2">
        <Select aria-label="Tipo di documento" value={type} onChange={(e) => setType(e.target.value as RiderDocumentType)}>
          {Object.entries(DOCUMENT_TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
        <label className={cn('inline-flex h-12 shrink-0 cursor-pointer items-center gap-2 rounded-full border border-line bg-white px-4 text-sm font-semibold', busy && 'opacity-50')}>
          <Upload className="h-4 w-4" /> Carica
          <input type="file" className="sr-only" accept="application/pdf,image/jpeg,image/png,image/webp" disabled={busy} onChange={(e) => void upload(e.target.files?.[0])} />
        </label>
      </div>
    </section>
  );
}

// ═════════════════════════════════════════════════════════════
//  /rider/delivery/:id — consegna passo per passo
// ═════════════════════════════════════════════════════════════
export function RiderDeliveryPage() {
  const { id = '' } = useParams();
  const { reload: reloadHome, lastLocation, networkOnline } = useRider();
  const toast = useToast();
  const navigate = useNavigate();
  const [job, setJob] = useState<RiderJob | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [pickupCode, setPickupCode] = useState('');
  const [deliveryCode, setDeliveryCode] = useState('');
  const [photoPath, setPhotoPath] = useState<string | null>(null);
  const [problemOpen, setProblemOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [unavailableOpen, setUnavailableOpen] = useState(false);
  const [now, setNow] = useState(Date.now());

  const load = useCallback(async () => {
    try {
      setJob(await api.getRiderJob(id));
      setError(null);
    } catch (e) {
      setError(errMsg(e));
    }
  }, [id]);
  useEffect(() => {
    void load();
    const t = window.setInterval(() => {
      setNow(Date.now());
      void load();
    }, 15_000);
    return () => window.clearInterval(t);
  }, [load]);

  const act = async (action: RiderJobAction, payload: Record<string, unknown> = {}, okMsg?: string) => {
    if (!networkOnline) {
      if (isSafeAction(action)) {
        enqueue(id, action);
        toast('Sei offline: l’azione verrà inviata appena torna la connessione.');
      } else toast('Serve la connessione per questa azione: riprova appena torna la rete.', 'error');
      return;
    }
    setBusy(action);
    try {
      const res = await api.riderJobAction(id, action, payload);
      if ('order_number' in res) setJob(res);
      if (okMsg) toast(okMsg);
      if (action === 'picked_up') void api.refreshDeliveryEta(id);
      if (action === 'cancel' || (('status' in res) && ['delivered', 'failed'].includes(res.status))) {
        await reloadHome();
        if (action === 'cancel') navigate('/rider');
      }
    } catch (e) {
      toast(errMsg(e), 'error');
    } finally {
      setBusy(null);
    }
  };

  if (error && !job) return <EmptyState icon="🔒" title="Consegna non disponibile" text={error} action={<ButtonLink to="/rider">Torna alla home</ButtonLink>} />;
  if (!job) return <PageLoader />;
  const toRestaurant = ['assigned', 'rider_to_restaurant'].includes(job.status);
  const atRestaurant = job.status === 'arrived_restaurant';
  const toCustomer = ['picked_up', 'rider_to_customer'].includes(job.status);
  const atCustomer = job.status === 'arrived_customer';
  const done = ['delivered', 'failed', 'cancelled'].includes(job.status);
  const step = toRestaurant ? (job.status === 'assigned' ? 1 : 1) : atRestaurant ? 3 : toCustomer ? 4 : atCustomer ? 5 : 6;
  const dest = toRestaurant || atRestaurant ? { lat: job.restaurant.latitude, lng: job.restaurant.longitude, label: job.restaurant.name } : { lat: job.customer?.latitude ?? null, lng: job.customer?.longitude ?? null, label: 'Cliente' };
  const links = dest.lat != null && dest.lng != null ? navigationLinks(dest.lat, dest.lng, dest.label) : null;
  const hint = lastLocation?.hint;
  const waitStart = job.customer_wait_started_at ? Date.parse(job.customer_wait_started_at) : null;
  const waitLeft = waitStart ? Math.max(0, Math.ceil((waitStart + job.customer_wait_minutes * 60_000 - now) / 60_000)) : null;
  const addr = job.customer?.address;

  return (
    <div className="space-y-4" data-testid="rider-delivery">
      <Link to="/rider" className="inline-flex items-center gap-1 text-sm font-semibold text-ink-muted"><ArrowLeft className="h-4 w-4" /> Home</Link>
      <header className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-sm font-bold text-ink-muted">{job.order_number}</p>
          <h1 className="text-2xl font-extrabold">{toRestaurant || atRestaurant ? job.restaurant.name : done ? JOB_STATUS_LABEL[job.status] : `Consegna a ${job.customer?.name ?? 'cliente'}`}</h1>
        </div>
        <JobStatusBadge status={job.status} />
      </header>

      {!done && (
        <ol className="grid grid-cols-6 gap-1" aria-label="Avanzamento">
          {['Vai al ristorante', 'Arrivato', 'Ritirato', 'Vai al cliente', 'Arrivato', 'Consegnato'].map((l, i) => (
            <li key={l + i} className={cn('h-1.5 rounded-full', i < step ? 'bg-emerald-500' : 'bg-line')} title={l}><span className="sr-only">{l}{i < step ? ' (fatto)' : ''}</span></li>
          ))}
        </ol>
      )}

      {!done && (
        <DeliveryMap ariaLabel="Mappa della consegna" markers={[
          { id: 'pickup', lat: job.restaurant.latitude, lng: job.restaurant.longitude, label: job.restaurant.name, emoji: '🍣' },
          { id: 'dropoff', lat: job.customer?.latitude, lng: job.customer?.longitude, label: 'Consegna', emoji: '🏠' },
        ]} />
      )}

      {hint === 'near_restaurant' && toRestaurant && <Alert tone="success">Sembri arrivato al ristorante: conferma quando sei sul posto.</Alert>}
      {hint === 'near_customer' && toCustomer && <Alert tone="success">Sembri arrivato all’indirizzo: conferma quando sei sul posto.</Alert>}

      {/* FASI 1–3: ristorante */}
      {(toRestaurant || atRestaurant) && (
        <section className="card space-y-3 p-5">
          <p className="flex items-center gap-2 font-bold"><Store className="h-5 w-5 text-coral" /> {atRestaurant ? 'Ritira l’ordine' : 'Vai al ristorante'}</p>
          <p className="text-sm">{job.restaurant.address}{job.restaurant.city ? `, ${job.restaurant.city}` : ''}</p>
          {job.eta_pickup_at && toRestaurant && <p className="text-sm text-ink-muted">Arrivo stimato tra circa {minutesUntil(job.eta_pickup_at, now)} min · pronto verso le {job.estimated_ready_at ? new Date(job.estimated_ready_at).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) : '—'}{job.ready ? ' (già pronto)' : ''}</p>}
          {atRestaurant && (
            <div className="rounded-2xl bg-cream/70 p-3 text-sm">
              <p className="font-semibold">Da ritirare:</p>
              <ul className="mt-1 list-disc pl-5">{job.items.map((i, k) => <li key={k}>{i.quantity}× {i.name}{i.variant ? ` (${i.variant})` : ''}</li>)}</ul>
              {job.restaurant_notes && <p className="mt-2 text-ink-muted">Note del ristorante: {job.restaurant_notes}</p>}
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            {links && toRestaurant && <NavButtons links={links} onOpen={() => job.status === 'assigned' && void act('depart')} />}
            {job.restaurant.phone && <a href={`tel:${job.restaurant.phone.replace(/\s+/g, '')}`} className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-white px-4 text-sm font-semibold"><Phone className="h-4 w-4" /> Ristorante</a>}
          </div>
          {toRestaurant && <Button size="lg" className="w-full" loading={busy === 'arrived_restaurant'} onClick={() => void act('arrived_restaurant', {}, 'Arrivo confermato.')} data-testid="rider-arrived-restaurant"><MapPin className="h-5 w-5" /> Sono arrivato</Button>}
          {atRestaurant && (
            <form className="space-y-2" onSubmit={(e: FormEvent) => { e.preventDefault(); void act('picked_up', { pickup_code: pickupCode }, 'Ordine ritirato: vai dal cliente.'); }}>
              {job.pickup_code_required && (
                <Field label="Codice di ritiro (te lo comunica il ristorante)" hint="4 cifre, stampate sulla comanda dell’ordine.">
                  <Input inputMode="numeric" maxLength={4} value={pickupCode} onChange={(e) => setPickupCode(e.target.value.replace(/\D/g, ''))} data-testid="pickup-code" autoComplete="one-time-code" />
                </Field>
              )}
              <Button type="submit" size="lg" className="w-full" loading={busy === 'picked_up'} disabled={job.pickup_code_required && pickupCode.length !== 4} data-testid="rider-picked-up"><Package className="h-5 w-5" /> Ordine ritirato</Button>
              <Button type="button" variant="ghost" className="w-full" loading={busy === 'not_ready'} onClick={() => void act('not_ready', {}, 'Segnalato: il ristorante è stato avvisato.')}><Clock className="h-4 w-4" /> Ordine non pronto</Button>
            </form>
          )}
          <button type="button" className="text-sm font-semibold text-ink-muted underline" onClick={() => setCancelOpen(true)}>Non posso ritirare questo ordine</button>
        </section>
      )}

      {/* FASI 4–6: cliente */}
      {(toCustomer || atCustomer) && job.customer && (
        <section className="card space-y-3 p-5">
          <p className="flex items-center gap-2 font-bold"><MapPin className="h-5 w-5 text-coral" /> {atCustomer ? 'Consegna al cliente' : 'Vai al cliente'}</p>
          <p className="text-sm font-semibold">{addr?.address_line_1}{addr?.address_line_2 ? `, ${addr.address_line_2}` : ''}<br />{addr?.postal_code} {addr?.city}</p>
          {(addr?.delivery_notes || job.customer.notes) && <p className="rounded-2xl bg-amber-50 p-3 text-sm text-amber-900">{addr?.delivery_notes}{addr?.delivery_notes && job.customer.notes ? ' · ' : ''}{job.customer.notes}</p>}
          {toCustomer && etaRangeText(job.eta_delivery_min_at, job.eta_delivery_max_at, now) && <p className="text-sm text-ink-muted">Tempo stimato: {etaRangeText(job.eta_delivery_min_at, job.eta_delivery_max_at, now)}</p>}
          <div className="flex flex-wrap gap-2">
            {links && toCustomer && <NavButtons links={links} />}
            {job.customer.phone && <a href={`tel:${job.customer.phone.replace(/\s+/g, '')}`} className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-white px-4 text-sm font-semibold" data-testid="call-customer"><Phone className="h-4 w-4" /> Chiama {job.customer.name}</a>}
          </div>
          {toCustomer && <Button size="lg" className="w-full" loading={busy === 'arrived_customer'} onClick={() => void act('arrived_customer', {}, 'Arrivo confermato.')} data-testid="rider-arrived-customer"><MapPin className="h-5 w-5" /> Sono arrivato</Button>}
          {atCustomer && (
            <form className="space-y-3" onSubmit={(e: FormEvent) => { e.preventDefault(); void act('delivered', { delivery_code: deliveryCode, photo_path: photoPath }, 'Consegna completata. Grazie!'); }}>
              {job.delivery_code_required && (
                <Field label="Codice di consegna (lo trovi chiedendolo al cliente)">
                  <Input inputMode="numeric" maxLength={4} value={deliveryCode} onChange={(e) => setDeliveryCode(e.target.value.replace(/\D/g, ''))} data-testid="delivery-code" autoComplete="one-time-code" />
                </Field>
              )}
              {job.proof_type === 'photo' && <ProofPhoto jobId={job.id} value={photoPath} onChange={setPhotoPath} />}
              <Button type="submit" size="lg" className="w-full" loading={busy === 'delivered'} disabled={(job.delivery_code_required && deliveryCode.length !== 4) || (job.proof_type === 'photo' && !photoPath)} data-testid="rider-delivered">
                <CheckCircle2 className="h-5 w-5" /> Consegna completata
              </Button>
            </form>
          )}
          <Button variant="outline" className="w-full" onClick={() => setUnavailableOpen(true)} data-testid="customer-unavailable">Cliente non disponibile</Button>
        </section>
      )}

      {done && (
        <section className="card p-6 text-center">
          {job.status === 'delivered' ? <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" /> : <AlertTriangle className="mx-auto h-12 w-12 text-coral" />}
          <p className="mt-2 text-xl font-extrabold">{JOB_STATUS_LABEL[job.status]}</p>
          {job.earning.total != null && <p className="mt-1 text-sm">{job.earning.final ? 'Compenso registrato' : 'Compenso stimato'}: <strong>{formatPrice(job.earning.total)}</strong></p>}
          <ButtonLink to="/rider" className="mt-4">Torna alle consegne</ButtonLink>
        </section>
      )}

      {!done && (
        <div className="rounded-3xl bg-white p-4 text-sm">
          <p className="flex items-center justify-between"><span className="text-ink-muted">{job.earning.final ? 'Compenso' : 'Compenso stimato'}</span><strong>{job.earning.total != null ? formatPrice(job.earning.total) : '—'}</strong></p>
          <p className="flex items-center justify-between"><span className="text-ink-muted">Distanza ristorante → cliente</span><span>{job.distance_km != null ? `${Number(job.distance_km).toFixed(1).replace('.', ',')} km` : '—'}</span></p>
        </div>
      )}
      {!done && <Button variant="danger" className="w-full" onClick={() => setProblemOpen(true)} data-testid="rider-problem"><LifeBuoy className="h-4 w-4" /> Ho un problema</Button>}

      <ProblemSheet open={problemOpen} onClose={() => setProblemOpen(false)} onSend={async (type, description) => { await act('problem', { type, description }, 'Segnalazione inviata al supporto.'); setProblemOpen(false); }} />
      <Sheet open={cancelOpen} onClose={() => setCancelOpen(false)} title="Non puoi ritirare l’ordine?">
        <p className="text-sm text-ink-muted">La consegna tornerà disponibile per un altro Rider. Nessuna penalità automatica.</p>
        <div className="mt-3 grid gap-2">
          {OFFER_REJECT_REASONS.map((x) => <Button key={x.value} variant="outline" loading={busy === 'cancel'} onClick={() => { setCancelOpen(false); void act('cancel', { reason: x.value }, 'Consegna rilasciata.'); }}>{x.label}</Button>)}
        </div>
      </Sheet>
      <Sheet open={unavailableOpen} onClose={() => setUnavailableOpen(false)} title="Cliente non disponibile">
        <ol className="space-y-3 text-sm">
          <li className="flex gap-3"><span className="font-bold">1.</span><span>Chiama il cliente {job.customer?.phone && <a className="font-semibold text-coral-700 underline" href={`tel:${job.customer.phone.replace(/\s+/g, '')}`}>{job.customer.phone}</a>}</span></li>
          <li className="flex gap-3"><span className="font-bold">2.</span><span>Attendi almeno {job.customer_wait_minutes} minuti all’indirizzo.{waitLeft != null && <strong> {waitLeft > 0 ? `Ancora ${waitLeft} min.` : 'Tempo di attesa trascorso.'}</strong>}</span></li>
          <li className="flex gap-3"><span className="font-bold">3.</span><span>Avvisa il supporto: deciderà cosa fare dell’ordine.</span></li>
        </ol>
        <div className="mt-4 grid gap-2">
          <Button variant="outline" loading={busy === 'customer_unavailable'} onClick={() => void act('customer_unavailable', { step: 'waiting' }, 'Attesa avviata: il cliente è stato avvisato.')} data-testid="start-wait">Avvia attesa e avvisa il cliente</Button>
          <Button variant="outline" onClick={() => void act('customer_unavailable', { step: 'support' }, 'Supporto avvisato.')}>Avvisa il supporto</Button>
          <Button variant="danger" disabled={waitLeft == null || waitLeft > 0} onClick={() => { setUnavailableOpen(false); void act('fail', { reason: 'customer_unavailable' }, 'Consegna chiusa come non riuscita: il supporto gestirà l’ordine.'); }}>
            Chiudi: cliente non trovato
          </Button>
          <p className="text-xs text-ink-muted">La consegna non viene mai completata automaticamente.</p>
        </div>
      </Sheet>
    </div>
  );
}

function NavButtons({ links, onOpen }: { links: ReturnType<typeof navigationLinks>; onOpen?: () => void }) {
  const apple = isAppleDevice();
  return (
    <>
      <a href={apple ? links.apple : links.google} target="_blank" rel="noopener noreferrer" onClick={onOpen} className="inline-flex h-11 items-center gap-2 rounded-full bg-ink px-4 text-sm font-semibold text-white" data-testid="open-navigation">
        <Navigation className="h-4 w-4" /> Apri navigazione
      </a>
      <a href={apple ? links.google : links.apple} target="_blank" rel="noopener noreferrer" onClick={onOpen} className="inline-flex h-11 items-center rounded-full border border-line bg-white px-4 text-sm font-semibold">
        {apple ? 'Google Maps' : 'Apple Maps'}
      </a>
    </>
  );
}

function ProofPhoto({ jobId, value, onChange }: { jobId: string; value: string | null; onChange: (p: string | null) => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <div className="rounded-2xl border border-dashed border-line p-3 text-sm">
      <p className="font-semibold">Foto del pacco consegnato</p>
      <p className="text-xs text-ink-muted">Fotografa solo il pacco o il punto di consegna autorizzato: mai persone, targhe o documenti.</p>
      <label className="mt-2 inline-flex h-11 cursor-pointer items-center gap-2 rounded-full border border-line bg-white px-4 font-semibold">
        {busy ? <Spinner className="h-4 w-4" /> : value ? <Check className="h-4 w-4 text-emerald-600" /> : <Camera className="h-4 w-4" />} {value ? 'Foto acquisita' : 'Scatta foto'}
        <input type="file" accept="image/*" capture="environment" className="sr-only" onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          setBusy(true);
          try {
            onChange(await api.riderUploadProof(jobId, f));
          } catch (err) {
            toast(errMsg(err), 'error');
          } finally {
            setBusy(false);
          }
        }} />
      </label>
    </div>
  );
}

function ProblemSheet({ open, onClose, onSend }: { open: boolean; onClose: () => void; onSend: (type: string, description: string) => Promise<void> }) {
  const [type, setType] = useState('order_problem');
  const [desc, setDesc] = useState('');
  const [busy, setBusy] = useState(false);
  return (
    <Sheet open={open} onClose={onClose} title="Ho un problema"
      footer={<Button className="w-full" loading={busy} onClick={async () => { setBusy(true); await onSend(type, desc); setBusy(false); setDesc(''); }}>Invia al supporto</Button>}>
      <p className="mb-3 rounded-2xl bg-coral-50 p-3 text-sm font-medium text-coral-700" role="note">
        Per un’emergenza reale (incidente con feriti, pericolo) chiama subito il <a className="underline" href="tel:112">112</a>. Questa segnalazione arriva al supporto AsiaFood, non ai servizi di emergenza.
      </p>
      <fieldset className="space-y-2">
        <legend className="sr-only">Tipo di problema</legend>
        {RIDER_PROBLEM_TYPES.map((x) => (
          <label key={x.value} className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border px-4 py-3 text-sm', type === x.value ? 'border-ink' : 'border-line')}>
            <input type="radio" name="problem" checked={type === x.value} onChange={() => setType(x.value)} className="accent-coral" /> {x.label}
          </label>
        ))}
      </fieldset>
      <Field label="Descrizione (facoltativa)" className="mt-3"><Textarea value={desc} maxLength={1000} onChange={(e) => setDesc(e.target.value)} /></Field>
    </Sheet>
  );
}

// ═════════════════════════════════════════════════════════════
//  /rider/earnings
// ═════════════════════════════════════════════════════════════
export function RiderEarningsPage() {
  const data = useAsync(() => api.getRiderEarnings(), []);
  const d = data.data;
  if (data.loading && !d) return <PageLoader />;
  if (data.error) return <Alert tone="error">{data.error.message}</Alert>;
  if (!d) return null;
  const STATUS: Record<string, string> = { pending: 'Da approvare', approved: 'Da pagare', paid: 'Pagato', cancelled: 'Annullato' };
  return (
    <div className="space-y-4" data-testid="rider-earnings">
      <h1 className="text-2xl font-extrabold">Guadagni</h1>
      <div className="grid grid-cols-3 gap-2 text-center">
        {([['Oggi', d.today], ['Settimana', d.week], ['Mese', d.month]] as const).map(([l, v]) => (
          <div key={l} className="rounded-3xl bg-white p-3"><p className="text-lg font-extrabold tabular-nums">{formatPrice(v)}</p><p className="text-xs text-ink-muted">{l}</p></div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-3xl bg-amber-50 p-4"><p className="text-xs text-amber-900">Da pagare</p><p className="text-xl font-extrabold tabular-nums">{formatPrice(d.to_pay)}</p></div>
        <div className="rounded-3xl bg-emerald-50 p-4"><p className="text-xs text-emerald-800">Pagato</p><p className="text-xl font-extrabold tabular-nums">{formatPrice(d.paid)}</p></div>
      </div>
      <p className="text-xs text-ink-muted"><ShieldCheck className="mr-1 inline h-3.5 w-3.5" />I compensi sono calcolati dalle regole AsiaFood (base + distanza) e approvati dallo staff. I pagamenti vengono registrati manualmente: nessun portafoglio prelevabile nell’app.</p>
      <ul className="divide-y divide-line rounded-3xl bg-white">
        {d.items.map((e) => (
          <li key={e.id} className="flex items-center justify-between gap-3 p-4 text-sm">
            <span>
              <span className="block font-semibold">{e.order_number ?? 'Rettifica'}</span>
              <span className="text-xs text-ink-muted">{new Date(e.created_at).toLocaleDateString('it-IT', { day: 'numeric', month: 'short' })} · base {formatPrice(e.base_fee)} + distanza {formatPrice(e.distance_fee)}{e.bonus ? ` + bonus ${formatPrice(e.bonus)}` : ''}{e.adjustment ? ` · rettifica ${formatPrice(e.adjustment)}` : ''}</span>
              {e.note && <span className="block text-xs text-ink-muted">{e.note}</span>}
            </span>
            <span className="text-right"><span className="block font-bold tabular-nums">{formatPrice(e.total)}</span><Badge tone={e.status === 'paid' ? 'green' : e.status === 'cancelled' ? 'coral' : 'amber'}>{STATUS[e.status]}</Badge></span>
          </li>
        ))}
        {!d.items.length && <li className="p-4 text-sm text-ink-muted">Ancora nessun compenso.</li>}
      </ul>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
//  /rider/apply — candidatura in 7 passi
// ═════════════════════════════════════════════════════════════
const STEPS = ['Dati personali', 'Contatti', 'Zona operativa', 'Veicolo', 'Documenti', 'Termini', 'Invio'];

export function RiderApplyPage() {
  useSeo({ title: 'Diventa Rider AsiaFood', path: '/rider/apply', description: 'Consegna con AsiaFood: candidatura Rider in pochi passi, con verifica dei documenti.' });
  const { user, profile } = useAuth();
  const { cities } = useReferenceData();
  const toast = useToast();
  const navigate = useNavigate();
  const home = useAsync(() => (user ? api.getRiderHome() : Promise.resolve(null)), [user?.id]);
  const zones = useAsync(() => api.listServiceZones(), []);
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ first_name: '', last_name: '', phone: '', email: '', city_slug: 'taranto', zone_id: '', vehicle_type: 'scooter' as VehicleType, vehicle_details: '', terms: false });
  const [files, setFiles] = useState<Partial<Record<RiderDocumentType, File>>>({});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    if (profile) {
      const [first, ...rest] = (profile.full_name ?? '').split(' ');
      setF((x) => ({ ...x, first_name: x.first_name || first || '', last_name: x.last_name || rest.join(' '), email: x.email || profile.email || '', phone: x.phone || profile.phone || '' }));
    }
  }, [profile]);

  if (!user) {
    return (
      <div className="container-app max-w-xl py-10">
        <EmptyState icon="🛵" title="Diventa Rider AsiaFood" text="Accedi o crea un account per inviare la candidatura."
          action={<ButtonLink to="/accedi?next=/rider/apply">Accedi per candidarti</ButtonLink>} />
      </div>
    );
  }
  if (home.loading) return <PageLoader />;
  const existing = home.data?.rider;
  if (existing && existing.status !== 'rejected') {
    return (
      <div className="container-app max-w-xl py-10">
        <EmptyState icon="📋" title={existing.status === 'pending' ? 'Candidatura inviata' : 'Sei già un Rider AsiaFood'}
          text={existing.status === 'pending' ? 'Lo staff sta verificando la tua candidatura: ti avviseremo con una notifica.' : 'Apri l’app Rider per andare online.'}
          action={<ButtonLink to="/rider">Apri l’app Rider</ButtonLink>} />
      </div>
    );
  }
  const needsLicense = LICENSE_VEHICLES.includes(f.vehicle_type);
  const valid = [
    f.first_name.trim().length > 0 && f.last_name.trim().length > 0,
    /^\+?[0-9 ]{6,20}$/.test(f.phone) && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email),
    !!f.city_slug,
    !!f.vehicle_type,
    !!files.identity && (!needsLicense || !!files.driving_license),
    f.terms,
    true,
  ];
  const submit = async () => {
    setBusy(true);
    setErr(null);
    try {
      await api.riderApply({ first_name: f.first_name, last_name: f.last_name, phone: f.phone, email: f.email, city_slug: f.city_slug, zone_id: f.zone_id || null,
        vehicle_type: f.vehicle_type, vehicle_details: f.vehicle_details || null, terms_accepted: f.terms });
      for (const [type, file] of Object.entries(files)) if (file) await api.riderUploadDocument(type as RiderDocumentType, file, null);
      toast('Candidatura inviata! Ti avviseremo dopo la verifica.');
      navigate('/rider');
    } catch (e) {
      setErr(errMsg(e));
    } finally {
      setBusy(false);
    }
  };
  const fileInput = (type: RiderDocumentType, required: boolean) => (
    <label key={type} className="flex items-center justify-between gap-3 rounded-2xl border border-line bg-white px-4 py-3 text-sm">
      <span><span className="font-semibold">{DOCUMENT_TYPE_LABEL[type]}</span>{required ? ' *' : ' (facoltativo)'}<span className="block text-xs text-ink-muted">{files[type]?.name ?? 'PDF, JPG, PNG · max 10 MB'}</span></span>
      <span className="inline-flex h-10 cursor-pointer items-center gap-1 rounded-full border border-line px-3 font-semibold">{files[type] ? <Check className="h-4 w-4 text-emerald-600" /> : <Upload className="h-4 w-4" />} Scegli</span>
      <input type="file" className="sr-only" accept="application/pdf,image/jpeg,image/png,image/webp" data-testid={`doc-${type}`}
        onChange={(e) => setFiles((x) => ({ ...x, [type]: e.target.files?.[0] }))} />
    </label>
  );
  const zoneCities = cities.filter((c) => ['taranto', 'massafra', 'grottaglie', 'martina-franca', 'manduria', 'statte', 'crispiano', 'palagiano'].includes(c.slug) || (zones.data ?? []).some((z) => z.city_id === c.id));

  return (
    <div className="container-app max-w-xl py-8" data-testid="rider-apply">
      <p className="text-sm font-bold uppercase tracking-wider text-coral">Diventa Rider AsiaFood</p>
      <h1 className="mt-1 text-3xl font-extrabold">{STEPS[step]}</h1>
      <p className="mt-1 text-sm text-ink-muted">Passo {step + 1} di {STEPS.length}. La candidatura viene verificata dallo staff: nessuna approvazione automatica.</p>
      <ol className="mt-4 grid grid-cols-7 gap-1" aria-hidden>{STEPS.map((s, i) => <li key={s} className={cn('h-1.5 rounded-full', i <= step ? 'bg-coral' : 'bg-line')} />)}</ol>

      <div className="card mt-6 space-y-4 p-5">
        {step === 0 && (
          <>
            <Field label="Nome"><Input value={f.first_name} onChange={(e) => setF({ ...f, first_name: e.target.value })} autoComplete="given-name" /></Field>
            <Field label="Cognome"><Input value={f.last_name} onChange={(e) => setF({ ...f, last_name: e.target.value })} autoComplete="family-name" /></Field>
          </>
        )}
        {step === 1 && (
          <>
            <Field label="Telefono" hint="Lo usano lo staff e, durante una consegna, cliente e ristorante."><Input type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} autoComplete="tel" /></Field>
            <Field label="Email"><Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} autoComplete="email" /></Field>
          </>
        )}
        {step === 2 && (
          <>
            <Field label="Comune in cui vuoi consegnare">
              <Select value={f.city_slug} onChange={(e) => setF({ ...f, city_slug: e.target.value })}>
                {zoneCities.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
              </Select>
            </Field>
            {(zones.data ?? []).length > 0 && (
              <Field label="Zona operativa AsiaFood (facoltativa)">
                <Select value={f.zone_id} onChange={(e) => setF({ ...f, zone_id: e.target.value })}>
                  <option value="">Tutta la città scelta</option>
                  {zones.data!.filter((z) => z.is_active).map((z) => <option key={z.id} value={z.id}>{z.name}</option>)}
                </Select>
              </Field>
            )}
          </>
        )}
        {step === 3 && (
          <>
            <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Veicolo">
              {(Object.keys(VEHICLE_LABEL) as VehicleType[]).map((v) => (
                <button key={v} type="button" role="radio" aria-checked={f.vehicle_type === v} onClick={() => setF({ ...f, vehicle_type: v })}
                  className={cn('h-14 rounded-2xl border text-sm font-semibold', f.vehicle_type === v ? 'border-ink bg-ink text-white' : 'border-line bg-white')}>{VEHICLE_LABEL[v]}</button>
              ))}
            </div>
            <Field label="Dettagli del veicolo (facoltativi)"><Input value={f.vehicle_details} maxLength={200} onChange={(e) => setF({ ...f, vehicle_details: e.target.value })} placeholder="Es. scooter 125 cc" /></Field>
          </>
        )}
        {step === 4 && (
          <div className="space-y-2">
            <p className="text-sm text-ink-muted">I documenti finiscono in un archivio privato: li vede solo lo staff AsiaFood per la verifica.{isDemoMode ? ' In DEMO il file non viene caricato.' : ''}</p>
            {fileInput('identity', true)}
            {needsLicense && fileInput('driving_license', true)}
            {needsLicense && fileInput('vehicle_registration', false)}
            {needsLicense && fileInput('vehicle_insurance', false)}
          </div>
        )}
        {step === 5 && (
          <div className="space-y-3 text-sm">
            <ul className="list-disc space-y-1 pl-5 text-ink-soft">
              <li>Scegli tu quando essere online; puoi rifiutare le offerte senza penalità automatiche.</li>
              <li>{LOCATION_NOTICE} Offline la posizione non viene raccolta.</li>
              <li>I compensi seguono le regole pubblicate nell’app e sono registrati per ogni consegna.</li>
              <li>I dati dei clienti servono solo per completare la consegna e non vanno conservati.</li>
            </ul>
            <label className="flex items-start gap-3 font-medium">
              <input type="checkbox" className="mt-0.5 h-5 w-5 accent-coral" checked={f.terms} onChange={(e) => setF({ ...f, terms: e.target.checked })} data-testid="rider-terms" />
              Accetto i termini del servizio Rider e l’informativa privacy.
            </label>
          </div>
        )}
        {step === 6 && (
          <dl className="space-y-1.5 text-sm">
            <div className="flex justify-between"><dt className="text-ink-muted">Nome</dt><dd className="font-semibold">{f.first_name} {f.last_name}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Contatti</dt><dd className="font-semibold">{f.phone} · {f.email}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Zona</dt><dd className="font-semibold">{cities.find((c) => c.slug === f.city_slug)?.name}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Veicolo</dt><dd className="font-semibold">{VEHICLE_LABEL[f.vehicle_type]}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-muted">Documenti</dt><dd className="font-semibold">{Object.values(files).filter(Boolean).length}</dd></div>
          </dl>
        )}
        {err && <Alert tone="error">{err}</Alert>}
      </div>

      <div className="mt-4 flex gap-2">
        {step > 0 && <Button variant="outline" onClick={() => setStep(step - 1)} disabled={busy}><ArrowLeft className="h-4 w-4" /> Indietro</Button>}
        {step < STEPS.length - 1 ? (
          <Button className="flex-1" disabled={!valid[step]} onClick={() => setStep(step + 1)} data-testid="rider-apply-next">Continua <ChevronRight className="h-4 w-4" /></Button>
        ) : (
          <Button className="flex-1" loading={busy} disabled={!valid.every(Boolean)} onClick={() => void submit()} data-testid="rider-apply-submit">Invia candidatura</Button>
        )}
      </div>
    </div>
  );
}


