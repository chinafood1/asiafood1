import { Link, useParams } from 'react-router-dom';
import { ChevronRight, Map as MapIcon } from 'lucide-react';
import { APP } from '@/config/app';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { breadcrumbJsonLd, itemListJsonLd, useSeo } from '@/lib/seo';
import { api } from '@/services';
import { CardSkeleton, RestaurantCard } from '@/components/restaurant/RestaurantCard';
import { SponsoredSlots } from '@/components/restaurant/SponsoredSlots';
import { CategoryStrip } from '@/components/restaurant/CategoryStrip';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { ButtonLink } from '@/components/ui/Button';
import NotFoundPage from './NotFoundPage';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';

/** Etichetta naturale per i titoli SEO (es. "Ristoranti cinesi a Taranto"). */
const SEO_NOUNS: Record<string, string> = {
  sushi: 'Sushi',
  giapponese: 'Ristoranti giapponesi',
  cinese: 'Ristoranti cinesi',
  thai: 'Ristoranti thai',
  coreano: 'Ristoranti coreani',
  poke: 'Poke',
  ramen: 'Ramen',
  fusion: 'Ristoranti asian fusion',
  'street-food': 'Asian street food',
  'all-you-can-eat': 'All You Can Eat',
  'bubble-tea': 'Bubble tea',
  'asian-bakery': 'Pasticcerie asiatiche',
  'asian-grocery': 'Alimentari asiatici',
};

/**
 * Pagine di atterraggio SEO:
 *   /ristoranti/:city          → tutti i locali asiatici del comune
 *   /:category                 → categoria su tutto il territorio
 *   /:category/:city           → es. /sushi/taranto, /all-you-can-eat/taranto
 */
export default function ListingPage({ kind }: { kind: 'city' | 'category' | 'category-city' }) {
  const runtime = useRuntimeConfig();
  const params = useParams();
  const { categoryBySlug, cityBySlug, cities, ready } = useReferenceData();
  const cat = kind !== 'city' ? categoryBySlug(params.category) : undefined;
  const city = kind !== 'category' ? cityBySlug(params.city) : undefined;
  const invalid = ready && ((kind !== 'city' && !cat) || (kind !== 'category' && !city));

  const result = useAsync(
    () => (invalid || !ready ? Promise.resolve([]) : api.searchRestaurants({ categorySlug: cat?.slug, citySlug: city?.slug, sort: 'relevance' })),
    [cat?.slug, city?.slug, ready, invalid],
  );

  const catLabel = cat ? (SEO_NOUNS[cat.slug] ?? `Ristoranti ${cat.name}`) : 'Ristoranti asiatici';
  const where = city ? `a ${city.name}` : `a ${APP.launchArea}`;
  const title = `${catLabel} ${where}`;
  const path = kind === 'city' ? `/ristoranti/${city?.slug}` : kind === 'category' ? `/${cat?.slug}` : `/${cat?.slug}/${city?.slug}`;
  const rows = result.data ?? [];

  const n = rows.length;
  const minCombo = Number(runtime.setting('seo_min_restaurants_category_city', 2));
  useSeo({
    title: invalid ? 'Pagina non trovata' : city && cat?.seo_title ? `${cat.seo_title} a ${city.name}` : title,
    description:
      (!city && cat?.seo_description) ||
      (n
        ? `${title}: ${n === 1 ? 'un locale' : `${n} locali`} con indirizzo, orari, contatti e indicazioni${cat?.slug === 'all-you-can-eat' ? ', con i prezzi della formula quando disponibili' : ''}.`
        : `${title}: elenco in aggiornamento su ${APP.name}.`),
    path,
    // Pagine senza risultati o categoria×comune sotto la soglia di qualità: niente indicizzazione (contenuti sottili)
    noindex: invalid || (!result.loading && (n === 0 || (!!city && !!cat && n < minCombo))),
    jsonLd: [
      breadcrumbJsonLd([
        { name: 'Home', path: '/' },
        ...(city ? [{ name: `Ristoranti ${city.name}`, path: `/ristoranti/${city.slug}` }] : []),
        ...(cat ? [{ name: cat.name, path }] : []),
      ]),
      itemListJsonLd(title, rows),
    ],
  });

  if (!ready) return <PageLoader />;
  if (invalid) return <NotFoundPage what="pagina" />;

  const otherCities = cities.filter((c) => c.id !== city?.id).slice(0, 12);

  return (
    <div className="container-app pb-10 pt-6">
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1 text-sm text-ink-muted">
        <Link to="/" className="hover:text-ink">Home</Link>
        {city && (
          <>
            <ChevronRight className="h-3.5 w-3.5" />
            <Link to={`/ristoranti/${city.slug}`} className="hover:text-ink">{city.name}</Link>
          </>
        )}
        {cat && (
          <>
            <ChevronRight className="h-3.5 w-3.5" />
            <span className="text-ink">{cat.name}</span>
          </>
        )}
      </nav>

      <header className="mb-8 max-w-3xl">
        <p className="mb-2 text-4xl">{cat?.emoji ?? '🥢'}</p>
        <h1 className="text-balance text-3xl font-extrabold sm:text-5xl">{title}</h1>
        <p className="mt-3 text-lg text-ink-muted">
          {cat?.description ? `${cat.description} ` : ''}
          {/* Spazio riservato: il conteggio arriva senza spostare la pagina (CLS) */}
          <span className="block min-h-[1.75rem]" aria-live="polite">{result.loading ? '\u00a0' : `${rows.length} ${rows.length === 1 ? 'locale' : 'locali'} ${where}.`}</span>
        </p>
        <ButtonLink
          to={`/map?${new URLSearchParams([...(city ? [['city', city.slug]] : []), ...(cat ? [['category', cat.slug]] : [])]).toString()}`}
          variant="outline"
          size="sm"
          className="mt-5"
          icon={<MapIcon className="h-4 w-4" />}
        >
          Apri mappa
        </ButtonLink>
      </header>

      {kind === 'city' && (
        <div className="mb-8">
          <CategoryStrip citySlug={city?.slug} />
        </div>
      )}

      {result.loading ? (
        <div className="grid gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }, (_, i) => <CardSkeleton key={i} />)}
        </div>
      ) : rows.length === 0 ? (
        <EmptyState
          icon={cat?.emoji ?? '🥢'}
          title="Ancora nessun locale qui"
          text={`Non abbiamo ancora ${catLabel.toLowerCase()} ${where}. Conosci un locale da segnalare o sei il titolare?`}
          action={<ButtonLink to="/per-ristoratori">Segnala o aggiungi un locale</ButtonLink>}
        />
      ) : (
        <>
        <SponsoredSlots
          placement={cat ? 'category_top' : 'city_top'}
          categorySlug={cat?.slug}
          citySlug={city?.slug}
          onlyIds={rows.map((r) => r.id)}
          className="mb-8"
        />
        <div className="grid gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {rows.map((r, i) => (
            <RestaurantCard key={r.id} r={r} eager={i < 4} source={`seo_${kind}`} />
          ))}
        </div>
        </>
      )}

      {/* Link interni per il crawling */}
      <section className="mt-16 grid gap-8 border-t border-line pt-10 md:grid-cols-2">
        {cat && (
          <div>
            <h2 className="mb-3 text-lg font-bold">{cat.name} in altri comuni</h2>
            <div className="flex flex-wrap gap-2">
              {otherCities.map((c) => (
                <Link key={c.id} to={`/${cat.slug}/${c.slug}`} className="rounded-full border border-line bg-white px-3 py-1.5 text-sm hover:border-ink">
                  {cat.name} {c.name}
                </Link>
              ))}
            </div>
          </div>
        )}
        {city && (
          <div>
            <h2 className="mb-3 text-lg font-bold">Altre cucine a {city.name}</h2>
            <CityCategoryLinks citySlug={city.slug} cityName={city.name} exclude={cat?.slug} />
          </div>
        )}
      </section>
    </div>
  );
}

function CityCategoryLinks({ citySlug, cityName, exclude }: { citySlug: string; cityName: string; exclude?: string }) {
  const { categories } = useReferenceData();
  return (
    <div className="flex flex-wrap gap-2">
      {categories
        .filter((c) => c.slug !== exclude)
        .map((c) => (
          <Link key={c.id} to={`/${c.slug}/${citySlug}`} className="rounded-full border border-line bg-white px-3 py-1.5 text-sm hover:border-ink">
            {c.emoji} {c.name} {cityName}
          </Link>
        ))}
    </div>
  );
}
