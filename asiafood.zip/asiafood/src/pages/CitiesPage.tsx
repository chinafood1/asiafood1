import { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';
import { APP } from '@/config/app';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { breadcrumbJsonLd, useSeo } from '@/lib/seo';
import { api } from '@/services';

export default function CitiesPage() {
  const { cities } = useReferenceData();
  const counts = useAsync(() => api.getCityCounts(), []);
  useSeo({
    title: `Ristoranti asiatici per città — ${APP.launchArea}`,
    description: `Tutti i comuni con ristoranti di sushi, cucina giapponese, cinese, thai, coreana e poke a ${APP.launchArea}.`,
    path: '/ristoranti',
    jsonLd: breadcrumbJsonLd([
      { name: 'Home', path: '/' },
      { name: 'Città', path: '/ristoranti' },
    ]),
  });
  return (
    <div className="container-app pb-10 pt-8">
      <h1 className="text-3xl font-extrabold sm:text-5xl">Ristoranti asiatici per città</h1>
      <p className="mt-3 max-w-2xl text-lg text-ink-muted">Scegli il comune: trovi sushi, ramen, All You Can Eat, poke e molto altro.</p>
      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {cities.map((c) => (
          <Link key={c.id} to={`/ristoranti/${c.slug}`} className="group flex items-center gap-4 rounded-3xl border border-line bg-white p-5 transition hover:-translate-y-0.5 hover:shadow-card">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cream transition group-hover:bg-coral-50">
              <MapPin className="h-5 w-5 text-coral" />
            </span>
            <span className="flex-1">
              <span className="block text-lg font-bold">{c.name}</span>
              <span className="text-sm text-ink-muted">{counts.data?.[c.slug] ?? 0} locali</span>
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
