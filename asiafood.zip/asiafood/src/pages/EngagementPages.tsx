import { useCallback, useEffect, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import { ArrowRight, Bell, BellOff, CheckCheck, Copy, Gift, Info, Share2, Sparkles, Ticket, Trophy, UserPlus } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { APP } from '@/config/app';
import { useAsync } from '@/hooks/useAsync';
import { cn, formatDate } from '@/lib/format';
import { disablePush, enablePush, pushPermission, pushSupport } from '@/lib/push';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import type { AppNotification } from '@/types/domain';
import type { LoyaltyWallet, NotificationPrefs, RedeemResult, Reward } from '@/types/engagement';
import { Badge } from '@/components/ui/Badge';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PushPrompt } from '@/components/engagement/PushPrompt';
import { storeReferralCode } from '@/components/engagement/EngagementEffects';
import { AmbassadorCard } from '@/components/launch/CommunityCard';

const int = new Intl.NumberFormat('it-IT');

function RequireLogin({ next, children }: { next: string; children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (!user) {
    return (
      <div className="container-app py-12">
        <EmptyState icon="👋" title="Accedi per continuare" text="Questa pagina è disponibile per gli utenti registrati." action={<ButtonLink to={`/accedi?next=${encodeURIComponent(next)}`}>Accedi</ButtonLink>} />
      </div>
    );
  }
  return <>{children}</>;
}

// ═════════════════════════════════════════════════════════════
//  /notifications
// ═════════════════════════════════════════════════════════════
export function NotificationsCenterPage() {
  useSeo({ title: 'Notifiche', path: '/notifications', noindex: true });
  return (
    <RequireLogin next="/notifications">
      <NotificationsCenter />
    </RequireLogin>
  );
}

function NotificationsCenter() {
  const navigate = useNavigate();
  const [items, setItems] = useState<AppNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const [onlyUnread, setOnlyUnread] = useState(false);
  const [more, setMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const PAGE = 20;
  const load = useCallback(async (reset: boolean) => {
    setLoading(true);
    const r = await api.listNotificationsPage({ limit: PAGE, offset: reset ? 0 : items.length, unreadOnly: onlyUnread });
    setItems((xs) => (reset ? r.items : [...xs, ...r.items]));
    setUnread(r.unread);
    setMore(r.items.length === PAGE);
    setLoading(false);
  }, [onlyUnread, items.length]);
  useEffect(() => {
    void load(true);
    const on = () => void load(true);
    window.addEventListener('af:notifications', on);
    return () => window.removeEventListener('af:notifications', on);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onlyUnread]);
  const markAll = async () => {
    await api.markNotificationsRead();
    window.dispatchEvent(new Event('af:notifications'));
  };
  const open = async (n: AppNotification) => {
    if (!n.read_at) await api.markNotificationsRead([n.id]);
    window.dispatchEvent(new Event('af:notifications'));
    if (n.link) navigate(n.link);
  };
  return (
    <div className="container-app max-w-2xl py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-extrabold">Notifiche</h1>
          <p className="text-ink-muted" aria-live="polite">{unread ? `${unread} da leggere` : 'Tutto letto'}</p>
        </div>
        <Link to="/settings/notifications" className="text-sm font-semibold text-coral-700 hover:underline">Preferenze</Link>
      </div>
      <PushPrompt className="mt-5" />
      <div className="mt-5 flex flex-wrap gap-2">
        <Button size="sm" variant={onlyUnread ? 'dark' : 'outline'} onClick={() => setOnlyUnread((v) => !v)} aria-pressed={onlyUnread}>Solo da leggere</Button>
        {unread > 0 && <Button size="sm" variant="outline" icon={<CheckCheck className="h-4 w-4" />} onClick={() => void markAll()}>Segna tutte come lette</Button>}
      </div>
      {!loading && items.length === 0 ? (
        <div className="mt-6"><EmptyState icon={<Bell className="h-6 w-6" />} title="Nessuna notifica" text="Qui trovi conferme, promemoria, punti e novità dei ristoranti che segui." /></div>
      ) : (
        <ul className="mt-5 divide-y divide-line overflow-hidden rounded-3xl border border-line bg-white">
          {items.map((n) => (
            <li key={n.id} className={cn('flex gap-3 p-4', !n.read_at && 'bg-coral-50/40')}>
              <span className={cn('mt-1.5 h-2 w-2 shrink-0 rounded-full', n.read_at ? 'bg-transparent' : 'bg-coral')} aria-hidden />
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{n.title}{!n.read_at && <span className="sr-only"> (da leggere)</span>}</p>
                {n.body && <p className="text-sm text-ink-muted">{n.body}</p>}
                <p className="mt-1 text-xs text-ink-faint">{formatDate(n.created_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}{n.type === 'promotion' && ' · promozionale'}</p>
              </div>
              <div className="flex flex-col items-end gap-1 self-center">
                {n.link && <button type="button" onClick={() => void open(n)} className="text-sm font-semibold text-coral-700 hover:underline">Apri</button>}
                {!n.read_at && <button type="button" onClick={async () => { await api.markNotificationsRead([n.id]); window.dispatchEvent(new Event('af:notifications')); }} className="text-xs text-ink-muted hover:underline">Segna come letta</button>}
              </div>
            </li>
          ))}
        </ul>
      )}
      {more && items.length > 0 && <Button variant="outline" size="sm" className="mt-4" loading={loading} onClick={() => void load(false)}>Carica altre</Button>}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
//  /settings/notifications
// ═════════════════════════════════════════════════════════════
export function NotificationSettingsPage() {
  useSeo({ title: 'Preferenze notifiche', path: '/settings/notifications', noindex: true });
  return (
    <RequireLogin next="/settings/notifications">
      <NotificationSettings />
    </RequireLogin>
  );
}

const ESSENTIAL: { key: keyof NotificationPrefs; label: string; description: string }[] = [
  { key: 'reservation_updates', label: 'Aggiornamenti prenotazioni', description: 'Conferme, rifiuti e cancellazioni; richiesta di recensione dopo la visita.' },
  { key: 'reservation_reminders', label: 'Promemoria prenotazioni', description: 'Il giorno prima e poco prima dell’orario.' },
  { key: 'coupon_expiry', label: 'Coupon in scadenza', description: 'Solo per coupon ottenuti e non ancora usati.' },
  { key: 'loyalty_updates', label: 'Punti e premi', description: 'Punti accreditati, badge e premi riscattati.' },
  { key: 'referral_updates', label: 'Inviti', description: 'Quando un amico si registra o completa la prima visita.' },
];
const PROMO: { key: keyof NotificationPrefs; label: string; description: string }[] = [
  { key: 'favorite_restaurants', label: 'Ristoranti che segui', description: 'Nuove offerte e coupon dei locali che segui (massimo un avviso al giorno per locale).' },
  { key: 'new_offers', label: 'Nuove offerte', description: 'Selezione di offerte della piattaforma.' },
  { key: 'marketing', label: 'Comunicazioni promozionali', description: 'Campagne di AsiaFood e dei ristoranti di cui sei cliente. Disattivate finché non le attivi.' },
];

function NotificationSettings() {
  const toast = useToast();
  const [p, setP] = useState<NotificationPrefs | null>(null);
  const [busy, setBusy] = useState(false);
  const [perm, setPerm] = useState(pushPermission());
  useEffect(() => {
    void api.getNotificationPrefs().then(setP);
  }, []);
  if (!p) return <PageLoader />;
  const save = async (patch: Partial<NotificationPrefs>) => {
    const prev = p;
    setP({ ...p, ...patch });
    try {
      setP(await api.saveNotificationPrefs(patch));
    } catch (e) {
      setP(prev);
      toast((e as Error).message, 'error');
    }
  };
  const togglePush = async () => {
    setBusy(true);
    try {
      if (p.push_enabled) {
        await disablePush();
        toast('Notifiche push disattivate su questo dispositivo');
      } else {
        const r = await enablePush();
        toast(r.message, r.ok ? undefined : 'error');
      }
      setP(await api.getNotificationPrefs());
      setPerm(pushPermission());
    } finally {
      setBusy(false);
    }
  };
  const support = pushSupport();
  return (
    <div className="container-app max-w-2xl py-8">
      <h1 className="text-3xl font-extrabold">Preferenze notifiche</h1>
      <p className="mt-1 text-ink-muted">Scegli cosa ricevere. Le comunicazioni essenziali sono separate da quelle promozionali.</p>

      <section className="card mt-6 p-6" aria-labelledby="ch">
        <h2 id="ch" className="text-lg font-bold">Canali</h2>
        <div className="mt-2 divide-y divide-line">
          <div className="flex items-start justify-between gap-4 py-3">
            <span>
              <span className="block text-[15px] font-medium">Notifiche push su questo dispositivo</span>
              <span className="block text-sm text-ink-muted">
                {!support.supported ? support.reason : perm === 'denied' ? 'Permesso negato: riattivalo dalle impostazioni del browser.' : p.push_enabled ? 'Attive.' : 'Disattivate.'}
              </span>
            </span>
            {support.supported && perm !== 'denied' && (
              <Button size="sm" variant={p.push_enabled ? 'outline' : 'primary'} loading={busy} icon={p.push_enabled ? <BellOff className="h-4 w-4" /> : <Bell className="h-4 w-4" />} onClick={() => void togglePush()}>
                {p.push_enabled ? 'Disattiva' : 'Attiva notifiche'}
              </Button>
            )}
          </div>
          <Toggle checked={p.email_enabled} onChange={(v) => void save({ email_enabled: v })} label="Email" description="Promemoria e comunicazioni via email secondo le scelte qui sotto." />
        </div>
      </section>

      <section className="card mt-5 p-6" aria-labelledby="ess">
        <h2 id="ess" className="text-lg font-bold">Essenziali</h2>
        <div className="mt-2 divide-y divide-line">
          {ESSENTIAL.map((x) => <Toggle key={x.key} checked={!!p[x.key]} onChange={(v) => void save({ [x.key]: v })} label={x.label} description={x.description} />)}
        </div>
      </section>

      <section className="card mt-5 p-6" aria-labelledby="pro">
        <h2 id="pro" className="text-lg font-bold">Promozionali</h2>
        <p className="text-sm text-ink-muted">Sempre facoltative. I ristoranti non vedono mai i tuoi contatti: gli invii li fa AsiaFood.</p>
        <div className="mt-2 divide-y divide-line">
          {PROMO.map((x) => <Toggle key={x.key} checked={!!p[x.key]} onChange={(v) => void save({ [x.key]: v })} label={x.label} description={x.description} />)}
        </div>
      </section>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
//  /profile/loyalty — wallet AsiaPoints (punti promozionali, non denaro)
// ═════════════════════════════════════════════════════════════
export function LoyaltyPage() {
  useSeo({ title: 'I miei punti', path: '/profile/loyalty', noindex: true });
  return (
    <RequireLogin next="/profile/loyalty">
      <Loyalty />
    </RequireLogin>
  );
}

const TX_LABEL: Record<string, string> = { earn: 'Guadagnati', redeem: 'Premio', expire: 'Scaduti', adjustment: 'Rettifica', bonus: 'Bonus', referral: 'Invito' };

function Loyalty() {
  const [w, setW] = useState<LoyaltyWallet | null>(null);
  const [offset, setOffset] = useState(0);
  const badges = useAsync(() => api.getMyAchievements(), []);
  useEffect(() => {
    void api.getLoyaltyWallet({ limit: 10, offset }).then(setW);
  }, [offset]);
  if (!w) return <PageLoader />;
  const pct = w.next_level ? Math.min(100, Math.round(((w.lifetime - (w.level_min ?? 0)) / (w.next_level.min - (w.level_min ?? 0))) * 100)) : 100;
  return (
    <div className="container-app max-w-3xl py-8">
      <h1 className="text-3xl font-extrabold">{w.program_name}</h1>
      <p className="mt-1 text-ink-muted">Punti promozionali di {APP.name}: si usano solo per i premi della piattaforma. Non sono denaro, non si convertono in euro e non si prelevano.</p>
      {!w.enabled && <Alert>Il programma punti è momentaneamente sospeso.</Alert>}

      <section className="mt-6 overflow-hidden rounded-4xl bg-ink p-6 text-white" aria-labelledby="bal">
        <p id="bal" className="text-sm text-white/60">Saldo</p>
        <p className="font-display text-5xl font-extrabold tabular-nums" data-testid="points-balance">{int.format(w.balance)} <span className="text-2xl font-bold text-coral-300">{w.program_name}</span></p>
        <p className="mt-3 flex items-center gap-2 text-lg font-semibold"><Trophy className="h-5 w-5 text-amber-400" /> {w.level}</p>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/15" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} aria-label="Progresso verso il prossimo livello">
          <div className="h-full rounded-full bg-coral" style={{ width: `${pct}%` }} />
        </div>
        <p className="mt-2 text-sm text-white/70">
          {w.next_level ? `Ti mancano ${int.format(w.next_level.missing)} punti per ${w.next_level.name}.` : 'Hai raggiunto il livello massimo.'}
          <span className="block text-xs text-white/50">I livelli sono un riconoscimento: al momento non includono vantaggi aggiuntivi.</span>
        </p>
        {w.expire_months ? (
          <p className="mt-3 rounded-2xl bg-white/10 px-3 py-2 text-sm">I punti scadono dopo {w.expire_months} mesi.{w.expiring_soon > 0 && ` ${int.format(w.expiring_soon)} punti scadono nei prossimi 30 giorni.`}</p>
        ) : (
          <p className="mt-3 text-xs text-white/50">I punti non hanno scadenza.</p>
        )}
        <ButtonLink to="/rewards" variant="primary" size="sm" className="mt-4" icon={<Gift className="h-4 w-4" />}>Vedi i premi</ButtonLink>
      </section>

      <section className="card mt-5 p-6" aria-labelledby="how">
        <h2 id="how" className="text-lg font-bold">Come guadagnare punti</h2>
        <ul className="mt-3 space-y-2 text-sm">
          {w.rules.map((r) => (
            <li key={r.event_key} className="flex justify-between gap-3"><span>{r.description}</span><span className="shrink-0 font-semibold">+{r.points}</span></li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-ink-muted">Punti solo per azioni reali e verificate (mai per click o visite). Le recensioni danno punti se la visita è verificata, qualunque sia il voto.</p>
      </section>

      <section className="card mt-5 p-6" aria-labelledby="bdg">
        <h2 id="bdg" className="text-lg font-bold">Badge</h2>
        <ul className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {(badges.data ?? []).map((b) => (
            <li key={b.id} className={cn('rounded-2xl border p-3', b.earned_at ? 'border-amber-200 bg-amber-50' : 'border-line opacity-70')}>
              <p className="text-2xl" aria-hidden>{b.icon}</p>
              <p className="font-semibold">{b.name}</p>
              <p className="text-xs text-ink-muted">{b.description}</p>
              <p className="mt-1 text-xs font-semibold">{b.earned_at ? `Ottenuto il ${formatDate(b.earned_at)}` : 'Da sbloccare'}</p>
            </li>
          ))}
        </ul>
      </section>

      {w.redemptions.length > 0 && (
        <section className="card mt-5 p-6" aria-labelledby="red">
          <h2 id="red" className="text-lg font-bold">I miei premi</h2>
          <ul className="mt-3 divide-y divide-line">
            {w.redemptions.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <div>
                  <p className="font-semibold">{r.title}</p>
                  <p className="text-xs text-ink-muted">{formatDate(r.created_at)}{r.expires_at && ` · valido fino al ${formatDate(r.expires_at)}`}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-xl bg-cream px-3 py-1.5 font-mono font-bold tracking-wider">{r.redemption_code}</span>
                  <Badge tone={r.status === 'claimed' ? 'green' : 'neutral'}>{{ claimed: 'Da usare', used: 'Usato', expired: 'Scaduto', cancelled: 'Annullato' }[r.status]}</Badge>
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="card mt-5 p-6" aria-labelledby="tx">
        <h2 id="tx" className="text-lg font-bold">Movimenti</h2>
        {w.transactions.length === 0 ? (
          <p className="mt-2 text-sm text-ink-muted">Nessun movimento.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {w.transactions.map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-3 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{t.description ?? TX_LABEL[t.type]}</p>
                  <p className="text-xs text-ink-muted">{TX_LABEL[t.type]} · {formatDate(t.created_at, { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                </div>
                <span className={cn('shrink-0 font-semibold tabular-nums', t.points > 0 ? 'text-emerald-700' : 'text-ink')}>{t.points > 0 ? '+' : '−'}{int.format(Math.abs(t.points))}</span>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-3 flex gap-2">
          {offset > 0 && <Button size="sm" variant="outline" onClick={() => setOffset((o) => Math.max(0, o - 10))}>Più recenti</Button>}
          {offset + 10 < w.transactions_total && <Button size="sm" variant="outline" onClick={() => setOffset((o) => o + 10)}>Meno recenti</Button>}
        </div>
      </section>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
//  /rewards
// ═════════════════════════════════════════════════════════════
export function RewardsPage() {
  const { user } = useAuth();
  const toast = useToast();
  const rewards = useAsync(() => api.listRewards(), []);
  const [balance, setBalance] = useState<number | null>(null);
  const [name, setName] = useState('AsiaPoints');
  const [confirm, setConfirm] = useState<Reward | null>(null);
  const [result, setResult] = useState<RedeemResult | null>(null);
  const [busy, setBusy] = useState(false);
  useSeo({ title: 'Premi', path: '/rewards', description: 'Premi riscattabili con i punti AsiaPoints.' });
  const refresh = useCallback(() => {
    if (!user) return;
    void api.getLoyaltyWallet({ limit: 1 }).then((w) => {
      setBalance(w.balance);
      setName(w.program_name);
    });
  }, [user]);
  useEffect(refresh, [refresh]);

  const redeem = async () => {
    if (!confirm) return;
    setBusy(true);
    try {
      const r = await api.redeemReward(confirm.id);
      setResult(r);
      setBalance(r.balance);
      rewards.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
      setConfirm(null);
    } finally {
      setBusy(false);
    }
  };
  const list = rewards.data ?? [];
  return (
    <div className="container-app max-w-4xl py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-extrabold">Premi</h1>
          <p className="text-ink-muted">Riscatta i tuoi {name}. I punti non hanno valore in denaro.</p>
        </div>
        {user ? (
          <Link to="/profile/loyalty" className="rounded-2xl bg-ink px-4 py-2 text-white">
            <span className="block text-xs text-white/60">Il tuo saldo</span>
            <span className="font-bold tabular-nums" data-testid="rewards-balance">{balance == null ? '…' : `${int.format(balance)} ${name}`}</span>
          </Link>
        ) : (
          <ButtonLink to="/accedi?next=%2Frewards" size="sm">Accedi per riscattare</ButtonLink>
        )}
      </div>
      {rewards.loading ? (
        <PageLoader />
      ) : list.length === 0 ? (
        <div className="mt-6"><EmptyState icon={<Gift className="h-6 w-6" />} title="Nessun premio disponibile al momento" text="I nuovi premi compariranno qui. Intanto continua ad accumulare punti." /></div>
      ) : (
        <ul className="mt-6 grid gap-4 sm:grid-cols-2">
          {list.map((r) => {
            const enough = balance != null && balance >= r.points_cost;
            const soldOut = r.stock != null && r.stock <= 0;
            return (
              <li key={r.id} className="flex flex-col rounded-3xl border border-line bg-white p-5">
                <div className="flex items-start justify-between gap-3">
                  <h2 className="text-lg font-bold">{r.title}</h2>
                  <span className="shrink-0 rounded-full bg-coral-50 px-3 py-1 text-sm font-bold text-coral-700">{int.format(r.points_cost)} punti</span>
                </div>
                {r.description && <p className="mt-1 text-sm text-ink-muted">{r.description}</p>}
                {r.terms && <p className="mt-2 text-xs text-ink-faint">{r.terms}</p>}
                <p className="mt-2 text-xs text-ink-muted">
                  {r.reward_type === 'restaurant_coupon' ? 'Coupon del ristorante, da mostrare in cassa' : 'Premio della piattaforma'}
                  {r.stock != null && ` · ${r.stock} disponibili`}
                  {r.ends_at && ` · fino al ${formatDate(r.ends_at)}`}
                </p>
                <div className="mt-auto pt-4">
                  {user ? (
                    <Button size="sm" disabled={!enough || soldOut} onClick={() => { setResult(null); setConfirm(r); }}>
                      {soldOut ? 'Esaurito' : enough ? 'Riscatta' : balance == null ? 'Riscatta' : `Ti mancano ${int.format(r.points_cost - balance)} punti`}
                    </Button>
                  ) : (
                    <ButtonLink to="/accedi?next=%2Frewards" size="sm" variant="outline">Accedi per riscattare</ButtonLink>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <Sheet open={!!confirm} onClose={() => { setConfirm(null); setResult(null); }} title={result ? 'Premio riscattato' : 'Conferma riscatto'}>
        {result ? (
          <div className="space-y-3 text-center">
            <p>{result.title}</p>
            <p className="rounded-2xl bg-cream px-4 py-3 font-mono text-2xl font-bold tracking-widest" data-testid="redeem-code">{result.code}</p>
            <p className="text-sm text-ink-muted">Nuovo saldo: {int.format(result.balance)} {name}{result.expires_at && ` · valido fino al ${formatDate(result.expires_at)}`}</p>
            <ButtonLink to="/profile/loyalty" variant="outline" size="sm">Vai ai miei premi</ButtonLink>
          </div>
        ) : confirm && (
          <div className="space-y-4">
            <p>Riscatti <strong>{confirm.title}</strong> per <strong>{int.format(confirm.points_cost)} punti</strong>. I punti vengono scalati subito; l’operazione non è reversibile da te.</p>
            <Button loading={busy} onClick={() => void redeem()}>Conferma</Button>
          </div>
        )}
      </Sheet>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
//  /profile/referrals e /invite/:code
// ═════════════════════════════════════════════════════════════
export function ReferralsPage() {
  useSeo({ title: 'Invita un amico', path: '/profile/referrals', noindex: true });
  return (
    <RequireLogin next="/profile/referrals">
      <Referrals />
    </RequireLogin>
  );
}

function Referrals() {
  const toast = useToast();
  const r = useAsync(() => api.getMyReferrals(), []);
  if (r.loading || !r.data) return <PageLoader />;
  const d = r.data;
  const link = `${window.location.origin}/invite/${d.code}`;
  const share = async () => {
    const text = `Ti invito su ${APP.name}: scopri i ristoranti asiatici vicino a te.`;
    // Fase 13: solo il fatto che l'invito è stato condiviso (mai il destinatario)
    api.trackAppEvent('referral_shared', { source: 'referrals' });
    const nav = navigator as Navigator & { share?: (d: ShareData) => Promise<void> };
    if (nav.share) {
      try {
        await nav.share({ title: APP.name, text, url: link });
        return;
      } catch {
        /* condivisione annullata */
      }
    }
    await navigator.clipboard?.writeText(link).catch(() => undefined);
    toast('Link copiato');
  };
  return (
    <div className="container-app max-w-2xl py-8">
      <h1 className="text-3xl font-extrabold">Invita un amico</h1>
      <p className="mt-1 text-ink-muted">
        {d.reward_points ? `Ricevi ${d.reward_points} punti quando un amico si registra con il tuo invito e completa la prima visita (prenotazione o coupon usato).` : 'Invita i tuoi amici su AsiaFood.'}
        {d.welcome_points ? ` Anche il tuo amico riceve ${d.welcome_points} punti.` : ''} Aprire il link non basta: conta solo la prima visita reale.
      </p>
      {!d.enabled && <Alert>Il programma inviti è momentaneamente sospeso.</Alert>}
      <section className="card mt-6 p-6">
        <p className="text-sm text-ink-muted">Il tuo codice</p>
        <p className="font-mono text-3xl font-extrabold tracking-widest" data-testid="referral-code">{d.code}</p>
        <div className="mt-3 flex items-center gap-2 rounded-2xl bg-cream px-3 py-2">
          <span className="min-w-0 flex-1 truncate text-sm" data-testid="referral-link">{link}</span>
          <button type="button" aria-label="Copia link" onClick={async () => { await navigator.clipboard?.writeText(link).catch(() => undefined); toast('Link copiato'); }} className="rounded-full p-2 hover:bg-white"><Copy className="h-4 w-4" /></button>
        </div>
        <Button className="mt-4" icon={<Share2 className="h-4 w-4" />} onClick={() => void share()}>Condividi invito</Button>
      </section>
      <div className="mt-5 grid grid-cols-3 gap-3">
        <div className="rounded-3xl border border-line bg-white p-4"><p className="text-sm text-ink-muted">Registrati</p><p className="text-2xl font-extrabold">{d.registered}</p></div>
        <div className="rounded-3xl border border-line bg-white p-4"><p className="text-sm text-ink-muted">Qualificati</p><p className="text-2xl font-extrabold">{d.qualified}</p></div>
        <div className="rounded-3xl border border-line bg-white p-4"><p className="text-sm text-ink-muted">Punti guadagnati</p><p className="text-2xl font-extrabold">{int.format(d.points)}</p></div>
      </div>
      {d.items.length > 0 && (
        <ul className="mt-5 divide-y divide-line rounded-3xl border border-line bg-white">
          {d.items.map((x, i) => (
            <li key={i} className="flex items-center justify-between gap-3 px-4 py-3 text-sm">
              <span>{x.name ?? 'Amico'} · registrato il {formatDate(x.registered_at)}</span>
              <Badge tone={x.status === 'rewarded' || x.status === 'qualified' ? 'green' : x.status === 'invalid' ? 'neutral' : 'amber'}>
                {{ invited: 'Invitato', registered: 'In attesa della prima visita', qualified: 'Qualificato', rewarded: 'Premiato', invalid: 'Non valido' }[x.status] ?? x.status}
              </Badge>
            </li>
          ))}
        </ul>
      )}
      <div className="mt-8"><AmbassadorCard /></div>
    </div>
  );
}

/** /invite/:code — conserva l'attribuzione (30 giorni, solo in questo browser) e porta alla registrazione. */
export function InvitePage() {
  const { code = '' } = useParams();
  const { user } = useAuth();
  const valid = /^[A-Za-z0-9]{4}-[A-Za-z0-9]{4}$/.test(code);
  useSeo({ title: `Invito su ${APP.name}`, path: '/invite', noindex: true });
  useEffect(() => {
    if (valid) storeReferralCode(code);
  }, [code, valid]);
  if (valid && user) return <Navigate to="/profile/referrals" replace />;
  return (
    <div className="container-app max-w-xl py-12 text-center">
      <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-3xl bg-coral-50 text-coral-700"><UserPlus className="h-7 w-7" /></span>
      <h1 className="mt-4 text-3xl font-extrabold">Sei stato invitato su {APP.name}</h1>
      {valid ? (
        <>
          <p className="mt-2 text-ink-muted">Registrati per scoprire i ristoranti asiatici vicino a te. Dopo la tua prima visita (prenotazione completata o coupon usato) tu e chi ti ha invitato riceverete punti {`AsiaPoints`}.</p>
          <p className="mt-2 font-mono text-lg font-bold tracking-widest">{code.toUpperCase()}</p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <ButtonLink to="/registrati?next=%2Fprofile%2Freferrals">Registrati</ButtonLink>
            <ButtonLink to="/accedi?next=%2Fprofile%2Freferrals" variant="outline">Ho già un account</ButtonLink>
          </div>
        </>
      ) : (
        <p className="mt-2 text-ink-muted">Il codice invito non è valido. <Link to="/" className="font-semibold text-coral-700">Vai alla home</Link></p>
      )}
      <p className="mt-6 flex items-center justify-center gap-1 text-xs text-ink-faint"><Info className="h-3.5 w-3.5" /> Nessun tracciamento: il codice resta solo in questo browser per 30 giorni.</p>
    </div>
  );
}

/** /r/:slug[/menu|/review] — QR pubblico del ristorante (CTA neutra, nessun incentivo al voto). */
/** QR del kit ristorante: registra solo il tipo di QR (nessun dato personale) e porta alla sezione giusta. */
export function QrRedirect() {
  const { slug = '', kind } = useParams();
  const k = (['menu', 'review', 'booking', 'offer'] as const).find((x) => x === kind) ?? 'profile';
  useEffect(() => {
    void api.launch.trackQrScan(slug, k);
  }, [slug, k]);
  const to = k === 'review' ? `/ristorante/${slug}?review=1#recensioni` : k === 'menu' ? `/ristorante/${slug}#menu`
    : k === 'booking' ? `/ristorante/${slug}/prenota` : k === 'offer' ? `/ristorante/${slug}#offerte` : `/ristorante/${slug}`;
  return <Navigate to={to} replace state={{ source: 'qr' }} />;
}

export function LoyaltyTeaser() {
  const { user } = useAuth();
  if (!user) return null;
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <Link to="/profile/loyalty" className="flex items-center gap-3 rounded-3xl border border-line bg-white p-4 hover:shadow-card"><Sparkles className="h-5 w-5 text-coral" /><span className="font-semibold">I miei punti</span><ArrowRight className="ml-auto h-4 w-4" /></Link>
      <Link to="/profile/referrals" className="flex items-center gap-3 rounded-3xl border border-line bg-white p-4 hover:shadow-card"><UserPlus className="h-5 w-5 text-coral" /><span className="font-semibold">Invita un amico</span><ArrowRight className="ml-auto h-4 w-4" /></Link>
      <Link to="/settings/notifications" className="flex items-center gap-3 rounded-3xl border border-line bg-white p-4 hover:shadow-card"><Ticket className="h-5 w-5 text-coral" /><span className="font-semibold">Notifiche</span><ArrowRight className="ml-auto h-4 w-4" /></Link>
    </div>
  );
}
