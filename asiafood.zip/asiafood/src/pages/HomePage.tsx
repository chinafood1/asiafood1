import { Link } from 'react-router-dom';
import { ArrowRight, CalendarCheck, Infinity as InfinityIcon, LocateFixed, Map as MapIcon, MapPin, ShieldCheck, Sparkles, Store } from 'lucide-react';
import { APP } from '@/config/app';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { loadOrderable } from '@/hooks/useOrderable';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useRadius } from '@/hooks/useRadius';
import { useSeo } from '@/lib/seo';
import { formatPrice } from '@/lib/format';
import { api } from '@/services';
import { HeroSearch } from '@/components/search/HeroSearch';
import { AskAiButton } from '@/components/ai/AiEntry';
import { CategoryStrip } from '@/components/restaurant/CategoryStrip';
import { RestaurantRail, Rail } from '@/components/restaurant/RestaurantRail';
import { OfferCard } from '@/components/restaurant/Offers';
import { SmartImage } from '@/components/ui/SmartImage';
import { SectionHeader } from '@/components/ui/Layout';
import { SponsoredSlots } from '@/components/restaurant/SponsoredSlots';
import { ButtonLink } from '@/components/ui/Button';
import type { RestaurantSummary } from '@/types/domain';

const HERO_IMAGES = [
  'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=900&q=70',
  'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=700&q=70',
  'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=700&q=70',
];

export default function HomePage() {
  const { categories, cities } = useReferenceData();
  const geo = useGeolocation('home');
  const [radius] = useRadius();

  useSeo({
    title: `${APP.name} — Ristoranti asiatici, sushi e All You Can Eat vicino a te`,
    description: `Scopri sushi, cucina giapponese, cinese, thai, coreana, poke e ramen a ${APP.launchArea}. Menu, prezzi, All You Can Eat, orari, offerte e coupon.`,
    path: '/',
    jsonLd: {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: APP.name,
      url: APP.siteUrl,
      potentialAction: {
        '@type': 'SearchAction',
        target: `${APP.siteUrl}/restaurants?q={search_term_string}`,
        'query-input': 'required name=search_term_string',
      },
    },
  });

  // Solo con posizione concessa: niente stime della posizione senza consenso
  const near = useAsync(
    () =>
      geo.coords
        ? api.searchRestaurants({ near: { ...geo.coords, radiusKm: radius }, sort: 'distance', limit: 10 })
        : Promise.resolve(undefined),
    [geo.coords?.lat, geo.coords?.lng, radius],
  );
  const ayce = useAsync(() => api.searchRestaurants({ ayce: true, sort: 'popular', limit: 10 }), []);
  const popular = useAsync(() => api.searchRestaurants({ sort: 'popular', limit: 10 }), []);
  const featured = useAsync(() => api.searchRestaurants({ featured: true, limit: 10 }), []);
  const newest = useAsync(() => api.searchRestaurants({ newOpenings: true, sort: 'newest', limit: 10 }), []);
  // Solo offerte realmente attive (le RLS escludono piani senza offerte); prima quelle in evidenza
  const offers = useAsync(() => api.getActiveOffers({ limit: 10 }), []);
  // "Prenota per stasera": solo locali con orari liberi reali, nessun risultato inventato
  const tonight = useAsync(() => api.getRestaurantsAvailableOn({ partySize: 2, from: '18:00', limit: 10 }), []);
  const openNow = useAsync(() => api.searchRestaurants({ openNow: true }), []);
  // Fase 8: "Ordina adesso" (solo ristoranti con ordini online e pagamenti attivi)
  const orderNow = useAsync(() => loadOrderable().then((m) => {
    const ids = [...m.values()].filter((o) => o.payments_ready && (o.takeaway || o.delivery)).sort((a, b) => Number(b.order_now) - Number(a.order_now)).map((o) => o.restaurant_id).slice(0, 10);
    return ids.length ? api.getRestaurantsByIds(ids) : [];
  }), []);
  const cityCounts = useAsync(() => api.getCityCounts(), []);
  const catCounts = useAsync(() => api.getCategoryCounts(), []);

  const aycePrices = (ayce.data ?? []).flatMap((r) => [r.ayce_lunch_price, r.ayce_dinner_price]).filter((x): x is number => x != null);
  const ayceFrom = aycePrices.length ? Math.min(...aycePrices) : null;

  return (
    <>
      {/* ─── HERO ─────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -right-40 -top-40 h-[520px] w-[520px] rounded-full bg-coral/10 blur-3xl" />
        <div className="container-app relative grid items-center gap-10 pb-10 pt-6 sm:pt-10 lg:grid-cols-[1.15fr_1fr] lg:pb-16 lg:pt-14">
          <div className="animate-fade-up">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1.5 text-xs font-semibold text-ink-soft">
              <MapPin className="h-3.5 w-3.5 text-coral" /> {APP.launchArea}
            </p>
            <h1 className="text-balance text-[40px] font-extrabold leading-[1.02] sm:text-6xl lg:text-[68px]">
              Il meglio della cucina asiatica <span className="relative whitespace-nowrap text-coral">vicino a te.</span>
            </h1>
            <p className="mt-5 max-w-xl text-pretty text-lg text-ink-muted">
              Scopri sushi, cucina giapponese, cinese, thai, poke e molto altro a Taranto e provincia.
            </p>
            <HeroSearch className="mt-8 max-w-3xl" />
            <div className="mt-5 flex flex-wrap items-center gap-2 text-sm">
              <AskAiButton from="home" className="!h-9 !px-3.5" />
              {['Sushi', 'All You Can Eat', 'Ramen', 'Poke'].map((q) => (
                <Link
                  key={q}
                  to={q === 'All You Can Eat' ? '/all-you-can-eat' : `/restaurants?q=${encodeURIComponent(q)}`}
                  className="rounded-full bg-cream px-3 py-1.5 font-medium text-ink-soft transition hover:bg-line"
                >
                  {q}
                </Link>
              ))}
            </div>
          </div>

          {/* Mosaico fotografico (desktop/tablet) */}
          <div className="relative hidden h-[520px] sm:block">
            <div className="absolute right-0 top-0 h-[78%] w-[62%] overflow-hidden rounded-[36px] shadow-lift">
              <SmartImage src={HERO_IMAGES[0]} alt="Sushi" eager className="h-full w-full" />
            </div>
            <div className="absolute bottom-0 left-0 h-[52%] w-[46%] overflow-hidden rounded-[30px] shadow-lift">
              <SmartImage src={HERO_IMAGES[1]} alt="Ramen" eager className="h-full w-full" />
            </div>
            <div className="absolute bottom-[6%] right-[8%] h-[30%] w-[30%] overflow-hidden rounded-[26px] border-4 border-paper shadow-lift">
              <SmartImage src={HERO_IMAGES[2]} alt="Poke bowl" eager className="h-full w-full" />
            </div>
            <div className="absolute left-[8%] top-[14%] animate-fade-up rounded-3xl bg-white p-4 shadow-lift [animation-delay:.2s]">
              <p className="flex items-center gap-2 text-xs font-semibold text-emerald-700">
                <span className="h-2 w-2 rounded-full bg-leaf" /> Aperti ora
              </p>
              <p className="mt-1 font-display text-2xl font-bold">
                {openNow.data?.length ?? '—'} <span className="text-base font-semibold text-ink-muted">locali</span>
              </p>
            </div>
            {ayceFrom !== null && (
              <div className="absolute right-[4%] top-[70%] hidden animate-fade-up items-center gap-2 rounded-full bg-ink px-4 py-2.5 text-sm font-semibold text-white shadow-lift [animation-delay:.35s] lg:flex">
                <InfinityIcon className="h-4 w-4 text-coral-400" /> AYCE da {formatPrice(ayceFrom)}
              </div>
            )}
          </div>
        </div>

        <div className="container-app pb-4">
          <CategoryStrip />
        </div>
      </section>

      {/* ─── SEZIONI ─────────────────────────────────────── */}
      <NearYou geo={geo} radius={radius} items={near.data} loading={near.loading} />

      {(orderNow.loading || (orderNow.data?.length ?? 0) > 0) && (
        <RestaurantRail
          eyebrow="Ritiro e consegna"
          title="Ordina adesso"
          subtitle="Paga online e segui l’ordine in tempo reale."
          items={orderNow.data ?? undefined}
          loading={orderNow.loading}
          to="/restaurants?order=now"
          source="home_order_now"
        />
      )}

      <RestaurantRail
        eyebrow="Formula illimitata"
        title="All You Can Eat"
        subtitle="Prezzi a pranzo e cena, sempre in chiaro."
        items={ayce.data}
        loading={ayce.loading}
        to="/all-you-can-eat"
        source="home_ayce"
      />

      <MapTeaser />

      <RestaurantRail title="Più popolari" eyebrow="Scelti da tutti" items={popular.data} loading={popular.loading} to="/restaurants?sort=popular" source="home_popular" />

      <RestaurantRail
        dark
        eyebrow="Selezione della redazione"
        title="In evidenza"
        items={featured.data}
        loading={featured.loading}
        to="/restaurants?featured=1"
        source="home_featured"
      />

      <section className="container-app py-4">
        <SponsoredSlots placement="home_featured" limit={3} />
      </section>

      {/* Prenota per stasera */}
      {tonight.data && tonight.data.length > 0 && (
        <section className="container-app py-7 sm:py-9">
          <SectionHeader eyebrow="Disponibilità reale" title="Prenota per stasera" subtitle="Tavoli liberi stasera per 2 persone, conferma in pochi secondi." />
          <Rail label="Prenota per stasera">
            {tonight.data.map(({ restaurant: x, first_slot, slots_count }) => (
              <Link
                key={x.id}
                to={`/ristorante/${x.slug}/prenota`}
                className="group flex w-[70%] shrink-0 snap-start flex-col overflow-hidden rounded-3xl border border-line bg-white transition hover:shadow-card sm:w-[40%] lg:w-[calc(25%-12px)]"
              >
                <SmartImage src={x.cover_url} alt={x.name} seed={x.id} emoji={x.categories[0]?.emoji} className="aspect-[16/10] w-full" />
                <div className="p-4">
                  <p className="truncate font-bold">{x.name}</p>
                  <p className="truncate text-sm text-ink-muted">{[x.categories[0]?.name, x.city?.name].filter(Boolean).join(' · ')}</p>
                  <p className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">
                    <CalendarCheck className="h-3.5 w-3.5" /> Libero dalle {first_slot} · {slots_count} {slots_count === 1 ? 'orario' : 'orari'}
                  </p>
                </div>
              </Link>
            ))}
          </Rail>
        </section>
      )}

      {/* Offerte da non perdere */}
      {(offers.loading || (offers.data && offers.data.length > 0)) && (
        <section className="container-app py-7 sm:py-9">
          <SectionHeader eyebrow="Promozioni attive" title="Offerte da non perdere" to="/offers" linkLabel="Vedi tutte" />
          <Rail label="Offerte da non perdere">
            {(offers.data ?? []).map((o) => (
              <div key={o.id} className="w-[82%] shrink-0 snap-start sm:w-[46%] lg:w-[calc(33.333%-11px)]">
                <OfferCard o={o} />
              </div>
            ))}
            {offers.loading &&
              Array.from({ length: 3 }, (_, i) => <div key={i} className="skeleton h-72 w-[82%] shrink-0 rounded-3xl sm:w-[46%] lg:w-[calc(33.333%-11px)]" />)}
          </Rail>
        </section>
      )}

      <RestaurantRail eyebrow="Appena arrivati" title="Nuove aperture" items={newest.data} loading={newest.loading} to="/restaurants?sort=newest" source="home_new" />

      {/* Categorie */}
      <section className="container-app py-7 sm:py-9">
        <SectionHeader eyebrow="Per tipo di cucina" title="Categorie" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {categories.map((c) => (
            <Link
              key={c.id}
              to={`/${c.slug}`}
              className="group flex items-center gap-3 rounded-3xl border border-line bg-white p-4 transition hover:-translate-y-0.5 hover:shadow-card"
            >
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-cream text-2xl transition group-hover:bg-coral-50">{c.emoji}</span>
              <span className="min-w-0">
                <span className="block truncate font-semibold">{c.name}</span>
                <span className="text-xs text-ink-muted">{catCounts.data?.[c.slug] ?? 0} locali</span>
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Ristoranti per città */}
      <section className="container-app py-7 sm:py-9">
        <SectionHeader eyebrow={APP.launchArea} title="Ristoranti per città" to="/ristoranti" />
        <div className="flex flex-wrap gap-2.5">
          {cities.map((c) => (
            <Link
              key={c.id}
              to={`/ristoranti/${c.slug}`}
              className="inline-flex items-center gap-2 rounded-full border border-line bg-white py-2 pl-4 pr-2 text-[15px] font-medium transition hover:border-ink"
            >
              {c.name}
              <span className="rounded-full bg-cream px-2 py-0.5 text-xs font-semibold text-ink-muted">{cityCounts.data?.[c.slug] ?? 0}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* CTA ristoratori */}
      <section className="container-app py-8">
        <div className="relative overflow-hidden rounded-[36px] bg-coral px-6 py-10 text-white sm:px-12 sm:py-14">
          <div className="pointer-events-none absolute -right-20 -top-24 h-80 w-80 rounded-full bg-white/10" />
          <div className="pointer-events-none absolute -bottom-32 right-24 h-72 w-72 rounded-full bg-white/10" />
          <div className="relative max-w-2xl">
            <Store className="mb-4 h-8 w-8" />
            <h2 className="text-3xl font-extrabold sm:text-4xl">Hai un ristorante asiatico?</h2>
            <p className="mt-3 text-lg text-white/85">
              Rivendica gratis la tua scheda, aggiorna menu, prezzi e orari e fatti trovare da chi cerca sushi, ramen o All You Can Eat vicino a te.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <ButtonLink to="/per-ristoratori" variant="dark" size="lg" icon={<Sparkles className="h-5 w-5" />}>
                Scopri come funziona
              </ButtonLink>
              <ButtonLink to="/restaurants" size="lg" className="!bg-white !text-ink hover:!bg-paper" icon={<ArrowRight className="h-5 w-5" />}>
                Trova il tuo locale
              </ButtonLink>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

const PRIVACY = 'La tua posizione viene usata solo per mostrarti ristoranti nelle vicinanze.';

/** "Vicino a te": senza posizione un invito esplicito, con posizione i locali più vicini. */
function NearYou({
  geo,
  radius,
  items,
  loading,
}: {
  geo: ReturnType<typeof useGeolocation>;
  radius: number;
  items: RestaurantSummary[] | undefined;
  loading: boolean;
}) {
  const mapLink = `/map?near=1&km=${radius}`;
  if (geo.coords) {
    return (
      <RestaurantRail
        eyebrow="In base alla tua posizione"
        title="Vicino a te"
        subtitle={`Entro ${radius} km, dal più vicino`}
        items={items}
        loading={loading}
        source="home_near"
        to={mapLink}
        action={
          <Link to={mapLink} className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-line bg-white px-4 py-2 text-sm font-semibold transition hover:border-ink">
            <MapIcon className="h-4 w-4 text-coral" /> <span className="hidden sm:inline">Vedi tutti sulla mappa</span><span className="sm:hidden">Mappa</span>
          </Link>
        }
        empty={
          <div className="rounded-3xl border border-dashed border-line bg-white/70 p-6 text-center">
            <p className="font-semibold">Nessun ristorante entro {radius} km.</p>
            <Link to={`/map?near=1&km=${Math.max(radius, 20) === radius ? 50 : 20}`} className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-coral-700 hover:underline">
              Allarga la ricerca sulla mappa <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        }
      />
    );
  }
  return (
    <section className="container-app py-7 sm:py-9" aria-labelledby="near-title">
      <div className="flex flex-col gap-5 rounded-[32px] border border-line bg-white p-6 sm:flex-row sm:items-center sm:p-8">
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-coral-50 text-coral-700">
          <MapPin className="h-7 w-7" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-coral-700">Vicino a te</p>
          <h2 id="near-title" className="mt-1 text-2xl font-extrabold">Scopri cosa c'è vicino a te</h2>
          <p className="mt-1.5 flex items-start gap-1.5 text-sm text-ink-muted">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" /> {PRIVACY}
          </p>
          {geo.message && <p className="mt-2 text-sm font-medium text-amber-800" role="status">{geo.message}</p>}
        </div>
        <div className="flex shrink-0 flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void geo.request()}
            disabled={geo.status === 'loading'}
            className="inline-flex h-12 items-center gap-2 rounded-full bg-ink px-5 text-[15px] font-semibold text-white transition hover:bg-ink-soft disabled:opacity-60"
          >
            <LocateFixed className="h-4 w-4" /> {geo.status === 'loading' ? 'Localizzo…' : 'Usa la mia posizione'}
          </button>
          <Link to={`/ristoranti/${APP.defaultCitySlug}`} className="inline-flex h-12 items-center rounded-full border border-line px-5 text-[15px] font-semibold transition hover:border-ink">
            Cerca per comune
          </Link>
        </div>
      </div>
    </section>
  );
}

/** Invito alla mappa: solo grafica statica, la libreria della mappa si carica aprendo /map. */
function MapTeaser() {
  const pins = [
    ['18%', '30%', '🍣'],
    ['36%', '58%', '🍜'],
    ['58%', '26%', '🥟'],
    ['72%', '62%', '🍱'],
    ['46%', '40%', '🌶️'],
  ];
  return (
    <section className="container-app py-7 sm:py-9">
      <Link
        to="/map"
        className="group relative block overflow-hidden rounded-[32px] border border-line bg-[#EDF0EA] p-6 transition hover:shadow-card sm:p-10"
        style={{ backgroundImage: 'linear-gradient(#DDE3DA 1px, transparent 1px), linear-gradient(90deg, #DDE3DA 1px, transparent 1px)', backgroundSize: '48px 48px' }}
      >
        <div aria-hidden className="pointer-events-none absolute inset-y-0 right-0 hidden w-1/2 sm:block">
          {pins.map(([left, top, emoji]) => (
            <span
              key={emoji}
              className="absolute flex h-11 w-11 -translate-x-1/2 -translate-y-full items-center justify-center rounded-full rounded-bl-md border-2 border-white bg-white text-lg shadow-[0_4px_14px_rgba(22,22,26,.2)] transition duration-300 group-hover:-translate-y-[110%]"
              style={{ left, top, rotate: '-45deg' }}
            >
              <span style={{ rotate: '45deg' }}>{emoji}</span>
            </span>
          ))}
        </div>
        <div className="relative max-w-md">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-ink-muted">Mappa</p>
          <h2 className="mt-1 text-2xl font-extrabold sm:text-3xl">Esplora sulla mappa</h2>
          <p className="mt-2 text-[15px] text-ink-soft">Tutti i ristoranti asiatici della zona, con filtri per cucina, prezzo, All You Can Eat e delivery.</p>
          <span className="mt-5 inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-sm font-semibold text-white transition group-hover:bg-ink-soft">
            <MapIcon className="h-4 w-4" /> Apri la mappa
          </span>
        </div>
      </Link>
    </section>
  );
}
