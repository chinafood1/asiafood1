import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Clock } from 'lucide-react';
import { BILLING } from '@/config/app';
import { useAuth } from '@/context/AuthContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { billingNotice, planName } from '@/lib/billing';
import { formatPrice } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import type { BillingInterval, PlanCode, PlanWithFeatures } from '@/types/domain';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Field, Select, Textarea } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';
import { BillingModeBadge, BillingNoticeBanner, ChangePlanSheet, IntervalToggle, PlanCards, PlanComparisonTable } from '@/components/billing/BillingUI';
import { ChoosePlan } from '@/components/billing/BillingSection';

const LIVE = ['trialing', 'active', 'past_due', 'unpaid', 'paused'];

/** /dashboard/plans — confronto piani e scelta: checkout Stripe (o lista d'attesa se i pagamenti non sono attivi). */
export default function PlansPage() {
  const { plans } = useReferenceData();
  const { user } = useAuth();
  const [params, setParams] = useSearchParams();
  const managed = useAsync(() => (user ? api.getManagedRestaurants(user.id) : Promise.resolve([])), [user?.id]);
  useSeo({ title: 'Piani', noindex: true });

  if (managed.loading) return <PageLoader />;
  const list = managed.data ?? [];
  const restaurant = list.find((x) => x.id === params.get('restaurant')) ?? list[0];

  return (
    <div>
      <PageTitle
        title="Piani"
        subtitle={BILLING.enabled ? 'Scegli le funzioni per il tuo locale. Pagamento sicuro con Stripe, cancelli quando vuoi.' : 'Scegli le funzioni per il tuo locale. I pagamenti online arriveranno a breve.'}
        action={<BillingModeBadge />}
      />
      {list.length === 0 ? (
        <EmptyState icon="🏪" title="Nessun locale collegato" text="Rivendica il tuo locale per scegliere un piano." action={<ButtonLink to="/restaurants">Trova il tuo locale</ButtonLink>} />
      ) : (
        <>
          {list.length > 1 && (
            <label className="mb-5 flex items-center gap-2 text-sm">
              <span className="text-ink-muted">Locale</span>
              <Select className="!h-10 !w-auto !py-0" value={restaurant?.id} onChange={(e) => setParams({ restaurant: e.target.value }, { replace: true })}>
                {list.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
              </Select>
            </label>
          )}
          {restaurant && (BILLING.enabled ? <BillingPlans key={restaurant.id} restaurantId={restaurant.id} restaurantName={restaurant.name} plans={plans} /> : <Waitlist restaurant={restaurant} plans={plans} />)}
        </>
      )}
      <div className="mt-10">
        <h2 className="mb-3 text-xl font-bold">Confronto funzioni</h2>
        <PlanComparisonTable plans={plans} current={restaurant?.subscription_plan} />
        <p className="mt-3 text-xs text-ink-muted">Prezzi IVA esclusa. La tabella riflette sempre la configurazione attuale dei piani. <Link to="/business/pricing" className="font-semibold">Pagina prezzi</Link></p>
      </div>
    </div>
  );
}

function BillingPlans({ restaurantId, restaurantName, plans }: { restaurantId: string; restaurantName: string; plans: PlanWithFeatures[] }) {
  const ov = useAsync(() => api.getBillingOverview(restaurantId), [restaurantId]);
  const [params] = useSearchParams();
  const [interval, setInterval] = useState<BillingInterval>(params.get('interval') === 'year' ? 'year' : 'month');
  const [changeOpen, setChangeOpen] = useState(false);
  if (ov.loading && !ov.data) return <PageLoader />;
  if (!ov.data) return <p className="text-ink-muted">Impossibile caricare lo stato del piano.</p>;
  const o = ov.data;
  const s = o.stripe && LIVE.includes(o.stripe.status) ? o.stripe : null;
  const notice = billingNotice(o, plans);
  if (!o.can_manage_billing) {
    return <p className="rounded-3xl bg-cream px-4 py-3 text-sm">Il piano di <strong>{restaurantName}</strong> è <strong>{planName(plans, o.effective_plan)}</strong>. Solo il titolare può modificarlo.</p>;
  }
  if (!s) {
    return (
      <div className="space-y-4">
        <BillingNoticeBanner notice={notice} restaurantId={restaurantId} />
        <p className="text-sm text-ink-muted"><strong className="text-ink">{restaurantName}</strong> · piano attuale <strong className="text-ink">{planName(plans, o.effective_plan)}</strong>{o.effective && o.effective.source !== 'stripe' ? ' (assegnato dallo staff)' : ''}</p>
        <ChoosePlan restaurantId={restaurantId} currentPlan={o.effective_plan} trialDays={o.trial_eligible ? o.trial_days : 0} plans={plans} />
      </div>
    );
  }
  return (
    <div className="space-y-4">
      <BillingNoticeBanner notice={notice} restaurantId={restaurantId} />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-ink-muted"><strong className="text-ink">{restaurantName}</strong> · abbonamento <strong className="text-ink">{planName(plans, s.plan_code)}</strong></p>
        <IntervalToggle value={interval} onChange={setInterval} plans={plans} />
      </div>
      <PlanCards
        plans={plans}
        interval={interval}
        current={s.billing_interval === interval ? s.plan_code : null}
        onSelect={() => setChangeOpen(true)}
        ctaLabel={(p) => (p.code === 'free' ? null : p.code === s.plan_code && interval === s.billing_interval ? null : 'Cambia piano')}
      />
      <p className="text-sm"><Link to={`/dashboard/restaurants/${restaurantId}/billing`} className="font-semibold text-coral-700">Fatturazione, fatture e cancellazione →</Link></p>
      <ChangePlanSheet open={changeOpen} onClose={() => setChangeOpen(false)} restaurantId={restaurantId} currentPlan={s.plan_code} currentInterval={s.billing_interval} onDone={ov.reload} />
    </div>
  );
}

/** Pagamenti online non ancora attivi: lista d'attesa (Fase 4), l'Admin attiva il piano a mano. */
function Waitlist({ restaurant, plans }: { restaurant: { id: string; name: string; subscription_plan: PlanCode }; plans: PlanWithFeatures[] }) {
  const toast = useToast();
  const requests = useAsync(() => api.listUpgradeRequests({ status: 'open' }), []);
  const [interval, setInterval] = useState<BillingInterval>('month');
  const [target, setTarget] = useState<PlanWithFeatures | null>(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const openFor = (code: string) => (requests.data ?? []).some((x) => x.restaurant_id === restaurant.id && x.plan_code === code);
  const current = plans.find((p) => p.code === restaurant.subscription_plan);
  const join = async () => {
    if (!target) return;
    setBusy(true);
    try {
      await api.requestPlanUpgrade({ restaurant_id: restaurant.id, plan_code: target.code, billing_interval: interval, message: message.trim() || null });
      toast('Sei in lista d’attesa: ti contatteremo per attivare il piano');
      setTarget(null);
      setMessage('');
      requests.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <IntervalToggle value={interval} onChange={setInterval} plans={plans} />
        <p className="text-sm text-ink-muted"><strong className="text-ink">{restaurant.name}</strong> · piano attuale <strong className="uppercase text-ink">{current?.name}</strong></p>
      </div>
      <PlanCards
        plans={plans}
        interval={interval}
        current={restaurant.subscription_plan}
        onSelect={(p) => setTarget(p)}
        ctaLabel={(p) => (p.code === restaurant.subscription_plan || p.code === 'free' || (current && p.sort_order <= current.sort_order) ? null : openFor(p.code) ? null : `Passa a ${p.name}`)}
      />
      {plans.some((p) => openFor(p.code)) && <p className="inline-flex items-center gap-1.5 text-sm font-semibold"><Clock className="h-4 w-4" /> Richiesta inviata: lo staff ti contatterà.</p>}
      <Sheet open={!!target} onClose={() => setTarget(null)} title={`Passa a ${target?.name ?? ''}`} footer={<div className="flex justify-end gap-3"><Button variant="outline" onClick={() => setTarget(null)}>Annulla</Button><Button loading={busy} onClick={join}>Entra in lista d’attesa</Button></div>}>
        <div className="space-y-4">
          <p className="rounded-2xl bg-cream px-4 py-3 text-[15px]"><strong>Pagamenti online in arrivo.</strong> Lascia la richiesta: lo staff ti contatterà per attivare il piano {target?.name} per {restaurant.name}. Nessun addebito ora.</p>
          <Field label="Fatturazione">
            <Select value={interval} onChange={(e) => setInterval(e.target.value as BillingInterval)}>
              <option value="month">Mensile{target ? ` · ${formatPrice(target.monthly_price)}` : ''}</option>
              <option value="year">Annuale{target?.yearly_price ? ` · ${formatPrice(target.yearly_price)}` : ''}</option>
            </Select>
          </Field>
          <Field label="Messaggio (facoltativo)"><Textarea rows={3} maxLength={500} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Es. orari in cui richiamarti" /></Field>
        </div>
      </Sheet>
    </div>
  );
}
