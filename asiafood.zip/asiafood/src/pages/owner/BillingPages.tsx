import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle2, CreditCard, FlaskConical, Loader2, ShieldCheck, XCircle } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAuth } from '@/context/AuthContext';
import { useAsync } from '@/hooks/useAsync';
import { billingErrorMessage, formatDay, INTERVAL_LABEL, planName, planPrice } from '@/lib/billing';
import { formatPrice } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import type { BillingAccountInput, BillingOverview, CheckoutConfirmation } from '@/types/domain';
import { Badge } from '@/components/ui/Badge';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Field, Input, Select } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';
import { InvoicesTable, SubscriptionStatusBadge } from '@/components/billing/BillingUI';

/**
 * /dashboard/billing/success — ritorno dal checkout Stripe.
 * Arrivare qui NON attiva nulla: il server rilegge la sessione da Stripe e il piano
 * risulta attivo solo quando Stripe lo conferma (webhook o lettura server-side).
 */
export function BillingSuccessPage() {
  const [params] = useSearchParams();
  const sessionId = params.get('session_id') ?? params.get('session') ?? '';
  const restaurantId = params.get('restaurant') ?? '';
  const { plans } = useReferenceData();
  const [conf, setConf] = useState<CheckoutConfirmation | null>(null);
  const [overview, setOverview] = useState<BillingOverview | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tries, setTries] = useState(0);
  const restaurant = useAsync(() => (restaurantId ? api.getRestaurantForEdit(restaurantId) : Promise.resolve(null)), [restaurantId]);
  useSeo({ title: 'Abbonamento', noindex: true });

  useEffect(() => {
    if (!sessionId) return;
    let stop = false;
    const tick = async (n: number) => {
      try {
        const c = await api.confirmCheckout(sessionId);
        if (stop) return;
        setConf(c);
        const o = await api.getBillingOverview(c.restaurant_id).catch(() => null);
        if (stop) return;
        setOverview(o);
        const confirmed = !!o?.stripe && ['trialing', 'active'].includes(o.stripe.status);
        // In attesa del webhook: riprova per ~40 secondi
        if (!confirmed && n < 20) setTimeout(() => void tick(n + 1), 2000);
        setTries(n);
      } catch (e) {
        if (!stop) setError(billingErrorMessage(e));
      }
    };
    void tick(0);
    return () => {
      stop = true;
    };
  }, [sessionId]);

  const sub = overview?.stripe;
  const confirmed = !!sub && ['trialing', 'active'].includes(sub.status);
  const rid = conf?.restaurant_id ?? restaurantId;
  const name = restaurant.data?.name;

  return (
    <div className="mx-auto max-w-xl py-6">
      <div className="card p-6 text-center sm:p-8">
        {error ? (
          <>
            <XCircle className="mx-auto h-12 w-12 text-coral" />
            <h1 className="mt-4 text-2xl font-extrabold">Non riusciamo a verificare il pagamento</h1>
            <p className="mt-2 text-ink-muted">{error}</p>
          </>
        ) : confirmed ? (
          <>
            <CheckCircle2 className="mx-auto h-12 w-12 text-leaf" />
            <h1 className="mt-4 text-2xl font-extrabold" data-testid="billing-success-title">Abbonamento attivato</h1>
            <dl className="mx-auto mt-5 grid max-w-sm gap-2 text-left text-[15px]">
              <div className="flex justify-between gap-4"><dt className="text-ink-muted">Piano</dt><dd className="font-bold">{planName(plans, sub!.plan_code)}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-ink-muted">Ristorante</dt><dd className="font-semibold">{name ?? '—'}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-ink-muted">Fatturazione</dt><dd className="font-semibold">{INTERVAL_LABEL[sub!.billing_interval]}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-ink-muted">Stato</dt><dd><SubscriptionStatusBadge status={sub!.status} /></dd></div>
              {sub!.status === 'trialing' && (
                <div className="flex justify-between gap-4"><dt className="text-ink-muted">Prova gratuita fino al</dt><dd className="font-semibold">{formatDay(sub!.trial_end)}</dd></div>
              )}
            </dl>
            <p className="mt-5 text-sm text-ink-muted">Le funzioni del piano sono già attive. Riceverai la conferma via email.</p>
          </>
        ) : (
          <>
            <Loader2 className="mx-auto h-12 w-12 animate-spin text-ink-muted" />
            <h1 className="mt-4 text-2xl font-extrabold">Stiamo confermando il pagamento…</h1>
            <p className="mt-2 text-ink-muted">
              {conf?.status === 'open'
                ? 'Il pagamento non risulta completato.'
                : tries >= 20
                  ? 'La conferma di Stripe sta impiegando più del previsto. Il piano si attiverà automaticamente appena arriva: puoi chiudere questa pagina.'
                  : 'Attendiamo la conferma di Stripe. Di solito bastano pochi secondi.'}
            </p>
          </>
        )}
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          {rid && <ButtonLink to={`/dashboard/restaurants/${rid}/billing`}>Vai alla fatturazione</ButtonLink>}
          {rid && confirmed && <ButtonLink variant="outline" to={`/dashboard/restaurants/${rid}/panoramica`}>Panoramica attività</ButtonLink>}
        </div>
      </div>
    </div>
  );
}

/** /dashboard/billing/cancel — l'utente è tornato indietro dal checkout: nulla cambia. */
export function BillingCancelPage() {
  const [params] = useSearchParams();
  const rid = params.get('restaurant');
  useSeo({ title: 'Pagamento non completato', noindex: true });
  return (
    <div className="mx-auto max-w-xl py-6">
      <div className="card p-6 text-center sm:p-8">
        <XCircle className="mx-auto h-12 w-12 text-ink-faint" />
        <h1 className="mt-4 text-2xl font-extrabold" data-testid="billing-cancel-title">Pagamento non completato.</h1>
        <p className="mt-2 text-ink-muted">Nessun addebito è stato effettuato e il piano attuale resta invariato. Puoi riprovare quando vuoi.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <ButtonLink to={rid ? `/dashboard/plans?restaurant=${rid}` : '/dashboard/plans'}>Torna ai piani</ButtonLink>
          {rid && <ButtonLink variant="outline" to={`/dashboard/restaurants/${rid}/billing`}>Fatturazione</ButtonLink>}
        </div>
      </div>
    </div>
  );
}

/**
 * Solo modalità DEMO: pagina di pagamento simulata (in produzione l'utente va su checkout.stripe.com).
 * Chiaramente etichettata, nessun dato di carta richiesto o salvato.
 */
export function DemoCheckoutPage() {
  const [params] = useSearchParams();
  const sessionId = params.get('session') ?? '';
  const navigate = useNavigate();
  const toast = useToast();
  const { plans } = useReferenceData();
  const conf = useAsync(() => api.confirmCheckout(sessionId), [sessionId]);
  const restaurant = useAsync(() => (conf.data ? api.getRestaurantForEdit(conf.data.restaurant_id) : Promise.resolve(null)), [conf.data?.restaurant_id]);
  const [busy, setBusy] = useState(false);
  useSeo({ title: 'Pagamento simulato', noindex: true });
  if (api.mode !== 'demo' || !api.simulateBilling) return <EmptyState icon="🔒" title="Pagina non disponibile" />;
  if (conf.loading) return <PageLoader />;
  if (!conf.data) return <EmptyState icon="🧾" title="Sessione di pagamento non trovata" action={<Link to="/dashboard/plans" className="font-semibold text-coral-700">Torna ai piani</Link>} />;
  const c = conf.data;
  const complete = async (card: boolean) => {
    setBusy(true);
    try {
      await api.simulateBilling!('complete_checkout', { sessionId, card });
      navigate(`/dashboard/billing/success?session_id=${sessionId}&restaurant=${c.restaurant_id}`);
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
      setBusy(false);
    }
  };
  const price = planPrice(plans, c.plan_code ?? 'free', c.billing_interval ?? 'month');
  return (
    <div className="mx-auto max-w-lg py-6">
      <div className="card overflow-hidden">
        <div className="flex items-center gap-2 bg-amber-50 px-5 py-3 text-sm font-semibold text-amber-900">
          <FlaskConical className="h-4 w-4" /> Pagamento simulato — modalità DEMO, nessun addebito
        </div>
        <div className="space-y-4 p-6">
          <h1 className="text-2xl font-extrabold">Riepilogo</h1>
          <dl className="grid gap-2 text-[15px]">
            <div className="flex justify-between gap-4"><dt className="text-ink-muted">Ristorante</dt><dd className="font-semibold">{restaurant.data?.name ?? '—'}</dd></div>
            <div className="flex justify-between gap-4"><dt className="text-ink-muted">Piano</dt><dd className="font-bold">{planName(plans, c.plan_code)}</dd></div>
            <div className="flex justify-between gap-4"><dt className="text-ink-muted">Fatturazione</dt><dd>{INTERVAL_LABEL[c.billing_interval ?? 'month']} · {formatPrice(price)}</dd></div>
            {!!c.trial_days && <div className="flex justify-between gap-4"><dt className="text-ink-muted">Prova gratuita</dt><dd className="font-semibold text-leaf">{c.trial_days} giorni, poi {formatPrice(price)}</dd></div>}
          </dl>
          {c.status !== 'open' ? (
            <Alert>Questa sessione è già stata completata.</Alert>
          ) : (
            <>
              <p className="text-sm text-ink-muted">In produzione qui si apre la pagina sicura di Stripe (carta di test 4242 4242 4242 4242 in modalità test).</p>
              <div className="grid gap-2">
                <Button size="lg" loading={busy} onClick={() => complete(true)} icon={<CreditCard className="h-5 w-5" />}>Simula pagamento con carta</Button>
                {!!c.trial_days && !c.require_payment_method && (
                  <Button size="lg" variant="outline" disabled={busy} onClick={() => complete(false)}>Inizia la prova senza carta</Button>
                )}
                <Button variant="ghost" disabled={busy} onClick={() => navigate(`/dashboard/billing/cancel?restaurant=${c.restaurant_id}`)}>Annulla e torna indietro</Button>
              </div>
            </>
          )}
          <p className="flex items-center gap-1.5 text-xs text-ink-muted"><ShieldCheck className="h-4 w-4" /> Nessun dato di carta viene richiesto o salvato in questa simulazione.</p>
        </div>
      </div>
    </div>
  );
}

/** Solo DEMO: Customer Portal simulato (in produzione: billing.stripe.com). */
export function DemoPortalPage() {
  const [params] = useSearchParams();
  const rid = params.get('restaurant') ?? '';
  const flow = params.get('flow');
  const toast = useToast();
  const navigate = useNavigate();
  const ov = useAsync(() => api.getBillingOverview(rid), [rid]);
  useSeo({ title: 'Gestione abbonamento (simulata)', noindex: true });
  if (api.mode !== 'demo' || !api.simulateBilling) return <EmptyState icon="🔒" title="Pagina non disponibile" />;
  if (ov.loading) return <PageLoader />;
  const s = ov.data?.stripe;
  const updateCard = async () => {
    try {
      await api.simulateBilling!('update_card', { restaurantId: rid });
      if (s?.status === 'past_due') await api.simulateBilling!('pay_invoice', { restaurantId: rid });
      toast('Metodo di pagamento aggiornato (simulato)');
      ov.reload();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    }
  };
  return (
    <div className="mx-auto max-w-xl space-y-4 py-6">
      <div className="card overflow-hidden">
        <div className="flex items-center gap-2 bg-amber-50 px-5 py-3 text-sm font-semibold text-amber-900"><FlaskConical className="h-4 w-4" /> Customer Portal simulato — modalità DEMO</div>
        <div className="space-y-4 p-6">
          <h1 className="text-2xl font-extrabold">Gestione abbonamento</h1>
          {flow === 'payment_method_update' && <Alert>Aggiorna il metodo di pagamento per continuare.</Alert>}
          <p className="text-[15px]">Metodo di pagamento: {s?.pm_last4 ? <strong className="capitalize">{s.pm_brand} •••• {s.pm_last4}</strong> : <span className="text-ink-muted">nessuno</span>}</p>
          <Button onClick={updateCard} icon={<CreditCard className="h-4 w-4" />}>{s?.pm_last4 ? 'Sostituisci carta (simulato)' : 'Aggiungi carta (simulato)'}</Button>
          <h2 className="pt-2 text-lg font-bold">Fatture</h2>
          <InvoicesTable invoices={ov.data?.invoices ?? []} />
          <p className="text-xs text-ink-muted">Nel portale Stripe reale il ristoratore può anche modificare i dati di fatturazione e cancellare l’abbonamento.</p>
          <Button variant="outline" onClick={() => navigate(`/dashboard/restaurants/${rid}/billing`)}>Torna ad AsiaFood</Button>
        </div>
      </div>
    </div>
  );
}

const EMPTY: BillingAccountInput = {
  business_name: null, vat_number: null, tax_code: null, billing_email: null, pec: null, recipient_code: null,
  address_line: null, postal_code: null, city: null, province: null, country: 'IT',
};
const COUNTRIES: [string, string][] = [['IT', 'Italia'], ['SM', 'San Marino'], ['CH', 'Svizzera'], ['FR', 'Francia'], ['DE', 'Germania'], ['ES', 'Spagna'], ['AT', 'Austria']];

/** /dashboard/billing — dati di fatturazione (privati) + riepilogo abbonamenti dei locali. */
export function BillingAccountPage() {
  const { user } = useAuth();
  const { plans } = useReferenceData();
  const toast = useToast();
  const account = useAsync(() => api.getBillingAccount(), []);
  const managed = useAsync(() => (user ? api.getManagedRestaurants(user.id) : Promise.resolve([])), [user?.id]);
  const [f, setF] = useState<BillingAccountInput>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof BillingAccountInput, string>>>({});
  const [saving, setSaving] = useState(false);
  const loaded = useRef(false);
  useSeo({ title: 'Fatturazione', noindex: true });

  useEffect(() => {
    if (account.data !== undefined && !loaded.current) {
      loaded.current = true;
      const a = account.data;
      setF(a ? { business_name: a.business_name, vat_number: a.vat_number, tax_code: a.tax_code, billing_email: a.billing_email, pec: a.pec, recipient_code: a.recipient_code, address_line: a.address_line, postal_code: a.postal_code, city: a.city, province: a.province, country: a.country } : { ...EMPTY, billing_email: user?.email ?? null });
    }
  }, [account.data, user?.email]);

  if (account.loading || managed.loading) return <PageLoader />;
  const set = (k: keyof BillingAccountInput, v: string) => setF((x) => ({ ...x, [k]: v }));
  const validate = () => {
    const e: typeof errors = {};
    const vat = (f.vat_number ?? '').replace(/\s/g, '').toUpperCase();
    const it = f.country === 'IT';
    if (vat && !(it ? /^(IT)?\d{11}$/ : /^[A-Z]{0,2}[0-9A-Z]{8,14}$/).test(vat)) e.vat_number = it ? 'La Partita IVA italiana ha 11 cifre' : 'Partita IVA non valida';
    const cf = (f.tax_code ?? '').replace(/\s/g, '').toUpperCase();
    if (cf && !/^([A-Z0-9]{16}|\d{11})$/.test(cf)) e.tax_code = 'Codice fiscale: 16 caratteri (persona) o 11 cifre (società)';
    if (f.recipient_code && !/^[0-9A-Za-z]{7}$/.test(f.recipient_code.trim())) e.recipient_code = 'Il codice destinatario SdI ha 7 caratteri';
    if (f.billing_email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.billing_email.trim())) e.billing_email = 'Email non valida';
    if (f.pec && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.pec.trim())) e.pec = 'PEC non valida';
    if (f.postal_code && it && !/^\d{5}$/.test(f.postal_code.trim())) e.postal_code = 'Il CAP ha 5 cifre';
    setErrors(e);
    return !Object.keys(e).length;
  };
  const save = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      await api.saveBillingAccount({ ...f, vat_number: f.vat_number ? f.vat_number.replace(/\s/g, '').toUpperCase() : null });
      toast('Dati di fatturazione salvati');
      account.reload();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setSaving(false);
    }
  };
  const list = managed.data ?? [];

  return (
    <div className="space-y-6">
      <PageTitle title="Fatturazione" subtitle="Dati privati: non vengono mai mostrati sulla scheda pubblica. Valgono per tutti i tuoi locali." />
      <section className="card p-5 sm:p-7">
        <h2 className="text-lg font-bold">Dati di fatturazione</h2>
        <p className="mt-1 text-sm text-ink-muted">Usati per le fatture Stripe e predisposti per la fatturazione elettronica (SdI). L’IVA è calcolata da Stripe Tax quando attivo.</p>
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <Field label="Ragione sociale" className="sm:col-span-2"><Input value={f.business_name ?? ''} onChange={(e) => set('business_name', e.target.value)} autoComplete="organization" maxLength={160} /></Field>
          <Field label="Partita IVA" error={errors.vat_number}><Input value={f.vat_number ?? ''} onChange={(e) => set('vat_number', e.target.value)} inputMode="text" placeholder="IT01234567890" maxLength={16} /></Field>
          <Field label="Codice fiscale" error={errors.tax_code}><Input value={f.tax_code ?? ''} onChange={(e) => set('tax_code', e.target.value.toUpperCase())} maxLength={16} /></Field>
          <Field label="Indirizzo" className="sm:col-span-2"><Input value={f.address_line ?? ''} onChange={(e) => set('address_line', e.target.value)} autoComplete="street-address" maxLength={200} /></Field>
          <Field label="CAP" error={errors.postal_code}><Input value={f.postal_code ?? ''} onChange={(e) => set('postal_code', e.target.value)} inputMode="numeric" autoComplete="postal-code" maxLength={10} /></Field>
          <Field label="Comune"><Input value={f.city ?? ''} onChange={(e) => set('city', e.target.value)} autoComplete="address-level2" maxLength={100} /></Field>
          <Field label="Provincia"><Input value={f.province ?? ''} onChange={(e) => set('province', e.target.value.toUpperCase())} placeholder="TA" maxLength={40} /></Field>
          <Field label="Paese">
            <Select value={f.country} onChange={(e) => set('country', e.target.value)}>
              {COUNTRIES.map(([c, n]) => <option key={c} value={c}>{n}</option>)}
            </Select>
          </Field>
          <Field label="Email per le fatture" error={errors.billing_email}><Input type="email" value={f.billing_email ?? ''} onChange={(e) => set('billing_email', e.target.value)} autoComplete="email" /></Field>
          <Field label="PEC (facoltativa)" error={errors.pec}><Input type="email" value={f.pec ?? ''} onChange={(e) => set('pec', e.target.value)} /></Field>
          <Field label="Codice destinatario (facoltativo)" hint="7 caratteri, per la fatturazione elettronica" error={errors.recipient_code}><Input value={f.recipient_code ?? ''} onChange={(e) => set('recipient_code', e.target.value.toUpperCase())} maxLength={7} /></Field>
        </div>
        <div className="mt-6 flex justify-end border-t border-line pt-5"><Button loading={saving} onClick={save}>Salva dati</Button></div>
      </section>

      <section className="card p-5 sm:p-7">
        <h2 className="text-lg font-bold">Abbonamenti dei tuoi locali</h2>
        {list.length === 0 ? (
          <p className="mt-3 text-sm text-ink-muted">Nessun locale collegato.</p>
        ) : (
          <ul className="mt-4 divide-y divide-line">
            {list.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <span className="min-w-0">
                  <strong>{r.name}</strong>
                  <span className="ml-2"><Badge tone="outline" className="uppercase">{planName(plans, r.subscription_plan)}</Badge></span>
                </span>
                <Link to={`/dashboard/restaurants/${r.id}/billing`} className="text-sm font-semibold text-coral-700">Gestisci →</Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
