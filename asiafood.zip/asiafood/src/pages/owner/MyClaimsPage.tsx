import { Link } from 'react-router-dom';
import { ArrowRight, Search } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { formatDate } from '@/lib/format';
import { CLAIM_STATUS, VERIFICATION_METHOD } from '@/lib/labels';
import { api } from '@/services';
import type { ClaimWithRestaurant } from '@/types/domain';
import { ClaimStatusBadge } from '@/components/ui/Badge';
import { ButtonLink } from '@/components/ui/Button';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { Monogram } from '@/components/ui/SmartImage';
import { PageTitle } from '@/components/layout/DashboardLayout';
import { ClaimThread, DocumentLink } from '@/components/claims/ClaimThread';

/** /dashboard/claims — le rivendicazioni inviate dall'utente, con stato e conversazione. */
export default function MyClaimsPage() {
  const { user } = useAuth();
  const claims = useAsync(() => api.getMyClaims(user!.id), [user?.id]);
  useSeo({ title: 'Le mie richieste', noindex: true });
  if (claims.loading && !claims.data) return <PageLoader />;
  const list = claims.data ?? [];
  return (
    <div>
      <PageTitle title="Le mie richieste" subtitle="Rivendicazioni inviate, stato della verifica e messaggi dello staff." />
      {list.length === 0 ? (
        <EmptyState
          icon="🏪"
          title="Nessuna richiesta inviata"
          text="Cerca il tuo locale e premi “Rivendica questa attività” nella scheda."
          action={<ButtonLink to="/restaurants" icon={<Search className="h-4 w-4" />}>Trova il tuo locale</ButtonLink>}
        />
      ) : (
        <div className="space-y-5">
          {list.map((c) => <ClaimItem key={c.id} c={c} userId={user!.id} onChanged={claims.reload} />)}
        </div>
      )}
    </div>
  );
}

function ClaimItem({ c, userId, onChanged }: { c: ClaimWithRestaurant; userId: string; onChanged: () => void }) {
  const st = CLAIM_STATUS[c.status];
  return (
    <article className="card p-5 sm:p-6" id={c.id}>
      <div className="flex flex-wrap items-start gap-4">
        <Monogram name={c.restaurant?.name ?? '?'} src={c.restaurant?.logo_url} className="h-12 w-12 shrink-0 text-base" />
        <div className="min-w-0 flex-1">
          <Link to={`/ristorante/${c.restaurant?.slug}`} className="text-lg font-bold hover:text-coral-700">{c.restaurant?.name ?? 'Locale non disponibile'}</Link>
          <p className="text-sm text-ink-muted">
            {c.restaurant?.city_name} · inviata il {formatDate(c.submitted_at)} · verifica: {VERIFICATION_METHOD[c.verification_method].label.toLowerCase()}
          </p>
        </div>
        <ClaimStatusBadge status={c.status} />
      </div>
      <p className="mt-3 text-sm text-ink-soft">{st.hint}</p>
      {c.admin_notes && c.status !== 'more_information_required' && (
        <p className="mt-3 rounded-2xl bg-cream p-3 text-sm"><strong>Nota dello staff:</strong> {c.admin_notes}</p>
      )}
      {c.verification_document_url && <div className="mt-3"><DocumentLink path={c.verification_document_url} label="Documento inviato" /></div>}
      <div className="mt-4 border-t border-line pt-4">
        <ClaimThread claim={c} viewer="claimant" userId={userId} onChanged={onChanged} />
      </div>
      {c.status === 'approved' && (
        <div className="mt-4">
          <ButtonLink to="/dashboard/restaurants" icon={<ArrowRight className="h-4 w-4" />}>Gestisci il locale</ButtonLink>
        </div>
      )}
    </article>
  );
}
