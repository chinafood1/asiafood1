import { lazy } from 'react';
import { Bell, CalendarDays, CreditCard, FileCheck2, Heart, LayoutDashboard, Receipt, Store, Ticket } from 'lucide-react';
import { Navigate, Route, Routes, useParams } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { RequireRole } from '@/components/auth/RequireRole';
import { DashboardLayout, type DashNavItem } from '@/components/layout/DashboardLayout';
import RestaurantEditor from '@/components/editor/RestaurantEditor';
import NotFoundPage from '../NotFoundPage';
import OwnerOverview, { ManagedRestaurantsPage } from './OwnerOverview';
import MyClaimsPage from './MyClaimsPage';
import { MyCouponsPage, MyReservationsPage, NotificationsPage } from './CustomerPages';

const PlansPage = lazy(() => import('./PlansPage'));
const BillingSuccessPage = lazy(() => import('./BillingPages').then((m) => ({ default: m.BillingSuccessPage })));
const BillingCancelPage = lazy(() => import('./BillingPages').then((m) => ({ default: m.BillingCancelPage })));
const DemoCheckoutPage = lazy(() => import('./BillingPages').then((m) => ({ default: m.DemoCheckoutPage })));
const DemoPortalPage = lazy(() => import('./BillingPages').then((m) => ({ default: m.DemoPortalPage })));
const BillingAccountPage = lazy(() => import('./BillingPages').then((m) => ({ default: m.BillingAccountPage })));

function LegacyRedirect() {
  const { id } = useParams();
  return <Navigate to={`/dashboard/restaurants/${id}`} replace />;
}

/**
 * Area utente/ristoratore: /dashboard/* (caricata on-demand).
 * Accessibile a ogni utente autenticato: prenotazioni, coupon e richieste sono di tutti,
 * i locali solo di chi ha una membership attiva (verificata anche dalle RLS).
 */
export default function OwnerArea() {
  const { isOwner } = useAuth();
  const nav: DashNavItem[] = [
    { to: '/dashboard', label: 'Panoramica', icon: LayoutDashboard, end: true },
    { to: '/dashboard/restaurants', label: 'I miei locali', icon: Store },
    ...(isOwner ? [{ to: '/dashboard/plans', label: 'Piani', icon: CreditCard }, { to: '/dashboard/billing', label: 'Fatturazione', icon: Receipt, end: true }] : []),
    { to: '/dashboard/reservations', label: 'Prenotazioni', icon: CalendarDays },
    { to: '/dashboard/coupons', label: 'I miei coupon', icon: Ticket },
    { to: '/dashboard/notifications', label: 'Notifiche', icon: Bell },
    { to: '/dashboard/claims', label: 'Le mie richieste', icon: FileCheck2 },
    { to: '/preferiti', label: 'Preferiti', icon: Heart },
  ];
  return (
    <RequireRole roles={['customer', 'restaurant_owner', 'admin']}>
      <Routes>
        <Route element={<DashboardLayout title="La mia area" nav={nav} />}>
          <Route index element={<OwnerOverview />} />
          <Route path="claims" element={<MyClaimsPage />} />
          <Route path="reservations" element={<MyReservationsPage />} />
          <Route path="coupons" element={<MyCouponsPage />} />
          <Route path="notifications" element={<NotificationsPage />} />
          <Route path="plans" element={<PlansPage />} />
          <Route path="billing" element={<BillingAccountPage />} />
          <Route path="billing/success" element={<BillingSuccessPage />} />
          <Route path="billing/cancel" element={<BillingCancelPage />} />
          <Route path="billing/demo-checkout" element={<DemoCheckoutPage />} />
          <Route path="billing/demo-portal" element={<DemoPortalPage />} />
          <Route path="restaurants" element={<ManagedRestaurantsPage />} />
          <Route path="restaurants/:id" element={<RestaurantEditor mode="owner" />} />
          <Route path="restaurants/:id/:section" element={<RestaurantEditor mode="owner" />} />
          <Route path="ristorante/:id" element={<LegacyRedirect />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </RequireRole>
  );
}
