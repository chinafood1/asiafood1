import { Link } from 'react-router-dom';
import { ArrowRight, Eye, MessageCircle, Navigation, Phone, Search } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useEntitlements } from '@/context/UpgradeContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { formatDate } from '@/lib/format';
import { MEMBER_ROLE } from '@/lib/labels';
import { api, type ManagedRestaurant } from '@/services';
import { OPEN_CLAIM_STATUSES } from '@/types/domain';
import { Badge, ClaimStatusBadge, DemoBadge, VerifiedBadge } from '@/components/ui/Badge';
import { ButtonLink } from '@/components/ui/Button';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { SmartImage } from '@/components/ui/SmartImage';
import { PageTitle } from '@/components/layout/DashboardLayout';
import { OpenStatus } from '@/components/restaurant/Status';
import { ProfileChecklist } from '@/components/billing/Onboarding';
import { BillingNoticeBanner } from '@/components/billing/BillingUI';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { billingNotice } from '@/lib/billing';

/** /dashboard — punto d'ingresso per clienti con richieste e ristoratori approvati. */
export default function OwnerOverview() {
  const { user, profile } = useAuth();
  const restaurants = useAsync(() => api.getManagedRestaurants(user!.id), [user?.id]);
  const claims = useAsync(() => api.getMyClaims(user!.id), [user?.id]);
  useSeo({ title: 'La mia area', noindex: true });

  if (restaurants.loading || claims.loading) return <PageLoader />;
  const list = restaurants.data ?? [];
  const open = (claims.data ?? []).filter((c) => OPEN_CLAIM_STATUSES.includes(c.status));

  return (
    <div>
      <PageTitle title={`Ciao ${profile?.full_name?.split(' ')[0] ?? ''} 👋`} subtitle={list.length ? 'Gestisci le schede dei tuoi locali.' : 'Qui trovi le tue richieste e, dopo l’approvazione, i tuoi locali.'} />

      {open.length > 0 && (
        <section className="mb-6 rounded-3xl border border-line bg-white p-5">
          <div className="flex items-center justify-between gap-3">
            <p className="font-semibold">Richieste in corso</p>
            <Link to="/dashboard/claims" className="inline-flex items-center gap-1 text-sm font-semibold text-coral-700">Dettagli <ArrowRight className="h-4 w-4" /></Link>
          </div>
          <ul className="mt-3 divide-y divide-line">
            {open.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm">
                <span>
                  <strong>{c.restaurant?.name}</strong> <span className="text-ink-muted">· inviata il {formatDate(c.submitted_at)}</span>
                </span>
                <ClaimStatusBadge status={c.status} />
              </li>
            ))}
          </ul>
        </section>
      )}

      {list.length === 0 ? (
        <EmptyState
          icon="🏪"
          title="Nessun locale collegato"
          text="Cerca il tuo ristorante e invia una richiesta di rivendicazione. Dopo l’approvazione lo troverai qui."
          action={<ButtonLink to="/restaurants" icon={<Search className="h-4 w-4" />}>Trova il tuo locale</ButtonLink>}
        />
      ) : (
        <ManagedList list={list} />
      )}
    </div>
  );
}

/** /dashboard/restaurants — solo i locali per cui l'utente ha una membership attiva. */
export function ManagedRestaurantsPage() {
  const { user } = useAuth();
  const restaurants = useAsync(() => api.getManagedRestaurants(user!.id), [user?.id]);
  useSeo({ title: 'I miei locali', noindex: true });
  if (restaurants.loading) return <PageLoader />;
  const list = restaurants.data ?? [];
  return (
    <div>
      <PageTitle title="I miei locali" subtitle="Attività che puoi gestire." />
      {list.length === 0 ? (
        <EmptyState icon="🏪" title="Nessun locale collegato" text="Le attività compaiono qui dopo l’approvazione della rivendicazione." action={<ButtonLink to="/dashboard/claims">Le mie richieste</ButtonLink>} />
      ) : (
        <ManagedList list={list} />
      )}
    </div>
  );
}

function ManagedList({ list }: { list: ManagedRestaurant[] }) {
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      {list.map((r) => <OwnedCard key={r.id} r={r} />)}
    </div>
  );
}

function OwnedCard({ r }: { r: ManagedRestaurant }) {
  const ent = useEntitlements(r.subscription_plan);
  const analytics = ent.can('analytics_enabled');
  const stats = useAsync(() => (analytics ? api.getRestaurantStats(r.id, 30) : Promise.resolve({} as Awaited<ReturnType<typeof api.getRestaurantStats>>)), [r.id, analytics]);
  const s = stats.data ?? {};
  return (
    <div className="card overflow-hidden">
      <SmartImage src={r.cover_url} alt={r.name} seed={r.id} emoji={r.categories[0]?.emoji} className="aspect-[16/6] w-full" />
      <div className="p-5">
        <div className="flex flex-wrap items-center gap-2">
          <h2 className="text-xl font-bold">{r.name}</h2>
          {r.is_verified && <VerifiedBadge label="Profilo verificato" />}
          {r.is_demo && <DemoBadge />}
          <Badge tone="outline" className="uppercase">{r.subscription_plan}</Badge>
          <Badge tone="neutral">{MEMBER_ROLE[r.member_role]}</Badge>
          {!r.is_active && <Badge tone="coral">Non pubblicato</Badge>}
          {r.is_temporarily_closed && <Badge tone="amber">Chiuso temporaneamente</Badge>}
        </div>
        <p className="mt-1 text-sm text-ink-muted">{r.city?.name}</p>
        <OpenStatus hours={r.hours} tz={r.timezone} className="mt-2" />
        {analytics ? <div className="mt-4 grid grid-cols-4 gap-2 text-center">
          {(
            [
              [Eye, s.restaurant_view ?? 0, 'Visite'],
              [Phone, s.phone_click ?? 0, 'Chiamate'],
              [MessageCircle, s.whatsapp_click ?? 0, 'WhatsApp'],
              [Navigation, s.directions_click ?? 0, 'Indicazioni'],
            ] as const
          ).map(([Icon, v, label]) => (
            <div key={label} className="rounded-2xl bg-cream px-1 py-3">
              <Icon className="mx-auto h-4 w-4 text-ink-muted" />
              <p className="mt-1 font-display text-lg font-bold tabular-nums">{v}</p>
              <p className="truncate text-[11px] text-ink-muted">{label}</p>
            </div>
          ))}
        </div> : null}
        {!r.onboarding_completed_at && <div className="mt-4"><ProfileChecklist compact restaurantId={r.id} base={`/dashboard/restaurants/${r.id}`} /></div>}
        <CardBillingNotice restaurantId={r.id} />
        <p className="mt-2 text-xs text-ink-faint">{analytics ? 'Ultimi 30 giorni' : <>Statistiche incluse dal piano Business · <Link to={`/dashboard/restaurants/${r.id}/billing`} className="font-semibold text-coral-700">Scopri i piani</Link></>}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <ButtonLink to={`/dashboard/restaurants/${r.id}`} icon={<ArrowRight className="h-4 w-4" />}>Gestisci scheda</ButtonLink>
          {r.is_active && (
            <Link to={`/ristorante/${r.slug}`} className="inline-flex h-11 items-center rounded-full border border-line px-5 text-[15px] font-semibold hover:border-ink">Vedi pubblica</Link>
          )}
        </div>
      </div>
    </div>
  );
}

function CardBillingNotice({ restaurantId }: { restaurantId: string }) {
  const { plans } = useReferenceData();
  const ov = useAsync(() => api.getBillingOverview(restaurantId).catch(() => null), [restaurantId]);
  const notice = billingNotice(ov.data, plans);
  if (!notice || (notice.kind !== 'payment_failed' && notice.kind !== 'trial_expiring')) return null;
  return <div className="mt-4"><BillingNoticeBanner notice={notice} restaurantId={restaurantId} compact /></div>;
}
