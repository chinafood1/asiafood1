import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell, CalendarDays, Ticket } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { cn, formatDate, telUrl } from '@/lib/format';
import { formatDay, localNow, RESERVATION_STATUS } from '@/lib/reservations';
import { api } from '@/services';
import type { CouponClaimView } from '@/types/domain';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';
import { ClaimedCoupon, discountLabel } from '@/components/restaurant/Offers';

/** /dashboard/reservations — prenotazioni del cliente (solo le proprie, garantito dalle RLS). */
export function MyReservationsPage() {
  const list = useAsync(() => api.getMyReservations(), []);
  const toast = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  useSeo({ title: 'Le mie prenotazioni', noindex: true });
  const today = localNow().date;
  if (list.loading) return <PageLoader />;
  const rows = list.data ?? [];
  const upcoming = rows.filter((x) => x.reservation_date >= today && (x.status === 'pending' || x.status === 'confirmed'));
  const past = rows.filter((x) => !upcoming.includes(x));

  const cancel = async (id: string) => {
    if (!confirm('Vuoi annullare questa prenotazione?')) return;
    setBusy(id);
    try {
      await api.setReservationStatus(id, 'cancelled');
      toast('Prenotazione annullata');
      list.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };

  const card = (x: (typeof rows)[number], canCancel: boolean) => (
    <li key={x.id} className="card flex flex-wrap items-center gap-4 p-4">
      <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-2xl bg-cream">
        <span className="text-[11px] font-semibold uppercase text-ink-muted">{formatDay(x.reservation_date, { month: 'short' })}</span>
        <span className="font-display text-2xl font-bold leading-none">{Number(x.reservation_date.slice(8))}</span>
      </div>
      <div className="min-w-0 flex-1">
        <Link to={`/ristorante/${x.restaurant?.slug}`} className="font-bold hover:text-coral-700">{x.restaurant?.name ?? 'Ristorante'}</Link>
        <p className="text-sm text-ink-muted">
          {formatDay(x.reservation_date, { weekday: 'long' })} alle {x.reservation_time.slice(0, 5)} · {x.party_size} {x.party_size === 1 ? 'persona' : 'persone'} · <span className="font-mono">{x.confirmation_code}</span>
        </p>
      </div>
      <Badge tone={RESERVATION_STATUS[x.status].tone}>{RESERVATION_STATUS[x.status].label}</Badge>
      {canCancel && (
        <div className="flex w-full gap-2 sm:w-auto">
          {x.restaurant?.phone && <a href={telUrl(x.restaurant.phone)} className="inline-flex h-9 items-center rounded-full border border-line px-4 text-sm font-semibold hover:border-ink">Chiama</a>}
          <Button size="sm" variant="danger" loading={busy === x.id} onClick={() => cancel(x.id)}>Annulla</Button>
        </div>
      )}
    </li>
  );

  return (
    <div>
      <PageTitle title="Le mie prenotazioni" subtitle="Prenotazioni fatte con il tuo account." />
      {rows.length === 0 ? (
        <EmptyState icon={<CalendarDays className="h-6 w-6" />} title="Nessuna prenotazione" text="Prenota un tavolo dalla scheda di un ristorante che accetta prenotazioni online." action={<Link to="/restaurants?reservation=1" className="font-semibold text-coral-700">Trova un ristorante</Link>} />
      ) : (
        <div className="space-y-8">
          <section>
            <h2 className="mb-3 text-lg font-bold">Prossime</h2>
            {upcoming.length ? <ul className="space-y-3">{upcoming.map((x) => card(x, true))}</ul> : <p className="text-sm text-ink-muted">Nessuna prenotazione in arrivo.</p>}
          </section>
          {past.length > 0 && (
            <section>
              <h2 className="mb-3 text-lg font-bold">Passate e annullate</h2>
              <ul className="space-y-3 opacity-80">{past.map((x) => card(x, false))}</ul>
            </section>
          )}
        </div>
      )}
      <p className="mt-6 text-sm text-ink-muted">Hai prenotato senza account? <Link to="/prenotazione" className="font-semibold text-coral-700">Gestisci con codice ed email</Link>.</p>
    </div>
  );
}

const CLAIM_STATUS: Record<CouponClaimView['status'], { label: string; tone: 'green' | 'neutral' | 'amber' | 'coral' }> = {
  claimed: { label: 'Da usare', tone: 'green' },
  redeemed: { label: 'Utilizzato', tone: 'neutral' },
  expired: { label: 'Scaduto', tone: 'amber' },
  cancelled: { label: 'Annullato', tone: 'coral' },
};

/** /dashboard/coupons — coupon ottenuti dal cliente, con QR da mostrare in cassa. */
export function MyCouponsPage() {
  const list = useAsync(() => api.getMyCouponClaims(), []);
  const [open, setOpen] = useState<CouponClaimView | null>(null);
  useSeo({ title: 'I miei coupon', noindex: true });
  if (list.loading) return <PageLoader />;
  const rows = list.data ?? [];
  return (
    <div>
      <PageTitle title="I miei coupon" subtitle="Mostra il codice o il QR alla cassa del ristorante." />
      {rows.length === 0 ? (
        <EmptyState icon={<Ticket className="h-6 w-6" />} title="Nessun coupon" text="Trova le offerte con coupon e premi “Ottieni coupon”." action={<Link to="/offers" className="font-semibold text-coral-700">Vai alle offerte</Link>} />
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2">
          {rows.map((x) => (
            <li key={x.id}>
              <button
                type="button"
                disabled={x.status !== 'claimed'}
                onClick={() => setOpen(x)}
                className={cn('card flex w-full items-center gap-4 p-4 text-left transition', x.status === 'claimed' ? 'hover:shadow-card' : 'opacity-70')}
              >
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-ink font-display text-sm font-bold text-white">
                  {(x.coupon && discountLabel(x.coupon)) ?? <Ticket className="h-5 w-5" />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-bold">{x.coupon?.title ?? 'Coupon'}</span>
                  <span className="block truncate text-sm text-ink-muted">{x.restaurant?.name}</span>
                  <span className="block font-mono text-xs">{x.claim_code}</span>
                </span>
                <Badge tone={CLAIM_STATUS[x.status].tone}>{CLAIM_STATUS[x.status].label}</Badge>
              </button>
            </li>
          ))}
        </ul>
      )}
      <Sheet open={!!open} onClose={() => setOpen(null)} title="Il tuo coupon">
        {open && (
          <ClaimedCoupon r={{ claim_code: open.claim_code, title: open.coupon?.title ?? 'Coupon', restaurant_name: open.restaurant?.name ?? '', valid_until: open.coupon?.valid_until ?? null, already: false }} />
        )}
      </Sheet>
    </div>
  );
}

/** /dashboard/notifications — notifiche interne (nuove prenotazioni, richieste…). */
export function NotificationsPage() {
  const list = useAsync(() => api.listNotifications(100), []);
  useSeo({ title: 'Notifiche', noindex: true });
  if (list.loading) return <PageLoader />;
  const rows = list.data ?? [];
  const unread = rows.filter((n) => !n.read_at).length;
  return (
    <div>
      <PageTitle title="Notifiche" subtitle={unread ? `${unread} da leggere` : 'Tutto letto'} />
      {unread > 0 && (
        <Button size="sm" variant="outline" className="mb-4" onClick={async () => { await api.markNotificationsRead(); list.reload(); window.dispatchEvent(new Event('af:notifications')); }}>
          Segna tutte come lette
        </Button>
      )}
      {rows.length === 0 ? (
        <EmptyState icon={<Bell className="h-6 w-6" />} title="Nessuna notifica" />
      ) : (
        <ul className="divide-y divide-line rounded-3xl border border-line bg-white">
          {rows.map((n) => (
            <li key={n.id} className={cn('flex gap-3 p-4', !n.read_at && 'bg-coral-50/40')}>
              <span className={cn('mt-1.5 h-2 w-2 shrink-0 rounded-full', n.read_at ? 'bg-transparent' : 'bg-coral')} aria-hidden />
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{n.title}</p>
                {n.body && <p className="text-sm text-ink-muted">{n.body}</p>}
                <p className="mt-1 text-xs text-ink-faint">{formatDate(n.created_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
              </div>
              {n.link && (
                <Link
                  to={n.link}
                  onClick={() => { void api.markNotificationsRead([n.id]).then(() => window.dispatchEvent(new Event('af:notifications'))); }}
                  className="self-center text-sm font-semibold text-coral-700 hover:underline"
                >
                  Apri
                </Link>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

