import { PushPrompt } from '@/components/engagement/PushPrompt';
import { forwardRef, useEffect, useRef, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, CalendarCheck, CalendarDays, Check, CheckCircle2, Clock, Minus, Phone, Plus, Users } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { hasFeature } from '@/lib/entitlements';
import { cn, telUrl } from '@/lib/format';
import { addDays, EMAIL_RE, formatDay, localNow, PHONE_RE } from '@/lib/reservations';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import type { Availability, ReservationResult, RestaurantDetail } from '@/types/domain';
import { Button } from '@/components/ui/Button';
import { Field, Input, Textarea } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { SmartImage } from '@/components/ui/SmartImage';
import NotFoundPage from './NotFoundPage';
import { sessionConversion } from '@/lib/experiments';

type Step = 1 | 2 | 3 | 4 | 5;
const STEPS = ['Data', 'Persone', 'Orario', 'Dati', 'Riepilogo'];

/** /ristorante/:slug/prenota — prenotazione tavolo, anche come ospite (senza account). */
export default function ReservationPage() {
  const { slug = '' } = useParams();
  const { data: r, loading } = useAsync(() => api.getRestaurantBySlug(slug), [slug]);
  if (loading) return <PageLoader />;
  if (!r) return <NotFoundPage what="ristorante" />;
  return <ReservationFlow r={r} />;
}

function ReservationFlow({ r }: { r: RestaurantDetail }) {
  const { plans } = useReferenceData();
  const { user, profile } = useAuth();
  const st = r.reservation_settings;
  const closed = r.is_permanently_closed || r.is_temporarily_closed;
  const bookable = r.has_reservation && !closed && !!st?.reservation_enabled && hasFeature(plans, r.subscription_plan, 'reservations_enabled');
  useSeo({ title: `Prenota un tavolo — ${r.name}`, path: `/ristorante/${r.slug}/prenota`, noindex: true });

  const today = localNow(r.timezone).date;
  // Precompilazione dall'assistente AI (/prenota?date=…&time=…&party=…&src=ai): l'utente conferma sempre
  const [params] = useSearchParams();
  const fromAi = params.get('src') === 'ai';
  const pDate = params.get('date');
  const pTime = params.get('time');
  const pParty = Number(params.get('party'));
  const initDate = pDate && /^\d{4}-\d{2}-\d{2}$/.test(pDate) && pDate >= today && pDate <= addDays(today, 180) ? pDate : today;
  const minParty = st?.min_party_size ?? 1;
  const maxParty = st?.max_party_size ?? 30;
  const initParty = Number.isInteger(pParty) && pParty >= minParty && pParty <= maxParty ? pParty : Math.max(2, minParty);
  const prefilled = fromAi && (!!pDate || !!pTime || !!params.get('party'));
  const [step, setStep] = useState<Step>(1);
  const [date, setDate] = useState(initDate);
  const [party, setParty] = useState(initParty);
  const [time, setTime] = useState<string | null>(null);
  const [av, setAv] = useState<Availability | null>(null);
  const [avLoading, setAvLoading] = useState(false);
  const [slotError, setSlotError] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', surname: '', email: '', phone: '', notes: '', consent: false });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [done, setDone] = useState<ReservationResult | null>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);

  // reservation_start: una volta per apertura del flusso
  useEffect(() => {
    if (bookable) api.track(r.id, 'reservation_start', fromAi ? 'ai' : 'reservation_page');
  }, [r.id, bookable, fromAi]);

  // Dati dall'assistente: si passa direttamente agli orari (verificati di nuovo qui)
  useEffect(() => {
    if (!prefilled || !bookable) return;
    setStep(3);
    void loadSlots(initDate, initParty).then((a) => {
      const t = pTime && /^\d{2}:\d{2}$/.test(pTime) ? pTime : null;
      if (t && a?.slots.some((x) => x.time.slice(0, 5) === t && x.status === 'available')) setTime(t);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Precompila con il profilo (se l'utente ha un account)
  useEffect(() => {
    if (!profile) return;
    const [first, ...rest] = (profile.full_name ?? '').split(' ');
    setForm((f) => ({ ...f, name: f.name || first || '', surname: f.surname || rest.join(' '), email: f.email || profile.email || '', phone: f.phone || profile.phone || '' }));
  }, [profile]);

  // Focus sul titolo del passaggio: chi usa lo screen reader sente il cambio di step
  useEffect(() => headingRef.current?.focus(), [step, done]);

  const loadSlots = async (d = date, p = party) => {
    setAvLoading(true);
    setSlotError(null);
    try {
      const a = await api.getReservationAvailability(r.id, d, p);
      setAv(a);
      return a;
    } catch {
      setAv({ ok: false, reason: 'Non riusciamo a caricare gli orari. Controlla la connessione e riprova.', slots: [] });
      return null;
    } finally {
      setAvLoading(false);
    }
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Inserisci il nome.';
    if (!form.surname.trim()) e.surname = 'Inserisci il cognome.';
    if (!EMAIL_RE.test(form.email.trim())) e.email = 'Inserisci un indirizzo email valido.';
    if (!PHONE_RE.test(form.phone.trim())) e.phone = 'Inserisci un numero di telefono valido (es. +39 333 1234567).';
    if (form.notes.length > 500) e.notes = 'Massimo 500 caratteri.';
    if (!form.consent) e.consent = 'Serve il consenso per inviare la prenotazione al ristorante.';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const submit = async () => {
    if (!time) return setStep(3);
    setSubmitting(true);
    setSubmitError(null);
    try {
      const res = await api.createReservation({
        restaurant_id: r.id, date, time, party_size: party, guest_name: form.name, guest_surname: form.surname,
        guest_email: form.email, guest_phone: form.phone, notes: form.notes || null, source: fromAi ? 'ai' : 'web',
      });
      setDone(res);
      sessionConversion('reservation_completed', r.id);
    } catch (e) {
      const msg = e instanceof Error ? e.message : '';
      if (/non è più disponibile|Orario non valido/.test(msg)) {
        // Slot appena occupato: si torna agli orari aggiornati
        setTime(null);
        setSlotError(msg);
        setStep(3);
        void loadSlots();
      } else {
        setSubmitError(/fetch|network|Failed to/i.test(msg) ? 'Connessione assente o instabile: la prenotazione non è stata inviata. Riprova.' : msg || 'Qualcosa è andato storto. Riprova.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const header = (
    <div className="mb-6 flex items-center gap-4">
      <SmartImage src={r.cover_url} alt="" seed={r.id} className="h-16 w-16 shrink-0 rounded-2xl" />
      <div className="min-w-0">
        <Link to={`/ristorante/${r.slug}`} className="inline-flex items-center gap-1 text-sm font-semibold text-ink-muted hover:text-ink">
          <ArrowLeft className="h-4 w-4" /> {r.name}
        </Link>
        <p className="text-sm text-ink-muted">{[r.address, r.city?.name].filter(Boolean).join(', ')}</p>
      </div>
    </div>
  );

  if (!bookable) {
    return (
      <div className="container-app max-w-2xl py-8">
        {header}
        <EmptyState
          icon="📅"
          title="Prenotazione online non disponibile"
          text={closed ? 'Il ristorante non accetta prenotazioni in questo periodo.' : 'Questo ristorante non accetta prenotazioni online. Puoi contattarlo direttamente.'}
          action={r.phone ? <a href={telUrl(r.phone)} className="inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-sm font-semibold text-white"><Phone className="h-4 w-4" /> Chiama {r.phone}</a> : undefined}
        />
      </div>
    );
  }

  if (done) {
    const confirmed = done.status === 'confirmed';
    return (
      <div className="container-app max-w-2xl py-8">
        {header}
        <div className="card p-6 text-center sm:p-8">
          <span className={cn('mx-auto flex h-16 w-16 items-center justify-center rounded-full', confirmed ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600')}>
            <CheckCircle2 className="h-8 w-8" />
          </span>
          <h1 ref={headingRef} tabIndex={-1} className="mt-4 text-2xl font-extrabold outline-none sm:text-3xl">
            {confirmed ? 'Prenotazione confermata' : 'Prenotazione inviata'}
          </h1>
          <p className="mt-2 text-ink-muted">
            {confirmed ? 'Ti aspettiamo! ' : 'Il ristorante confermerà a breve la tua richiesta. '}
            Conserva il codice: serve per modificare o annullare.
          </p>
          <dl className="mx-auto mt-6 grid max-w-sm gap-2 text-left text-[15px]">
            <Row label="Ristorante" value={done.restaurant_name} />
            <Row label="Data" value={formatDay(done.reservation_date, { weekday: 'long', day: 'numeric', month: 'long' })} />
            <Row label="Ora" value={done.reservation_time} />
            <Row label="Persone" value={String(done.party_size)} />
            <Row label="Codice" value={<span className="font-mono text-lg font-bold tracking-wider">{done.code}</span>} />
          </dl>
          {st?.guest_message && <p className="mt-5 rounded-2xl bg-cream px-4 py-3 text-sm">{st.guest_message}</p>}
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <Link to={`/ristorante/${r.slug}`} className="inline-flex h-11 items-center rounded-full border border-line px-5 text-sm font-semibold hover:border-ink">
              Torna al ristorante
            </Link>
            {user ? (
              <Link to="/dashboard/reservations" className="inline-flex h-11 items-center rounded-full bg-ink px-5 text-sm font-semibold text-white">
                Le mie prenotazioni
              </Link>
            ) : (
              <Link to="/prenotazione" className="inline-flex h-11 items-center rounded-full bg-ink px-5 text-sm font-semibold text-white">
                Gestisci prenotazione
              </Link>
            )}
          </div>
          <PushPrompt className="mt-6 text-left" />
        </div>
      </div>
    );
  }

  const maxDays = st!.max_advance_days;
  const quickDays = Array.from({ length: Math.min(14, maxDays + 1) }, (_, i) => addDays(today, i));
  const slots = (av?.slots ?? []).filter((s) => s.status !== 'too_soon');
  const groups = [
    { label: 'Pranzo', items: slots.filter((s) => s.time < '16:00') },
    { label: 'Cena', items: slots.filter((s) => s.time >= '16:00') },
  ].filter((g) => g.items.length);

  return (
    <div className="container-app max-w-2xl pb-16 pt-8">
      {header}
      <ol className="mb-6 flex gap-1.5" aria-label="Passaggi della prenotazione">
        {STEPS.map((label, i) => (
          <li key={label} className="flex-1" aria-current={step === i + 1 ? 'step' : undefined}>
            <span className={cn('block h-1.5 rounded-full', i + 1 <= step ? 'bg-coral' : 'bg-line')} />
            <span className={cn('mt-1.5 hidden text-xs font-semibold sm:block', i + 1 === step ? 'text-ink' : 'text-ink-faint')}>{label}</span>
          </li>
        ))}
      </ol>
      {prefilled && step < 5 && (
        <p className="mb-4 rounded-2xl bg-cream px-4 py-3 text-sm text-ink-soft" role="status">
          Data, persone e orario sono stati precompilati dall’assistente: controllali prima di confermare. Nessuna prenotazione viene inviata senza la tua conferma.
        </p>
      )}

      <div className="card p-5 sm:p-7">
        {step === 1 && (
          <section aria-labelledby="step-title">
            <StepTitle ref={headingRef} icon={<CalendarDays className="h-5 w-5" />} n={1}>Scegli la data</StepTitle>
            <div className="scrollbar-none -mx-1 flex gap-2 overflow-x-auto px-1 pb-1" role="radiogroup" aria-label="Data">
              {quickDays.map((d, i) => (
                <button
                  key={d}
                  type="button"
                  role="radio"
                  aria-checked={date === d}
                  onClick={() => setDate(d)}
                  className={cn('flex h-[72px] w-16 shrink-0 flex-col items-center justify-center rounded-2xl border text-sm transition', date === d ? 'border-ink bg-ink text-white' : 'border-line bg-white hover:border-ink/40')}
                >
                  <span className="text-[11px] font-semibold uppercase opacity-70">{i === 0 ? 'Oggi' : i === 1 ? 'Domani' : formatDay(d, { weekday: 'short' })}</span>
                  <span className="font-display text-xl font-bold">{Number(d.slice(8))}</span>
                  <span className="text-[11px] opacity-70">{formatDay(d, { month: 'short' })}</span>
                </button>
              ))}
            </div>
            <Field label="Oppure scegli un'altra data" className="mt-4 max-w-xs">
              <Input type="date" value={date} min={today} max={addDays(today, maxDays)} onChange={(e) => e.target.value && setDate(e.target.value)} />
            </Field>
            <Nav onNext={() => setStep(2)} nextLabel="Continua" />
          </section>
        )}

        {step === 2 && (
          <section>
            <StepTitle ref={headingRef} icon={<Users className="h-5 w-5" />} n={2}>Quante persone?</StepTitle>
            <div className="flex items-center justify-center gap-6 py-4">
              <button type="button" aria-label="Una persona in meno" disabled={party <= st!.min_party_size} onClick={() => setParty(party - 1)} className="flex h-14 w-14 items-center justify-center rounded-full border border-line bg-white text-ink transition hover:border-ink disabled:opacity-40">
                <Minus className="h-5 w-5" />
              </button>
              <p className="w-24 text-center" aria-live="polite">
                <span className="block font-display text-5xl font-extrabold">{party}</span>
                <span className="text-sm text-ink-muted">{party === 1 ? 'persona' : 'persone'}</span>
              </p>
              <button type="button" aria-label="Una persona in più" disabled={party >= st!.max_party_size} onClick={() => setParty(party + 1)} className="flex h-14 w-14 items-center justify-center rounded-full border border-line bg-white text-ink transition hover:border-ink disabled:opacity-40">
                <Plus className="h-5 w-5" />
              </button>
            </div>
            <p className="text-center text-sm text-ink-muted">
              Da {st!.min_party_size} a {st!.max_party_size} persone.
              {r.phone && <> Per gruppi più numerosi <a href={telUrl(r.phone)} className="font-semibold text-coral-700 hover:underline">chiama il ristorante</a>.</>}
            </p>
            <Nav onBack={() => setStep(1)} onNext={() => { setTime(null); setStep(3); void loadSlots(date, party); }} nextLabel="Vedi orari" />
          </section>
        )}

        {step === 3 && (
          <section>
            <StepTitle ref={headingRef} icon={<Clock className="h-5 w-5" />} n={3}>Scegli l’orario</StepTitle>
            <p className="-mt-2 mb-4 text-sm text-ink-muted">
              {formatDay(date, { weekday: 'long', day: 'numeric', month: 'long' })} · {party} {party === 1 ? 'persona' : 'persone'}
            </p>
            {slotError && <p role="alert" className="mb-4 rounded-2xl bg-coral-50 px-4 py-3 text-sm font-medium text-coral-800">{slotError}</p>}
            {avLoading ? (
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-4" aria-busy="true">
                {Array.from({ length: 8 }, (_, i) => <div key={i} className="skeleton h-12 rounded-2xl" />)}
              </div>
            ) : !av?.ok || !groups.some((g) => g.items.some((s) => s.status === 'available')) ? (
              <div className="rounded-3xl border border-dashed border-line p-6 text-center">
                <p className="font-semibold">{av?.reason ?? 'Nessun orario disponibile in questa data.'}</p>
                <p className="mt-1 text-sm text-ink-muted">Prova un altro giorno o un numero di persone diverso.</p>
                <Button variant="outline" size="sm" className="mt-4" onClick={() => setStep(1)}>Cambia data</Button>
              </div>
            ) : (
              <div className="space-y-5">
                {groups.map((g) => (
                  <div key={g.label}>
                    <p className="mb-2 text-xs font-bold uppercase tracking-wider text-ink-muted">{g.label}</p>
                    <div className="grid grid-cols-3 gap-2 sm:grid-cols-4" role="radiogroup" aria-label={`Orari ${g.label}`}>
                      {g.items.map((s) => {
                        const free = s.status === 'available';
                        return (
                          <button
                            key={s.time}
                            type="button"
                            role="radio"
                            aria-checked={time === s.time}
                            disabled={!free}
                            onClick={() => setTime(s.time)}
                            className={cn(
                              'flex h-12 flex-col items-center justify-center rounded-2xl border text-[15px] font-semibold tabular-nums transition',
                              time === s.time ? 'border-ink bg-ink text-white' : free ? 'border-line bg-white hover:border-ink' : 'cursor-not-allowed border-dashed border-line bg-cream/50 text-ink-faint',
                            )}
                          >
                            {s.time}
                            {!free && <span className="text-[10px] font-medium">{s.status === 'closed' ? 'Chiuso' : 'Completo'}</span>}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
            <Nav onBack={() => setStep(2)} onNext={() => time && setStep(4)} nextDisabled={!time} nextLabel="Continua" />
          </section>
        )}

        {step === 4 && (
          <section>
            <StepTitle ref={headingRef} icon={<Users className="h-5 w-5" />} n={4}>I tuoi dati</StepTitle>
            <form
              noValidate
              onSubmit={(e) => {
                e.preventDefault();
                if (validate()) setStep(5);
              }}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Nome *" error={errors.name}>
                  <Input autoComplete="given-name" value={form.name} maxLength={60} aria-invalid={!!errors.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </Field>
                <Field label="Cognome *" error={errors.surname}>
                  <Input autoComplete="family-name" value={form.surname} maxLength={60} aria-invalid={!!errors.surname} onChange={(e) => setForm({ ...form, surname: e.target.value })} />
                </Field>
                <Field label="Email *" error={errors.email} hint="Ti invieremo la conferma.">
                  <Input type="email" inputMode="email" autoComplete="email" value={form.email} aria-invalid={!!errors.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </Field>
                <Field label="Telefono *" error={errors.phone} hint="Il ristorante ti contatta solo per la prenotazione.">
                  <Input type="tel" inputMode="tel" autoComplete="tel" value={form.phone} aria-invalid={!!errors.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                </Field>
                <Field label="Note (facoltative)" error={errors.notes} hint={`${form.notes.length}/500 · es. seggiolone, allergie, occasione speciale`} className="sm:col-span-2">
                  <Textarea rows={3} maxLength={500} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
                </Field>
              </div>
              <label className="mt-4 flex items-start gap-3 text-sm">
                <input type="checkbox" className="mt-0.5 h-5 w-5 shrink-0 accent-coral" checked={form.consent} onChange={(e) => setForm({ ...form, consent: e.target.checked })} aria-invalid={!!errors.consent} />
                <span>Acconsento a inviare questi dati al ristorante per gestire la prenotazione. Nessun uso pubblicitario.</span>
              </label>
              {errors.consent && <p role="alert" className="mt-1 text-xs font-medium text-coral-700">{errors.consent}</p>}
              <Nav onBack={() => setStep(3)} submit nextLabel="Riepilogo" />
            </form>
          </section>
        )}

        {step === 5 && (
          <section>
            <StepTitle ref={headingRef} icon={<Check className="h-5 w-5" />} n={5}>Riepilogo</StepTitle>
            <dl className="grid gap-2 text-[15px]">
              <Row label="Ristorante" value={r.name} />
              <Row label="Data" value={formatDay(date, { weekday: 'long', day: 'numeric', month: 'long' })} onEdit={() => setStep(1)} />
              <Row label="Persone" value={String(party)} onEdit={() => setStep(2)} />
              <Row label="Ora" value={time ?? ''} onEdit={() => setStep(3)} />
              <Row label="Nome" value={`${form.name} ${form.surname}`} onEdit={() => setStep(4)} />
              <Row label="Contatti" value={`${form.email} · ${form.phone}`} onEdit={() => setStep(4)} />
              {form.notes && <Row label="Note" value={form.notes} onEdit={() => setStep(4)} />}
            </dl>
            <p className="mt-4 rounded-2xl bg-cream px-4 py-3 text-sm text-ink-soft">
              {av?.auto_confirm ? 'La prenotazione sarà confermata subito.' : 'Il ristorante riceverà la richiesta e la confermerà.'}
              {st?.guest_message && ` ${st.guest_message}`}
            </p>
            {submitError && <p role="alert" className="mt-4 rounded-2xl bg-coral-50 px-4 py-3 text-sm font-medium text-coral-800">{submitError}</p>}
            <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-between">
              <Button variant="ghost" onClick={() => setStep(4)}>Indietro</Button>
              <Button size="lg" loading={submitting} onClick={submit} icon={<CalendarCheck className="h-5 w-5" />}>
                Conferma prenotazione
              </Button>
            </div>
          </section>
        )}
      </div>
      <p className="mt-4 text-center text-xs text-ink-faint">Nessun account richiesto. I tuoi dati vengono inviati solo a {r.name}.</p>
    </div>
  );
}

const StepTitle = forwardRef<HTMLHeadingElement, { icon: React.ReactNode; n: number; children: React.ReactNode }>(function StepTitle({ icon, n, children }, ref) {
  return (
    <h1 ref={ref} tabIndex={-1} id="step-title" className="mb-4 flex items-center gap-2 text-xl font-bold outline-none">
      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-coral-50 text-coral-700" aria-hidden>{icon}</span>
      <span className="sr-only">Passaggio {n} di 5: </span>
      {children}
    </h1>
  );
});

function Nav({ onBack, onNext, nextLabel, nextDisabled, submit }: { onBack?: () => void; onNext?: () => void; nextLabel: string; nextDisabled?: boolean; submit?: boolean }) {
  return (
    <div className="mt-6 flex items-center justify-between gap-3">
      {onBack ? <Button type="button" variant="ghost" onClick={onBack}>Indietro</Button> : <span />}
      <Button type={submit ? 'submit' : 'button'} size="lg" disabled={nextDisabled} onClick={submit ? undefined : onNext}>
        {nextLabel}
      </Button>
    </div>
  );
}

function Row({ label, value, onEdit }: { label: string; value: React.ReactNode; onEdit?: () => void }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-line pb-2 last:border-0">
      <dt className="shrink-0 text-ink-muted">{label}</dt>
      <dd className="min-w-0 text-right font-semibold">
        <span className="break-words">{value}</span>
        {onEdit && (
          <button type="button" onClick={onEdit} className="ml-2 text-xs font-semibold text-coral-700 hover:underline">
            Modifica
          </button>
        )}
      </dd>
    </div>
  );
}
