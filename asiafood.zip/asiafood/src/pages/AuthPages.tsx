import { useState, type FormEvent } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { FlaskConical, Mail, Shield, Store, User, Bike } from 'lucide-react';
import { APP } from '@/config/app';
import { useAuth } from '@/context/AuthContext';
import { useSeo } from '@/lib/seo';
import { isDemoMode } from '@/services';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';
import { Alert } from '@/components/ui/Layout';
import { LogoMark } from '@/components/layout/Logo';
import type { UserRole } from '@/types/domain';
import { safeNext } from '@/lib/safeRedirect';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { storePendingInvite } from '@/components/platform/BetaInvite';

function AuthShell({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="container-app flex min-h-[calc(100dvh-64px)] items-start justify-center pb-24 pt-8 sm:items-center">
      <div className="w-full max-w-md animate-fade-up">
        <LogoMark className="mb-6 h-12 w-12" />
        <h1 className="text-3xl font-extrabold">{title}</h1>
        {subtitle && <p className="mt-2 text-ink-muted">{subtitle}</p>}
        <div className="mt-8">{children}</div>
      </div>
    </div>
  );
}


function DemoLogin({ next }: { next: string }) {
  const { demoSignIn } = useAuth();
  const navigate = useNavigate();
  const go = (role: UserRole, to: string) => {
    demoSignIn(role);
    navigate(next !== '/profilo' ? next : to);
  };
  return (
    <div className="rounded-3xl border border-line bg-white p-5">
      <p className="flex items-center gap-2 text-sm font-bold">
        <FlaskConical className="h-4 w-4 text-coral" /> Modalità demo — accedi come:
      </p>
      <div className="mt-4 grid gap-2">
        <Button variant="outline" icon={<User className="h-4 w-4" />} onClick={() => go('customer', '/profilo')}>
          Cliente
        </Button>
        <Button variant="outline" className="!h-auto min-h-11 !whitespace-normal py-2.5" icon={<Store className="h-4 w-4 shrink-0" />} onClick={() => go('restaurant_owner', '/dashboard')}>
          Ristoratore (gestisce “Ramen Kōen”)
        </Button>
        <Button variant="outline" icon={<Bike className="h-4 w-4" />} onClick={() => go('rider', '/rider')}>
          Rider (app consegne)
        </Button>
        <Button variant="dark" icon={<Shield className="h-4 w-4" />} onClick={() => go('admin', '/admin')}>
          Amministratore
        </Button>
      </div>
      <p className="mt-3 text-xs text-ink-muted">Le modifiche restano solo in questo browser. Collega Supabase per l'autenticazione reale.</p>
    </div>
  );
}

export function LoginPage() {
  const { signIn, signInWithMagicLink, sendPasswordReset, user } = useAuth();
  const [params] = useSearchParams();
  const next = safeNext(params.get('next'));
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useSeo({ title: 'Accedi', path: '/accedi', noindex: true });

  if (user) return <Navigate to={next} replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await signIn(email, password);
      navigate(next, { replace: true });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const magic = async () => {
    if (!email) return setError('Inserisci la tua email.');
    setError(null);
    try {
      await signInWithMagicLink(email);
      setInfo('Ti abbiamo inviato un link di accesso via email.');
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const reset = async () => {
    if (!email) return setError('Inserisci la tua email per reimpostare la password.');
    setError(null);
    try {
      await sendPasswordReset(email);
      setInfo('Se l’indirizzo è registrato riceverai un’email per reimpostare la password.');
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const reason = params.get('motivo');
  return (
    <AuthShell
      title="Bentornato"
      subtitle={reason === 'preferiti' ? 'Accedi per salvare i tuoi locali preferiti.' : `Accedi al tuo account ${APP.name}.`}
    >
      {isDemoMode ? (
        <DemoLogin next={next} />
      ) : (
        <form onSubmit={submit} className="space-y-4">
          {error && <Alert tone="error">{error}</Alert>}
          {info && <Alert tone="success">{info}</Alert>}
          <Field label="Email">
            <Input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Password">
            <Input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <div className="flex justify-end">
            <button type="button" onClick={reset} className="text-sm font-medium text-ink-muted hover:text-ink">
              Password dimenticata?
            </button>
          </div>
          <Button type="submit" size="lg" className="w-full" loading={busy}>
            Accedi
          </Button>
          <Button type="button" variant="outline" size="lg" className="w-full" icon={<Mail className="h-4 w-4" />} onClick={magic}>
            Ricevi un link via email
          </Button>
        </form>
      )}
      <p className="mt-6 text-center text-sm text-ink-muted">
        Non hai un account?{' '}
        <Link to={`/registrati${params.toString() ? `?${params}` : ''}`} className="font-semibold text-ink link-underline">
          Registrati
        </Link>
      </p>
    </AuthShell>
  );
}

export function RegisterPage() {
  const { signUp, user } = useAuth();
  const [params] = useSearchParams();
  const next = safeNext(params.get('next'));
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', terms: false, invite: params.get('invito') ?? '' });
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const { setting } = useRuntimeConfig();
  const inviteOnly = setting<boolean>('beta_invite_only', false) === true;
  useSeo({ title: 'Registrati', path: '/registrati', noindex: true });

  if (user && !done) return <Navigate to={next} replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (form.password.length < 8) return setError('La password deve contenere almeno 8 caratteri.');
    if (!form.terms) return setError('Devi accettare termini e privacy.');
    if (inviteOnly && form.invite.trim().length < 10) return setError('Durante la beta privata serve un codice di invito.');
    setError(null);
    setBusy(true);
    try {
      // Il codice viene riscattato al primo accesso (anche dopo la conferma email)
      if (form.invite.trim()) storePendingInvite(form.invite.trim());
      const { needsConfirmation } = await signUp(form.name.trim(), form.email.trim(), form.password, next);
      if (needsConfirmation) setDone(true);
      else navigate(next, { replace: true });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <AuthShell title="Controlla la tua email" subtitle={`Abbiamo inviato un link di conferma a ${form.email}.`}>
        <Alert tone="success">
          {next.includes('/rivendica') ? 'Dopo la conferma tornerai automaticamente alla richiesta di rivendicazione.' : 'Dopo la conferma potrai accedere e salvare i tuoi preferiti o rivendicare il tuo locale.'}
        </Alert>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="Crea il tuo account" subtitle="Salva i preferiti e, se sei un ristoratore, rivendica il tuo locale.">
      <form onSubmit={submit} className="space-y-4">
        {error && <Alert tone="error">{error}</Alert>}
        <Field label="Nome e cognome">
          <Input required autoComplete="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </Field>
        <Field label="Email">
          <Input type="email" required autoComplete="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        </Field>
        <Field label="Password" hint="Almeno 8 caratteri.">
          <Input type="password" required minLength={8} autoComplete="new-password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </Field>
        {inviteOnly && (
          <Field label="Codice di invito" hint="La beta è su invito: trovi il codice nell’email ricevuta.">
            <Input required value={form.invite} onChange={(e) => setForm({ ...form, invite: e.target.value })} data-testid="invite-code" />
          </Field>
        )}
        <label className="flex items-start gap-3 text-sm text-ink-soft">
          <input type="checkbox" className="mt-0.5 h-4 w-4 accent-coral" checked={form.terms} onChange={(e) => setForm({ ...form, terms: e.target.checked })} />
          <span>Accetto i <Link to="/terms" className="underline">termini di servizio</Link> e ho letto l’<Link to="/privacy" className="underline">informativa privacy</Link>.</span>
        </label>
        <Button type="submit" size="lg" className="w-full" loading={busy}>
          Registrati
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-ink-muted">
        Hai già un account?{' '}
        <Link to={`/accedi${params.toString() ? `?${params}` : ''}`} className="font-semibold text-ink link-underline">
          Accedi
        </Link>
      </p>
    </AuthShell>
  );
}

export function ResetPasswordPage() {
  const { updatePassword } = useAuth();
  const navigate = useNavigate();
  const [pw, setPw] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useSeo({ title: 'Nuova password', noindex: true });
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (pw.length < 8) return setError('Almeno 8 caratteri.');
    setBusy(true);
    try {
      await updatePassword(pw);
      navigate('/profilo', { replace: true });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <AuthShell title="Imposta una nuova password">
      <form onSubmit={submit} className="space-y-4">
        {error && <Alert tone="error">{error}</Alert>}
        <Field label="Nuova password">
          <Input type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} />
        </Field>
        <Button type="submit" size="lg" className="w-full" loading={busy}>
          Salva password
        </Button>
      </form>
    </AuthShell>
  );
}
