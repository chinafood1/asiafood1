import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarX2 } from 'lucide-react';
import { useSeo } from '@/lib/seo';
import { EMAIL_RE } from '@/lib/reservations';
import { api } from '@/services';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';

/** /prenotazione — annullamento per chi ha prenotato senza account (codice + email). */
export default function ManageReservationPage() {
  useSeo({ title: 'Gestisci la tua prenotazione', path: '/prenotazione', noindex: true });
  const [code, setCode] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!/^ASF-[A-Z0-9]{5}$/i.test(code.trim())) return setError('Il codice ha il formato ASF-XXXXX.');
    if (!EMAIL_RE.test(email.trim())) return setError('Inserisci l’email usata per prenotare.');
    if (!confirm('Vuoi davvero annullare la prenotazione?')) return;
    setBusy(true);
    try {
      await api.cancelReservationByCode(code.trim().toUpperCase(), email.trim());
      setDone(true);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container-app max-w-lg py-10">
      <h1 className="text-3xl font-extrabold">Gestisci la prenotazione</h1>
      <p className="mt-2 text-ink-muted">Hai prenotato senza account? Inserisci il codice ricevuto e l’email usata per annullare.</p>
      {done ? (
        <div className="card mt-6 p-6 text-center" role="status">
          <CalendarX2 className="mx-auto h-10 w-10 text-coral" />
          <p className="mt-3 text-lg font-bold">Prenotazione annullata</p>
          <p className="mt-1 text-sm text-ink-muted">Il ristorante è stato avvisato. Grazie per averlo comunicato.</p>
          <Link to="/" className="mt-5 inline-flex h-11 items-center rounded-full bg-ink px-5 text-sm font-semibold text-white">Torna alla home</Link>
        </div>
      ) : (
        <form onSubmit={submit} noValidate className="card mt-6 space-y-4 p-6">
          <Field label="Codice prenotazione">
            <Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="ASF-8K2P4" autoCapitalize="characters" className="font-mono tracking-wider" />
          </Field>
          <Field label="Email">
            <Input type="email" inputMode="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          {error && <p role="alert" className="rounded-2xl bg-coral-50 px-4 py-3 text-sm font-medium text-coral-800">{error}</p>}
          <Button type="submit" variant="danger" className="w-full" loading={busy}>Annulla prenotazione</Button>
        </form>
      )}
    </div>
  );
}
