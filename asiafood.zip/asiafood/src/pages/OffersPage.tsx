import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { LocateFixed, X } from 'lucide-react';
import { APP } from '@/config/app';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useSeo } from '@/lib/seo';
import { localNow } from '@/lib/reservations';
import { api } from '@/services';
import { filterOffers } from '@/services/filters';
import type { OfferType, OfferWithRestaurant } from '@/types/domain';
import { OFFER_TYPE_LABELS, OfferCard } from '@/components/restaurant/Offers';
import { SponsoredSlots } from '@/components/restaurant/SponsoredSlots';
import { Rail } from '@/components/restaurant/RestaurantRail';
import { Chip } from '@/components/ui/Badge';
import { Input, Select } from '@/components/ui/Field';
import { EmptyState, SectionHeader } from '@/components/ui/Layout';

/** /offers — offerte attive realmente disponibili, con sezioni e filtri. */
export default function OffersPage() {
  const { cities, categories, cityBySlug } = useReferenceData();
  const [params, setParams] = useSearchParams();
  const geo = useGeolocation('offers');
  const f = {
    citySlug: params.get('city') ?? undefined,
    categorySlug: params.get('category') ?? undefined,
    date: params.get('date') ?? undefined,
    offerType: (params.get('type') as OfferType | null) ?? undefined,
  };
  const filtered = !!(f.citySlug || f.categorySlug || f.date || f.offerType);
  const all = useAsync(() => api.getActiveOffers({}), []);
  const today = localNow().date;
  const defaultCity = cityBySlug(APP.defaultCitySlug);

  useSeo({
    title: 'Offerte nei ristoranti asiatici: sushi, All You Can Eat e promo',
    description: `Offerte attive di sushi, All You Can Eat, ramen e cucina asiatica a ${APP.launchArea}: menu speciali, happy hour, 2x1 e coupon.`,
    path: '/offers',
    noindex: params.toString().length > 0,
  });

  const set = (k: string, v?: string) => {
    const p = new URLSearchParams(params);
    if (v) p.set(k, v);
    else p.delete(k);
    setParams(p, { replace: true });
  };

  const rows = useMemo(() => all.data ?? [], [all.data]);
  const results = useMemo(() => filterOffers(rows, f), [rows, f.citySlug, f.categorySlug, f.date, f.offerType]); // eslint-disable-line react-hooks/exhaustive-deps
  const sections = useMemo(() => {
    const list: { key: string; title: string; eyebrow?: string; items: OfferWithRestaurant[]; to?: string }[] = [];
    if (geo.coords) list.push({ key: 'near', title: 'Offerte vicino a te', eyebrow: 'Entro 15 km', items: filterOffers(rows, { near: { ...geo.coords, radiusKm: 15 }, limit: 12 }) });
    if (defaultCity) list.push({ key: 'city', title: `Offerte a ${defaultCity.name}`, items: filterOffers(rows, { citySlug: defaultCity.slug, limit: 12 }), to: `/offers?city=${defaultCity.slug}` });
    list.push({ key: 'today', title: 'Offerte di oggi', eyebrow: 'Valide oggi', items: filterOffers(rows, { date: today, limit: 12 }), to: `/offers?date=${today}` });
    list.push({ key: 'ayce', title: 'Offerte All You Can Eat', items: filterOffers(rows, { ayce: true, limit: 12 }), to: '/offers?category=all-you-can-eat' });
    list.push({ key: 'sushi', title: 'Offerte sushi', items: filterOffers(rows, { categorySlug: 'sushi', limit: 12 }), to: '/offers?category=sushi' });
    return list.filter((s) => s.items.length > 0);
  }, [rows, geo.coords, defaultCity, today]);

  return (
    <div className="pb-12 pt-8">
      <div className="container-app">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-coral">Promozioni attive</p>
        <h1 className="mt-1 text-3xl font-extrabold sm:text-5xl">Offerte</h1>
        <p className="mt-3 max-w-2xl text-lg text-ink-muted">Menu speciali, happy hour, 2x1, promo All You Can Eat e coupon dei ristoranti. Solo offerte attive.</p>

        {/* Filtri */}
        <div className="mt-6 grid gap-3 rounded-4xl border border-line bg-white p-4 sm:grid-cols-2 lg:grid-cols-4" role="search" aria-label="Filtra le offerte">
          <label className="block">
            <span className="label">Città</span>
            <Select value={f.citySlug ?? ''} onChange={(e) => set('city', e.target.value || undefined)}>
              <option value="">Tutte</option>
              {cities.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
            </Select>
          </label>
          <label className="block">
            <span className="label">Categoria</span>
            <Select value={f.categorySlug ?? ''} onChange={(e) => set('category', e.target.value || undefined)}>
              <option value="">Tutte</option>
              {categories.map((c) => <option key={c.id} value={c.slug}>{c.emoji} {c.name}</option>)}
            </Select>
          </label>
          <label className="block">
            <span className="label">Data</span>
            <Input type="date" min={today} value={f.date ?? ''} onChange={(e) => set('date', e.target.value || undefined)} />
          </label>
          <label className="block">
            <span className="label">Tipo di offerta</span>
            <Select value={f.offerType ?? ''} onChange={(e) => set('type', e.target.value || undefined)}>
              <option value="">Tutti</option>
              {(Object.keys(OFFER_TYPE_LABELS) as OfferType[]).map((t) => <option key={t} value={t}>{OFFER_TYPE_LABELS[t]}</option>)}
            </Select>
          </label>
          <div className="flex flex-wrap items-center gap-2 sm:col-span-2 lg:col-span-4">
            <Chip active={f.date === today} onClick={() => set('date', f.date === today ? undefined : today)} className="!h-9">Valide oggi</Chip>
            {!geo.coords && (
              <Chip onClick={() => void geo.request()} icon={<LocateFixed className="h-4 w-4" />} className="!h-9">
                {geo.status === 'loading' ? 'Localizzo…' : 'Offerte vicino a me'}
              </Chip>
            )}
            {filtered && (
              <button type="button" onClick={() => setParams(new URLSearchParams(), { replace: true })} className="inline-flex items-center gap-1 text-sm font-semibold text-coral-700 hover:underline">
                <X className="h-4 w-4" /> Cancella filtri
              </button>
            )}
            {geo.message && <span className="text-sm text-amber-800">{geo.message}</span>}
          </div>
        </div>
      </div>

      {all.loading ? (
        <div className="container-app mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }, (_, i) => <div key={i} className="skeleton h-80 rounded-3xl" />)}
        </div>
      ) : all.error ? (
        <div className="container-app mt-8">
          <EmptyState icon="⚠️" title="Non riusciamo a caricare le offerte" text="Controlla la connessione e riprova." action={<button onClick={all.reload} className="font-semibold text-coral-700">Riprova</button>} />
        </div>
      ) : filtered ? (
        <div className="container-app mt-8">
          <p className="mb-4 text-sm text-ink-muted" aria-live="polite">{results.length} {results.length === 1 ? 'offerta' : 'offerte'}</p>
          {results.length === 0 ? (
            <EmptyState icon="🏷️" title="Nessuna offerta con questi filtri" text="Prova a cambiare città, data o tipo di offerta." />
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{results.map((o) => <OfferCard key={o.id} o={o} />)}</div>
          )}
        </div>
      ) : rows.length === 0 ? (
        <div className="container-app mt-8">
          <EmptyState icon="🏷️" title="Nessuna offerta al momento" text="Torna presto: i locali aggiornano spesso le promozioni." />
        </div>
      ) : (
        <>
          <div className="container-app mt-8">
            <SponsoredSlots placement="offers_featured" citySlug={f.citySlug} title="In evidenza · Sponsorizzato" />
          </div>
          {sections.map((s) => (
            <section key={s.key} className="container-app py-6">
              <SectionHeader eyebrow={s.eyebrow} title={s.title} to={s.to} />
              <Rail label={s.title}>
                {s.items.map((o) => (
                  <div key={o.id} className="w-[82%] shrink-0 snap-start sm:w-[46%] lg:w-[calc(33.333%-11px)]">
                    <OfferCard o={o} />
                  </div>
                ))}
              </Rail>
            </section>
          ))}
          <section className="container-app py-6">
            <SectionHeader title="Tutte le offerte" />
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{rows.map((o) => <OfferCard key={o.id} o={o} />)}</div>
          </section>
        </>
      )}
    </div>
  );
}
