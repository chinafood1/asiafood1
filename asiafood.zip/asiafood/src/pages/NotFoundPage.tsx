import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Compass, Home, Map, Search } from 'lucide-react';
import { useSeo } from '@/lib/seo';
import { ButtonLink } from '@/components/ui/Button';

/** 404 professionale: suggerimenti (Home, Esplora, Mappa) e ricerca diretta. Mai indicizzata. */
export default function NotFoundPage({ what = 'pagina' }: { what?: string }) {
  useSeo({ title: 'Pagina non trovata', noindex: true });
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  return (
    <div className="container-app flex min-h-[60vh] flex-col items-center justify-center py-16 text-center" data-testid="not-found">
      <p className="text-7xl" aria-hidden>🥢</p>
      <p className="mt-4 text-sm font-bold uppercase tracking-widest text-coral-700">Errore 404</p>
      <h1 className="mt-2 text-3xl font-extrabold sm:text-4xl">Questa {what} non esiste (più)</h1>
      <p className="mt-2 max-w-md text-ink-muted">Forse il link è cambiato, l’offerta è scaduta o il locale non è più attivo. Prova a cercarlo:</p>
      <form className="mt-6 flex w-full max-w-md gap-2" role="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) navigate(`/restaurants?q=${encodeURIComponent(q.trim())}`); }}>
        <label className="sr-only" htmlFor="nf-q">Cerca un ristorante</label>
        <input id="nf-q" className="input flex-1" placeholder="Sushi, ramen, nome del locale…" value={q} onChange={(e) => setQ(e.target.value)} />
        <button type="submit" className="inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 font-semibold text-white"><Search className="h-4 w-4" aria-hidden />Cerca</button>
      </form>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <ButtonLink to="/" icon={<Home className="h-4 w-4" />}>Home</ButtonLink>
        <ButtonLink to="/restaurants" variant="outline" icon={<Compass className="h-4 w-4" />}>Esplora ristoranti</ButtonLink>
        <ButtonLink to="/map" variant="outline" icon={<Map className="h-4 w-4" />}>Mappa</ButtonLink>
      </div>
    </div>
  );
}
