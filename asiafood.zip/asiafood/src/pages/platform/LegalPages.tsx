// ─────────────────────────────────────────────────────────────
//  Pagine legali: STRUTTURE/TEMPLATE, non testi definitivi.
//  Ogni pagina è marcata "Da revisionare con consulente legale" e contiene segnaposto [DA COMPLETARE]
//  per i dati societari e le scelte che spettano al titolare (basi giuridiche, fornitori, tempi).
// ─────────────────────────────────────────────────────────────
import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle } from 'lucide-react';
import { APP } from '@/config/app';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { openConsentPreferences } from '@/lib/consent';
import { useSeo } from '@/lib/seo';
import { t } from '@/i18n';
import type { LegalDocumentType } from '@/types/platform';

const P = () => <mark className="rounded bg-amber-100 px-1 text-amber-900">{t('legal.placeholder')}</mark>;

function useCompany() {
  const { setting } = useRuntimeConfig();
  const v = (k: string) => (setting<string | null>(k, null) || null);
  return { name: v('legal_company_name'), vat: v('legal_vat_number'), address: v('legal_address'), email: v('legal_email'), pec: v('legal_pec'), support: v('support_email') };
}

function Val({ v }: { v: string | null }) {
  return v ? <strong>{v}</strong> : <P />;
}

function LegalLayout({ type, title, intro, children }: { type: LegalDocumentType; title: string; intro: string; children: ReactNode }) {
  const { config } = useRuntimeConfig();
  const doc = config.legal[type];
  // Bozza: non indicizzata finché non è revisionata
  useSeo({ title, description: intro, path: doc?.url, noindex: doc?.draft !== false });
  return (
    <article className="container-app max-w-3xl py-10" data-testid={`legal-${type}`}>
      <div role="note" className="mb-6 flex gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
        <AlertTriangle className="h-5 w-5 shrink-0" aria-hidden />
        <p><strong>{t('legal.draft')}.</strong> Questa è una struttura di lavoro: i contenuti segnati {t('legal.placeholder')} e le scelte indicate vanno completati e verificati prima della pubblicazione definitiva.</p>
      </div>
      <h1 className="text-3xl font-extrabold sm:text-4xl">{title}</h1>
      <p className="mt-2 text-sm text-ink-muted">
        Versione {doc?.version ?? '—'}{doc?.effective_at ? ` · in vigore dal ${new Date(doc.effective_at).toLocaleDateString('it-IT')}` : ''}{doc?.draft ? ' · bozza' : ''}
      </p>
      <p className="mt-4 text-ink-soft">{intro}</p>
      <div className="legal-body mt-8 space-y-6 text-[15px] leading-relaxed text-ink-soft [&_h2]:mt-8 [&_h2]:text-xl [&_h2]:font-bold [&_h2]:text-ink [&_li]:ml-5 [&_li]:list-disc [&_table]:w-full [&_td]:border-t [&_td]:border-line [&_td]:py-2 [&_td]:pr-3 [&_td]:align-top [&_th]:pb-2 [&_th]:pr-3 [&_th]:text-left [&_th]:text-ink">
        {children}
      </div>
    </article>
  );
}

function Controller() {
  const c = useCompany();
  return (
    <p>
      Titolare del trattamento: <Val v={c.name} />, P.IVA <Val v={c.vat} />, sede <Val v={c.address} />. Contatto privacy: <Val v={c.email} />{c.pec ? <>, PEC <strong>{c.pec}</strong></> : null}.
      Responsabile della protezione dei dati (DPO), se nominato: <P />.
    </p>
  );
}

export function PrivacyPage() {
  return (
    <LegalLayout type="privacy" title="Informativa privacy" intro={`Come ${APP.name} tratta i dati personali di utenti, clienti e visitatori.`}>
      <h2>1. Titolare del trattamento</h2>
      <Controller />
      <h2>2. Dati trattati, finalità e basi giuridiche</h2>
      <table>
        <thead><tr><th>Dati</th><th>Finalità</th><th>Base giuridica (da confermare)</th></tr></thead>
        <tbody>
          <tr><td>Account: nome, email, telefono (facoltativo)</td><td>Registrazione, accesso, assistenza</td><td>Esecuzione del contratto</td></tr>
          <tr><td>Prenotazioni e ordini: nome, contatti, indirizzo di consegna, dettagli dell’ordine</td><td>Gestione di prenotazioni, ordini, consegne, rimborsi</td><td>Esecuzione del contratto; obblighi di legge (contabilità)</td></tr>
          <tr><td>Pagamenti (gestiti da Stripe: AsiaFood non conserva numero di carta né CVC)</td><td>Incasso e prevenzione frodi</td><td>Contratto; legittimo interesse <P /></td></tr>
          <tr><td>Recensioni, preferiti, AsiaPoints, inviti</td><td>Funzioni della piattaforma</td><td>Contratto</td></tr>
          <tr><td>Posizione approssimata (solo se consentita dal browser, non salvata)</td><td>Locali vicini</td><td>Consenso</td></tr>
          <tr><td>Conversazioni con l’assistente AI (conservate per pochi giorni)</td><td>Rispondere alle domande</td><td>Contratto / legittimo interesse <P /></td></tr>
          <tr><td>Statistiche di utilizzo e prestazioni</td><td>Migliorare il servizio</td><td>Consenso (cookie «Statistiche»)</td></tr>
          <tr><td>Comunicazioni promozionali</td><td>Offerte e novità</td><td>Consenso (revocabile)</td></tr>
          <tr><td>Log tecnici e di sicurezza (indirizzo IP solo in forma di hash)</td><td>Sicurezza, prevenzione abusi</td><td>Legittimo interesse</td></tr>
        </tbody>
      </table>
      <h2>3. Destinatari e responsabili del trattamento</h2>
      <p>Fornitori che trattano dati per conto del titolare (con nomina ex art. 28 GDPR da verificare): hosting e database (Supabase), hosting del sito (Netlify), pagamenti (Stripe), mappe (Mapbox, se attivo), email transazionali <P />, assistente AI <P />, error tracking (Sentry, se attivo). I ristoranti ricevono i dati necessari a gestire prenotazioni e ordini; i Rider solo quelli necessari alla consegna.</p>
      <h2>4. Trasferimenti extra UE</h2>
      <p>Per i fornitori con sede o server fuori dallo Spazio Economico Europeo: garanzie adottate (clausole contrattuali standard / decisione di adeguatezza) <P />.</p>
      <h2>5. Conservazione</h2>
      <p>I tempi sono descritti nella tabella di retention (documento interno PRIVACY_DATA_MAP). In sintesi: dati contabili degli ordini per il periodo previsto dalla legge <P />; conversazioni AI 7 giorni; posizioni precise dei Rider 24 ore; statistiche 13 mesi; log di sicurezza 12 mesi.</p>
      <h2>6. Diritti dell’interessato</h2>
      <p>Accesso, rettifica, cancellazione, limitazione, portabilità, opposizione e revoca del consenso. Da <Link to="/settings/privacy" className="underline">Impostazioni → Privacy</Link> puoi scaricare i tuoi dati ed eliminare l’account; per le altre richieste scrivi a <P /> o usa il <Link to="/support" className="underline">supporto</Link>. Puoi proporre reclamo al Garante per la protezione dei dati personali.</p>
      <h2>7. Minori</h2>
      <p>Il servizio non è rivolto a minori di <P /> anni.</p>
      <h2>8. Modifiche</h2>
      <p>Le versioni dell’informativa sono registrate con data; in caso di modifiche rilevanti chiederemo di nuovo le scelte sui cookie.</p>
    </LegalLayout>
  );
}

export function CookiePolicyPage() {
  return (
    <LegalLayout type="cookie" title="Cookie policy" intro="Quali cookie e tecnologie simili usiamo, per cosa, e come gestire le tue scelte.">
      <p><button type="button" onClick={openConsentPreferences} className="font-semibold text-coral-700 underline" data-testid="open-consent">Apri le preferenze cookie</button></p>
      <h2>Categorie</h2>
      <table>
        <thead><tr><th>Categoria</th><th>Cosa comprende</th><th>Consenso</th></tr></thead>
        <tbody>
          <tr><td>Necessari</td><td>Sessione di accesso (Supabase), sicurezza, carrello, preferenze di consenso, lingua, installazione app (service worker)</td><td>Non richiesto (tecnici)</td></tr>
          <tr><td>Statistiche</td><td>Misure aggregate di utilizzo e prestazioni (Core Web Vitals) raccolte da AsiaFood stessa, senza servizi pubblicitari</td><td>Sì</td></tr>
          <tr><td>Marketing</td><td>Comunicazioni promozionali (email/notifiche) su offerte dei locali</td><td>Sì</td></tr>
          <tr><td>Personalizzazione</td><td>Suggerimenti basati sulle preferenze salvate</td><td>Sì</td></tr>
        </tbody>
      </table>
      <h2>Servizi di terze parti</h2>
      <p>Pagamento (Stripe, solo al checkout), mappe (Mapbox, se attive), verifica anti-bot (Cloudflare Turnstile, sui moduli). Elenco completo e durata dei cookie: <P />.</p>
      <h2>Durata della scelta</h2>
      <p>La scelta è conservata nel browser e registrata come prova (con un identificativo casuale per chi non ha un account). Viene richiesta di nuovo quando l’informativa cambia in modo rilevante.</p>
    </LegalLayout>
  );
}

export function TermsPage() {
  const c = useCompany();
  return (
    <LegalLayout type="terms" title="Termini di servizio" intro={`Condizioni d’uso di ${APP.name} per utenti e clienti.`}>
      <h2>1. Chi siamo</h2>
      <p>Il servizio è offerto da <Val v={c.name} /> (P.IVA <Val v={c.vat} />).</p>
      <h2>2. Il servizio</h2>
      <p>{APP.name} è una guida ai ristoranti asiatici con prenotazioni, offerte e ordini online. Le informazioni sui locali provengono dai ristoratori o da fonti pubbliche e possono cambiare: verifica orari e prezzi.</p>
      <h2>3. Ordini e pagamenti</h2>
      <p>Il contratto di vendita dei prodotti è con il ristorante <P />. Prezzi, commissioni e costi di consegna sono mostrati prima del pagamento. Annullamenti e rimborsi: <P />.</p>
      <h2>4. Recensioni</h2>
      <p>Le recensioni devono riguardare esperienze reali; possiamo moderarle secondo le regole pubblicate <P />.</p>
      <h2>5. Responsabilità, legge applicabile e foro</h2>
      <p><P /></p>
    </LegalLayout>
  );
}

export function BusinessTermsPage() {
  return (
    <LegalLayout type="business_terms" title="Condizioni per i ristoratori" intro="Condizioni per l’uso degli strumenti business, degli abbonamenti e degli ordini online.">
      <h2>1. Rivendicazione e gestione della scheda</h2><p><P /></p>
      <h2>2. Abbonamenti, prove gratuite e fatturazione</h2><p>Rinnovi, recesso, cambi di piano e fatture elettroniche: <P />.</p>
      <h2>3. Ordini online, commissioni e pagamenti (Stripe Connect)</h2><p>Commissione piattaforma, tempi di accredito, rimborsi e contestazioni: <P />.</p>
      <h2>4. Obblighi del ristoratore</h2><p>Informazioni corrette su prezzi, allergeni, orari; rispetto delle norme igienico-sanitarie <P />.</p>
      <h2>5. Trattamento dei dati dei clienti</h2><p>Ruoli privacy (titolari autonomi / responsabile) <P />.</p>
    </LegalLayout>
  );
}

export function RiderPrivacyPage() {
  return (
    <LegalLayout type="rider_privacy" title="Informativa privacy Rider" intro="Dati dei Rider: candidatura, documenti, posizione durante il turno, compensi.">
      <Controller />
      <h2>Posizione</h2>
      <p>Solo quando sei online e hai dato il consenso; posizioni precise conservate 24 ore; nessun tracciamento offline; nessuna sospensione automatica basata su un singolo dato GPS.</p>
      <h2>Documenti</h2>
      <p>Archiviati in uno spazio privato, visibili solo a te e allo staff autorizzato con link temporanei; conservazione <P />.</p>
      <h2>Valutazioni e statistiche</h2>
      <p>Basate su dati operativi (consegne, tempi), mai su caratteristiche personali.</p>
    </LegalLayout>
  );
}

export function RiderTermsPage() {
  return (
    <LegalLayout type="rider_terms" title="Condizioni di collaborazione Rider" intro="Condizioni per i Rider che effettuano consegne con AsiaFood.">
      <h2>Inquadramento</h2><p>Tipo di rapporto, assicurazione, dotazioni di sicurezza: <P />.</p>
      <h2>Compensi</h2><p>Regole pubblicate nell’app (base + distanza), approvazione e pagamento: <P />.</p>
      <h2>Sicurezza</h2><p>In caso di emergenza contatta il 112: l’app non sostituisce i servizi di emergenza.</p>
    </LegalLayout>
  );
}
