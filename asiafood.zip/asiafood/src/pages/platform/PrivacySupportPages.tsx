// ─────────────────────────────────────────────────────────────
//  /settings/privacy — scarica i miei dati, elimina account, consensi, preferenze privacy
//  /support          — FAQ, contatto, problemi con un ordine, supporto business e Rider, i miei ticket
// ─────────────────────────────────────────────────────────────
import { useCallback, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Bell, Bike, ChevronDown, Download, LifeBuoy, ShieldCheck, Store, Trash2, UserX } from 'lucide-react';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { Badge } from '@/components/ui/Badge';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { TurnstileWidget, turnstileEnabled } from '@/components/platform/Turnstile';
import { useAuth } from '@/context/AuthContext';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { useAsync } from '@/hooks/useAsync';
import { CONSENT_DEFAULT, openConsentPreferences, readConsent, writeConsent } from '@/lib/consent';
import { friendlyError } from '@/lib/errors';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import { fieldErrors, supportSchema } from '@shared/validation';
import { SUPPORT_CATEGORY_LABEL, SUPPORT_STATUS_LABEL, type ConsentChoices, type SupportCategory } from '@/types/platform';

const fmt = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleString('it-IT', { dateStyle: 'medium', timeStyle: 'short' }) : '—');

// ═════════════════════════════════════════════════════════════
//  /settings/privacy
// ═════════════════════════════════════════════════════════════
export function PrivacySettingsPage() {
  useSeo({ title: 'Privacy e dati', path: '/settings/privacy', noindex: true });
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (!user) {
    return (
      <div className="container-app py-12">
        <EmptyState icon="🔒" title="Accedi per gestire la privacy" text="Puoi comunque scegliere le preferenze cookie senza account."
          action={<div className="flex gap-2"><ButtonLink to="/accedi?next=%2Fsettings%2Fprivacy">Accedi</ButtonLink><Button variant="outline" onClick={openConsentPreferences}>Preferenze cookie</Button></div>} />
      </div>
    );
  }
  return <PrivacySettings />;
}

function PrivacySettings() {
  const toast = useToast();
  const { config } = useRuntimeConfig();
  const version = String(config.settings.consent_policy_version ?? '');
  const status = useAsync(() => api.getPrivacyStatus(), []);
  const [choices, setChoices] = useState<ConsentChoices>(() => readConsent()?.choices ?? CONSENT_DEFAULT);
  const [savingConsent, setSavingConsent] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [delOpen, setDelOpen] = useState(false);

  const saveConsent = async () => {
    setSavingConsent(true);
    try {
      writeConsent(choices, version);
      await api.recordConsent(choices, null, 'settings');
      toast('Preferenze salvate');
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setSavingConsent(false);
    }
  };

  const download = async () => {
    setExporting(true);
    try {
      const r = await api.exportMyData();
      // Il file viene creato nel browser: nessuna copia resta sul server
      const blob = new Blob([JSON.stringify(r.data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `asiafood-miei-dati-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      toast('Download avviato');
      status.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setExporting(false);
    }
  };

  const cancelDeletion = async () => {
    try {
      await api.cancelAccountDeletion();
      toast('Eliminazione annullata');
      status.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };

  const del = status.data?.deletion;
  const pendingDel = del && ['scheduled', 'blocked'].includes(del.status);

  return (
    <div className="container-app max-w-3xl py-8" data-testid="privacy-settings">
      <h1 className="text-3xl font-extrabold">Privacy e dati</h1>
      <p className="mt-1 text-ink-muted">Controlla i tuoi consensi, scarica una copia dei tuoi dati o elimina l’account.</p>

      {pendingDel && (
        <div className="mt-6"><Alert tone="error">
          <strong>Eliminazione account programmata</strong> per il {fmt(del!.scheduled_for)}.
          {del!.status === 'blocked' ? ' La richiesta richiede un intervento dello staff (es. sei titolare di un locale: serve prima il trasferimento).' : ' Fino ad allora puoi annullarla.'}
          {del!.status === 'scheduled' && <div className="mt-3"><Button size="sm" variant="outline" onClick={() => void cancelDeletion()} data-testid="cancel-deletion">Annulla eliminazione</Button></div>}
        </Alert></div>
      )}

      <section className="mt-8 rounded-3xl border border-line bg-white p-5">
        <h2 className="flex items-center gap-2 text-lg font-bold"><ShieldCheck className="h-5 w-5 text-coral" aria-hidden /> Gestisci consensi</h2>
        <div className="mt-2 divide-y divide-line">
          <Toggle checked disabled onChange={() => undefined} label="Necessari" description="Sessione, sicurezza, carrello. Sempre attivi." />
          <Toggle checked={choices.analytics} onChange={(v) => setChoices((c) => ({ ...c, analytics: v }))} label="Statistiche" description="Misure anonime di utilizzo e prestazioni." />
          <Toggle checked={choices.marketing} onChange={(v) => setChoices((c) => ({ ...c, marketing: v }))} label="Marketing" description="Offerte e novità via email e notifiche." />
          <Toggle checked={choices.personalization} onChange={(v) => setChoices((c) => ({ ...c, personalization: v }))} label="Personalizzazione" description="Suggerimenti basati sulle tue preferenze." />
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button onClick={() => void saveConsent()} loading={savingConsent} data-testid="save-consents">Salva consensi</Button>
          <Link to="/cookie-policy" className="self-center text-sm font-semibold text-ink-muted underline">Cookie policy</Link>
        </div>
      </section>

      <section className="mt-4 rounded-3xl border border-line bg-white p-5">
        <h2 className="flex items-center gap-2 text-lg font-bold"><Bell className="h-5 w-5 text-coral" aria-hidden /> Preferenze privacy</h2>
        <ul className="mt-2 space-y-2 text-sm">
          <li><Link to="/settings/notifications" className="font-semibold underline">Notifiche e comunicazioni</Link> — scegli quali messaggi ricevere.</li>
          <li><Link to="/profilo" className="font-semibold underline">Profilo</Link> — nome visibile nelle recensioni e dati di contatto.</li>
          <li><Link to="/privacy" className="font-semibold underline">Informativa privacy</Link> — come trattiamo i dati.</li>
        </ul>
      </section>

      <section className="mt-4 rounded-3xl border border-line bg-white p-5">
        <h2 className="flex items-center gap-2 text-lg font-bold"><Download className="h-5 w-5 text-coral" aria-hidden /> Scarica i miei dati</h2>
        <p className="mt-1 text-sm text-ink-muted">Un file JSON con profilo, preferiti, recensioni, prenotazioni, ordini, AsiaPoints, inviti, preferenze e consensi. Massimo 3 download al giorno.</p>
        <Button className="mt-4" variant="dark" onClick={() => void download()} loading={exporting} data-testid="export-data">Scarica i miei dati</Button>
        {!!status.data?.exports.length && (
          <p className="mt-3 text-xs text-ink-muted">Ultima richiesta: {fmt(status.data.exports[0]!.requested_at)}</p>
        )}
      </section>

      <section className="mt-4 rounded-3xl border border-coral-200 bg-white p-5">
        <h2 className="flex items-center gap-2 text-lg font-bold text-coral-700"><UserX className="h-5 w-5" aria-hidden /> Elimina account</h2>
        <p className="mt-1 text-sm text-ink-muted">
          L’eliminazione avviene dopo {status.data?.grace_days ?? 7} giorni (puoi annullarla prima). Gli ordini restano per obblighi contabili ma senza i tuoi dati personali;
          preferiti, AsiaPoints, notifiche e indirizzi vengono cancellati.
        </p>
        <Button className="mt-4" variant="danger" icon={<Trash2 className="h-4 w-4" />} disabled={!!pendingDel} onClick={() => setDelOpen(true)} data-testid="delete-account">Elimina account</Button>
      </section>
      <DeleteAccountSheet open={delOpen} onClose={() => setDelOpen(false)} onDone={() => status.reload()} />
    </div>
  );
}

function DeleteAccountSheet({ open, onClose, onDone }: { open: boolean; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.requestAccountDeletion(password, reason || null);
      toast('Eliminazione programmata: riceverai una notifica');
      onClose();
      onDone();
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet open={open} onClose={onClose} title="Elimina account"
      footer={<Button variant="danger" className="w-full" disabled={confirm.trim().toUpperCase() !== 'ELIMINA' || !password} loading={busy} onClick={() => void submit()} data-testid="confirm-delete">Programma eliminazione</Button>}>
      <p className="text-sm text-ink-muted">Per sicurezza conferma la password (ri-autenticazione) e scrivi <strong>ELIMINA</strong>.</p>
      <div className="mt-4 space-y-3">
        <Field label="Password"><Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} data-testid="delete-password" /></Field>
        <Field label="Scrivi ELIMINA per confermare"><Input value={confirm} onChange={(e) => setConfirm(e.target.value)} data-testid="delete-confirm" /></Field>
        <Field label="Motivo (facoltativo)"><Textarea value={reason} maxLength={500} onChange={(e) => setReason(e.target.value)} /></Field>
        {error && <Alert tone="error">{error}</Alert>}
      </div>
    </Sheet>
  );
}

// ═════════════════════════════════════════════════════════════
//  /support
// ═════════════════════════════════════════════════════════════
const FAQ: { q: string; a: string }[] = [
  { q: 'Il mio ordine è in ritardo o c’è un problema', a: 'Apri il tracciamento dal link ricevuto dopo il pagamento: trovi lo stato e l’orario stimato. Se qualcosa non va, usa il modulo qui sotto scegliendo «Ordine» e indica il numero (AF-…). Per un rimborso decide il ristorante o lo staff AsiaFood.' },
  { q: 'Come annullo o modifico una prenotazione?', a: 'Dal link nella conferma (pagina «Gestisci prenotazione») con il codice ricevuto. Per richieste particolari contatta direttamente il locale.' },
  { q: 'Le informazioni di un locale sono sbagliate', a: 'Dalla scheda del locale usa «Segnala un errore», oppure scrivici con la categoria «Informazioni su un locale».' },
  { q: 'Sono un ristoratore: come gestisco la mia scheda?', a: 'Rivendica il locale dalla sua scheda e completa la verifica. Per piani, fatture e pagamenti scegli «Per ristoratori» o «Fatturazione».' },
  { q: 'Sono un Rider: a chi mi rivolgo?', a: 'Per consegne in corso usa «Ho un problema» nell’app Rider. Per compensi, documenti e account scegli la categoria «Rider e consegne». In caso di emergenza chiama il 112.' },
  { q: 'Come scarico o cancello i miei dati?', a: 'Da Impostazioni → Privacy puoi scaricare una copia dei dati ed eliminare l’account (con 7 giorni per ripensarci).' },
];

/** Fase 12 · FAQ di lancio per categoria (clienti e ristoratori). Nessuna promessa di tempi garantiti. */
const FAQ_GROUPS: { title: string; items: { q: string; a: string }[] }[] = [
  { title: 'Account', items: [
    { q: 'Devo registrarmi per usare AsiaFood?', a: 'No: puoi cercare, vedere menu, mappa e offerte senza account. Serve un account per sincronizzare i preferiti, salvare coupon, accumulare punti e scrivere recensioni.' },
    { q: 'Ho dimenticato la password', a: 'Dalla pagina Accedi usa «Password dimenticata»: ricevi un’email per reimpostarla.' },
  ] },
  { title: 'Ristoranti', items: [
    { q: 'Quali locali trovo su AsiaFood?', a: 'Solo ristoranti di cucina asiatica di Taranto e provincia. Le schede non ancora rivendicate sono costruite da fonti pubbliche e indicate come tali.' },
    { q: 'Il locale risulta aperto ma è chiuso', a: 'Segnalacelo dalla scheda («Segnala un errore»): le segnalazioni sui dati errati hanno la priorità.' },
  ] },
  { title: 'Prenotazioni', items: [
    { q: 'La prenotazione è confermata subito?', a: 'Dipende dal locale: alcuni confermano automaticamente, altri manualmente. Lo stato è sempre indicato nella conferma e nella pagina «Gestisci prenotazione».' },
  ] },
  { title: 'Ordini e pagamenti', items: [
    { q: 'Quando viene addebitato l’ordine?', a: 'Il pagamento avviene con Stripe al momento dell’ordine; l’ordine è confermato solo dopo la conferma del pagamento. I dati della carta non passano da AsiaFood.' },
    { q: 'Come chiedo un rimborso?', a: 'Scrivici con la categoria «Ordine» indicando il numero AF-…: valutano il ristorante o lo staff, secondo le condizioni dell’ordine.' },
  ] },
  { title: 'Coupon e AsiaPoints', items: [
    { q: 'Come uso un coupon?', a: 'Salvalo dalla scheda del locale e mostralo in cassa: le condizioni (giorni, spesa minima, scadenza) sono sempre scritte sul coupon.' },
    { q: 'Come funzionano gli AsiaPoints?', a: 'Si accumulano con azioni concluse (prenotazioni completate, coupon usati, recensioni verificate, inviti qualificati) secondo il regolamento in Profilo → Punti. Mai in cambio di recensioni positive.' },
  ] },
  { title: 'Per ristoratori', items: [
    { q: 'Come rivendico il mio locale?', a: 'Dalla scheda del locale: «È il tuo locale?» → verifica. È gratuita. Se il locale non c’è ancora, scrivici con la categoria «Ristoratori · Rivendicazione».' },
    { q: 'Come aggiorno il menu?', a: 'Dashboard → il tuo locale → Menu: categorie, piatti, prezzi e allergeni. I piatti esauriti si nascondono con un tocco.' },
    { q: 'Come funziona l’abbonamento?', a: 'La scheda base è gratuita. I piani a pagamento si attivano da Dashboard → Piani e si gestiscono da Fatturazione; la disdetta è sempre possibile dalla dashboard.' },
    { q: 'Come funzionano le sponsorizzazioni?', a: 'Sono facoltative e sempre etichettate come «Sponsorizzato» al pubblico. Si gestiscono da Dashboard → Sponsorizzazioni.' },
    { q: 'Posso ricevere ordini online?', a: 'Sì, se il modulo è attivo per il tuo locale: Dashboard → Impostazioni ordini e Pagamenti ordini (Stripe Connect).' },
  ] },
];

export function SupportPage() {
  useSeo({ title: 'Supporto', description: 'Domande frequenti e contatti per clienti, ristoratori e Rider.', path: '/support' });
  const { user } = useAuth();
  const [params] = useSearchParams();
  const tickets = useAsync(() => (user ? api.getMySupportTickets() : Promise.resolve([])), [user?.id]);
  const initial = (params.get('category') as SupportCategory | null) ?? (params.get('order') ? 'order' : 'other');
  return (
    <div className="container-app max-w-4xl py-8" data-testid="support-page">
      <h1 className="text-3xl font-extrabold">Supporto</h1>
      <p className="mt-1 text-ink-muted">Risposte rapide e un modulo per scriverci. Rispondiamo di solito entro 1 giorno lavorativo.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <Link to="/support?category=order#contatto" className="rounded-3xl border border-line bg-white p-4 hover:shadow-card"><LifeBuoy className="h-5 w-5 text-coral" aria-hidden /><p className="mt-2 font-semibold">Problema con un ordine</p><p className="text-sm text-ink-muted">Numero ordine e link di tracciamento</p></Link>
        <Link to="/support?category=business#contatto" className="rounded-3xl border border-line bg-white p-4 hover:shadow-card"><Store className="h-5 w-5 text-coral" aria-hidden /><p className="mt-2 font-semibold">Supporto ristoratori</p><p className="text-sm text-ink-muted">Scheda, piani, pagamenti</p></Link>
        <Link to="/support?category=rider#contatto" className="rounded-3xl border border-line bg-white p-4 hover:shadow-card"><Bike className="h-5 w-5 text-coral" aria-hidden /><p className="mt-2 font-semibold">Supporto Rider</p><p className="text-sm text-ink-muted">Consegne, compensi, documenti</p></Link>
      </div>

      <section className="mt-10" aria-labelledby="faq">
        <h2 id="faq" className="text-xl font-bold">Domande frequenti</h2>
        <div className="mt-3 divide-y divide-line rounded-3xl border border-line bg-white">
          {FAQ.map((f) => (
            <details key={f.q} className="group p-4">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-3 font-semibold">{f.q}<ChevronDown className="h-4 w-4 shrink-0 transition group-open:rotate-180" aria-hidden /></summary>
              <p className="mt-2 text-sm text-ink-muted">{f.a}</p>
            </details>
          ))}
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2" data-testid="faq-groups">
          {FAQ_GROUPS.map((g) => (
            <div key={g.title} className="rounded-3xl border border-line bg-white p-4">
              <h3 className="font-bold">{g.title}</h3>
              {g.items.map((f) => (
                <details key={f.q} className="group mt-2">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-sm font-semibold">{f.q}<ChevronDown className="h-4 w-4 shrink-0 transition group-open:rotate-180" aria-hidden /></summary>
                  <p className="mt-1 text-sm text-ink-muted">{f.a}</p>
                </details>
              ))}
            </div>
          ))}
        </div>
      </section>

      <section id="contatto" className="mt-10 scroll-mt-24">
        <h2 className="text-xl font-bold">Scrivici</h2>
        <SupportForm key={initial} initialCategory={initial} orderNumber={params.get('order') ?? ''} onSent={() => tickets.reload()} />
      </section>

      {user && (
        <section className="mt-10">
          <h2 className="text-xl font-bold">Le mie richieste</h2>
          {tickets.data?.length ? (
            <ul className="mt-3 divide-y divide-line rounded-3xl border border-line bg-white" data-testid="my-tickets">
              {tickets.data.map((t) => (
                <li key={t.id} className="flex flex-wrap items-center justify-between gap-2 p-4">
                  <div><p className="font-semibold">{t.subject}</p><p className="text-xs text-ink-muted">{t.reference} · {SUPPORT_CATEGORY_LABEL[t.category]} · {fmt(t.created_at)}</p>
                    {t.resolution && <p className="mt-1 text-sm text-ink-soft">{t.resolution}</p>}</div>
                  <Badge tone={['resolved', 'closed'].includes(t.status) ? 'green' : 'amber'}>{SUPPORT_STATUS_LABEL[t.status]}</Badge>
                </li>
              ))}
            </ul>
          ) : <p className="mt-2 text-sm text-ink-muted">Nessuna richiesta inviata.</p>}
        </section>
      )}
    </div>
  );
}

function SupportForm({ initialCategory, orderNumber, onSent }: { initialCategory: SupportCategory; orderNumber: string; onSent: () => void }) {
  const { user } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ category: initialCategory, subject: '', description: '', email: '', name: '', order_number: orderNumber, order_token: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const onToken = useCallback((t: string | null) => setToken(t), []);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const guestNeedsCaptcha = !user && turnstileEnabled();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const v = fieldErrors(supportSchema, { ...f, email: user ? '' : f.email });
    const errs = v.ok ? {} : { ...v.errors };
    if (!user && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email)) errs.email = 'Inserisci un’email per ricevere la risposta';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    if (guestNeedsCaptcha && !token) return setErrors({ _: 'Completa la verifica anti-bot.' });
    setBusy(true);
    try {
      const r = await api.createSupportTicket({ ...f, order_number: f.order_number || undefined, order_token: f.order_token || undefined, turnstile_token: token });
      setSent(r.reference);
      toast(`Richiesta inviata (${r.reference})`);
      onSent();
    } catch (err) {
      setErrors({ _: friendlyError(err) });
    } finally {
      setBusy(false);
    }
  };

  if (sent) {
    return <div className="mt-3"><Alert tone="success">Grazie! Abbiamo ricevuto la richiesta <strong data-testid="ticket-reference">{sent}</strong>. Ti risponderemo via email{user ? ' e nelle notifiche' : ''}.</Alert></div>;
  }
  return (
    <form onSubmit={(e) => void submit(e)} className="mt-3 space-y-4 rounded-3xl border border-line bg-white p-5" noValidate data-testid="support-form">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Argomento"><Select value={f.category} onChange={set('category')} data-testid="support-category">
          {Object.entries(SUPPORT_CATEGORY_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
        </Select></Field>
        {!user && <Field label="Email per la risposta" error={errors.email}><Input type="email" autoComplete="email" value={f.email} onChange={set('email')} data-testid="support-email" /></Field>}
        {!user && <Field label="Nome (facoltativo)"><Input autoComplete="name" value={f.name} onChange={set('name')} /></Field>}
        {(f.category === 'order' || f.category === 'rider' || f.category === 'billing') && (
          <Field label="Numero ordine (facoltativo)" hint="Es. AF-261004-AB12" error={errors.order_number}><Input value={f.order_number} onChange={set('order_number')} data-testid="support-order" /></Field>
        )}
        {!user && f.order_number && <Field label="Codice del link di tracciamento" hint="La parte dopo «t=» nel link ricevuto"><Input value={f.order_token} onChange={set('order_token')} /></Field>}
      </div>
      <Field label="Oggetto" error={errors.subject}><Input value={f.subject} maxLength={140} onChange={set('subject')} data-testid="support-subject" /></Field>
      <Field label="Descrizione" error={errors.description} hint="Non inserire dati di carte di pagamento o documenti."><Textarea value={f.description} maxLength={4000} onChange={set('description')} data-testid="support-description" /></Field>
      {guestNeedsCaptcha && <TurnstileWidget onToken={onToken} />}
      {errors._ && <Alert tone="error">{errors._}</Alert>}
      <Button type="submit" loading={busy} data-testid="support-submit">Invia richiesta</Button>
    </form>
  );
}
