import { useSearchParams } from 'react-router-dom';
import { Sparkles } from 'lucide-react';
import { AI, APP } from '@/config/app';
import { useSeo } from '@/lib/seo';
import { AssistantChat } from '@/components/ai/AssistantChat';
import { EmptyState } from '@/components/ui/Layout';
import { ButtonLink } from '@/components/ui/Button';

/** /assistant — AI Food Assistant: trova ristoranti, piatti, offerte e posti liberi con i dati della piattaforma. */
export default function AssistantPage() {
  const [params] = useSearchParams();
  const q = params.get('q')?.slice(0, 500) ?? null;
  useSeo({
    title: `Cosa vuoi mangiare? — Assistente ${APP.name}`,
    description: 'Chiedi all’assistente: sushi, ramen, all you can eat, offerte e ristoranti aperti ora, con i dati reali dei locali.',
    path: '/assistant',
    // Le conversazioni non sono pagine da indicizzare
    noindex: params.toString().length > 0,
  });
  if (!AI.enabled) {
    return (
      <div className="container-app py-16">
        <EmptyState icon={<Sparkles className="h-6 w-6" />} title="Assistente non disponibile" text="Puoi continuare a cercare ristoranti con la ricerca e la mappa." action={<ButtonLink to="/restaurants">Vai alla ricerca</ButtonLink>} />
      </div>
    );
  }
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="border-b border-line bg-paper">
        <div className="container-app flex items-center gap-3 py-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-coral-50 text-coral-700">
            <Sparkles className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h1 className="text-xl font-bold leading-tight">Cosa vuoi mangiare?</h1>
            <p className="truncate text-xs text-ink-muted">AI Food Assistant · solo dati reali dei ristoranti di {APP.name}</p>
          </div>
        </div>
      </header>
      <AssistantChat initialPrompt={q} />
    </div>
  );
}
