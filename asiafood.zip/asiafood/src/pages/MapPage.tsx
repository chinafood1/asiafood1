import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Bike, List, LocateFixed, Map as MapIcon, RefreshCw, Search, ShieldCheck, SlidersHorizontal, Sparkles, X } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { useRadius } from '@/hooks/useRadius';
import { AI, RADIUS_OPTIONS } from '@/config/app';
import { useSeo } from '@/lib/seo';
import { cn } from '@/lib/format';
import { filtersFromParams, filtersToParams } from '@/lib/filterParams';
import { normalizeText, parseSearchQuery } from '@/lib/searchQuery';
import { InteractiveMap } from '@/lib/maps/InteractiveMap';
import {
  boundsAround,
  boundsFromParam,
  boundsOf,
  boundsToParam,
  LAUNCH_BOUNDS,
  roundBounds,
  type GeoBounds,
  type MapHandle,
  type MapPoint,
  type MoveEndEvent,
} from '@/lib/maps/types';
import { api, type SortKey } from '@/services';
import type { RestaurantSummary } from '@/types/domain';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Field';
import { Sheet } from '@/components/ui/Sheet';
import { BottomSheet, type SheetSnap } from '@/components/map/BottomSheet';
import { matchesOrderMode, useOrderable } from '@/hooks/useOrderable';
import { MapCardSkeleton, RestaurantMapCard } from '@/components/map/RestaurantMapCard';
import { SponsoredSlots } from '@/components/restaurant/SponsoredSlots';
import { ActiveFilterChips, type ExtraChip } from '@/components/search/ActiveFilterChips';
import { countActive, FiltersForm, type FilterState } from '@/components/search/FiltersPanel';

const PRIVACY = 'La tua posizione viene usata solo per mostrarti ristoranti nelle vicinanze.';
const MAP_SORTS: { value: SortKey; label: string }[] = [
  { value: 'distance', label: 'Più vicini' },
  { value: 'relevance', label: 'Pertinenza' },
  { value: 'popular', label: 'Più popolari' },
  { value: 'price_asc', label: 'Prezzo crescente' },
  { value: 'price_desc', label: 'Prezzo decrescente' },
];
/** Tetto di risultati per richiesta: la mappa non scarica mai l'intero database. */
const MAX_RESULTS = 300;
const hasCoords = (r: RestaurantSummary) => r.latitude != null && r.longitude != null;

/**
 * /map: mappa + lista sincronizzata.
 * Desktop: lista 40% a sinistra, mappa 60% fissa. Mobile: mappa a tutto schermo,
 * bottom sheet (chiuso / metà / pieno), carosello di card legato ai marker.
 */
export default function MapPage() {
  const [params, setParams] = useSearchParams();
  const { view: _view, ...filters } = useMemo(() => filtersFromParams(params), [params]);
  void _view;
  const bbox = useMemo(() => boundsFromParam(params.get('bbox')), [params]);
  const restaurantParam = params.get('restaurant');
  // /map?ids=… : risultati dell'assistente AI (solo ID, dati letti dal database)
  const idsParam = params.get('ids');
  const aiIds = useMemo(() => (idsParam ?? '').split(',').filter((x) => /^[0-9a-f-]{36}$/i.test(x)).slice(0, 20), [idsParam]);
  const idsMode = aiIds.length > 0;
  const { categories, cities, cityBySlug, ready } = useReferenceData();
  const geo = useGeolocation('map');
  const [savedRadius, setSavedRadius] = useRadius();
  const isDesktop = useMediaQuery('(min-width: 1024px)');

  const mapRef = useRef<MapHandle>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const carouselRef = useRef<HTMLDivElement>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [pendingBounds, setPendingBounds] = useState<GeoBounds | null>(null);
  const [snap, setSnap] = useState<SheetSnap>('closed');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [providerError, setProviderError] = useState<string | null>(null);
  const [geoDismissed, setGeoDismissed] = useState(false);

  // ── Modalità di ricerca ──────────────────────────────────────
  const coords = geo.coords;
  const radiusKm = filters.radiusKm ?? savedRadius;
  const nearMode = !idsMode && !!filters.useLocation && !!coords && !bbox;
  const city = cityBySlug(filters.citySlug);
  const mode = idsMode ? 'ids' : nearMode ? 'near' : bbox ? 'bbox' : filters.citySlug ? 'city' : 'all';
  const modeKey = idsMode ? `ids:${idsParam}` : nearMode ? `near:${coords!.lat},${coords!.lng},${radiusKm}` : mode === 'city' ? `city:${filters.citySlug}` : mode;

  const searchBounds: GeoBounds | undefined = nearMode ? roundBounds(boundsAround(coords!, radiusKm), 2) : (bbox ?? undefined);
  const near = coords ? { ...coords, radiusKm: nearMode ? radiusKm : undefined } : undefined;
  const sort: SortKey = filters.sort === 'distance' && !coords ? 'relevance' : (filters.sort ?? (nearMode ? 'distance' : 'relevance'));

  // La chiave esclude "restaurant" (selezione) così selezionare non rilancia la ricerca
  const searchKey = useMemo(() => {
    const p = new URLSearchParams(params);
    p.delete('restaurant');
    return p.toString();
  }, [params]);
  const result = useAsync(
    () =>
      idsMode
        ? api.getRestaurantsByIds(aiIds).then((list) => list.sort((a, b) => aiIds.indexOf(a.id) - aiIds.indexOf(b.id)))
        : api.searchRestaurants({
        ...filters,
        radiusKm: undefined,
        useLocation: undefined,
        bounds: searchBounds,
        near,
        sort,
        limit: MAX_RESULTS,
      } as FilterState),
    [searchKey, near?.lat, near?.lng, near?.radiusKm],
  );

  // Ristorante richiesto dal deeplink (/map?restaurant=slug): aggiunto alla lista se fuori area
  const [deeplinked, setDeeplinked] = useState<RestaurantSummary | null>(null);
  // Fase 8: filtro ordini online e "Consegna qui" (ristoranti che consegnano al centro della mappa)
  const orderable = useOrderable();
  const [deliverHere, setDeliverHere] = useState<{ ids: Set<string>; fee: Map<string, number> } | null>(null);
  const [deliverBusy, setDeliverBusy] = useState(false);
  const checkDeliverHere = async () => {
    const b = mapRef.current?.getBounds();
    const center = b ? { lat: (b.north + b.south) / 2, lng: (b.east + b.west) / 2 } : coords;
    if (!center) return;
    setDeliverBusy(true);
    try {
      const list = await api.getRestaurantsDeliveringTo(center.lat, center.lng);
      setDeliverHere({ ids: new Set(list.map((x) => x.restaurant_id)), fee: new Map(list.map((x) => [x.restaurant_id, x.delivery_fee])) });
    } catch {
      setDeliverHere({ ids: new Set(), fee: new Map() });
    } finally {
      setDeliverBusy(false);
    }
  };
  const rows = useMemo(() => {
    let list = result.data ?? [];
    const om = filters.orderMode;
    if (om && orderable) list = list.filter((r) => matchesOrderMode(orderable.get(r.id), om));
    if (deliverHere) list = list.filter((r) => deliverHere.ids.has(r.id));
    if (deeplinked && !list.some((r) => r.id === deeplinked.id)) return [deeplinked, ...list];
    return list;
  }, [result.data, deeplinked, filters.orderMode, orderable, deliverHere]);
  const mapped = useMemo(() => rows.filter(hasCoords), [rows]);
  const unmappedCount = rows.length - mapped.length;
  const points: MapPoint[] = useMemo(
    () => mapped.map((r) => ({ id: r.id, lat: r.latitude!, lng: r.longitude!, label: r.name, emoji: r.categories[0]?.emoji, sponsored: r.sponsored_now })),
    [mapped],
  );
  const landmarks = useMemo(
    () => cities.filter((c) => c.latitude != null && c.longitude != null).map((c) => ({ lat: c.latitude!, lng: c.longitude!, label: c.name, rank: c.population ?? 0 })),
    [cities],
  );
  const selected = rows.find((r) => r.id === selectedId) ?? null;

  // ── URL ─────────────────────────────────────────────────────
  const writeParams = useCallback(
    (f: FilterState, extra: { bbox?: string | null; restaurant?: string | null; ids?: string | null } = {}) => {
      const keepBbox = extra.bbox === undefined ? params.get('bbox') ?? undefined : extra.bbox ?? undefined;
      const keepRestaurant = extra.restaurant === undefined ? params.get('restaurant') ?? undefined : extra.restaurant ?? undefined;
      // Cambiare i filtri esce dai risultati dell'assistente; selezionare un locale no
      setParams(filtersToParams(f, { ids: extra.ids ?? undefined, bbox: keepBbox, restaurant: keepRestaurant }), { replace: true });
    },
    [params, setParams],
  );
  const update = (f: FilterState) => writeParams(f);

  // ── Analytics / SEO ─────────────────────────────────────────
  useEffect(() => {
    api.trackAppEvent('map_open', { source: params.get('ids') ? 'ai' : params.get('restaurant') ? 'restaurant' : params.get('city') ? 'city' : 'direct' });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (nearMode) api.trackAppEvent('near_me_search', { source: 'map', metadata: { radius_km: radiusKm } });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modeKey]);

  const title = city ? `Mappa dei ristoranti asiatici a ${city.name}` : 'Mappa dei ristoranti asiatici';
  useSeo({
    title,
    description: 'Trova ristoranti giapponesi, cinesi, thai e sushi sulla mappa: vicino a te o nel tuo comune.',
    path: '/map',
    noindex: params.toString().length > 0,
  });

  // ── Posizione ───────────────────────────────────────────────
  const startNearMe = async (km = radiusKm) => {
    setGeoDismissed(false);
    const c = coords ?? (await geo.request());
    if (!c) return;
    setSavedRadius(km);
    writeParams({ ...filters, citySlug: undefined, useLocation: true, radiusKm: km, sort: filters.sort }, { bbox: null });
    setPendingBounds(null);
  };

  // ── Adattamento della vista quando cambia la modalità (mai sulle ricerche per area) ──
  const fittedKey = useRef<string | null>(null);
  const deeplinkHandled = useRef<string | null>(null);
  useEffect(() => {
    if (result.loading || fittedKey.current === modeKey) return;
    const map = mapRef.current;
    if (!map) return;
    if (mode === 'bbox') {
      fittedKey.current = modeKey;
      return;
    }
    if (restaurantParam && deeplinkHandled.current !== restaurantParam) return; // ci pensa il deeplink
    fittedKey.current = modeKey;
    if (mode === 'near') return map.fitBounds(boundsAround(coords!, radiusKm), 24);
    const b = boundsOf(points);
    if (b) {
      if (points.length === 1) return map.flyTo(points[0]!, 14);
      return map.fitBounds(b, 48);
    }
    if (mode === 'city' && city?.latitude != null && city.longitude != null) return map.flyTo({ lat: city.latitude, lng: city.longitude }, 12);
    map.fitBounds(LAUNCH_BOUNDS, 24);
  }, [result.loading, modeKey, mode, points, coords, radiusKm, city, restaurantParam]);

  // Deeplink dalla scheda ristorante: seleziona e centra una sola volta
  useEffect(() => {
    if (!restaurantParam || deeplinkHandled.current === restaurantParam || result.loading) return;
    const local = rows.find((r) => r.slug === restaurantParam);
    const apply = (r: RestaurantSummary | null) => {
      deeplinkHandled.current = restaurantParam;
      if (!r) return;
      setSelectedId(r.id);
      if (hasCoords(r)) {
        fittedKey.current = modeKey;
        mapRef.current?.flyTo({ lat: r.latitude!, lng: r.longitude! }, 15);
      }
    };
    if (local) return apply(local);
    let cancelled = false;
    api.getRestaurantBySlug(restaurantParam).then((d) => {
      if (cancelled) return;
      if (d) setDeeplinked(d);
      apply(d);
    });
    return () => {
      cancelled = true;
    };
  }, [restaurantParam, rows, result.loading, modeKey]);

  // ── Selezione sincronizzata lista ⇄ mappa ───────────────────
  const ignoreCarouselUntil = useRef(0);
  const scrollCardIntoView = (id: string) => {
    if (isDesktop) {
      const el = listRef.current?.querySelector<HTMLElement>(`[data-id="${id}"]`);
      el?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
      const el = carouselRef.current?.querySelector<HTMLElement>(`[data-id="${id}"]`);
      if (el && carouselRef.current) {
        ignoreCarouselUntil.current = Date.now() + 700;
        const c = carouselRef.current;
        c.scrollTo({ left: el.offsetLeft - (c.clientWidth - el.clientWidth) / 2, behavior: 'smooth' });
      }
    }
  };

  const select = (id: string | null, from: 'marker' | 'card' | 'carousel' | 'map') => {
    setSelectedId(id);
    const r = id ? rows.find((x) => x.id === id) : null;
    deeplinkHandled.current = r?.slug ?? null;
    writeParams(filters, { restaurant: r?.slug ?? null, ids: idsParam });
    if (!r) return;
    if (from === 'marker') {
      api.trackAppEvent('restaurant_marker_click', { restaurantId: r.id, source: isDesktop ? 'map_desktop' : 'map_mobile' });
      if (!isDesktop) setSnap('closed');
      requestAnimationFrame(() => scrollCardIntoView(r.id));
    }
    if ((from === 'card' || from === 'carousel') && hasCoords(r)) {
      const zoom = mapRef.current?.getZoom() ?? 12;
      mapRef.current?.flyTo({ lat: r.latitude!, lng: r.longitude! }, from === 'card' && zoom < 13 ? 14 : undefined);
      if (from === 'card' && !isDesktop) setSnap('closed');
      if (from === 'card' && !isDesktop) requestAnimationFrame(() => scrollCardIntoView(r.id));
    }
  };

  // Carosello mobile: la card centrata diventa quella selezionata
  const carouselTimer = useRef<number>();
  const onCarouselScroll = () => {
    window.clearTimeout(carouselTimer.current);
    carouselTimer.current = window.setTimeout(() => {
      const c = carouselRef.current;
      if (!c || Date.now() < ignoreCarouselUntil.current) return;
      const mid = c.scrollLeft + c.clientWidth / 2;
      let best: HTMLElement | null = null;
      let dist = Infinity;
      c.querySelectorAll<HTMLElement>('[data-id]').forEach((el) => {
        const d = Math.abs(el.offsetLeft + el.clientWidth / 2 - mid);
        if (d < dist) {
          dist = d;
          best = el;
        }
      });
      const id = (best as HTMLElement | null)?.dataset.id;
      if (id && id !== selectedId) select(id, 'carousel');
    }, 140);
  };

  // ── "Cerca in questa zona" ──────────────────────────────────
  const onMoveEnd = (e: MoveEndEvent) => {
    if (e.userInitiated) setPendingBounds(e.bounds);
  };
  const searchThisArea = () => {
    const b = pendingBounds ?? mapRef.current?.getBounds();
    if (!b) return;
    const rb = roundBounds(b, 3);
    fittedKey.current = 'bbox';
    api.trackAppEvent('map_area_search', { source: isDesktop ? 'map_desktop' : 'map_mobile' });
    writeParams({ ...filters, citySlug: undefined, useLocation: undefined, radiusKm: undefined }, { bbox: boundsToParam(rb) });
    setPendingBounds(null);
  };

  // ── Ricerca testuale (comune → centra la mappa) ─────────────
  const [q, setQ] = useState(filters.q ?? '');
  const [suggestOpen, setSuggestOpen] = useState(false);
  useEffect(() => setQ(filters.q ?? ''), [filters.q]);
  const citySuggestions = useMemo(() => {
    const t = normalizeText(q);
    if (t.length < 2) return [];
    return cities.filter((c) => normalizeText(c.name).startsWith(t)).slice(0, 5);
  }, [q, cities]);
  const goToCity = (slug: string) => {
    setSuggestOpen(false);
    setQ('');
    setPendingBounds(null);
    writeParams({ ...filters, q: undefined, citySlug: slug, useLocation: undefined, radiusKm: undefined }, { bbox: null, restaurant: null });
    setSelectedId(null);
  };
  const submitQuery = (raw: string) => {
    setSuggestOpen(false);
    const text = raw.trim();
    if (!text) return update({ ...filters, q: undefined });
    const p = parseSearchQuery(text, categories, cities);
    const next: FilterState = {
      ...filters,
      q: p.text ? text.replace(/\s+/g, ' ') : undefined,
      categorySlug: p.categorySlug ?? (p.text ? filters.categorySlug : undefined),
      ayce: p.ayce || filters.ayce,
    };
    if (p.citySlug) {
      setPendingBounds(null);
      return writeParams({ ...next, citySlug: p.citySlug, useLocation: undefined, radiusKm: undefined }, { bbox: null, restaurant: null });
    }
    update(next);
  };

  // ── Filtri ──────────────────────────────────────────────────
  const onFiltersChange = (f: FilterState) => {
    if (f.radiusKm && f.radiusKm !== filters.radiusKm) {
      setSavedRadius(f.radiusKm);
      if (!coords) return void startNearMe(f.radiusKm);
      return writeParams({ ...f, useLocation: true, citySlug: undefined }, { bbox: null });
    }
    update(f);
  };
  const clearFilters = () =>
    writeParams(
      { citySlug: filters.citySlug, useLocation: filters.useLocation, radiusKm: filters.useLocation ? filters.radiusKm : undefined, sort: filters.sort },
      {},
    );
  const onSort = (s: SortKey) => {
    if (s === 'distance' && !coords) {
      void geo.request().then((c) => c && update({ ...filters, sort: 'distance' }));
      return;
    }
    update({ ...filters, sort: s === 'relevance' ? undefined : s });
  };
  const activeCount = countActive({ ...filters, citySlug: undefined, radiusKm: undefined });

  const areaChips: ExtraChip[] = [];
  if (bbox) areaChips.push({ key: 'bbox', label: 'Area della mappa', onRemove: () => writeParams(filters, { bbox: null }) });
  if (deliverHere) areaChips.push({ key: 'deliver', label: `Consegnano qui (${deliverHere.ids.size})`, onRemove: () => setDeliverHere(null) });
  if (idsMode) areaChips.push({ key: 'ids', label: `Suggeriti dall’assistente (${aiIds.length})`, onRemove: () => writeParams(filters, { ids: null, restaurant: null }) });

  // ── Testi di stato ──────────────────────────────────────────
  const where = idsMode ? 'suggeriti dall’assistente' : nearMode ? `entro ${radiusKm} km da te` : bbox ? 'in quest’area' : city ? `a ${city.name}` : 'nella zona di lancio';
  const nextRadius = RADIUS_OPTIONS.find((r) => r > radiusKm);
  const showGeoMessage = !!geo.message && !geoDismissed;

  // ── Blocchi riusati (lista desktop e bottom sheet mobile) ───
  const nearMeCta = !nearMode && (
    <div className="rounded-3xl border border-line bg-white p-4">
      <Button type="button" variant="dark" size="sm" onClick={() => void startNearMe()} loading={geo.status === 'loading'} icon={<LocateFixed className="h-4 w-4" />}>
        Trova ristoranti vicino a me
      </Button>
      <p className="mt-2 flex items-start gap-1.5 text-xs text-ink-muted">
        <ShieldCheck className="mt-px h-3.5 w-3.5 shrink-0" /> {PRIVACY}
      </p>
    </div>
  );

  const radiusPicker = nearMode && (
    <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Raggio di ricerca">
      <span className="mr-1 text-xs font-semibold text-ink-muted">Raggio</span>
      {RADIUS_OPTIONS.map((km) => (
        <button
          key={km}
          type="button"
          aria-pressed={km === radiusKm}
          onClick={() => {
            setSavedRadius(km);
            update({ ...filters, radiusKm: km, useLocation: true });
          }}
          className={cn('h-8 rounded-full px-3 text-xs font-semibold transition', km === radiusKm ? 'bg-ink text-white' : 'bg-white text-ink ring-1 ring-line hover:ring-ink/40')}
        >
          {km} km
        </button>
      ))}
    </div>
  );

  const sortSelect = (
    <Select value={sort} onChange={(e) => onSort(e.target.value as SortKey)} aria-label="Ordina" className="!h-9 !w-auto !py-0 !pl-3 text-sm">
      {MAP_SORTS.map((o) => (
        <option key={o.value} value={o.value}>
          {o.value === 'distance' && !coords ? 'Più vicini (usa posizione)' : o.label}
        </option>
      ))}
    </Select>
  );

  const emptyState = (
    <div className="rounded-3xl border border-dashed border-line bg-white/70 px-5 py-10 text-center">
      <div className="text-3xl" aria-hidden>🥢</div>
      <p className="mt-3 font-bold">Nessun ristorante trovato in quest'area.</p>
      <div className="mt-4 flex flex-wrap justify-center gap-2">
        {nearMode && nextRadius && (
          <Button size="sm" variant="dark" onClick={() => { setSavedRadius(nextRadius); update({ ...filters, radiusKm: nextRadius, useLocation: true }); }}>
            Aumenta il raggio ({nextRadius} km)
          </Button>
        )}
        {activeCount > 0 && (
          <Button size="sm" variant="outline" onClick={clearFilters}>
            Rimuovi alcuni filtri
          </Button>
        )}
        {mode !== 'all' && (
          <Button size="sm" variant="ghost" onClick={() => writeParams({ ...filters, citySlug: undefined, useLocation: undefined, radiusKm: undefined }, { bbox: null })}>
            Mostra tutta la zona
          </Button>
        )}
      </div>
    </div>
  );

  const listBody = (variant: 'desktop' | 'sheet') => (
    <div className="space-y-3">
      {!result.loading && rows.length > 0 && (
        <SponsoredSlots placement="map_featured" citySlug={filters.citySlug} limit={1} onlyIds={rows.map((r) => r.id)} variant="row" title="In evidenza · Sponsorizzato" />
      )}
      {result.error && (
        <div className="rounded-3xl bg-coral-50 p-4 text-sm text-coral-800" role="alert">
          Non riusciamo a caricare i ristoranti in questo momento.{' '}
          <button className="font-semibold underline" onClick={result.reload}>
            Riprova
          </button>
        </div>
      )}
      {result.loading && !result.data
        ? Array.from({ length: 4 }, (_, i) => <MapCardSkeleton key={i} />)
        : !result.error && rows.length === 0
          ? emptyState
          : rows.map((r) => (
              <RestaurantMapCard
                key={r.id}
                r={r}
                variant="list"
                active={r.id === selectedId}
                onActivate={() => select(r.id, 'card')}
                onHover={variant === 'desktop' ? (on) => setHoveredId(on ? r.id : null) : undefined}
                source="map"
              />
            ))}
      {rows.length >= MAX_RESULTS && <p className="text-center text-xs text-ink-muted">Mostriamo i primi {MAX_RESULTS} risultati: avvicina la mappa o aggiungi filtri.</p>}
    </div>
  );

  const countLine = (
    <p className="text-sm text-ink-muted" aria-live="polite">
      {result.loading ? (
        'Cerco ristoranti…'
      ) : (
        <>
          <strong className="text-ink">{rows.length}</strong> {rows.length === 1 ? 'ristorante' : 'ristoranti'} {where}
          {unmappedCount > 0 && <span> · {unmappedCount} non ancora sulla mappa</span>}
        </>
      )}
    </p>
  );

  // Assistente AI: link discreto accanto ai filtri (le schede dell'assistente tornano qui con /map?ids=…)
  const aiButton = (glass: boolean) =>
    AI.enabled && (
      <Link
        to="/assistant"
        state={{ from: 'map' }}
        aria-label="Chiedi all’assistente AI"
        title="Chiedi all’assistente AI"
        className={cn('inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition', glass ? 'bg-white shadow-lift' : 'border border-line bg-white hover:border-ink')}
      >
        <Sparkles className="h-5 w-5 text-coral" />
      </Link>
    );

  const searchForm = (glass: boolean) => (
    <form
      role="search"
      onSubmit={(e) => {
        e.preventDefault();
        submitQuery(q);
      }}
      className={cn('relative flex items-center gap-2 rounded-full border bg-white p-1 pl-4', glass ? 'border-transparent shadow-lift' : 'border-line shadow-card focus-within:border-ink')}
    >
      <Search className="h-4 w-4 shrink-0 text-ink-muted" />
      <input
        type="search"
        value={q}
        onChange={(e) => {
          setQ(e.target.value);
          setSuggestOpen(true);
        }}
        onFocus={() => setSuggestOpen(true)}
        onBlur={() => window.setTimeout(() => setSuggestOpen(false), 150)}
        placeholder="Comune, cucina o nome del locale"
        aria-label="Cerca sulla mappa"
        className="h-9 min-w-0 flex-1 bg-transparent text-[15px] focus:outline-none"
      />
      {q && (
        <button type="button" aria-label="Cancella ricerca" onClick={() => { setQ(''); update({ ...filters, q: undefined }); }} className="rounded-full p-1.5 text-ink-muted hover:bg-cream">
          <X className="h-4 w-4" />
        </button>
      )}
      <button type="submit" className="h-9 rounded-full bg-coral px-4 text-sm font-semibold text-white hover:bg-coral-600">
        Cerca
      </button>
      {suggestOpen && citySuggestions.length > 0 && (
        <ul className="absolute inset-x-0 top-full z-50 mt-2 overflow-hidden rounded-3xl border border-line bg-white py-1 shadow-lift" role="listbox" aria-label="Comuni">
          {citySuggestions.map((c) => (
            <li key={c.id}>
              <button type="button" role="option" aria-selected={false} onMouseDown={(e) => e.preventDefault()} onClick={() => goToCity(c.slug)} className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm hover:bg-cream">
                <MapIcon className="h-4 w-4 text-ink-muted" /> Vai a <strong>{c.name}</strong>
              </button>
            </li>
          ))}
        </ul>
      )}
    </form>
  );

  const filtersButton = (glass: boolean) => (
    <button
      type="button"
      onClick={() => setFiltersOpen(true)}
      className={cn('relative inline-flex h-11 shrink-0 items-center gap-2 rounded-full px-4 text-sm font-semibold', glass ? 'bg-white shadow-lift' : 'border border-line bg-white hover:border-ink')}
      aria-label={activeCount ? `Filtri, ${activeCount} attivi` : 'Filtri'}
    >
      <SlidersHorizontal className="h-4 w-4" />
      <span className={cn(glass && 'sr-only')}>Filtri</span>
      {activeCount > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-coral px-1 text-[11px] font-bold text-white">{activeCount}</span>}
    </button>
  );

  const chips = (glass: boolean) => (
    <ActiveFilterChips
      value={{ ...filters, radiusKm: undefined }}
      onChange={update}
      onClear={clearFilters}
      extra={areaChips}
      glass={glass}
    />
  );

  // Spazio in basso occupato da sheet chiuso + carosello (mobile), per centrare i punti nella parte visibile
  const PEEK = 92;
  const CAROUSEL_H = 196;
  // Il carosello compare quando si tocca un marker (o una card): la mappa resta libera finché non serve
  const showCarousel = !isDesktop && snap === 'closed' && !!selected && hasCoords(selected);
  // All'apertura del carosello porta subito in vista la card selezionata (senza animazione)
  useEffect(() => {
    if (!showCarousel || !selectedId) return;
    const c = carouselRef.current;
    const el = c?.querySelector<HTMLElement>(`[data-id="${selectedId}"]`);
    if (!c || !el) return;
    ignoreCarouselUntil.current = Date.now() + 400;
    c.scrollLeft = el.offsetLeft - (c.clientWidth - el.clientWidth) / 2;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showCarousel]);
  const mapPadding = isDesktop ? { bottom: selected ? 190 : 0 } : { top: 110, bottom: PEEK + (showCarousel ? CAROUSEL_H : 0) };

  return (
    <div className="relative flex h-full min-h-0 w-full">
      <h1 className="sr-only">{title}</h1>

      {/* ── Lista desktop (40%) ── */}
      <aside className="hidden w-[40%] min-w-[380px] max-w-[620px] flex-col border-r border-line bg-paper lg:flex" aria-label="Elenco ristoranti">
        <div className="space-y-3 border-b border-line px-5 pb-4 pt-5">
          <div className="flex items-center gap-2">
            <div className="min-w-0 flex-1">{searchForm(false)}</div>
            {filtersButton(false)}
            {aiButton(false)}
          </div>
          <div className="flex items-center justify-between gap-3">
            {countLine}
            {sortSelect}
          </div>
          {radiusPicker}
          {chips(false)}
        </div>
        <div ref={listRef} className="min-h-0 flex-1 space-y-3 overflow-y-auto px-5 py-4">
          {showGeoMessage && <GeoNotice text={geo.message!} onClose={() => setGeoDismissed(true)} />}
          {nearMeCta}
          {listBody('desktop')}
        </div>
      </aside>

      {/* ── Mappa (60% desktop, full screen mobile) ── */}
      <section className="relative min-w-0 flex-1 overflow-hidden" aria-label="Mappa">
        <InteractiveMap
          ref={mapRef}
          points={points}
          selectedId={selectedId}
          hoveredId={hoveredId}
          onSelect={(id) => select(id, id ? 'marker' : 'map')}
          onHover={setHoveredId}
          onMoveEnd={onMoveEnd}
          user={coords}
          radiusKm={nearMode ? radiusKm : null}
          initialView={
            nearMode
              ? { bounds: boundsAround(coords!, radiusKm) }
              : bbox
                ? { bounds: bbox }
                : city?.latitude != null && city.longitude != null
                  ? { center: { lat: city.latitude, lng: city.longitude }, zoom: 12 }
                  : { bounds: LAUNCH_BOUNDS }
          }
          landmarks={ready ? landmarks : []}
          padding={mapPadding}
          controls={isDesktop}
          onProviderError={setProviderError}
          ariaLabel="Mappa dei ristoranti. L'elenco dei risultati è disponibile come alternativa accessibile."
          className="absolute inset-0 h-full w-full"
        />

        {/* Barra superiore mobile */}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-20 space-y-2 p-3 lg:hidden">
          <div className="pointer-events-auto flex items-center gap-2">
            <div className="min-w-0 flex-1">{searchForm(true)}</div>
            {filtersButton(true)}
            {aiButton(true)}
          </div>
          <div className="pointer-events-auto">{chips(true)}</div>
        </div>

        {/* Avvisi */}
        <div className="pointer-events-none absolute inset-x-0 top-[112px] z-20 flex flex-col items-center gap-2 px-3 lg:top-4">
          {pendingBounds && (
            <button
              type="button"
              onClick={searchThisArea}
              className="pointer-events-auto inline-flex h-10 animate-fade-up items-center gap-2 rounded-full bg-ink px-4 text-sm font-semibold text-white shadow-lift hover:bg-ink-soft"
            >
              <RefreshCw className="h-4 w-4" /> Cerca in questa zona
            </button>
          )}
          {!idsMode && (
            <button
              type="button"
              onClick={() => (deliverHere ? setDeliverHere(null) : void checkDeliverHere())}
              aria-pressed={!!deliverHere}
              className={cn('pointer-events-auto inline-flex h-9 items-center gap-2 rounded-full px-4 text-[13px] font-semibold shadow-card',
                deliverHere ? 'bg-coral text-white' : 'bg-white/95 text-ink hover:bg-white')}
              data-testid="deliver-here"
            >
              <Bike className="h-4 w-4" /> {deliverBusy ? 'Verifico…' : deliverHere ? `Consegnano qui: ${deliverHere.ids.size} · mostra tutti` : 'Consegna qui'}
            </button>
          )}
          {providerError && (
            <div className="pointer-events-auto flex max-w-md items-center gap-2 rounded-2xl bg-white/95 px-3 py-2 text-xs shadow-card" role="status">
              <span>Mappa in vista semplificata: il servizio di mappe non è raggiungibile. Lista e filtri funzionano normalmente.</span>
              <button aria-label="Chiudi avviso" onClick={() => setProviderError(null)} className="rounded-full p-1 hover:bg-cream">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
          {showGeoMessage && !isDesktop && (
            <div className="pointer-events-auto w-full max-w-md">
              <GeoNotice text={geo.message!} onClose={() => setGeoDismissed(true)} />
            </div>
          )}
        </div>

        {/* Pulsanti flottanti mobile */}
        <div
          className="absolute right-3 z-20 flex flex-col gap-2 transition-[bottom] duration-300 lg:hidden"
          style={{ bottom: PEEK + (showCarousel ? CAROUSEL_H : 0) + 12 }}
        >
          <button
            type="button"
            onClick={() => (nearMode && coords ? mapRef.current?.fitBounds(boundsAround(coords, radiusKm), 24) : void startNearMe())}
            aria-label={nearMode ? 'Centra sulla mia posizione' : 'Trova ristoranti vicino a me'}
            title={PRIVACY}
            className={cn('flex h-12 w-12 items-center justify-center rounded-full shadow-lift', nearMode ? 'bg-ink text-white' : 'bg-white text-ink', geo.status === 'loading' && 'animate-pulse')}
          >
            <LocateFixed className="h-5 w-5" />
          </button>
        </div>

        {/* Popup desktop */}
        {isDesktop && selected && (
          <div className="absolute inset-x-0 bottom-5 z-20 flex justify-center px-4">
            <RestaurantMapCard r={selected} variant="popup" onClose={() => select(null, 'map')} source="map_popup" />
          </div>
        )}

        {/* Carosello mobile (sincronizzato con i marker) */}
        {showCarousel && (
          <div className="absolute inset-x-0 z-20 lg:hidden" style={{ bottom: PEEK + 4 }}>
            <div
              ref={carouselRef}
              onScroll={onCarouselScroll}
              className="scrollbar-none flex snap-x snap-mandatory gap-3 overflow-x-auto px-[7vw] pb-2 pt-1"
              aria-label="Ristoranti sulla mappa"
            >
              {mapped.map((r) => (
                <RestaurantMapCard key={r.id} r={r} variant="carousel" active={r.id === selectedId} onActivate={() => select(r.id, 'card')} source="map_carousel" />
              ))}
            </div>
          </div>
        )}

        {/* Bottom sheet mobile */}
        {!isDesktop && (
          <BottomSheet
            snap={snap}
            onSnapChange={setSnap}
            peek={PEEK}
            topGap={8}
            header={
              <div className="flex items-center justify-between gap-2">
                {countLine}
                <button
                  type="button"
                  onClick={() => setSnap(snap === 'closed' ? 'full' : 'closed')}
                  className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full bg-ink px-3.5 text-sm font-semibold text-white"
                >
                  {snap === 'closed' ? (
                    <>
                      <List className="h-4 w-4" /> Lista
                    </>
                  ) : (
                    <>
                      <MapIcon className="h-4 w-4" /> Mappa
                    </>
                  )}
                </button>
              </div>
            }
          >
            <div className="space-y-3 pt-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                {sortSelect}
                <Link to={`/restaurants?${filtersToParams(filters).toString()}`} className="text-xs font-semibold text-ink-muted underline-offset-2 hover:underline">
                  Vista elenco completa
                </Link>
              </div>
              {radiusPicker}
              {!nearMode && nearMeCta}
              {listBody('sheet')}
            </div>
          </BottomSheet>
        )}
      </section>

      <Sheet open={filtersOpen} onClose={() => setFiltersOpen(false)} title="Filtri" footer={
        <div className="flex gap-3">
          <Button variant="ghost" className="flex-1" onClick={clearFilters}>Cancella filtri</Button>
          <Button variant="dark" className="flex-1" onClick={() => setFiltersOpen(false)}>
            {result.loading ? 'Mostra risultati' : `Mostra ${rows.length} risultati`}
          </Button>
        </div>
      }>
        <FiltersForm
          value={{ ...filters, radiusKm: nearMode ? radiusKm : undefined }}
          onChange={onFiltersChange}
          geoAvailable={!!coords}
          onRequestLocation={() => void startNearMe()}
          hideCity
        />
      </Sheet>
    </div>
  );
}

function GeoNotice({ text, onClose }: { text: string; onClose: () => void }) {
  return (
    <div className="flex items-start gap-2 rounded-2xl bg-amber-50 px-3 py-2.5 text-sm text-amber-900 shadow-card" role="status">
      <LocateFixed className="mt-0.5 h-4 w-4 shrink-0" />
      <span className="flex-1">{text}</span>
      <button aria-label="Chiudi avviso" onClick={onClose} className="rounded-full p-1 hover:bg-amber-100">
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
