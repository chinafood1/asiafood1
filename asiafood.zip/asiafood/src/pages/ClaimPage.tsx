import { useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check, CheckCircle2, FileText, LogIn, MapPin, Phone, ShieldCheck, Upload, UserPlus, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { cn } from '@/lib/format';
import { BUSINESS_ROLES, CLAIM_STATUS, VERIFICATION_METHOD } from '@/lib/labels';
import { api } from '@/services';
import { isValidTaxCode, isValidVat } from '@/lib/validation';
import { OPEN_CLAIM_STATUSES, type RestaurantDetail, type VerificationMethod } from '@/types/domain';
import { Button, ButtonLink } from '@/components/ui/Button';
import { ClaimStatusBadge } from '@/components/ui/Badge';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { Monogram, SmartImage } from '@/components/ui/SmartImage';

const STEPS = ['Accesso', 'Attività', 'I tuoi dati', 'Verifica'];
const DOC_TYPES = 'application/pdf,image/jpeg,image/png,image/webp';
const DOC_MAX_MB = 10;

/** "Sei il proprietario di questa attività? Rivendica questa attività." */
export default function ClaimPage() {
  const { slug = '' } = useParams();
  const { user, loading: authLoading } = useAuth();
  const { data: r, loading } = useAsync(() => api.getRestaurantBySlug(slug), [slug]);
  const myClaims = useAsync(() => (user ? api.getMyClaims(user.id) : Promise.resolve([])), [user?.id]);
  useSeo({ title: r ? `Rivendica ${r.name}` : 'Rivendica attività', noindex: true });

  if (authLoading || loading) return <PageLoader />;
  if (!r) return <div className="container-app py-16"><EmptyState icon="🔎" title="Locale non trovato" /></div>;

  if (r.owner_id) {
    return (
      <div className="container-app max-w-xl py-16">
        <EmptyState
          icon="🔒"
          title="Questa attività è già gestita"
          text="La scheda è stata rivendicata da un titolare verificato. Se ritieni che ci sia un errore, usa “Segnala informazioni errate” nella scheda."
          action={<ButtonLink to={`/ristorante/${r.slug}`}>Torna alla scheda</ButtonLink>}
        />
      </div>
    );
  }
  if (r.is_permanently_closed) {
    return (
      <div className="container-app max-w-xl py-16">
        <EmptyState icon="🚫" title="Attività chiusa definitivamente" text="Non è possibile rivendicare un’attività segnata come chiusa. Se è ancora aperta, inviaci una segnalazione dalla scheda." action={<ButtonLink to={`/ristorante/${r.slug}`}>Torna alla scheda</ButtonLink>} />
      </div>
    );
  }

  const open = (myClaims.data ?? []).find((c) => c.restaurant_id === r.id && OPEN_CLAIM_STATUSES.includes(c.status));
  if (open) {
    return (
      <div className="container-app max-w-xl py-16">
        <EmptyState
          icon="⏳"
          title="Hai già una richiesta per questa attività"
          text={CLAIM_STATUS[open.status].hint}
          action={
            <div className="flex flex-col items-center gap-3">
              <ClaimStatusBadge status={open.status} />
              <ButtonLink to="/dashboard/claims">Segui la richiesta</ButtonLink>
            </div>
          }
        />
      </div>
    );
  }

  return <ClaimWizard r={r} />;
}

function Stepper({ step }: { step: number }) {
  return (
    <ol className="mb-8 grid grid-cols-4 gap-2" aria-label="Avanzamento">
      {STEPS.map((label, i) => (
        <li key={label} className="min-w-0">
          <div className={cn('h-1.5 rounded-full transition', i <= step ? 'bg-coral' : 'bg-line')} />
          <p className={cn('mt-2 truncate text-xs font-semibold', i === step ? 'text-ink' : 'text-ink-faint')}>
            <span className="tabular-nums">{i + 1}.</span> {label}
          </p>
        </li>
      ))}
    </ol>
  );
}

function BusinessCard({ r }: { r: RestaurantDetail }) {
  return (
    <div className="overflow-hidden rounded-4xl border border-line bg-white">
      <SmartImage src={r.cover_url} alt={r.name} seed={r.id} emoji={r.categories[0]?.emoji} className="aspect-[16/6] w-full" />
      <div className="flex items-start gap-4 p-5">
        <Monogram name={r.name} src={r.logo_url} className="-mt-10 h-16 w-16 shrink-0 border-4 border-white text-lg shadow-card" />
        <div className="min-w-0">
          <p className="text-xl font-bold">{r.name}</p>
          <p className="text-sm text-ink-muted">{r.categories.map((c) => c.name).join(' · ')}</p>
        </div>
      </div>
      <dl className="grid gap-3 border-t border-line p-5 text-sm sm:grid-cols-2">
        <div className="flex gap-2">
          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-coral" />
          <div>
            <dt className="text-xs text-ink-muted">Indirizzo</dt>
            <dd className="font-medium">{[r.address, r.city?.name].filter(Boolean).join(', ') || 'Non disponibile'}</dd>
          </div>
        </div>
        <div className="flex gap-2">
          <Phone className="mt-0.5 h-4 w-4 shrink-0 text-coral" />
          <div>
            <dt className="text-xs text-ink-muted">Telefono pubblico</dt>
            <dd className="font-medium">{r.phone ?? 'Non disponibile'}</dd>
          </div>
        </div>
      </dl>
    </div>
  );
}

function ClaimWizard({ r }: { r: RestaurantDetail }) {
  const { user, profile } = useAuth();
  const location = useLocation();
  const [step, setStep] = useState(user ? 1 : 0);
  const [nameFirst, ...nameRest] = (profile?.full_name ?? '').split(' ');
  const [form, setForm] = useState({
    first_name: nameFirst ?? '',
    last_name: nameRest.join(' '),
    role: 'Titolare',
    business_name: '',
    vat_number: '',
    tax_code: '',
    business_email: user?.email ?? '',
    phone: profile?.phone ?? '',
    website: '',
    message: '',
  });
  const [method, setMethod] = useState<VerificationMethod>('phone');
  const [doc, setDoc] = useState<File | null>(null);
  const [consent, setConsent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const next = encodeURIComponent(location.pathname);
  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const validate = useMemo(
    () => () => {
      const e: Record<string, string> = {};
      if (!form.first_name.trim()) e.first_name = 'Obbligatorio';
      if (!form.last_name.trim()) e.last_name = 'Obbligatorio';
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.business_email)) e.business_email = 'Email non valida';
      if (form.phone.replace(/\D/g, '').length < 6) e.phone = 'Telefono non valido';
      if (form.vat_number && !isValidVat(form.vat_number)) e.vat_number = 'Partita IVA non valida (11 cifre)';
      if (form.tax_code && !isValidTaxCode(form.tax_code.trim())) e.tax_code = 'Codice fiscale non valido';
      if (form.website && !/^(https?:\/\/)?[^\s.]+\.[^\s]{2,}/.test(form.website)) e.website = 'Indirizzo non valido';
      return e;
    },
    [form],
  );

  const goStep3 = (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length === 0) setStep(3);
  };

  const pickDoc = (f: File | undefined) => {
    if (!f) return;
    if (!DOC_TYPES.split(',').includes(f.type)) return setError('Formato non supportato: usa PDF, JPG, PNG o WebP.');
    if (f.size > DOC_MAX_MB * 1024 * 1024) return setError(`Il file supera ${DOC_MAX_MB} MB.`);
    setError(null);
    setDoc(f);
  };

  const submit = async () => {
    if (!user) return;
    if (method === 'document' && !doc) return setError('Per la verifica con documento carica un file.');
    if (!consent) return setError('Conferma di essere autorizzato a rappresentare l’attività.');
    setError(null);
    setBusy(true);
    try {
      const path = doc ? await api.uploadClaimDocument(user.id, doc) : null;
      const website = form.website.trim() ? (/^https?:\/\//.test(form.website) ? form.website.trim() : `https://${form.website.trim()}`) : null;
      await api.createClaim({
        restaurant_id: r.id,
        user_id: user.id,
        first_name: form.first_name.trim(),
        last_name: form.last_name.trim(),
        role: form.role,
        business_name: form.business_name.trim() || null,
        vat_number: form.vat_number.replace(/\s/g, '').toUpperCase() || null,
        tax_code: form.tax_code.trim().toUpperCase() || null,
        business_email: form.business_email.trim().toLowerCase(),
        phone: form.phone.trim(),
        website,
        verification_method: method,
        verification_document_url: path,
        message: form.message.trim() || null,
      });
      setSent(true);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (sent) {
    return (
      <div className="container-app max-w-xl py-16 text-center">
        <CheckCircle2 className="mx-auto h-14 w-14 text-leaf" />
        <h1 className="mt-4 text-3xl font-extrabold">Richiesta inviata</h1>
        <p className="mt-2 text-ink-muted">
          La scheda <strong>non</strong> ti viene assegnata automaticamente: un amministratore verificherà i dati con il metodo scelto ({VERIFICATION_METHOD[method].label.toLowerCase()}).
          Potrai seguire lo stato e rispondere a eventuali richieste dalla tua area.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <ButtonLink to="/dashboard/claims">Le mie richieste</ButtonLink>
          <ButtonLink to={`/ristorante/${r.slug}`} variant="outline">Torna alla scheda</ButtonLink>
        </div>
      </div>
    );
  }

  return (
    <div className="container-app max-w-2xl pb-24 pt-6">
      <Link to={`/ristorante/${r.slug}`} className="mb-5 inline-flex items-center gap-1 text-sm font-semibold text-ink-muted hover:text-ink">
        <ArrowLeft className="h-4 w-4" /> {r.name}
      </Link>
      <h1 className="text-3xl font-extrabold">Rivendica questa attività</h1>
      <p className="mb-6 mt-2 text-ink-muted">Gratis. Dopo la verifica potrai aggiornare menu, orari, foto, offerte e coupon.</p>
      <Stepper step={step} />

      {step === 0 && (
        <StepCard title="Accedi per continuare" text="Per proteggere i titolari ogni richiesta è legata a un account. Dopo l’accesso tornerai qui.">
          <div className="grid gap-3 sm:grid-cols-2">
            <ButtonLink to={`/accedi?next=${next}`} size="lg" icon={<LogIn className="h-4 w-4" />}>Accedi</ButtonLink>
            <ButtonLink to={`/registrati?next=${next}`} size="lg" variant="outline" icon={<UserPlus className="h-4 w-4" />}>Crea un account</ButtonLink>
          </div>
        </StepCard>
      )}

      {step === 1 && (
        <StepCard title="È questa la tua attività?" text="Controlla che nome e indirizzo corrispondano al locale che rappresenti.">
          <BusinessCard r={r} />
          <div className="mt-6 flex flex-wrap justify-between gap-3">
            <ButtonLink to="/restaurants" variant="ghost">No, cerca un altro locale</ButtonLink>
            <Button onClick={() => setStep(2)} icon={<Check className="h-4 w-4" />}>Sì, è la mia attività</Button>
          </div>
        </StepCard>
      )}

      {step === 2 && (
        <form onSubmit={goStep3} noValidate>
          <StepCard title="I tuoi dati" text="Servono solo per la verifica: non vengono pubblicati.">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Nome *" error={errors.first_name}><Input autoComplete="given-name" value={form.first_name} onChange={(e) => set('first_name', e.target.value)} /></Field>
              <Field label="Cognome *" error={errors.last_name}><Input autoComplete="family-name" value={form.last_name} onChange={(e) => set('last_name', e.target.value)} /></Field>
              <Field label="Ruolo nell’attività *">
                <Select value={form.role} onChange={(e) => set('role', e.target.value)}>
                  {BUSINESS_ROLES.map((x) => <option key={x}>{x}</option>)}
                </Select>
              </Field>
              <Field label="Ragione sociale"><Input autoComplete="organization" value={form.business_name} onChange={(e) => set('business_name', e.target.value)} placeholder="Es. Rossi S.r.l." /></Field>
              <Field label="Partita IVA" error={errors.vat_number}><Input inputMode="numeric" value={form.vat_number} onChange={(e) => set('vat_number', e.target.value)} placeholder="11 cifre" /></Field>
              <Field label="Codice fiscale azienda" hint="Se diverso dalla P.IVA (es. ditta individuale)." error={errors.tax_code}><Input value={form.tax_code} onChange={(e) => set('tax_code', e.target.value)} /></Field>
              <Field label="Email aziendale *" error={errors.business_email}><Input type="email" autoComplete="email" value={form.business_email} onChange={(e) => set('business_email', e.target.value)} /></Field>
              <Field label="Telefono *" error={errors.phone}><Input type="tel" autoComplete="tel" value={form.phone} onChange={(e) => set('phone', e.target.value)} /></Field>
              <Field label="Sito web" className="sm:col-span-2" error={errors.website}><Input inputMode="url" value={form.website} onChange={(e) => set('website', e.target.value)} placeholder="www.illocale.it" /></Field>
              <Field label="Messaggio" className="sm:col-span-2"><Textarea maxLength={2000} value={form.message} onChange={(e) => set('message', e.target.value)} placeholder="Informazioni utili per la verifica…" /></Field>
            </div>
            <div className="mt-6 flex justify-between gap-3">
              <Button type="button" variant="ghost" onClick={() => setStep(1)} icon={<ArrowLeft className="h-4 w-4" />}>Indietro</Button>
              <Button type="submit">Continua <ArrowRight className="h-4 w-4" /></Button>
            </div>
          </StepCard>
        </form>
      )}

      {step === 3 && (
        <StepCard title="Come preferisci essere verificato?" text="Nella prima fase la verifica è manuale: un operatore controlla ogni richiesta.">
          {error && <div className="mb-4"><Alert tone="error">{error}</Alert></div>}
          <div className="grid gap-3" role="radiogroup" aria-label="Metodo di verifica">
            {(Object.keys(VERIFICATION_METHOD) as VerificationMethod[]).map((m) => (
              <button
                key={m}
                type="button"
                role="radio"
                aria-checked={method === m}
                onClick={() => setMethod(m)}
                className={cn('flex items-start gap-3 rounded-3xl border p-4 text-left transition', method === m ? 'border-ink bg-white shadow-card' : 'border-line bg-white/60 hover:border-ink/30')}
              >
                <span className={cn('mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2', method === m ? 'border-coral' : 'border-line')}>
                  {method === m && <span className="h-2.5 w-2.5 rounded-full bg-coral" />}
                </span>
                <span>
                  <span className="block font-semibold">{VERIFICATION_METHOD[m].label}</span>
                  <span className="block text-sm text-ink-muted">{VERIFICATION_METHOD[m].description}</span>
                </span>
              </button>
            ))}
          </div>

          <div className="mt-5 rounded-3xl border border-dashed border-line bg-white p-4">
            <p className="flex items-center gap-2 text-sm font-semibold">
              <FileText className="h-4 w-4 text-coral" /> Documento {method === 'document' ? '(obbligatorio)' : '(facoltativo)'}
            </p>
            <p className="mt-1 text-xs text-ink-muted">Visura camerale, documento del rappresentante o altro documento aziendale. PDF/JPG/PNG fino a {DOC_MAX_MB} MB. Archiviato in uno spazio privato: lo vedono solo lo staff e tu.</p>
            <input ref={fileRef} type="file" accept={DOC_TYPES} hidden onChange={(e) => pickDoc(e.target.files?.[0])} />
            {doc ? (
              <div className="mt-3 flex items-center justify-between gap-2 rounded-2xl bg-cream px-3 py-2 text-sm">
                <span className="truncate">{doc.name}</span>
                <button type="button" aria-label="Rimuovi documento" onClick={() => setDoc(null)} className="rounded-full p-1 hover:bg-line"><X className="h-4 w-4" /></button>
              </div>
            ) : (
              <Button type="button" variant="outline" size="sm" className="mt-3" icon={<Upload className="h-4 w-4" />} onClick={() => fileRef.current?.click()}>Scegli file</Button>
            )}
          </div>

          <label className="mt-5 flex items-start gap-3 text-sm text-ink-soft">
            <input type="checkbox" className="mt-0.5 h-4 w-4 accent-coral" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            Dichiaro di essere autorizzato a rappresentare questa attività e acconsento al trattamento dei dati ai soli fini della verifica.
          </label>
          <div className="mt-6 flex items-center gap-2 rounded-3xl bg-cream p-4 text-sm text-ink-soft">
            <ShieldCheck className="h-5 w-5 shrink-0 text-leaf" /> La scheda non viene assegnata automaticamente: la gestirai solo dopo l’approvazione.
          </div>
          <div className="mt-6 flex justify-between gap-3">
            <Button type="button" variant="ghost" onClick={() => setStep(2)} icon={<ArrowLeft className="h-4 w-4" />}>Indietro</Button>
            <Button size="lg" loading={busy} onClick={submit}>Invia richiesta</Button>
          </div>
        </StepCard>
      )}
    </div>
  );
}

function StepCard({ title, text, children }: { title: string; text?: string; children: ReactNode }) {
  return (
    <section className="animate-fade-up">
      <h2 className="text-xl font-bold">{title}</h2>
      {text && <p className="mb-5 mt-1 text-sm text-ink-muted">{text}</p>}
      {children}
    </section>
  );
}
