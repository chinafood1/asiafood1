import { Heart } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useFavorites } from '@/context/FavoritesContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import { CardSkeleton, RestaurantCard } from '@/components/restaurant/RestaurantCard';
import { EmptyState } from '@/components/ui/Layout';
import { ButtonLink } from '@/components/ui/Button';

export default function FavoritesPage() {
  const { user, loading } = useAuth();
  const { ids } = useFavorites();
  const key = [...ids].sort().join(',');
  const result = useAsync(() => api.getRestaurantsByIds([...ids]), [key]);
  useSeo({ title: 'I tuoi preferiti', path: '/preferiti', noindex: true });

  return (
    <div className="container-app pb-10 pt-8">
      <h1 className="text-3xl font-extrabold sm:text-4xl">Preferiti</h1>
      <p className="mt-2 text-ink-muted">I locali che hai salvato, sempre a portata di mano.</p>
      <div className="mt-8">
        {!loading && !user ? (
          <EmptyState
            icon={<Heart className="h-6 w-6 text-coral" />}
            title="Accedi per salvare i preferiti"
            text="Crea un account gratuito per ritrovare i tuoi locali su tutti i dispositivi."
            action={<ButtonLink to="/accedi?next=/preferiti">Accedi o registrati</ButtonLink>}
          />
        ) : result.loading ? (
          <div className="grid gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 3 }, (_, i) => <CardSkeleton key={i} />)}
          </div>
        ) : (result.data ?? []).length === 0 ? (
          <EmptyState
            icon={<Heart className="h-6 w-6 text-coral" />}
            title="Nessun preferito, per ora"
            text="Tocca il cuore su un locale per salvarlo qui."
            action={<ButtonLink to="/restaurants">Esplora i ristoranti</ButtonLink>}
          />
        ) : (
          <div className="grid gap-x-5 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
            {result.data!.map((r) => (
              <RestaurantCard key={r.id} r={r} source="favorites" />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
