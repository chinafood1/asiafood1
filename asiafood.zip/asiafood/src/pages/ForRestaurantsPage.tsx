import { BarChart3, ImagePlus, Search, ShieldCheck, Tag, UtensilsCrossed } from 'lucide-react';
import { APP } from '@/config/app';
import { useSeo } from '@/lib/seo';
import { ButtonLink } from '@/components/ui/Button';

const STEPS = [
  { icon: Search, title: 'Trova il tuo locale', text: 'Cerca il tuo ristorante: molto probabilmente è già presente.' },
  { icon: ShieldCheck, title: 'Rivendicalo', text: 'Apri la scheda e tocca “Rivendica attività”. Verifichiamo che sei il titolare.' },
  { icon: UtensilsCrossed, title: 'Aggiorna tutto', text: 'Menu, prezzi AYCE, orari, foto, servizi, offerte e coupon.' },
];


export default function ForRestaurantsPage() {
  useSeo({
    title: `Per i ristoratori — porta il tuo locale su ${APP.name}`,
    description: 'Rivendica gratis la scheda del tuo ristorante asiatico: menu, prezzi, orari, foto, offerte e statistiche.',
    path: '/per-ristoratori',
  });
  return (
    <div className="pb-16">
      <section className="container-app pt-10 text-center sm:pt-16">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-coral">Per i ristoratori</p>
        <h1 className="mx-auto mt-3 max-w-3xl text-balance text-4xl font-extrabold leading-tight sm:text-6xl">Fatti trovare da chi cerca cucina asiatica vicino a te</h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-ink-muted">
          {APP.name} è la guida verticale ai ristoranti asiatici. La scheda base è gratuita: rivendicala e tienila aggiornata in pochi minuti.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <ButtonLink to="/restaurants" size="lg" icon={<Search className="h-5 w-5" />}>
            Trova il tuo locale
          </ButtonLink>
          <ButtonLink to="/registrati?next=/restaurants" size="lg" variant="outline">
            Crea un account
          </ButtonLink>
        </div>
      </section>

      <section className="container-app mt-16 grid gap-4 md:grid-cols-3">
        {STEPS.map((s, i) => (
          <div key={s.title} className="card p-6">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-coral-50">
                <s.icon className="h-5 w-5 text-coral" />
              </span>
              <span className="font-display text-sm font-bold text-ink-faint">0{i + 1}</span>
            </div>
            <h3 className="mt-4 text-lg font-bold">{s.title}</h3>
            <p className="mt-1 text-ink-muted">{s.text}</p>
          </div>
        ))}
      </section>

      <section className="container-app mt-16">
        <div className="grid gap-4 rounded-[36px] bg-ink p-8 text-white sm:grid-cols-2 lg:grid-cols-4 lg:p-10">
          {[
            [UtensilsCrossed, 'Menu e prezzi', 'Carta, menu pranzo e formula All You Can Eat.'],
            [ImagePlus, 'Foto protagoniste', 'Cover, logo e galleria su storage veloce.'],
            [Tag, 'Offerte e coupon', 'Promozioni con giorni e scadenze.'],
            [BarChart3, 'Statistiche', 'Visite, chiamate, WhatsApp, indicazioni.'],
          ].map(([Icon, t, d]) => {
            const I = Icon as typeof Tag;
            return (
              <div key={t as string}>
                <I className="h-6 w-6 text-coral-400" />
                <h3 className="mt-3 text-lg font-bold text-white">{t as string}</h3>
                <p className="mt-1 text-sm text-white/60">{d as string}</p>
              </div>
            );
          })}
        </div>
      </section>

      <section className="container-app mt-16 text-center">
        <h2 className="text-3xl font-extrabold">Piani</h2>
        <p className="mx-auto mt-2 max-w-xl text-ink-muted">Free per sempre, oppure Business, Premium e Top con prova gratuita. Nessun vincolo: cambi o cancelli quando vuoi.</p>
        <div className="mt-6 flex justify-center gap-3">
          <ButtonLink to="/business/pricing" size="lg">Vedi prezzi e confronto</ButtonLink>
        </div>
      </section>
    </div>
  );
}
