import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { BadgeCheck, Info, Megaphone, Play, Users } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { cn, formatDate } from '@/lib/format';
import { api } from '@/services';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle, StatTile } from '@/components/layout/DashboardLayout';
import { CrudPage } from '@/components/admin/CrudPage';
import { StarsDisplay } from '@/components/reviews/Stars';
import { CampaignList } from '@/components/editor/EngagementSections';
import { REVIEW_REPORT_REASONS, PLATFORM_TARGETS, type AdminReview, type BusinessReferral, type CampaignChannel, type CampaignTarget, type RetentionStats } from '@/types/engagement';
import { CRUD } from './crudConfigs';

const REASON = Object.fromEntries(REVIEW_REPORT_REASONS.map((r) => [r.value, r.label])) as Record<string, string>;
const FLAG_LABEL: Record<string, string> = { link: 'Contiene link', email: 'Contiene email', phone: 'Contiene telefono', shouting: 'Tutto maiuscolo' };
const R_STATUS: Record<string, { label: string; tone: 'neutral' | 'green' | 'amber' | 'coral' | 'dark' }> = {
  pending: { label: 'Da moderare', tone: 'amber' },
  flagged: { label: 'Segnalata', tone: 'amber' },
  published: { label: 'Pubblicata', tone: 'green' },
  hidden: { label: 'Nascosta', tone: 'dark' },
  rejected: { label: 'Rifiutata', tone: 'coral' },
};

// ─── /admin/reviews ──────────────────────────────────────────
export function AdminReviews() {
  const [status, setStatus] = useState<string | null>('queue');
  const list = useAsync(() => api.adminListReviews(status), [status]);
  useSeo({ title: 'Admin · Recensioni', noindex: true });
  return (
    <div>
      <PageTitle title="Recensioni" subtitle="Moderazione umana: i filtri automatici segnalano soltanto, la decisione è sempre dello staff." />
      <div className="scrollbar-none mb-5 flex gap-2 overflow-x-auto">
        {([['queue', 'Da gestire'], ['published', 'Pubblicate'], ['hidden', 'Nascoste'], ['rejected', 'Rifiutate'], [null, 'Tutte']] as [string | null, string][]).map(([v, l]) => (
          <Chip key={l} active={status === v} onClick={() => setStatus(v)}>{l}</Chip>
        ))}
      </div>
      {list.loading && !list.data ? <PageLoader /> : (list.data ?? []).length === 0 ? (
        <EmptyState icon="✅" title="Nessuna recensione in questa vista" />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2" data-testid="admin-reviews">
          {list.data!.map((r) => <ReviewModCard key={r.id} r={r} onDone={list.reload} />)}
        </div>
      )}
    </div>
  );
}

function ReviewModCard({ r, onDone }: { r: AdminReview; onDone: () => void }) {
  const toast = useToast();
  const [note, setNote] = useState(r.moderation_note ?? '');
  const [busy, setBusy] = useState<string | null>(null);
  const st = R_STATUS[r.status] ?? R_STATUS.pending!;
  const act = async (action: 'publish' | 'hide' | 'reject' | 'restore') => {
    setBusy(action);
    try {
      await api.moderateReview(r.id, action, note.trim() || null);
      toast('Recensione aggiornata');
      onDone();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };
  return (
    <article className="card p-5">
      <div className="flex flex-wrap items-center gap-2">
        <StarsDisplay value={r.rating_overall} />
        <Badge tone={st.tone}>{st.label}</Badge>
        {r.is_verified && <Badge tone="green" icon={<BadgeCheck className="h-3.5 w-3.5" />}>Verificata · {r.verification_source === 'coupon' ? 'coupon' : 'prenotazione'}</Badge>}
        {r.is_edited && <Badge>Modificata</Badge>}
        {r.reports_open > 0 && <Badge tone="coral">{r.reports_open} segnalazioni</Badge>}
      </div>
      <p className="mt-2 text-sm text-ink-muted">
        <Link to={`/ristorante/${r.restaurant.slug}`} className="font-semibold text-ink hover:underline">{r.restaurant.name}</Link> · {r.author} · {formatDate(r.created_at)}
      </p>
      {r.title && <p className="mt-2 font-semibold">{r.title}</p>}
      <p className="mt-1 whitespace-pre-line text-sm">{r.content}</p>
      {r.moderation_flags.length > 0 && (
        <p className="mt-2 flex flex-wrap gap-1">{r.moderation_flags.map((f) => <Badge key={f} tone="amber">{FLAG_LABEL[f] ?? f}</Badge>)}</p>
      )}
      {r.reports.length > 0 && (
        <details className="mt-3 rounded-2xl bg-cream p-3 text-sm">
          <summary className="cursor-pointer font-semibold">Segnalazioni ({r.reports.length})</summary>
          <ul className="mt-2 space-y-1">
            {r.reports.map((x, i) => <li key={i}><strong>{REASON[x.reason] ?? x.reason}</strong>{x.details ? ` — ${x.details}` : ''} <span className="text-ink-faint">· {x.status} · {formatDate(x.created_at)}</span></li>)}
          </ul>
        </details>
      )}
      <Textarea className="mt-3" rows={2} placeholder="Nota di moderazione (interna)" value={note} onChange={(e) => setNote(e.target.value)} aria-label="Nota di moderazione" />
      <div className="mt-3 flex flex-wrap gap-2">
        {r.status !== 'published' && r.status !== 'hidden' && r.status !== 'rejected' && <Button size="sm" loading={busy === 'publish'} onClick={() => void act('publish')}>Pubblica</Button>}
        {r.status === 'published' && <Button size="sm" variant="outline" loading={busy === 'hide'} onClick={() => void act('hide')}>Nascondi</Button>}
        {r.status !== 'rejected' && <Button size="sm" variant="ghost" loading={busy === 'reject'} onClick={() => void act('reject')}>Rifiuta</Button>}
        {(r.status === 'hidden' || r.status === 'rejected') && <Button size="sm" variant="outline" loading={busy === 'restore'} onClick={() => void act('restore')}>Ripristina</Button>}
      </div>
    </article>
  );
}

// ─── /admin/loyalty ──────────────────────────────────────────
type LoyTab = 'rules' | 'levels' | 'rewards' | 'achievements' | 'redemptions' | 'adjust';
export function AdminLoyalty() {
  const [tab, setTab] = useState<LoyTab>('rules');
  useSeo({ title: 'Admin · Fedeltà', noindex: true });
  const TABS: [LoyTab, string][] = [['rules', 'Regole'], ['levels', 'Livelli'], ['rewards', 'Premi'], ['achievements', 'Badge'], ['redemptions', 'Riscatti'], ['adjust', 'Rettifica saldo']];
  return (
    <div>
      <PageTitle title="AsiaPoints" subtitle="Programma fedeltà. I punti non sono denaro: non si convertono, non si prelevano e cambiano solo sul server." />
      <div className="scrollbar-none mb-6 flex gap-2 overflow-x-auto">
        {TABS.map(([k, l]) => <Chip key={k} active={tab === k} onClick={() => setTab(k)}>{l}</Chip>)}
      </div>
      {tab === 'rules' && <CrudPage key="rules" config={CRUD.loyalty_rules!} />}
      {tab === 'levels' && <CrudPage key="levels" config={CRUD.loyalty_levels!} />}
      {tab === 'rewards' && <CrudPage key="rewards" config={CRUD.rewards!} />}
      {tab === 'achievements' && <CrudPage key="ach" config={CRUD.achievements!} />}
      {tab === 'redemptions' && <Redemptions />}
      {tab === 'adjust' && <Adjust />}
    </div>
  );
}

function Redemptions() {
  const toast = useToast();
  const list = useAsync(() => api.adminListRedemptions(), []);
  if (list.loading && !list.data) return <PageLoader />;
  if (!list.data?.length) return <EmptyState icon="🎁" title="Nessun riscatto" />;
  const update = async (id: string, status: 'used' | 'cancelled') => {
    try {
      await api.adminUpdateRedemption(id, status);
      toast(status === 'cancelled' ? 'Riscatto annullato e punti restituiti' : 'Segnato come utilizzato');
      list.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
  return (
    <div className="card overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-cream text-left text-xs uppercase tracking-wide text-ink-muted">
          <tr><th className="px-4 py-3">Premio</th><th className="px-4 py-3">Utente</th><th className="px-4 py-3">Codice</th><th className="px-4 py-3">Punti</th><th className="px-4 py-3">Stato</th><th className="px-4 py-3">Data</th><th className="px-4 py-3" /></tr>
        </thead>
        <tbody className="divide-y divide-line">
          {list.data.map((x) => (
            <tr key={String(x.id)}>
              <td className="px-4 py-3 font-medium">{x.reward_title}</td>
              <td className="px-4 py-3">{x.user_name}</td>
              <td className="px-4 py-3 font-mono">{String(x.redemption_code)}</td>
              <td className="px-4 py-3 tabular-nums">{String(x.points_spent)}</td>
              <td className="px-4 py-3"><Badge>{String(x.status)}</Badge></td>
              <td className="px-4 py-3">{formatDate(String(x.created_at))}</td>
              <td className="px-4 py-3">
                {x.status === 'claimed' && (
                  <span className="flex gap-1">
                    <Button size="sm" variant="outline" onClick={() => void update(String(x.id), 'used')}>Usato</Button>
                    <Button size="sm" variant="ghost" onClick={() => void update(String(x.id), 'cancelled')}>Annulla</Button>
                  </span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Adjust() {
  const toast = useToast();
  const [q, setQ] = useState('');
  const users = useAsync(() => (q.trim().length >= 2 ? api.listProfiles(q.trim()) : Promise.resolve([])), [q]);
  const [userId, setUserId] = useState('');
  const [points, setPoints] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const bal = await api.adminLoyaltyAdjust(userId, Number(points), reason.trim());
      toast(`Rettifica registrata. Nuovo saldo: ${bal}`);
      setPoints('');
      setReason('');
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <form onSubmit={submit} className="card grid max-w-2xl gap-4 p-6">
      <Alert>Ogni rettifica è registrata nel registro Admin con motivazione. Il saldo non può diventare negativo.</Alert>
      <Field label="Cerca utente (nome o email)">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Almeno 2 caratteri" />
      </Field>
      <Field label="Utente">
        <Select required value={userId} onChange={(e) => setUserId(e.target.value)}>
          <option value="">—</option>
          {(users.data ?? []).map((u) => <option key={u.id} value={u.id}>{u.full_name || 'Senza nome'}{u.email ? ` · ${u.email}` : ''}</option>)}
        </Select>
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Punti (+/−)"><Input type="number" required value={points} onChange={(e) => setPoints(e.target.value)} /></Field>
        <Field label="Motivazione"><Input required minLength={5} maxLength={200} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      </div>
      <Button type="submit" loading={busy} disabled={!userId || !points || Number(points) === 0}>Registra rettifica</Button>
    </form>
  );
}

// ─── /admin/referrals ────────────────────────────────────────
const REF_STATUS: Record<string, string> = { invited: 'Invitato', registered: 'Registrato', qualified: 'Qualificato', rewarded: 'Premiato', invalid: 'Non valido', approved: 'Approvato', rejected: 'Rifiutato' };
export function AdminReferrals() {
  const [tab, setTab] = useState<'users' | 'business'>('users');
  const [status, setStatus] = useState<string | null>(null);
  const toast = useToast();
  const users = useAsync(() => (tab === 'users' ? api.adminListReferrals(status) : Promise.resolve([])), [tab, status]);
  const biz = useAsync(() => (tab === 'business' ? api.listBusinessReferrals(null) : Promise.resolve([])), [tab]);
  useSeo({ title: 'Admin · Inviti', noindex: true });
  const action = async (id: string, a: 'invalidate' | 'qualify') => {
    const reason = a === 'invalidate' ? window.prompt('Motivo dell’annullamento') : null;
    if (a === 'invalidate' && !reason) return;
    try {
      await api.adminReferralAction(id, a, reason);
      toast('Invito aggiornato');
      users.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
  return (
    <div>
      <PageTitle title="Inviti" subtitle="Un invito diventa “qualificato” solo dopo email verificata e una prima visita reale. Autoinviti bloccati." />
      <div className="mb-4 flex gap-2">
        <Chip active={tab === 'users'} onClick={() => setTab('users')}>Utenti</Chip>
        <Chip active={tab === 'business'} onClick={() => setTab('business')}>Ristoranti (B2B)</Chip>
      </div>
      {tab === 'users' ? (
        <>
          <div className="scrollbar-none mb-4 flex gap-2 overflow-x-auto">
            {[null, 'registered', 'qualified', 'rewarded', 'invalid'].map((s) => <Chip key={String(s)} active={status === s} onClick={() => setStatus(s)}>{s ? REF_STATUS[s] : 'Tutti'}</Chip>)}
          </div>
          {users.loading && !users.data ? <PageLoader /> : !users.data?.length ? <EmptyState icon="🤝" title="Nessun invito" /> : (
            <div className="card overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-cream text-left text-xs uppercase tracking-wide text-ink-muted">
                  <tr><th className="px-4 py-3">Chi invita</th><th className="px-4 py-3">Invitato</th><th className="px-4 py-3">Stato</th><th className="px-4 py-3">Email verificata</th><th className="px-4 py-3">Data</th><th className="px-4 py-3" /></tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {users.data.map((x) => (
                    <tr key={x.id}>
                      <td className="px-4 py-3">{x.referrer}</td>
                      <td className="px-4 py-3">{x.referred ?? '—'}</td>
                      <td className="px-4 py-3"><Badge tone={x.status === 'invalid' ? 'coral' : x.status === 'rewarded' ? 'green' : 'neutral'}>{REF_STATUS[x.status]}</Badge>{x.invalid_reason && <span className="ml-1 text-xs text-ink-faint">{x.invalid_reason}</span>}</td>
                      <td className="px-4 py-3">{x.email_verified == null ? '—' : x.email_verified ? 'Sì' : 'No'}</td>
                      <td className="px-4 py-3">{formatDate(x.created_at)}</td>
                      <td className="px-4 py-3">
                        <span className="flex gap-1">
                          {x.status === 'registered' && <Button size="sm" variant="outline" onClick={() => void action(x.id, 'qualify')}>Verifica ora</Button>}
                          {x.status !== 'invalid' && x.status !== 'rewarded' && <Button size="sm" variant="ghost" onClick={() => void action(x.id, 'invalidate')}>Annulla</Button>}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      ) : biz.loading && !biz.data ? <PageLoader /> : !biz.data?.length ? <EmptyState icon="🏪" title="Nessun invito tra ristoranti" /> : (
        <div className="grid gap-4 lg:grid-cols-2">{biz.data.map((b) => <BizCard key={b.id} b={b} onDone={biz.reload} />)}</div>
      )}
    </div>
  );
}

function BizCard({ b, onDone }: { b: BusinessReferral; onDone: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ reward_type: b.reward_type ?? 'trial_extension', reward_value: b.reward_value?.toString() ?? '', note: b.admin_note ?? '' });
  const update = async (status: BusinessReferral['status']) => {
    try {
      await api.adminBusinessReferralUpdate(b.id, { status, reward_type: f.reward_type as BusinessReferral['reward_type'], reward_value: f.reward_value ? Number(f.reward_value) : null, note: f.note || null });
      toast('Aggiornato');
      onDone();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
  return (
    <article className="card p-5 text-sm">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-semibold">{b.referred_business_name || b.referred_business_email}</span>
        <Badge>{REF_STATUS[b.status] ?? b.status}</Badge>
        <span className="ml-auto text-xs text-ink-muted">{formatDate(b.created_at)}</span>
      </div>
      <p className="mt-1 text-ink-muted">{b.referred_business_email} · codice {b.code}</p>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <Select value={f.reward_type} onChange={(e) => setF({ ...f, reward_type: e.target.value as NonNullable<BusinessReferral['reward_type']> })} aria-label="Tipo premio">
          <option value="trial_extension">Estensione prova (giorni)</option>
          <option value="promo_months">Mesi promozionali</option>
          <option value="sponsorship_credits">Crediti sponsorizzazione</option>
          <option value="manual_admin_reward">Premio manuale</option>
        </Select>
        <Input type="number" placeholder="Valore" value={f.reward_value} onChange={(e) => setF({ ...f, reward_value: e.target.value })} aria-label="Valore premio" />
        <Input className="sm:col-span-2" placeholder="Nota" value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} aria-label="Nota" />
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {['invited', 'registered', 'qualified'].includes(b.status) && <Button size="sm" onClick={() => void update('approved')}>Approva</Button>}
        {b.status === 'approved' && <Button size="sm" onClick={() => void update('rewarded')}>Segna premiato</Button>}
        {b.status !== 'rejected' && b.status !== 'rewarded' && <Button size="sm" variant="ghost" onClick={() => void update('rejected')}>Rifiuta</Button>}
      </div>
      <p className="mt-2 text-xs text-ink-faint">Il premio va applicato manualmente (es. promozione B2B): nessun accredito automatico.</p>
    </article>
  );
}

// ─── /admin/campaigns ────────────────────────────────────────
export function AdminCampaigns() {
  const toast = useToast();
  const [scope, setScope] = useState<'platform' | 'restaurant'>('platform');
  const list = useAsync(() => api.listCampaigns({ scope }), [scope]);
  const [ticking, setTicking] = useState(false);
  useSeo({ title: 'Admin · Campagne', noindex: true });
  const tick = async () => {
    setTicking(true);
    try {
      const r = await api.runEngagementTick();
      toast(`Scheduler eseguito: ${r.campaigns} campagne, ${r.reservation_reminders + r.guest_reminders} promemoria, ${r.coupon_reminders} coupon, ${r.review_requests} richieste recensione`);
      list.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setTicking(false);
    }
  };
  return (
    <div>
      <PageTitle
        title="Campagne"
        subtitle="Notifiche in-app, push ed email solo a chi ha dato il consenso promozionale, con limite di frequenza settimanale."
        action={<Button variant="outline" loading={ticking} onClick={() => void tick()}><Play className="h-4 w-4" /> Esegui scheduler ora</Button>}
      />
      <PlatformCampaignForm onCreated={list.reload} />
      <div className="mb-4 mt-8 flex gap-2">
        <Chip active={scope === 'platform'} onClick={() => setScope('platform')}>Piattaforma</Chip>
        <Chip active={scope === 'restaurant'} onClick={() => setScope('restaurant')}>Ristoranti</Chip>
      </div>
      <div className="card p-5"><CampaignList items={list.data} loading={list.loading} onChange={list.reload} /></div>
    </div>
  );
}

function PlatformCampaignForm({ onCreated }: { onCreated: () => void }) {
  const toast = useToast();
  const { cities, categories } = useReferenceData();
  const [f, setF] = useState({ title: '', message: '', action_url: '/offers', target: 'all_users' as CampaignTarget, value: '', push: true, email: false, send_at: '' });
  const [audience, setAudience] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const targeting = useMemo((): Record<string, string> => {
    if (f.target === 'city') return { city_slug: f.value };
    if (f.target === 'favorite_category') return { category_slug: f.value };
    if (f.target === 'loyalty_level') return { level: f.value };
    return {};
  }, [f.target, f.value]);
  useEffect(() => {
    let alive = true;
    setAudience(null);
    api.campaignAudienceCount('platform', null, f.target, targeting).then((n) => alive && setAudience(n), () => alive && setAudience(0));
    return () => { alive = false; };
  }, [f.target, targeting]);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const channels: CampaignChannel[] = ['in_app', ...(f.push ? (['push'] as const) : []), ...(f.email ? (['email'] as const) : [])];
      const r = await api.createCampaign({ scope: 'platform', title: f.title.trim(), message: f.message.trim(), action_url: f.action_url.trim() || null, target: f.target, targeting, channels, send_at: f.send_at ? new Date(f.send_at).toISOString() : null });
      toast(`Campagna programmata · ${r.audience} destinatari`);
      setF((x) => ({ ...x, title: '', message: '', send_at: '' }));
      onCreated();
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  const needsValue = ['city', 'favorite_category', 'loyalty_level'].includes(f.target);
  return (
    <form onSubmit={submit} className="card grid gap-4 p-6 sm:grid-cols-2" data-testid="admin-campaign-form">
      <h2 className="flex items-center gap-2 text-lg font-bold sm:col-span-2"><Megaphone className="h-5 w-5 text-coral" /> Nuova campagna piattaforma</h2>
      <Field label="Titolo" className="sm:col-span-2"><Input required minLength={3} maxLength={60} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
      <Field label="Messaggio" hint={`${f.message.length}/180`} className="sm:col-span-2"><Textarea required minLength={5} maxLength={180} rows={3} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} /></Field>
      <Field label="Destinatari">
        <Select value={f.target} onChange={(e) => setF({ ...f, target: e.target.value as CampaignTarget, value: '' })}>
          {PLATFORM_TARGETS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
        </Select>
      </Field>
      {needsValue ? (
        <Field label="Valore">
          <Select required value={f.value} onChange={(e) => setF({ ...f, value: e.target.value })}>
            <option value="">—</option>
            {f.target === 'city' && cities.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
            {f.target === 'favorite_category' && categories.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
            {f.target === 'loyalty_level' && ['Explorer', 'Foodie', 'Insider', 'Master'].map((l) => <option key={l} value={l}>{l}</option>)}
          </Select>
        </Field>
      ) : <div className="hidden sm:block" />}
      <Field label="Link (percorso interno)"><Input value={f.action_url} pattern="/[A-Za-z0-9_#?=&.\/\-]*" onChange={(e) => setF({ ...f, action_url: e.target.value })} /></Field>
      <Field label="Invio" hint="Vuoto = appena possibile"><Input type="datetime-local" value={f.send_at} onChange={(e) => setF({ ...f, send_at: e.target.value })} /></Field>
      <div className="flex flex-wrap gap-4 text-sm sm:col-span-2">
        <label className="flex items-center gap-2"><input type="checkbox" checked disabled className="h-4 w-4" /> In-app</label>
        <label className="flex items-center gap-2"><input type="checkbox" checked={f.push} onChange={(e) => setF({ ...f, push: e.target.checked })} className="h-4 w-4 accent-coral" /> Push</label>
        <label className="flex items-center gap-2"><input type="checkbox" checked={f.email} onChange={(e) => setF({ ...f, email: e.target.checked })} className="h-4 w-4 accent-coral" /> Email</label>
      </div>
      <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
        <p className="flex items-center gap-1.5 text-sm"><Users className="h-4 w-4 text-coral" /> Destinatari stimati: <strong className="tabular-nums" data-testid="admin-audience">{audience ?? '…'}</strong></p>
        <Button type="submit" loading={busy} disabled={audience === 0 || (needsValue && !f.value)} className="ml-auto">Programma</Button>
      </div>
    </form>
  );
}

// ─── /admin/retention ────────────────────────────────────────
export function AdminRetention() {
  const [days, setDays] = useState(30);
  const s = useAsync(() => api.getRetentionStats(days), [days]);
  useSeo({ title: 'Admin · Retention', noindex: true });
  const d = s.data;
  return (
    <div>
      <PageTitle title="Retention" subtitle="Metriche calcolate da eventi reali (attività giornaliera, prenotazioni, coupon, recensioni). Nessun dato stimato." />
      <div className="mb-5 flex gap-2" role="group" aria-label="Periodo">
        {[7, 30, 90].map((x) => <Chip key={x} active={days === x} onClick={() => setDays(x)}>{x} giorni</Chip>)}
      </div>
      {s.loading && !d ? <PageLoader /> : !d ? <EmptyState icon="📉" title="Statistiche non disponibili" /> : (
        <div className="space-y-6" data-testid="retention">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <StatTile accent label="Utenti attivi oggi (DAU)" value={d.dau} />
            <StatTile label="Ultimi 7 giorni (WAU)" value={d.wau} />
            <StatTile label="Ultimi 30 giorni (MAU)" value={d.mau} />
            <StatTile label="DAU/MAU" value={d.mau ? `${Math.round((d.dau / d.mau) * 100)}%` : '—'} hint="Frequenza di ritorno" />
          </div>
          <ActiveChart data={d.daily} />
          <div className="grid gap-4 lg:grid-cols-3">
            <MetricGroup title="Ritorno" rows={[
              ['Utenti tornati', d.returning_users, `su ${d.previous_period_users} attivi nel periodo precedente`, pct(d.returning_users, d.previous_period_users)],
              ['Più prenotazioni', d.repeat_reservation_users, `su ${d.reservation_users} utenti con prenotazioni`, pct(d.repeat_reservation_users, d.reservation_users)],
              ['Coupon riutilizzati', d.coupon_repeat_users, `su ${d.coupon_users} utenti con coupon`, pct(d.coupon_repeat_users, d.coupon_users)],
              ['Visite completate', d.completed_reservations],
            ]} />
            <MetricGroup title="Recensioni e inviti" rows={[
              ['Recensioni pubblicate', d.reviews_published],
              ['di cui verificate', d.reviews_verified, undefined, pct(d.reviews_verified, d.reviews_published)],
              ['In moderazione', d.reviews_pending],
              ['Registrazioni da invito', d.referral_signups],
              ['Inviti qualificati', d.referral_qualified, undefined, pct(d.referral_qualified, d.referral_signups)],
            ]} />
            <MetricGroup title="Fedeltà e notifiche" rows={[
              ['Punti assegnati', d.points_issued],
              ['Punti riscattati', d.points_redeemed],
              ['Premi riscattati', d.rewards_redeemed],
              ['Dispositivi con push attive', d.push_subscribers],
              ['Follow ai ristoranti', d.followers],
            ]} />
          </div>
          <details className="card p-5 text-sm">
            <summary className="flex cursor-pointer items-center gap-2 font-semibold"><Info className="h-4 w-4" /> Definizioni</summary>
            <dl className="mt-3 grid gap-2 sm:grid-cols-2">
              {Object.entries(d.definitions).map(([k, v]) => <div key={k}><dt className="font-semibold">{k}</dt><dd className="text-ink-muted">{v}</dd></div>)}
            </dl>
          </details>
        </div>
      )}
    </div>
  );
}

const pct = (a: number, b: number) => (b ? `${Math.round((a / b) * 1000) / 10}%` : '—');

function MetricGroup({ title, rows }: { title: string; rows: [string, number, string?, string?][] }) {
  return (
    <section className="card p-5">
      <h2 className="font-bold">{title}</h2>
      <dl className="mt-3 space-y-2 text-sm">
        {rows.map(([l, v, hint, p]) => (
          <div key={l} className="flex items-baseline justify-between gap-3">
            <dt className="text-ink-muted">{l}{hint && <span className="block text-[11px] text-ink-faint">{hint}</span>}</dt>
            <dd className="text-right font-semibold tabular-nums">{v}{p && <span className="ml-1.5 text-xs font-normal text-ink-muted">{p}</span>}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

/** Utenti attivi al giorno: una serie, barre sottili ancorate alla base, tooltip e tabella alternativa. */
function ActiveChart({ data }: { data: RetentionStats['daily'] }) {
  const [hover, setHover] = useState<number | null>(null);
  const [table, setTable] = useState(false);
  const max = Math.max(1, ...data.map((d) => d.active));
  const h = hover !== null ? data[hover] : null;
  return (
    <section className="card p-5">
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-bold">Utenti attivi al giorno</h2>
        <button type="button" onClick={() => setTable((t) => !t)} className="text-sm font-semibold text-coral-700">{table ? 'Mostra grafico' : 'Mostra tabella'}</button>
      </div>
      {table ? (
        <div className="mt-3 max-h-72 overflow-y-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-left text-ink-muted"><th className="py-1">Giorno</th><th className="py-1 text-right">Attivi</th></tr></thead>
            <tbody>{data.map((d) => <tr key={d.day} className="border-t border-line"><td className="py-1">{formatDate(d.day)}</td><td className="py-1 text-right tabular-nums">{d.active}</td></tr>)}</tbody>
          </table>
        </div>
      ) : (
        <>
          <div className="mb-2 mt-3 h-5 text-sm" aria-live="polite">
            {h ? <span><strong>{formatDate(h.day)}</strong> · {h.active} utenti attivi</span> : <span className="text-ink-muted">Picco: {max} utenti</span>}
          </div>
          {data.length === 0 ? <p className="text-sm text-ink-muted">Nessuna attività nel periodo.</p> : (
            <div className="flex h-40 items-end gap-[2px] border-b border-line" onMouseLeave={() => setHover(null)}>
              {data.map((d, i) => (
                <button key={d.day} type="button" aria-label={`${formatDate(d.day)}: ${d.active} utenti attivi`} onMouseEnter={() => setHover(i)} onFocus={() => setHover(i)} className="flex h-full min-w-0 flex-1 items-end">
                  <span className={cn('block w-full rounded-t-[4px] transition-colors', hover === i ? 'bg-ink' : 'bg-coral')} style={{ height: `${Math.max(d.active ? 3 : 0, (d.active / max) * 100)}%` }} />
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </section>
  );
}


