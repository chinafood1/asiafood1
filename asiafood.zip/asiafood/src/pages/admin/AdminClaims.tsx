import { useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, Check, CheckCircle2, ExternalLink, HelpCircle, Mail, MessageSquareWarning, Phone, SearchCheck, X } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { formatDate } from '@/lib/format';
import { CLAIM_STATUS, SOURCE_TYPE, VERIFICATION_METHOD } from '@/lib/labels';
import { api, type ClaimFilter } from '@/services';
import { OPEN_CLAIM_STATUSES, type ClaimStatus, type ClaimWithRestaurant, type RestaurantDetail } from '@/types/domain';
import { ClaimStatusBadge, DataStatusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Textarea } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';
import { ClaimThread, DocumentLink } from '@/components/claims/ClaimThread';
import { isValidVat } from '@/lib/validation';

const FILTERS: { value: ClaimFilter['status']; label: string }[] = [
  { value: 'open', label: 'Da gestire' },
  { value: 'pending', label: CLAIM_STATUS.pending.label },
  { value: 'under_review', label: CLAIM_STATUS.under_review.label },
  { value: 'more_information_required', label: 'Info richieste' },
  { value: 'approved', label: CLAIM_STATUS.approved.label },
  { value: 'rejected', label: CLAIM_STATUS.rejected.label },
  { value: undefined, label: 'Tutte' },
];

/** /admin/claims — elenco rivendicazioni. */
export default function AdminClaims() {
  const [params, setParams] = useSearchParams();
  const status = (params.has('status') ? params.get('status') || undefined : 'open') as ClaimFilter['status'];
  const restaurantId = params.get('restaurant') ?? undefined;
  const claims = useAsync(() => api.listClaims({ status, restaurantId }), [status, restaurantId]);
  const navigate = useNavigate();
  useSeo({ title: 'Admin · Rivendicazioni', noindex: true });
  const setStatus = (s: ClaimFilter['status']) => {
    const next = new URLSearchParams(params);
    next.set('status', s ?? '');
    setParams(next, { replace: true });
  };
  const list = claims.data ?? [];
  return (
    <div>
      <PageTitle title="Rivendicazioni" subtitle="Nessuna attività viene assegnata senza approvazione. Verifica sempre con il metodo scelto dal richiedente." />
      {restaurantId && (
        <div className="mb-4 flex items-center justify-between gap-3 rounded-2xl bg-cream px-4 py-2.5 text-sm">
          <span>Filtrate per un ristorante{list[0]?.restaurant ? `: ${list[0].restaurant.name}` : ''}</span>
          <button onClick={() => { const n = new URLSearchParams(params); n.delete('restaurant'); setParams(n); }} className="inline-flex items-center gap-1 font-semibold text-coral-700"><X className="h-4 w-4" /> Rimuovi</button>
        </div>
      )}
      <div className="scrollbar-none -mx-4 mb-5 flex gap-2 overflow-x-auto px-4 sm:mx-0 sm:px-0">
        {FILTERS.map((f) => (
          <button key={f.label} onClick={() => setStatus(f.value)} className={`inline-flex h-10 shrink-0 items-center rounded-full border px-4 text-sm font-medium ${status === f.value ? 'border-ink bg-ink text-white' : 'border-line bg-white'}`}>{f.label}</button>
        ))}
      </div>
      {claims.loading ? (
        <PageLoader />
      ) : list.length === 0 ? (
        <EmptyState icon="✅" title="Nessuna richiesta" />
      ) : (
        <>
          <div className="hidden overflow-x-auto rounded-3xl border border-line bg-white md:block">
            <table className="w-full min-w-[820px] text-left text-sm">
              <thead className="border-b border-line bg-cream/60 text-[11px] uppercase tracking-wider text-ink-muted">
                <tr><th className="px-4 py-3">Richiedente</th><th className="px-3 py-3">Ristorante</th><th className="px-3 py-3">Città</th><th className="px-3 py-3">Data</th><th className="px-3 py-3">Metodo verifica</th><th className="px-3 py-3">Stato</th></tr>
              </thead>
              <tbody className="divide-y divide-line">
                {list.map((c) => (
                  <tr key={c.id} onClick={() => navigate(`/admin/claims/${c.id}`)} className="cursor-pointer hover:bg-paper">
                    <td className="px-4 py-3"><p className="font-semibold">{c.first_name} {c.last_name}</p><p className="text-xs text-ink-muted">{c.role} · {c.business_email}</p></td>
                    <td className="px-3 py-3 font-medium">{c.restaurant?.name ?? '—'}</td>
                    <td className="px-3 py-3">{c.restaurant?.city_name}</td>
                    <td className="px-3 py-3 whitespace-nowrap text-ink-muted">{formatDate(c.submitted_at, { day: 'numeric', month: 'short', year: '2-digit' })}</td>
                    <td className="px-3 py-3">{VERIFICATION_METHOD[c.verification_method].label}{c.verification_document_url ? ' · 📎' : ''}</td>
                    <td className="px-3 py-3"><ClaimStatusBadge status={c.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <ul className="space-y-3 md:hidden">
            {list.map((c) => (
              <li key={c.id}>
                <Link to={`/admin/claims/${c.id}`} className="block rounded-3xl border border-line bg-white p-4">
                  <div className="flex items-start justify-between gap-2"><p className="font-semibold">{c.restaurant?.name}</p><ClaimStatusBadge status={c.status} /></div>
                  <p className="mt-1 text-sm text-ink-muted">{c.first_name} {c.last_name} · {c.restaurant?.city_name} · {formatDate(c.submitted_at, { day: 'numeric', month: 'short' })}</p>
                  <p className="mt-1 text-xs text-ink-muted">Verifica: {VERIFICATION_METHOD[c.verification_method].label}</p>
                </Link>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

const digits = (s: string | null | undefined) => (s ?? '').replace(/\D/g, '').replace(/^39(?=\d{9,10}$)/, '');
const hostOf = (u: string | null | undefined) => {
  try {
    return u ? new URL(/^https?:/.test(u) ? u : `https://${u}`).hostname.replace(/^www\./, '') : null;
  } catch {
    return null;
  }
};

function Check2({ ok, label }: { ok: boolean | null; label: string }) {
  if (ok === null) return <li className="flex items-center gap-2 text-ink-muted"><HelpCircle className="h-4 w-4" /> {label}: non verificabile</li>;
  return (
    <li className={`flex items-center gap-2 ${ok ? 'text-emerald-700' : 'text-amber-700'}`}>
      {ok ? <CheckCircle2 className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />} {label}
    </li>
  );
}

/** /admin/claims/:id — dettaglio con dati, documenti, scheda, fonti, messaggi e azioni. */
export function AdminClaimDetail() {
  const { id = '' } = useParams();
  const claim = useAsync(() => api.getClaim(id), [id]);
  const restaurant = useAsync(() => (claim.data ? api.getRestaurantForEdit(claim.data.restaurant_id) : Promise.resolve(null)), [claim.data?.restaurant_id]);
  const siblings = useAsync(() => (claim.data ? api.listClaims({ restaurantId: claim.data.restaurant_id, status: 'open' }) : Promise.resolve([])), [claim.data?.restaurant_id, claim.data?.status]);
  useSeo({ title: 'Admin · Rivendicazione', noindex: true });
  if (claim.loading && !claim.data) return <PageLoader />;
  const c = claim.data;
  if (!c) return <EmptyState icon="🔎" title="Richiesta non trovata" />;
  const r = restaurant.data;
  const others = (siblings.data ?? []).filter((x) => x.id !== c.id);

  return (
    <div>
      <Link to="/admin/claims" className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-ink-muted hover:text-ink"><ArrowLeft className="h-4 w-4" /> Tutte le richieste</Link>
      <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold sm:text-3xl">{c.restaurant?.name ?? 'Locale'}</h1>
          <p className="mt-1 text-sm text-ink-muted">Richiesta di {c.first_name} {c.last_name} · inviata il {formatDate(c.submitted_at)}</p>
        </div>
        <ClaimStatusBadge status={c.status} />
      </div>

      {others.length > 0 && <div className="mb-5"><Alert tone="error">Ci sono altre {others.length} richieste aperte per questo locale: approvandone una, le altre verranno chiuse.</Alert></div>}
      {c.restaurant?.owner_id && c.status !== 'approved' && <div className="mb-5"><Alert tone="error">Il locale ha già un titolare. Per cambiarlo usa “Trasferisci proprietà” nell’editor.</Alert></div>}

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="min-w-0 space-y-6">
          <section className="card p-5 sm:p-6">
            <h2 className="mb-4 text-lg font-bold">Richiedente</h2>
            <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
              <Item label="Nome e cognome">{c.first_name} {c.last_name}</Item>
              <Item label="Ruolo">{c.role ?? '—'}</Item>
              <Item label="Account">{c.claimant?.full_name ?? '—'} <span className="text-ink-muted">{c.claimant?.email}</span></Item>
              <Item label="Email aziendale"><a className="inline-flex items-center gap-1 hover:text-coral-700" href={`mailto:${c.business_email}`}><Mail className="h-3.5 w-3.5" /> {c.business_email}</a></Item>
              <Item label="Telefono"><a className="inline-flex items-center gap-1 hover:text-coral-700" href={`tel:${c.phone}`}><Phone className="h-3.5 w-3.5" /> {c.phone}</a></Item>
              <Item label="Sito web">{c.website ? <a className="inline-flex items-center gap-1 text-coral-700 hover:underline" href={c.website} target="_blank" rel="noreferrer">{c.website} <ExternalLink className="h-3 w-3" /></a> : '—'}</Item>
            </dl>
          </section>

          <section className="card p-5 sm:p-6">
            <h2 className="mb-4 text-lg font-bold">Dati aziendali e verifica</h2>
            <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
              <Item label="Ragione sociale">{c.business_name ?? '—'}</Item>
              <Item label="Partita IVA">{c.vat_number ?? '—'} {c.vat_number && (isValidVat(c.vat_number) ? <span className="text-emerald-700">· formato valido</span> : <span className="text-amber-700">· formato non valido</span>)}</Item>
              <Item label="Codice fiscale">{c.tax_code ?? '—'}</Item>
              <Item label="Metodo scelto">{VERIFICATION_METHOD[c.verification_method].label}</Item>
            </dl>
            <p className="mt-3 text-xs text-ink-muted">{VERIFICATION_METHOD[c.verification_method].description}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {c.verification_document_url ? <DocumentLink path={c.verification_document_url} label="Documento di verifica" /> : <span className="text-sm text-ink-muted">Nessun documento allegato.</span>}
            </div>
            {c.message && <p className="mt-4 whitespace-pre-line rounded-2xl bg-cream p-4 text-sm"><strong>Messaggio:</strong> {c.message}</p>}
          </section>

          <section className="card p-5 sm:p-6">
            <h2 className="mb-4 flex items-center gap-2 text-lg font-bold"><MessageSquareWarning className="h-5 w-5 text-coral" /> Conversazione</h2>
            <ClaimThread claim={c} viewer="admin" />
          </section>
        </div>

        <aside className="space-y-6">
          <ActionsCard c={c} onDone={() => { claim.reload(); restaurant.reload(); siblings.reload(); }} />
          {r && <ListingCard r={r} c={c} />}
        </aside>
      </div>
    </div>
  );
}

function Item({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs text-ink-muted">{label}</dt>
      <dd className="truncate font-medium">{children}</dd>
    </div>
  );
}

function ListingCard({ r, c }: { r: RestaurantDetail; c: ClaimWithRestaurant }) {
  const phoneMatch = r.phone ? [digits(c.phone)].some((d) => d && digits(r.phone).endsWith(d.slice(-9))) : null;
  const siteHost = hostOf(r.website);
  const emailHost = c.business_email.split('@')[1]?.toLowerCase() ?? null;
  const emailMatch = siteHost && emailHost ? emailHost === siteHost || emailHost.endsWith(`.${siteHost}`) : null;
  const siteMatch = siteHost && c.website ? hostOf(c.website) === siteHost : null;
  return (
    <section className="card p-5">
      <h2 className="mb-3 flex items-center gap-2 text-lg font-bold"><SearchCheck className="h-5 w-5 text-coral" /> Dati nella scheda</h2>
      <dl className="space-y-2 text-sm">
        <Item label="Indirizzo">{[r.address, r.city?.name].filter(Boolean).join(', ') || '—'}</Item>
        <Item label="Telefono pubblico">{r.phone ?? '—'}</Item>
        <Item label="Sito">{r.website ?? '—'}</Item>
        <Item label="Email">{r.email ?? '—'}</Item>
        <div className="flex items-center justify-between"><dt className="text-xs text-ink-muted">Stato dati</dt><dd><DataStatusBadge status={r.data_status} /></dd></div>
      </dl>
      <ul className="mt-4 space-y-1.5 border-t border-line pt-4 text-sm">
        <Check2 ok={phoneMatch} label="Telefono coincide con quello pubblico" />
        <Check2 ok={emailMatch} label="Dominio email coincide con il sito" />
        <Check2 ok={siteMatch} label="Sito indicato coincide con la scheda" />
      </ul>
      <h3 className="mb-2 mt-5 text-sm font-bold">Fonti disponibili</h3>
      {r.sources.length === 0 ? (
        <p className="text-sm text-ink-muted">Nessuna fonte registrata.</p>
      ) : (
        <ul className="space-y-1.5 text-sm">
          {r.sources.map((s) => (
            <li key={s.id}>
              {s.source_url ? <a href={s.source_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-coral-700 hover:underline">{s.source_name || SOURCE_TYPE[s.source_type]} <ExternalLink className="h-3 w-3" /></a> : s.source_name}
            </li>
          ))}
        </ul>
      )}
      <Link to={`/admin/restaurants/${r.id}/proprietario`} className="mt-5 inline-flex text-sm font-semibold text-coral-700 hover:underline">Apri nell’editor →</Link>
    </section>
  );
}

function ActionsCard({ c, onDone }: { c: ClaimWithRestaurant; onDone: () => void }) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const open = OPEN_CLAIM_STATUSES.includes(c.status);
  const act = async (kind: 'approve' | 'reject' | 'info' | 'review') => {
    if (kind === 'info' && !text.trim()) return toast('Scrivi quali informazioni servono', 'error');
    if (kind === 'reject' && !text.trim() && !confirm('Rifiutare senza una nota per il richiedente?')) return;
    if (kind === 'approve' && !confirm(`Approvare e assegnare “${c.restaurant?.name}” a ${c.first_name} ${c.last_name}?`)) return;
    setBusy(kind);
    try {
      if (kind === 'approve') await api.approveClaim(c.id, text.trim() || undefined);
      if (kind === 'reject') await api.rejectClaim(c.id, text.trim() || undefined);
      if (kind === 'info') await api.requestClaimInfo(c.id, text.trim());
      if (kind === 'review') await api.setClaimUnderReview(c.id, text.trim() || undefined);
      const msg: Record<string, string> = { approve: 'Approvata: il richiedente ora gestisce il locale', reject: 'Richiesta rifiutata', info: 'Richiesta di informazioni inviata', review: 'Messa in revisione' };
      toast(msg[kind]!);
      setText('');
      onDone();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };
  const st: ClaimStatus = c.status;
  return (
    <section className="card p-5">
      <h2 className="text-lg font-bold">Azioni</h2>
      <p className="mt-1 text-sm text-ink-muted">{CLAIM_STATUS[st].hint}</p>
      {c.admin_notes && <p className="mt-3 rounded-2xl bg-cream p-3 text-sm"><strong>Nota:</strong> {c.admin_notes}</p>}
      {open ? (
        <div className="mt-4 space-y-3">
          <Textarea rows={3} value={text} onChange={(e) => setText(e.target.value)} placeholder="Nota per il richiedente / informazioni da richiedere…" className="!min-h-0" />
          <div className="grid gap-2">
            <Button variant="dark" loading={busy === 'approve'} icon={<Check className="h-4 w-4" />} onClick={() => act('approve')} disabled={!!c.restaurant?.owner_id}>Approva</Button>
            <Button variant="outline" loading={busy === 'info'} icon={<HelpCircle className="h-4 w-4" />} onClick={() => act('info')}>Richiedi informazioni</Button>
            {st !== 'under_review' && <Button variant="soft" loading={busy === 'review'} icon={<SearchCheck className="h-4 w-4" />} onClick={() => act('review')}>Metti in revisione</Button>}
            <Button variant="danger" loading={busy === 'reject'} icon={<X className="h-4 w-4" />} onClick={() => act('reject')}>Rifiuta</Button>
          </div>
        </div>
      ) : (
        <p className="mt-3 text-sm text-ink-muted">{st === 'approved' ? `Approvata il ${formatDate(c.approved_at)}` : `Rifiutata il ${formatDate(c.rejected_at)}`}.</p>
      )}
    </section>
  );
}
