import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Pencil } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { formatDate } from '@/lib/format';
import { REPORT_STATUS, REPORT_TYPE } from '@/lib/labels';
import { api } from '@/services';
import type { ReportStatus, ReportWithRestaurant } from '@/types/domain';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Textarea } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';

type Filter = ReportStatus | 'open_all' | undefined;
const FILTERS: [Filter, string][] = [['open_all', 'Da gestire'], ['resolved', 'Risolte'], ['dismissed', 'Archiviate'], [undefined, 'Tutte']];

/** /admin/reports — segnalazioni "Informazioni errate" inviate dagli utenti. */
export default function AdminReports() {
  const [status, setStatus] = useState<Filter>('open_all');
  const reports = useAsync(() => api.listReports({ status }), [status]);
  useSeo({ title: 'Admin · Segnalazioni', noindex: true });
  return (
    <div>
      <PageTitle title="Segnalazioni" subtitle="Correzioni proposte dagli utenti. Verifica sulle fonti prima di modificare la scheda." />
      <div className="scrollbar-none mb-5 flex gap-2 overflow-x-auto">
        {FILTERS.map(([v, l]) => <Chip key={l} active={status === v} onClick={() => setStatus(v)}>{l}</Chip>)}
      </div>
      {reports.loading ? (
        <PageLoader />
      ) : (reports.data ?? []).length === 0 ? (
        <EmptyState icon="📭" title="Nessuna segnalazione" />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {reports.data!.map((r) => <ReportCard key={r.id} r={r} onDone={reports.reload} />)}
        </div>
      )}
    </div>
  );
}

function ReportCard({ r, onDone }: { r: ReportWithRestaurant; onDone: () => void }) {
  const toast = useToast();
  const [notes, setNotes] = useState(r.admin_notes ?? '');
  const [busy, setBusy] = useState<ReportStatus | null>(null);
  const update = async (status: ReportStatus) => {
    setBusy(status);
    try {
      await api.updateReport(r.id, { status, admin_notes: notes.trim() || null });
      toast(`Segnalazione: ${REPORT_STATUS[status].label.toLowerCase()}`);
      onDone();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };
  const st = REPORT_STATUS[r.status];
  const done = r.status === 'resolved' || r.status === 'dismissed';
  return (
    <article className="card p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wide text-coral-700">{REPORT_TYPE[r.report_type]}</p>
          <Link to={`/ristorante/${r.restaurant?.slug}`} target="_blank" className="block truncate text-lg font-bold hover:text-coral-700">{r.restaurant?.name ?? 'Locale eliminato'}</Link>
          <p className="text-xs text-ink-muted">{formatDate(r.created_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}{r.user_id ? ' · utente registrato' : ' · anonimo'}</p>
        </div>
        <Badge tone={st.tone}>{st.label}</Badge>
      </div>
      <p className="mt-3 whitespace-pre-line rounded-2xl bg-cream p-3 text-sm">{r.description}</p>
      {r.email && <a href={`mailto:${r.email}`} className="mt-2 inline-flex items-center gap-1 text-sm text-coral-700 hover:underline"><Mail className="h-3.5 w-3.5" /> {r.email}</a>}
      {!done ? (
        <div className="mt-4 space-y-3">
          <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Nota interna…" className="!min-h-0" />
          <div className="flex flex-wrap gap-2">
            {r.restaurant && <Link to={`/admin/restaurants/${r.restaurant.id}`} className="inline-flex h-9 items-center gap-1.5 rounded-full border border-line px-4 text-sm font-semibold hover:border-ink"><Pencil className="h-4 w-4" /> Correggi scheda</Link>}
            {r.status === 'open' && <Button size="sm" variant="soft" loading={busy === 'in_progress'} onClick={() => update('in_progress')}>In lavorazione</Button>}
            <Button size="sm" variant="dark" loading={busy === 'resolved'} onClick={() => update('resolved')}>Risolta</Button>
            <Button size="sm" variant="ghost" loading={busy === 'dismissed'} onClick={() => update('dismissed')}>Archivia</Button>
          </div>
        </div>
      ) : (
        r.admin_notes && <p className="mt-3 text-sm text-ink-muted">Nota: {r.admin_notes}</p>
      )}
    </article>
  );
}
