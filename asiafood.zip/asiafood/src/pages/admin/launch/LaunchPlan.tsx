// Piano: fasi di lancio, impostazioni del programma, obiettivi (target vs actual), piano 30 giorni, roadmap 90 giorni,
// scenario (ipotesi separate dai dati reali), feedback, ambassador, segnali per l'espansione
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select } from '@/components/ui/Field';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { api } from '@/services';
import {
  FEEDBACK_TYPE_LABELS, GOAL_LABELS, GOAL_STATUS_LABELS, PHASE_LABELS, type FeedbackRow, type GoalMetric, type LaunchPhase, type PlanItem,
} from '@/types/launch';
import { Card, euro, fmtDate, n, Note, Table } from './shared';

const PHASES: { key: LaunchPhase; title: string; text: string }[] = [
  { key: 'private_beta', title: 'Fase A · Beta privata', text: '5–10 ristoranti, 50–100 utenti invitati. Obiettivo: bug e feedback. Impostazioni: beta_invite_only attivo, inviti da Admin → Sistema.' },
  { key: 'local_beta', title: 'Fase B · Beta locale', text: '20+ ristoranti, pubblico limitato a Taranto. Registrazione aperta, badge Beta visibile.' },
  { key: 'public_launch', title: 'Fase C · Lancio pubblico', text: 'Campagna completa (landing, social, stampa, partner). Solo con la launch checklist senza blocker.' },
];

type Tab = 'plan' | 'goals' | 'settings' | 'feedback' | 'community' | 'expansion';
export default function LaunchPlan() {
  const [tab, setTab] = useState<Tab>('plan');
  const tabs: [Tab, string][] = [['plan', 'Fasi e piano'], ['goals', 'Obiettivi e scenario'], ['settings', 'Impostazioni lancio'], ['feedback', 'Feedback'], ['community', 'Ambassador'], ['expansion', 'Espansione']];
  return (
    <div className="space-y-4" data-testid="launch-plan">
      <div className="flex flex-wrap gap-2">{tabs.map(([k, l]) => <Chip key={k} active={tab === k} onClick={() => setTab(k)}>{l}</Chip>)}</div>
      {tab === 'plan' && <PhasesAndPlan />}
      {tab === 'goals' && <Goals />}
      {tab === 'settings' && <Settings />}
      {tab === 'feedback' && <Feedback />}
      {tab === 'community' && <Ambassadors />}
      {tab === 'expansion' && <Expansion />}
    </div>
  );
}

function PhasesAndPlan() {
  const toast = useToast();
  const o = useAsync(() => api.launch.overview('taranto'), []);
  const items = useAsync(() => api.launch.planItems('taranto'), []);
  const [confirm, setConfirm] = useState<LaunchPhase | null>(null);
  const setPhase = async (p: LaunchPhase) => {
    try {
      await api.launch.setPhase('taranto', p);
      toast(`Fase aggiornata: ${PHASE_LABELS[p]}`);
      setConfirm(null);
      o.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const update = async (i: PlanItem, status: PlanItem['status']) => {
    try {
      await api.launch.planItemUpdate(i.id, { status });
      items.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const current = o.data?.market.status;
  const groups: [PlanItem['bucket'], string][] = [['week1', 'Settimana 1 · beta privata, QA dati, primi partner, bug'], ['week2', 'Settimana 2 · acquisizione ristoranti, QR, contenuti organici'],
    ['week3', 'Settimana 3 · lancio consumer, referral, partnership locali'], ['week4', 'Settimana 4 · conversione paganti, retention, preparazione espansione']];
  const road: [PlanItem['bucket'], string][] = [['month1', 'Mese 1 · Validazione Taranto'], ['month2', 'Mese 2 · Saturazione provincia'], ['month3', 'Mese 3 · Preparazione secondo mercato']];
  return (
    <>
      <Card title="Fasi di lancio" subtitle={current ? `Fase attuale: ${PHASE_LABELS[current]}` : undefined} testId="phases">
        <div className="grid gap-3 md:grid-cols-3">
          {PHASES.map((p) => (
            <div key={p.key} className={cn('rounded-2xl border p-4', current === p.key ? 'border-ink bg-cream/50' : 'border-line')}>
              <p className="font-bold">{p.title}</p>
              <p className="mt-1 text-sm text-ink-muted">{p.text}</p>
              {current !== p.key && (confirm === p.key
                ? <div className="mt-3 flex gap-2"><Button size="sm" onClick={() => void setPhase(p.key)} data-testid={`phase-confirm-${p.key}`}>Conferma</Button><Button size="sm" variant="ghost" onClick={() => setConfirm(null)}>Annulla</Button></div>
                : <Button size="sm" variant="outline" className="mt-3" onClick={() => setConfirm(p.key)} data-testid={`phase-${p.key}`}>Passa a questa fase</Button>)}
            </div>
          ))}
        </div>
        <Note>Il cambio di fase è registrato nell’audit e non modifica da solo le impostazioni critiche (inviti, manutenzione, pagamenti): quelle restano in Admin → Sistema. Prima del lancio pubblico: <Link to="/admin/launch-checklist" className="font-semibold text-coral-700">launch checklist</Link>.</Note>
      </Card>
      {items.loading && !items.data ? <PageLoader /> : items.data && (
        <>
          <Card title="Piano operativo 30 giorni" testId="plan-30">
            <div className="grid gap-4 md:grid-cols-2">
              {groups.map(([b, l]) => <PlanGroup key={b} title={l} items={items.data!.filter((i) => i.horizon === '30d' && i.bucket === b)} onStatus={update} />)}
            </div>
          </Card>
          <Card title="Roadmap 90 giorni" subtitle="La scelta della seconda città si basa sui segnali della sezione Espansione, non su ipotesi." testId="plan-90">
            <div className="grid gap-4 md:grid-cols-3">
              {road.map(([b, l]) => <PlanGroup key={b} title={l} items={items.data!.filter((i) => i.horizon === '90d' && i.bucket === b)} onStatus={update} />)}
            </div>
          </Card>
        </>
      )}
    </>
  );
}

function PlanGroup({ title, items, onStatus }: { title: string; items: PlanItem[]; onStatus: (i: PlanItem, s: PlanItem['status']) => void }) {
  return (
    <div>
      <p className="text-sm font-bold">{title}</p>
      <ul className="mt-2 space-y-2">
        {items.map((i) => (
          <li key={i.id} className="flex items-start gap-2 text-sm" data-testid="plan-item">
            <input type="checkbox" className="mt-1 h-4 w-4 accent-ink" checked={i.status === 'done'} onChange={(e) => onStatus(i, e.target.checked ? 'done' : 'todo')} aria-label={i.title} />
            <span className={cn(i.status === 'done' && 'text-ink-muted line-through')}><strong className="font-semibold">{i.title}</strong>{i.description && <span className="block text-xs text-ink-muted">{i.description}</span>}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

interface Scenario { contacts_per_week: number; contact_to_claim_pct: number; claim_to_paid_pct: number; arpa_eur: number }
function Goals() {
  const toast = useToast();
  const o = useAsync(() => api.launch.overview('taranto'), []);
  const fc = useAsync(() => api.getSetting<Record<string, Scenario> | null>('launch_forecast'), []);
  const [g, setG] = useState({ metric_key: 'restaurants_claimed' as GoalMetric, target_value: '', period_start: new Date().toISOString().slice(0, 10), period_end: '' });
  const [sc, setSc] = useState<Record<string, Scenario>>({});
  useEffect(() => setSc(fc.data ?? {}), [fc.data]);
  const saveGoal = async () => {
    try {
      await api.launch.goalUpsert({ ...g, target_value: Number(g.target_value) });
      toast('Obiettivo salvato');
      o.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const saveScenario = async () => {
    try {
      await api.setSetting('launch_forecast', sc);
      toast('Ipotesi salvate');
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  if (o.loading && !o.data) return <PageLoader />;
  if (!o.data) return <Alert tone="error">{friendlyError(o.error)}</Alert>;
  const actual = o.data.kpis;
  const names: [string, string][] = [['conservative', 'Conservative'], ['base', 'Base'], ['growth', 'Growth']];
  return (
    <>
      <Card title="Obiettivi (target vs actual)" subtitle="Target operativi configurabili: non sono risultati garantiti." testId="goals-table">
        <Table head={['Metrica', 'Periodo', 'Target', 'Actual', 'Stato', '']}>
          {o.data.goals.map((x) => (
            <tr key={x.id}>
              <td className="py-2 pr-3 font-semibold">{GOAL_LABELS[x.metric_key]}</td>
              <td className="py-2 pr-3">{fmtDate(x.period_start)} → {fmtDate(x.period_end)}</td>
              <td className="py-2 pr-3 tabular-nums">{x.metric_key === 'mrr_cents' ? euro(x.target_value) : n(x.target_value)}</td>
              <td className="py-2 pr-3 tabular-nums">{x.metric_key === 'mrr_cents' ? euro(x.actual_value) : n(x.actual_value ?? 0)}</td>
              <td className="py-2 pr-3">{GOAL_STATUS_LABELS[x.status]}</td>
              <td className="py-2 pr-3"><Button size="sm" variant="ghost" onClick={() => void api.launch.goalDelete(x.id).then(o.reload)}>Elimina</Button></td>
            </tr>
          ))}
        </Table>
        <div className="mt-4 grid gap-3 sm:grid-cols-5 sm:items-end">
          <Field label="Metrica"><Select value={g.metric_key} onChange={(e) => setG({ ...g, metric_key: e.target.value as GoalMetric })}>{Object.entries(GOAL_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
          <Field label="Target"><Input inputMode="numeric" value={g.target_value} onChange={(e) => setG({ ...g, target_value: e.target.value })} /></Field>
          <Field label="Dal"><Input type="date" value={g.period_start} onChange={(e) => setG({ ...g, period_start: e.target.value })} /></Field>
          <Field label="Al"><Input type="date" value={g.period_end} onChange={(e) => setG({ ...g, period_end: e.target.value })} /></Field>
          <Button size="sm" disabled={!(Number(g.target_value) > 0) || !g.period_end} onClick={() => void saveGoal()}>Aggiungi</Button>
        </div>
      </Card>
      <Card title="Scenario a 90 giorni" subtitle="Ipotesi inserite da te, separate dai dati reali. Nessuna previsione viene calcolata senza ipotesi esplicite." testId="forecast">
        <div className="grid gap-4 md:grid-cols-3">
          {names.map(([k, l]) => {
            const s = sc[k];
            const set = (f: keyof Scenario, v: string) => setSc({ ...sc, [k]: { ...{ contacts_per_week: 0, contact_to_claim_pct: 0, claim_to_paid_pct: 0, arpa_eur: 0 }, ...s, [f]: Number(v) } });
            const paid = s ? Math.round(s.contacts_per_week * 13 * (s.contact_to_claim_pct / 100) * (s.claim_to_paid_pct / 100)) : null;
            return (
              <div key={k} className="rounded-2xl border border-line p-3">
                <p className="font-bold">{l}</p>
                <p className="mt-1 text-xs font-semibold uppercase text-ink-muted">Ipotesi</p>
                <div className="mt-1 grid grid-cols-2 gap-2">
                  <Field label="Contatti/sett."><Input inputMode="numeric" value={s?.contacts_per_week ?? ''} onChange={(e) => set('contacts_per_week', e.target.value)} /></Field>
                  <Field label="% contatto→rivend."><Input inputMode="numeric" value={s?.contact_to_claim_pct ?? ''} onChange={(e) => set('contact_to_claim_pct', e.target.value)} /></Field>
                  <Field label="% rivend.→pagante"><Input inputMode="numeric" value={s?.claim_to_paid_pct ?? ''} onChange={(e) => set('claim_to_paid_pct', e.target.value)} /></Field>
                  <Field label="€/mese per pagante"><Input inputMode="numeric" value={s?.arpa_eur ?? ''} onChange={(e) => set('arpa_eur', e.target.value)} /></Field>
                </div>
                <p className="mt-2 text-xs font-semibold uppercase text-ink-muted">Scenario (calcolato dalle ipotesi)</p>
                <p className="text-sm">{paid == null ? 'Inserisci le ipotesi' : `≈ ${paid} paganti · MRR ≈ ${euro(paid * (s!.arpa_eur ?? 0) * 100)}`}</p>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-sm"><strong>Actual oggi:</strong> {actual.paying} paganti · MRR {euro(actual.mrr_cents)} · {actual.claimed} rivendicati</p>
        <Button size="sm" className="mt-3" onClick={() => void saveScenario()}>Salva ipotesi</Button>
      </Card>
    </>
  );
}

const LAUNCH_SETTINGS: { key: string; label: string; kind: 'bool' | 'num' | 'text' | 'plan' }[] = [
  { key: 'founding_program_enabled', label: 'Programma Partner Fondatori attivo', kind: 'bool' },
  { key: 'founding_program_name', label: 'Nome del programma/badge', kind: 'text' },
  { key: 'founding_limit', label: 'Numero massimo di Partner Fondatori (20/30/50…)', kind: 'num' },
  { key: 'founding_plan', label: 'Piano concesso', kind: 'plan' },
  { key: 'founding_days', label: 'Giorni gratuiti (es. 30 o 60)', kind: 'num' },
  { key: 'founding_badge_enabled', label: 'Badge visibile sulle schede degli aderenti', kind: 'bool' },
  { key: 'founding_foodie_open', label: 'Badge “Founding Foodie” ai nuovi iscritti', kind: 'bool' },
  { key: 'launch_first_n', label: 'Dimensione lista First N', kind: 'num' },
  { key: 'launch_daily_target_research', label: 'Target giornaliero: lead ricercati', kind: 'num' },
  { key: 'launch_daily_target_contacts', label: 'Target giornaliero: contatti', kind: 'num' },
  { key: 'launch_daily_target_demos', label: 'Target giornaliero: demo', kind: 'num' },
  { key: 'launch_daily_target_claims', label: 'Target giornaliero: rivendicazioni', kind: 'num' },
  { key: 'launch_daily_target_trials', label: 'Target giornaliero: prove', kind: 'num' },
  { key: 'sla_claim_review_hours', label: 'SLA interno rivendicazioni (ore)', kind: 'num' },
  { key: 'sla_support_first_response_hours', label: 'SLA interno supporto (ore)', kind: 'num' },
  { key: 'sla_order_issue_hours', label: 'SLA interno problemi ordini (ore)', kind: 'num' },
  { key: 'sla_data_report_hours', label: 'SLA interno segnalazioni dati (ore)', kind: 'num' },
  { key: 'nps_enabled', label: 'Chiedi NPS dopo uso significativo', kind: 'bool' },
  { key: 'ambassador_program_enabled', label: 'Candidature Ambassador aperte', kind: 'bool' },
  { key: 'experiments_max_running', label: 'Esperimenti attivi insieme (max)', kind: 'num' },
];

function Settings() {
  const toast = useToast();
  const vals = useAsync(() => Promise.all(LAUNCH_SETTINGS.map((s) => api.getSetting(s.key))).then((v) => Object.fromEntries(LAUNCH_SETTINGS.map((s, i) => [s.key, v[i]]))), []);
  const [draft, setDraft] = useState<Record<string, unknown>>({});
  useEffect(() => setDraft(vals.data ?? {}), [vals.data]);
  const save = async (key: string, value: unknown) => {
    try {
      await api.setSetting(key, value);
      setDraft((d) => ({ ...d, [key]: value }));
      toast('Impostazione salvata');
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  if (vals.loading && !vals.data) return <PageLoader />;
  return (
    <Card title="Impostazioni del lancio" subtitle="Nessuna impostazione critica (pagamenti, manutenzione, inviti) si cambia da qui: sono in Admin → Sistema." testId="launch-settings">
      <ul className="divide-y divide-line">
        {LAUNCH_SETTINGS.map((s) => (
          <li key={s.key} className="flex flex-wrap items-center justify-between gap-3 py-2.5 text-sm">
            <span>{s.label}<span className="block font-mono text-xs text-ink-muted">{s.key}</span></span>
            {s.kind === 'bool' ? (
              <input type="checkbox" className="h-5 w-5 accent-ink" checked={draft[s.key] === true} onChange={(e) => void save(s.key, e.target.checked)} aria-label={s.label} />
            ) : s.kind === 'plan' ? (
              <Select className="w-40" value={String(draft[s.key] ?? 'premium')} onChange={(e) => void save(s.key, e.target.value)}>{['business', 'premium', 'top'].map((p) => <option key={p}>{p}</option>)}</Select>
            ) : (
              <span className="flex gap-2">
                <Input className="w-44" value={String(draft[s.key] ?? '')} onChange={(e) => setDraft((d) => ({ ...d, [s.key]: e.target.value }))} aria-label={s.label} />
                <Button size="sm" variant="outline" onClick={() => void save(s.key, s.kind === 'num' ? Number(draft[s.key]) : String(draft[s.key] ?? ''))}>Salva</Button>
              </span>
            )}
          </li>
        ))}
      </ul>
    </Card>
  );
}

function Feedback() {
  const toast = useToast();
  const [type, setType] = useState<FeedbackRow['type'] | ''>('');
  const f = useAsync(() => api.launch.feedbackList(type || null, null, 100, 0), [type]);
  const upd = async (id: string, status: FeedbackRow['status']) => {
    try {
      await api.launch.feedbackUpdate(id, status);
      f.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <Card title="Feedback in-app" subtitle="Utenti: “Come possiamo migliorare AsiaFood?” · Ristoratori: “Cosa manca alla dashboard?” · NPS · motivi di disdetta." testId="feedback-admin">
      <div className="flex flex-wrap gap-2">
        <Chip active={!type} onClick={() => setType('')}>Tutti</Chip>
        {Object.entries(FEEDBACK_TYPE_LABELS).map(([k, v]) => <Chip key={k} active={type === k} onClick={() => setType(k as FeedbackRow['type'])}>{v}</Chip>)}
      </div>
      <ul className="mt-3 divide-y divide-line text-sm">
        {(f.data?.rows ?? []).map((x) => (
          <li key={x.id} className="flex flex-wrap items-start justify-between gap-3 py-2.5">
            <span className="min-w-0 flex-1"><strong>{FEEDBACK_TYPE_LABELS[x.type]}</strong>{x.rating != null && ` · ${x.rating}/10`}{x.reason && ` · ${x.reason}`}{x.restaurant_name && ` · ${x.restaurant_name}`}
              <span className="block whitespace-pre-line">{x.message ?? '—'}</span><span className="text-xs text-ink-muted">{fmtDate(x.created_at)}{x.page ? ` · ${x.page}` : ''}</span></span>
            <Select className="w-36" value={x.status} onChange={(e) => void upd(x.id, e.target.value as FeedbackRow['status'])} aria-label="Stato feedback">
              {['new', 'reviewed', 'planned', 'done', 'dismissed'].map((s) => <option key={s}>{s}</option>)}
            </Select>
          </li>
        ))}
        {f.data && !f.data.rows.length && <li className="py-3 text-ink-muted">Nessun feedback.</li>}
      </ul>
    </Card>
  );
}

function Ambassadors() {
  const toast = useToast();
  const a = useAsync(() => api.launch.ambassadors('taranto'), []);
  const set = async (id: string, status: 'approved' | 'paused' | 'rejected') => {
    try {
      await api.launch.ambassadorSetStatus(id, status);
      a.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <Card title="AsiaFood Ambassador" subtitle="Utenti locali che scoprono ristoranti, condividono l’app, creano contenuti e invitano amici. Nessun compenso automatico: regole e compliance da definire prima di qualsiasi premio." testId="ambassadors">
      {(a.data ?? []).length ? (
        <ul className="divide-y divide-line text-sm">
          {a.data!.map((x) => (
            <li key={x.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
              <span><strong>{x.name ?? x.email}</strong> · {x.status} · codice {x.referral_code} · {x.referrals} inviti ({x.qualified} qualificati)
                {x.motivation && <span className="block text-ink-muted">“{x.motivation}”</span>}</span>
              <span className="flex gap-2">
                {x.status !== 'approved' && <Button size="sm" onClick={() => void set(x.id, 'approved')}>Approva</Button>}
                {x.status === 'approved' && <Button size="sm" variant="outline" onClick={() => void set(x.id, 'paused')}>Sospendi</Button>}
                {x.status === 'applied' && <Button size="sm" variant="ghost" onClick={() => void set(x.id, 'rejected')}>Rifiuta</Button>}
              </span>
            </li>
          ))}
        </ul>
      ) : <p className="text-sm text-ink-muted">Nessuna candidatura. Le candidature si aprono con “Candidature Ambassador aperte” nelle impostazioni del lancio.</p>}
    </Card>
  );
}

function Expansion() {
  const e = useAsync(() => api.launch.expansionSignals(), []);
  return (
    <Card title="Segnali per il secondo mercato" subtitle="Solo dati: locali censiti fuori dal mercato, rivendicazioni, lead e preferiti per provincia. Nessuna previsione." testId="expansion">
      {e.loading && !e.data ? <PageLoader /> : (e.data ?? []).length ? (
        <Table head={['Provincia', 'Locali censiti', 'Rivendicazioni', 'Lead CRM', 'Preferiti', 'Punteggio']}>
          {e.data!.map((x) => <tr key={x.code} className="tabular-nums"><td className="py-2 pr-3 font-semibold">{x.province}</td><td className="py-2 pr-3">{x.restaurants}</td><td className="py-2 pr-3">{x.claims}</td><td className="py-2 pr-3">{x.leads}</td><td className="py-2 pr-3">{x.favorites}</td><td className="py-2 pr-3">{x.score}</td></tr>)}
        </Table>
      ) : <p className="text-sm text-ink-muted">Ancora nessun segnale fuori da Taranto: normale durante il primo mese.</p>}
      <Note>Criteri suggeriti per scegliere la seconda area (mese 3): domanda osservata, locali censibili, costo di acquisizione reale a Taranto, capacità del team. Vedi docs/launch/ROADMAP_90_DAYS.md.</Note>
    </Card>
  );
}
