// Marketing: calendario contenuti (bozze → pubblicazione manuale), materiali stampabili, template (stampa, email, newsletter)
import { useMemo, useState } from 'react';
import { Copy, Plus, Sparkles } from 'lucide-react';
import { Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PRINT_KINDS, PrintSheet, type PrintKind } from '@/components/launch/PrintMaterials';
import { APP } from '@/config/app';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { GEO_CAMPAIGNS, GIVEAWAY_CHECKLIST, launchEmailUsers, pressRelease, restaurantNewsletter, SPOTLIGHT_RULES, UGC_GUIDELINES } from '@/lib/launchTemplates';
import { buildUtmUrl } from '@shared/utm';
import { api } from '@/services';
import { CONTENT_STATUS_LABELS, CONTENT_TYPE_LABELS, PLATFORM_LABELS, type ContentItem, type ContentStatus } from '@/types/launch';
import { Card, fmtDateTime, Note } from './shared';

type Tab = 'calendar' | 'materials' | 'templates';
export default function LaunchMarketing() {
  const [tab, setTab] = useState<Tab>('calendar');
  return (
    <div className="space-y-4" data-testid="launch-marketing">
      <div className="flex flex-wrap gap-2">
        <Chip active={tab === 'calendar'} onClick={() => setTab('calendar')}>Calendario contenuti</Chip>
        <Chip active={tab === 'materials'} onClick={() => setTab('materials')}>Materiali offline</Chip>
        <Chip active={tab === 'templates'} onClick={() => setTab('templates')}>Template e regole</Chip>
      </div>
      {tab === 'calendar' && <Calendar />}
      {tab === 'materials' && <Materials />}
      {tab === 'templates' && <Templates />}
    </div>
  );
}

function Calendar() {
  const toast = useToast();
  const list = useAsync(() => api.launch.contentList('taranto'), []);
  const [edit, setEdit] = useState<Partial<ContentItem> | null>(null);
  const [status, setStatus] = useState<ContentStatus | ''>('');
  const seed = async () => {
    try {
      const k = await api.launch.seedSocialCalendar('taranto', null);
      toast(k ? `${k} idee create (bozze da personalizzare)` : 'Il calendario è già stato generato');
      list.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const rows = (list.data ?? []).filter((c) => !status || c.status === status);
  return (
    <Card title="Calendario social (Instagram, Facebook, TikTok) ed email" subtitle="Nessuna pubblicazione automatica: qui si pianifica, si approva e si segna come pubblicato dopo averlo fatto a mano."
      action={<div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => void seed()} data-testid="seed-calendar"><Sparkles className="h-4 w-4" /> Genera 30 giorni (bozze)</Button>
        <Button size="sm" onClick={() => setEdit({ platform: 'instagram', content_type: 'local', status: 'idea' })}><Plus className="h-4 w-4" /> Nuovo</Button></div>}>
      <div className="flex flex-wrap gap-2">
        <Chip active={!status} onClick={() => setStatus('')}>Tutti</Chip>
        {(Object.keys(CONTENT_STATUS_LABELS) as ContentStatus[]).map((s) => <Chip key={s} active={status === s} onClick={() => setStatus(s)}>{CONTENT_STATUS_LABELS[s]} ({(list.data ?? []).filter((c) => c.status === s).length})</Chip>)}
      </div>
      <div className="mt-3">
        {list.loading && !list.data ? <PageLoader /> : list.error ? <Alert tone="error">{friendlyError(list.error)}</Alert> : rows.length ? (
          <ul className="divide-y divide-line" data-testid="content-list">
            {rows.map((c) => (
              <li key={c.id}>
                <button type="button" className="w-full py-2.5 text-left hover:bg-cream/50" onClick={() => setEdit(c)}>
                  <span className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="rounded-full bg-cream px-2 py-0.5 text-xs font-semibold">{CONTENT_STATUS_LABELS[c.status]}</span>
                    <strong>{c.title ?? CONTENT_TYPE_LABELS[c.content_type]}</strong>
                    <span className="text-ink-muted">· {PLATFORM_LABELS[c.platform]} · {CONTENT_TYPE_LABELS[c.content_type]}{c.is_sponsored ? ' · Sponsorizzato' : ''}</span>
                  </span>
                  <span className="block text-xs text-ink-muted">{c.scheduled_for ? `Programmato ${fmtDateTime(c.scheduled_for)}` : c.notes ?? ''}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : <EmptyState title="Nessun contenuto" text="Genera il calendario di 30 giorni: sono idee e bozze da completare con dati e foto reali." />}
      </div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title="Contenuto">
        {edit && <ContentForm item={edit} onSaved={() => { setEdit(null); list.reload(); }} />}
      </Sheet>
    </Card>
  );
}

function ContentForm({ item, onSaved }: { item: Partial<ContentItem>; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState<Partial<ContentItem>>({ ...item, scheduled_for: item.scheduled_for ? item.scheduled_for.slice(0, 16) : null });
  const save = async () => {
    try {
      await api.launch.contentUpsert({ ...f, scheduled_for: f.scheduled_for ? new Date(f.scheduled_for).toISOString() : null });
      toast('Contenuto salvato');
      onSaved();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const del = async () => {
    if (!f.id) return;
    await api.launch.contentDelete(f.id).catch(() => undefined);
    onSaved();
  };
  return (
    <div className="space-y-3" data-testid="content-form">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Canale"><Select value={f.platform} onChange={(e) => setF({ ...f, platform: e.target.value as ContentItem['platform'] })}>{Object.entries(PLATFORM_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
        <Field label="Tipo"><Select value={f.content_type} onChange={(e) => setF({ ...f, content_type: e.target.value as ContentItem['content_type'] })}>{Object.entries(CONTENT_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
        <Field label="Stato"><Select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as ContentStatus })} data-testid="content-status">{Object.entries(CONTENT_STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
        <Field label="Data di pubblicazione"><Input type="datetime-local" value={f.scheduled_for ?? ''} onChange={(e) => setF({ ...f, scheduled_for: e.target.value || null })} /></Field>
      </div>
      <Field label="Titolo"><Input value={f.title ?? ''} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
      <Field label="Testo / didascalia"><Textarea rows={5} value={f.caption ?? ''} onChange={(e) => setF({ ...f, caption: e.target.value })} data-testid="content-caption" /></Field>
      <Field label="Link al media (facoltativo)"><Input value={f.media_url ?? ''} onChange={(e) => setF({ ...f, media_url: e.target.value })} placeholder="https://…" /></Field>
      <Toggle checked={!!f.is_sponsored} onChange={(v) => setF({ ...f, is_sponsored: v })} label="Contenuto sponsorizzato / con corrispettivo" description="Richiede #adv o “Sponsorizzato” nella didascalia per essere approvato." />
      {f.content_type === 'ugc' && <Toggle checked={!!f.rights_confirmed} onChange={(v) => setF({ ...f, rights_confirmed: v })} label="Permesso dell’autore confermato" description="Senza permesso scritto il contenuto resta bozza." />}
      {f.content_type === 'giveaway' && <Toggle checked={!!f.compliance_checked} onChange={(v) => setF({ ...f, compliance_checked: v })} label="Checklist di conformità completata" description="Vedi Template e regole → Giveaway." />}
      <Field label="Note interne"><Textarea rows={2} value={f.notes ?? ''} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
      <div className="flex gap-2"><Button onClick={() => void save()} data-testid="content-save">Salva</Button>{f.id && <Button variant="ghost" onClick={() => void del()}>Elimina</Button>}</div>
    </div>
  );
}

function Materials() {
  const [kind, setKind] = useState<PrintKind>('flyer_customer');
  const [partner, setPartner] = useState('');
  const [zone, setZone] = useState('');
  const content = useMemo(() => {
    const utm = (source: string, medium: string, campaign: string, extra?: string) => `${APP.siteUrl}${buildUtmUrl(kind === 'flyer_restaurant' ? '/per-ristoratori' : '/taranto', { source, medium, campaign, content: extra })}`;
    switch (kind) {
      case 'flyer_restaurant':
        return { qrUrl: utm('flyer_b2b', 'offline', 'founding_restaurants', zone), title: `Porta il tuo ristorante su ${APP.name}.`, subtitle: 'La piattaforma dedicata alla cucina asiatica di Taranto e provincia. Scheda gratuita, menu digitale, offerte e statistiche.', cta: 'Inquadra e scopri come funziona' };
      case 'poster_partner':
        return { qrUrl: utm('partner_qr', 'partner', 'taranto_launch', partner || 'partner'), title: 'Dove mangiare sushi a Taranto?', subtitle: 'Tutta la cucina asiatica della città e della provincia, con mappa, menu e offerte.', cta: `Scopri ${APP.name}` };
      default:
        return { qrUrl: utm(kind === 'flyer_customer' ? 'flyer' : 'poster', 'offline', 'taranto_launch', zone), title: 'Cerchi sushi, poke o cucina asiatica a Taranto?', subtitle: `Scopri ${APP.name}.`, cta: 'Inquadra il QR' };
    }
  }, [kind, partner, zone]);
  const kinds: PrintKind[] = ['flyer_customer', 'flyer_restaurant', 'poster_partner', 'sticker'];
  return (
    <Card title="Street marketing e partner locali" subtitle="Ogni materiale ha un QR con UTM: le visite si vedono in Crescita → Campagne. I QR dei singoli ristoranti sono nel loro kit (dashboard ristoratore → Kit QR).">
      <div className="flex flex-wrap gap-2">{kinds.map((k) => <Chip key={k} active={kind === k} onClick={() => setKind(k)}>{PRINT_KINDS[k].label}</Chip>)}</div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        {kind === 'poster_partner' ? <Field label="Partner (utm_content, es. hotel_centro)"><Input value={partner} onChange={(e) => setPartner(e.target.value)} /></Field>
          : <Field label="Zona (campagna geolocalizzata)"><Select value={zone} onChange={(e) => setZone(e.target.value)}><option value="">Nessuna</option>{GEO_CAMPAIGNS.map((g) => <option key={g.utm} value={g.utm}>{g.zone}</option>)}</Select></Field>}
      </div>
      <div className="mt-4"><PrintSheet kind={kind} content={content} testId="print-sheet" /></div>
      <Note>Nessuna pubblicità a pagamento viene attivata dalla piattaforma. Le zone (Taranto centro, Talsano, San Vito, Massafra, Martina Franca, Grottaglie) servono solo a distinguere i materiali distribuiti.</Note>
    </Card>
  );
}

function Templates() {
  const toast = useToast();
  const { setting } = useRuntimeConfig();
  const landing = useAsync(() => api.launch.marketLanding('taranto'), []);
  const feats = {
    orders: setting<boolean>('orders_enabled', true) !== false, ai: setting<boolean>('ai_enabled', true) !== false, reviews: setting<boolean>('reviews_enabled', true) !== false,
    loyalty: setting<boolean>('loyalty_enabled', true) !== false, reservations: true, delivery: setting<boolean>('logistics_enabled', true) !== false,
  };
  const pr = pressRelease({ app: APP.name, restaurants: landing.data?.total ?? 0, cities: landing.data?.cities.length ?? 0, features: feats,
    company: setting<string | null>('legal_company_name', null), contact: setting<string | null>('support_email', null) });
  const em = launchEmailUsers({ app: APP.name, url: `${APP.siteUrl}/taranto?utm_source=newsletter&utm_medium=email&utm_campaign=taranto_launch`, features: feats });
  const nl = restaurantNewsletter({ app: APP.name, dashboardUrl: `${APP.siteUrl}/dashboard` });
  const copy = (t: string) => void navigator.clipboard.writeText(t).then(() => toast('Testo copiato'), () => toast('Copia non riuscita', 'error'));
  const Block = ({ title, text, note }: { title: string; text: string; note?: string }) => (
    <Card title={title} action={<Button size="sm" variant="outline" onClick={() => copy(text)}><Copy className="h-4 w-4" /> Copia</Button>}>
      <pre className="max-h-80 overflow-auto whitespace-pre-wrap [overflow-wrap:anywhere] rounded-2xl bg-cream/60 p-3 font-sans text-sm">{text}</pre>
      {note && <Note>{note}</Note>}
    </Card>
  );
  const List = ({ title, items, testId }: { title: string; items: string[]; testId?: string }) => (
    <Card title={title} testId={testId}><ol className="list-decimal space-y-1.5 pl-5 text-sm">{items.map((x) => <li key={x}>{x}</li>)}</ol></Card>
  );
  return (
    <div className={cn('grid gap-5 lg:grid-cols-2')} data-testid="templates">
      <Block title="Comunicato stampa (bozza)" text={pr} note="Menziona solo le funzioni attive ora e i numeri reali della landing. Nessun invio automatico: inviare a mano ai contatti del CRM → Stampa." />
      <Block title={`Email di lancio agli utenti · “${em.subject}”`} text={em.body} note={em.note} />
      <Block title={`Newsletter ristoratori · “${nl.subject}”`} text={nl.body} note={nl.note} />
      <List title="Contenuti degli utenti (UGC)" items={UGC_GUIDELINES} />
      <List title="Ristorante della settimana" items={SPOTLIGHT_RULES} />
      <List title="Giveaway: checklist di conformità (prima di qualsiasi concorso)" items={GIVEAWAY_CHECKLIST} testId="giveaway-checklist" />
      <Card title="Press kit"><p className="text-sm">Pagina pubblica con logo, descrizione e contatti stampa: <a className="font-semibold text-coral-700" href="/press">/press</a>. Screenshot e dati del fondatore sono segnaposto da completare.</p></Card>
      <Card title="Eventi locali (futuro)"><p className="text-sm text-ink-muted">AsiaFood Week, Sushi Week Taranto, Asian Food Festival: solo idee da pianificare nel CRM (Partner → eventi). Nessun evento fisico viene lanciato dalla piattaforma.</p></Card>
    </div>
  );
}
