// Qualità dei dati (monitoraggio giornaliero durante il lancio) + segmenti commerciali
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { api } from '@/services';
import { FILTER_LABELS, MISSING_LABELS, type RestaurantFilter } from '@/types/launch';
import { Card, DemoNotice, fmtDate, n, Note, Segment, Table } from './shared';

const FILTERS: RestaurantFilter[] = ['incomplete', 'no_coords', 'no_hours', 'no_phone', 'no_menu', 'claimable', 'stale', 'closed', 'duplicates', 'position', 'segment_a', 'segment_b', 'segment_c'];

export default function LaunchQuality() {
  const [filter, setFilter] = useState<RestaurantFilter | null>('incomplete');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(0);
  const d = useAsync(() => api.launch.restaurants('taranto', filter, q || null, 50, page * 50), [filter, q, page]);
  const data = d.data;
  return (
    <div className="space-y-4" data-testid="launch-quality">
      {data && <DemoNotice show={data.include_demo} />}
      <Card title="Qualità dei dati" subtitle="Da controllare ogni giorno durante il lancio: locali chiusi, orari o telefoni errati, posizioni sulla mappa, doppioni. Le segnalazioni dei clienti hanno la priorità."
        action={data ? <Link to="/admin/reports" className="text-sm font-semibold text-coral-700">Segnalazioni aperte: {data.open_reports}</Link> : null}>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filtri qualità">
          <Chip active={filter === null} onClick={() => { setFilter(null); setPage(0); }}>Tutti {data ? `(${data.counts.all})` : ''}</Chip>
          {FILTERS.map((f) => (
            <Chip key={f} active={filter === f} onClick={() => { setFilter(f); setPage(0); }}>
              {FILTER_LABELS[f]} {data ? `(${data.counts[f]})` : ''}
            </Chip>
          ))}
        </div>
        <Input className="mt-3" placeholder="Cerca per nome" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} aria-label="Cerca ristorante" />
        <div className="mt-4">
          {d.loading && !data ? <PageLoader /> : d.error ? <Alert tone="error">{friendlyError(d.error)}</Alert> : data && data.rows.length ? (
            <>
              <Table head={['Seg.', 'Ristorante', 'Comune', 'Completezza', 'Mancano', 'Segnali', 'Ultima verifica', '']} testId="quality-table">
                {data.rows.map((r) => (
                  <tr key={r.id} data-testid="quality-row">
                    <td className="py-2 pr-3"><Segment s={r.segment} /></td>
                    <td className="py-2 pr-3 font-semibold">{r.name}{!r.is_active && <span className="ml-1 text-xs font-normal text-ink-muted">(bozza)</span>}{r.is_demo && <span className="ml-1 text-xs font-normal text-ink-muted">(DEMO)</span>}</td>
                    <td className="py-2 pr-3">{r.city_name}</td>
                    <td className="py-2 pr-3 tabular-nums">
                      <span className="inline-flex items-center gap-2"><span className="h-1.5 w-14 overflow-hidden rounded-full bg-cream"><span className="block h-full bg-ink" style={{ width: `${r.completion}%` }} /></span>{r.completion}%</span>
                    </td>
                    <td className="py-2 pr-3 text-xs text-ink-muted">{r.missing.map((m) => MISSING_LABELS[m] ?? m).join(', ') || '—'}</td>
                    <td className="py-2 pr-3 text-xs">{[r.closed && 'chiuso', r.duplicate && 'possibile doppione', r.position_far && 'posizione anomala', r.stale && 'dati obsoleti', r.claimable && 'rivendicabile'].filter(Boolean).join(' · ') || '—'}</td>
                    <td className="py-2 pr-3 text-xs">{fmtDate(r.last_verified_at)}</td>
                    <td className="py-2 pr-3"><Link to={`/admin/restaurants/${r.id}`} className="text-sm font-semibold text-coral-700">Modifica</Link></td>
                  </tr>
                ))}
              </Table>
              <div className="mt-3 flex items-center justify-between text-sm">
                <span className="text-ink-muted">{n(data.total)} risultati</span>
                <span className="flex gap-2">
                  <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Indietro</Button>
                  <Button size="sm" variant="outline" disabled={(page + 1) * 50 >= data.total} onClick={() => setPage((p) => p + 1)}>Avanti</Button>
                </span>
              </div>
            </>
          ) : <EmptyState title="Nessun problema con questo filtro" />}
        </div>
        <Note>Completezza (0–100): nome, indirizzo, coordinate, telefono, orari, categorie, logo, copertina, menu, social, servizi, prezzi, AYCE, consegna/asporto, prenotazioni. Criteri in docs/launch/METRICS.md.</Note>
      </Card>
    </div>
  );
}
