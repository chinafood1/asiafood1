// Partner success: health score di utilizzo, rischi, follow-up, Partner Fondatori, tempo al valore, ROI misurato
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/Button';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { api } from '@/services';
import { PARTNER_FLAG_LABELS, type TimeToValue } from '@/types/launch';
import { Card, fmtDate, n, Note, Stat, Table } from './shared';

const hrs = (h: number | null) => (h == null ? '—' : h < 48 ? `${h} h` : `${Math.round(h / 24)} gg`);

export function TimeToValueCard({ t }: { t: TimeToValue }) {
  const rows: [string, { n: number; median_hours: number | null }][] = [['Profilo completato', t.profile], ['Menu creato', t.menu], ['Prima offerta', t.offer], ['Prima prenotazione', t.reservation], ['Abbonamento pagato', t.paid]];
  return (
    <Card title="Tempo al valore" subtitle={`Mediana dalla rivendicazione · ${t.claimed} ristoranti rivendicati`} testId="time-to-value">
      <dl className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        {rows.map(([l, v]) => (
          <div key={l} className="rounded-2xl bg-cream/60 p-3"><dt className="text-xs text-ink-muted">{l}</dt><dd className="font-display text-xl font-extrabold tabular-nums">{hrs(v.median_hours)}</dd><dd className="text-xs text-ink-muted">{v.n} su {t.claimed}</dd></div>
        ))}
      </dl>
    </Card>
  );
}

export default function LaunchPartners() {
  const toast = useToast();
  const p = useAsync(() => api.launch.partners('taranto'), []);
  if (p.loading && !p.data) return <PageLoader />;
  if (p.error || !p.data) return <Alert tone="error">{friendlyError(p.error)}</Alert>;
  const d = p.data;
  const gen = async () => {
    try {
      const k = await api.launch.generateFollowups('taranto');
      toast(k ? `${k} follow-up creati` : 'Nessun nuovo follow-up: quelli aperti sono già in lista');
      p.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const f = d.founding;
  return (
    <div className="space-y-5" data-testid="launch-partners">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Partner (rivendicati)" value={n(d.rows.length)} />
        <Stat label="A rischio" value={n(d.at_risk)} tone={d.at_risk ? 'warn' : 'ok'} testId="at-risk" />
        <Stat label="Partner Fondatori" value={`${f.used} / ${f.limit}`} hint={f.enabled ? `${f.plan} per ${f.days} giorni` : 'Programma disattivato'} />
        <Stat label="Paganti" value={n(d.rows.filter((r) => r.paying).length)} />
      </div>
      <Card title="Health score di utilizzo" subtitle="Quanto il ristoratore usa la piattaforma (profilo, menu, accessi, offerte, risposta alle prenotazioni, azioni dei clienti). Non è un giudizio sul ristorante."
        action={<Button size="sm" variant="outline" onClick={() => void gen()} data-testid="gen-followups">Crea follow-up per i partner a rischio</Button>}>
        {d.rows.length ? (
          <Table head={['Ristorante', 'Health', 'Segnali', 'Ultimo accesso', 'Offerte', 'Piano', 'ROI 30 gg (misurato)']} testId="partners-table">
            {d.rows.map((r) => (
              <tr key={r.restaurant_id} data-testid="partner-row">
                <td className="py-2 pr-3 font-semibold"><Link to={`/admin/restaurants/${r.restaurant_id}`} className="hover:underline">{r.name}</Link><span className="block text-xs font-normal text-ink-muted">{r.city_name}{r.founding ? ' · Partner Fondatore' : ''}</span></td>
                <td className="py-2 pr-3"><span className={cn('font-display text-lg font-extrabold tabular-nums', r.health >= 70 ? 'text-emerald-700' : r.health < 40 ? 'text-coral-700' : '')}>{r.health}</span></td>
                <td className="py-2 pr-3 text-xs">{r.flags.map((x) => PARTNER_FLAG_LABELS[x]).join(' · ') || '—'}</td>
                <td className="py-2 pr-3 text-xs">{fmtDate(r.last_owner_activity)}</td>
                <td className="py-2 pr-3 tabular-nums">{r.active_offers}</td>
                <td className="py-2 pr-3">{r.plan}{r.trial_ends_at && <span className="block text-xs text-ink-muted">fino al {fmtDate(r.trial_ends_at)}</span>}</td>
                <td className="py-2 pr-3 text-xs tabular-nums">{r.roi.views} visite · {r.roi.calls} chiamate · {r.roi.directions} indicazioni · {r.roi.bookings} prenotazioni · {r.roi.orders} ordini · {r.roi.coupon_uses} coupon · {r.roi.qr_scans} QR</td>
              </tr>
            ))}
          </Table>
        ) : <EmptyState title="Ancora nessun partner" text="I ristoranti compaiono qui dopo la rivendicazione approvata." />}
        <Note>ROI = solo numeri misurati sulla scheda negli ultimi 30 giorni, da mostrare al ristoratore dopo le prime conversioni reali. Mai promettere risultati futuri.</Note>
      </Card>
      <Card title={f.name} subtitle={`${f.used}/${f.limit} posti · beneficio: piano ${f.plan} per ${f.days} giorni senza addebiti · badge ${f.badge_enabled ? 'visibile' : 'nascosto'} solo per gli aderenti`} testId="founding-list">
        {f.rows.length ? (
          <ul className="divide-y divide-line text-sm">
            {f.rows.map((x) => (
              <li key={x.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                <span><strong>#{x.number} {x.restaurant_name}</strong> <span className="text-ink-muted">· attivato {fmtDate(x.activated_at)}</span></span>
                <span className={cn('text-xs font-semibold', x.status === 'revoked' ? 'text-coral-700' : x.status === 'active' ? 'text-emerald-700' : 'text-ink-muted')}>
                  {x.status === 'active' ? `Attivo · ${x.days_left ?? '—'} giorni rimasti` : x.status === 'completed' ? `Beneficio concluso${x.paying ? ' · ora pagante' : ''}` : `Revocato: ${x.revoked_reason}`}
                </span>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-ink-muted">Nessun Partner Fondatore: si attiva dalla scheda lead di un ristorante rivendicato.</p>}
      </Card>
      <TimeToValueCard t={d.time_to_value} />
    </div>
  );
}
