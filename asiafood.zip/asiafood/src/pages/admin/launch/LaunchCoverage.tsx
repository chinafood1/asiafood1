// Copertura ristoranti per comune (Taranto e provincia) + mappa dei comuni prioritari
import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { MapView } from '@/lib/maps/MapView';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { api } from '@/services';
import { Card, DemoNotice, LAUNCH_BASE, n, Note, Table } from './shared';

export default function LaunchCoverage() {
  const c = useAsync(() => api.launch.coverage('taranto'), []);
  const [active, setActive] = useState<string | null>(null);
  const rows = useMemo(() => c.data?.rows ?? [], [c.data]);
  const points = useMemo(() => rows.filter((r) => r.lat != null && r.lng != null)
    .map((r) => ({ id: r.city_id, lat: r.lat!, lng: r.lng!, label: `${r.city}: ${r.listed} pubblicati, ${r.claimed} rivendicati`, emoji: r.listed > 0 ? String(Math.min(r.listed, 99)) : '·' })), [rows]);
  if (c.loading && !c.data) return <PageLoader />;
  if (c.error || !c.data) return <Alert tone="error">{friendlyError(c.error)}</Alert>;
  const tot = rows.reduce((s, r) => ({ censused: s.censused + r.censused, listed: s.listed + r.listed, verified: s.verified + r.verified, claimed: s.claimed + r.claimed, partner: s.partner + r.partner }),
    { censused: 0, listed: 0, verified: 0, claimed: 0, partner: 0 });
  const empty = rows.filter((r) => r.priority != null && r.priority <= 19 && r.listed === 0);
  return (
    <div className="space-y-5" data-testid="launch-coverage">
      <DemoNotice show={c.data.include_demo} />
      <div className="grid gap-5 lg:grid-cols-[1fr_1.2fr]">
        <Card title="Mappa della copertura" subtitle="Un segnaposto per comune: il numero indica i locali pubblicati.">
          <MapView points={points} activeId={active} onSelect={setActive} className="h-80 rounded-2xl" />
          {active && (() => {
            const r = rows.find((x) => x.city_id === active);
            return r ? <p className="mt-2 text-sm"><strong>{r.city}</strong> · {r.censused} censiti · {r.verified} verificati · {r.claimed} rivendicati · {r.partner} partner</p> : null;
          })()}
        </Card>
        <Card title="Totale provincia" subtitle={`${rows.length} comuni (19 prioritari + altri con locali)`}>
          <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
            {([['Censiti', tot.censused], ['Pubblicati', tot.listed], ['Verificati', tot.verified], ['Rivendicati', tot.claimed], ['Partner', tot.partner]] as const).map(([l, v]) => (
              <div key={l} className="rounded-2xl bg-cream/60 p-3"><dt className="text-xs text-ink-muted">{l}</dt><dd className="font-display text-xl font-extrabold tabular-nums">{n(v)}</dd></div>
            ))}
          </dl>
          {empty.length > 0 && <p className="mt-3 text-sm text-ink-muted">Comuni prioritari ancora senza locali pubblicati: <strong className="text-ink">{empty.map((r) => r.city).join(', ')}</strong>.</p>}
          <Note>Per censire nuovi locali: Admin → Importa (CSV/JSON con fonte) oppure inserimento manuale. Mai dati inventati.</Note>
        </Card>
      </div>
      <Card title="Copertura per comune" testId="coverage-table">
        <Table head={['#', 'Comune', 'Censiti', 'Pubblicati', 'Verificati', 'Non rivendicati', 'Rivendicati', 'Partner', 'Premium/Top', 'Completezza']}>
          {rows.map((r) => (
            <tr key={r.city_id} className={cn(r.listed === 0 && 'text-ink-muted')} data-testid="coverage-row">
              <td className="py-2 pr-3 tabular-nums">{r.priority ?? '—'}</td>
              <td className="py-2 pr-3 font-semibold"><Link to={`/ristoranti/${r.slug}`} className="hover:underline">{r.city}</Link></td>
              <td className="py-2 pr-3 tabular-nums">{r.censused}</td>
              <td className="py-2 pr-3 tabular-nums">{r.listed}</td>
              <td className="py-2 pr-3 tabular-nums">{r.verified}</td>
              <td className="py-2 pr-3 tabular-nums">{r.unclaimed}</td>
              <td className="py-2 pr-3 tabular-nums">{r.claimed}</td>
              <td className="py-2 pr-3 tabular-nums">{r.partner}</td>
              <td className="py-2 pr-3 tabular-nums">{r.premium_top}</td>
              <td className="py-2 pr-3 tabular-nums">{r.avg_completion != null ? `${r.avg_completion}%` : '—'}</td>
            </tr>
          ))}
        </Table>
        <p className="mt-3 text-sm"><Link to={`${LAUNCH_BASE}/quality`} className="font-semibold text-coral-700">Vai alla qualità dei dati</Link></p>
      </Card>
    </div>
  );
}
