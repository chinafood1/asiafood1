// ─────────────────────────────────────────────────────────────
//  Fase 12 · Taranto Launch Control Center (/admin/launch/taranto/*)
//  Una schermata per ciò che serve a lanciare davvero: copertura, vendite, utenti,
//  engagement, ricavi, ordini, SEO, qualità, supporto, readiness. Numeri solo da dati reali.
// ─────────────────────────────────────────────────────────────
import { lazy, Suspense } from 'react';
import { Link, NavLink, Route, Routes } from 'react-router-dom';
import { AlertTriangle, ArrowRight, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import { CHANNEL_LABELS, GOAL_LABELS, GOAL_STATUS_LABELS, LEAD_STATUS_LABELS, PHASE_LABELS, RESTAURANT_PIPELINE, type Channel } from '@/types/launch';
import { BarList, Card, Columns, DemoNotice, fmtDate, euro, LAUNCH_BASE, n, Note, ProgressBar, Stat } from './shared';

const Coverage = lazy(() => import('./LaunchCoverage'));
const Sales = lazy(() => import('./LaunchSales'));
const Quality = lazy(() => import('./LaunchQuality'));
const Partners = lazy(() => import('./LaunchPartners'));
const Growth = lazy(() => import('./LaunchGrowth'));
const Marketing = lazy(() => import('./LaunchMarketing'));
const Plan = lazy(() => import('./LaunchPlan'));
const Today = lazy(() => import('./LaunchToday'));

const TABS: [string, string][] = [
  ['', 'Panoramica'], ['daily', 'Oggi (vendite)'], ['today', 'Operations'], ['coverage', 'Copertura'], ['first50', 'First 50'], ['crm', 'CRM'],
  ['quality', 'Qualità dati'], ['partners', 'Partner'], ['growth', 'Crescita'], ['marketing', 'Marketing'], ['plan', 'Piano e obiettivi'],
];

export default function LaunchArea() {
  useSeo({ title: 'Taranto Launch Control', noindex: true });
  return (
    <div data-testid="launch-area">
      <h1 className="text-2xl font-extrabold">Taranto Launch Control</h1>
      <p className="mt-1 text-sm text-ink-muted">Lancio di AsiaFood a Taranto e provincia. Target operativi, non risultati garantiti.</p>
      <nav className="-mx-1 mt-4 flex gap-1 overflow-x-auto pb-1" aria-label="Sezioni del lancio">
        {TABS.map(([to, label]) => (
          <NavLink key={to} to={to ? `${LAUNCH_BASE}/${to}` : LAUNCH_BASE} end={!to}
            className={({ isActive }) => cn('shrink-0 rounded-full px-3.5 py-2 text-sm font-semibold', isActive ? 'bg-ink text-white' : 'text-ink hover:bg-cream')}>
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="mt-5">
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route index element={<Overview />} />
            <Route path="daily" element={<Sales view="daily" />} />
            <Route path="first50" element={<Sales view="first50" />} />
            <Route path="crm" element={<Sales view="crm" />} />
            <Route path="crm/:id" element={<Sales view="crm" />} />
            <Route path="today" element={<Today />} />
            <Route path="coverage" element={<Coverage />} />
            <Route path="quality" element={<Quality />} />
            <Route path="partners" element={<Partners />} />
            <Route path="growth" element={<Growth />} />
            <Route path="marketing" element={<Marketing />} />
            <Route path="plan" element={<Plan />} />
          </Routes>
        </Suspense>
      </div>
    </div>
  );
}

function Overview() {
  const o = useAsync(() => api.launch.overview('taranto'), []);
  if (o.loading && !o.data) return <PageLoader />;
  if (o.error || !o.data) return <Alert tone="error">{friendlyError(o.error)}</Alert>;
  const d = o.data;
  const k = d.kpis;
  const channels = Object.entries(k.traffic_by_channel).sort((a, b) => b[1] - a[1]);
  return (
    <div className="space-y-5" data-testid="launch-overview">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm"><span className="rounded-full bg-cream px-3 py-1 font-semibold" data-testid="launch-phase">{PHASE_LABELS[d.phase] ?? d.phase}</span>
          <span className="ml-2 text-ink-muted">Aggiornato {fmtDate(d.generated_at)} · {new Date(d.generated_at).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}</span></p>
        <Button size="sm" variant="outline" onClick={o.reload}><RefreshCw className="h-4 w-4" /> Aggiorna</Button>
      </div>
      <DemoNotice show={d.include_demo && k.demo > 0} />

      {d.alerts.length > 0 && (
        <ul className="space-y-2" data-testid="launch-alerts">
          {d.alerts.map((a, i) => (
            <li key={i} className={cn('flex items-start gap-2 rounded-2xl px-4 py-3 text-sm', a.level === 'high' ? 'bg-coral-50 text-coral-700' : a.level === 'medium' ? 'bg-amber-50 text-amber-900' : 'bg-cream text-ink')}>
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
              <span className="flex-1">{a.text}</span>
              {a.link && <Link to={a.link} className="shrink-0 font-semibold underline">Apri</Link>}
            </li>
          ))}
        </ul>
      )}

      <Card title="Avanzamento del lancio" subtitle="Calcolato dai dati reali rispetto ai target operativi (modificabili in Piano e obiettivi)." testId="launch-progress">
        <div className="grid gap-4 md:grid-cols-2">
          {d.progress.map((p) => <ProgressBar key={p.key} label={p.label} value={p.value} target={p.target} pctValue={p.pct} testId={`progress-${p.key}`} />)}
        </div>
      </Card>

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4" aria-label="Ristoranti">
        <Stat label="Censiti (incl. bozze)" value={n(k.censused)} hint={`${n(k.listed)} pubblicati · ${n(k.drafts)} bozze`} testId="kpi-censused" />
        <Stat label="Verificati" value={n(k.verified)} hint={`Completezza media ${k.avg_completion ?? '—'}%`} />
        <Stat label="Rivendicati" value={n(k.claimed)} testId="kpi-claimed" />
        <Stat label="Partner" value={n(k.partner)} hint={`${n(k.founding)} Partner Fondatori · ${n(k.premium_top)} Premium/Top`} />
        <Stat label="Paganti" value={n(k.paying)} hint={`MRR ${euro(k.mrr_cents)}`} />
        <Stat label="Utenti registrati" value={n(k.users)} hint={`${n(k.users_active_30d)} attivi negli ultimi 30 giorni`} />
        <Stat label="Prenotazioni (30 gg)" value={n(k.reservations_30d)} />
        <Stat label={k.orders_enabled ? 'Ordini completati (30 gg)' : 'Ordini (modulo disattivato)'} value={n(k.orders_30d)} hint={k.orders_enabled ? `GMV ${k.gmv_30d.toLocaleString('it-IT', { style: 'currency', currency: 'EUR' })}` : undefined} />
        <Stat label="Coupon salvati (30 gg)" value={n(k.coupon_claims_30d)} hint={`${n(k.coupon_redeemed_30d)} usati in cassa`} />
        <Stat label="Recensioni (30 gg)" value={n(k.reviews_30d)} />
        <Stat label="Inviti amici" value={n(k.referrals.invited)} hint={`${n(k.referrals.registered)} iscritti · ${n(k.referrals.qualified)} qualificati`} />
        <Stat label="Sponsorizzate attive" value={n(k.sponsored.active)} hint={`${n(k.sponsored.impressions_30d)} impression · ${n(k.sponsored.clicks_30d)} clic (30 gg)`} />
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Successful Food Connections" subtitle="North Star interna: prenotazioni completate + ordini completati + coupon usati + indicazioni stradali (deduplicate). Per settimana." testId="north-star">
          <p className="mb-2 font-display text-3xl font-extrabold tabular-nums">{n(k.food_connections_30d)} <span className="text-sm font-normal text-ink-muted">negli ultimi 30 giorni</span></p>
          <Columns data={d.north_star.map((w) => ({ label: fmtDate(w.week), value: w.value }))} label="Food Connections per settimana" />
          <Note>Le visualizzazioni da sole non sono una misura di successo: qui contano solo azioni concrete dei clienti.</Note>
        </Card>
        <Card title="Traffico (30 gg)" subtitle={`${n(k.visits_30d)} visite di atterraggio · ${n(k.qr_scans_30d)} scansioni QR`}>
          <BarList rows={channels.map(([c, v]) => ({ label: CHANNEL_LABELS[c as Channel] ?? c, value: v }))} testId="traffic-channels" empty="Ancora nessuna visita registrata." />
          <Link to={`${LAUNCH_BASE}/growth`} className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-coral-700">Crescita e UTM <ArrowRight className="h-4 w-4" /></Link>
        </Card>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Pipeline vendite (ristoranti)" action={<Link to={`${LAUNCH_BASE}/crm`} className="text-sm font-semibold text-coral-700">CRM</Link>} testId="pipeline">
          <BarList rows={RESTAURANT_PIPELINE.map((s) => ({ label: LEAD_STATUS_LABELS[s], value: d.pipeline[s] ?? 0 }))} empty="Nessun lead: crea i lead dai ristoranti nella sezione CRM." />
        </Card>
        <Card title="SEO locale" subtitle={`${n(k.seo.restaurant_pages)} schede · ${n(k.seo.city_pages)} pagine comune · query prioritarie pronte ${k.seo.local_queries_ready}/${k.seo.local_queries_total}`} testId="seo-local">
          <ul className="grid gap-1.5 text-sm sm:grid-cols-2">
            {d.local_queries.map((q) => (
              <li key={q.query} className="flex items-center justify-between gap-2 rounded-xl bg-cream/60 px-3 py-2">
                <Link to={q.path} className="truncate hover:underline">{q.query}</Link>
                <span className={cn('shrink-0 text-xs font-semibold', q.ready ? 'text-emerald-700' : 'text-ink-muted')}>{q.ready ? `Pronta · ${q.count}` : `${q.count} ${q.count === 1 ? 'locale' : 'locali'}`}</span>
              </li>
            ))}
          </ul>
          <Note>Una pagina categoria×città diventa indicizzabile solo con abbastanza locali pubblici: niente pagine vuote.</Note>
        </Card>
      </div>

      <Card title="Obiettivi (target vs actual)" action={<Link to={`${LAUNCH_BASE}/plan`} className="text-sm font-semibold text-coral-700">Modifica</Link>} testId="goals">
        <ul className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {d.goals.map((g) => (
            <li key={g.id} className="rounded-2xl border border-line p-3 text-sm">
              <p className="font-semibold">{GOAL_LABELS[g.metric_key]}</p>
              <p className="tabular-nums">{n(g.actual_value ?? 0)} / {n(g.target_value)} <span className="text-ink-muted">entro {fmtDate(g.period_end)}</span></p>
              <p className={cn('mt-1 text-xs font-semibold', g.status === 'achieved' || g.status === 'on_track' ? 'text-emerald-700' : g.status === 'behind' ? 'text-coral-700' : 'text-ink-muted')}>{GOAL_STATUS_LABELS[g.status]}</p>
            </li>
          ))}
        </ul>
        <Note>Target operativi suggeriti: 100 ristoranti censiti, 30 rivendicati, 20 partner, 10 paganti, 1.000 utenti, 500 attivi. Non sono previsioni.</Note>
      </Card>
      <p className="text-sm text-ink-muted">Readiness tecnica e blocker di lancio: <Link to="/admin/launch-checklist" className="font-semibold text-coral-700">Launch checklist</Link>.</p>
    </div>
  );
}
