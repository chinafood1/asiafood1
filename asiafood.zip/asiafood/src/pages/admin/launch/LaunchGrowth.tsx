// Crescita: review settimanale, funnel, coorti, acquisizione (canali, UTM, codici, QR), referral, esperimenti, costi/CAC, ricavi
import { useState } from 'react';
import { Copy } from 'lucide-react';
import { buildUtmUrl, UTM_PRESETS } from '@shared/utm';
import { Button } from '@/components/ui/Button';
import { Chip } from '@/components/ui/Badge';
import { Field, Input, Select } from '@/components/ui/Field';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { QrCode } from '@/components/ui/QrCode';
import { useToast } from '@/components/ui/Toast';
import { APP } from '@/config/app';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { api } from '@/services';
import { CANCELLATION_REASONS, CHANNEL_LABELS, FEEDBACK_TYPE_LABELS, QR_KIND_LABELS, type Channel, type QrKind } from '@/types/launch';
import { BarList, Card, Columns, euro, fmtDate, Note, pct, Stat, Table } from './shared';
import { TimeToValueCard } from './LaunchPartners';

export default function LaunchGrowth() {
  const [days, setDays] = useState(30);
  const w = useAsync(() => api.launch.weekly('taranto', 8), []);
  const g = useAsync(() => api.launch.growth('taranto', days), [days]);
  if ((w.loading && !w.data) || (g.loading && !g.data)) return <PageLoader />;
  if (w.error || g.error || !w.data || !g.data) return <Alert tone="error">{friendlyError(w.error ?? g.error)}</Alert>;
  const wk = w.data;
  const gr = g.data;
  const uf = wk.user_funnel;
  const bf = wk.business_funnel;
  return (
    <div className="space-y-5" data-testid="launch-growth">
      <Card title="Review settimanale" subtitle="Ultime 8 settimane (lunedì–domenica, fuso Europe/Rome)." testId="weekly">
        <div className="grid gap-5 lg:grid-cols-2">
          <div><p className="mb-1 text-sm font-semibold">Ristoranti contattati</p><Columns data={wk.weeks.map((x) => ({ label: fmtDate(x.week), value: x.contacted }))} label="Ristoranti contattati per settimana" /></div>
          <div><p className="mb-1 text-sm font-semibold">Nuovi utenti</p><Columns data={wk.weeks.map((x) => ({ label: fmtDate(x.week), value: x.new_users }))} label="Nuovi utenti per settimana" /></div>
        </div>
        <div className="mt-4">
          <Table head={['Settimana', 'Contattati', 'Risposte', 'Rivendicazioni', 'Prove', 'Paganti', 'Nuovi utenti', 'Visite', 'Prenotazioni', 'Ordini', 'Food Connections']} testId="weekly-table">
            {wk.weeks.map((x) => (
              <tr key={x.week} className="tabular-nums">
                <td className="py-1.5 pr-3">{fmtDate(x.week)}</td><td className="py-1.5 pr-3">{x.contacted}</td><td className="py-1.5 pr-3">{x.replies}</td><td className="py-1.5 pr-3">{x.claims}</td>
                <td className="py-1.5 pr-3">{x.trials}</td><td className="py-1.5 pr-3">{x.paid}</td><td className="py-1.5 pr-3">{x.new_users}</td><td className="py-1.5 pr-3">{x.visits}</td>
                <td className="py-1.5 pr-3">{x.reservations}</td><td className="py-1.5 pr-3">{x.orders}</td><td className="py-1.5 pr-3">{x.food_connections}</td>
              </tr>
            ))}
          </Table>
          <p className="mt-2 text-sm">MRR attuale: <strong>{euro(wk.mrr_cents)}</strong></p>
        </div>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Funnel utente (30 gg)" subtitle="Conteggi per fase, non il percorso della stessa persona." testId="user-funnel">
          <BarList rows={[
            { label: 'Visite', value: uf.visits }, { label: 'Ricerche', value: uf.searches }, { label: 'Schede viste', value: uf.restaurant_views }, { label: 'Menu visti', value: uf.menu_views },
            { label: 'Preferiti', value: uf.favorites }, { label: 'Prenotazioni / ordini', value: uf.reservations_orders }, { label: 'Recensioni', value: uf.reviews }, { label: 'Utenti tornati (≥ 2 giorni)', value: uf.returning_users },
          ]} />
        </Card>
        <Card title="Funnel business" subtitle="Ristoranti del mercato per fase." testId="business-funnel">
          <BarList rows={[
            { label: 'Censiti', value: bf.discovered }, { label: 'Lead', value: bf.lead }, { label: 'Contattati', value: bf.contacted }, { label: 'Rivendicati', value: bf.claimed },
            { label: 'In prova', value: bf.trial }, { label: 'Attivati', value: bf.activated, hint: pct(bf.activated, bf.claimed) }, { label: 'Paganti', value: bf.paid, hint: pct(bf.paid, bf.claimed) },
            { label: 'Trattenuti (> 60 gg)', value: bf.retained },
          ]} />
        </Card>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Attivazione" subtitle="Definizioni in docs/launch/METRICS.md" testId="activation">
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Utenti attivati (iscritti 30–60 gg fa)" value={pct(wk.activation.users_activated_30_60d, wk.activation.users_signed_up_30_60d)} hint={`${wk.activation.users_activated_30_60d} su ${wk.activation.users_signed_up_30_60d}: preferito, coupon, prenotazione o ordine entro 30 giorni`} />
            <Stat label="Ristoranti attivati" value={pct(wk.activation.restaurants_activated, wk.activation.restaurants_claimed)} hint={`${wk.activation.restaurants_activated} su ${wk.activation.restaurants_claimed}: profilo ≥ 70% + menu o offerta + prima azione di un cliente`} />
          </div>
        </Card>
        <Card title="Coorti" testId="cohorts">
          <Table head={['Settimana iscrizione', 'Utenti', 'Tornati in sett. 2', 'Tornati dopo', 'Ristoranti rivendicati', 'Attivati', 'Paganti']}>
            {wk.cohorts.users.map((u, i) => {
              const r = wk.cohorts.restaurants[i];
              return (
                <tr key={u.week} className="tabular-nums">
                  <td className="py-1.5 pr-3">{fmtDate(u.week)}</td><td className="py-1.5 pr-3">{u.size}</td><td className="py-1.5 pr-3">{u.size ? `${u.returned_week2} (${pct(u.returned_week2, u.size)})` : '—'}</td>
                  <td className="py-1.5 pr-3">{u.size ? u.returned_after : '—'}</td><td className="py-1.5 pr-3">{r?.claimed ?? 0}</td><td className="py-1.5 pr-3">{r?.activated ?? 0}</td><td className="py-1.5 pr-3">{r?.paid ?? 0}</td>
                </tr>
              );
            })}
          </Table>
          <p className="mt-2 text-sm text-ink-muted">Conversione prove: Partner Fondatori {wk.cohorts.trial_conversion.founding_converted}/{wk.cohorts.trial_conversion.founding_completed} · prove Stripe {wk.cohorts.trial_conversion.stripe_trials_converted}/{wk.cohorts.trial_conversion.stripe_trials_ended}</p>
        </Card>
      </div>

      <TimeToValueCard t={wk.time_to_value} />

      <Card title="Feedback loop (7 gg)" subtitle="Da rivedere ogni settimana: problemi principali, richieste, abbandoni, voce di ristoratori e utenti." testId="feedback-loop">
        <div className="grid gap-5 md:grid-cols-3">
          <div><p className="mb-2 text-sm font-semibold">Supporto per categoria</p><BarList rows={Object.entries(wk.feedback_loop.support_by_category).map(([k, v]) => ({ label: k, value: v }))} empty="Nessun ticket." /></div>
          <div><p className="mb-2 text-sm font-semibold">Feedback per tipo</p><BarList rows={Object.entries(wk.feedback_loop.feedback_by_type).map(([k, v]) => ({ label: FEEDBACK_TYPE_LABELS[k as keyof typeof FEEDBACK_TYPE_LABELS] ?? k, value: v }))} empty="Nessun feedback." /></div>
          <div><p className="mb-2 text-sm font-semibold">Motivi di disdetta (90 gg)</p><BarList rows={Object.entries(wk.feedback_loop.cancellation_reasons).map(([k, v]) => ({ label: CANCELLATION_REASONS[k] ?? k, value: v }))} empty="Nessuna disdetta." />
            <p className="mt-2 text-sm">NPS (90 gg): <strong>{wk.feedback_loop.nps.score ?? '—'}</strong> <span className="text-ink-muted">su {wk.feedback_loop.nps.responses} risposte</span></p></div>
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-2 text-sm">
          <div><p className="font-semibold">Ultimi utenti</p><ul className="mt-1 space-y-1 text-ink-muted">{wk.feedback_loop.latest_user.map((x, i) => <li key={i}>“{x.message}”</li>)}{!wk.feedback_loop.latest_user.length && <li>—</li>}</ul></div>
          <div><p className="font-semibold">Ultimi ristoratori</p><ul className="mt-1 space-y-1 text-ink-muted">{wk.feedback_loop.latest_restaurant.map((x, i) => <li key={i}>“{x.message}” <span>· {x.restaurant}</span></li>)}{!wk.feedback_loop.latest_restaurant.length && <li>—</li>}</ul></div>
        </div>
      </Card>

      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-semibold">Periodo acquisizione:</span>
        {[7, 30, 90].map((d) => <Chip key={d} active={days === d} onClick={() => setDays(d)}>{d} giorni</Chip>)}
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Visite per canale" subtitle="Una visita per sessione, senza identificativi." testId="visits-channel">
          <BarList rows={Object.entries(gr.visits_by_channel).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ label: CHANNEL_LABELS[k as Channel] ?? k, value: v }))} empty="Nessuna visita." />
          <p className="mt-3 text-sm">Iscrizioni: <strong>{gr.signups_total}</strong> · attribuite a un canale: {gr.signups_attributed} <span className="text-ink-muted">(solo con consenso “Statistiche”)</span></p>
          <BarList rows={Object.entries(gr.signups_by_channel).map(([k, v]) => ({ label: CHANNEL_LABELS[k as Channel] ?? k, value: v }))} empty="" />
        </Card>
        <Card title="Campagne (UTM)">
          {gr.campaigns.length ? (
            <Table head={['Sorgente', 'Mezzo', 'Campagna', 'Visite']}>
              {gr.campaigns.map((c, i) => <tr key={i}><td className="py-1.5 pr-3">{c.utm_source ?? '—'}</td><td className="py-1.5 pr-3">{c.utm_medium ?? '—'}</td><td className="py-1.5 pr-3">{c.utm_campaign}</td><td className="py-1.5 pr-3 tabular-nums">{c.visits}</td></tr>)}
            </Table>
          ) : <p className="text-sm text-ink-muted">Nessuna campagna tracciata: usa il generatore di link qui sotto.</p>}
        </Card>
        <Card title="Scansioni QR per tipo">
          <BarList rows={(Object.keys(QR_KIND_LABELS) as QrKind[]).map((k) => ({ label: QR_KIND_LABELS[k], value: gr.qr_by_kind[k] ?? 0 }))} empty="Nessuna scansione." />
        </Card>
        <Card title="Inviti" testId="referrals">
          <p className="mb-2 text-sm font-semibold">Utenti (“Invita un amico”)</p>
          <BarList rows={[{ label: 'Inviti', value: gr.referral_funnel.invited }, { label: 'Iscritti', value: gr.referral_funnel.registered }, { label: 'Qualificati', value: gr.referral_funnel.qualified }, { label: 'Premiati', value: gr.referral_funnel.rewarded }]} empty="Nessun invito nel periodo." />
          <p className="mb-2 mt-4 text-sm font-semibold">Ristoranti che invitano ristoranti</p>
          <BarList rows={[{ label: 'Inviti', value: gr.restaurant_referral_funnel.invited }, { label: 'Qualificati', value: gr.restaurant_referral_funnel.qualified }, { label: 'Premiati', value: gr.restaurant_referral_funnel.rewarded }]} empty="Nessun invito nel periodo." />
          <p className="mt-3 text-sm">Ambassador: {gr.ambassadors.applied} candidature · {gr.ambassadors.approved} approvati</p>
          <Note>Premi AsiaPoints configurabili in Admin → AsiaPoints; premi ristorante (mese Premium, crediti sponsorizzazione, beneficio manuale) in Admin → Inviti.</Note>
        </Card>
      </div>

      <UtmBuilder />
      <Codes codes={gr.codes} onSaved={g.reload} />
      <Experiments rows={gr.experiments} onSaved={g.reload} />
      <Costs gr={gr} onSaved={g.reload} />
    </div>
  );
}

function UtmBuilder() {
  const toast = useToast();
  const [preset, setPreset] = useState('restaurant_qr');
  const [path, setPath] = useState('/taranto');
  const [content, setContent] = useState('');
  const p = UTM_PRESETS[preset]!;
  const url = `${APP.siteUrl}${buildUtmUrl(path || '/', { ...p, content })}`;
  return (
    <Card title="Generatore link UTM" subtitle="Per ogni materiale (volantino, QR partner, bio social, creator) un link tracciato: si vede in “Campagne”." testId="utm-builder">
      <div className="grid gap-3 sm:grid-cols-3">
        <Field label="Uso"><Select value={preset} onChange={(e) => setPreset(e.target.value)}>{Object.entries(UTM_PRESETS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</Select></Field>
        <Field label="Pagina di destinazione"><Input value={path} onChange={(e) => setPath(e.target.value)} placeholder="/taranto" /></Field>
        <Field label="Dettaglio (utm_content)"><Input value={content} onChange={(e) => setContent(e.target.value)} placeholder="es. hotel_centro" /></Field>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-4">
        <QrCode value={url} size={120} />
        <div className="min-w-0 flex-1">
          <p className="break-all rounded-2xl bg-cream/60 p-3 text-sm" data-testid="utm-url">{url}</p>
          <Button size="sm" variant="outline" className="mt-2" onClick={() => void navigator.clipboard.writeText(url).then(() => toast('Link copiato'), () => toast('Copia non riuscita', 'error'))}><Copy className="h-4 w-4" /> Copia link</Button>
        </div>
      </div>
    </Card>
  );
}

function Codes({ codes, onSaved }: { codes: Awaited<ReturnType<typeof api.launch.growth>>['codes']; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ code: '', kind: 'campaign', description: '' });
  const save = async (c: { code: string; kind?: string; description?: string | null; is_active?: boolean }) => {
    try {
      await api.launch.codeUpsert(c);
      setF({ code: '', kind: 'campaign', description: '' });
      onSaved();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <Card title="Codici di acquisizione" subtitle="Es. TARANTO, SUSHI, nome di un partner: usati in URL (?code=TARANTO) o sui materiali. Servono all’attribuzione; nessuno sconto automatico." testId="codes">
      {codes.length > 0 && (
        <ul className="mb-3 divide-y divide-line text-sm">
          {codes.map((c) => (
            <li key={c.code} className="flex flex-wrap items-center justify-between gap-2 py-2">
              <span><strong className="font-mono">{c.code}</strong> <span className="text-ink-muted">· {c.kind}{c.description ? ` · ${c.description}` : ''}</span></span>
              <span className="flex items-center gap-3"><span className="tabular-nums">{c.uses} usi</span>
                <Button size="sm" variant="outline" onClick={() => void save({ code: c.code, is_active: !c.is_active })}>{c.is_active ? 'Disattiva' : 'Attiva'}</Button></span>
            </li>
          ))}
        </ul>
      )}
      <div className="grid gap-3 sm:grid-cols-[160px_160px_1fr_auto] sm:items-end">
        <Field label="Codice"><Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} maxLength={20} /></Field>
        <Field label="Tipo"><Select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>{['campaign', 'restaurant', 'partner', 'creator', 'event'].map((k) => <option key={k}>{k}</option>)}</Select></Field>
        <Field label="Descrizione"><Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
        <Button size="sm" disabled={f.code.length < 3} onClick={() => void save(f)}>Salva</Button>
      </div>
    </Card>
  );
}

function Experiments({ rows, onSaved }: { rows: Awaited<ReturnType<typeof api.launch.growth>>['experiments']; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ key: '', name: '', hypothesis: '', primary_metric: '' });
  const run = async (fn: () => Promise<unknown>) => {
    try {
      await fn();
      onSaved();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <Card title="Esperimenti A/B (leggeri)" subtitle="Al massimo 2 attivi insieme. Esempi: CTA della home, testo prezzi business, CTA di rivendicazione. Esposizioni registrate solo con consenso." testId="experiments">
      {rows.length > 0 && (
        <ul className="mb-3 divide-y divide-line text-sm">
          {rows.map((e) => (
            <li key={e.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
              <span><strong>{e.name}</strong> <span className="font-mono text-xs text-ink-muted">{e.key}</span> · {e.status}
                <span className="block text-xs text-ink-muted">Varianti: {e.variants.map((v) => `${v} (${e.exposures?.[v] ?? 0})`).join(' · ')}{e.primary_metric ? ` · metrica: ${e.primary_metric}` : ''}</span></span>
              <span className="flex gap-2">
                {e.status !== 'running' && <Button size="sm" variant="outline" onClick={() => void run(() => api.launch.experimentSetStatus(e.id, 'running'))}>Avvia</Button>}
                {e.status === 'running' && <Button size="sm" variant="outline" onClick={() => void run(() => api.launch.experimentSetStatus(e.id, 'stopped'))}>Ferma</Button>}
              </span>
            </li>
          ))}
        </ul>
      )}
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Chiave (es. hero_cta)"><Input value={f.key} onChange={(e) => setF({ ...f, key: e.target.value.toLowerCase() })} /></Field>
        <Field label="Nome"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Ipotesi"><Input value={f.hypothesis} onChange={(e) => setF({ ...f, hypothesis: e.target.value })} /></Field>
        <Field label="Metrica principale"><Input value={f.primary_metric} onChange={(e) => setF({ ...f, primary_metric: e.target.value })} placeholder="es. click su Scopri i ristoranti" /></Field>
      </div>
      <Button size="sm" className="mt-3" disabled={f.key.length < 3 || f.name.length < 3} onClick={() => void run(() => api.launch.experimentUpsert(f).then(() => setF({ key: '', name: '', hypothesis: '', primary_metric: '' })))}>Crea esperimento</Button>
      <Note>Esperimento già predisposto nel codice: “hero_cta” sulla landing /taranto (varianti control / variant_b). Senza un esperimento attivo, tutti vedono la versione standard.</Note>
    </Card>
  );
}

function Costs({ gr, onSaved }: { gr: Awaited<ReturnType<typeof api.launch.growth>>; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ audience: 'restaurants' as 'restaurants' | 'users', category: 'print', amount: '', spent_on: new Date().toISOString().slice(0, 10), notes: '' });
  const add = async () => {
    try {
      await api.launch.costAdd({ audience: f.audience, category: f.category, channel: null, amount_cents: Math.round(Number(f.amount.replace(',', '.')) * 100), spent_on: f.spent_on, notes: f.notes || null });
      setF({ ...f, amount: '', notes: '' });
      onSaved();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const reason = (r: string | null) => (r === 'no_costs' ? 'nessun costo registrato' : r === 'too_few_conversions' ? `meno di ${gr.cac.min_conversions} conversioni nel periodo` : '');
  return (
    <Card title="Costi di acquisizione e CAC" subtitle="Il CAC si calcola solo con costi registrati e abbastanza conversioni: nessun numero inventato." testId="cac">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Costi ristoranti" value={euro(gr.costs.restaurants_cents)} />
        <Stat label="CAC ristorante" value={gr.cac.restaurant_cents != null ? euro(gr.cac.restaurant_cents) : '—'} hint={gr.cac.restaurant_cents == null ? `Non calcolabile: ${reason(gr.cac.restaurant_reason)}` : `${gr.cac.restaurant_conversions} nuovi paganti`} testId="cac-restaurant" />
        <Stat label="Costi utenti" value={euro(gr.costs.users_cents)} />
        <Stat label="CAC utente" value={gr.cac.user_cents != null ? euro(gr.cac.user_cents) : '—'} hint={gr.cac.user_cents == null ? `Non calcolabile: ${reason(gr.cac.user_reason)}` : `${gr.cac.user_conversions} nuovi utenti`} />
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-5 sm:items-end">
        <Field label="Per"><Select value={f.audience} onChange={(e) => setF({ ...f, audience: e.target.value as 'restaurants' | 'users' })}><option value="restaurants">Ristoranti</option><option value="users">Utenti</option></Select></Field>
        <Field label="Categoria"><Select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{['sales', 'marketing', 'promo', 'print', 'events', 'tools', 'other'].map((c) => <option key={c}>{c}</option>)}</Select></Field>
        <Field label="Importo (€)"><Input inputMode="decimal" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} /></Field>
        <Field label="Data"><Input type="date" value={f.spent_on} onChange={(e) => setF({ ...f, spent_on: e.target.value })} /></Field>
        <Button size="sm" disabled={!(Number(f.amount.replace(',', '.')) > 0)} onClick={() => void add()}>Aggiungi costo</Button>
      </div>
      {gr.costs.rows.length > 0 && (
        <ul className="mt-3 divide-y divide-line text-sm">{gr.costs.rows.map((c) => (
          <li key={c.id} className="flex justify-between gap-2 py-1.5"><span>{fmtDate(c.spent_on)} · {c.audience} · {c.category}{c.notes ? ` · ${c.notes}` : ''}</span>
            <span className="flex items-center gap-2 tabular-nums">{euro(c.amount_cents)}<Button size="sm" variant="ghost" onClick={() => void api.launch.costDelete(c.id).then(onSaved)}>Elimina</Button></span></li>
        ))}</ul>
      )}
      <p className="mt-4 text-sm font-semibold">Ricavi reali per ristorante (base per un futuro LTV)</p>
      {gr.revenue_per_restaurant.length ? (
        <ul className="mt-1 divide-y divide-line text-sm">{gr.revenue_per_restaurant.map((r) => (
          <li key={r.id} className="flex justify-between gap-2 py-1.5"><span>{r.name}</span><span className="tabular-nums">{euro(r.total_cents)} <span className="text-ink-muted">(abbonamenti {euro(r.subscription_cents)} · commissioni {euro(r.order_fees_cents)})</span></span></li>
        ))}</ul>
      ) : <p className="text-sm text-ink-muted">Ancora nessun ricavo registrato.</p>}
      <Note>Nessun valore economico viene attribuito ai singoli utenti.</Note>
    </Card>
  );
}

