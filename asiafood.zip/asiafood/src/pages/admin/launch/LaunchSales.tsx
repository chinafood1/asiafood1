// Vendite: dashboard giornaliera, First 50, CRM (ristoranti, creator, partner locali, stampa) con scheda lead
import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { CheckCircle2, Copy, Instagram, Mail, MessageCircle, Phone, Plus, RefreshCw, Store } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Chip } from '@/components/ui/Badge';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { APP } from '@/config/app';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { emailTemplate, instagramDm, mailtoLink, OBJECTIONS, phoneScript, visitScript, whatsappLink, whatsappMessage, type OutreachContext } from '@/lib/outreach';
import { api } from '@/services';
import {
  ACTIVITY_LABELS, CLOSED_STATUSES, COMPETITOR_LABELS, KIND_CATEGORIES, LEAD_CATEGORY_LABELS, LEAD_KIND_LABELS, LEAD_STATUS_LABELS, OTHER_PIPELINE,
  OUTCOME_LABELS, RESTAURANT_PIPELINE, type ActivityOutcome, type ActivityType, type CrmLeadDetail, type LeadKind, type LeadStatus,
} from '@/types/launch';
import { Card, DemoNotice, fmtDate, fmtDateTime, LAUNCH_BASE, n, Note, Segment, Stat, Table } from './shared';

type View = 'daily' | 'first50' | 'crm';
export default function LaunchSales({ view }: { view: View }) {
  const { id } = useParams();
  const nav = useNavigate();
  const [open, setOpen] = useState<string | null>(null);
  const [bump, setBump] = useState(0);
  useEffect(() => setOpen(id ?? null), [id]);
  const close = () => {
    setOpen(null);
    setBump((b) => b + 1);
    if (id) nav(`${LAUNCH_BASE}/crm`, { replace: true });
  };
  return (
    <>
      {view === 'daily' && <Daily onOpen={setOpen} bump={bump} />}
      {view === 'first50' && <First50 onOpen={setOpen} bump={bump} />}
      {view === 'crm' && <Crm onOpen={setOpen} bump={bump} />}
      <Sheet open={!!open} onClose={close} title="Lead">
        {open && <LeadDetail id={open} onChanged={() => setBump((b) => b + 1)} />}
      </Sheet>
    </>
  );
}

// ─── Dashboard giornaliera ───────────────────────────────────
function Daily({ onOpen, bump }: { onOpen: (id: string) => void; bump: number }) {
  const toast = useToast();
  const d = useAsync(() => api.launch.daily('taranto'), [bump]);
  if (d.loading && !d.data) return <PageLoader />;
  if (d.error || !d.data) return <Alert tone="error">{friendlyError(d.error)}</Alert>;
  const b = d.data;
  const done = async (id: string) => {
    try {
      await api.launch.crmTaskSetStatus(id, 'done');
      d.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const T: [keyof typeof b.targets, string][] = [['research', 'Lead ricercati'], ['contacts', 'Contatti'], ['demos', 'Demo'], ['claims', 'Rivendicazioni'], ['trials', 'Prove attivate']];
  return (
    <div className="space-y-5" data-testid="launch-daily">
      <Card title={`Obiettivi di oggi · ${new Date(b.day).toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' })}`} subtitle="Target operativi configurabili: servono a organizzare la giornata, non sono una promessa.">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          {T.map(([k, l]) => <Stat key={k} label={l} value={`${n(b.actual[k])} / ${n(b.targets[k])}`} tone={b.actual[k] >= b.targets[k] ? 'ok' : undefined} testId={`daily-${k}`} />)}
        </div>
      </Card>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card title={`Lead da chiamare oggi (${b.due_leads.length})`} testId="due-leads">
          {b.due_leads.length ? (
            <ul className="divide-y divide-line">
              {b.due_leads.map((l) => (
                <li key={l.id}>
                  <button type="button" onClick={() => onOpen(l.id)} className="flex w-full items-start justify-between gap-3 py-2.5 text-left hover:bg-cream/50">
                    <span><strong>{l.name}</strong> <span className="text-sm text-ink-muted">{l.city_name ?? ''} · {LEAD_STATUS_LABELS[l.status]}</span>
                      <span className="block text-sm">{l.next_action ?? 'Prossima azione'}</span></span>
                    <span className={cn('shrink-0 text-xs', l.next_action_at && Date.parse(l.next_action_at) < Date.now() ? 'font-semibold text-coral-700' : 'text-ink-muted')}>{fmtDateTime(l.next_action_at)}</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">Nessuna azione in scadenza. Parti dalla lista <Link to={`${LAUNCH_BASE}/first50`} className="font-semibold text-coral-700">First 50</Link>.</p>}
        </Card>
        <Card title={`Follow-up senza prossima azione (${b.follow_ups.length})`} subtitle="Contattati da oltre 3 giorni, senza un passo successivo pianificato.">
          {b.follow_ups.length ? (
            <ul className="divide-y divide-line text-sm">
              {b.follow_ups.map((l) => (
                <li key={l.id} className="flex items-center justify-between gap-3 py-2">
                  <button type="button" className="text-left font-semibold hover:underline" onClick={() => onOpen(l.id)}>{l.name}</button>
                  <span className="text-ink-muted">{LEAD_STATUS_LABELS[l.status]} · {fmtDate(l.last_contact_at)}</span>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">Tutti i lead contattati hanno una prossima azione.</p>}
        </Card>
        <Card title={`Rivendicazioni in attesa (${b.claims_pending.length})`} testId="daily-claims">
          {b.claims_pending.length ? (
            <ul className="divide-y divide-line text-sm">
              {b.claims_pending.map((c) => (
                <li key={c.id} className="flex items-center justify-between gap-3 py-2">
                  <Link to={`/admin/claims/${c.id}`} className="font-semibold hover:underline">{c.restaurant_name}</Link>
                  <span className={cn(c.overdue ? 'font-semibold text-coral-700' : 'text-ink-muted')}>{c.age_hours} h{c.overdue ? ' · oltre SLA' : ''}</span>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">Nessuna rivendicazione in attesa.</p>}
        </Card>
        <Card title={`Piani in scadenza entro 7 giorni (${b.trials_expiring.length})`}>
          {b.trials_expiring.length ? (
            <ul className="divide-y divide-line text-sm">
              {b.trials_expiring.map((t) => (
                <li key={t.restaurant_id + t.ends_at} className="flex items-center justify-between gap-3 py-2">
                  <span><strong>{t.name}</strong> · {t.plan_code}{t.founding ? ' · Partner Fondatore' : ''}</span><span className="text-ink-muted">{fmtDate(t.ends_at)}</span>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">Nessun piano in scadenza.</p>}
          {b.new_paying.length > 0 && <p className="mt-3 text-sm"><CheckCircle2 className="mr-1 inline h-4 w-4 text-emerald-700" aria-hidden />Nuovi paganti (7 gg): {b.new_paying.map((x) => x.name).join(', ')}</p>}
        </Card>
        <Card title={`Attività (${b.tasks.length})`} className="lg:col-span-2" testId="daily-tasks">
          {b.tasks.length ? (
            <ul className="divide-y divide-line text-sm">
              {b.tasks.map((t) => (
                <li key={t.id} className="flex items-center justify-between gap-3 py-2">
                  <span>{t.title}<span className="block text-xs text-ink-muted">{t.source !== 'manual' ? 'Generata automaticamente · ' : ''}{t.due_at ? `entro ${fmtDate(t.due_at)}` : 'senza scadenza'}</span></span>
                  <Button size="sm" variant="outline" onClick={() => void done(t.id)}>Fatto</Button>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">Nessuna attività aperta.</p>}
        </Card>
      </div>
    </div>
  );
}

// ─── First 50 ────────────────────────────────────────────────
function First50({ onOpen, bump }: { onOpen: (id: string) => void; bump: number }) {
  const toast = useToast();
  const f = useAsync(() => api.launch.firstN('taranto'), [bump]);
  const openFor = async (restaurantId: string, leadId: string | null) => {
    try {
      onOpen(leadId ?? (await api.launch.crmUpsertLead({ restaurant_id: restaurantId })));
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  if (f.loading && !f.data) return <PageLoader />;
  if (f.error || !f.data) return <Alert tone="error">{friendlyError(f.error)}</Alert>;
  return (
    <div className="space-y-4" data-testid="launch-first50">
      <DemoNotice show={f.data.include_demo} />
      <Card title={`First ${f.data.n} Taranto`} subtitle="Ristoranti prioritari per l’outreach. Ordine: segmento commerciale (A → C), punteggio di priorità, completezza. Esclusi paganti, chiusi e chi ha chiesto di non essere ricontattato.">
        {f.data.rows.length ? (
          <Table head={['#', 'Seg.', 'Attività', 'Comune', 'Contatti', 'Rivendicazione', 'Stato lead', 'Assegnato', 'Prossima azione', 'Ultimo contatto', 'Piano potenziale']} testId="first50-table">
            {f.data.rows.map((r) => (
              <tr key={r.id} className="cursor-pointer hover:bg-cream/50" onClick={() => void openFor(r.id, r.lead_id)} data-testid="first50-row">
                <td className="py-2 pr-3 tabular-nums">{r.rank}</td>
                <td className="py-2 pr-3"><Segment s={r.segment} /></td>
                <td className="py-2 pr-3 font-semibold">{r.name}<span className="block text-xs font-normal text-ink-muted">{r.is_ayce ? 'AYCE · ' : ''}{r.has_delivery ? 'Asporto/consegna · ' : ''}completezza {r.completion}%</span></td>
                <td className="py-2 pr-3">{r.city_name}</td>
                <td className="py-2 pr-3"><span className="flex gap-1.5 text-ink-muted">{(r.phone || r.whatsapp) && <Phone className="h-4 w-4" aria-label="Telefono" />}{r.email && <Mail className="h-4 w-4" aria-label="Email" />}{r.instagram && <Instagram className="h-4 w-4" aria-label="Instagram" />}{!r.phone && !r.whatsapp && !r.email && !r.instagram && '—'}</span></td>
                <td className="py-2 pr-3">{r.claimed ? 'Rivendicato' : r.claim_status ? `Richiesta: ${r.claim_status}` : 'Non rivendicato'}</td>
                <td className="py-2 pr-3">{r.lead_status ? LEAD_STATUS_LABELS[r.lead_status] : 'Nessun lead'}</td>
                <td className="py-2 pr-3">{r.assigned_name ?? '—'}</td>
                <td className="py-2 pr-3">{r.next_action ?? '—'}{r.next_action_at && <span className="block text-xs text-ink-muted">{fmtDateTime(r.next_action_at)}</span>}</td>
                <td className="py-2 pr-3">{fmtDate(r.last_contact_at)}</td>
                <td className="py-2 pr-3">{r.potential_plan ?? '—'}</td>
              </tr>
            ))}
          </Table>
        ) : <EmptyState title="Nessun ristorante da contattare" text="Importa i locali di Taranto e provincia (Admin → Importa) per popolare la lista." />}
        <Note>Il segmento è una priorità commerciale interna (AYCE, consegna, menu, social, più sedi, zona ad alta domanda). Non è un giudizio sulla qualità del ristorante e non è mai mostrato al pubblico.</Note>
      </Card>
    </div>
  );
}

// ─── CRM ─────────────────────────────────────────────────────
function Crm({ onOpen, bump }: { onOpen: (id: string) => void; bump: number }) {
  const toast = useToast();
  const [kind, setKind] = useState<LeadKind>('restaurant');
  const [status, setStatus] = useState<string>('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(0);
  const [creating, setCreating] = useState(false);
  const list = useAsync(() => api.launch.crmLeads('taranto', kind, status || null, q || null, 50, page * 50), [kind, status, q, page, bump]);
  const sync = async () => {
    try {
      const k = await api.launch.crmSyncRestaurantLeads('taranto');
      toast(k ? `${k} lead creati dai ristoranti` : 'Tutti i ristoranti hanno già un lead');
      list.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const pipeline = kind === 'restaurant' ? RESTAURANT_PIPELINE : OTHER_PIPELINE;
  return (
    <div className="space-y-4" data-testid="launch-crm">
      <div className="flex flex-wrap gap-2">
        {(Object.keys(LEAD_KIND_LABELS) as LeadKind[]).map((k) => <Chip key={k} active={kind === k} onClick={() => { setKind(k); setStatus(''); setPage(0); }}>{LEAD_KIND_LABELS[k]}</Chip>)}
      </div>
      <Card title={LEAD_KIND_LABELS[kind]} action={
        <div className="flex flex-wrap gap-2">
          {kind === 'restaurant' && <Button size="sm" variant="outline" onClick={() => void sync()} data-testid="crm-sync"><RefreshCw className="h-4 w-4" /> Crea lead dai ristoranti</Button>}
          <Button size="sm" onClick={() => setCreating(true)} data-testid="crm-new"><Plus className="h-4 w-4" /> Nuovo lead</Button>
        </div>
      }>
        <div className="grid gap-3 sm:grid-cols-[1fr_220px]">
          <Input placeholder="Cerca per nome o referente" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} aria-label="Cerca lead" />
          <Select value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }} aria-label="Filtra per stato">
            <option value="">Tutti gli stati</option>
            <option value="open">Aperti</option>
            <option value="due">Da fare oggi</option>
            {[...pipeline, ...CLOSED_STATUSES].map((s) => <option key={s} value={s}>{LEAD_STATUS_LABELS[s]}</option>)}
          </Select>
        </div>
        <div className="mt-4">
          {list.loading && !list.data ? <PageLoader /> : list.error ? <Alert tone="error">{friendlyError(list.error)}</Alert> : list.data && list.data.rows.length ? (
            <>
              <Table head={['Nome', 'Comune', 'Stato', 'Prossima azione', 'Ultimo contatto', 'Assegnato', 'Task']} testId="crm-table">
                {list.data.rows.map((l) => (
                  <tr key={l.id} className="cursor-pointer hover:bg-cream/50" onClick={() => onOpen(l.id)} data-testid="crm-row">
                    <td className="py-2 pr-3 font-semibold">{l.name}{l.category && <span className="block text-xs font-normal text-ink-muted">{LEAD_CATEGORY_LABELS[l.category] ?? l.category}</span>}</td>
                    <td className="py-2 pr-3">{l.city_name ?? '—'}</td>
                    <td className="py-2 pr-3">{LEAD_STATUS_LABELS[l.status]}</td>
                    <td className="py-2 pr-3">{l.next_action ?? '—'}{l.next_action_at && <span className="block text-xs text-ink-muted">{fmtDateTime(l.next_action_at)}</span>}</td>
                    <td className="py-2 pr-3">{fmtDate(l.last_contact_at)}</td>
                    <td className="py-2 pr-3">{l.assigned_name ?? '—'}</td>
                    <td className="py-2 pr-3 tabular-nums">{l.open_tasks ?? 0}</td>
                  </tr>
                ))}
              </Table>
              <div className="mt-3 flex items-center justify-between text-sm">
                <span className="text-ink-muted">{n(list.data.total)} lead</span>
                <span className="flex gap-2">
                  <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Indietro</Button>
                  <Button size="sm" variant="outline" disabled={(page + 1) * 50 >= list.data.total} onClick={() => setPage((p) => p + 1)}>Avanti</Button>
                </span>
              </div>
            </>
          ) : <EmptyState title="Nessun lead" text={kind === 'restaurant' ? 'Usa “Crea lead dai ristoranti” per partire dai locali già censiti.' : 'Aggiungi il primo contatto con “Nuovo lead”.'} />}
        </div>
        {kind === 'creator' && <Note>Non valutare i creator solo dai follower: conta la pertinenza locale. Ogni collaborazione va tracciata e, se c’è un corrispettivo, dichiarata (#adv).</Note>}
        {kind === 'press' && <Note>Nessun comunicato viene inviato automaticamente: bozza in Marketing → Contenuti, invio manuale.</Note>}
      </Card>
      <Sheet open={creating} onClose={() => setCreating(false)} title="Nuovo lead">
        <NewLead kind={kind} onDone={(id) => { setCreating(false); list.reload(); onOpen(id); }} />
      </Sheet>
    </div>
  );
}

function NewLead({ kind, onDone }: { kind: LeadKind; onDone: (id: string) => void }) {
  const toast = useToast();
  const [f, setF] = useState({ name: '', category: KIND_CATEGORIES[kind][0] ?? '', contact_name: '', email: '', phone: '', instagram: '', tiktok: '', followers: '' });
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const save = async () => {
    setBusy(true);
    try {
      onDone(await api.launch.crmUpsertLead({ kind, name: f.name, category: f.category || null, contact_name: f.contact_name || null, email: f.email || null,
        phone: f.phone || null, instagram: f.instagram || null, tiktok: f.tiktok || null, followers: f.followers ? Number(f.followers) : null }));
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="space-y-3" data-testid="new-lead-form">
      {kind === 'restaurant' && <Alert>Per un ristorante già censito apri il lead dalla lista First 50 o con “Crea lead dai ristoranti”. Qui puoi annotare un locale non ancora in database: poi censiscilo con fonte verificabile.</Alert>}
      <Field label="Nome"><Input value={f.name} onChange={set('name')} data-testid="lead-name" /></Field>
      {KIND_CATEGORIES[kind].length > 0 && (
        <Field label="Categoria"><Select value={f.category} onChange={set('category')}>{KIND_CATEGORIES[kind].map((c) => <option key={c} value={c}>{LEAD_CATEGORY_LABELS[c]}</option>)}</Select></Field>
      )}
      <Field label="Referente (solo se ha dato il consenso a essere contattato)"><Input value={f.contact_name} onChange={set('contact_name')} /></Field>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Email di lavoro"><Input type="email" value={f.email} onChange={set('email')} /></Field>
        <Field label="Telefono di lavoro"><Input value={f.phone} onChange={set('phone')} /></Field>
        <Field label="Instagram"><Input value={f.instagram} onChange={set('instagram')} /></Field>
        {kind === 'creator' && <Field label="TikTok"><Input value={f.tiktok} onChange={set('tiktok')} /></Field>}
        {kind === 'creator' && <Field label="Follower (facoltativo)"><Input inputMode="numeric" value={f.followers} onChange={set('followers')} /></Field>}
      </div>
      <Button disabled={busy || f.name.trim().length < 2} onClick={() => void save()} data-testid="lead-save">Crea lead</Button>
    </div>
  );
}

// ─── Scheda lead ─────────────────────────────────────────────
function LeadDetail({ id, onChanged }: { id: string; onChanged: () => void }) {
  const toast = useToast();
  const d = useAsync(() => api.launch.crmLead(id), [id]);
  const staff = useAsync(() => api.listProfiles().then((ps) => ps.filter((p) => p.role === 'admin')), []);
  const founding = useAsync(() => api.launch.foundingList('taranto').catch(() => null), []);
  if (d.loading && !d.data) return <PageLoader />;
  if (d.error || !d.data) return <Alert tone="error">{friendlyError(d.error)}</Alert>;
  const reload = () => {
    d.reload();
    onChanged();
  };
  return (
    <div className="space-y-5" data-testid="lead-detail">
      <LeadHeader d={d.data} />
      <LeadForm d={d.data} staff={staff.data ?? []} onSaved={reload} />
      <ActivityForm d={d.data} onSaved={reload} />
      {d.data.lead.kind === 'restaurant' && d.data.lead.contact_allowed && (
        <Outreach d={d.data} founding={founding.data ?? null} onLogged={reload} />
      )}
      {d.data.restaurant && <FoundingBox d={d.data} program={founding.data ?? null} onChanged={() => { reload(); founding.reload(); }} toast={toast} />}
      <section>
        <h3 className="font-bold">Storico</h3>
        {d.data.activities.length ? (
          <ol className="mt-2 space-y-2 text-sm" data-testid="lead-activities">
            {d.data.activities.map((a) => (
              <li key={a.id} className="rounded-2xl bg-cream/50 px-3 py-2">
                <p><strong>{ACTIVITY_LABELS[a.type]}</strong>{a.outcome && ` · ${OUTCOME_LABELS[a.outcome]}`} <span className="text-ink-muted">· {fmtDateTime(a.created_at)}{a.by_name ? ` · ${a.by_name}` : ''}</span></p>
                {a.notes && <p className="mt-0.5 whitespace-pre-line">{a.notes}</p>}
                {a.disclosure_required && <p className="mt-0.5 text-xs text-amber-900">Collaborazione: trasparenza obbligatoria (#adv) se c’è un corrispettivo.</p>}
              </li>
            ))}
          </ol>
        ) : <p className="mt-1 text-sm text-ink-muted">Ancora nessuna attività.</p>}
      </section>
    </div>
  );
}

function LeadHeader({ d }: { d: CrmLeadDetail }) {
  const r = d.restaurant;
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{LEAD_KIND_LABELS[d.lead.kind]}{d.lead.city_name ? ` · ${d.lead.city_name}` : ''}</p>
      <h2 className="text-xl font-extrabold">{d.lead.name}</h2>
      {r && (
        <div className="mt-2 space-y-1 text-sm">
          <p><Store className="mr-1 inline h-4 w-4" aria-hidden />{r.is_active ? <Link to={`/ristorante/${r.slug}`} className="font-semibold text-coral-700 hover:underline">Scheda pubblica</Link> : 'Scheda in bozza'}
            {' · '}completezza {r.completion.score}% · {r.claimed ? 'rivendicato' : r.claim_status ? `rivendicazione ${r.claim_status}` : 'non rivendicato'} · piano {r.plan}</p>
          <p className="text-ink-muted">{[r.phone, r.whatsapp && `WhatsApp ${r.whatsapp}`, r.email, r.instagram, r.website].filter(Boolean).join(' · ') || 'Nessun contatto pubblico'}</p>
          {r.completion.missing.length > 0 && <p className="text-ink-muted">Mancano: {r.completion.missing.join(', ')}</p>}
        </div>
      )}
      {!d.lead.contact_allowed && <Alert tone="error">Ha chiesto di non essere ricontattato: nessuna attività di outreach (nemmeno win-back).</Alert>}
    </div>
  );
}

function LeadForm({ d, staff, onSaved }: { d: CrmLeadDetail; staff: { id: string; full_name?: string | null; email?: string | null }[]; onSaved: () => void }) {
  const toast = useToast();
  const l = d.lead;
  const [f, setF] = useState({
    status: l.status as LeadStatus, segment_override: l.segment_override ?? '', assigned_to: l.assigned_to ?? '', next_action: l.next_action ?? '',
    next_action_at: l.next_action_at ? l.next_action_at.slice(0, 16) : '', potential_plan: l.potential_plan ?? '', competitor_tools: l.competitor_tools,
    competitor_source: l.competitor_source ?? '', contact_allowed: l.contact_allowed, notes: l.notes ?? '', lost_reason: l.lost_reason ?? '',
  });
  const [busy, setBusy] = useState(false);
  const pipeline = l.kind === 'restaurant' ? RESTAURANT_PIPELINE : OTHER_PIPELINE;
  const save = async () => {
    setBusy(true);
    try {
      await api.launch.crmUpsertLead({ id: l.id, status: f.status, segment_override: (f.segment_override || null) as 'A' | null, assigned_to: f.assigned_to || null,
        next_action: f.next_action || null, next_action_at: f.next_action_at ? new Date(f.next_action_at).toISOString() : null, potential_plan: f.potential_plan || null,
        competitor_tools: f.competitor_tools, competitor_source: (f.competitor_source || null) as 'public' | null, contact_allowed: f.contact_allowed,
        notes: f.notes || null, lost_reason: f.lost_reason || null });
      toast('Lead aggiornato');
      onSaved();
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="space-y-3 rounded-3xl border border-line p-4" data-testid="lead-form">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Stato"><Select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as LeadStatus })} data-testid="lead-status">
          {[...pipeline, ...CLOSED_STATUSES].map((s) => <option key={s} value={s}>{LEAD_STATUS_LABELS[s]}</option>)}</Select></Field>
        <Field label="Assegnato a"><Select value={f.assigned_to} onChange={(e) => setF({ ...f, assigned_to: e.target.value })}>
          <option value="">—</option>{staff.map((p) => <option key={p.id} value={p.id}>{p.full_name || p.email}</option>)}</Select></Field>
        <Field label="Prossima azione"><Input value={f.next_action} onChange={(e) => setF({ ...f, next_action: e.target.value })} placeholder="Es. Richiamare dopo le 15" data-testid="lead-next-action" /></Field>
        <Field label="Quando"><Input type="datetime-local" value={f.next_action_at} onChange={(e) => setF({ ...f, next_action_at: e.target.value })} /></Field>
        {l.kind === 'restaurant' && (
          <>
            <Field label="Segmento (override interno)"><Select value={f.segment_override} onChange={(e) => setF({ ...f, segment_override: e.target.value })}>
              <option value="">Automatico</option><option value="A">A · alta priorità</option><option value="B">B · buona opportunità</option><option value="C">C · più avanti</option></Select></Field>
            <Field label="Piano potenziale"><Select value={f.potential_plan} onChange={(e) => setF({ ...f, potential_plan: e.target.value })}>
              <option value="">—</option><option value="business">Business</option><option value="premium">Premium</option><option value="top">Top</option></Select></Field>
          </>
        )}
      </div>
      {l.kind === 'restaurant' && (
        <fieldset>
          <legend className="text-sm font-semibold">Strumenti già usati (solo se pubblici o dichiarati dal ristoratore)</legend>
          <div className="mt-2 flex flex-wrap gap-2">
            {Object.entries(COMPETITOR_LABELS).map(([k, v]) => (
              <Chip key={k} active={f.competitor_tools.includes(k)} onClick={() => setF({ ...f, competitor_tools: f.competitor_tools.includes(k) ? f.competitor_tools.filter((x) => x !== k) : [...f.competitor_tools, k] })}>{v}</Chip>
            ))}
          </div>
          {f.competitor_tools.length > 0 && (
            <Select className="mt-2" value={f.competitor_source} onChange={(e) => setF({ ...f, competitor_source: e.target.value })} aria-label="Fonte dell'informazione">
              <option value="">Fonte dell’informazione…</option><option value="public">Comunicato pubblicamente</option><option value="declared">Dichiarato dal ristoratore</option>
            </Select>
          )}
        </fieldset>
      )}
      <Field label="Note"><Textarea rows={3} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
      {['lost', 'not_interested'].includes(f.status) && <Field label="Motivo"><Input value={f.lost_reason} onChange={(e) => setF({ ...f, lost_reason: e.target.value })} /></Field>}
      <Toggle checked={f.contact_allowed} onChange={(v) => setF({ ...f, contact_allowed: v })} label="Può essere ricontattato" description="Disattiva se ha chiesto di non essere contattato: blocca ogni outreach, anche futuro." />
      <Button disabled={busy} onClick={() => void save()} data-testid="lead-update">Salva</Button>
    </section>
  );
}

function ActivityForm({ d, onSaved }: { d: CrmLeadDetail; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState<{ type: ActivityType; outcome: string; notes: string; next_action: string; next_action_at: string }>({ type: 'call', outcome: '', notes: '', next_action: '', next_action_at: '' });
  const [busy, setBusy] = useState(false);
  const log = async () => {
    setBusy(true);
    try {
      await api.launch.crmLogActivity({ lead_id: d.lead.id, type: f.type, outcome: (f.outcome || null) as ActivityOutcome | null, notes: f.notes || null,
        ...(f.next_action || f.next_action_at ? { next_action: f.next_action || null, next_action_at: f.next_action_at ? new Date(f.next_action_at).toISOString() : null } : {}) });
      toast('Attività registrata');
      setF({ type: 'call', outcome: '', notes: '', next_action: '', next_action_at: '' });
      onSaved();
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const types: ActivityType[] = d.lead.contact_allowed ? ['call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'demo', 'claim_link_sent', 'follow_up', 'collaboration', 'research', 'note'] : ['note', 'research'];
  return (
    <section className="space-y-3 rounded-3xl border border-line p-4" data-testid="activity-form">
      <h3 className="font-bold">Registra attività</h3>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Tipo"><Select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value as ActivityType })} data-testid="activity-type">
          {types.map((t) => <option key={t} value={t}>{ACTIVITY_LABELS[t]}</option>)}</Select></Field>
        <Field label="Esito"><Select value={f.outcome} onChange={(e) => setF({ ...f, outcome: e.target.value })} data-testid="activity-outcome">
          <option value="">—</option>{Object.entries(OUTCOME_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
        <Field label="Prossima azione (facoltativa)"><Input value={f.next_action} onChange={(e) => setF({ ...f, next_action: e.target.value })} /></Field>
        <Field label="Quando"><Input type="datetime-local" value={f.next_action_at} onChange={(e) => setF({ ...f, next_action_at: e.target.value })} /></Field>
      </div>
      <Field label="Note"><Textarea rows={2} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} data-testid="activity-notes" /></Field>
      <Button size="sm" disabled={busy} onClick={() => void log()} data-testid="activity-save">Registra</Button>
    </section>
  );
}

function Outreach({ d, founding, onLogged }: { d: CrmLeadDetail; founding: Awaited<ReturnType<typeof api.launch.foundingList>> | null; onLogged: () => void }) {
  const toast = useToast();
  const [tab, setTab] = useState<'whatsapp' | 'email' | 'instagram' | 'phone' | 'visit' | 'objections'>('whatsapp');
  const r = d.restaurant;
  const ctx: OutreachContext = useMemo(() => ({
    business: d.lead.name, city: d.lead.city_name, appName: APP.name,
    profileUrl: r?.is_active ? `${APP.siteUrl}/ristorante/${r.slug}?utm_source=outreach&utm_medium=${tab}&utm_campaign=founding_restaurants` : null,
    claimUrl: r?.is_active && !r.claimed ? `${APP.siteUrl}/ristorante/${r.slug}/rivendica?utm_source=outreach&utm_medium=${tab}&utm_campaign=founding_restaurants` : null,
    founding: founding ? { enabled: founding.enabled, name: founding.name, plan: founding.plan, days: founding.days, slotsLeft: founding.limit - founding.used } : null,
  }), [d, r, tab, founding]);
  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast('Testo copiato: invialo tu e registra l’attività');
    } catch {
      toast('Copia non riuscita', 'error');
    }
  };
  const logged = async (type: ActivityType) => {
    try {
      await api.launch.crmLogActivity({ lead_id: d.lead.id, type, notes: 'Messaggio preparato dal template' });
      onLogged();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const wa = whatsappMessage(ctx);
  const em = emailTemplate(ctx);
  const ig = instagramDm(ctx);
  return (
    <section className="space-y-3 rounded-3xl border border-line p-4" data-testid="outreach">
      <h3 className="font-bold">Outreach</h3>
      <div className="flex flex-wrap gap-2">
        {([['whatsapp', 'WhatsApp'], ['email', 'Email'], ['instagram', 'Instagram DM'], ['phone', 'Telefonata'], ['visit', 'Visita'], ['objections', 'Obiezioni']] as const).map(([k, l]) => (
          <Chip key={k} active={tab === k} onClick={() => setTab(k)}>{l}</Chip>
        ))}
      </div>
      {tab === 'whatsapp' && (
        <>
          <pre className="whitespace-pre-wrap [overflow-wrap:anywhere] rounded-2xl bg-cream/60 p-3 font-sans text-sm" data-testid="outreach-text">{wa}</pre>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => void copy(wa)}><Copy className="h-4 w-4" /> Copia</Button>
            <a className="inline-flex h-9 items-center gap-2 rounded-full bg-ink px-4 text-sm font-semibold text-white" href={whatsappLink(r?.whatsapp ?? r?.phone, wa)} target="_blank" rel="noopener noreferrer"
              onClick={() => void logged('whatsapp')}><MessageCircle className="h-4 w-4" /> Apri WhatsApp</a>
          </div>
        </>
      )}
      {tab === 'email' && (
        <>
          <p className="text-sm"><strong>Oggetto:</strong> {em.subject}</p>
          <pre className="whitespace-pre-wrap [overflow-wrap:anywhere] rounded-2xl bg-cream/60 p-3 font-sans text-sm">{em.body}</pre>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => void copy(`${em.subject}\n\n${em.body}`)}><Copy className="h-4 w-4" /> Copia</Button>
            <a className="inline-flex h-9 items-center gap-2 rounded-full bg-ink px-4 text-sm font-semibold text-white" href={mailtoLink(r?.email, em.subject, em.body)} onClick={() => void logged('email')}><Mail className="h-4 w-4" /> Apri email</a>
          </div>
        </>
      )}
      {tab === 'instagram' && (
        <>
          <pre className="whitespace-pre-wrap [overflow-wrap:anywhere] rounded-2xl bg-cream/60 p-3 font-sans text-sm">{ig}</pre>
          <Button size="sm" variant="outline" onClick={() => void copy(ig)}><Copy className="h-4 w-4" /> Copia</Button>
        </>
      )}
      {tab === 'phone' && (
        <ol className="space-y-2 text-sm">{phoneScript(ctx).map((s) => <li key={s.step}><strong>{s.step}.</strong> {s.text}</li>)}</ol>
      )}
      {tab === 'visit' && (
        <ol className="list-decimal space-y-1.5 pl-5 text-sm">{visitScript(ctx).map((s) => <li key={s}>{s}</li>)}</ol>
      )}
      {tab === 'objections' && (
        <dl className="space-y-2 text-sm">{OBJECTIONS.map((o) => <div key={o.q}><dt className="font-semibold">“{o.q}”</dt><dd className="text-ink-muted">{o.a}</dd></div>)}</dl>
      )}
      <Note>Nessun invio automatico: i testi si copiano o si aprono nell’app, e l’invio lo fa una persona. Frasi come “profilo già presente” compaiono solo se la scheda esiste davvero.</Note>
    </section>
  );
}

function FoundingBox({ d, program, onChanged, toast }: { d: CrmLeadDetail; program: Awaited<ReturnType<typeof api.launch.foundingList>> | null; onChanged: () => void; toast: ReturnType<typeof useToast> }) {
  const r = d.restaurant!;
  const [note, setNote] = useState('');
  const [reason, setReason] = useState('');
  const f = r.founding && r.founding.status !== 'revoked' ? r.founding : null;
  const act = async () => {
    try {
      const res = await api.launch.foundingActivate(r.id, note || null);
      toast(`Partner Fondatore n. ${res.number} attivato${res.days ? ` · ${res.plan} per ${res.days} giorni` : ''}`);
      onChanged();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const revoke = async () => {
    try {
      await api.launch.foundingRevoke(r.id, reason);
      toast('Adesione revocata');
      onChanged();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <section className="space-y-2 rounded-3xl border border-line p-4" data-testid="founding-box">
      <h3 className="font-bold">{program?.name ?? 'Partner Fondatore'}</h3>
      {f ? (
        <>
          <p className="text-sm">Partner Fondatore n. <strong>{f.number}</strong> · {f.status === 'active' ? `piano ${f.benefit_plan} fino al ${fmtDate(f.benefit_ends_at)}` : 'beneficio concluso (il badge resta)'}</p>
          <div className="flex flex-wrap gap-2"><Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Motivo della revoca" className="max-w-xs" />
            <Button size="sm" variant="danger" disabled={!reason.trim()} onClick={() => void revoke()}>Revoca adesione</Button></div>
        </>
      ) : !r.claimed ? (
        <p className="text-sm text-ink-muted">Disponibile dopo la rivendicazione approvata: solo i ristoranti che aderiscono davvero ricevono il badge.</p>
      ) : program && !program.enabled ? (
        <p className="text-sm text-ink-muted">Programma disattivato (Piano e obiettivi → impostazioni).</p>
      ) : (
        <>
          <p className="text-sm text-ink-muted">{program ? `Posti usati ${program.used}/${program.limit} · beneficio: piano ${program.plan} per ${program.days} giorni, poi scade senza addebiti.` : ''}</p>
          <div className="flex flex-wrap gap-2"><Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Nota (es. aderito dopo la demo)" className="max-w-xs" />
            <Button size="sm" onClick={() => void act()} disabled={!!program && program.used >= program.limit} data-testid="founding-activate">Attiva Partner Fondatore</Button></div>
        </>
      )}
    </section>
  );
}
