// Operations board "Oggi": ciò che richiede azione adesso (SLA interni, non promessi al pubblico) + incidenti di lancio
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { api } from '@/services';
import type { IncidentSeverity, OpsCount } from '@/types/launch';
import { Card, fmtDateTime, LAUNCH_BASE, n, Note } from './shared';

function Tile({ label, c, to, testId }: { label: string; c: OpsCount | null; to: string; testId?: string }) {
  if (!c) return null;
  return (
    <Link to={to} className={cn('rounded-3xl border p-4 hover:shadow-card', c.overdue ? 'border-coral-200 bg-coral-50' : 'border-line bg-white')} data-testid={testId}>
      <p className="text-xs text-ink-muted">{label}</p>
      <p className="font-display text-2xl font-extrabold tabular-nums">{n(c.count)}</p>
      {c.overdue ? <p className="text-xs font-semibold text-coral-700">{c.overdue} oltre SLA interno</p> : <p className="text-xs text-ink-muted">nei tempi</p>}
    </Link>
  );
}

const SEV: Record<IncidentSeverity, string> = { low: 'Bassa', medium: 'Media', high: 'Alta', critical: 'Critica' };

export default function LaunchToday() {
  const toast = useToast();
  const o = useAsync(() => api.launch.opsToday(), []);
  const [f, setF] = useState<{ title: string; severity: IncidentSeverity; area: string; description: string }>({ title: '', severity: 'medium', area: 'data', description: '' });
  if (o.loading && !o.data) return <PageLoader />;
  if (o.error || !o.data) return <Alert tone="error">{friendlyError(o.error)}</Alert>;
  const d = o.data;
  const open = async () => {
    try {
      await api.launch.incidentUpsert(f);
      setF({ title: '', severity: 'medium', area: 'data', description: '' });
      toast('Incidente registrato');
      o.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const setStatus = async (id: string, status: 'investigating' | 'mitigated' | 'resolved') => {
    try {
      await api.launch.incidentUpsert({ id, status });
      o.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <div className="space-y-5" data-testid="launch-today">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Tile label="Rivendicazioni da revisionare" c={d.claims_pending} to="/admin/claims" testId="ops-claims" />
        <Tile label="Problemi sugli ordini" c={d.order_issues} to="/admin/orders" />
        <Tile label="Supporto ristoranti" c={d.restaurant_support} to="/admin/support" />
        <Tile label="Supporto clienti" c={d.customer_support} to="/admin/support" />
        <Tile label="Segnalazioni dati errati" c={d.data_reports} to="/admin/reports" />
        <Tile label="Problemi consegne (Rider)" c={d.rider_issues} to="/admin/dispatch" />
        <Tile label="Pagamenti falliti (24 h)" c={{ count: d.payments_failed_24h }} to="/admin/orders" />
        <Tile label="Follow-up commerciali" c={{ count: d.sales_followups }} to={`${LAUNCH_BASE}/daily`} />
      </div>
      <Note>SLA interni: rivendicazioni {d.sla.claim_hours} h · supporto {d.sla.support_hours} h · ordini {d.sla.order_issue_hours} h · segnalazioni dati {d.sla.data_report_hours} h. Obiettivi operativi, non garanzie pubbliche.</Note>
      {d.data_reports.rows.length > 0 && (
        <Card title="Segnalazioni dati errati (priorità)">
          <ul className="divide-y divide-line text-sm">
            {d.data_reports.rows.slice(0, 10).map((r) => (
              <li key={r.id} className="flex justify-between gap-3 py-2"><Link to={`/ristorante/${r.slug}`} className="font-semibold hover:underline">{r.restaurant}</Link><span className="text-ink-muted">{r.type} · {fmtDateTime(r.created_at)}</span></li>
            ))}
          </ul>
        </Card>
      )}
      <Card title="Incidenti di lancio" subtitle={`${d.feedback_new} feedback nuovi da leggere in Piano e obiettivi → Feedback`} testId="incidents">
        {d.incidents.length ? (
          <ul className="space-y-2">
            {d.incidents.map((i) => (
              <li key={i.id} className="rounded-2xl border border-line p-3 text-sm">
                <p><span className={cn('mr-2 rounded-full px-2 py-0.5 text-xs font-bold', i.severity === 'critical' || i.severity === 'high' ? 'bg-coral-50 text-coral-700' : 'bg-cream')}>{SEV[i.severity]}</span>
                  <strong>{i.title}</strong> <span className="text-ink-muted">· {i.area} · {fmtDateTime(i.created_at)} · {i.status}</span></p>
                {i.description && <p className="mt-1 whitespace-pre-line text-ink-muted">{i.description}</p>}
                <div className="mt-2 flex gap-2">
                  {i.status === 'open' && <Button size="sm" variant="outline" onClick={() => void setStatus(i.id, 'investigating')}>In analisi</Button>}
                  <Button size="sm" variant="outline" onClick={() => void setStatus(i.id, 'mitigated')}>Mitigato</Button>
                  <Button size="sm" onClick={() => void setStatus(i.id, 'resolved')}>Risolto</Button>
                </div>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-ink-muted">Nessun incidente aperto.</p>}
        <div className="mt-4 grid gap-3 rounded-2xl bg-cream/50 p-3 sm:grid-cols-3">
          <Field label="Titolo" className="sm:col-span-3"><Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} data-testid="incident-title" /></Field>
          <Field label="Gravità"><Select value={f.severity} onChange={(e) => setF({ ...f, severity: e.target.value as IncidentSeverity })}>{Object.entries(SEV).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
          <Field label="Area"><Select value={f.area} onChange={(e) => setF({ ...f, area: e.target.value })}>
            {['data', 'payments', 'orders', 'delivery', 'auth', 'performance', 'seo', 'support', 'restaurant', 'other'].map((a) => <option key={a} value={a}>{a}</option>)}</Select></Field>
          <Field label="Descrizione" className="sm:col-span-3"><Textarea rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
          <div><Button size="sm" disabled={f.title.trim().length < 3} onClick={() => void open()} data-testid="incident-open">Apri incidente</Button></div>
        </div>
        <Note>Procedura: docs/RUNBOOK.md e docs/SECURITY.md § 8 (incidente di sicurezza). Gli incidenti gravi compaiono come avviso nella panoramica.</Note>
      </Card>
    </div>
  );
}
