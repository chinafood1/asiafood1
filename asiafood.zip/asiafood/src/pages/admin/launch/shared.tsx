// ─────────────────────────────────────────────────────────────
//  Fase 12 · Componenti condivisi del Launch Control Center.
//  Grafici minimi e accessibili: una sola serie (nessuna legenda), un solo colore,
//  valori sempre leggibili come testo (etichetta o tabella), tooltip al passaggio.
// ─────────────────────────────────────────────────────────────
import { useState, type ReactNode } from 'react';
import { AlertTriangle, Info } from 'lucide-react';
import { cn } from '@/lib/format';

export const LAUNCH_BASE = '/admin/launch/taranto';
export const fmtDate = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleDateString('it-IT', { day: '2-digit', month: 'short' }) : '—');
export const fmtDateTime = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleString('it-IT', { dateStyle: 'short', timeStyle: 'short' }) : '—');
export const euro = (cents: number | null | undefined) => (cents == null ? '—' : (cents / 100).toLocaleString('it-IT', { style: 'currency', currency: 'EUR' }));
export const n = (v: number | null | undefined) => (v == null ? '—' : v.toLocaleString('it-IT'));
export const pct = (a: number, b: number) => (b > 0 ? `${Math.round((a * 100) / b)}%` : '—');

export function Stat({ label, value, hint, tone, testId }: { label: string; value: ReactNode; hint?: ReactNode; tone?: 'ok' | 'warn' | 'bad'; testId?: string }) {
  const t = { ok: 'text-emerald-700', warn: 'text-amber-800', bad: 'text-coral-700' };
  return (
    <div className="rounded-3xl border border-line bg-white p-4" data-testid={testId}>
      <p className="text-xs text-ink-muted">{label}</p>
      <p className={cn('mt-1 font-display text-2xl font-extrabold tabular-nums', tone && t[tone])}>{value}</p>
      {hint && <p className="mt-0.5 text-xs text-ink-muted">{hint}</p>}
    </div>
  );
}

export function Card({ title, children, action, subtitle, testId, className }: { title: string; children: ReactNode; action?: ReactNode; subtitle?: ReactNode; testId?: string; className?: string }) {
  return (
    <section className={cn('rounded-3xl border border-line bg-white p-5', className)} data-testid={testId}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold">{title}</h2>
          {subtitle && <p className="mt-0.5 text-sm text-ink-muted">{subtitle}</p>}
        </div>
        {action}
      </div>
      <div className="mt-3">{children}</div>
    </section>
  );
}

/** Barra di avanzamento verso un target operativo (valore sempre scritto accanto). */
export function ProgressBar({ label, value, target, pctValue, testId }: { label: string; value: number; target: number; pctValue: number; testId?: string }) {
  return (
    <div data-testid={testId}>
      <div className="flex items-baseline justify-between gap-3 text-sm">
        <span className="font-semibold">{label}</span>
        <span className="tabular-nums text-ink-muted"><strong className="text-ink">{pctValue}%</strong> · {n(value)} / {n(target)}</span>
      </div>
      <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-cream" role="progressbar" aria-valuenow={pctValue} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
        <div className="h-full rounded-full bg-ink" style={{ width: `${Math.max(pctValue, pctValue > 0 ? 2 : 0)}%` }} />
      </div>
    </div>
  );
}

/** Colonne verticali a serie singola (es. North Star per settimana). Hover: valore; sotto: etichette. */
export function Columns({ data, label, format = n, testId }: { data: { label: string; value: number }[]; label: string; format?: (v: number) => string; testId?: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <figure data-testid={testId}>
      <div className="relative flex h-32 items-end gap-[2px]" role="img" aria-label={`${label}: ${data.map((d) => `${d.label} ${format(d.value)}`).join(', ')}`}>
        {data.map((d, i) => (
          <div key={d.label} className="relative flex h-full flex-1 items-end" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
            <div className={cn('w-full rounded-t-[4px] bg-ink transition-opacity', hover != null && hover !== i && 'opacity-40')} style={{ height: `${(d.value / max) * 100}%`, minHeight: d.value > 0 ? 3 : 1 }} />
            {hover === i && (
              <div className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-1 -translate-x-1/2 whitespace-nowrap rounded-lg bg-ink px-2 py-1 text-xs text-white shadow-lift">
                {d.label}: <strong>{format(d.value)}</strong>
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="mt-1 flex gap-[2px] text-[10px] text-ink-muted">
        {data.map((d) => <span key={d.label} className="flex-1 truncate text-center">{d.label}</span>)}
      </div>
    </figure>
  );
}

/** Funnel / classifica come barre orizzontali con etichetta e valore sempre visibili. */
export function BarList({ rows, testId, empty = 'Nessun dato nel periodo.' }: { rows: { label: string; value: number; hint?: string }[]; testId?: string; empty?: string }) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  if (!rows.length || rows.every((r) => r.value === 0)) return <p className="text-sm text-ink-muted" data-testid={testId}>{empty}</p>;
  return (
    <ul className="space-y-2" data-testid={testId}>
      {rows.map((r) => (
        <li key={r.label} title={`${r.label}: ${n(r.value)}`}>
          <div className="flex justify-between gap-3 text-sm"><span>{r.label}</span><span className="tabular-nums font-semibold">{n(r.value)}{r.hint && <span className="ml-1 font-normal text-ink-muted">{r.hint}</span>}</span></div>
          <div className="mt-1 h-2 rounded-full bg-cream"><div className="h-2 rounded-full bg-ink/80" style={{ width: `${(r.value / max) * 100}%` }} /></div>
        </li>
      ))}
    </ul>
  );
}

export function DemoNotice({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <p className="flex items-start gap-2 rounded-2xl bg-amber-50 px-4 py-3 text-sm text-amber-900" data-testid="demo-notice">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
      I numeri includono i locali DEMO (impostazione “Mostra dati demo” attiva): non sono risultati reali. In produzione i DEMO sono esclusi.
    </p>
  );
}

export function Note({ children }: { children: ReactNode }) {
  return (
    <p className="flex items-start gap-2 text-xs text-ink-muted"><Info className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />{children}</p>
  );
}

/** Tabella semplice e responsiva (scroll orizzontale solo dentro la card). */
export function Table({ head, children, testId }: { head: ReactNode[]; children: ReactNode; testId?: string }) {
  return (
    <div className="-mx-5 overflow-x-auto px-5" tabIndex={0} role="region" aria-label="Tabella scorrevole">
      <table className="w-full min-w-[640px] text-left text-sm" data-testid={testId}>
        <thead className="text-xs uppercase tracking-wide text-ink-muted">
          <tr>{head.map((h, i) => <th key={i} className="border-b border-line py-2 pr-3 font-semibold">{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-line">{children}</tbody>
      </table>
    </div>
  );
}

export function Segment({ s }: { s: 'A' | 'B' | 'C' }) {
  const t = { A: 'bg-ink text-white', B: 'bg-cream text-ink', C: 'border border-line text-ink-muted' };
  return <span className={cn('inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold', t[s])} title={`Segmento ${s} (priorità commerciale interna, non qualità)`}>{s}</span>;
}
