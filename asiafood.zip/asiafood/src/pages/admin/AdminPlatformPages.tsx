// ─────────────────────────────────────────────────────────────
//  Fase 11 · Admin:
//   /admin/system            stato app, errori, webhook, job, email/push/AI, pulizia, DB, Web Vitals,
//                            feature flag e kill switch, privacy (export/cancellazioni), audit, consistenza
//   /admin/support           ticket con filtri (aperti, urgenti, ordini, ristoranti, Rider, fatturazione)
//   /admin/launch-checklist  checklist di lancio (SECURITY…SUPPORT) + Taranto Launch Readiness
//  Nessun segreto mostrato: solo conteggi, stati e nomi.
// ─────────────────────────────────────────────────────────────
import { useEffect, useState, type ReactNode } from 'react';
import { AlertTriangle, CheckCircle2, CircleDashed, Clock, MinusCircle, RefreshCw, XCircle } from 'lucide-react';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import {
  LAUNCH_STATUS_LABEL, SUPPORT_CATEGORY_LABEL, SUPPORT_STATUS_LABEL,
  type AdminSupportTicket, type CheckStatus, type FlagState, type LaunchCheck, type SupportFilter, type SupportPriority, type SupportStatus,
} from '@/types/platform';

const fmt = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleString('it-IT', { dateStyle: 'short', timeStyle: 'short' }) : '—');
const bytes = (n: number | null | undefined) => (n == null ? '—' : n > 1e9 ? `${(n / 1e9).toFixed(1)} GB` : n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.round(n / 1e3)} kB`);

function Stat({ label, value, tone, hint }: { label: string; value: ReactNode; tone?: 'ok' | 'warn' | 'bad'; hint?: string }) {
  const t = { ok: 'text-emerald-700', warn: 'text-amber-700', bad: 'text-coral-700' };
  return (
    <div className="rounded-3xl border border-line bg-white p-4">
      <p className="text-xs text-ink-muted">{label}</p>
      <p className={cn('mt-1 font-display text-2xl font-extrabold tabular-nums', tone && t[tone])}>{value}</p>
      {hint && <p className="mt-0.5 text-xs text-ink-faint">{hint}</p>}
    </div>
  );
}
function Card({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="rounded-3xl border border-line bg-white p-5">
      <div className="flex items-center justify-between gap-3"><h2 className="text-lg font-bold">{title}</h2>{action}</div>
      <div className="mt-3">{children}</div>
    </section>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/system
// ═════════════════════════════════════════════════════════════
type SysTab = 'overview' | 'flags' | 'privacy' | 'audit' | 'data';
export function AdminSystem() {
  useSeo({ title: 'Sistema', noindex: true });
  const [tab, setTab] = useState<SysTab>('overview');
  useEffect(() => api.recordAdminSession(), []);
  return (
    <div data-testid="admin-system">
      <h1 className="text-2xl font-extrabold">Sistema e monitoraggio</h1>
      <p className="mt-1 text-sm text-ink-muted">Stato dell’app, errori, webhook, job, flag operativi, privacy e audit. Nessun segreto è mai mostrato.</p>
      <div className="mt-5 flex flex-wrap gap-2">
        {([['overview', 'Stato'], ['flags', 'Flag e kill switch'], ['privacy', 'Privacy'], ['audit', 'Audit'], ['data', 'Consistenza dati']] as const).map(([k, l]) => (
          <Chip key={k} active={tab === k} onClick={() => setTab(k)}>{l}</Chip>
        ))}
      </div>
      <div className="mt-5">
        {tab === 'overview' && <SystemOverview />}
        {tab === 'flags' && <FlagsPanel />}
        {tab === 'privacy' && <PrivacyPanel />}
        {tab === 'audit' && <AuditPanel />}
        {tab === 'data' && <ConsistencyPanel />}
      </div>
    </div>
  );
}

function SystemOverview() {
  const toast = useToast();
  const s = useAsync(() => api.getSystemStatus(), []);
  if (s.loading && !s.data) return <PageLoader />;
  if (s.error) return <Alert tone="error">{friendlyError(s.error)}</Alert>;
  const d = s.data!;
  const vit = (m: 'LCP' | 'INP' | 'CLS', good: number, unit: string) => {
    const v = d.web_vitals[m];
    if (!v) return { value: '—', hint: 'nessuna misura (serve consenso Statistiche)' };
    return { value: `${m === 'CLS' ? v.p75.toFixed(3) : Math.round(v.p75)}${unit}`, tone: v.p75 <= good ? ('ok' as const) : ('warn' as const), hint: `p75 · ${v.samples} misure (7 gg)` };
  };
  const retry = async (id: string) => {
    try {
      await api.adminRetryJob(id);
      toast('Job rimesso in coda');
      s.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 text-sm text-ink-muted">
        <span>Aggiornato: {fmt(d.generated_at)}</span>
        <Button size="sm" variant="outline" icon={<RefreshCw className="h-4 w-4" />} onClick={s.reload}>Aggiorna</Button>
      </div>
      {d.alerts.length > 0 && (
        <div className="space-y-2" data-testid="system-alerts">
          {d.alerts.map((a) => <Alert key={a.key} tone={a.level === 'critical' ? 'error' : 'info'}><strong>{a.level === 'critical' ? 'Critico' : a.level === 'warning' ? 'Attenzione' : 'Info'}:</strong> {a.message}</Alert>)}
        </div>
      )}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Errori server (10 min)" value={d.errors.last_10min} tone={d.errors.last_10min ? 'warn' : 'ok'} />
        <Stat label="Errori (24 h)" value={d.errors.last_24h} hint={`di cui client: ${d.errors.client_24h}`} />
        <Stat label="Webhook falliti (24 h)" value={d.webhooks.failed_24h} tone={d.webhooks.failed_24h ? 'bad' : 'ok'} hint={`bloccati: ${d.webhooks.stuck}`} />
        <Stat label="Job falliti" value={d.jobs.failed.length} tone={d.jobs.failed.length ? 'bad' : 'ok'} hint={`in esecuzione: ${d.jobs.running}`} />
        <Stat label="Email in coda" value={d.email.pending} hint={`fallite 24 h: ${d.email.failed_24h}`} tone={d.email.failed_24h ? 'warn' : undefined} />
        <Stat label="Push (24 h)" value={d.push.sent_24h} hint={d.push.enabled ? `dispositivi attivi: ${d.push.active_devices}` : 'push disattivate'} />
        <Stat label="AI (ultima ora)" value={d.ai.requests_1h} hint={d.ai.enabled ? `errori: ${d.ai.errors_1h} · fallback: ${d.ai.fallback_1h}` : 'assistente disattivato'} tone={d.ai.errors_1h ? 'warn' : undefined} />
        <Stat label="Pagamenti falliti (1 h)" value={d.payments.failed_1h} hint={`rimborsi in coda: ${d.payments.refunds_pending}`} tone={d.payments.failed_1h ? 'warn' : undefined} />
        <Stat label="Dispatch falliti (1 h)" value={d.dispatch.failed_1h} hint={`avvisi aperti: ${d.dispatch.open_alerts}`} />
        <Stat label="Ticket aperti" value={d.support.open} hint={`urgenti: ${d.support.urgent}`} tone={d.support.urgent ? 'warn' : undefined} />
        <Stat label="Richieste bloccate (rate limit, 24 h)" value={d.security.rate_limited_24h} hint={`GPS anomali: ${d.security.gps_flood_24h}`} />
        <Stat label="Database" value={bytes(d.db.size_bytes)} hint="dimensione stimata" />
      </div>
      <Card title="Core Web Vitals (utenti reali)">
        <div className="grid grid-cols-3 gap-3">
          <Stat label="LCP (< 2,5 s)" {...vit('LCP', 2500, ' ms')} />
          <Stat label="INP (< 200 ms)" {...vit('INP', 200, ' ms')} />
          <Stat label="CLS (< 0,1)" {...vit('CLS', 0.1, '')} />
        </div>
      </Card>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Errori recenti">
          {d.errors.recent.length ? (
            <ul className="max-h-80 space-y-2 overflow-y-auto text-sm" data-testid="recent-errors">
              {d.errors.recent.map((e) => (
                <li key={e.id} className="rounded-2xl bg-cream p-3">
                  <p className="font-mono text-xs text-ink-muted">{fmt(e.created_at)} · {e.source} · {e.code ?? '—'} {e.request_id ? `· ${e.request_id.slice(0, 8)}` : ''}</p>
                  <p className="mt-1 break-words">{e.message}</p>
                  {e.route && <p className="text-xs text-ink-faint">{e.route}</p>}
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-ink-muted">Nessun errore registrato.</p>}
        </Card>
        <Card title="Webhook Stripe">
          <p className="text-sm text-ink-muted">Elaborati 24 h: {d.webhooks.processed_24h} · ultimo: {fmt(d.webhooks.last_processed_at)} · falliti 7 gg: {d.webhooks.failed_7d}</p>
          {d.webhooks.recent_failed.length ? (
            <ul className="mt-2 space-y-2 text-sm" data-testid="failed-webhooks">
              {d.webhooks.recent_failed.map((w) => <li key={w.id} className="rounded-2xl bg-coral-50 p-3"><strong>{w.event_type}</strong> · tentativi {w.attempts} · {fmt(w.at)}<br /><span className="text-xs">{w.error ?? '—'}</span></li>)}
            </ul>
          ) : <p className="mt-2 text-sm text-emerald-700">Nessun webhook fallito.</p>}
        </Card>
        <Card title="Job pianificati">
          {d.jobs.last_runs.length ? (
            <table className="w-full text-sm"><thead><tr className="text-left text-xs text-ink-muted"><th className="pb-2">Job</th><th>Stato</th><th>Ultima fine</th></tr></thead>
              <tbody>{d.jobs.last_runs.map((j) => (
                <tr key={j.type} className="border-t border-line"><td className="py-2 font-mono text-xs">{j.type}</td>
                  <td><Badge tone={j.status === 'completed' ? 'green' : j.status === 'failed' ? 'coral' : 'amber'}>{j.status}</Badge></td><td className="text-xs">{fmt(j.completed_at)}</td></tr>
              ))}</tbody></table>
          ) : <p className="text-sm text-ink-muted">Nessun job registrato (i cron girano solo con il backend Netlify).</p>}
          {d.jobs.failed.length > 0 && (
            <ul className="mt-3 space-y-2 text-sm">
              {d.jobs.failed.map((j) => (
                <li key={j.id} className="flex items-start justify-between gap-2 rounded-2xl bg-coral-50 p-3">
                  <span><strong className="font-mono text-xs">{j.type}</strong> · {j.attempts}/{j.max_attempts} · {fmt(j.at)}<br /><span className="text-xs">{j.error}</span></span>
                  <Button size="sm" variant="outline" disabled={j.attempts >= j.max_attempts} onClick={() => void retry(j.id)}>Riprova</Button>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card title="Pulizia e retention">
          <ul className="space-y-1 text-sm">
            <li>Ultima retention: {d.cleanup.last_retention ? `${d.cleanup.last_retention.status} · ${fmt(d.cleanup.last_retention.at)}` : 'mai eseguita'}</li>
            <li>Posizioni GPS oltre la retention: <strong>{d.cleanup.rider_locations_overdue}</strong></li>
            <li>Sessioni AI scadute da eliminare: <strong>{d.cleanup.expired_ai_sessions}</strong></li>
            <li>Contatori rate limit: {d.cleanup.rate_limit_rows}</li>
            <li>Cancellazioni account programmate: {d.privacy.deletions_scheduled} · bloccate: {d.privacy.deletions_blocked}</li>
          </ul>
        </Card>
        <Card title="Controlli di sistema (backend)">
          {d.system_checks.length ? (
            <ul className="space-y-1 text-sm">{d.system_checks.map((c) => <li key={c.key} className="flex justify-between gap-2"><span className="font-mono text-xs">{c.key}</span><StatusPill status={c.status as CheckStatus} /></li>)}</ul>
          ) : <p className="text-sm text-ink-muted">In attesa del cron di sistema (ogni 15 minuti con Netlify).</p>}
        </Card>
        <Card title="Database: tabelle principali">
          <table className="w-full text-sm"><thead><tr className="text-left text-xs text-ink-muted"><th className="pb-2">Tabella</th><th className="text-right">Righe</th><th className="text-right">Seq/Idx scan</th></tr></thead>
            <tbody>{d.db.tables.map((t) => <tr key={t.table} className="border-t border-line"><td className="py-1.5 font-mono text-xs">{t.table}</td><td className="text-right tabular-nums">{t.rows}</td><td className="text-right text-xs tabular-nums">{t.seq_scans}/{t.idx_scans}</td></tr>)}</tbody></table>
        </Card>
      </div>
    </div>
  );
}

function FlagsPanel() {
  const toast = useToast();
  const s = useAsync(() => api.getSystemStatus(), []);
  const [confirm, setConfirm] = useState<FlagState | null>(null);
  const apply = async (f: FlagState, value: boolean) => {
    try {
      await api.adminSetFlag(f.flag, value);
      toast(`${f.label}: ${value ? 'attivo' : 'disattivato'}`);
      s.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setConfirm(null);
    }
  };
  if (s.loading && !s.data) return <PageLoader />;
  const flags = s.data?.flags ?? [];
  const group = (k: FlagState['kind'], title: string, hint: string) => (
    <Card title={title}>
      <p className="-mt-1 mb-2 text-sm text-ink-muted">{hint}</p>
      <div className="divide-y divide-line">
        {flags.filter((f) => f.kind === k).map((f) => (
          <div key={f.flag} data-testid={`flag-${f.flag}`}>
            <Toggle checked={f.value} label={f.label} description={`${f.flag} → ${f.key}`}
              onChange={(v) => (f.kind !== 'feature' ? setConfirm({ ...f, value: v }) : void apply(f, v))} />
          </div>
        ))}
      </div>
    </Card>
  );
  return (
    <div className="space-y-5">
      {group('kill_switch', 'Kill switch', 'Disattivano rapidamente un modulo in produzione. Ogni modifica è registrata nell’audit.')}
      {group('maintenance', 'Manutenzione', 'Il pubblico vede «Stiamo effettuando un aggiornamento», gli Admin continuano a lavorare; nuovi ordini rifiutati dal backend.')}
      {group('feature', 'Feature flag', 'Moduli attivabili/disattivabili senza deploy.')}
      <Sheet open={!!confirm} onClose={() => setConfirm(null)} title="Confermi la modifica?"
        footer={<div className="grid grid-cols-2 gap-2"><Button variant="outline" onClick={() => setConfirm(null)}>Annulla</Button><Button variant="dark" onClick={() => confirm && void apply(confirm, confirm.value)} data-testid="confirm-flag">Conferma</Button></div>}>
        <p className="text-sm">{confirm?.label}: <strong>{confirm?.value ? 'ATTIVO' : 'DISATTIVATO'}</strong>. L’effetto è immediato per tutti gli utenti.</p>
      </Sheet>
    </div>
  );
}

function PrivacyPanel() {
  const toast = useToast();
  const r = useAsync(() => api.adminPrivacyRequests(), []);
  const [invite, setInvite] = useState<{ email: string; role: string; days: number }>({ email: '', role: 'customer', days: 14 });
  const [token, setToken] = useState<string | null>(null);
  const act = async (id: string, a: 'retry' | 'cancel') => {
    try {
      await api.adminDeletionAction(id, a);
      r.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const createInvite = async () => {
    try {
      const x = await api.adminCreateBetaInvite(invite.email || null, invite.role, invite.days);
      setToken(x.token);
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  if (r.loading && !r.data) return <PageLoader />;
  return (
    <div className="space-y-5">
      <Card title="Cancellazioni account">
        {r.data?.deletions.length ? (
          <table className="w-full text-sm" data-testid="deletion-requests"><thead><tr className="text-left text-xs text-ink-muted"><th className="pb-2">Utente</th><th>Stato</th><th>Programmata</th><th /></tr></thead>
            <tbody>{r.data.deletions.map((d) => (
              <tr key={d.id} className="border-t border-line"><td className="py-2">{d.name ?? '—'}<br /><span className="text-xs text-ink-muted">{d.email_masked ?? '—'}</span></td>
                <td><Badge tone={d.status === 'blocked' ? 'coral' : d.status === 'scheduled' ? 'amber' : 'neutral'}>{d.status}</Badge>{d.blocked_reason && <p className="text-xs text-coral-700">{d.blocked_reason === 'owns_restaurant' ? 'titolare di un locale' : d.blocked_reason}</p>}</td>
                <td className="text-xs">{fmt(d.scheduled_for)}</td>
                <td className="text-right">{d.status === 'blocked' && <Button size="sm" variant="outline" onClick={() => void act(d.id, 'retry')}>Riprova</Button>}
                  {['scheduled', 'blocked'].includes(d.status) && <Button size="sm" variant="ghost" onClick={() => void act(d.id, 'cancel')}>Annulla</Button>}</td></tr>
            ))}</tbody></table>
        ) : <p className="text-sm text-ink-muted">Nessuna richiesta.</p>}
      </Card>
      <Card title="Export dati">
        <p className="text-sm text-ink-muted">{r.data?.exports.length ?? 0} richieste recenti (i file sono generati nel browser dell’utente, nessuna copia sul server).</p>
      </Card>
      <Card title="Inviti beta">
        <div className="grid gap-3 sm:grid-cols-[1fr_auto_auto_auto] sm:items-end">
          <Field label="Email (facoltativa)"><Input value={invite.email} onChange={(e) => setInvite({ ...invite, email: e.target.value })} /></Field>
          <Field label="Ruolo"><Select value={invite.role} onChange={(e) => setInvite({ ...invite, role: e.target.value })}><option value="customer">Cliente</option><option value="restaurant_owner">Ristoratore</option><option value="rider">Rider</option><option value="tester">Tester</option></Select></Field>
          <Field label="Giorni"><Input type="number" min={1} max={90} value={invite.days} onChange={(e) => setInvite({ ...invite, days: Number(e.target.value) })} /></Field>
          <Button onClick={() => void createInvite()}>Crea invito</Button>
        </div>
        {token && <Alert tone="success">Codice invito (mostrato una sola volta): <code className="break-all font-mono">{token}</code></Alert>}
      </Card>
    </div>
  );
}

function AuditPanel() {
  const [kind, setKind] = useState<'admin' | 'security'>('admin');
  const [page, setPage] = useState(0);
  const PAGE = 25;
  const r = useAsync(() => api.adminAuditList(kind, PAGE, page * PAGE), [kind, page]);
  return (
    <div className="space-y-3">
      <div className="flex gap-2"><Chip active={kind === 'admin'} onClick={() => { setKind('admin'); setPage(0); }}>Admin</Chip><Chip active={kind === 'security'} onClick={() => { setKind('security'); setPage(0); }}>Sicurezza</Chip></div>
      {r.loading && !r.data ? <PageLoader /> : r.data?.rows.length ? (
        <div className="overflow-x-auto rounded-3xl border border-line bg-white">
          <table className="w-full min-w-[640px] text-sm" data-testid="audit-table"><thead><tr className="text-left text-xs text-ink-muted"><th className="p-3">Quando</th><th>Azione</th><th>Oggetto</th><th>Autore</th><th>Dettagli</th></tr></thead>
            <tbody>{r.data.rows.map((x) => (
              <tr key={x.id} className="border-t border-line align-top"><td className="p-3 text-xs">{fmt(x.created_at)}</td><td className="font-mono text-xs">{x.action}</td>
                <td className="text-xs">{x.entity_type} {x.entity_id ? `· ${String(x.entity_id).slice(0, 12)}` : ''}</td><td className="text-xs">{x.actor ?? '—'} <span className="text-ink-faint">({x.actor_role ?? '—'})</span></td>
                <td className="max-w-xs truncate font-mono text-[11px] text-ink-muted" title={JSON.stringify(x.metadata)}>{JSON.stringify(x.metadata)}</td></tr>
            ))}</tbody></table>
        </div>
      ) : <EmptyState title="Nessun evento" />}
      <Pager page={page} total={r.data?.total ?? 0} size={PAGE} onPage={setPage} />
    </div>
  );
}

function ConsistencyPanel() {
  const r = useAsync(() => api.getConsistencyReport(), []);
  if (r.loading && !r.data) return <PageLoader />;
  if (r.error) return <Alert tone="error">{friendlyError(r.error)}</Alert>;
  return (
    <Card title={`Report di consistenza · ${r.data!.total_issues} anomalie`} action={<Button size="sm" variant="outline" onClick={r.reload}>Ricalcola</Button>}>
      <ul className="divide-y divide-line text-sm" data-testid="consistency-report">
        {r.data!.checks.map((c) => (
          <li key={c.key} className="flex items-start justify-between gap-3 py-2">
            <span>{c.label}{c.count > 0 && <span className="block font-mono text-[11px] text-ink-muted">{c.sample.join(', ')}</span>}</span>
            <Badge tone={c.count === 0 ? 'green' : c.severity === 'high' ? 'coral' : 'amber'}>{c.count}</Badge>
          </li>
        ))}
      </ul>
    </Card>
  );
}

function Pager({ page, total, size, onPage }: { page: number; total: number; size: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / size));
  if (pages <= 1) return null;
  return (
    <nav className="flex items-center justify-center gap-3 text-sm" aria-label="Paginazione">
      <Button size="sm" variant="outline" disabled={page === 0} onClick={() => onPage(page - 1)}>Precedente</Button>
      <span>Pagina {page + 1} di {pages}</span>
      <Button size="sm" variant="outline" disabled={page + 1 >= pages} onClick={() => onPage(page + 1)}>Successiva</Button>
    </nav>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/support
// ═════════════════════════════════════════════════════════════
const FILTERS: [SupportFilter, string][] = [['open', 'Aperti'], ['urgent', 'Urgenti'], ['orders', 'Ordini'], ['restaurants', 'Ristoranti'], ['riders', 'Rider'], ['billing', 'Fatturazione'], ['closed', 'Chiusi'], ['all', 'Tutti']];
export function AdminSupport() {
  useSeo({ title: 'Supporto', noindex: true });
  const [filter, setFilter] = useState<SupportFilter>('open');
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState<AdminSupportTicket | null>(null);
  const PAGE = 25;
  const r = useAsync(() => api.adminSupportTickets(filter, PAGE, page * PAGE), [filter, page]);
  return (
    <div data-testid="admin-support">
      <h1 className="text-2xl font-extrabold">Supporto</h1>
      <div className="mt-4 flex flex-wrap gap-2">{FILTERS.map(([k, l]) => <Chip key={k} active={filter === k} onClick={() => { setFilter(k); setPage(0); }}>{l}</Chip>)}</div>
      <div className="mt-4">
        {r.loading && !r.data ? <PageLoader /> : r.data?.rows.length ? (
          <ul className="divide-y divide-line rounded-3xl border border-line bg-white">
            {r.data.rows.map((t) => (
              <li key={t.id}>
                <button className="flex w-full flex-wrap items-center justify-between gap-2 p-4 text-left hover:bg-cream/50" onClick={() => setOpen(t)} data-testid="ticket-row">
                  <span><span className="font-semibold">{t.subject}</span><span className="block text-xs text-ink-muted">{t.reference} · {SUPPORT_CATEGORY_LABEL[t.category]}{t.order_number ? ` · ${t.order_number}` : ''}{t.restaurant_name ? ` · ${t.restaurant_name}` : ''} · {fmt(t.created_at)}</span></span>
                  <span className="flex gap-2"><Badge tone={t.priority === 'urgent' || t.priority === 'high' ? 'coral' : 'neutral'}>{t.priority}</Badge><Badge tone={['resolved', 'closed'].includes(t.status) ? 'green' : 'amber'}>{SUPPORT_STATUS_LABEL[t.status]}</Badge></span>
                </button>
              </li>
            ))}
          </ul>
        ) : <EmptyState icon="🎉" title="Nessun ticket" text="Non ci sono richieste in questa vista." />}
        <div className="mt-3"><Pager page={page} total={r.data?.total ?? 0} size={PAGE} onPage={setPage} /></div>
      </div>
      {open && <TicketSheet t={open} onClose={() => setOpen(null)} onSaved={() => { setOpen(null); r.reload(); }} />}
    </div>
  );
}

function TicketSheet({ t, onClose, onSaved }: { t: AdminSupportTicket; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ status: t.status, priority: t.priority, admin_notes: t.admin_notes ?? '', resolution: t.resolution ?? '' });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      await api.adminSupportUpdate(t.id, f);
      toast('Ticket aggiornato');
      onSaved();
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet open onClose={onClose} title={`${t.reference} · ${t.subject}`} wide footer={<Button className="w-full" loading={busy} onClick={() => void save()} data-testid="save-ticket">Salva</Button>}>
      <p className="whitespace-pre-wrap rounded-2xl bg-cream p-4 text-sm">{t.description}</p>
      <p className="mt-2 text-xs text-ink-muted">Contatto: {t.contact_name ?? '—'} · {t.contact_email ?? 'utente registrato'} {t.order_number ? `· ordine ${t.order_number}` : ''}</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <Field label="Stato"><Select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as SupportStatus })} data-testid="ticket-status">
          {Object.entries(SUPPORT_STATUS_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
        <Field label="Priorità"><Select value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value as SupportPriority })}>
          {['low', 'normal', 'high', 'urgent'].map((p) => <option key={p} value={p}>{p}</option>)}</Select></Field>
      </div>
      <Field label="Risposta / risoluzione (visibile all’utente)" className="mt-3"><Textarea value={f.resolution} onChange={(e) => setF({ ...f, resolution: e.target.value })} /></Field>
      <Field label="Note interne" className="mt-3"><Textarea value={f.admin_notes} onChange={(e) => setF({ ...f, admin_notes: e.target.value })} /></Field>
    </Sheet>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/launch-checklist
// ═════════════════════════════════════════════════════════════
function StatusPill({ status }: { status: CheckStatus }) {
  const m: Record<CheckStatus, [string, string, ReactNode]> = {
    pass: ['OK', 'text-emerald-700 bg-emerald-50', <CheckCircle2 key="i" className="h-3.5 w-3.5" />],
    fail: ['Fallito', 'text-coral-700 bg-coral-50', <XCircle key="i" className="h-3.5 w-3.5" />],
    warn: ['Attenzione', 'text-amber-800 bg-amber-50', <AlertTriangle key="i" className="h-3.5 w-3.5" />],
    pending: ['Da verificare', 'text-ink-soft bg-cream', <Clock key="i" className="h-3.5 w-3.5" />],
    na: ['N/A', 'text-ink-muted bg-cream', <MinusCircle key="i" className="h-3.5 w-3.5" />],
  };
  const [l, c, i] = m[status] ?? m.pending;
  return <span className={cn('inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold', c)}>{i}{l}</span>;
}

export function AdminLaunchChecklist() {
  useSeo({ title: 'Launch checklist', noindex: true });
  const toast = useToast();
  const r = useAsync(() => api.getLaunchChecklist(), []);
  const [edit, setEdit] = useState<LaunchCheck | null>(null);
  const [form, setForm] = useState<{ status: CheckStatus; notes: string }>({ status: 'pass', notes: '' });
  if (r.loading && !r.data) return <PageLoader />;
  if (r.error) return <Alert tone="error">{friendlyError(r.error)}</Alert>;
  const d = r.data!;
  const sections = [...new Set(d.checks.map((c) => c.section))];
  const tone = d.status === 'READY_FOR_PRODUCTION' ? 'bg-emerald-600' : d.status === 'READY_FOR_BETA' ? 'bg-emerald-500' : d.status === 'BLOCKED' ? 'bg-coral' : 'bg-amber-500';
  const save = async () => {
    try {
      await api.setLaunchCheck(edit!.key, form.status, form.notes || null);
      setEdit(null);
      r.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <div className="space-y-5" data-testid="launch-checklist">
      <h1 className="text-2xl font-extrabold">Launch checklist</h1>
      <div className="flex flex-wrap items-center gap-4 rounded-3xl border border-line bg-white p-5">
        <span className={cn('rounded-2xl px-4 py-2 text-lg font-extrabold text-white', tone)} data-testid="launch-status">{LAUNCH_STATUS_LABEL[d.status]}</span>
        <span className="text-sm"><strong className="font-display text-3xl tabular-nums" data-testid="launch-score">{d.score}%</strong> controlli superati</span>
        <span className="text-xs text-ink-muted">Lo stato è un suggerimento calcolato dai controlli: nessuna configurazione viene cambiata automaticamente. Con controlli critici aperti il punteggio non arriva mai al 100%.</span>
        <Button size="sm" variant="outline" icon={<RefreshCw className="h-4 w-4" />} onClick={r.reload} className="ml-auto">Ricalcola</Button>
      </div>
      {d.blocking.length > 0 && (
        <Card title={`Blocker da risolvere (${d.blocking.length})`}>
          <ul className="space-y-1 text-sm" data-testid="launch-blockers">
            {d.blocking.map((b) => <li key={b.key} className="flex items-center justify-between gap-2"><span>{b.title} <span className="text-xs text-ink-muted">({b.stage === 'beta' ? 'critico per la beta' : 'critico per la produzione'})</span></span><StatusPill status={b.status} /></li>)}
          </ul>
        </Card>
      )}
      <CityPanel city={d.city} />
      {sections.map((s) => (
        <Card key={s} title={s}>
          <ul className="divide-y divide-line">
            {d.checks.filter((c) => c.section === s).map((c) => (
              <li key={c.key} className="flex flex-wrap items-start justify-between gap-2 py-2.5 text-sm">
                <span className="min-w-0 flex-1">
                  {c.title}
                  {(c.crit_beta || c.crit_prod) && <Badge tone={c.crit_beta ? 'coral' : 'amber'} className="ml-2">{c.crit_beta ? 'critico beta' : 'critico prod'}</Badge>}
                  <span className="block text-xs text-ink-muted">{c.kind === 'auto' ? 'automatico' : c.kind === 'system' ? 'dal backend' : 'manuale'}{c.detail ? ` · ${c.detail}` : ''}{c.last_checked_at ? ` · ${fmt(c.last_checked_at)}` : ''}</span>
                </span>
                <span className="flex items-center gap-2"><StatusPill status={c.status} />
                  {c.kind === 'manual' && <Button size="sm" variant="ghost" onClick={() => { setEdit(c); setForm({ status: c.status === 'pending' ? 'pass' : c.status, notes: c.detail && c.detail !== 'Da confermare manualmente' ? c.detail : '' }); }} data-testid={`edit-${c.key}`}>Aggiorna</Button>}</span>
              </li>
            ))}
          </ul>
        </Card>
      ))}
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.title ?? ''} footer={<Button className="w-full" onClick={() => void save()} data-testid="save-check">Salva</Button>}>
        <Field label="Esito"><Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as CheckStatus })}>
          <option value="pass">OK (verificato)</option><option value="warn">Attenzione</option><option value="fail">Fallito</option><option value="pending">Da verificare</option><option value="na">Non applicabile</option></Select></Field>
        <Field label="Note (data, chi, evidenza)" className="mt-3"><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
      </Sheet>
    </div>
  );
}

function CityPanel({ city }: { city: import('@/types/platform').CityReadiness }) {
  return (
    <section className="rounded-3xl border border-line bg-white p-5" data-testid="taranto-readiness">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-lg font-bold">Taranto Launch Readiness</h2>
        <span className={cn('rounded-full px-3 py-1 text-sm font-bold text-white', city.ready ? 'bg-emerald-600' : 'bg-coral')}>{city.ready ? 'Ready' : 'Not Ready'} · {city.score}%</span>
      </div>
      <p className="mt-1 text-sm text-ink-muted">{city.restaurants} locali reali attivi in provincia (esclusi i locali demo). Controlli critici non superati: {city.critical_failing}.</p>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {city.checks.map((c) => (
          <div key={c.key} className="flex items-center justify-between gap-2 rounded-2xl bg-cream/60 px-3 py-2 text-sm">
            <span>{c.label}{c.critical && <span className="text-coral-700"> *</span>}<span className="block text-xs text-ink-muted">{typeof c.value === 'number' ? (/%/.test(c.target) ? `${c.value}%` : c.value) : c.value ? String(c.value).slice(0, 40) : '—'} · obiettivo {c.target}</span></span>
            <StatusPill status={c.status} />
          </div>
        ))}
      </div>
      <p className="mt-2 flex items-center gap-1 text-xs text-ink-faint"><CircleDashed className="h-3 w-3" /> * controllo critico</p>
    </section>
  );
}
