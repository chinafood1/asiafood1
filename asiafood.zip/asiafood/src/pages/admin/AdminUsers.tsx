import { useState } from 'react';
import { Search } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { formatDate } from '@/lib/format';
import { api } from '@/services';
import type { Profile, UserRole } from '@/types/domain';
import { Select, Toggle } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';

export default function AdminUsers() {
  const { user } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [search, setSearch] = useState('');
  const users = useAsync(() => api.listProfiles(search || undefined), [search]);
  useSeo({ title: 'Admin · Utenti', noindex: true });

  const update = async (p: Profile, patch: Partial<Profile>) => {
    if (p.id === user?.id && patch.role && patch.role !== 'admin') {
      if (!confirm('Stai rimuovendo il tuo ruolo di amministratore. Continuare?')) return;
    }
    try {
      await api.updateProfile(p.id, patch);
      users.setData((list) => list?.map((x) => (x.id === p.id ? { ...x, ...patch } : x)));
      toast('Utente aggiornato');
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };

  return (
    <div>
      <PageTitle title="Utenti" subtitle="Ruoli e blocchi. I ristoratori ottengono il ruolo automaticamente all’approvazione di una rivendicazione." />
      <form onSubmit={(e) => { e.preventDefault(); setSearch(q); }} className="mb-5 flex max-w-md items-center gap-2 rounded-full border border-line bg-white px-4">
        <Search className="h-4 w-4 text-ink-muted" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nome o email…" className="h-11 flex-1 bg-transparent text-sm focus:outline-none" />
      </form>
      {users.loading ? (
        <PageLoader />
      ) : (users.data ?? []).length === 0 ? (
        <EmptyState icon="👤" title="Nessun utente" />
      ) : (
        <div className="overflow-x-auto rounded-3xl border border-line bg-white">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="border-b border-line bg-cream/60 text-xs uppercase tracking-wider text-ink-muted">
              <tr>
                <th className="px-4 py-3">Utente</th>
                <th className="px-4 py-3">Registrato</th>
                <th className="px-4 py-3">Ruolo</th>
                <th className="px-4 py-3">Bloccato</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {users.data!.map((p) => (
                <tr key={p.id}>
                  <td className="px-4 py-3">
                    <p className="font-semibold">{p.full_name || '—'}</p>
                    <p className="text-xs text-ink-muted">{p.email}</p>
                  </td>
                  <td className="px-4 py-3 text-ink-muted">{formatDate(p.created_at, { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                  <td className="px-4 py-3">
                    <Select value={p.role} onChange={(e) => update(p, { role: e.target.value as UserRole })} className="!h-10 !w-44 !py-0 text-sm" aria-label="Ruolo">
                      <option value="customer">Cliente</option>
                      <option value="restaurant_owner">Ristoratore</option>
                      <option value="admin">Amministratore</option>
                    </Select>
                  </td>
                  <td className="px-4 py-3">
                    <Toggle label="" checked={p.is_blocked} onChange={(v) => update(p, { is_blocked: v })} disabled={p.id === user?.id} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
