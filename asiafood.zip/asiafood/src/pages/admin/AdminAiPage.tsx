import { useEffect, useState } from 'react';
import { KeyRound, RefreshCw } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { cn } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api, isDemoMode } from '@/services';
import { AI_SETTING_KEYS, type AiAdminStats, type AiSettingKey } from '@/types/ai';
import { Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Toggle } from '@/components/ui/Field';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle, StatTile } from '@/components/layout/DashboardLayout';

const INTENT_LABEL: Record<string, string> = {
  restaurant_search: 'Ricerca ristoranti',
  dish_search: 'Piatti',
  nearby_search: 'Vicino a me',
  price_search: 'Budget',
  open_now_search: 'Aperti ora',
  ayce_search: 'All you can eat',
  offer_search: 'Offerte',
  reservation_search: 'Prenotazioni',
  menu_question: 'Domande su un ristorante',
  dietary_search: 'Esigenze alimentari',
  restaurant_comparison: 'Confronti',
  general_food_question: 'Domande generali',
  unknown: 'Non classificate',
};

const int = new Intl.NumberFormat('it-IT');
const usd = new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'USD', maximumFractionDigits: 4 });
const dayLabel = (d: string) => new Date(`${d}T12:00:00`).toLocaleDateString('it-IT', { day: 'numeric', month: 'short' });

/** Richieste al giorno: una serie, barre sottili, dettaglio al passaggio (errori inclusi) e tabella accessibile. */
function DailyChart({ series }: { series: AiAdminStats['daily'] }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(...series.map((x) => x.requests), 0);
  const tickEvery = Math.max(1, Math.ceil(series.length / 6));
  return (
    <figure>
      <figcaption className="sr-only">Richieste all’assistente per giorno</figcaption>
      <div className="relative flex h-40 items-end gap-[3px] border-b border-line pb-px" onMouseLeave={() => setHover(null)}>
        {series.map((d, i) => {
          const h = max ? Math.max((d.requests / max) * 100, d.requests ? 3 : 0) : 0;
          return (
            <div
              key={d.day}
              className="relative flex h-full flex-1 items-end"
              onMouseEnter={() => setHover(i)}
              onFocus={() => setHover(i)}
              tabIndex={0}
              aria-label={`${dayLabel(d.day)}: ${d.requests} richieste, ${d.errors} errori`}
            >
              <div className={cn('w-full rounded-t-[4px] transition-colors', hover === i ? 'bg-coral' : 'bg-coral/55')} style={{ height: `${h}%` }} />
              {hover === i && (
                <div role="tooltip" className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 -translate-x-1/2 whitespace-nowrap rounded-xl bg-ink px-2.5 py-1.5 text-xs font-semibold text-white shadow-lift">
                  {dayLabel(d.day)} · {int.format(d.requests)} richieste{d.errors ? ` · ${d.errors} errori` : ''}
                </div>
              )}
            </div>
          );
        })}
        {max === 0 && <p className="absolute inset-0 flex items-center justify-center text-sm text-ink-muted">Ancora nessuna richiesta: il grafico mostra zero.</p>}
      </div>
      <div className="mt-1.5 flex gap-[3px] text-[11px] text-ink-muted">
        {series.map((d, i) => (
          <span key={d.day} className="flex-1 overflow-visible whitespace-nowrap text-center">{i % tickEvery === 0 ? dayLabel(d.day) : ''}</span>
        ))}
      </div>
      <table className="sr-only">
        <thead><tr><th>Giorno</th><th>Richieste</th><th>Errori</th></tr></thead>
        <tbody>{series.map((d) => <tr key={d.day}><td>{d.day}</td><td>{d.requests}</td><td>{d.errors}</td></tr>)}</tbody>
      </table>
    </figure>
  );
}

function IntentBars({ intents }: { intents: AiAdminStats['intents'] }) {
  const max = Math.max(...intents.map((i) => i.count), 0);
  if (!intents.length) return <p className="text-sm text-ink-muted">Nessun dato: gli intenti compariranno con le prime richieste.</p>;
  return (
    <ul className="space-y-2.5">
      {intents.map((i) => (
        <li key={i.intent}>
          <div className="mb-1 flex justify-between text-sm">
            <span>{INTENT_LABEL[i.intent] ?? i.intent}</span>
            <span className="font-semibold tabular-nums">{int.format(i.count)}</span>
          </div>
          <div className="h-2 rounded-full bg-cream" aria-hidden>
            <div className="h-2 rounded-full bg-coral" style={{ width: `${max ? (i.count / max) * 100 : 0}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

type Form = Record<AiSettingKey, string | boolean>;
const DEFAULTS: Form = {
  ai_enabled: true, ai_provider: '', ai_model: '', ai_guest_limit_per_hour: '10', ai_user_limit_per_hour: '30', ai_premium_limit_per_hour: '60',
  ai_max_restaurants: '5', ai_temperature: '', ai_max_tokens: '', ai_chat_retention_days: '7', ai_cache_ttl_seconds: '300',
};

function AiConfig() {
  const toast = useToast();
  const [form, setForm] = useState<Form | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void Promise.all(AI_SETTING_KEYS.map(async (k) => [k, await api.getSetting(k)] as const)).then((rows) => {
      const f = { ...DEFAULTS };
      for (const [k, v] of rows) {
        if (v === null || v === undefined) continue;
        f[k] = k === 'ai_enabled' ? v !== false : String(v);
      }
      setForm(f);
    });
  }, []);

  if (!form) return <PageLoader />;
  const set = (k: AiSettingKey, v: string | boolean) => setForm({ ...form, [k]: v });
  const num = (k: AiSettingKey, min: number, max: number, allowEmpty = false) => {
    const raw = String(form[k]).trim();
    if (allowEmpty && raw === '') return null;
    const n = Number(raw.replace(',', '.'));
    if (!Number.isFinite(n) || n < min || n > max) throw new Error(`Valore non valido: deve essere tra ${min} e ${max}.`);
    return n;
  };

  const save = async () => {
    setError(null);
    try {
      const values: Record<AiSettingKey, unknown> = {
        ai_enabled: !!form.ai_enabled,
        ai_provider: form.ai_provider || null,
        ai_model: String(form.ai_model).trim().slice(0, 80) || null,
        ai_guest_limit_per_hour: num('ai_guest_limit_per_hour', 0, 1000),
        ai_user_limit_per_hour: num('ai_user_limit_per_hour', 0, 1000),
        ai_premium_limit_per_hour: num('ai_premium_limit_per_hour', 0, 5000),
        ai_max_restaurants: num('ai_max_restaurants', 3, 8),
        ai_temperature: num('ai_temperature', 0, 1, true),
        ai_max_tokens: num('ai_max_tokens', 100, 2000, true),
        ai_chat_retention_days: num('ai_chat_retention_days', 0, 90),
        ai_cache_ttl_seconds: num('ai_cache_ttl_seconds', 0, 3600),
      };
      setSaving(true);
      for (const k of AI_SETTING_KEYS) await api.setSetting(k, values[k]);
      toast('Configurazione dell’assistente salvata.');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="card p-6" aria-labelledby="ai-config">
      <h2 id="ai-config" className="text-lg font-bold">Configurazione</h2>
      <p className="mt-1 flex items-start gap-2 text-sm text-ink-muted">
        <KeyRound className="mt-0.5 h-4 w-4 shrink-0" />
        La chiave del provider non si imposta qui: resta un secret del server (variabile <code>AI_API_KEY</code> nelle Netlify Functions) e non viene mai mostrata.
      </p>
      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Toggle checked={!!form.ai_enabled} onChange={(v) => set('ai_enabled', v)} label="Assistente attivo" description="Se disattivato, l’app mostra un messaggio e rimanda alla ricerca classica." />
        </div>
        <Field label="Provider" hint="Vuoto = variabile AI_PROVIDER. Senza provider l’assistente risponde solo con i dati (template).">
          <Select value={String(form.ai_provider)} onChange={(e) => set('ai_provider', e.target.value)}>
            <option value="">Da ambiente (AI_PROVIDER)</option>
            <option value="anthropic">Anthropic</option>
            <option value="openai">OpenAI</option>
            <option value="gemini">Google Gemini</option>
            <option value="openai_compatible">Compatibile OpenAI (AI_BASE_URL)</option>
            <option value="none">Nessun modello (solo dati)</option>
          </Select>
        </Field>
        <Field label="Modello" hint="Vuoto = variabile AI_MODEL.">
          <Input value={String(form.ai_model)} onChange={(e) => set('ai_model', e.target.value)} maxLength={80} placeholder="Da ambiente" />
        </Field>
        <Field label="Limite ospiti (richieste/ora)">
          <Input inputMode="numeric" value={String(form.ai_guest_limit_per_hour)} onChange={(e) => set('ai_guest_limit_per_hour', e.target.value)} />
        </Field>
        <Field label="Limite utenti registrati (richieste/ora)">
          <Input inputMode="numeric" value={String(form.ai_user_limit_per_hour)} onChange={(e) => set('ai_user_limit_per_hour', e.target.value)} />
        </Field>
        <Field label="Limite titolari Premium/Top (richieste/ora)">
          <Input inputMode="numeric" value={String(form.ai_premium_limit_per_hour)} onChange={(e) => set('ai_premium_limit_per_hour', e.target.value)} />
        </Field>
        <Field label="Ristoranti massimi per risposta (3–8)">
          <Input inputMode="numeric" value={String(form.ai_max_restaurants)} onChange={(e) => set('ai_max_restaurants', e.target.value)} />
        </Field>
        <Field label="Temperatura (0–1)" hint="Vuoto = variabile AI_TEMPERATURE (predefinito 0,2).">
          <Input inputMode="decimal" value={String(form.ai_temperature)} onChange={(e) => set('ai_temperature', e.target.value)} placeholder="Da ambiente" />
        </Field>
        <Field label="Token massimi di risposta" hint="Vuoto = variabile AI_MAX_TOKENS (predefinito 600).">
          <Input inputMode="numeric" value={String(form.ai_max_tokens)} onChange={(e) => set('ai_max_tokens', e.target.value)} placeholder="Da ambiente" />
        </Field>
        <Field label="Conservazione conversazioni (giorni)" hint="0 = i messaggi non vengono salvati (resta solo il contesto dei filtri).">
          <Input inputMode="numeric" value={String(form.ai_chat_retention_days)} onChange={(e) => set('ai_chat_retention_days', e.target.value)} />
        </Field>
        <Field label="Cache risposte generiche (secondi)" hint="Mai in cache: posizione, dati personali, disponibilità.">
          <Input inputMode="numeric" value={String(form.ai_cache_ttl_seconds)} onChange={(e) => set('ai_cache_ttl_seconds', e.target.value)} />
        </Field>
      </div>
      {error && <div className="mt-4"><Alert tone="error">{error}</Alert></div>}
      <div className="mt-5">
        <Button onClick={() => void save()} loading={saving}>Salva configurazione</Button>
      </div>
    </section>
  );
}

/** /admin/ai — utilizzo, costi, qualità e configurazione dell'assistente. */
export default function AdminAiPage() {
  useSeo({ title: 'Assistente AI · Admin', noindex: true });
  const [days, setDays] = useState(30);
  const stats = useAsync(() => api.getAdminAiStats(days), [days]);
  const s = stats.data;
  return (
    <div className="space-y-6">
      <PageTitle
        title="Assistente AI"
        subtitle="Richieste, costi stimati, qualità delle risposte e conversioni. Nessun contenuto delle conversazioni è mostrato qui."
        action={
          <div className="flex items-center gap-2">
            {[7, 30, 90].map((d) => (
              <Chip key={d} active={days === d} onClick={() => setDays(d)}>{d} giorni</Chip>
            ))}
            <Button size="sm" variant="outline" icon={<RefreshCw className="h-4 w-4" />} onClick={stats.reload}>Aggiorna</Button>
          </div>
        }
      />
      {isDemoMode && <Alert>Modalità DEMO: nessun modello collegato, quindi token e costi restano a zero. Le metriche contano le richieste fatte in questo browser.</Alert>}
      {stats.error && <Alert tone="error">{stats.error.message}</Alert>}
      {!s ? (
        stats.loading ? <PageLoader /> : null
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <StatTile label="Richieste oggi" value={int.format(s.requests_today)} accent />
            <StatTile label="Richieste questo mese" value={int.format(s.requests_month)} />
            <StatTile label={`Token (${days} giorni)`} value={int.format(s.input_tokens + s.output_tokens)} hint={`${int.format(s.input_tokens)} in · ${int.format(s.output_tokens)} out`} />
            <StatTile label={`Costo stimato (${days} giorni)`} value={usd.format(Number(s.estimated_cost) || 0)} hint="Stima dai prezzi per milione di token configurati" />
            <StatTile label="Tasso di errore" value={`${s.error_rate}%`} hint={`Risposte senza modello (fallback): ${s.fallback_rate}%`} />
            <StatTile label="Latenza media" value={`${int.format(s.avg_latency_ms)} ms`} />
            <StatTile label="Nessun risultato" value={`${s.no_results_rate}%`} hint={`Limite raggiunto: ${int.format(s.rate_limited)} · Cache: ${int.format(s.cache_hits)}`} />
            <StatTile label="Conversazioni attive" value={int.format(s.active_sessions)} />
          </div>

          <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
            <section className="card p-6" aria-labelledby="ai-daily">
              <h2 id="ai-daily" className="mb-4 text-lg font-bold">Richieste al giorno</h2>
              <DailyChart series={s.daily ?? []} />
            </section>
            <section className="card p-6" aria-labelledby="ai-intents">
              <h2 id="ai-intents" className="mb-4 text-lg font-bold">Intenti principali</h2>
              <IntentBars intents={s.intents ?? []} />
            </section>
          </div>

          <section className="card p-6" aria-labelledby="ai-conv">
            <h2 id="ai-conv" className="text-lg font-bold">Conversioni dall’assistente</h2>
            <p className="mt-1 text-sm text-ink-muted">Solo eventi reali con origine “ai”.</p>
            <div className="mt-4 grid gap-3 sm:grid-cols-4">
              <StatTile label="Clic sui risultati" value={int.format(s.conversions.result_clicks)} />
              <StatTile label="Aperture mappa" value={int.format(s.conversions.map_opens)} />
              <StatTile label="Prenotazioni" value={int.format(s.conversions.reservations)} />
              <StatTile label="Coupon ottenuti" value={int.format(s.conversions.coupon_claims)} />
            </div>
          </section>
        </>
      )}
      <AiConfig />
    </div>
  );
}
