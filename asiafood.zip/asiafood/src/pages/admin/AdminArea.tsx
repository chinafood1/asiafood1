import { Navigate, Route, Routes, useParams } from 'react-router-dom';
import { Compass, LineChart, Gauge, LifeBuoy, Rocket, Activity, BadgeCheck, BellRing, CreditCard, Gift, MessageSquareText, UserPlus, Flag, LayoutGrid, MapPin, MapPinned, Megaphone, Percent, Receipt, Server, Shapes, ShoppingBag, TrendingUp, Bike, Radar, Truck, Sparkles, Store, Tag, Ticket, Upload, Users } from 'lucide-react';
import { lazy } from 'react';
import { RequireRole } from '@/components/auth/RequireRole';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import RestaurantEditor from '@/components/editor/RestaurantEditor';
import { CrudPage } from '@/components/admin/CrudPage';
import { Chip } from '@/components/ui/Badge';
import { useState } from 'react';
import NotFoundPage from '../NotFoundPage';
import AdminOverview from './AdminOverview';
import AdminRestaurants from './AdminRestaurants';
import AdminClaims, { AdminClaimDetail } from './AdminClaims';
import AdminImport from './AdminImport';
import AdminReports from './AdminReports';
import AdminPlans from './AdminPlans';
import AdminChangeRequests from './AdminChangeRequests';
import AdminUsers from './AdminUsers';
import { AdminSponsorships, AdminStripeSystem, AdminSubscriptions } from './AdminBillingPages';
import { CRUD } from './crudConfigs';

const AdminAiPage = lazy(() => import('./AdminAiPage'));
const LaunchArea = lazy(() => import('./launch/LaunchArea'));
const GrowthArea = lazy(() => import('./growth/GrowthArea'));
const NextMarketPage = lazy(() => import('./growth/Markets').then((m) => ({ default: m.NextMarketPage })));
const platAdmin = () => import('./AdminPlatformPages');
const AdminSystem = lazy(() => platAdmin().then((m) => ({ default: m.AdminSystem })));
const AdminSupport = lazy(() => platAdmin().then((m) => ({ default: m.AdminSupport })));
const AdminLaunchChecklist = lazy(() => platAdmin().then((m) => ({ default: m.AdminLaunchChecklist })));
const ordAdmin = () => import('./AdminOrdersPages');
const AdminOrders = lazy(() => ordAdmin().then((m) => ({ default: m.AdminOrders })));
const AdminMarketplace = lazy(() => ordAdmin().then((m) => ({ default: m.AdminMarketplace })));
const lgAdmin = () => import('./AdminLogisticsPages');
const AdminRiders = lazy(() => lgAdmin().then((m) => ({ default: m.AdminRiders })));
const AdminDispatch = lazy(() => lgAdmin().then((m) => ({ default: m.AdminDispatch })));
const AdminLogistics = lazy(() => lgAdmin().then((m) => ({ default: m.AdminLogistics })));
const AdminLogisticsSettings = lazy(() => lgAdmin().then((m) => ({ default: m.AdminLogisticsSettings })));
const engAdmin = () => import('./AdminEngagementPages');
const AdminReviews = lazy(() => engAdmin().then((m) => ({ default: m.AdminReviews })));
const AdminLoyalty = lazy(() => engAdmin().then((m) => ({ default: m.AdminLoyalty })));
const AdminReferrals = lazy(() => engAdmin().then((m) => ({ default: m.AdminReferrals })));
const AdminCampaigns = lazy(() => engAdmin().then((m) => ({ default: m.AdminCampaigns })));
const AdminRetention = lazy(() => engAdmin().then((m) => ({ default: m.AdminRetention })));

/** Regioni, province e comuni in un'unica sezione a schede. */
function GeoPage() {
  const [tab, setTab] = useState<'cities' | 'provinces' | 'regions'>('cities');
  return (
    <div>
      <div className="mb-6 flex gap-2">
        <Chip active={tab === 'cities'} onClick={() => setTab('cities')}>Comuni</Chip>
        <Chip active={tab === 'provinces'} onClick={() => setTab('provinces')}>Province</Chip>
        <Chip active={tab === 'regions'} onClick={() => setTab('regions')}>Regioni</Chip>
      </div>
      <CrudPage key={tab} config={CRUD[tab]!} />
    </div>
  );
}

function LegacyRestaurantRedirect() {
  const { id } = useParams();
  return <Navigate to={`/admin/restaurants/${id}`} replace />;
}

/** Area amministratore: /admin/* (caricata on-demand). */
export default function AdminArea() {
  return (
    <RequireRole roles={['admin']}>
      <Routes>
        <Route
          element={
            <DashboardLayout
              title="Amministrazione"
              nav={[
                { to: '/admin', label: 'Panoramica', icon: LayoutGrid, end: true },
                { to: '/admin/system', label: 'Sistema', icon: Gauge, end: true },
                { to: '/admin/growth', label: 'Growth', icon: LineChart },
                { to: '/admin/expansion/next-market', label: 'Prossimo mercato', icon: Compass },
                { to: '/admin/launch/taranto', label: 'Lancio Taranto', icon: Flag },
                { to: '/admin/launch-checklist', label: 'Launch checklist', icon: Rocket },
                { to: '/admin/support', label: 'Supporto', icon: LifeBuoy },
                { to: '/admin/restaurants', label: 'Ristoranti', icon: Store },
                { to: '/admin/orders', label: 'Ordini', icon: ShoppingBag },
                { to: '/admin/marketplace', label: 'Marketplace', icon: TrendingUp },
                { to: '/admin/dispatch', label: 'Dispatch', icon: Radar },
                { to: '/admin/riders', label: 'Rider', icon: Bike },
                { to: '/admin/logistics', label: 'Logistica', icon: Truck },
                { to: '/admin/import', label: 'Importa', icon: Upload },
                { to: '/admin/claims', label: 'Rivendicazioni', icon: BadgeCheck },
                { to: '/admin/reports', label: 'Segnalazioni', icon: Flag },
                { to: '/admin/modifiche', label: 'Modifiche posizione', icon: MapPin },
                { to: '/admin/reviews', label: 'Recensioni', icon: MessageSquareText },
                { to: '/admin/utenti', label: 'Utenti', icon: Users },
                { to: '/admin/loyalty', label: 'AsiaPoints', icon: Gift },
                { to: '/admin/referrals', label: 'Inviti', icon: UserPlus },
                { to: '/admin/campaigns', label: 'Campagne', icon: BellRing },
                { to: '/admin/retention', label: 'Retention', icon: Activity },
                { to: '/admin/categorie', label: 'Categorie', icon: Shapes },
                { to: '/admin/geografia', label: 'Città e territori', icon: MapPinned },
                { to: '/admin/offerte', label: 'Offerte', icon: Tag },
                { to: '/admin/coupon', label: 'Coupon', icon: Ticket },
                { to: '/admin/sponsorships', label: 'Sponsorizzazioni', icon: Megaphone },
                { to: '/admin/subscriptions', label: 'Abbonamenti', icon: Receipt },
                { to: '/admin/plans', label: 'Piani', icon: CreditCard },
                { to: '/admin/promozioni', label: 'Promozioni B2B', icon: Percent },
                { to: '/admin/system/stripe', label: 'Stripe', icon: Server },
                { to: '/admin/ai', label: 'Assistente AI', icon: Sparkles },
              ]}
            />
          }
        >
          <Route index element={<AdminOverview />} />
          <Route path="restaurants" element={<AdminRestaurants />} />
          <Route path="restaurants/:id" element={<RestaurantEditor mode="admin" />} />
          <Route path="restaurants/:id/:section" element={<RestaurantEditor mode="admin" />} />
          <Route path="import" element={<AdminImport />} />
          <Route path="orders" element={<AdminOrders />} />
          <Route path="marketplace" element={<AdminMarketplace />} />
          <Route path="dispatch" element={<AdminDispatch />} />
          <Route path="riders" element={<AdminRiders />} />
          <Route path="logistics" element={<AdminLogistics />} />
          <Route path="logistics/settings" element={<AdminLogisticsSettings />} />
          <Route path="claims" element={<AdminClaims />} />
          <Route path="claims/:id" element={<AdminClaimDetail />} />
          <Route path="reports" element={<AdminReports />} />
          <Route path="modifiche" element={<AdminChangeRequests />} />
          {/* Compatibilità con gli URL della Fase 1 */}
          <Route path="ristoranti" element={<Navigate to="/admin/restaurants" replace />} />
          <Route path="ristoranti/:id" element={<LegacyRestaurantRedirect />} />
          <Route path="rivendicazioni" element={<Navigate to="/admin/claims" replace />} />
          <Route path="utenti" element={<AdminUsers />} />
          <Route path="categorie" element={<CrudPage key="categories" config={CRUD.categories!} />} />
          <Route path="geografia" element={<GeoPage />} />
          <Route path="offerte" element={<CrudPage key="offers" config={CRUD.offers!} />} />
          <Route path="coupon" element={<CrudPage key="coupons" config={CRUD.coupons!} />} />
          <Route path="sponsorizzati" element={<Navigate to="/admin/sponsorships" replace />} />
          <Route path="sponsorships" element={<AdminSponsorships />} />
          <Route path="subscriptions" element={<AdminSubscriptions />} />
          <Route path="promozioni" element={<CrudPage key="promotions" config={CRUD.promotions!} />} />
          <Route path="system/stripe" element={<AdminStripeSystem />} />
          <Route path="system" element={<AdminSystem />} />
          <Route path="support" element={<AdminSupport />} />
          <Route path="launch-checklist" element={<AdminLaunchChecklist />} />
          <Route path="launch/taranto/*" element={<LaunchArea />} />
          <Route path="growth/*" element={<GrowthArea />} />
          <Route path="expansion/next-market" element={<NextMarketPage />} />
          <Route path="expansion" element={<Navigate to="/admin/expansion/next-market" replace />} />
          <Route path="launch" element={<Navigate to="/admin/launch/taranto" replace />} />
          <Route path="ai" element={<AdminAiPage />} />
          <Route path="reviews" element={<AdminReviews />} />
          <Route path="loyalty" element={<AdminLoyalty />} />
          <Route path="referrals" element={<AdminReferrals />} />
          <Route path="campaigns" element={<AdminCampaigns />} />
          <Route path="retention" element={<AdminRetention />} />
          <Route path="plans" element={<AdminPlans />} />
          <Route path="piani" element={<Navigate to="/admin/plans" replace />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </RequireRole>
  );
}
