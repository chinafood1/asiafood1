import { useMemo, useState, type FormEvent } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  BadgeCheck, MapPinOff, ChevronLeft, ChevronRight, Copy, Eye, EyeOff, FileSearch, Link2, MoreHorizontal, Pencil, Plus, Search, SlidersHorizontal,
  Store, Trash2, Upload, X, DoorClosed, DoorOpen, Ban,
} from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { cn, formatDate } from '@/lib/format';
import { DATA_STATUS } from '@/lib/labels';
import { api, type AdminRestaurantQuery, type YesNo } from '@/services';
import type { DataStatus, PlanCode, RestaurantSummary } from '@/types/domain';
import { Badge, DataStatusBadge, DemoBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Toggle } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { Monogram } from '@/components/ui/SmartImage';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';

const PAGE_SIZE = 25;
const PLANS: PlanCode[] = ['free', 'business', 'premium', 'top'];
const FILTER_KEYS = ['q', 'city', 'category', 'verified', 'claimed', 'active', 'status', 'sponsored', 'plan', 'demo', 'closed', 'coords', 'sort', 'page'] as const;

function useQueryState() {
  const [params, setParams] = useSearchParams();
  const query: AdminRestaurantQuery = {
    q: params.get('q') ?? undefined,
    cityId: params.get('city') ?? undefined,
    categoryId: params.get('category') ?? undefined,
    verified: (params.get('verified') as YesNo) ?? undefined,
    claimed: (params.get('claimed') as YesNo) ?? undefined,
    active: (params.get('active') as YesNo) ?? undefined,
    dataStatus: (params.get('status') as DataStatus) ?? undefined,
    sponsored: (params.get('sponsored') as YesNo) ?? undefined,
    plan: (params.get('plan') as PlanCode) ?? undefined,
    demo: (params.get('demo') as YesNo) ?? undefined,
    closed: (params.get('closed') as AdminRestaurantQuery['closed']) ?? undefined,
    coords: (params.get('coords') as AdminRestaurantQuery['coords']) ?? undefined,
    sort: (params.get('sort') as AdminRestaurantQuery['sort']) ?? undefined,
    page: Number(params.get('page') ?? 1),
    pageSize: PAGE_SIZE,
  };
  const set = (patch: Record<string, string | undefined>, resetPage = true) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    if (resetPage && !('page' in patch)) next.delete('page');
    setParams(next, { replace: true });
  };
  const active = FILTER_KEYS.filter((k) => !['q', 'sort', 'page'].includes(k) && params.get(k)).length;
  return { query, set, params, active, reset: () => setParams(new URLSearchParams(), { replace: true }) };
}

export default function AdminRestaurants() {
  const { cities, categories } = useReferenceData();
  const toast = useToast();
  const navigate = useNavigate();
  const { query, set, params, active, reset } = useQueryState();
  const result = useAsync(() => api.adminListRestaurants(query), [params.toString()]);
  const [q, setQ] = useState(query.q ?? '');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [actions, setActions] = useState<RestaurantSummary | null>(null);
  const [creating, setCreating] = useState(false);
  useSeo({ title: 'Admin · Ristoranti', noindex: true });

  const total = result.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const page = query.page ?? 1;

  const filters = (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <Sel label="Comune" value={query.cityId} onChange={(v) => set({ city: v })} options={cities.map((c) => [c.id, c.name])} />
      <Sel label="Categoria" value={query.categoryId} onChange={(v) => set({ category: v })} options={categories.map((c) => [c.id, `${c.emoji ?? ''} ${c.name}`])} />
      <Sel label="Profilo verificato" value={query.verified} onChange={(v) => set({ verified: v })} options={[['yes', 'Verificato'], ['no', 'Non verificato']]} />
      <Sel label="Rivendicato" value={query.claimed} onChange={(v) => set({ claimed: v })} options={[['yes', 'Rivendicato'], ['no', 'Non rivendicato']]} />
      <Sel label="Pubblicazione" value={query.active} onChange={(v) => set({ active: v })} options={[['yes', 'Pubblicato'], ['no', 'Bozza / disattivato']]} />
      <Sel label="Stato dati" value={query.dataStatus} onChange={(v) => set({ status: v })} options={(Object.keys(DATA_STATUS) as DataStatus[]).map((k) => [k, DATA_STATUS[k].label])} />
      <Sel label="Sponsorizzato" value={query.sponsored} onChange={(v) => set({ sponsored: v })} options={[['yes', 'Sì'], ['no', 'No']]} />
      <Sel label="Piano" value={query.plan} onChange={(v) => set({ plan: v })} options={PLANS.map((p) => [p, p.toUpperCase()])} />
      <Sel label="Chiusura" value={query.closed} onChange={(v) => set({ closed: v })} options={[['open', 'Aperti'], ['temporary', 'Chiusi temporaneamente'], ['permanent', 'Chiusi definitivamente']]} />
      <Sel label="Posizione" value={query.coords} onChange={(v) => set({ coords: v })} options={[['missing', 'Coordinate mancanti'], ['present', 'Sulla mappa']]} />
      <Sel label="Dati demo" value={query.demo} onChange={(v) => set({ demo: v })} options={[['no', 'Solo reali'], ['yes', 'Solo demo']]} />
      <Sel label="Ordina per" value={query.sort} onChange={(v) => set({ sort: v }, false)} options={[['updated', 'Ultima modifica'], ['last_verified', 'Da verificare prima']]} placeholder="Nome (A–Z)" />
    </div>
  );

  return (
    <div>
      <PageTitle
        title="Ristoranti"
        subtitle={`${total} schede${active ? ' filtrate' : ''}`}
        action={
          <div className="flex gap-2">
            <Link to="/admin/import" className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-white px-5 text-[15px] font-semibold hover:border-ink"><Upload className="h-4 w-4" /> Importa</Link>
            <Button icon={<Plus className="h-4 w-4" />} onClick={() => setCreating(true)}>Nuovo</Button>
          </div>
        }
      />

      <div className="mb-4 flex gap-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            set({ q: q.trim() || undefined });
          }}
          className="flex flex-1 items-center gap-2 rounded-full border border-line bg-white px-4"
        >
          <Search className="h-4 w-4 text-ink-muted" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cerca per nome, slug o indirizzo…" className="h-11 min-w-0 flex-1 bg-transparent text-sm focus:outline-none" />
        </form>
        <button onClick={() => setFiltersOpen(true)} className="inline-flex h-11 shrink-0 items-center gap-2 rounded-full bg-ink px-4 text-sm font-semibold text-white lg:hidden">
          <SlidersHorizontal className="h-4 w-4" /> Filtri {active > 0 && <span className="rounded-full bg-coral px-1.5 text-xs">{active}</span>}
        </button>
      </div>
      <div className="mb-5 hidden rounded-3xl border border-line bg-white p-4 lg:block">
        {filters}
        {active > 0 && <button onClick={reset} className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-coral-700"><X className="h-4 w-4" /> Azzera filtri</button>}
      </div>
      <Sheet open={filtersOpen} onClose={() => setFiltersOpen(false)} title="Filtri" footer={<div className="flex gap-3"><Button variant="outline" className="flex-1" onClick={reset}>Azzera</Button><Button className="flex-[2]" onClick={() => setFiltersOpen(false)}>Mostra {total}</Button></div>}>
        {filters}
      </Sheet>

      {result.loading && !result.data ? (
        <PageLoader />
      ) : result.error ? (
        <EmptyState icon="⚠️" title="Errore" text={result.error.message} />
      ) : (result.data?.rows.length ?? 0) === 0 ? (
        <EmptyState icon="🔎" title="Nessun ristorante" text={active ? 'Prova a cambiare i filtri.' : 'Importa un file o crea la prima scheda.'} />
      ) : (
        <>
          {/* Tabella desktop */}
          <div className="hidden overflow-x-auto rounded-3xl border border-line bg-white md:block">
            <table className="w-full min-w-[1080px] text-left text-sm">
              <thead className="border-b border-line bg-cream/60 text-[11px] uppercase tracking-wider text-ink-muted">
                <tr>
                  <th className="px-4 py-3">Nome</th>
                  <th className="px-3 py-3">Città</th>
                  <th className="px-3 py-3">Categorie</th>
                  <th className="px-3 py-3">Stato</th>
                  <th className="px-3 py-3">Verificato</th>
                  <th className="px-3 py-3">Rivendicato</th>
                  <th className="px-3 py-3">Piano</th>
                  <th className="px-3 py-3">Sponsor</th>
                  <th className="px-3 py-3">Ultima verifica</th>
                  <th className="px-3 py-3 text-right">Azioni</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {result.data!.rows.map((r) => (
                  <tr key={r.id} className={cn('hover:bg-paper', !r.is_active && 'bg-paper/60')}>
                    <td className="px-4 py-3">
                      <Link to={`/admin/restaurants/${r.id}`} className="flex items-center gap-3">
                        <Monogram name={r.name} src={r.logo_url} className="h-9 w-9 shrink-0 text-xs" />
                        <span className="min-w-0">
                          <span className="flex items-center gap-1.5 font-semibold"><span className="max-w-[220px] truncate">{r.name}</span>{r.is_demo && <DemoBadge />}{r.latitude == null && <Badge tone="amber" icon={<MapPinOff className="h-3 w-3" />} className="whitespace-nowrap">Coordinate mancanti</Badge>}</span>
                          <span className="block max-w-[260px] truncate text-xs text-ink-muted">{r.address ?? 'Indirizzo mancante'}</span>
                        </span>
                      </Link>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">{r.city?.name}</td>
                    <td className="px-3 py-3"><CatList r={r} /></td>
                    <td className="px-3 py-3"><StatusCell r={r} /></td>
                    <td className="px-3 py-3"><DataStatusBadge status={r.data_status} /></td>
                    <td className="px-3 py-3">{r.owner_id ? <Badge tone="green" icon={<BadgeCheck className="h-3.5 w-3.5" />}>Sì</Badge> : <span className="text-ink-faint">No</span>}</td>
                    <td className="px-3 py-3"><PlanBadge plan={r.subscription_plan} /></td>
                    <td className="px-3 py-3">{r.sponsored_now ? <Badge tone="coral">Sì</Badge> : <span className="text-ink-faint">—</span>}</td>
                    <td className="px-3 py-3 whitespace-nowrap text-ink-muted">{r.last_verified_at ? formatDate(r.last_verified_at, { day: 'numeric', month: 'short', year: '2-digit' }) : <span className="text-coral-700">mai</span>}</td>
                    <td className="px-3 py-2 text-right whitespace-nowrap">
                      <Link aria-label="Modifica" title="Modifica" to={`/admin/restaurants/${r.id}`} className="inline-flex rounded-full p-2 text-ink-muted hover:bg-cream hover:text-ink"><Pencil className="h-4 w-4" /></Link>
                      <button aria-label="Altre azioni" title="Azioni" onClick={() => setActions(r)} className="rounded-full p-2 text-ink-muted hover:bg-cream hover:text-ink"><MoreHorizontal className="h-4 w-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Card mobile */}
          <ul className="space-y-3 md:hidden">
            {result.data!.rows.map((r) => (
              <li key={r.id} className="rounded-3xl border border-line bg-white p-4">
                <div className="flex items-start gap-3">
                  <Monogram name={r.name} src={r.logo_url} className="h-11 w-11 shrink-0 text-sm" />
                  <Link to={`/admin/restaurants/${r.id}`} className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{r.name}</p>
                    <p className="truncate text-xs text-ink-muted">{r.city?.name} · {r.categories.slice(0, 2).map((c) => c.name).join(', ') || 'nessuna categoria'}</p>
                  </Link>
                  <button aria-label="Azioni" onClick={() => setActions(r)} className="rounded-full p-2 text-ink-muted hover:bg-cream"><MoreHorizontal className="h-5 w-5" /></button>
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <StatusCell r={r} />
                  <DataStatusBadge status={r.data_status} />
                  {r.owner_id && <Badge tone="green">Rivendicato</Badge>}
                  <PlanBadge plan={r.subscription_plan} />
                  {r.sponsored_now && <Badge tone="coral">Sponsor</Badge>}
                  {r.is_demo && <DemoBadge />}
                  {r.latitude == null && <Badge tone="amber">Coordinate mancanti</Badge>}
                </div>
              </li>
            ))}
          </ul>
        </>
      )}

      {pages > 1 && (
        <div className="mt-4 flex items-center justify-end gap-2 text-sm">
          <button disabled={page <= 1} onClick={() => set({ page: String(page - 1) }, false)} className="rounded-full border border-line bg-white p-2 disabled:opacity-40" aria-label="Pagina precedente"><ChevronLeft className="h-4 w-4" /></button>
          <span>Pagina {page} di {pages}</span>
          <button disabled={page >= pages} onClick={() => set({ page: String(page + 1) }, false)} className="rounded-full border border-line bg-white p-2 disabled:opacity-40" aria-label="Pagina successiva"><ChevronRight className="h-4 w-4" /></button>
        </div>
      )}

      <ActionsSheet r={actions} onClose={() => setActions(null)} onDone={() => { setActions(null); result.reload(); }} navigate={navigate} toast={toast} />
      <CreateSheet open={creating} onClose={() => setCreating(false)} />
    </div>
  );
}

function Sel({ label, value, onChange, options, placeholder = 'Tutti' }: { label: string; value?: string; onChange: (v: string | undefined) => void; options: [string, string][]; placeholder?: string }) {
  return (
    <Field label={label}>
      <Select value={value ?? ''} onChange={(e) => onChange(e.target.value || undefined)} className="!h-10 !py-0 text-sm">
        <option value="">{placeholder}</option>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </Select>
    </Field>
  );
}

function CatList({ r }: { r: RestaurantSummary }) {
  if (!r.categories.length) return <span className="text-xs text-coral-700">nessuna</span>;
  return (
    <span className="flex flex-wrap gap-1">
      {r.categories.slice(0, 2).map((c) => <Badge key={c.id} tone="neutral" className="whitespace-nowrap">{c.emoji} {c.name}</Badge>)}
      {r.categories.length > 2 && <Badge tone="outline">+{r.categories.length - 2}</Badge>}
    </span>
  );
}

function StatusCell({ r }: { r: RestaurantSummary }) {
  if (r.is_permanently_closed) return <Badge tone="dark">Chiuso</Badge>;
  if (!r.is_active) return <Badge tone="coral">Bozza</Badge>;
  if (r.is_temporarily_closed) return <Badge tone="amber">Chiuso temp.</Badge>;
  return <Badge tone="green">Pubblicato</Badge>;
}

const PlanBadge = ({ plan }: { plan: PlanCode }) => <Badge tone={plan === 'free' ? 'outline' : 'dark'} className="uppercase">{plan}</Badge>;

function ActionsSheet({ r, onClose, onDone, navigate, toast }: { r: RestaurantSummary | null; onClose: () => void; onDone: () => void; navigate: ReturnType<typeof useNavigate>; toast: ReturnType<typeof useToast> }) {
  const run = async (fn: () => Promise<unknown>, msg: string) => {
    try {
      await fn();
      toast(msg);
      onDone();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
  if (!r) return null;
  const items: { icon: typeof Eye; label: string; hint?: string; onClick: () => void; danger?: boolean; disabled?: boolean }[] = [
    { icon: Eye, label: 'Visualizza scheda pubblica', disabled: !r.is_active, hint: r.is_active ? undefined : 'Non pubblicata', onClick: () => window.open(`/ristorante/${r.slug}`, '_blank') },
    { icon: Pencil, label: 'Modifica', onClick: () => navigate(`/admin/restaurants/${r.id}`) },
    r.is_active
      ? { icon: EyeOff, label: 'Disattiva (torna in bozza)', onClick: () => run(() => api.updateRestaurant(r.id, { is_active: false }), 'Scheda disattivata') }
      : { icon: Eye, label: 'Pubblica', onClick: () => run(() => api.updateRestaurant(r.id, { is_active: true }), 'Scheda pubblicata') },
    {
      icon: BadgeCheck,
      label: 'Verifica (dati controllati oggi)',
      hint: 'Imposta stato “Verificato” e data di verifica',
      onClick: () => confirm('Hai controllato i dati sulle fonti pubbliche?') && run(() => api.updateRestaurant(r.id, { data_status: r.owner_id ? 'claimed' : 'verified', last_verified_at: new Date().toISOString() }), 'Segnato come verificato'),
    },
    r.is_temporarily_closed || r.is_permanently_closed
      ? { icon: DoorOpen, label: 'Segna come aperto', onClick: () => run(() => api.updateRestaurant(r.id, { is_temporarily_closed: false, is_permanently_closed: false }), 'Segnato come aperto') }
      : { icon: DoorClosed, label: 'Segna come chiuso temporaneamente', onClick: () => run(() => api.updateRestaurant(r.id, { is_temporarily_closed: true }), 'Chiuso temporaneamente') },
    ...(!r.is_permanently_closed ? [{ icon: Ban, label: 'Segna come chiuso definitivamente', onClick: () => confirm('Il locale uscirà dai risultati di ricerca. Continuare?') && run(() => api.updateRestaurant(r.id, { is_permanently_closed: true }), 'Chiuso definitivamente') }] : []),
    { icon: Copy, label: 'Duplica', hint: 'Copia dati, categorie e orari in una nuova bozza', onClick: () => run(async () => navigate(`/admin/restaurants/${await api.duplicateRestaurant(r.id)}/info`), 'Scheda duplicata') },
    { icon: Link2, label: 'Gestisci fonti', onClick: () => navigate(`/admin/restaurants/${r.id}/fonti`) },
    { icon: FileSearch, label: 'Gestisci claim', onClick: () => navigate(`/admin/claims?restaurant=${r.id}`) },
    { icon: Trash2, label: 'Elimina definitivamente', danger: true, onClick: () => confirm(`Eliminare “${r.name}”? Per nasconderlo usa “Disattiva”.`) && run(() => api.deleteRestaurant(r.id), 'Eliminato') },
  ];
  return (
    <Sheet open onClose={onClose} title={r.name}>
      <ul className="-mx-2">
        {items.map((it) => (
          <li key={it.label}>
            <button
              disabled={it.disabled}
              onClick={it.onClick}
              className={cn('flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left text-[15px] transition hover:bg-cream disabled:opacity-40', it.danger && 'text-coral-700')}
            >
              <it.icon className="h-5 w-5 shrink-0" />
              <span className="min-w-0">
                <span className="block font-medium">{it.label}</span>
                {it.hint && <span className="block text-xs text-ink-muted">{it.hint}</span>}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}

function CreateSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { cities, categories } = useReferenceData();
  const toast = useToast();
  const navigate = useNavigate();
  const [draft, setDraft] = useState({ name: '', city_id: '', category_id: '', address: '', publish: false });
  const [busy, setBusy] = useState(false);
  const cityOptions = useMemo(() => cities.map((c) => <option key={c.id} value={c.id}>{c.name}</option>), [cities]);
  const create = async (e: FormEvent) => {
    e.preventDefault();
    if (!draft.name.trim() || !draft.city_id) return toast('Nome e comune sono obbligatori', 'error');
    setBusy(true);
    try {
      const r = await api.createRestaurant({ name: draft.name.trim(), city_id: draft.city_id, address: draft.address || null, is_active: draft.publish }, draft.category_id ? [draft.category_id] : []);
      toast('Ristorante creato');
      navigate(`/admin/restaurants/${r.id}/info`);
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet open={open} onClose={onClose} title="Nuovo ristorante">
      <form onSubmit={create} className="grid gap-4">
        <Field label="Nome *"><Input autoFocus value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
        <Field label="Comune *">
          <Select value={draft.city_id} onChange={(e) => setDraft({ ...draft, city_id: e.target.value })}>
            <option value="">Seleziona…</option>
            {cityOptions}
          </Select>
        </Field>
        <Field label="Categoria principale">
          <Select value={draft.category_id} onChange={(e) => setDraft({ ...draft, category_id: e.target.value })}>
            <option value="">—</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>)}
          </Select>
        </Field>
        <Field label="Indirizzo"><Input value={draft.address} onChange={(e) => setDraft({ ...draft, address: e.target.value })} /></Field>
        <Toggle label="Pubblica subito" description="Altrimenti resta in bozza finché non la verifichi" checked={draft.publish} onChange={(v) => setDraft({ ...draft, publish: v })} />
        <p className="flex items-start gap-2 text-xs text-ink-muted"><Store className="mt-0.5 h-4 w-4 shrink-0" /> Inserisci solo dati verificabili e registra la fonte nella sezione “Fonti”. Lo slug SEO viene generato automaticamente.</p>
        <Button type="submit" loading={busy}>Crea e modifica</Button>
      </form>
    </Sheet>
  );
}

