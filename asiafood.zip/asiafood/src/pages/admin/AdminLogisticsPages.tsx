import { useCallback, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { AlertTriangle, Bike, CheckCircle2, FileText, Play, RefreshCw, Settings, UserCheck, UserX } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { cn, formatPrice } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import type { AdminJobDetail, AdminRiderDetail, CompensationRule, DispatchBoard, LogisticsSettings, LogisticsStats, ServiceZone } from '@/types/logistics';
import { DOCUMENT_TYPE_LABEL, JOB_STATUS_LABEL, RIDER_STATUS_LABEL, VEHICLE_LABEL } from '@/types/logistics';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader, Spinner } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PageTitle, StatTile } from '@/components/layout/DashboardLayout';
import { DeliveryMap, JobStatusBadge, RiderStatusBadge } from '@/components/logistics/LogisticsParts';

const dt = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleString('it-IT', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');
const pct = (v: number | null) => (v == null ? '—' : `${Math.round(v * 1000) / 10}%`.replace('.', ','));
const mins = (v: number | null) => (v == null ? '—' : `${String(v).replace('.', ',')} min`);

function useAct() {
  const toast = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const run = async (key: string, fn: () => Promise<unknown>, ok: string, after?: () => void) => {
    setBusy(key);
    try {
      await fn();
      toast(ok);
      after?.();
      return true;
    } catch (e) {
      toast((e as Error).message, 'error');
      return false;
    } finally {
      setBusy(null);
    }
  };
  return { busy, run };
}

// ═════════════════════════════════════════════════════════════
//  /admin/riders
// ═════════════════════════════════════════════════════════════
export function AdminRiders() {
  useSeo({ title: 'Admin · Rider', noindex: true });
  const [params, setParams] = useSearchParams();
  const status = params.get('status') ?? '';
  const [q, setQ] = useState('');
  const list = useAsync(() => api.adminListRiders({ status: status || undefined, q: q || undefined }), [status, q]);
  const [openId, setOpenId] = useState<string | null>(null);
  return (
    <div>
      <PageTitle title="Rider" subtitle="Candidature, documenti e stato dei Rider AsiaFood. Il ruolo Rider lo assegna solo l’Admin con l’approvazione." />
      <div className="mb-4 flex flex-wrap gap-2">
        {[['', 'Tutti'], ['pending', 'In attesa'], ['approved', 'Approvati'], ['active', 'Attivi'], ['suspended', 'Sospesi'], ['rejected', 'Rifiutati']].map(([v, l]) => (
          <Chip key={v} active={status === v} onClick={() => setParams(v ? { status: v } : {}, { replace: true })}>{l}</Chip>
        ))}
        <Input className="!h-10 max-w-xs" aria-label="Cerca Rider" placeholder="Nome o città" onKeyDown={(e) => e.key === 'Enter' && setQ((e.target as HTMLInputElement).value.trim())} />
      </div>
      {list.loading && !list.data ? <PageLoader /> : list.error ? <Alert tone="error">{list.error.message}</Alert> : !(list.data ?? []).length ? (
        <EmptyState icon="🛵" title="Nessun Rider" text="Con questi filtri non ci sono Rider." />
      ) : (
        <div className="overflow-x-auto rounded-4xl border border-line bg-white">
          <table className="w-full min-w-[860px] text-left text-sm" data-testid="admin-riders">
            <thead><tr className="border-b border-line text-xs uppercase tracking-wider text-ink-muted">
              <th className="px-4 py-3">Nome</th><th className="px-4 py-3">Città</th><th className="px-4 py-3">Veicolo</th><th className="px-4 py-3">Stato</th>
              <th className="px-4 py-3">Online</th><th className="px-4 py-3 text-right">Consegne</th><th className="px-4 py-3">Documenti</th><th className="px-4 py-3">Ultima attività</th>
            </tr></thead>
            <tbody>
              {list.data!.map((r) => (
                <tr key={r.id} className="cursor-pointer border-t border-line hover:bg-cream/50" onClick={() => setOpenId(r.id)}>
                  <td className="px-4 py-3"><button type="button" className="font-semibold hover:text-coral-700" onClick={() => setOpenId(r.id)}>{r.name}</button>{r.is_demo && <Badge tone="amber" className="ml-2">DEMO</Badge>}</td>
                  <td className="px-4 py-3">{r.city}</td>
                  <td className="px-4 py-3">{VEHICLE_LABEL[r.vehicle_type]}</td>
                  <td className="px-4 py-3"><RiderStatusBadge status={r.status} /></td>
                  <td className="px-4 py-3">{r.is_online ? <Badge tone={r.busy ? 'amber' : 'green'}>{r.busy ? 'Occupato' : 'Online'}</Badge> : <span className="text-ink-muted">Offline</span>}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{r.total_deliveries}</td>
                  <td className="px-4 py-3">{r.documents}{r.documents_pending > 0 && <Badge tone="amber" className="ml-2">{r.documents_pending} da verificare</Badge>}</td>
                  <td className="px-4 py-3 text-ink-muted">{dt(r.last_activity)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <RiderSheet id={openId} onClose={() => setOpenId(null)} onChanged={list.reload} />
    </div>
  );
}

function RiderSheet({ id, onClose, onChanged }: { id: string | null; onClose: () => void; onChanged: () => void }) {
  const [d, setD] = useState<AdminRiderDetail | null>(null);
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const { busy, run } = useAct();
  const load = useCallback(async () => {
    if (!id) return;
    const x = await api.adminRiderDetail(id);
    setD(x);
    setNotes(x.admin_notes ?? '');
  }, [id]);
  useEffect(() => {
    setD(null);
    setReason('');
    void load();
  }, [load]);
  const action = (a: 'approve' | 'reject' | 'suspend' | 'reactivate' | 'note', msg: string, r?: string) => run(a, () => api.adminRiderAction(id!, a, r ?? reason), msg, () => { void load(); onChanged(); });
  const openDoc = async (path: string) => {
    const url = await api.adminRiderDocumentUrl(path).catch(() => null);
    if (url) window.open(url, '_blank', 'noopener');
    else window.alert('DEMO: il file non è stato caricato (in produzione si apre con un link temporaneo di 2 minuti).');
  };
  return (
    <Sheet open={!!id} onClose={onClose} title={d ? `${d.first_name} ${d.last_name}` : 'Rider'} wide>
      {!d ? <div className="flex justify-center py-10"><Spinner className="h-8 w-8" /></div> : (
        <div className="space-y-5" data-testid="admin-rider-detail">
          <div className="flex flex-wrap items-center gap-2">
            <RiderStatusBadge status={d.status} />
            <Badge tone="neutral">{VEHICLE_LABEL[d.vehicle_type]}{d.vehicle_details ? ` · ${d.vehicle_details}` : ''}</Badge>
            {d.availability?.is_online && <Badge tone="green">Online</Badge>}
          </div>
          <dl className="grid gap-2 text-sm sm:grid-cols-2">
            <div><dt className="text-ink-muted">Contatti</dt><dd>{d.phone} · {d.email}</dd></div>
            <div><dt className="text-ink-muted">Zona</dt><dd>{d.city}</dd></div>
            <div><dt className="text-ink-muted">Consegne</dt><dd>{d.total_deliveries} · valutazione interna {d.ratings.average ?? '—'} ({d.ratings.count})</dd></div>
            <div><dt className="text-ink-muted">Compensi</dt><dd>da pagare {formatPrice(d.earnings.pending)} · pagati {formatPrice(d.earnings.paid)}</dd></div>
          </dl>
          {d.suspension_reason && <Alert tone="error">Sospeso: {d.suspension_reason}</Alert>}
          <section>
            <h3 className="mb-2 font-bold">Documenti (privati)</h3>
            <ul className="space-y-2 text-sm">
              {d.documents.map((doc) => (
                <li key={doc.id} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-line p-3">
                  <span><FileText className="mr-1 inline h-4 w-4" /> {DOCUMENT_TYPE_LABEL[doc.document_type]} · caricato {dt(doc.uploaded_at)}{doc.expires_at ? ` · scade ${doc.expires_at}` : ''}</span>
                  <span className="flex items-center gap-1.5">
                    <Badge tone={doc.status === 'approved' ? 'green' : doc.status === 'pending' ? 'amber' : 'coral'}>{doc.status}</Badge>
                    <Button size="sm" variant="ghost" onClick={() => void openDoc(doc.storage_path)}>Visualizza</Button>
                    {doc.status !== 'approved' && <Button size="sm" variant="outline" loading={busy === `doc-${doc.id}`} onClick={() => void run(`doc-${doc.id}`, () => api.adminReviewRiderDocument(doc.id, 'approved'), 'Documento approvato.', () => void load())}>Approva</Button>}
                    {doc.status === 'pending' && <Button size="sm" variant="ghost" onClick={() => void run(`docr-${doc.id}`, () => api.adminReviewRiderDocument(doc.id, 'rejected'), 'Documento rifiutato.', () => void load())}>Rifiuta</Button>}
                  </span>
                </li>
              ))}
              {!d.documents.length && <li className="text-ink-muted">Nessun documento.</li>}
            </ul>
          </section>
          <section className="rounded-3xl bg-cream/60 p-4">
            <h3 className="mb-2 font-bold">Azioni</h3>
            <Field label="Motivo (obbligatorio per sospendere)"><Input value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
            <div className="mt-3 flex flex-wrap gap-2">
              {['pending', 'rejected', 'inactive'].includes(d.status) && <Button size="sm" loading={busy === 'approve'} onClick={() => void action('approve', 'Rider approvato.')} data-testid="approve-rider"><UserCheck className="h-4 w-4" /> Approva</Button>}
              {d.status === 'pending' && <Button size="sm" variant="danger" loading={busy === 'reject'} onClick={() => void action('reject', 'Candidatura rifiutata.')}><UserX className="h-4 w-4" /> Rifiuta</Button>}
              {['approved', 'active'].includes(d.status) && <Button size="sm" variant="danger" disabled={reason.trim().length < 3} loading={busy === 'suspend'} onClick={() => void action('suspend', 'Rider sospeso.')}>Sospendi</Button>}
              {['suspended', 'inactive'].includes(d.status) && <Button size="sm" variant="outline" loading={busy === 'reactivate'} onClick={() => void action('reactivate', 'Rider riattivato.')}>Riattiva</Button>}
            </div>
            <Field label="Note interne" className="mt-3"><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
            <Button size="sm" variant="dark" className="mt-2" loading={busy === 'note'} onClick={() => void action('note', 'Nota salvata.', notes)}>Salva nota</Button>
          </section>
          <section>
            <h3 className="mb-2 font-bold">Ultime consegne</h3>
            <ul className="space-y-1 text-sm">
              {d.recent_jobs.map((j) => <li key={j.id} className="flex justify-between gap-2"><span>{j.order_number} · {j.restaurant}</span><JobStatusBadge status={j.status} /></li>)}
              {!d.recent_jobs.length && <li className="text-ink-muted">Nessuna consegna.</li>}
            </ul>
          </section>
          {d.flags.length > 0 && (
            <section>
              <h3 className="mb-2 font-bold">Segnalazioni automatiche (da verificare)</h3>
              <ul className="space-y-1 text-xs">{d.flags.map((f, i) => <li key={i}>{dt(f.created_at)} · {f.message}</li>)}</ul>
            </section>
          )}
        </div>
      )}
    </Sheet>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/dispatch — control center (solo Admin)
// ═════════════════════════════════════════════════════════════
export function AdminDispatch() {
  useSeo({ title: 'Admin · Dispatch', noindex: true });
  const [params, setParams] = useSearchParams();
  const [board, setBoard] = useState<DispatchBoard | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [assignFor, setAssignFor] = useState<string | null>(null);
  const [detail, setDetail] = useState<string | null>(params.get('job'));
  const { busy, run } = useAct();
  const load = useCallback(async () => {
    try {
      setBoard(await api.getDispatchBoard());
      setErr(null);
    } catch (e) {
      setErr((e as Error).message);
    }
  }, []);
  useEffect(() => {
    void load();
    const t = window.setInterval(() => void load(), 10_000);
    return () => window.clearInterval(t);
  }, [load]);
  if (!board) return err ? <Alert tone="error">{err}</Alert> : <PageLoader />;
  const waiting = board.jobs.filter((j) => ['waiting_assignment', 'offered'].includes(j.status));
  const active = board.jobs.filter((j) => !['waiting_assignment', 'offered'].includes(j.status));
  const available = board.riders.filter((r) => !r.busy && r.accepting_orders);
  const busyRiders = board.riders.filter((r) => r.busy);
  const markers = [
    ...board.riders.map((r) => ({ id: `r-${r.id}`, lat: r.latitude, lng: r.longitude, label: `${r.name} · ${r.busy ? 'occupato' : 'disponibile'}`, emoji: r.busy ? '🟠' : '🟢' })),
    ...board.jobs.map((j) => ({ id: `p-${j.id}`, lat: j.pickup.latitude, lng: j.pickup.longitude, label: `Ritiro ${j.order_number} · ${j.restaurant}`, emoji: '🍣' })),
    ...board.jobs.map((j) => ({ id: `d-${j.id}`, lat: j.dropoff.latitude, lng: j.dropoff.longitude, label: `Consegna ${j.order_number}`, emoji: '🏠' })),
  ];
  return (
    <div className="space-y-5">
      <PageTitle title="Dispatch" subtitle="Control center consegne AsiaFood. Posizioni dei Rider visibili solo allo staff autorizzato."
        action={<div className="flex gap-2">
          <Button variant="outline" size="sm" loading={busy === 'tick'} onClick={() => void run('tick', () => api.runLogisticsTick(), 'Scheduler eseguito.', () => void load())}><Play className="h-4 w-4" /> Esegui scheduler</Button>
          <Link to="/admin/logistics/settings" className="inline-flex h-9 items-center gap-1.5 rounded-full border border-line bg-white px-4 text-sm font-semibold"><Settings className="h-4 w-4" /> Impostazioni</Link>
        </div>} />
      {!board.service_enabled && <Alert tone="error">Servizio Rider disattivato: nessuna nuova consegna AsiaFood.</Alert>}
      {!board.auto_dispatch && <Alert>Assegnazione automatica disattivata: assegna le consegne manualmente.</Alert>}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4" data-testid="dispatch-stats">
        <StatTile accent label="Da assegnare" value={waiting.length} />
        <StatTile label="Consegne attive" value={active.length} />
        <StatTile label="Rider disponibili" value={available.length} />
        <StatTile label="Rider occupati" value={busyRiders.length} />
      </div>
      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          <DeliveryMap ariaLabel="Mappa dispatch (solo staff)" className="relative h-[420px] overflow-hidden rounded-4xl border border-line" markers={markers} />
          <p className="text-xs text-ink-muted">🟢 Rider disponibile · 🟠 Rider occupato · 🍣 ritiro · 🏠 consegna. Mappa privata dello staff: non è pubblicata da nessuna parte.</p>
          <section className="card p-5">
            <h2 className="mb-3 text-lg font-bold">Consegne</h2>
            {!board.jobs.length && <p className="text-sm text-ink-muted">Nessuna consegna in corso.</p>}
            <ul className="divide-y divide-line">
              {board.jobs.map((j) => (
                <li key={j.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm" data-testid="dispatch-job">
                  <span className="min-w-0">
                    <button type="button" className="font-mono font-bold hover:text-coral-700" onClick={() => setDetail(j.id)}>{j.order_number}</button> · {j.restaurant}
                    <span className="block text-xs text-ink-muted">{j.rider ? `Rider: ${j.rider.name}` : `In attesa da ${j.waiting_minutes} min · tentativi ${j.dispatch_attempts}`}{j.ready ? ' · pronto' : ''}{j.flags.length ? ` · ${j.flags.join(', ')}` : ''}</span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <JobStatusBadge status={j.status} />
                    {['waiting_assignment', 'offered', 'assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(j.status) && <Button size="sm" variant="outline" onClick={() => setAssignFor(j.id)} data-testid="assign-rider">Assegna</Button>}
                    {j.status === 'waiting_assignment' && <Button size="sm" variant="ghost" loading={busy === `re-${j.id}`} onClick={() => void run(`re-${j.id}`, () => api.adminDeliveryAction(j.id, 'redispatch'), 'Ricerca Rider rilanciata.', () => void load())}><RefreshCw className="h-4 w-4" /></Button>}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        </div>
        <div className="space-y-4">
          <section className="card p-5">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-bold"><AlertTriangle className="h-5 w-5 text-coral" /> Avvisi</h2>
            <ul className="space-y-2 text-sm">
              {board.alerts.map((a) => (
                <li key={a.id} className={cn('rounded-2xl border p-3', a.status === 'open' ? 'border-coral-200 bg-coral-50' : 'border-line')}>
                  <p className="font-semibold">{a.alert_type.replace(/_/g, ' ')}</p>
                  <p className="text-ink-soft">{a.message}</p>
                  <div className="mt-2 flex gap-2">
                    {a.delivery_job_id && <Button size="sm" variant="ghost" onClick={() => setDetail(a.delivery_job_id)}>Apri</Button>}
                    {a.status === 'open' && <Button size="sm" variant="ghost" onClick={() => void run(`ack-${a.id}`, () => api.updateLogisticsAlert(a.id, 'acknowledged'), 'Preso in carico.', () => void load())}>Presa in carico</Button>}
                    <Button size="sm" variant="ghost" onClick={() => void run(`res-${a.id}`, () => api.updateLogisticsAlert(a.id, 'resolved'), 'Risolto.', () => void load())}><CheckCircle2 className="h-4 w-4" /> Risolto</Button>
                  </div>
                </li>
              ))}
              {!board.alerts.length && <li className="text-ink-muted">Nessun avviso aperto.</li>}
            </ul>
          </section>
          <section className="card p-5">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-bold"><Bike className="h-5 w-5 text-coral" /> Rider online</h2>
            <ul className="space-y-1.5 text-sm">
              {board.riders.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-2">
                  <span>{r.name} <span className="text-xs text-ink-muted">· {VEHICLE_LABEL[r.vehicle_type]}</span></span>
                  <Badge tone={r.busy ? 'amber' : 'green'}>{r.busy ? `Occupato ${r.capacity}/${r.max}` : 'Disponibile'}</Badge>
                </li>
              ))}
              {!board.riders.length && <li className="text-ink-muted">Nessun Rider online.</li>}
            </ul>
          </section>
        </div>
      </div>
      <Sheet open={!!assignFor} onClose={() => setAssignFor(null)} title="Assegna Rider">
        <ul className="space-y-2">
          {board.riders.map((r) => (
            <li key={r.id}>
              <Button variant="outline" className="w-full justify-between" disabled={r.capacity >= r.max} loading={busy === `as-${r.id}`}
                onClick={() => void run(`as-${r.id}`, () => api.adminAssignDelivery(assignFor!, r.id), 'Consegna assegnata.', () => { setAssignFor(null); void load(); })}>
                <span>{r.name}</span><span className="text-xs">{r.busy ? 'occupato' : 'disponibile'}</span>
              </Button>
            </li>
          ))}
          {!board.riders.length && <li className="text-sm text-ink-muted">Nessun Rider online.</li>}
        </ul>
        <p className="mt-3 text-xs text-ink-muted">L’assegnazione manuale è registrata nell’audit log.</p>
      </Sheet>
      <JobDetailSheet id={detail} onClose={() => { setDetail(null); if (params.get('job')) setParams({}, { replace: true }); }} onChanged={() => void load()} />
    </div>
  );
}

export function JobDetailSheet({ id, onClose, onChanged }: { id: string | null; onClose: () => void; onChanged?: () => void }) {
  const [d, setD] = useState<AdminJobDetail | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const [amount, setAmount] = useState('');
  const { busy, run } = useAct();
  const load = useCallback(async () => {
    if (!id) return;
    try {
      setD(await api.adminDeliveryDetail(id));
      setErr(null);
    } catch (e) {
      setErr((e as Error).message);
    }
  }, [id]);
  useEffect(() => {
    setD(null);
    void load();
  }, [load]);
  const act = (a: 'redispatch' | 'release' | 'mark_failed' | 'mark_delivered' | 'cancel', msg: string) =>
    run(a, () => api.adminDeliveryAction(d!.id, a, { reason }), msg, () => { void load(); onChanged?.(); });
  return (
    <Sheet open={!!id} onClose={onClose} title={d ? `Consegna ${d.order_number}` : 'Consegna'} wide>
      {err ? <Alert tone="error">{err}</Alert> : !d ? <div className="flex justify-center py-10"><Spinner className="h-8 w-8" /></div> : (
        <div className="space-y-5" data-testid="delivery-timeline">
          <div className="flex flex-wrap items-center gap-2">
            <JobStatusBadge status={d.status} />
            <Badge tone="neutral">Ordine: {d.order_status}</Badge>
            {d.flags.map((f) => <Badge key={f} tone="coral">{f}</Badge>)}
            <Link to={`/admin/orders?q=${d.order_number}`} className="text-sm font-semibold text-coral-700">Apri ordine →</Link>
          </div>
          <dl className="grid gap-2 text-sm sm:grid-cols-3">
            <div><dt className="text-ink-muted">Rider</dt><dd>{d.rider ? `${d.rider.name} · ${d.rider.phone}` : '—'}</dd></div>
            <div><dt className="text-ink-muted">Distanza</dt><dd>{d.estimated_distance_km ?? '—'} km</dd></div>
            <div><dt className="text-ink-muted">Attesa al ristorante</dt><dd>{mins(d.waiting_minutes)}</dd></div>
            <div><dt className="text-ink-muted">Prova di consegna</dt><dd>{d.proof_type}{d.delivery_code_required ? ' + codice' : ''}</dd></div>
            <div><dt className="text-ink-muted">Tentativi / riassegnazioni</dt><dd>{d.dispatch_attempts} / {d.reassignment_count}</dd></div>
            <div><dt className="text-ink-muted">Punti GPS conservati</dt><dd>{d.location_points}</dd></div>
          </dl>
          <section>
            <h3 className="mb-2 font-bold">Timeline</h3>
            <ol className="max-h-72 space-y-1 overflow-y-auto text-xs">
              {d.events.map((e, i) => (
                <li key={i} className="flex gap-3"><span className="shrink-0 tabular-nums text-ink-muted">{dt(e.created_at)}</span><span className="font-semibold">{JOB_STATUS_LABEL[e.type as keyof typeof JOB_STATUS_LABEL] ?? e.type.replace(/_/g, ' ')}</span><span className="text-ink-muted">{e.actor}</span></li>
              ))}
            </ol>
          </section>
          <section>
            <h3 className="mb-2 font-bold">Tentativi di assegnazione</h3>
            <ul className="space-y-1 text-xs">
              {d.assignments.map((x) => <li key={x.id}>{dt(x.offered_at)} · {x.rider} · <strong>{x.status}</strong>{x.manual ? ' (manuale)' : ''}{x.distance_to_pickup_km != null ? ` · ${x.distance_to_pickup_km} km` : ''}{x.rejection_reason ? ` · ${x.rejection_reason}` : ''}</li>)}
              {!d.assignments.length && <li className="text-ink-muted">Nessuno.</li>}
            </ul>
          </section>
          {(d.issues.length > 0 || d.rating) && (
            <section className="text-sm">
              <h3 className="mb-2 font-bold">Segnalazioni e valutazione</h3>
              {d.issues.map((x) => <p key={x.id}>{x.reported_by_type} · {x.issue_type} · {x.status}{x.description ? ` — ${x.description}` : ''}</p>)}
              {d.rating && <p>Valutazione cliente: {d.rating.rating}/5{d.rating.comment ? ` — ${d.rating.comment}` : ''}</p>}
            </section>
          )}
          <section className="text-sm">
            <h3 className="mb-2 font-bold">Compensi</h3>
            {d.earnings.map((e) => (
              <div key={e.id} className="flex flex-wrap items-center justify-between gap-2 py-1">
                <span>{formatPrice(e.total)} · {e.status}{e.note ? ` · ${e.note}` : ''}</span>
                <span className="flex gap-1">
                  {e.status === 'pending' && <Button size="sm" variant="ghost" onClick={() => void run(`ap-${e.id}`, () => api.adminEarningAction(e.id, 'approve'), 'Approvato.', () => void load())}>Approva</Button>}
                  {['pending', 'approved'].includes(e.status) && <Button size="sm" variant="ghost" onClick={() => void run(`pd-${e.id}`, () => api.adminEarningAction(e.id, 'mark_paid', null, 'Registrato da Admin'), 'Registrato come pagato.', () => void load())}>Segna pagato</Button>}
                </span>
              </div>
            ))}
            {!d.earnings.length && ['failed', 'cancelled'].includes(d.status) && (
              <div className="mt-2 flex flex-wrap gap-2">
                <Input className="!h-10 w-28" inputMode="decimal" placeholder="€" value={amount} onChange={(e) => setAmount(e.target.value)} aria-label="Importo compenso" />
                <Button size="sm" variant="outline" disabled={!(Number(amount.replace(',', '.')) > 0) || reason.trim().length < 3}
                  onClick={() => void run('earn', () => api.adminEarningCreate(d.id, Number(amount.replace(',', '.')), reason.trim()), 'Compenso registrato.', () => void load())}>Registra compenso (motivo sotto)</Button>
              </div>
            )}
          </section>
          <section className="rounded-3xl bg-cream/60 p-4">
            <Field label="Motivo (registrato nell’audit)"><Input value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
            <div className="mt-3 flex flex-wrap gap-2">
              {d.status === 'waiting_assignment' && <Button size="sm" variant="outline" loading={busy === 'redispatch'} onClick={() => void act('redispatch', 'Ricerca rilanciata.')}>Rilancia ricerca</Button>}
              {['assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(d.status) && <Button size="sm" variant="outline" loading={busy === 'release'} onClick={() => void act('release', 'Consegna rilasciata e ridistribuita.')}>Rilascia (prima del ritiro)</Button>}
              {['picked_up', 'rider_to_customer', 'arrived_customer'].includes(d.status) && <Button size="sm" variant="outline" disabled={reason.trim().length < 3} loading={busy === 'mark_delivered'} onClick={() => void act('mark_delivered', 'Consegna chiusa manualmente.')}>Segna consegnata</Button>}
              {!['delivered', 'failed', 'cancelled'].includes(d.status) && <Button size="sm" variant="danger" disabled={reason.trim().length < 3} loading={busy === 'mark_failed'} onClick={() => void act('mark_failed', 'Consegna segnata come non riuscita.')}>Non riuscita</Button>}
              {!['delivered', 'failed', 'cancelled'].includes(d.status) && <Button size="sm" variant="danger" disabled={reason.trim().length < 3} loading={busy === 'cancel'} onClick={() => void act('cancel', 'Consegna annullata.')}>Annulla consegna</Button>}
            </div>
            <p className="mt-2 text-xs text-ink-muted">Dopo il ritiro non c’è riassegnazione automatica: decide lo staff. Rimborsi e annullamento dell’ordine si gestiscono da Admin → Ordini.</p>
          </section>
        </div>
      )}
    </Sheet>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/logistics — metriche, compensi, regole, zone
// ═════════════════════════════════════════════════════════════
export function AdminLogistics() {
  useSeo({ title: 'Admin · Logistica', noindex: true });
  const [days, setDays] = useState(30);
  const stats = useAsync<LogisticsStats>(() => api.getLogisticsStats(days), [days]);
  const s = stats.data;
  return (
    <div className="space-y-6">
      <PageTitle title="Logistica" subtitle="Metriche reali dei Rider AsiaFood (nessuna classifica pubblica)."
        action={<div className="flex gap-2"><Link to="/admin/dispatch" className="inline-flex h-9 items-center rounded-full bg-ink px-4 text-sm font-semibold text-white">Dispatch</Link><Link to="/admin/logistics/settings" className="inline-flex h-9 items-center gap-1.5 rounded-full border border-line bg-white px-4 text-sm font-semibold"><Settings className="h-4 w-4" /> Impostazioni</Link></div>} />
      <div className="flex gap-2" role="group" aria-label="Periodo">{[7, 30, 90].map((d) => <Chip key={d} active={days === d} onClick={() => setDays(d)}>{d} giorni</Chip>)}</div>
      {stats.loading && !s ? <PageLoader /> : stats.error ? <Alert tone="error">{stats.error.message}</Alert> : s && (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-5" data-testid="logistics-stats">
            <StatTile accent label="Consegne attive" value={s.active} />
            <StatTile label="In attesa di Rider" value={s.waiting_assignment} />
            <StatTile label="Consegnate" value={s.delivered} hint={`${s.failed} non riuscite · ${s.cancelled} annullate`} />
            <StatTile label="Puntualità" value={pct(s.on_time_rate)} />
            <StatTile label="Rider online" value={s.riders_online} hint={`Utilizzo ${pct(s.utilization)}`} />
            <StatTile label="Tempo di assegnazione" value={mins(s.avg_assignment_minutes)} />
            <StatTile label="Tempo al ritiro" value={mins(s.avg_pickup_minutes)} />
            <StatTile label="Tempo di consegna" value={mins(s.avg_delivery_minutes)} />
            <StatTile label="Attesa al ristorante" value={mins(s.avg_wait_minutes)} />
            <StatTile label="Compensi da pagare" value={formatPrice(s.earnings.pending)} hint={`Pagati nel periodo ${formatPrice(s.earnings.paid_period)}`} />
          </div>
          <div className="grid gap-6 lg:grid-cols-2">
            <section className="card p-5 text-sm">
              <h2 className="mb-2 text-lg font-bold">Offerte</h2>
              <p>Inviate {s.offers.sent} · accettate {s.offers.accepted} · rifiutate {s.offers.rejected} · scadute {s.offers.expired}</p>
              <p className="mt-1 text-ink-muted">Rider attivi {s.riders_total} · candidature in attesa <Link className="font-semibold text-coral-700" to="/admin/riders?status=pending">{s.riders_pending}</Link> · avvisi aperti {s.open_alerts}</p>
            </section>
            <section className="card p-5 text-sm">
              <h2 className="mb-2 text-lg font-bold">Attese ai ristoranti</h2>
              {!s.slow_restaurants.length ? <p className="text-ink-muted">Nessun dato nel periodo.</p> : (
                <table className="w-full"><thead><tr className="text-left text-xs uppercase text-ink-muted"><th>Ristorante</th><th className="text-right">Consegne</th><th className="text-right">Attesa media</th><th className="text-right">"Non pronto"</th></tr></thead>
                  <tbody>{s.slow_restaurants.map((x) => <tr key={x.restaurant} className="border-t border-line"><td className="py-1">{x.restaurant}</td><td className="text-right">{x.deliveries}</td><td className="text-right">{mins(x.avg_wait_minutes)}</td><td className="text-right">{x.not_ready_reports}</td></tr>)}</tbody></table>
              )}
            </section>
          </div>
          <section className="card p-5 text-sm">
            <h2 className="mb-2 text-lg font-bold">Definizioni</h2>
            <dl className="grid gap-2 sm:grid-cols-2">{Object.entries(s.definitions).map(([k, v]) => <div key={k}><dt className="font-semibold">{k}</dt><dd className="text-ink-muted">{v}</dd></div>)}</dl>
          </section>
        </>
      )}
      <EarningsPanel />
      <RulesPanel />
      <ZonesPanel />
    </div>
  );
}

function EarningsPanel() {
  const list = useAsync(() => api.adminListEarnings(), []);
  const { busy, run } = useAct();
  const [filter, setFilter] = useState<'open' | 'all'>('open');
  const rows = (list.data ?? []).filter((e) => filter === 'all' || ['pending', 'approved'].includes(e.status));
  return (
    <section className="card p-5" data-testid="admin-earnings">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-bold">Compensi Rider</h2>
        <div className="flex gap-2"><Chip active={filter === 'open'} onClick={() => setFilter('open')}>Da pagare</Chip><Chip active={filter === 'all'} onClick={() => setFilter('all')}>Tutti</Chip></div>
      </div>
      <p className="mb-3 text-xs text-ink-muted">Nessun trasferimento automatico: “Segna pagato” registra un pagamento eseguito fuori piattaforma (bonifico). Architettura pronta per Stripe Connect / SEPA.</p>
      <ul className="divide-y divide-line text-sm">
        {rows.map((e) => (
          <li key={e.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
            <span>{e.rider_name} · {e.order_number ?? 'Rettifica'} · <strong>{formatPrice(e.total)}</strong> <Badge tone={e.status === 'paid' ? 'green' : e.status === 'cancelled' ? 'coral' : 'amber'}>{e.status}</Badge></span>
            <span className="flex gap-1">
              {e.status === 'pending' && <Button size="sm" variant="ghost" loading={busy === `a-${e.id}`} onClick={() => void run(`a-${e.id}`, () => api.adminEarningAction(e.id, 'approve'), 'Approvato.', list.reload)}>Approva</Button>}
              {['pending', 'approved'].includes(e.status) && <Button size="sm" variant="outline" loading={busy === `p-${e.id}`} onClick={() => void run(`p-${e.id}`, () => api.adminEarningAction(e.id, 'mark_paid', null, 'Bonifico registrato'), 'Registrato come pagato.', list.reload)}>Segna pagato</Button>}
            </span>
          </li>
        ))}
        {!rows.length && <li className="py-2 text-ink-muted">Nessun compenso.</li>}
      </ul>
    </section>
  );
}

function RulesPanel() {
  const { cities } = useReferenceData();
  const list = useAsync(() => api.listCompensationRules(), []);
  const { busy, run } = useAct();
  const [draft, setDraft] = useState<Partial<CompensationRule> | null>(null);
  const n = (v: string) => (v.trim() === '' ? null : Number(v.replace(',', '.')));
  return (
    <section className="card p-5">
      <h2 className="text-lg font-bold">Regole compensi</h2>
      <p className="mb-3 text-xs text-ink-muted">Compenso = max(minimo, base + €/km × distanza ristorante→cliente), con tetto alla quota distanza. Bonus meteo/picco solo manuali: nessun prezzo dinamico automatico.</p>
      <ul className="divide-y divide-line text-sm">
        {(list.data ?? []).map((k) => (
          <li key={k.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
            <span>{k.city_id ? cities.find((c) => c.id === k.city_id)?.name : 'Tutte le città'} · base {formatPrice(k.base_fee)} + {formatPrice(k.per_km_fee)}/km · min {formatPrice(k.minimum_fee)}{k.max_distance_fee != null ? ` · max distanza ${formatPrice(k.max_distance_fee)}` : ''} {k.is_active ? <Badge tone="green">Attiva</Badge> : <Badge tone="neutral">Non attiva</Badge>}</span>
            <Button size="sm" variant="ghost" onClick={() => setDraft(k)}>Modifica</Button>
          </li>
        ))}
      </ul>
      {draft ? (
        <div className="mt-3 grid gap-3 rounded-3xl bg-cream/60 p-4 sm:grid-cols-3">
          <Field label="Città"><Select value={draft.city_id ?? ''} onChange={(e) => setDraft({ ...draft, city_id: e.target.value || null })}><option value="">Tutte</option>{cities.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
          <Field label="Base (€)"><Input inputMode="decimal" value={draft.base_fee ?? ''} onChange={(e) => setDraft({ ...draft, base_fee: n(e.target.value) ?? 0 })} /></Field>
          <Field label="€/km"><Input inputMode="decimal" value={draft.per_km_fee ?? ''} onChange={(e) => setDraft({ ...draft, per_km_fee: n(e.target.value) ?? 0 })} /></Field>
          <Field label="Minimo (€)"><Input inputMode="decimal" value={draft.minimum_fee ?? ''} onChange={(e) => setDraft({ ...draft, minimum_fee: n(e.target.value) ?? 0 })} /></Field>
          <Field label="Tetto quota distanza (€)"><Input inputMode="decimal" value={draft.max_distance_fee ?? ''} onChange={(e) => setDraft({ ...draft, max_distance_fee: n(e.target.value) })} /></Field>
          <div className="flex items-end"><Toggle label="Attiva" checked={draft.is_active ?? true} onChange={(v) => setDraft({ ...draft, is_active: v })} /></div>
          <div className="flex gap-2 sm:col-span-3">
            <Button loading={busy === 'rule'} onClick={() => void run('rule', () => api.saveCompensationRule(draft), 'Regola salvata (vale per le nuove consegne).', () => { setDraft(null); list.reload(); })}>Salva</Button>
            <Button variant="ghost" onClick={() => setDraft(null)}>Annulla</Button>
          </div>
        </div>
      ) : <Button variant="outline" className="mt-3" onClick={() => setDraft({ base_fee: 3, per_km_fee: 0.6, minimum_fee: 4, max_distance_fee: 6, is_active: true })}>Nuova regola</Button>}
    </section>
  );
}

function ZonesPanel() {
  const { cities } = useReferenceData();
  const list = useAsync(() => api.listServiceZones(), []);
  const { busy, run } = useAct();
  const [draft, setDraft] = useState<Partial<ServiceZone> | null>(null);
  return (
    <section className="card p-5">
      <h2 className="text-lg font-bold">Zone servite dai Rider</h2>
      <p className="mb-3 text-xs text-ink-muted">Ristorante e cliente devono trovarsi in una zona attiva. Consigliato iniziare con Taranto e provincia.</p>
      <ul className="divide-y divide-line text-sm">
        {(list.data ?? []).map((z) => (
          <li key={z.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
            <span>{z.name} · raggio {z.radius_km} km {z.is_active ? <Badge tone="green">Attiva</Badge> : <Badge tone="neutral">Non attiva</Badge>}</span>
            <span className="flex gap-1">
              <Button size="sm" variant="ghost" onClick={() => setDraft(z)}>Modifica</Button>
              <Button size="sm" variant="ghost" onClick={() => void run(`del-${z.id}`, () => api.deleteServiceZone(z.id), 'Zona eliminata.', list.reload)}>Elimina</Button>
            </span>
          </li>
        ))}
      </ul>
      {draft ? (
        <div className="mt-3 grid gap-3 rounded-3xl bg-cream/60 p-4 sm:grid-cols-3">
          <Field label="Nome"><Input value={draft.name ?? ''} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Città"><Select value={draft.city_id ?? ''} onChange={(e) => {
            const c = cities.find((x) => x.id === e.target.value);
            setDraft({ ...draft, city_id: e.target.value || null, center_latitude: c?.latitude ?? draft.center_latitude, center_longitude: c?.longitude ?? draft.center_longitude });
          }}><option value="">—</option>{cities.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
          <Field label="Raggio (km)"><Input inputMode="decimal" value={draft.radius_km ?? ''} onChange={(e) => setDraft({ ...draft, radius_km: Number(e.target.value.replace(',', '.')) })} /></Field>
          <Field label="Centro lat"><Input inputMode="decimal" value={draft.center_latitude ?? ''} onChange={(e) => setDraft({ ...draft, center_latitude: Number(e.target.value) })} /></Field>
          <Field label="Centro lng"><Input inputMode="decimal" value={draft.center_longitude ?? ''} onChange={(e) => setDraft({ ...draft, center_longitude: Number(e.target.value) })} /></Field>
          <div className="flex items-end"><Toggle label="Attiva" checked={draft.is_active ?? true} onChange={(v) => setDraft({ ...draft, is_active: v })} /></div>
          <div className="flex gap-2 sm:col-span-3">
            <Button loading={busy === 'zone'} onClick={() => void run('zone', () => api.saveServiceZone(draft), 'Zona salvata.', () => { setDraft(null); list.reload(); })}>Salva</Button>
            <Button variant="ghost" onClick={() => setDraft(null)}>Annulla</Button>
          </div>
        </div>
      ) : <Button variant="outline" className="mt-3" onClick={() => setDraft({ name: '', radius_km: 5, is_active: true })}>Nuova zona</Button>}
    </section>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/logistics/settings
// ═════════════════════════════════════════════════════════════
export function AdminLogisticsSettings() {
  useSeo({ title: 'Admin · Impostazioni logistica', noindex: true });
  const data = useAsync(() => api.getLogisticsSettings(), []);
  const [f, setF] = useState<LogisticsSettings | null>(null);
  const { busy, run } = useAct();
  useEffect(() => {
    if (data.data) setF(data.data);
  }, [data.data]);
  if (!f) return <PageLoader />;
  const set = <K extends keyof LogisticsSettings>(k: K, v: LogisticsSettings[K]) => setF({ ...f, [k]: v });
  const numField = (k: keyof LogisticsSettings, label: string, hint?: string) => (
    <Field key={k} label={label} hint={hint}><Input inputMode="numeric" value={String(f[k])} onChange={(e) => set(k, Number(e.target.value.replace(',', '.')) as never)} /></Field>
  );
  return (
    <div className="space-y-6" data-testid="logistics-settings">
      <PageTitle title="Impostazioni logistica" subtitle="Valgono per le nuove consegne. Nessun prezzo dinamico o bonus automatico." />
      <section className="card p-5">
        <h2 className="mb-2 text-lg font-bold">Servizio e dispatch</h2>
        <div className="divide-y divide-line">
          <Toggle label="Servizio Rider AsiaFood attivo" checked={f.enabled} onChange={(v) => set('enabled', v)} />
          <Toggle label="Assegnazione automatica (auto_dispatch_enabled)" checked={f.auto_dispatch_enabled} onChange={(v) => set('auto_dispatch_enabled', v)} />
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          {numField('initial_search_radius', 'Raggio iniziale (km)')}
          {numField('max_search_radius', 'Raggio massimo (km)', 'Oltre non si cerca')}
          <Field label="Raggi di ricerca (km)" hint="Es. 3,5,8,10"><Input value={f.search_radii} onChange={(e) => set('search_radii', e.target.value)} /></Field>
          {numField('offer_timeout_seconds', 'Timeout offerta (s)')}
          {numField('max_dispatch_attempts', 'Tentativi automatici max')}
          {numField('default_rider_capacity', 'Consegne contemporanee per Rider', 'MVP: 1')}
          <Field label="Quando cercare il Rider"><Select value={f.dispatch_strategy} onChange={(e) => set('dispatch_strategy', e.target.value as LogisticsSettings['dispatch_strategy'])}>
            <option value="immediate">Subito dopo l’accettazione</option><option value="before_ready">X minuti prima di “pronto”</option></Select></Field>
          {numField('dispatch_before_ready_minutes', 'Minuti prima di “pronto”')}
          {numField('alert_unassigned_minutes', 'Avviso: senza Rider dopo (min)')}
        </div>
      </section>
      <section className="card p-5">
        <h2 className="mb-2 text-lg font-bold">Posizione e privacy</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          {numField('location_interval_active', 'Invio posizione in consegna (s)')}
          {numField('location_interval_idle', 'Invio posizione in attesa (s)')}
          {numField('location_retention_hours', 'Conservazione posizioni (ore)')}
          {numField('rider_stale_minutes', 'Avviso: Rider senza aggiornamenti (min)')}
          {numField('document_retention_days', 'Conservazione documenti dopo chiusura (giorni)')}
          {numField('delivery_data_retention_days', 'Anonimizzazione consegne dopo (giorni)')}
        </div>
      </section>
      <section className="card p-5">
        <h2 className="mb-2 text-lg font-bold">Ritiro e consegna</h2>
        <div className="divide-y divide-line">
          <Toggle label="Codice di ritiro richiesto al Rider" checked={f.pickup_code_required} onChange={(v) => set('pickup_code_required', v)} />
          <Toggle label="Codice di consegna (OTP 4 cifre) richiesto" checked={f.delivery_code_required} onChange={(v) => set('delivery_code_required', v)} />
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          <Field label="Prova di consegna"><Select value={f.proof_of_delivery_type} onChange={(e) => set('proof_of_delivery_type', e.target.value as LogisticsSettings['proof_of_delivery_type'])}>
            <option value="confirmation">Conferma del Rider</option><option value="otp">Codice (OTP)</option><option value="photo">Foto del pacco</option></Select></Field>
          {numField('customer_wait_minutes', 'Attesa minima cliente non disponibile (min)')}
        </div>
      </section>
      <Button size="lg" loading={busy === 'save'} onClick={() => void run('save', () => api.saveLogisticsSettings(f), 'Impostazioni salvate.')} data-testid="save-logistics-settings">Salva impostazioni</Button>
      <p className="text-xs text-ink-muted">{RIDER_STATUS_LABEL.active}: i Rider vedono i nuovi intervalli al prossimo aggiornamento dell’app.</p>
    </div>
  );
}
