import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { FEATURE_ORDER, FEATURES, type FeatureKey } from '@/lib/entitlements';
import { cn, formatDate } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import type { PlanCode, PlanUpgradeRequest, PlanWithFeatures } from '@/types/domain';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { EmptyState } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';

/** /admin/plans — prezzi, feature e limiti per piano (nessuna regola scritta nel codice) + lista d'attesa upgrade. */
export default function AdminPlans() {
  const { plans, reloadPlans } = useReferenceData();
  const toast = useToast();
  const requests = useAsync(() => api.listUpgradeRequests(), []);
  const [savingCell, setSavingCell] = useState<string | null>(null);
  useSeo({ title: 'Admin · Piani', noindex: true });
  const sorted = [...plans].sort((a, b) => a.sort_order - b.sort_order);

  const setFeature = async (p: PlanWithFeatures, key: FeatureKey, patch: { enabled: boolean; limit_value: number | null }) => {
    setSavingCell(`${p.code}:${key}`);
    try {
      await api.setPlanFeature(p.code, key, patch);
      await reloadPlans();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setSavingCell(null);
    }
  };

  return (
    <div className="space-y-8">
      <PageTitle
        title="Piani"
        subtitle="Prezzi, funzioni e collegamento a Stripe: le modifiche valgono subito per tutti i locali del piano, senza modificare il frontend."
        action={<ProvisionButton onDone={reloadPlans} />}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {sorted.map((p) => <PlanCard key={p.code} p={p} onSaved={reloadPlans} />)}
      </div>

      <section>
        <h2 className="mb-3 text-xl font-bold">Funzioni e limiti</h2>
        <p className="mb-4 text-sm text-ink-muted">Interruttore = funzione inclusa. Per i limiti, campo vuoto = illimitato. Il database applica queste regole anche se il frontend venisse aggirato.</p>
        <div className="overflow-x-auto rounded-4xl border border-line bg-white">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead>
              <tr className="border-b border-line">
                <th className="px-4 py-3">Funzione</th>
                {sorted.map((p) => <th key={p.code} className="px-4 py-3 text-center">{p.name}</th>)}
              </tr>
            </thead>
            <tbody>
              {FEATURE_ORDER.map((key) => (
                <tr key={key} className="border-t border-line">
                  <td className="px-4 py-2.5">
                    <span className="font-medium">{FEATURES[key].label}</span>
                    <code className="ml-2 text-[11px] text-ink-faint">{key}</code>
                  </td>
                  {sorted.map((p) => {
                    const f = p.plan_features.find((x) => x.feature_key === key);
                    const enabled = !!f?.enabled;
                    const busy = savingCell === `${p.code}:${key}`;
                    return (
                      <td key={p.code} className={cn('px-4 py-2', busy && 'opacity-50')}>
                        <div className="flex items-center justify-center gap-2">
                          <input
                            type="checkbox"
                            className="h-5 w-5 accent-coral"
                            aria-label={`${FEATURES[key].label} nel piano ${p.name}`}
                            checked={enabled}
                            disabled={busy}
                            onChange={(e) => setFeature(p, key, { enabled: e.target.checked, limit_value: f?.limit_value ?? null })}
                          />
                          {FEATURES[key].kind === 'limit' && enabled && (
                            <LimitInput
                              value={f?.limit_value ?? null}
                              label={`Limite ${FEATURES[key].label} nel piano ${p.name}`}
                              onSave={(v) => setFeature(p, key, { enabled: true, limit_value: v })}
                            />
                          )}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-xl font-bold">Richieste di upgrade (lista d’attesa)</h2>
        {(requests.data ?? []).length === 0 ? (
          <EmptyState icon="📨" title="Nessuna richiesta" text="Quando un ristoratore preme “Passa a …” la richiesta compare qui." />
        ) : (
          <ul className="space-y-3">
            {requests.data!.map((x) => <RequestRow key={x.id} x={x} onDone={requests.reload} />)}
          </ul>
        )}
      </section>
    </div>
  );
}

function ProvisionButton({ onDone }: { onDone: () => Promise<void> }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const run = async () => {
    if (!confirm('Creare o aggiornare su Stripe prodotti e prezzi dai prezzi attuali? In modalità test non ci sono addebiti.')) return;
    setBusy(true);
    try {
      const r = await api.adminBilling<{ environment: string; plans: Record<string, unknown> }>('provision_prices');
      await onDone();
      toast(`Prezzi Stripe (${r.environment}) allineati per ${Object.keys(r.plans).length} piani`);
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return <Button variant="outline" loading={busy} onClick={run}>Crea/aggiorna prezzi su Stripe</Button>;
}

function LimitInput({ value, onSave, label }: { value: number | null; onSave: (v: number | null) => void; label: string }) {
  const [v, setV] = useState(value === null ? '' : String(value));
  const commit = () => {
    const next = v.trim() === '' ? null : Math.max(0, Math.floor(Number(v)));
    if (next !== value && (next === null || Number.isFinite(next))) onSave(next);
  };
  return (
    <input
      aria-label={label}
      inputMode="numeric"
      placeholder="∞"
      className="h-8 w-16 rounded-lg border border-line px-2 text-center text-sm tabular-nums focus:border-ink focus:outline-none"
      value={v}
      onChange={(e) => setV(e.target.value.replace(/[^\d]/g, ''))}
      onBlur={commit}
      onKeyDown={(e) => e.key === 'Enter' && commit()}
    />
  );
}

function PlanCard({ p, onSaved }: { p: PlanWithFeatures; onSaved: () => Promise<void> }) {
  const toast = useToast();
  const [f, setF] = useState({
    name: p.name, monthly_price: String(p.monthly_price), yearly_price: p.yearly_price == null ? '' : String(p.yearly_price), description: p.description ?? '',
    is_active: p.is_active, sort_order: p.sort_order, trial_enabled: p.trial_enabled ?? p.code !== 'free',
    stripe_product_id: p.stripe_product_id ?? '', stripe_monthly_price_id: p.stripe_monthly_price_id ?? '', stripe_yearly_price_id: p.stripe_yearly_price_id ?? '',
  });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    const monthly = Number(f.monthly_price.replace(',', '.'));
    const yearly = f.yearly_price === '' ? null : Number(f.yearly_price.replace(',', '.'));
    if (!f.name.trim() || !Number.isFinite(monthly) || monthly < 0 || (yearly !== null && (!Number.isFinite(yearly) || yearly < 0))) return toast('Controlla nome e prezzi', 'error');
    const idOk = (v: string, prefix: string) => !v.trim() || new RegExp(`^${prefix}_[A-Za-z0-9]+$`).test(v.trim());
    if (!idOk(f.stripe_product_id, 'prod') || !idOk(f.stripe_monthly_price_id, 'price') || !idOk(f.stripe_yearly_price_id, 'price')) return toast('ID Stripe non validi (prod_… / price_…)', 'error');
    setBusy(true);
    try {
      await api.upsert('subscription_plans', {
        code: p.code, name: f.name.trim(), monthly_price: monthly, yearly_price: yearly, description: f.description.trim() || null, is_active: f.is_active, sort_order: f.sort_order,
        trial_enabled: f.trial_enabled, stripe_product_id: f.stripe_product_id.trim() || null,
        stripe_monthly_price_id: f.stripe_monthly_price_id.trim() || null, stripe_yearly_price_id: f.stripe_yearly_price_id.trim() || null,
      }, 'code');
      await onSaved();
      toast(`Piano ${f.name} salvato`);
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="card space-y-3 p-5">
      <div className="flex items-center justify-between"><code className="text-xs text-ink-muted">{p.code}</code>{!p.is_active && <Badge>Non attivo</Badge>}</div>
      <Field label="Nome"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="€ / mese"><Input inputMode="decimal" value={f.monthly_price} onChange={(e) => setF({ ...f, monthly_price: e.target.value })} /></Field>
        <Field label="€ / anno"><Input inputMode="decimal" value={f.yearly_price} onChange={(e) => setF({ ...f, yearly_price: e.target.value })} /></Field>
      </div>
      <Field label="Descrizione"><Textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <Toggle label="Attivo" description="Visibile ai ristoratori" checked={f.is_active} onChange={(v) => setF({ ...f, is_active: v })} />
      {p.code !== 'free' && (
        <>
          <Toggle label="Prova gratuita" description="Durata in Admin → Stripe" checked={f.trial_enabled} onChange={(v) => setF({ ...f, trial_enabled: v })} />
          <details className="rounded-2xl bg-cream px-3 py-2 text-sm">
            <summary className="cursor-pointer font-semibold">Stripe {f.stripe_monthly_price_id ? '✓' : '· prezzi non collegati'}</summary>
            <div className="mt-3 space-y-2">
              <Field label="Product ID"><Input className="font-mono text-xs" value={f.stripe_product_id} onChange={(e) => setF({ ...f, stripe_product_id: e.target.value })} placeholder="prod_…" /></Field>
              <Field label="Price ID mensile"><Input className="font-mono text-xs" value={f.stripe_monthly_price_id} onChange={(e) => setF({ ...f, stripe_monthly_price_id: e.target.value })} placeholder="price_…" /></Field>
              <Field label="Price ID annuale"><Input className="font-mono text-xs" value={f.stripe_yearly_price_id} onChange={(e) => setF({ ...f, stripe_yearly_price_id: e.target.value })} placeholder="price_…" /></Field>
              <p className="text-xs text-ink-muted">Se cambi un prezzo, usa “Crea/aggiorna prezzi su Stripe”: i Price Stripe sono immutabili, ne viene creato uno nuovo (gli abbonati esistenti restano sul precedente).</p>
            </div>
          </details>
        </>
      )}
      <Button className="w-full" loading={busy} onClick={save}>Salva</Button>
    </div>
  );
}

const REQ_STATUS: Record<PlanUpgradeRequest['status'], { label: string; tone: 'amber' | 'green' | 'neutral' }> = {
  open: { label: 'Da contattare', tone: 'amber' },
  contacted: { label: 'Contattato', tone: 'green' },
  closed: { label: 'Chiusa', tone: 'neutral' },
};

function RequestRow({ x, onDone }: { x: PlanUpgradeRequest; onDone: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const setStatus = async (status: PlanUpgradeRequest['status']) => {
    try {
      await api.updateUpgradeRequest(x.id, status);
      onDone();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
  const activate = async () => {
    if (!x.restaurant || !confirm(`Attivare il piano ${x.plan_code.toUpperCase()} per ${x.restaurant.name}? (nessun pagamento online: attivazione manuale)`)) return;
    setBusy(true);
    try {
      await api.adminGrantPlan(x.restaurant.id, x.plan_code as PlanCode, null, 'manual', 'Attivato dalla lista d’attesa');
      await api.updateUpgradeRequest(x.id, 'closed');
      toast('Piano attivato');
      onDone();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <li className="card flex flex-wrap items-center gap-3 p-4">
      <div className="min-w-0 flex-1">
        <p className="font-semibold">
          {x.restaurant ? <Link to={`/admin/restaurants/${x.restaurant.id}/abbonamento`} className="hover:text-coral-700">{x.restaurant.name}</Link> : 'Locale'} · <span className="uppercase">{x.restaurant?.subscription_plan}</span> → <span className="uppercase text-coral-700">{x.plan_code}</span>
          <span className="text-sm font-normal text-ink-muted"> ({x.billing_interval === 'year' ? 'annuale' : 'mensile'})</span>
        </p>
        <p className="text-sm text-ink-muted">{x.requester?.full_name || x.requester?.email} · {formatDate(x.created_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
        {x.message && <p className="mt-1 text-sm">“{x.message}”</p>}
      </div>
      <Badge tone={REQ_STATUS[x.status].tone}>{REQ_STATUS[x.status].label}</Badge>
      <Select className="!h-9 !w-auto !py-0 text-sm" value={x.status} aria-label="Stato richiesta" onChange={(e) => setStatus(e.target.value as PlanUpgradeRequest['status'])}>
        {Object.entries(REQ_STATUS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
      </Select>
      {x.status !== 'closed' && <Button size="sm" variant="dark" loading={busy} onClick={activate}>Attiva piano</Button>}
    </li>
  );
}
