// ─────────────────────────────────────────────────────────────
//  Fase 13 · Mercati, Market Opportunity Score trasparente, Taranto review (target vs actual)
//  e /admin/expansion/next-market: città da ANALIZZARE, mai un lancio automatico.
// ─────────────────────────────────────────────────────────────
import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle2, Circle, Search as SearchIcon } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Field';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import { explainScore, MARKET_SCORE_KEYS, MARKET_SCORE_LABELS, type MarketScoreKey } from '@shared/growth';
import { GOAL_METRIC_LABELS, PLAYBOOK_STAGES, type MarketCandidate, type MarketReadiness } from '@/types/growth';
import { Card, euro, fmtDate, Insufficient, Loadable, n, Note, pctText, rateText, Table } from './shared';

export default function Markets({ view }: { view: 'markets' | 'review' }) {
  return view === 'markets' ? <MarketsView /> : <Review />;
}

function Readiness({ r }: { r: MarketReadiness | null }) {
  if (!r) return <span className="text-xs text-ink-muted">—</span>;
  const items: [keyof MarketReadiness, string][] = [['data', 'Dati'], ['sales', 'Vendite'], ['seo', 'SEO'], ['operational', 'Operatività'], ['launch_ready', 'Pronto al lancio']];
  return (
    <ul className="flex flex-wrap gap-1" aria-label="Readiness">
      {items.map(([k, l]) => {
        const it = r[k] as { ok: boolean; detail: string };
        return <li key={k} title={it.detail} className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold', it.ok ? 'bg-emerald-50 text-emerald-700' : 'bg-cream text-ink-muted')}>
          {it.ok ? <CheckCircle2 className="h-3 w-3" aria-hidden /> : <Circle className="h-3 w-3" aria-hidden />}{l}</li>;
      })}
    </ul>
  );
}

function MarketsView() {
  const m = useAsync(() => api.growth.markets(), []);
  return (
    <Loadable state={m}>{(d) => (
      <div className="space-y-4" data-testid="growth-markets">
        <Card title="Mercati attivi e pianificati" subtitle="Ultimi 30 giorni; crescita del traffico solo con campione sufficiente">
          <Table head={['Mercato', 'Stato', 'Ristoranti', 'Rivendicati', 'Paganti', 'Utenti', 'Ricerche', 'Zero risultati', 'Prenot.', 'Ordini', 'MRR', 'GMV', 'Gap', 'Traffico', 'Readiness']}>
            {d.markets.map((x) => (
              <tr key={x.id} className="align-top">
                <td className="py-2 pr-3 font-semibold">{x.name}</td><td className="py-2 pr-3">{x.status}</td>
                {[x.restaurants, x.claimed, x.paying, x.users, x.searches_30d, x.zero_results_30d, x.reservations_30d, x.orders_30d].map((v, i) => <td key={i} className="py-2 pr-3 tabular-nums">{n(v)}</td>)}
                <td className="py-2 pr-3 tabular-nums">{euro(x.mrr_cents)}</td><td className="py-2 pr-3 tabular-nums">{euro(x.gmv_30d_cents)}</td>
                <td className="py-2 pr-3 tabular-nums">{n(x.supply_gaps)}</td>
                <td className="py-2 pr-3 tabular-nums">{x.traffic_growth_pct == null ? '—' : `${x.traffic_growth_pct > 0 ? '+' : ''}${pctText(x.traffic_growth_pct)}`}</td>
                <td className="py-2 pr-3"><Readiness r={x.readiness} /></td>
              </tr>
            ))}
          </Table>
        </Card>
        <NextCityCards candidates={d.candidates} />
        <p className="text-sm"><Link to="/admin/expansion/next-market" className="font-semibold text-coral-700 hover:underline">Confronto completo e playbook → /admin/expansion/next-market</Link></p>
      </div>
    )}</Loadable>
  );
}

/** Next City Recommendation: città da analizzare (non da lanciare), con punteggio scomposto. */
function NextCityCards({ candidates }: { candidates: MarketCandidate[] }) {
  const withData = candidates.filter((c) => c.data_points > 0 && c.score > 0);
  return (
    <Card title="Prossima città da analizzare" subtitle="Suggerimenti basati su dati reali. Nessuna decisione viene presa automaticamente." testId="next-city">
      {withData.length ? (
        <div className="grid gap-3 md:grid-cols-3">
          {withData.slice(0, 3).map((c, i) => (
            <div key={c.slug} className="rounded-3xl border border-line p-4" data-testid={`candidate-${c.slug}`}>
              <p className="text-xs text-ink-muted">#{i + 1} · {c.region_name}</p>
              <p className="font-display text-xl font-extrabold">{c.name}</p>
              <p className="mt-1 text-2xl font-extrabold tabular-nums">{c.score}<span className="text-sm font-normal text-ink-muted">/100</span></p>
              <p className="mt-1 text-xs text-ink-muted">{explainScore(c.breakdown)}</p>
              <dl className="mt-2 grid grid-cols-2 gap-1 text-xs">
                <dt className="text-ink-muted">Ricerche</dt><dd className="tabular-nums">{n(c.inputs.search_demand)}</dd>
                <dt className="text-ink-muted">Lead potenziali</dt><dd className="tabular-nums">{n(c.inputs.lead_availability)}</dd>
                <dt className="text-ink-muted">Locali censiti</dt><dd className="tabular-nums">{n(c.inputs.supply)}</dd>
                <dt className="text-ink-muted">Utenti del territorio</dt><dd className="tabular-nums">{n(c.inputs.organic_interest)}</dd>
              </dl>
              <Link to={`/admin/expansion/next-market?c=${c.slug}`} className="mt-3 inline-flex text-sm font-semibold text-coral-700 hover:underline">Apri analisi mercato</Link>
            </div>
          ))}
        </div>
      ) : <Insufficient>nessuna città candidata ha ancora segnali reali (ricerche, lead, utenti). Nessuna raccomandazione.</Insufficient>}
    </Card>
  );
}

function Review() {
  const r = useAsync(() => api.growth.marketReview('taranto'), []);
  return (
    <Loadable state={r}>{(d) => (
      <div className="space-y-4" data-testid="taranto-review">
        <Card title={`${d.market.name}: obiettivi vs risultati`} subtitle="Target operativi (non promesse). Gap = quanto manca al target.">
          <Table head={['Metrica', 'Target', 'Attuale', 'Gap', '%', 'Stato', 'Periodo']}>
            {d.goals.map((g) => (
              <tr key={g.metric_key}>
                <td className="py-2 pr-3 font-semibold">{GOAL_METRIC_LABELS[g.metric_key] ?? g.metric_key}</td>
                <td className="py-2 pr-3 tabular-nums">{g.metric_key === 'mrr_cents' ? euro(g.target) : n(g.target)}</td>
                <td className="py-2 pr-3 tabular-nums">{g.actual == null ? '—' : g.metric_key === 'mrr_cents' ? euro(g.actual) : n(g.actual)}</td>
                <td className="py-2 pr-3 tabular-nums">{g.metric_key === 'mrr_cents' ? euro(g.gap) : n(g.gap)}</td>
                <td className="py-2 pr-3 tabular-nums">{pctText(g.pct)}</td>
                <td className="py-2 pr-3">{({ not_started: 'Troppo presto per valutare', on_track: 'In linea', at_risk: 'A rischio', behind: 'In ritardo', achieved: 'Raggiunto' } as Record<string, string>)[g.status] ?? g.status}</td>
                <td className="py-2 pr-3 text-xs">{fmtDate(g.period_start)}–{fmtDate(g.period_end)}</td>
              </tr>
            ))}
          </Table>
        </Card>
        <Card title="Dati correlati" subtitle={d.note}>
          <dl className="grid gap-2 text-sm sm:grid-cols-3">
            <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Rivendicati / censiti</dt><dd className="font-bold">{n(d.correlated.restaurants_claimed)} / {n(d.correlated.restaurants_indexed)} · {rateText(d.correlated.restaurants_claimed, d.correlated.restaurants_indexed)}</dd></div>
            <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Paganti / rivendicati</dt><dd className="font-bold">{n(d.correlated.restaurants_paying)} / {n(d.correlated.restaurants_claimed)} · {rateText(d.correlated.restaurants_paying, d.correlated.restaurants_claimed)}</dd></div>
            <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Prove: avviate · concluse · convertite</dt><dd className="font-bold">{n(d.correlated.trials.started)} · {n(d.correlated.trials.ended)} · {n(d.correlated.trials.converted)}</dd></div>
            <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Ristoranti attivati</dt><dd className="font-bold">{n(d.correlated.activated)}</dd></div>
            <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Utenti tornati entro 30 giorni</dt><dd className="font-bold">{n(d.correlated.users_d30.returned)} / {n(d.correlated.users_d30.eligible)}</dd></div>
            <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Connessioni ultimi 30 giorni</dt><dd className="font-bold">{n(d.correlated.conversions_30d)}</dd></div>
          </dl>
          <h3 className="mt-4 text-sm font-bold">Pipeline commerciale</h3>
          {Object.keys(d.correlated.pipeline).length ? <p className="mt-1 text-sm">{Object.entries(d.correlated.pipeline).map(([k, v]) => `${k}: ${v}`).join(' · ')}</p> : <p className="text-sm text-ink-muted">Nessun lead registrato.</p>}
        </Card>
      </div>
    )}</Loadable>
  );
}

/** /admin/expansion/next-market — confronto candidate, pesi trasparenti, Start Research, playbook. */
export function NextMarketPage() {
  useSeo({ title: 'Prossimo mercato', noindex: true });
  const toast = useToast();
  const [params] = useSearchParams();
  const m = useAsync(() => api.growth.markets(), []);
  const [weights, setWeights] = useState<Record<MarketScoreKey, number> | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const focus = params.get('c');
  const start = async (slug: string) => {
    setBusy(slug);
    try {
      const r = await api.growth.startResearch(slug);
      toast(`Ricerca avviata: ${r.tasks} task e ${r.playbook_items} attività di playbook create. Nessun lancio automatico.`, 'success');
      m.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setBusy(null);
    }
  };
  const saveWeights = async () => {
    try {
      await api.growth.setSetting('growth_market_weights', weights);
      toast('Pesi aggiornati', 'success');
      setWeights(null);
      m.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <div className="space-y-5" data-testid="next-market">
      <div>
        <h1 className="text-2xl font-extrabold">Prossimo mercato</h1>
        <p className="mt-1 text-sm text-ink-muted">Città da analizzare dopo Taranto. Il punteggio aiuta a scegliere cosa studiare: la decisione resta umana.</p>
      </div>
      <Loadable state={m}>{(d) => {
        const w = weights ?? d.weights;
        return (
          <>
            <Card title="Confronto città candidate" subtitle="Input reali degli ultimi 90 giorni. Passa il mouse sul punteggio per la scomposizione." testId="candidates-table">
              <Table head={['Città', 'Domanda', 'Offerta (locali)', 'Supply gap', 'Lead', 'Utenti organici', 'Interesse commerciale', 'SEO', 'Readiness', 'Punteggio', '']}>
                {d.candidates.map((c) => (
                  <tr key={c.slug} className={cn('align-top', focus === c.slug && 'bg-cream/60')}>
                    <td className="py-2 pr-3 font-semibold">{c.name}<p className="text-xs font-normal text-ink-muted">{c.region_name}{!c.has_province && ' · provincia non presente nei dati'}</p></td>
                    <td className="py-2 pr-3 tabular-nums">{n(c.inputs.search_demand)}</td>
                    <td className="py-2 pr-3 tabular-nums">{n(c.inputs.supply)}</td>
                    <td className="py-2 pr-3 tabular-nums">{n(c.inputs.supply_gap)}</td>
                    <td className="py-2 pr-3 tabular-nums">{n(c.inputs.lead_availability)}</td>
                    <td className="py-2 pr-3 tabular-nums">{n(c.inputs.organic_interest)}</td>
                    <td className="py-2 pr-3 tabular-nums">{n(c.inputs.commercial_interest)}</td>
                    <td className="py-2 pr-3 tabular-nums" title="Ricerche senza risultati: pagine che potrebbero rispondere a una domanda reale">{n(c.inputs.zero_results)}</td>
                    <td className="py-2 pr-3"><Readiness r={c.readiness} /></td>
                    <td className="py-2 pr-3" title={explainScore(c.breakdown)}><strong className="tabular-nums">{c.score}</strong><p className="text-xs text-ink-muted">{explainScore(c.breakdown)}</p></td>
                    <td className="py-2 pr-3">
                      {c.status === 'candidate' ? (
                        <Button size="sm" variant="outline" icon={<SearchIcon className="h-4 w-4" />} loading={busy === c.slug} disabled={!c.has_province} onClick={() => void start(c.slug)}>Start Research</Button>
                      ) : <span className="text-xs font-semibold text-emerald-700">Ricerca avviata {c.research_started_at ? fmtDate(c.research_started_at) : ''}</span>}
                    </td>
                  </tr>
                ))}
              </Table>
              <div className="mt-2 space-y-1">
                <Note>“Start Research” crea il mercato in stato pianificato, la checklist del playbook e i task di ricerca. Non contatta nessuno, non spende budget, non lancia nulla.</Note>
                <Note>Discovery Agent e Research Agent non sono disponibili in questa versione: i task di censimento e verifica sono manuali.</Note>
              </div>
            </Card>
            <Card title="Pesi del Market Opportunity Score" subtitle="Modificabili; normalizzati a 100. Ogni componente è confrontato con il valore massimo tra le candidate.">
              <div className="grid gap-3 sm:grid-cols-5">
                {MARKET_SCORE_KEYS.map((k) => (
                  <label key={k} className="text-sm"><span className="block text-ink-muted">{MARKET_SCORE_LABELS[k]}</span>
                    <Input type="number" min={0} max={100} value={w[k] ?? 0} onChange={(e) => setWeights({ ...w, [k]: Math.max(0, Math.min(100, Number(e.target.value) || 0)) })} /></label>
                ))}
              </div>
              {weights && <Button className="mt-3" size="sm" onClick={() => void saveWeights()}>Salva pesi</Button>}
            </Card>
            {d.candidates.filter((c) => c.market_id).map((c) => <Playbook key={c.slug} slug={c.slug} name={c.name} />)}
          </>
        );
      }}</Loadable>
    </div>
  );
}

function Playbook({ slug, name }: { slug: string; name: string }) {
  const p = useAsync(() => api.growth.playbook(slug), [slug]);
  const toggle = (id: string, done: boolean) => void api.growth.setPlaybookItem(id, done).then(p.reload);
  return (
    <Loadable state={p}>{(d) => (
      <Card title={`Playbook di mercato: ${name}`} subtitle="Ricerca → Dati → Vendite → SEO → Partner → Utenti beta → Lancio" testId={`playbook-${slug}`}>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          {PLAYBOOK_STAGES.map((s) => {
            const items = d.items.filter((i) => i.stage === s.key);
            return (
              <div key={s.key} className="rounded-2xl border border-line p-3">
                <h3 className="text-sm font-bold">{s.label} <span className="font-normal text-ink-muted">{items.filter((i) => i.done_at).length}/{items.length}</span></h3>
                <ul className="mt-2 space-y-1.5">
                  {items.map((i) => (
                    <li key={i.id}>
                      <label className="flex cursor-pointer items-start gap-2 text-sm">
                        <input type="checkbox" className="mt-1" checked={!!i.done_at} onChange={(e) => toggle(i.id, e.target.checked)} />
                        <span><span className={cn(i.done_at && 'line-through text-ink-muted')}>{i.title}</span>{i.hint && <span className="block text-xs text-ink-muted">{i.hint}</span>}</span>
                      </label>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
        <h3 className="mt-4 text-sm font-bold">Cosa abbiamo imparato altrove (da verificare, non da copiare)</h3>
        {d.learnings.length ? (
          <ul className="mt-1 space-y-1 text-sm">{d.learnings.map((l) => <li key={l.id}>• <strong>{l.title}</strong> <span className="text-ink-muted">({l.market_slug ?? 'generale'}, confidenza {l.confidence})</span> — {l.description}</li>)}</ul>
        ) : <p className="text-sm text-ink-muted">Nessun apprendimento registrato. Aggiungili da Growth → Task e apprendimenti.</p>}
      </Card>
    )}</Loadable>
  );
}
