// ─────────────────────────────────────────────────────────────
//  Fase 13 · Growth Command Center: in pochi minuti quanti utenti, quanti tornano, quanti ristoranti
//  pagano, MRR, ordini/prenotazioni, cosa fare oggi. Confronti % solo se il periodo precedente è completo.
// ─────────────────────────────────────────────────────────────
import { Link } from 'react-router-dom';
import { ArrowRight, ListChecks } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { api } from '@/services';
import type { GrowthOverview } from '@/types/growth';
import { Card, Columns, CsvButton, DataQuality, DeltaStat, euro, Freshness, GROWTH_BASE, Loadable, n, Note, pctText, RangeBar, useRange } from './shared';

export default function CommandCenter() {
  const r = useRange();
  const ov = useAsync(() => api.growth.overview(r.from, r.to, r.market || null), [r.from, r.to, r.market]);
  const today = useAsync(() => api.growth.today(), []);
  const markets = useAsync(() => api.growth.markets().then((m) => m.markets.map((x) => ({ slug: x.slug, name: x.name }))).catch(() => []), []);
  return (
    <div className="space-y-5" data-testid="growth-command-center">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <RangeBar withMarket markets={markets.data ?? []} />
        {ov.data && <Freshness at={ov.data.freshness.today_at ?? ov.data.freshness.batch_at} live />}
      </div>
      <Loadable state={ov}>{(d) => <Body d={d} />}</Loadable>
      <Card title="Oggi: priorità operative" subtitle="Massimo 10 azioni, ordinate per gravità. Nessuna azione viene eseguita automaticamente." testId="today-brief"
        action={<ListChecks className="h-5 w-5 text-ink-muted" aria-hidden />}>
        <Loadable state={today}>{(items) => items.length ? (
          <ol className="divide-y divide-line">
            {items.map((t, i) => (
              <li key={i} className="flex items-start justify-between gap-3 py-2.5">
                <div>
                  <p className="text-sm font-semibold">{t.title}</p>
                  {t.detail && <p className="text-xs text-ink-muted">{t.detail}</p>}
                </div>
                <Link to={t.link} className="inline-flex shrink-0 items-center gap-1 text-sm font-semibold text-coral-700 hover:underline">Apri <ArrowRight className="h-4 w-4" aria-hidden /></Link>
              </li>
            ))}
          </ol>
        ) : <p className="text-sm text-ink-muted">Nessuna priorità aperta. Gli alert si aggiornano ogni ora.</p>}</Loadable>
      </Card>
    </div>
  );
}

function Body({ d }: { d: GrowthOverview }) {
  const c = d.current;
  const p = d.previous;
  const pc = !!p?.complete;
  const s = d.state;
  return (
    <>
      <DataQuality items={d.data_quality} />
      <section aria-labelledby="cc-users">
        <h2 id="cc-users" className="mb-2 text-sm font-bold uppercase tracking-wide text-ink-muted">Utenti</h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
          <DeltaStat label="Utenti attivi oggi" current={s.users_today} testId="kpi-users-today" hint="Registrati con almeno un accesso" />
          <DeltaStat label="Attivi 7 giorni" current={s.users_7d} />
          <DeltaStat label="Attivi 30 giorni" current={s.users_30d} />
          <DeltaStat label="Nuovi utenti nel periodo" current={c.new_users ?? null} previous={p?.new_users ?? null} previousComplete={pc} testId="kpi-new-users" />
          <DeltaStat label="Tornati entro 30 giorni" current={s.retention_d30} format={(v) => pctText(v)} hint={s.retention_d30 == null ? `Dati insufficienti (< ${d.min_sample} iscritti idonei)` : 'Iscritti 30–180 giorni fa'} />
        </div>
      </section>
      <section aria-labelledby="cc-rest">
        <h2 id="cc-rest" className="mb-2 text-sm font-bold uppercase tracking-wide text-ink-muted">Ristoranti e ricavi</h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
          <DeltaStat label="Ristoranti attivi" current={s.restaurants_active} />
          <DeltaStat label="Rivendicati" current={s.restaurants_claimed} />
          <DeltaStat label="Paganti" current={s.restaurants_paying} testId="kpi-paying" />
          <DeltaStat label="Prove attive" current={s.trials_active} hint={s.trials_expiring_7d ? `${s.trials_expiring_7d} in scadenza entro 7 giorni` : undefined} />
          <DeltaStat label="MRR" current={s.mrr_cents} format={(v) => euro(v)} testId="kpi-mrr" />
        </div>
      </section>
      <section aria-labelledby="cc-act">
        <h2 id="cc-act" className="mb-2 text-sm font-bold uppercase tracking-wide text-ink-muted">Attività nel periodo ({d.range.days} giorni)</h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <DeltaStat label="Visite" current={c.visits} previous={p?.visits ?? null} previousComplete={pc} testId="kpi-visits" />
          <DeltaStat label="Ricerche" current={c.searches} previous={p?.searches ?? null} previousComplete={pc} hint={`${n(c.zero_result_searches)} senza risultati`} />
          <DeltaStat label="Prenotazioni" current={c.reservations} previous={p?.reservations ?? null} previousComplete={pc} />
          <DeltaStat label="Ordini pagati" current={c.orders} previous={p?.orders ?? null} previousComplete={pc} />
          <DeltaStat label="GMV ordini" current={c.gmv_cents} previous={p?.gmv_cents ?? null} previousComplete={pc} format={(v) => euro(v)} />
          <DeltaStat label="Coupon utilizzati" current={c.coupon_redemptions} previous={p?.coupon_redemptions ?? null} previousComplete={pc} />
          <DeltaStat label="Inviti qualificati" current={c.referrals_qualified ?? null} previous={p?.referrals_qualified ?? null} previousComplete={pc} />
          <DeltaStat label="Tasso di conversione" current={d.conversion_rate} format={(v) => pctText(v)}
            hint={d.conversion_rate == null ? `Dati insufficienti (< ${d.min_sample} visite)` : 'Conversioni / visite'} testId="kpi-conversion" />
        </div>
        <Note>Conversioni = prenotazioni inviate + ordini pagati + coupon utilizzati. Il confronto % compare solo se il periodo precedente è interamente aggregato e maggiore di zero.</Note>
      </section>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Visite al giorno" subtitle="Visite di atterraggio (anche senza consenso, nessun identificativo)"
          action={<CsvButton filename={`growth-${d.range.from}-${d.range.to}.csv`} rows={d.series} columns={[{ key: 'date', label: 'Data' }, { key: 'visits', label: 'Visite' },
            { key: 'active_users', label: 'Utenti attivi' }, { key: 'new_users', label: 'Nuovi utenti' }, { key: 'searches', label: 'Ricerche' }, { key: 'reservations', label: 'Prenotazioni' },
            { key: 'orders', label: 'Ordini' }, { key: 'gmv_cents', label: 'GMV (cent)' }]} />}>
          <Columns label="Visite al giorno" data={d.series.map((x) => ({ label: x.date.slice(5), value: x.visits }))} testId="series-visits" />
        </Card>
        <Card title="Prenotazioni + ordini al giorno" subtitle="Dalle tabelle di dominio (mai dal client)">
          <Columns label="Prenotazioni e ordini al giorno" data={d.series.map((x) => ({ label: x.date.slice(5), value: x.reservations + x.orders }))} />
        </Card>
      </div>
      <Card title="Metriche per board e investitori" subtitle="Solo metriche di business, niente vanity metric" testId="board-metrics">
        <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
          <div><dt className="text-ink-muted">MRR</dt><dd className="font-bold">{euro(s.mrr_cents)}</dd></div>
          <div><dt className="text-ink-muted">Ristoranti paganti</dt><dd className="font-bold">{n(s.restaurants_paying)}</dd></div>
          <div><dt className="text-ink-muted">Utenti attivi (30 gg)</dt><dd className="font-bold">{n(s.users_30d)}</dd></div>
          <div><dt className="text-ink-muted">GMV nel periodo</dt><dd className="font-bold">{euro(c.gmv_cents)}</dd></div>
          <div><dt className="text-ink-muted">Retention D30</dt><dd className="font-bold">{pctText(s.retention_d30)}</dd></div>
          <div><dt className="text-ink-muted">Mercati</dt><dd className="font-bold"><Link to={`${GROWTH_BASE}/markets`} className="hover:underline">Vedi mercati</Link></dd></div>
        </dl>
      </Card>
    </>
  );
}
