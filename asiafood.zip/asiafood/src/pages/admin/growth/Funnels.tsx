// ─────────────────────────────────────────────────────────────
//  Fase 13 · Funnel consumer e B2B, retention D1/D7/D30, coorti, segmenti.
//  Dove perdiamo conversioni? Quanti utenti tornano? (definizioni sempre visibili)
// ─────────────────────────────────────────────────────────────
import { funnelSteps } from '@shared/growth';
import { useAsync } from '@/hooks/useAsync';
import { api } from '@/services';
import { SEGMENT_LABELS, type RetentionPoint } from '@/types/growth';
import { Card, Insufficient, Loadable, n, Note, pctText, rateText, RangeBar, Table, useRange } from './shared';

function FunnelView({ stages, minSample, testId }: { stages: { key: string; label: string; value: number }[]; minSample: number; testId: string }) {
  const f = funnelSteps(stages, minSample);
  const max = Math.max(1, ...stages.map((s) => s.value));
  return (
    <div data-testid={testId}>
      <ol className="space-y-2">
        {f.steps.map((s) => (
          <li key={s.key}>
            <div className="flex justify-between gap-3 text-sm"><span className="font-semibold">{s.label}</span>
              <span className="tabular-nums"><strong>{n(s.value)}</strong>{s.pctOfPrev != null && <span className="ml-2 text-ink-muted">{pctText(s.pctOfPrev)} della fase precedente</span>}</span></div>
            <div className="mt-1 h-2.5 rounded-full bg-cream"><div className="h-2.5 rounded-full bg-ink/80" style={{ width: `${(s.value / max) * 100}%` }} /></div>
          </li>
        ))}
      </ol>
      {f.largestDrop ? (
        <p className="mt-3 rounded-2xl bg-amber-50 px-4 py-2.5 text-sm text-amber-900" data-testid={`${testId}-drop`}>
          Perdita maggiore: <strong>{f.largestDrop.from} → {f.largestDrop.to}</strong> (−{f.largestDrop.lostPct.toLocaleString('it-IT')}%).
        </p>
      ) : (
        <p className="mt-3 text-xs text-ink-muted">Drop-off principale non indicato: servono almeno {minSample} unità nella fase di partenza.</p>
      )}
    </div>
  );
}

const retentionText = (p: RetentionPoint, min: number) => (p.eligible >= min ? rateText(p.returned, p.eligible) : null);

export default function Funnels() {
  const r = useRange();
  const f = useAsync(() => api.growth.funnels(r.from, r.to, r.market || null), [r.from, r.to, r.market]);
  const ret = useAsync(() => api.growth.retention(8), []);
  const seg = useAsync(() => api.growth.segments(), []);
  return (
    <div className="space-y-5" data-testid="growth-funnels">
      <RangeBar />
      <Loadable state={f}>{(d) => (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Funnel utenti" subtitle={d.definitions.unit}>
            <FunnelView stages={d.consumer} minSample={d.min_sample} testId="funnel-consumer" />
            <div className="mt-3 space-y-1"><Note>Intenzione: {d.definitions.intent}</Note><Note>Conversione: {d.definitions.conversion}</Note></div>
            <div className="mt-4 rounded-2xl border border-line p-3 text-sm" data-testid="funnel-return">
              <p className="font-semibold">Ritorno</p>
              <p className="mt-1">{n(d.return.returned_users)} su {n(d.return.converted_users)} utenti con una conversione sono tornati entro {d.return.window_days} giorni
                {d.return.converted_users >= d.min_sample ? ` (${rateText(d.return.returned_users, d.return.converted_users)})` : ' — campione insufficiente per una percentuale'}.</p>
              {d.return.window_open > 0 && <p className="text-xs text-ink-muted">{n(d.return.window_open)} hanno ancora la finestra aperta.</p>}
              <Note>{d.definitions.return}</Note>
            </div>
          </Card>
          <Card title="Funnel ristoranti (B2B)" subtitle="Stato cumulativo per fase, dai lead CRM ai paganti">
            <FunnelView stages={d.b2b} minSample={d.min_sample} testId="funnel-b2b" />
            <h3 className="mt-4 text-sm font-bold">Velocità di vendita (media, giorni)</h3>
            <dl className="mt-2 grid grid-cols-2 gap-2 text-sm" data-testid="sales-velocity">
              {([['lead_to_contact', 'Lead → primo contatto'], ['lead_to_claim', 'Lead → rivendicazione'], ['claim_to_trial', 'Rivendicazione → prova'], ['trial_to_paid', 'Prova → pagamento']] as const).map(([k, l]) => (
                <div key={k} className="rounded-2xl bg-cream/60 p-3"><dt className="text-xs text-ink-muted">{l}</dt>
                  <dd className="font-bold">{d.velocity[k].n ? `${d.velocity[k].avg_days?.toLocaleString('it-IT')} gg` : '—'} <span className="text-xs font-normal text-ink-muted">n = {d.velocity[k].n}</span></dd></div>
              ))}
            </dl>
          </Card>
        </div>
      )}</Loadable>
      <Loadable state={ret}>{(d) => (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card title="Retention utenti" subtitle={d.definitions.return} testId="retention">
            <dl className="grid grid-cols-3 gap-2 text-center">
              {(['d1', 'd7', 'd30'] as const).map((k) => (
                <div key={k} className="rounded-2xl bg-cream/60 p-3"><dt className="text-xs font-semibold uppercase">{k.toUpperCase()}</dt>
                  <dd className="font-display text-xl font-extrabold">{retentionText(d.users[k], d.min_sample) ?? '—'}</dd>
                  <dd className="text-xs text-ink-muted">{n(d.users[k].returned)}/{n(d.users[k].eligible)}</dd></div>
              ))}
            </dl>
            {d.users.d1.eligible < d.min_sample && <Insufficient>percentuali mostrate solo con almeno {d.min_sample} iscritti idonei</Insufficient>}
            <div className="mt-2 space-y-1">{(['d1', 'd7', 'd30'] as const).map((k) => <Note key={k}>{k.toUpperCase()}: {d.definitions[k]}</Note>)}</div>
          </Card>
          <Card title="Coorti settimanali" subtitle={d.definitions.cohort} className="lg:col-span-2" testId="cohorts">
            <Table head={['Settimana', 'Iscritti', 'Sett. 0', 'Sett. 1', 'Sett. 2', 'Sett. 3', 'Sett. 4']}>
              {d.cohorts.map((c) => (
                <tr key={c.week}>
                  <td className="py-2 pr-3">{new Date(c.week).toLocaleDateString('it-IT', { day: '2-digit', month: 'short' })}</td>
                  <td className="py-2 pr-3 tabular-nums">{n(c.size)}</td>
                  {c.weeks.map((w, i) => <td key={i} className="py-2 pr-3 tabular-nums">{w == null ? '' : c.size ? `${n(w)} · ${rateText(w, c.size)}` : '—'}</td>)}
                </tr>
              ))}
            </Table>
          </Card>
          <Card title="Retention ristoranti" subtitle={d.definitions.restaurant} className="lg:col-span-3">
            <dl className="grid gap-2 text-sm sm:grid-cols-3">
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Prova → pagante</dt><dd className="font-bold">{rateText(d.restaurants.trial_to_paid.converted, d.restaurants.trial_to_paid.ended)} <span className="font-normal text-ink-muted">({n(d.restaurants.trial_to_paid.converted)}/{n(d.restaurants.trial_to_paid.ended)} prove concluse)</span></dd></div>
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Pagante mese 1 → 2</dt><dd className="font-bold">{rateText(d.restaurants.paid_m1_m2.retained, d.restaurants.paid_m1_m2.base)} <span className="font-normal text-ink-muted">({n(d.restaurants.paid_m1_m2.retained)}/{n(d.restaurants.paid_m1_m2.base)})</span></dd></div>
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Pagante mese 2 → 3</dt><dd className="font-bold">{rateText(d.restaurants.paid_m2_m3.retained, d.restaurants.paid_m2_m3.base)} <span className="font-normal text-ink-muted">({n(d.restaurants.paid_m2_m3.retained)}/{n(d.restaurants.paid_m2_m3.base)})</span></dd></div>
            </dl>
          </Card>
        </div>
      )}</Loadable>
      <Loadable state={seg}>{(d) => (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Segmenti clienti" subtitle="Solo conteggi, nessuna lista di persone. Contattabili per marketing solo con consenso." testId="segments-customers">
            <Table head={['Segmento', 'Utenti', 'Con consenso marketing']}>
              {d.customers.map((s) => <tr key={s.key}><td className="py-2 pr-3" title={d.definitions[s.key]}>{SEGMENT_LABELS[s.key] ?? s.key}</td><td className="py-2 pr-3 tabular-nums">{n(s.count)}</td><td className="py-2 pr-3 tabular-nums">{n(s.marketing_consent)}</td></tr>)}
            </Table>
            <Note>Passa il mouse sul nome del segmento per la definizione.</Note>
          </Card>
          <Card title="Segmenti ristoranti" testId="segments-restaurants">
            <Table head={['Segmento', 'Ristoranti']}>
              {d.restaurants.map((s) => <tr key={s.key}><td className="py-2 pr-3">{SEGMENT_LABELS[s.key] ?? s.key}</td><td className="py-2 pr-3 tabular-nums">{n(s.count)}</td></tr>)}
            </Table>
          </Card>
        </div>
      )}</Loadable>
    </div>
  );
}
