// ─────────────────────────────────────────────────────────────
//  Fase 13 · Domanda: ricerche, zero risultati, supply gap; offerte, menu, AI, referral,
//  loyalty, recensioni; feedback e supporto. Dati anonimi e aggregati.
// ─────────────────────────────────────────────────────────────
import { ListPlus } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Field';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { api } from '@/services';
import { FEEDBACK_CATEGORY_LABELS, type FeedbackCategory, type SearchRow, type SupplyGapRow } from '@/types/growth';
import { BarList, Card, CsvButton, euro, fmtDate, Insufficient, Loadable, n, Note, pctText, RangeBar, rateText, Stat, Table, useRange } from './shared';

export default function Demand({ view }: { view: 'search' | 'engagement' | 'voice' }) {
  return (
    <div className="space-y-5">
      <RangeBar withMarket={view === 'search'} markets={[{ slug: 'taranto', name: 'Taranto e provincia' }]} />
      {view === 'search' && <Search />}
      {view === 'engagement' && <Engagement />}
      {view === 'voice' && <Voice />}
    </div>
  );
}

const searchLabel = (x: { query: string | null; category: string | null; city: string | null }) => [x.category ?? x.query, x.city].filter(Boolean).join(' · ') || '(solo filtri)';
const gapLabel = (x: SupplyGapRow) => [x.category ?? (x.term ? `“${x.term}”` : null), x.city].filter(Boolean).join(' · ');

function Search() {
  const r = useRange();
  const toast = useToast();
  const s = useAsync(() => api.growth.search(r.from, r.to, r.market || null), [r.from, r.to, r.market]);
  const task = async (x: SupplyGapRow) => {
    try {
      await api.growth.upsertTask({ title: `Cercare ristoranti ${(x.category ?? x.term ?? '').toLowerCase()} a ${x.city}`.slice(0, 200), source: 'insight',
        source_ref: `gap:${x.city_slug}:${x.category_slug ?? x.term}`, priority: x.score >= 60 ? 'high' : 'normal',
        description: `${x.searches} ricerche, ${x.zero_results} senza risultati, ${x.supply} locali disponibili (${fmtDate(r.from)}–${fmtDate(r.to)}). Nessun contatto automatico.` });
      toast('Task creato in Growth → Task', 'success');
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <Loadable state={s}>{(d) => (
      <div className="space-y-4" data-testid="growth-search">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat label="Ricerche registrate" value={n(d.totals.searches)} />
          <Stat label="Senza risultati" value={n(d.totals.zero_results)} hint={rateText(d.totals.zero_results, d.totals.searches)} tone={d.totals.zero_results ? 'warn' : undefined} testId="search-zero" />
          <Stat label="Dall'assistente AI" value={n(d.totals.ai_searches)} />
          <Stat label="Seguite da una scheda" value={d.conversion.with_session >= d.min_sample ? rateText(d.conversion.converted, d.conversion.with_session) : '—'}
            hint={d.conversion.with_session >= d.min_sample ? `${n(d.conversion.converted)} su ${n(d.conversion.with_session)} con consenso` : `Campione < ${d.min_sample} ricerche con consenso`} />
        </div>
        <Card title="Supply gap: domanda senza offerta" subtitle={d.definitions.supply_gap} testId="supply-gap"
          action={<CsvButton filename={`supply-gap-${r.from}-${r.to}.csv`} rows={d.supply_gap.map((x) => ({ ...x, label: gapLabel(x) }))} columns={[{ key: 'label', label: 'Comune / categoria' },
            { key: 'searches', label: 'Ricerche' }, { key: 'zero_results', label: 'Senza risultati' }, { key: 'zero_pct', label: '% senza risultati' }, { key: 'supply', label: 'Locali disponibili' }, { key: 'score', label: 'Opportunity score' }]} />}>
          {d.supply_gap.length ? (
            <Table head={['Comune · categoria', 'Ricerche', 'Senza risultati', 'Locali disponibili', 'Opportunity score', '']}>
              {d.supply_gap.map((x) => (
                <tr key={`${x.city_slug}-${x.category_slug}-${x.term}`}>
                  <td className="py-2 pr-3 font-semibold">{gapLabel(x)}{x.ai_searches > 0 && <span className="ml-1 text-xs text-ink-muted">({x.ai_searches} da AI)</span>}</td>
                  <td className="py-2 pr-3 tabular-nums">{n(x.searches)}</td>
                  <td className="py-2 pr-3 tabular-nums">{n(x.zero_results)} · {x.zero_pct}%</td>
                  <td className="py-2 pr-3 tabular-nums">{n(x.supply)}</td>
                  <td className="py-2 pr-3 tabular-nums" title={`Domanda +${x.breakdown.demand}, zero risultati +${x.breakdown.zero_results}, offerta scarsa +${x.breakdown.low_supply}`}>
                    <strong>{x.score}</strong> <span className="text-xs text-ink-muted">(+{x.breakdown.demand} domanda, +{x.breakdown.zero_results} zero, +{x.breakdown.low_supply} offerta)</span></td>
                  <td className="py-2 pr-3"><Button size="sm" variant="outline" icon={<ListPlus className="h-4 w-4" />} onClick={() => void task(x)}>Crea task</Button></td>
                </tr>
              ))}
            </Table>
          ) : <Insufficient>nessuna combinazione comune/categoria con abbastanza ricerche nel periodo</Insufficient>}
        </Card>
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Ricerche senza risultati" subtitle={d.definitions.zero_result} testId="zero-results">
            {d.zero_results.length ? (
              <ul className="divide-y divide-line text-sm">
                {d.zero_results.slice(0, 20).map((x: SearchRow, i) => (
                  <li key={i} className="flex justify-between gap-3 py-2"><span className="font-semibold">{searchLabel(x)}</span>
                    <span className="tabular-nums">{n(x.searches)} ricerche — <strong>{n(x.zero_results)}</strong> senza risultati</span></li>
                ))}
              </ul>
            ) : <p className="text-sm text-ink-muted">Nessuna ricerca senza risultati nel periodo.</p>}
          </Card>
          <Card title="Ricerche più frequenti" subtitle="Con demand score (0–100)">
            <Table head={['Ricerca', 'Ricerche', 'Sessioni', 'Seguite da scheda', 'Score']}>
              {d.top.slice(0, 20).map((x, i) => (
                <tr key={i}><td className="py-2 pr-3">{searchLabel(x)}</td><td className="py-2 pr-3 tabular-nums">{n(x.searches)}</td><td className="py-2 pr-3 tabular-nums">{n(x.sessions)}</td>
                  <td className="py-2 pr-3 tabular-nums">{x.with_session ? `${n(x.converted ?? 0)}/${n(x.with_session)}` : '—'}</td><td className="py-2 pr-3 tabular-nums">{x.demand_score}</td></tr>
              ))}
            </Table>
            <div className="mt-2"><Note>{d.definitions.demand_score}</Note></div>
          </Card>
          <Card title="Categorie cercate"><BarList rows={d.categories.map((x) => ({ label: x.name ?? x.slug, value: x.searches, hint: x.zero_results ? `· ${x.zero_results} senza risultati` : undefined }))} /></Card>
          <Card title="Comuni cercati"><BarList rows={d.cities.map((x) => ({ label: x.name ?? x.slug, value: x.searches, hint: x.zero_results ? `· ${x.zero_results} senza risultati` : undefined }))} /></Card>
        </div>
        <Note>{d.definitions.privacy}</Note>
      </div>
    )}</Loadable>
  );
}

function Engagement() {
  const r = useRange();
  const e = useAsync(() => api.growth.engagement(r.from, r.to), [r.from, r.to]);
  return (
    <Loadable state={e}>{(d) => (
      <div className="space-y-4" data-testid="growth-engagement">
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Coupon e offerte che funzionano" subtitle={`${n(d.offers.views)} visualizzazioni di offerte nel periodo`}>
            {d.offers.coupons.length ? (
              <Table head={['Coupon', 'Ristorante', 'Richiesti', 'Utilizzati', 'Utilizzo', 'Ordini']}>
                {d.offers.coupons.slice(0, 15).map((c) => <tr key={c.id}><td className="py-2 pr-3">{c.title}</td><td className="py-2 pr-3">{c.restaurant}</td><td className="py-2 pr-3 tabular-nums">{n(c.claims)}</td>
                  <td className="py-2 pr-3 tabular-nums">{n(c.redemptions)}</td><td className="py-2 pr-3 tabular-nums">{rateText(c.redemptions, c.claims)}</td><td className="py-2 pr-3 tabular-nums">{n(c.orders)}</td></tr>)}
              </Table>
            ) : <p className="text-sm text-ink-muted">Nessun coupon richiesto nel periodo.</p>}
            <h3 className="mt-3 text-sm font-bold">Tipi di offerta</h3>
            {d.offers.by_type.length ? <BarList rows={d.offers.by_type.map((x) => ({ label: x.discount_type, value: x.claims, hint: `· ${rateText(x.redemptions, x.claims)} utilizzati` }))} />
              : <Insufficient>servono almeno {d.min_sample} richieste per tipo di offerta</Insufficient>}
          </Card>
          <Card title="Piatti: visti, aggiunti, ordinati" subtitle="Dai clic sui piatti e dagli ordini pagati">
            {d.menu.items.length ? (
              <Table head={['Piatto', 'Ristorante', 'Viste', 'Carrello', 'Ordinati', 'Ordini/viste']}>
                {d.menu.items.slice(0, 15).map((x) => <tr key={x.id}><td className="py-2 pr-3">{x.name}</td><td className="py-2 pr-3">{x.restaurant}</td><td className="py-2 pr-3 tabular-nums">{n(x.views)}</td>
                  <td className="py-2 pr-3 tabular-nums">{n(x.add_to_cart)}</td><td className="py-2 pr-3 tabular-nums">{n(x.ordered)}</td><td className="py-2 pr-3 tabular-nums">{pctText(x.order_rate)}</td></tr>)}
              </Table>
            ) : <p className="text-sm text-ink-muted">Nessun piatto aperto nel periodo.</p>}
            {d.menu.searched_terms.length > 0 && <><h3 className="mt-3 text-sm font-bold">Termini cercati (non categorie)</h3>
              <BarList rows={d.menu.searched_terms.map((x) => ({ label: x.term, value: x.searches, hint: x.zero_results ? `· ${x.zero_results} senza risultati` : undefined }))} /></>}
          </Card>
          <Card title="Assistente AI" subtitle={d.ai.note} testId="growth-ai">
            <dl className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3">
              {[['Richieste', n(d.ai.queries)], ['Errori', n(d.ai.errors)], ['Clic sui risultati', `${n(d.ai.result_clicks)} · ${rateText(d.ai.result_clicks, d.ai.queries)}`],
                ['Mappa aperta', n(d.ai.map_opens)], ['Prenotazioni da AI', `${n(d.ai.bookings)} · ${rateText(d.ai.bookings, d.ai.queries)}`], ['Ordini da AI', `${n(d.ai.orders)} · ${rateText(d.ai.orders, d.ai.queries)}`],
                ['Senza risultati', n(d.ai.no_results)], ['Costo stimato', euro(d.ai.cost_cents)], ['Costo per conversione assistita', d.ai.cost_per_assisted_conversion_cents == null ? '—' : euro(d.ai.cost_per_assisted_conversion_cents)]].map(([l, v]) => (
                <div key={l} className="rounded-2xl bg-cream/60 p-3"><dt className="text-xs text-ink-muted">{l}</dt><dd className="font-bold">{v}</dd></div>
              ))}
            </dl>
            {d.ai.no_result_top.length > 0 && <><h3 className="mt-3 text-sm font-bold">Richieste AI senza risultati (alimentano il supply gap)</h3>
              <BarList rows={d.ai.no_result_top.map((x) => ({ label: [x.category, x.term, x.city].filter(Boolean).join(' · '), value: x.count }))} /></>}
            <h3 className="mt-3 text-sm font-bold">Intenti</h3>
            <BarList rows={d.ai.intents.map((x) => ({ label: x.intent, value: x.count }))} />
          </Card>
          <div className="space-y-4">
            <Card title="Inviti (referral)">
              <dl className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3">
                <div><dt className="text-ink-muted">Condivisi</dt><dd className="font-bold">{n(d.referral.shared)}</dd></div>
                <div><dt className="text-ink-muted">Iscritti</dt><dd className="font-bold">{n(d.referral.registered)}</dd></div>
                <div><dt className="text-ink-muted">Qualificati</dt><dd className="font-bold">{n(d.referral.qualified)} · {rateText(d.referral.qualified, d.referral.registered)}</dd></div>
                <div><dt className="text-ink-muted">Punti emessi</dt><dd className="font-bold">{n(d.referral.points_issued)}</dd></div>
                <div><dt className="text-ink-muted">Costo equivalente</dt><dd className="font-bold">{d.referral.point_value_cents == null ? 'non configurato' : euro(d.referral.points_issued * d.referral.point_value_cents)}</dd></div>
                <div><dt className="text-ink-muted">K-factor</dt><dd className="font-bold">{d.referral.k_factor ?? '—'}</dd></div>
              </dl>
              <div className="mt-2"><Note>{d.referral.k_factor_note}</Note></div>
            </Card>
            <Card title="AsiaPoints">
              <dl className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3">
                <div><dt className="text-ink-muted">Punti assegnati</dt><dd className="font-bold">{n(d.loyalty.points_issued)}</dd></div>
                <div><dt className="text-ink-muted">Punti usati</dt><dd className="font-bold">{n(d.loyalty.points_redeemed)}</dd></div>
                <div><dt className="text-ink-muted">Saldo in circolazione</dt><dd className="font-bold">{n(d.loyalty.outstanding)}</dd></div>
                <div><dt className="text-ink-muted">Premi riscattati</dt><dd className="font-bold">{n(d.loyalty.reward_claims)}</dd></div>
                <div><dt className="text-ink-muted">Clienti abituali</dt><dd className="font-bold">{n(d.loyalty.repeat_users)}</dd></div>
              </dl>
            </Card>
            <Card title="Recensioni">
              <dl className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3">
                <div><dt className="text-ink-muted">Nuove</dt><dd className="font-bold">{n(d.reviews.new)}</dd></div>
                <div><dt className="text-ink-muted">Verificate</dt><dd className="font-bold">{rateText(d.reviews.verified, d.reviews.new)}</dd></div>
                <div><dt className="text-ink-muted">Voto medio</dt><dd className="font-bold">{d.reviews.avg_rating ?? '—'}</dd></div>
                <div><dt className="text-ink-muted">Con risposta</dt><dd className="font-bold">{rateText(d.reviews.responded, d.reviews.new)}</dd></div>
                <div><dt className="text-ink-muted">Recensori tornati</dt><dd className="font-bold">{d.reviews.reviewers >= d.min_sample ? rateText(d.reviews.reviewers_returned, d.reviews.reviewers) : '—'}</dd></div>
              </dl>
              <div className="mt-2"><Note>{d.reviews.note}</Note></div>
            </Card>
          </div>
        </div>
      </div>
    )}</Loadable>
  );
}

function Voice() {
  const r = useRange();
  const toast = useToast();
  const v = useAsync(() => api.growth.voice(r.from, r.to), [r.from, r.to]);
  const setCat = (id: string, c: string) => api.growth.setFeedbackCategory(id, c || null).then(() => { toast('Categoria aggiornata', 'success'); v.reload(); }, (e) => toast(friendlyError(e), 'error'));
  return (
    <Loadable state={v}>{(d) => (
      <div className="grid gap-4 lg:grid-cols-2" data-testid="growth-voice">
        <Card title="Feedback di prodotto" subtitle={`Basato su ${n(d.feedback.total)} feedback. ${d.feedback.summary_basis}`}>
          <BarList rows={d.feedback.by_category.map((x) => ({ label: FEEDBACK_CATEGORY_LABELS[x.category as FeedbackCategory] ?? x.category, value: x.count }))} empty="Nessun feedback nel periodo." />
          <div className="mt-4 space-y-3">
            {d.feedback.by_category.filter((x) => x.recent?.length).map((x) => (
              <div key={x.category}>
                <h3 className="text-sm font-bold">{FEEDBACK_CATEGORY_LABELS[x.category as FeedbackCategory] ?? x.category}</h3>
                <ul className="mt-1 space-y-1.5 text-sm">
                  {x.recent!.map((m) => (
                    <li key={m.id} className="rounded-2xl bg-cream/60 p-2.5">
                      <p>“{m.message}”</p>
                      <div className="mt-1 flex items-center justify-between gap-2 text-xs text-ink-muted"><span>{fmtDate(m.created_at)}{m.page ? ` · ${m.page}` : ''}</span>
                        <Select aria-label="Categoria" className="h-8 w-44 text-xs" value={x.category === 'uncategorized' ? '' : x.category} onChange={(e) => void setCat(m.id, e.target.value)}>
                          <option value="">Da classificare</option>
                          {(['bug', 'feature_request', 'ux', 'restaurant_data', 'pricing', 'delivery', 'other'] as const).map((k) => <option key={k} value={k}>{FEEDBACK_CATEGORY_LABELS[k]}</option>)}
                        </Select></div>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <p className="mt-3 text-sm">NPS: {n(d.feedback.nps.responses)} risposte · {n(d.feedback.nps.promoters)} promotori · {n(d.feedback.nps.detractors)} detrattori</p>
        </Card>
        <Card title="Supporto" subtitle={`Categorie ricorrenti (≥ ${d.support.insight_threshold} ticket) diventano segnali di prodotto`}>
          <dl className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
            <div><dt className="text-ink-muted">Ticket</dt><dd className="font-bold">{n(d.support.total)}</dd></div>
            <div><dt className="text-ink-muted">Aperti</dt><dd className="font-bold">{n(d.support.open)}</dd></div>
            <div><dt className="text-ink-muted">Riaperture</dt><dd className="font-bold">{n(d.support.reopened)}</dd></div>
            <div><dt className="text-ink-muted">Risoluzione (mediana)</dt><dd className="font-bold">{d.support.median_resolution_hours == null ? '—' : `${d.support.median_resolution_hours} h`}</dd></div>
          </dl>
          <div className="mt-3"><BarList rows={d.support.by_category.map((x) => ({ label: x.category, value: x.count }))} empty="Nessun ticket nel periodo." /></div>
          {d.support.product_insights.length > 0 && (
            <ul className="mt-3 space-y-1.5" data-testid="support-insights">{d.support.product_insights.map((x) => <li key={x.category} className="rounded-2xl bg-amber-50 px-3 py-2 text-sm text-amber-900">{x.message}</li>)}</ul>
          )}
        </Card>
      </div>
    )}</Loadable>
  );
}
