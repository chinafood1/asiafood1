// ─────────────────────────────────────────────────────────────
//  Fase 13 · Operazioni growth: alert, automazioni (kill switch, approvazioni, storico),
//  esperimenti (guardrail, report), report settimanali, task e apprendimenti, scenari,
//  Admin AI Analyst (strumenti controllati, niente SQL), dati e impostazioni.
// ─────────────────────────────────────────────────────────────
import { useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Check, FlaskConical, Play, Power, RefreshCw, Send, ShieldAlert, X } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Chip } from '@/components/ui/Badge';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { api } from '@/services';
import {
  analystRoute, ANALYST_QUESTIONS, CHURN_REASON_LABELS, experimentVerdict, forecast, FORECAST_LABELS, FORECAST_SCENARIOS, type AnalystTool, type ForecastAssumptions, type ForecastScenario,
} from '@shared/growth';
import type { AutomationRule, GrowthExperiment, GuardrailArea } from '@/types/growth';
import { Card, channelLabel, CsvButton, euro, fmtDate, fmtDateTime, Freshness, GROWTH_BASE, Insufficient, Loadable, n, Note, pctText, rateText, RangeBar, Table, useRange } from './shared';

export default function Operations({ view }: { view: 'alerts' | 'automations' | 'experiments' | 'reports' | 'tasks' | 'forecast' | 'analyst' | 'data' }) {
  return (
    <div className="space-y-5">
      {view === 'alerts' && <Alerts />}
      {view === 'automations' && <Automations />}
      {view === 'experiments' && <Experiments />}
      {view === 'reports' && <Reports />}
      {view === 'tasks' && <Tasks />}
      {view === 'forecast' && <Forecast />}
      {view === 'analyst' && <Analyst />}
      {view === 'data' && <DataSettings />}
    </div>
  );
}

function useAct() {
  const toast = useToast();
  return async (fn: () => Promise<unknown>, ok?: string, after?: () => void) => {
    try {
      await fn();
      if (ok) toast(ok, 'success');
      after?.();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
}

// ─── Alert ───
function Alerts() {
  const [status, setStatus] = useState('open');
  const act = useAct();
  const a = useAsync(() => api.growth.alerts(status), [status]);
  const sev = { critical: 'border-coral-200 bg-coral-50', warning: 'border-amber-200 bg-amber-50', info: 'border-line bg-cream/60' };
  const label = { critical: 'Critico', warning: 'Attenzione', info: 'Info' };
  return (
    <Card title="Alert" subtitle="Segnalazioni con soglie minime (nessuna reazione su numeri piccoli). Si chiudono da sole quando il problema scompare."
      action={<Button size="sm" variant="outline" icon={<RefreshCw className="h-4 w-4" />} onClick={() => void act(() => api.growth.refreshAlerts(), 'Alert aggiornati', a.reload)}>Aggiorna ora</Button>}
      testId="growth-alerts">
      <div className="mb-3 flex gap-1.5">{[['open', 'Aperti'], ['acknowledged', 'Presi in carico'], ['resolved', 'Risolti']].map(([k, l]) => <Chip key={k} active={status === k} onClick={() => setStatus(k!)}>{l}</Chip>)}</div>
      <Loadable state={a}>{(list) => list.length ? (
        <ul className="space-y-2">
          {list.map((x) => (
            <li key={x.id} className={cn('rounded-2xl border p-3', sev[x.severity])} data-testid="alert-item">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wide">{label[x.severity]}</p>
                  <p className="font-semibold">{x.title}</p>
                  {x.detail && <p className="text-sm">{x.detail}</p>}
                  <p className="mt-1 text-xs text-ink-muted">Dal {fmtDateTime(x.first_seen_at)} · ultimo controllo {fmtDateTime(x.last_seen_at)}</p>
                </div>
                <div className="flex gap-1.5">
                  {x.link && <Link to={x.link} className="inline-flex h-9 items-center rounded-full border border-line bg-white px-3 text-sm font-semibold">Apri</Link>}
                  {x.status === 'open' && <Button size="sm" variant="outline" onClick={() => void act(() => api.growth.setAlert(x.id, 'acknowledged'), 'Preso in carico', a.reload)}>Prendi in carico</Button>}
                  {x.status !== 'resolved' && <Button size="sm" variant="ghost" onClick={() => void act(() => api.growth.setAlert(x.id, 'resolved'), 'Risolto', a.reload)}>Risolvi</Button>}
                </div>
              </div>
            </li>
          ))}
        </ul>
      ) : <p className="text-sm text-ink-muted">Nessun alert in questo stato.</p>}</Loadable>
    </Card>
  );
}

// ─── Automazioni ───
const AUDIENCE: Record<AutomationRule['audience'], string> = { consumer: 'Clienti', restaurant: 'Ristoranti', sales: 'Vendite' };
const ACTION: Record<AutomationRule['action'], string> = { create_crm_task: 'Crea task CRM interno', owner_notification: 'Notifica al titolare', draft_user_message: 'Bozza di messaggio (da approvare)', unavailable: 'Non disponibile' };

function Automations() {
  const act = useAct();
  const toast = useToast();
  const rules = useAsync(() => api.growth.automationRules(), []);
  const items = useAsync(() => api.growth.automationItems('pending_approval'), []);
  const runs = useAsync(() => api.growth.automationRuns(null), []);
  const reload = () => { rules.reload(); items.reload(); runs.reload(); };
  return (
    <div className="space-y-4" data-testid="growth-automations">
      <Loadable state={rules}>{(d) => (
        <>
          <div className={cn('flex flex-wrap items-center justify-between gap-3 rounded-3xl border p-4', d.kill_switch ? 'border-coral-200 bg-coral-50' : 'border-line bg-white')}>
            <div className="flex items-start gap-2">
              <Power className="mt-0.5 h-5 w-5" aria-hidden />
              <div><p className="font-bold">Interruttore generale {d.kill_switch ? 'ATTIVO: nessuna automazione viene eseguita' : 'disattivo'}</p>
                <p className="text-sm text-ink-muted">Blocca immediatamente tutte le automazioni (manuali e pianificate).</p></div>
            </div>
            <Button variant={d.kill_switch ? 'dark' : 'danger'} size="sm" data-testid="kill-switch" onClick={() => void act(() => api.growth.setKillSwitch(!d.kill_switch), d.kill_switch ? 'Automazioni riattivate' : 'Automazioni bloccate', reload)}>
              {d.kill_switch ? 'Riattiva automazioni' : 'Blocca tutte le automazioni'}</Button>
          </div>
          <Card title="Regole" subtitle="Ogni regola è disattivabile e registrata. I messaggi agli utenti restano bozze finché un Admin non li approva, e solo con consenso marketing.">
            <ul className="divide-y divide-line">
              {d.rules.map((r) => (
                <li key={r.id} className="py-3" data-testid={`rule-${r.key}`}>
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="max-w-2xl">
                      <p className="font-semibold">{r.name} <span className="ml-1 rounded-full bg-cream px-2 py-0.5 text-xs font-normal">{AUDIENCE[r.audience]}</span></p>
                      <p className="text-sm text-ink-muted">{r.description}</p>
                      <p className="mt-1 text-xs text-ink-muted">Azione: {ACTION[r.action]}{r.requires_approval && r.action === 'draft_user_message' ? ' · approvazione obbligatoria' : ''}{r.consent_required ? ' · solo con consenso marketing' : ''}
                        {' · '}ogni {r.interval_minutes >= 1440 ? `${r.interval_minutes / 1440} g` : `${r.interval_minutes} min`}
                        {' · '}ultima esecuzione: {r.last_run ? `${fmtDateTime(r.last_run.started_at)} (${r.last_run.status}${r.last_run.records_affected ? `, ${r.last_run.records_affected} elementi` : ''})` : 'mai'}
                        {r.next_run_at && ` · prossima: ${fmtDateTime(r.next_run_at)}`}{r.owner_name && ` · responsabile: ${r.owner_name}`}</p>
                      {r.failure_count > 0 && <p className="mt-1 text-xs font-semibold text-coral-700">{r.failure_count} errori consecutivi: {r.last_error}</p>}
                      {r.pending_items > 0 && <p className="mt-1 text-xs font-semibold text-amber-800">{r.pending_items} bozze in attesa di approvazione</p>}
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {r.action !== 'unavailable' && <Toggle checked={r.enabled} label={r.enabled ? 'Attiva' : 'Disattiva'} onChange={(v) => void act(() => api.growth.updateAutomationRule(r.id, { enabled: v }), v ? 'Regola attivata' : 'Regola disattivata', reload)} />}
                      <Button size="sm" variant="outline" icon={<FlaskConical className="h-4 w-4" />} onClick={() => void api.growth.runAutomation(r.id, true).then(
                        (res) => { toast(res.status === 'success' ? `Prova a vuoto: ${res.records_affected} elementi verrebbero creati (nulla è stato scritto).` : `Esito: ${res.status}`, res.status === 'success' ? 'success' : 'error'); runs.reload(); },
                        (e) => toast(friendlyError(e), 'error'))}>Prova a vuoto</Button>
                      <Button size="sm" variant="outline" icon={<Play className="h-4 w-4" />} disabled={!r.enabled || d.kill_switch}
                        onClick={() => void act(async () => { const res = await api.growth.runAutomation(r.id, false); if (res.status === 'failed') throw new Error(res.error ?? 'Errore'); }, 'Eseguita', reload)}>Esegui ora</Button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </Card>
        </>
      )}</Loadable>
      <Card title="Bozze in attesa di approvazione" subtitle="Nessun messaggio parte senza approvazione. Il consenso viene ricontrollato al momento dell'invio. I dati di contatto non sono mostrati." testId="approvals">
        <Loadable state={items}>{(list) => list.length ? (
          <ul className="divide-y divide-line">
            {list.map((i) => (
              <li key={i.id} className="flex flex-wrap items-start justify-between gap-3 py-3">
                <div><p className="text-xs text-ink-muted">{i.rule_name} · {fmtDateTime(i.created_at)}</p><p className="font-semibold">{i.title}</p>{i.body && <p className="text-sm">{i.body}</p>}</div>
                <div className="flex gap-2">
                  <Button size="sm" icon={<Send className="h-4 w-4" />} onClick={() => void act(async () => { const r = await api.growth.decideAutomationItem(i.id, true); if (r !== 'sent') throw new Error('Non inviato: il destinatario non ha più il consenso marketing.'); }, 'Inviato (notifica in-app)', reload)}>Approva e invia</Button>
                  <Button size="sm" variant="outline" icon={<X className="h-4 w-4" />} onClick={() => void act(() => api.growth.decideAutomationItem(i.id, false), 'Scartato', reload)}>Scarta</Button>
                </div>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-ink-muted">Nessuna bozza in attesa.</p>}</Loadable>
      </Card>
      <Card title="Storico esecuzioni" subtitle="Audit di ogni esecuzione (pianificata, manuale o prova a vuoto)">
        <Loadable state={runs}>{(list) => list.length ? (
          <Table head={['Quando', 'Regola', 'Tipo', 'Esito', 'Elementi', 'Errore']}>
            {list.slice(0, 30).map((x) => <tr key={x.id}><td className="py-2 pr-3">{fmtDateTime(x.started_at)}</td><td className="py-2 pr-3">{x.rule_name}</td><td className="py-2 pr-3">{x.trigger}</td>
              <td className="py-2 pr-3">{x.status}</td><td className="py-2 pr-3 tabular-nums">{n(x.records_affected)}</td><td className="py-2 pr-3 text-xs">{x.error ?? ''}</td></tr>)}
          </Table>
        ) : <p className="text-sm text-ink-muted">Nessuna esecuzione registrata.</p>}</Loadable>
      </Card>
    </div>
  );
}

// ─── Esperimenti ───
const GUARDRAILS: Record<GuardrailArea, string> = { none: 'Nessuna area sensibile', pricing: 'Prezzi pagati', consent: 'Consenso privacy', security: 'Sicurezza', accessibility: 'Accessibilità critica' };

function Experiments() {
  const act = useAct();
  const list = useAsync(() => api.growth.experiments(), []);
  const [open, setOpen] = useState<string | null>(null);
  const [form, setForm] = useState({ key: '', name: '', hypothesis: '', primary_metric: 'reservation_completed', guardrail_area: 'none' as GuardrailArea, a: 50 });
  const create = () => act(() => api.growth.upsertExperiment({ key: form.key, name: form.name, hypothesis: form.hypothesis || null, primary_metric: form.primary_metric, guardrail_area: form.guardrail_area,
    variants: [{ name: 'control', allocation: form.a }, { name: 'variant_b', allocation: 100 - form.a }] }), 'Esperimento creato (bozza)', () => { list.reload(); setForm({ ...form, key: '', name: '', hypothesis: '' }); });
  return (
    <div className="space-y-4" data-testid="growth-experiments">
      <Card title="Nuovo esperimento" subtitle="Massimo 2 attivi. Prezzi pagati, consenso privacy, sicurezza e accessibilità critica richiedono la revisione di un secondo Admin.">
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Chiave (a-z, 0-9, _)"><Input value={form.key} onChange={(e) => setForm({ ...form, key: e.target.value.toLowerCase() })} /></Field>
          <Field label="Nome"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Metrica primaria"><Select value={form.primary_metric} onChange={(e) => setForm({ ...form, primary_metric: e.target.value })}>
            <option value="reservation_completed">Prenotazione inviata</option><option value="coupon_claimed">Coupon richiesto</option><option value="signup">Iscrizione</option><option value="order_completed">Ordine completato</option></Select></Field>
          <Field label="Ipotesi" className="sm:col-span-2"><Textarea rows={2} value={form.hypothesis} onChange={(e) => setForm({ ...form, hypothesis: e.target.value })} /></Field>
          <Field label="Area sensibile"><Select value={form.guardrail_area} onChange={(e) => setForm({ ...form, guardrail_area: e.target.value as GuardrailArea })}>{Object.entries(GUARDRAILS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field label={`Allocazione: controllo ${form.a}% · variante ${100 - form.a}%`}><Input type="range" min={10} max={90} step={5} value={form.a} onChange={(e) => setForm({ ...form, a: Number(e.target.value) })} /></Field>
        </div>
        <Button className="mt-3" size="sm" disabled={!/^[a-z0-9_]{3,40}$/.test(form.key) || form.name.length < 3} onClick={() => void create()}>Crea bozza</Button>
      </Card>
      <Loadable state={list}>{(rows) => rows.length ? (
        <div className="space-y-3">
          {rows.map((e) => <ExperimentCard key={e.id} e={e} open={open === e.id} onToggle={() => setOpen(open === e.id ? null : e.id)} reload={list.reload} />)}
        </div>
      ) : <p className="text-sm text-ink-muted">Nessun esperimento.</p>}</Loadable>
    </div>
  );
}

function ExperimentCard({ e, open, onToggle, reload }: { e: GrowthExperiment; open: boolean; onToggle: () => void; reload: () => void }) {
  const act = useAct();
  const [note, setNote] = useState('');
  const rep = useAsync(() => (open ? api.growth.experimentReport(e.id) : Promise.resolve(null)), [open, e.id]);
  const needsReview = e.guardrail_area !== 'none' && !e.review_approved_at;
  return (
    <Card title={`${e.name} (${e.key})`} subtitle={`${e.status} · metrica: ${e.primary_metric ?? '—'} · ${e.allocations.map((a) => `${a.name} ${a.allocation}%`).join(' / ')} · ${n(e.assignments)} assegnazioni`}
      action={<div className="flex flex-wrap gap-2">
        {e.status !== 'running' && <Button size="sm" disabled={needsReview} onClick={() => void act(() => api.growth.setExperimentStatus(e.id, 'running'), 'Esperimento avviato', reload)}>Avvia</Button>}
        {e.status === 'running' && <Button size="sm" variant="outline" onClick={() => void act(() => api.growth.setExperimentStatus(e.id, 'stopped'), 'Esperimento fermato', reload)}>Ferma</Button>}
        <Button size="sm" variant="ghost" onClick={onToggle}>{open ? 'Chiudi report' : 'Report'}</Button>
      </div>}>
      {e.hypothesis && <p className="text-sm">Ipotesi: {e.hypothesis}</p>}
      {e.guardrail_area !== 'none' && (
        <div className={cn('mt-2 rounded-2xl px-3 py-2 text-sm', needsReview ? 'bg-amber-50 text-amber-900' : 'bg-emerald-50 text-emerald-800')}>
          <ShieldAlert className="mr-1 inline h-4 w-4" aria-hidden />Area sensibile: {GUARDRAILS[e.guardrail_area]}. {needsReview ? 'Serve la revisione di un secondo Admin prima dell\'avvio.' : `Revisionato il ${fmtDate(e.review_approved_at)}: ${e.review_note ?? ''}`}
          {needsReview && !e.same_creator && (
            <div className="mt-2 flex gap-2"><Input placeholder="Motivazione della revisione" value={note} onChange={(ev) => setNote(ev.target.value)} />
              <Button size="sm" disabled={note.trim().length < 10} onClick={() => void act(() => api.growth.reviewExperiment(e.id, note), 'Revisione registrata', reload)}>Approva</Button></div>
          )}
          {needsReview && e.same_creator && <p className="mt-1 text-xs">Hai creato tu l'esperimento: la revisione deve farla un altro Admin.</p>}
        </div>
      )}
      {open && <Loadable state={rep}>{(r) => {
        if (!r) return null;
        const v = experimentVerdict(r.variants, r.min_sample);
        return (
          <div className="mt-3" data-testid="experiment-report">
            <Table head={['Variante', 'Allocazione', 'Utenti', 'Conversioni', 'Tasso', 'Uplift vs controllo', 'z']}>
              {v.rows.map((x) => <tr key={x.variant}><td className="py-2 pr-3 font-semibold">{x.variant}</td><td className="py-2 pr-3">{r.variants.find((y) => y.variant === x.variant)?.allocation}%</td>
                <td className="py-2 pr-3 tabular-nums">{n(x.users)}</td><td className="py-2 pr-3 tabular-nums">{n(x.conversions)}</td><td className="py-2 pr-3 tabular-nums">{rateText(x.conversions, x.users)}</td>
                <td className="py-2 pr-3 tabular-nums">{x.upliftPct == null ? '—' : `${x.upliftPct > 0 ? '+' : ''}${x.upliftPct}%`}</td><td className="py-2 pr-3 tabular-nums">{x.z ?? '—'}</td></tr>)}
            </Table>
            <p className={cn('mt-2 rounded-2xl px-3 py-2 text-sm', v.winner ? 'bg-emerald-50 text-emerald-800' : 'bg-cream/60')}>{v.winner ? `Vincitore: ${v.winner}. ` : 'Nessun vincitore. '}{v.reason}</p>
            <Note>Esposizioni registrate: {n(r.exposures)}. Campione minimo per variante: {r.min_sample}. Assegnazioni e conversioni solo con consenso “Statistiche”.</Note>
          </div>
        );
      }}</Loadable>}
    </Card>
  );
}

// ─── Report ───
function Reports() {
  const act = useAct();
  const r = useRange();
  const list = useAsync(() => api.growth.reports(), []);
  const [sel, setSel] = useState<string | null>(null);
  const monday = (() => { const d = new Date(); const dow = (d.getDay() + 6) % 7; d.setDate(d.getDate() - dow - 7); return d.toISOString().slice(0, 10); })();
  const sunday = (() => { const d = new Date(`${monday}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + 6); return d.toISOString().slice(0, 10); })();
  return (
    <div className="space-y-4" data-testid="growth-reports">
      <RangeBar />
      <Card title="Report executive" subtitle="Generato ogni lunedì per la settimana precedente. I numeri sono quelli reali: lo zero resta zero, nessuna narrativa inventata."
        action={<div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={() => void act(() => api.growth.generateReport('weekly', monday, sunday), 'Report settimanale generato', list.reload)}>Settimana scorsa</Button>
          <Button size="sm" onClick={() => void act(() => api.growth.generateReport('custom', r.from, r.to), 'Report del periodo generato', list.reload)}>Report del periodo selezionato</Button>
        </div>}>
        <Loadable state={list}>{(rows) => rows.length ? (
          <ul className="divide-y divide-line">
            {rows.map((x) => (
              <li key={x.id} className="py-3">
                <button type="button" className="text-left font-semibold hover:underline" onClick={() => setSel(sel === x.id ? null : x.id)}>
                  {({ weekly: 'Settimanale', monthly: 'Mensile', custom: 'Periodo' } as const)[x.report_type]} · {fmtDate(x.period_start)}–{fmtDate(x.period_end)}
                </button>
                <span className="ml-2 text-xs text-ink-muted">generato {fmtDateTime(x.created_at)}</span>
                {sel === x.id && (
                  <div className="mt-2" data-testid="report-detail">
                    <pre className="whitespace-pre-wrap rounded-2xl bg-cream/60 p-3 font-sans text-sm [overflow-wrap:anywhere]">{x.summary}</pre>
                    <div className="mt-2"><CsvButton filename={`report-${x.period_start}-${x.period_end}.csv`} label="Esporta metriche (CSV)"
                      rows={Object.entries((x.metrics_json as { current?: Record<string, unknown> }).current ?? {}).map(([k, v]) => ({ metric: k, value: v }))}
                      columns={[{ key: 'metric', label: 'Metrica' }, { key: 'value', label: 'Valore' }]} /></div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-ink-muted">Nessun report ancora. Il primo viene generato dal job giornaliero o con i pulsanti qui sopra.</p>}</Loadable>
      </Card>
    </div>
  );
}

// ─── Task e apprendimenti ───
function Tasks() {
  const act = useAct();
  const [status, setStatus] = useState('open');
  const t = useAsync(() => api.growth.tasks(status), [status]);
  const l = useAsync(() => api.growth.learnings(), []);
  const ev = useAsync(() => api.growth.learningEvidence('taranto'), []);
  const [title, setTitle] = useState('');
  const [lf, setLf] = useState({ category: 'outreach', title: '', description: '', confidence: 'low' as 'low' | 'medium' | 'high' });
  return (
    <div className="space-y-4" data-testid="growth-tasks">
      <Card title="Task growth" subtitle="Nati da insight, alert o espansione. Nessuna esecuzione automatica: niente contatti, budget, prezzi o campagne.">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          {[['open', 'Aperti'], ['done', 'Fatti'], ['dismissed', 'Scartati']].map(([k, l2]) => <Chip key={k} active={status === k} onClick={() => setStatus(k!)}>{l2}</Chip>)}
          <Input placeholder="Nuovo task" aria-label="Nuovo task" value={title} onChange={(e) => setTitle(e.target.value)} className="h-10 w-72" />
          <Button size="sm" disabled={title.trim().length < 3} onClick={() => void act(() => api.growth.upsertTask({ title }), 'Task creato', () => { setTitle(''); t.reload(); })}>Aggiungi</Button>
        </div>
        <Loadable state={t}>{(rows) => rows.length ? (
          <ul className="divide-y divide-line">{rows.map((x) => (
            <li key={x.id} className="flex flex-wrap items-start justify-between gap-2 py-2.5">
              <div><p className="font-semibold">{x.priority === 'high' && <span className="mr-1 text-coral-700">●</span>}{x.title}</p>
                {x.description && <p className="text-sm text-ink-muted">{x.description}</p>}
                <p className="text-xs text-ink-muted">{x.source}{x.market_slug ? ` · ${x.market_slug}` : ''} · {fmtDate(x.created_at)}</p></div>
              {x.status === 'open' && <div className="flex gap-1.5">
                <Button size="sm" variant="outline" icon={<Check className="h-4 w-4" />} onClick={() => void act(() => api.growth.setTaskStatus(x.id, 'done'), 'Fatto', t.reload)}>Fatto</Button>
                <Button size="sm" variant="ghost" onClick={() => void act(() => api.growth.setTaskStatus(x.id, 'dismissed'), 'Scartato', t.reload)}>Scarta</Button></div>}
            </li>))}</ul>
        ) : <p className="text-sm text-ink-muted">Nessun task.</p>}</Loadable>
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Evidenze osservate a Taranto" subtitle="Calcolate, non salvate: registrale come apprendimento solo se utili.">
          <Loadable state={ev}>{(d) => (
            <div className="space-y-3 text-sm">
              <div><h3 className="font-bold">Canale di contatto che risponde meglio</h3>
                {d.outreach.length ? <ul>{d.outreach.map((o) => <li key={o.channel}>{o.channel}: {o.replied}/{o.contacts} risposte {o.rate != null && `(${o.rate}%)`} · confidenza {o.confidence}</li>)}</ul> : <p className="text-ink-muted">Nessun contatto registrato.</p>}</div>
              <p><strong>Prova → pagante:</strong> {d.trial_conversion.converted}/{d.trial_conversion.ended} {rateText(d.trial_conversion.converted, d.trial_conversion.ended)}</p>
              <p><strong>QR:</strong> {n(d.qr.scans)} scansioni · {n(d.qr.visits)} visite · {n(d.qr.signups)} iscrizioni</p>
              <p><strong>Sorgenti di iscrizione:</strong> {d.acquisition.map((x) => `${channelLabel(x.channel)} ${x.signups}`).join(' · ') || '—'}</p>
              <Note>{d.note}</Note>
            </div>
          )}</Loadable>
        </Card>
        <Card title="Knowledge base (growth_learnings)" subtitle="Cosa abbiamo imparato, con evidenze e livello di confidenza. Usato nel playbook dei nuovi mercati.">
          <div className="grid gap-2 sm:grid-cols-2">
            <Field label="Categoria"><Select value={lf.category} onChange={(e) => setLf({ ...lf, category: e.target.value })}>
              {['outreach', 'conversion', 'acquisition', 'qr', 'pricing', 'product', 'operations', 'other'].map((c) => <option key={c} value={c}>{c}</option>)}</Select></Field>
            <Field label="Confidenza"><Select value={lf.confidence} onChange={(e) => setLf({ ...lf, confidence: e.target.value as 'low' })}><option value="low">Bassa</option><option value="medium">Media</option><option value="high">Alta</option></Select></Field>
            <Field label="Titolo" className="sm:col-span-2"><Input value={lf.title} onChange={(e) => setLf({ ...lf, title: e.target.value })} /></Field>
            <Field label="Descrizione ed evidenza" className="sm:col-span-2"><Textarea rows={2} value={lf.description} onChange={(e) => setLf({ ...lf, description: e.target.value })} /></Field>
          </div>
          <Button className="mt-2" size="sm" disabled={lf.title.length < 3 || lf.description.length < 3}
            onClick={() => void act(() => api.growth.upsertLearning({ ...lf, market: 'taranto', evidence: ev.data ?? {} }), 'Apprendimento salvato', () => { setLf({ ...lf, title: '', description: '' }); l.reload(); })}>Salva apprendimento</Button>
          <Loadable state={l}>{(rows) => rows.length ? (
            <ul className="mt-3 space-y-2 text-sm">{rows.map((x) => <li key={x.id} className="rounded-2xl bg-cream/60 p-2.5"><strong>{x.title}</strong> <span className="text-xs text-ink-muted">({x.category} · {x.market_slug ?? 'generale'} · confidenza {x.confidence})</span><p>{x.description}</p>
              <button type="button" className="text-xs text-coral-700 hover:underline" onClick={() => void act(() => api.growth.deleteLearning(x.id), 'Eliminato', l.reload)}>Elimina</button></li>)}</ul>
          ) : <p className="mt-3 text-sm text-ink-muted">Nessun apprendimento registrato.</p>}</Loadable>
        </Card>
      </div>
    </div>
  );
}

// ─── Scenari (ipotesi, mai previsioni) ───
const DEFAULT_ASSUMPTIONS: Record<ForecastScenario, ForecastAssumptions> = {
  conservative: { restaurants_contacted: 50, claim_rate: 0.1, trial_rate: 0.3, trial_to_paid: 0.2, arpa_cents: 1900 },
  base: { restaurants_contacted: 50, claim_rate: 0.2, trial_rate: 0.4, trial_to_paid: 0.3, arpa_cents: 2900 },
  growth: { restaurants_contacted: 80, claim_rate: 0.3, trial_rate: 0.5, trial_to_paid: 0.4, arpa_cents: 3900 },
};
function Forecast() {
  const act = useAct();
  const s = useAsync(() => api.growth.settings(), []);
  const [a, setA] = useState<Record<ForecastScenario, ForecastAssumptions> | null>(null);
  const fields: [keyof ForecastAssumptions, string, number][] = [['restaurants_contacted', 'Ristoranti contattati', 1], ['claim_rate', 'Tasso di rivendicazione (0–1)', 0.05], ['trial_rate', 'Tasso di attivazione prova (0–1)', 0.05],
    ['trial_to_paid', 'Prova → pagante (0–1)', 0.05], ['arpa_cents', 'ARPA (centesimi/mese)', 100]];
  return (
    <Loadable state={s}>{(settings) => {
      const cur = a ?? ((settings.growth_forecast as Record<ForecastScenario, ForecastAssumptions> | null) ?? DEFAULT_ASSUMPTIONS);
      return (
        <Card title="Scenari su ipotesi" subtitle="Scenario basato su ipotesi — non è una previsione né un risultato garantito. Le ipotesi le inserisce l'Admin." testId="growth-forecast">
          <div className="grid gap-4 lg:grid-cols-3">
            {FORECAST_SCENARIOS.map((k) => {
              const out = forecast(cur[k]);
              return (
                <div key={k} className="rounded-3xl border border-line p-4">
                  <h3 className="font-bold">{FORECAST_LABELS[k]}</h3>
                  <div className="mt-2 space-y-2">{fields.map(([f, l, step]) => (
                    <label key={f} className="block text-sm"><span className="text-ink-muted">{l}</span>
                      <Input type="number" step={step} min={0} value={cur[k][f]} onChange={(e) => setA({ ...cur, [k]: { ...cur[k], [f]: Number(e.target.value) } })} /></label>
                  ))}</div>
                  <dl className="mt-3 grid grid-cols-2 gap-1 text-sm">
                    <dt className="text-ink-muted">Rivendicati</dt><dd className="tabular-nums">{out.claimed}</dd>
                    <dt className="text-ink-muted">Prove</dt><dd className="tabular-nums">{out.trials}</dd>
                    <dt className="text-ink-muted">Paganti</dt><dd className="font-bold tabular-nums">{out.paying}</dd>
                    <dt className="text-ink-muted">MRR (scenario)</dt><dd className="font-bold tabular-nums">{euro(out.mrr_cents)}</dd>
                  </dl>
                  <p className="mt-2 text-xs text-ink-muted">{out.label}</p>
                </div>
              );
            })}
          </div>
          {a && <Button className="mt-3" size="sm" onClick={() => void act(() => api.growth.setSetting('growth_forecast', a), 'Ipotesi salvate', () => { setA(null); s.reload(); })}>Salva ipotesi</Button>}
          <div className="mt-2"><Note>I tassi reali osservati (Funnel B2B, Taranto review) sono il riferimento per ipotesi realistiche.</Note></div>
        </Card>
      );
    }}</Loadable>
  );
}

// ─── Admin AI Analyst: domande → strumenti controllati (nessuna query libera) ───
async function runTool(tool: AnalystTool, from: string, to: string): Promise<{ answer: ReactNode; source: string; link: string }> {
  const g = api.growth;
  switch (tool) {
    case 'overview': { const o = await g.overview(from, to); return { source: 'Command Center', link: GROWTH_BASE,
      answer: <>Nel periodo: {n(o.current.visits)} visite, {n(o.current.new_users ?? 0)} nuovi utenti, {n(o.state.users_30d)} utenti attivi negli ultimi 30 giorni, {n(o.current.reservations)} prenotazioni, {n(o.current.orders)} ordini pagati ({euro(o.current.gmv_cents)} di GMV).</> }; }
    case 'retention': { const r = await g.retention(); const d30 = r.users.d30; return { source: 'Retention', link: `${GROWTH_BASE}/funnels`,
      answer: d30.eligible >= r.min_sample ? <>Tornano entro 30 giorni {rateText(d30.returned, d30.eligible)} degli iscritti ({n(d30.returned)} su {n(d30.eligible)}). D7: {rateText(r.users.d7.returned, r.users.d7.eligible)}.</>
        : <>Dati insufficienti: {n(d30.eligible)} iscritti idonei (servono almeno {r.min_sample}). Finora ne sono tornati {n(d30.returned)}.</> }; }
    case 'revenue': { const v = await g.revenue(from, to); return { source: 'Ricavi', link: `${GROWTH_BASE}/revenue`,
      answer: <>MRR {euro(v.mrr_cents)} da {n(v.paying_restaurants)} ristoranti paganti{v.arpa_cents != null ? ` (ARPA ${euro(v.arpa_cents)})` : ''}. LTV: {v.ltv_cents == null ? v.ltv_reason : euro(v.ltv_cents)}</> }; }
    case 'acquisition': { const a = await g.acquisition(from, to); const top = a.channels.filter((c) => c.signups > 0).sort((x, y) => y.signups - x.signups).slice(0, 3); return { source: 'Acquisizione', link: `${GROWTH_BASE}/acquisition`,
      answer: top.length ? <>Canali con più iscrizioni: {top.map((c) => `${channelLabel(c.channel)} (${c.signups})`).join(', ')}. Campagne con più visite: {a.campaigns.slice(0, 3).map((c) => c.utm_campaign || c.utm_source).join(', ') || 'nessuna con UTM'}.</>
        : <>Nessuna iscrizione attribuita nel periodo ({n(a.coverage.signups_total)} iscrizioni totali, attribuzione solo con consenso).</> }; }
    case 'funnels': { const f = await g.funnels(from, to); const st = f.consumer; let worst = ''; let lost = -1;
      for (let i = 1; i < st.length; i++) if (st[i - 1]!.value >= f.min_sample) { const l = 1 - st[i]!.value / st[i - 1]!.value; if (l > lost) { lost = l; worst = `${st[i - 1]!.label} → ${st[i]!.label}`; } }
      return { source: 'Funnel', link: `${GROWTH_BASE}/funnels`, answer: worst ? <>La perdita maggiore è {worst} (−{Math.round(lost * 100)}%).</> : <>Dati insufficienti per indicare dove si perdono conversioni (servono almeno {f.min_sample} sessioni con consenso per fase).</> }; }
    case 'restaurants': { const r = await g.restaurants({ from, to, status: 'at_risk', limit: 10 }); return { source: 'Ristoranti', link: `${GROWTH_BASE}/restaurants`,
      answer: r.total ? <>{n(r.total)} ristoranti a rischio: {r.rows.slice(0, 5).map((x) => `${x.name} (${x.health.signals.map((s) => s.label).join(', ')})`).join('; ')}.</> : <>Nessun ristorante con health “a rischio”.</> }; }
    case 'churn': { const c = await g.churn(from, to); return { source: 'Churn', link: `${GROWTH_BASE}/churn`,
      answer: <>Churn: {c.churn.rate == null ? 'nessuna base paganti a inizio periodo' : `${pctText(c.churn.rate)} (${c.churn.lost}/${c.churn.base})`}. Prove inattive: {c.lists.inactive_trials.length}. Pagamenti non riusciti: {c.lists.past_due.length}. Motivi: {c.reasons.map((x) => `${CHURN_REASON_LABELS[x.reason as keyof typeof CHURN_REASON_LABELS] ?? x.reason} ${x.count}`).join(', ') || '—'}.</> }; }
    case 'search': { const s = await g.search(from, to); return { source: 'Ricerca', link: `${GROWTH_BASE}/search`,
      answer: s.zero_results.length ? <>Ricerche senza risultati: {s.zero_results.slice(0, 5).map((x) => `${[x.category ?? x.query, x.city].filter(Boolean).join(' · ')} (${x.zero_results})`).join(', ')}. Supply gap principali: {s.supply_gap.slice(0, 3).map((x) => `${x.category ?? x.term} a ${x.city}`).join(', ') || '—'}.</>
        : <>Nessuna ricerca senza risultati nel periodo.</> }; }
    case 'costs': { const c = await g.costs(from, to); const ai = c.costs.find((x) => x.key === 'ai'); return { source: 'Costi', link: `${GROWTH_BASE}/costs`,
      answer: <>Costo AI stimato nel periodo: {euro(ai?.cents ?? 0)}{c.unit.ai_cost_per_active_user_cents != null ? ` (${euro(c.unit.ai_cost_per_active_user_cents)} per utente attivo)` : ''}. Stima da token × tariffe configurate.</> }; }
    case 'automations': { const a = await g.automationRules(); const on = a.rules.filter((r) => r.enabled); return { source: 'Automazioni', link: `${GROWTH_BASE}/automations`,
      answer: <>{a.kill_switch ? 'Interruttore generale ATTIVO: nessuna automazione eseguita. ' : ''}{on.length} regole attive: {on.map((r) => r.name).join(', ') || 'nessuna'}.</> }; }
    case 'today': { const t = await g.today(); return { source: 'Oggi', link: GROWTH_BASE, answer: t.length ? <ol className="list-decimal pl-5">{t.map((x, i) => <li key={i}>{x.title}</li>)}</ol> : <>Nessuna priorità aperta.</> }; }
    case 'review': { const r = await g.marketReview('taranto'); return { source: 'Taranto review', link: `${GROWTH_BASE}/taranto-review`,
      answer: <>{r.goals.map((x) => `${x.metric_key}: ${x.actual ?? 0}/${x.target}`).join(' · ')}.</> }; }
    case 'markets': { const m = await g.markets(); const c = m.candidates.filter((x) => x.score > 0 && x.data_points > 0); return { source: 'Mercati', link: '/admin/expansion/next-market',
      answer: c.length ? <>Città con più opportunità da analizzare: {c.slice(0, 3).map((x) => `${x.name} (${x.score})`).join(', ')}.</> : <>Nessuna città candidata ha ancora segnali reali: nessuna raccomandazione.</> }; }
    case 'alerts': { const a = await g.alerts('open'); return { source: 'Alert', link: `${GROWTH_BASE}/alerts`, answer: a.length ? <>{a.length} alert aperti: {a.slice(0, 5).map((x) => x.title).join('; ')}.</> : <>Nessun alert aperto.</> }; }
  }
}

function Analyst() {
  const r = useRange();
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [out, setOut] = useState<{ q: string; answer: ReactNode; source: string; link: string } | null>(null);
  const ask = async (question: string) => {
    setQ(question);
    const tool = analystRoute(question);
    if (!tool) return setOut({ q: question, answer: 'Non so rispondere a questa domanda con gli strumenti disponibili. Prova con una delle domande suggerite. Non eseguo query libere sul database.', source: '—', link: GROWTH_BASE });
    setBusy(true);
    try {
      setOut({ q: question, ...(await runTool(tool, r.from, r.to)) });
    } catch (e) {
      setOut({ q: question, answer: friendlyError(e), source: '—', link: GROWTH_BASE });
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="space-y-4" data-testid="growth-analyst">
      <RangeBar />
      <Card title="Admin AI Analyst" subtitle="Risponde usando solo strumenti controllati (le stesse RPC delle dashboard, solo Admin). Nessun SQL arbitrario, nessun dato inventato.">
        <form className="flex flex-wrap gap-2" onSubmit={(e) => { e.preventDefault(); void ask(q); }}>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Es. Quali ricerche non trovano risultati?" aria-label="Domanda" className="min-w-0 flex-1" />
          <Button type="submit" loading={busy} disabled={q.trim().length < 3}>Chiedi</Button>
        </form>
        <div className="mt-3 flex flex-wrap gap-1.5">{ANALYST_QUESTIONS.map((x) => <Chip key={x.q} onClick={() => void ask(x.q)}>{x.q}</Chip>)}</div>
        {out && (
          <div className="mt-4 rounded-2xl border border-line p-4" data-testid="analyst-answer">
            <p className="text-xs text-ink-muted">{out.q}</p>
            <div className="mt-1 text-sm">{out.answer}</div>
            <p className="mt-2 text-xs text-ink-muted">Fonte: {out.source} · periodo {fmtDate(r.from)}–{fmtDate(r.to)} · <Link to={out.link} className="underline">apri la dashboard</Link></p>
          </div>
        )}
      </Card>
    </div>
  );
}

// ─── Dati, freschezza, backfill, impostazioni ───
const NUM_SETTINGS: [string, string][] = [
  ['growth_min_sample', 'Campione minimo per tassi e confronti'], ['growth_return_window_days', 'Finestra "ritorno" (giorni)'], ['growth_experiment_min_sample', 'Esperimenti: utenti minimi per variante'],
  ['growth_supply_gap_min_searches', 'Supply gap: ricerche minime'], ['growth_alert_zero_result_min', 'Alert zero risultati (7 giorni)'], ['growth_alert_no_login_days', 'Alert nessun accesso (giorni)'],
  ['growth_anomaly_min_baseline', 'Anomalie: volume minimo giornaliero'], ['growth_anomaly_drop_pct', 'Anomalie: calo % ordini/prenotazioni'], ['growth_checkout_drop_pct', 'Anomalie: calo % conversione checkout'],
  ['growth_search_log_days', 'Conservazione ricerche grezze (giorni)'], ['cac_min_conversions', 'CAC: iscrizioni minime'],
];
function DataSettings() {
  const act = useAct();
  const s = useAsync(() => api.growth.settings(), []);
  const ov = useAsync(() => { const t = new Date().toISOString().slice(0, 10); return api.growth.overview(t, t); }, []);
  const [from, setFrom] = useState(() => { const d = new Date(); d.setDate(d.getDate() - 90); return d.toISOString().slice(0, 10); });
  const [to, setTo] = useState(() => new Date().toISOString().slice(0, 10));
  const [vals, setVals] = useState<Record<string, number>>({});
  return (
    <div className="space-y-4" data-testid="growth-data">
      <Card title="Freschezza e aggregazioni" subtitle="Realtime: ordini, pagamenti, alert critici (oggi ricalcolato al massimo ogni 5 minuti). Batch: retention, coorti, mercati, report (job giornaliero).">
        {ov.data && <div className="space-y-1"><Freshness at={ov.data.freshness.today_at} label="Oggi aggiornato" /><br /><Freshness at={ov.data.freshness.batch_at} label="Ultimo job giornaliero" /></div>}
        <div className="mt-3 flex flex-wrap items-end gap-2">
          <Field label="Dal"><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label="Al"><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
          <Button size="sm" onClick={() => void act(async () => { const r = await api.growth.backfill(from, to); if (!r.days) throw new Error('Nessun giorno ricalcolato'); }, 'Backfill completato (idempotente: i giorni vengono ricalcolati)', ov.reload)}>Ricalcola aggregati (backfill)</Button>
        </div>
        <div className="mt-2"><Note>Il backfill è idempotente (ricalcola e sostituisce i giorni) e limitato a 400 giorni per esecuzione. L'MRR dei giorni passati è ricostruito dalle date di inizio/fine abbonamento.</Note></div>
      </Card>
      <Loadable state={s}>{(settings) => (
        <Card title="Soglie e impostazioni" subtitle="Valori usati da dashboard, alert e raccomandazioni. Ogni modifica è registrata nell'audit.">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {NUM_SETTINGS.map(([k, l]) => (
              <Field key={k} label={l}><div className="flex gap-2">
                <Input type="number" min={1} max={1000} value={vals[k] ?? Number(settings[k] ?? 0)} onChange={(e) => setVals({ ...vals, [k]: Number(e.target.value) })} />
                {vals[k] !== undefined && <Button size="sm" onClick={() => void act(() => api.growth.setSetting(k, vals[k]), 'Salvato', () => { const { [k]: _omit, ...rest } = vals; void _omit; setVals(rest); s.reload(); })}>Salva</Button>}
              </div></Field>
            ))}
          </div>
          <div className="mt-3 max-w-xl">
            <Toggle checked={settings.growth_directions_as_conversion === true} label="Conta indicazioni e chiamate come conversione qualificata"
              description="Di default sono solo intenzioni. Attivalo solo se lo consideri una conversione reale per il tuo modello."
              onChange={(v) => void act(() => api.growth.setSetting('growth_directions_as_conversion', v), 'Salvato', s.reload)} />
          </div>
          {settings.growth_market_weights != null && <p className="mt-2 text-sm text-ink-muted">Pesi del Market Opportunity Score: modificabili da <Link className="underline" to="/admin/expansion/next-market">Prossimo mercato</Link>.</p>}
          {!Object.keys(settings).length && <Insufficient />}
        </Card>
      )}</Loadable>
    </div>
  );
}
