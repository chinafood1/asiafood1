// ─────────────────────────────────────────────────────────────
//  Fase 13 · Componenti condivisi della Growth suite.
//  Regole: ogni numero ha un'etichetta testuale; variazioni % solo quando valide (pctChange);
//  "Dati insufficienti" invece di numeri fragili; freschezza del dato sempre visibile.
// ─────────────────────────────────────────────────────────────
import { createContext, useContext, useMemo, useState, type ReactNode } from 'react';
import { AlertTriangle, Clock, Download, Info, TrendingDown, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Chip } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Field';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { downloadBlob } from '@/lib/qrExport';
import { pctChange, rangeDates, toCsv, type RangeKey } from '@shared/growth';
import type { DataQualityItem } from '@/types/growth';

export { BarList, Card, Columns, DemoNotice, euro, fmtDate, fmtDateTime, n, Note, Stat, Table } from '../launch/shared';

export const GROWTH_BASE = '/admin/growth';
export const romeToday = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome' }).format(new Date());
export const pctText = (v: number | null | undefined) => (v == null ? '—' : `${v.toLocaleString('it-IT')}%`);
export const rateText = (num: number, den: number, min = 1) => (den >= min && den > 0 ? `${Math.round((num * 1000) / den) / 10}%` : '—');

// ─── Periodo condiviso tra le pagine ───
interface RangeState { key: RangeKey; from: string; to: string; setKey: (k: RangeKey) => void; setCustom: (from: string, to: string) => void; market: string; setMarket: (m: string) => void }
const RangeCtx = createContext<RangeState | null>(null);

export function RangeProvider({ children }: { children: ReactNode }) {
  const [key, setKey] = useState<RangeKey>('30d');
  const [custom, setCustomState] = useState<{ from: string; to: string }>(() => rangeDates('30d', romeToday()));
  const [market, setMarket] = useState('');
  const value = useMemo<RangeState>(() => {
    const r = rangeDates(key, romeToday(), custom);
    return { key, ...r, setKey, setCustom: (from, to) => { setCustomState({ from, to }); setKey('custom'); }, market, setMarket };
  }, [key, custom, market]);
  return <RangeCtx.Provider value={value}>{children}</RangeCtx.Provider>;
}
export function useRange() {
  const c = useContext(RangeCtx);
  if (!c) throw new Error('RangeProvider mancante');
  return c;
}

const RANGE_LABELS: [RangeKey, string][] = [['today', 'Oggi'], ['yesterday', 'Ieri'], ['7d', '7 giorni'], ['30d', '30 giorni'], ['90d', '90 giorni'], ['custom', 'Personalizzato']];

/** Selettore periodo (una riga sopra i grafici) + mercato opzionale. */
export function RangeBar({ withMarket = false, markets = [] }: { withMarket?: boolean; markets?: { slug: string; name: string }[] }) {
  const r = useRange();
  return (
    <div className="flex flex-wrap items-center gap-2" data-testid="range-bar">
      <div className="flex flex-wrap gap-1.5" role="group" aria-label="Periodo">
        {RANGE_LABELS.map(([k, label]) => <Chip key={k} active={r.key === k} onClick={() => (k === 'custom' ? r.setCustom(r.from, r.to) : r.setKey(k))}>{label}</Chip>)}
      </div>
      {r.key === 'custom' && (
        <span className="flex items-center gap-1.5 text-sm">
          <Input type="date" aria-label="Dal" value={r.from} max={r.to} onChange={(e) => e.target.value && r.setCustom(e.target.value, r.to)} className="h-10 w-40" />
          <span>–</span>
          <Input type="date" aria-label="Al" value={r.to} min={r.from} max={romeToday()} onChange={(e) => e.target.value && r.setCustom(r.from, e.target.value)} className="h-10 w-40" />
        </span>
      )}
      {withMarket && (
        <select aria-label="Mercato" value={r.market} onChange={(e) => r.setMarket(e.target.value)} className="h-10 rounded-full border border-line bg-white px-4 text-sm">
          <option value="">Tutti i mercati</option>
          {markets.map((m) => <option key={m.slug} value={m.slug}>{m.name}</option>)}
        </select>
      )}
    </div>
  );
}

/** KPI con confronto sul periodo precedente — mostrato solo se matematicamente valido. */
export function DeltaStat({ label, value, current, previous, previousComplete = true, format, hint, testId, invert }: {
  label: string; value?: ReactNode; current: number | null | undefined; previous?: number | null; previousComplete?: boolean; format?: (v: number) => string; hint?: ReactNode; testId?: string; invert?: boolean;
}) {
  const ch = previous === undefined ? null : pctChange(current, previous, previousComplete);
  const good = ch == null ? null : invert ? ch < 0 : ch > 0;
  return (
    <div className="rounded-3xl border border-line bg-white p-4" data-testid={testId}>
      <p className="text-xs text-ink-muted">{label}</p>
      <p className="mt-1 font-display text-2xl font-extrabold tabular-nums">{value ?? (current == null ? '—' : format ? format(current) : current.toLocaleString('it-IT'))}</p>
      {ch != null ? (
        <p className={cn('mt-0.5 inline-flex items-center gap-1 text-xs font-semibold', good ? 'text-emerald-700' : ch === 0 ? 'text-ink-muted' : 'text-coral-700')} title="Rispetto al periodo precedente di pari durata">
          {ch > 0 ? <TrendingUp className="h-3.5 w-3.5" aria-hidden /> : ch < 0 ? <TrendingDown className="h-3.5 w-3.5" aria-hidden /> : null}
          {ch > 0 ? '+' : ''}{ch.toLocaleString('it-IT')}% vs periodo precedente
        </p>
      ) : previous !== undefined ? (
        <p className="mt-0.5 text-xs text-ink-muted">Confronto non disponibile</p>
      ) : null}
      {hint && <p className="mt-0.5 text-xs text-ink-muted">{hint}</p>}
    </div>
  );
}

export function Freshness({ at, label = 'Ultimo aggiornamento', live }: { at: string | null | undefined; label?: string; live?: boolean }) {
  return (
    <p className="inline-flex items-center gap-1.5 text-xs text-ink-muted" data-testid="freshness">
      <Clock className="h-3.5 w-3.5" aria-hidden />
      {label}: {at ? new Date(at).toLocaleString('it-IT', { dateStyle: 'short', timeStyle: 'short' }) : 'mai'}
      {live && ' · oggi quasi in tempo reale (≤ 5 min), storico giornaliero'}
    </p>
  );
}

export function DataQuality({ items }: { items: DataQualityItem[] }) {
  if (!items.length) return null;
  const tone = { critical: 'border-coral-200 bg-coral-50 text-coral-700', warning: 'border-amber-200 bg-amber-50 text-amber-900', info: 'border-line bg-cream/60 text-ink-soft' };
  return (
    <ul className="space-y-2" data-testid="data-quality" aria-label="Avvisi sulla qualità dei dati">
      {items.map((d) => (
        <li key={d.key} className={cn('flex items-start gap-2 rounded-2xl border px-4 py-2.5 text-sm', tone[d.severity])}>
          {d.severity === 'info' ? <Info className="mt-0.5 h-4 w-4 shrink-0" aria-hidden /> : <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />}
          <span>{d.message}</span>
        </li>
      ))}
    </ul>
  );
}

/** "Dati insufficienti" con il motivo (mai un numero fragile). */
export function Insufficient({ children }: { children?: ReactNode }) {
  return <p className="rounded-2xl bg-cream/60 px-4 py-3 text-sm text-ink-muted" data-testid="insufficient">Dati insufficienti{children ? <>: {children}</> : '.'}</p>;
}

/** Esportazione CSV di aggregati (nessun dato personale). */
export function CsvButton({ rows, columns, filename, label = 'CSV' }: { rows: Record<string, unknown>[]; columns: { key: string; label: string }[]; filename: string; label?: string }) {
  return (
    <Button size="sm" variant="outline" icon={<Download className="h-4 w-4" />} disabled={!rows.length}
      onClick={() => downloadBlob(new Blob(['﻿' + toCsv(rows, columns)], { type: 'text/csv;charset=utf-8' }), filename)}>{label}</Button>
  );
}

/** Stato di caricamento/errore uniforme. */
export function Loadable<T>({ state, children }: { state: { data?: T; loading: boolean; error: Error | null }; children: (d: T) => ReactNode }) {
  if (state.loading && !state.data) return <PageLoader />;
  if (state.error && !state.data) return <Alert tone="error">{friendlyError(state.error)}</Alert>;
  if (!state.data) return null;
  return <>{children(state.data)}</>;
}

export const channelLabel = (k: string) => ({
  organic_google: 'Google organico', direct: 'Diretto', instagram: 'Instagram', facebook: 'Facebook', tiktok: 'TikTok', restaurant_qr: 'QR ristorante',
  referral: 'Invito (referral)', creator: 'Creator', paid_social: 'Social a pagamento', partner: 'Partner', email: 'Email', other_social: 'Altri social', other: 'Altro',
} as Record<string, string>)[k] ?? k;

export function HealthBadge({ status, score }: { status: string; score: number | null }) {
  const t: Record<string, string> = { healthy: 'bg-emerald-50 text-emerald-700', needs_attention: 'bg-amber-50 text-amber-800', at_risk: 'bg-coral-50 text-coral-700' };
  const l: Record<string, string> = { healthy: 'In salute', needs_attention: 'Da seguire', at_risk: 'A rischio', unknown: 'Dati insufficienti', not_claimed: 'Non rivendicato' };
  return <span className={cn('inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold', t[status] ?? 'bg-cream text-ink-muted')} title="Health interno del rapporto commerciale: non è un giudizio sulla qualità del ristorante">
    {l[status] ?? status}{score != null ? ` · ${score}` : ''}</span>;
}
