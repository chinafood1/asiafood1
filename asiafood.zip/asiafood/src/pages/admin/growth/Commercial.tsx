// ─────────────────────────────────────────────────────────────
//  Fase 13 · Ristoranti (performance + health), churn, ricavi/MRR, acquisizione/CAC, costi.
// ─────────────────────────────────────────────────────────────
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Chip } from '@/components/ui/Badge';
import { Field, Input, Select } from '@/components/ui/Field';
import { useToast } from '@/components/ui/Toast';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { api } from '@/services';
import { CHURN_REASON_LABELS } from '@shared/growth';
import { COST_CATEGORIES, COST_CATEGORY_LABELS, type ChurnListRow } from '@/types/growth';
import {
  BarList, Card, channelLabel, CsvButton, euro, fmtDate, HealthBadge, Insufficient, Loadable, n, Note, pctText, RangeBar, Stat, Table, useRange,
} from './shared';

export default function Commercial({ view }: { view: 'restaurants' | 'churn' | 'revenue' | 'acquisition' | 'costs' }) {
  return (
    <div className="space-y-5">
      <RangeBar />
      {view === 'restaurants' && <Restaurants />}
      {view === 'churn' && <Churn />}
      {view === 'revenue' && <Revenue />}
      {view === 'acquisition' && <Acquisition />}
      {view === 'costs' && <Costs />}
    </div>
  );
}

function Restaurants() {
  const r = useRange();
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(0);
  const st = useAsync(() => api.growth.restaurants({ from: r.from, to: r.to, market: r.market || null, status: status || null, search: q || null, limit: 25, offset: page * 25 }), [r.from, r.to, r.market, status, q, page]);
  return (
    <Card title="Performance dei ristoranti" subtitle="Quali convertono meglio e quali rischiano di abbandonare" testId="growth-restaurants">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        {[['', 'Tutti'], ['at_risk', 'A rischio'], ['needs_attention', 'Da seguire'], ['healthy', 'In salute'], ['not_claimed', 'Non rivendicati']].map(([k, l]) => (
          <Chip key={k} active={status === k} onClick={() => { setStatus(k!); setPage(0); }}>{l}</Chip>
        ))}
        <Input type="search" placeholder="Cerca ristorante" aria-label="Cerca ristorante" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} className="h-10 w-56" />
      </div>
      <Loadable state={st}>{(d) => (
        <>
          <Table head={['Ristorante', 'Health', 'Viste', 'Menu', 'Indicaz.', 'Chiamate', 'WhatsApp', 'Prenot.', 'Ordini', 'Coupon', 'Recens.', 'Ritorni', 'Incasso', 'Conversione', 'Piano']} testId="restaurants-table">
            {d.rows.map((x) => (
              <tr key={x.id} className="align-top">
                <td className="py-2 pr-3"><Link to={`/admin/restaurants/${x.id}`} className="font-semibold hover:underline">{x.name}</Link><p className="text-xs text-ink-muted">{x.city}</p>
                  {x.health.signals.length > 0 && <ul className="mt-1 space-y-0.5 text-xs text-coral-700">{x.health.signals.slice(0, 3).map((s) => <li key={s.key}>• {s.label}</li>)}</ul>}</td>
                <td className="py-2 pr-3"><HealthBadge status={x.health.status} score={x.health.score} /></td>
                {[x.views, x.menu_views, x.directions, x.calls, x.whatsapp, x.bookings, x.orders, x.coupon_redemptions, x.reviews, x.repeat_customers].map((v, i) => <td key={i} className="py-2 pr-3 tabular-nums">{n(v)}</td>)}
                <td className="py-2 pr-3 tabular-nums">{euro(x.revenue_cents)}</td>
                <td className="py-2 pr-3 tabular-nums">{pctText(x.conversion_rate)}</td>
                <td className="py-2 pr-3">{x.subscription_plan}</td>
              </tr>
            ))}
          </Table>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-sm">
            <span className="text-ink-muted">{n(d.total)} ristoranti</span>
            <span className="flex gap-2">
              <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage(page - 1)}>Precedenti</Button>
              <Button size="sm" variant="outline" disabled={(page + 1) * 25 >= d.total} onClick={() => setPage(page + 1)}>Successivi</Button>
              <CsvButton filename={`ristoranti-${r.from}-${r.to}.csv`} rows={d.rows.map((x) => ({ ...x, health_score: x.health.score, health_status: x.health.status }))}
                columns={[{ key: 'name', label: 'Ristorante' }, { key: 'city', label: 'Comune' }, { key: 'health_status', label: 'Health' }, { key: 'health_score', label: 'Punteggio' },
                  { key: 'views', label: 'Viste' }, { key: 'bookings', label: 'Prenotazioni' }, { key: 'orders', label: 'Ordini' }, { key: 'conversion_rate', label: 'Conversione %' }]} />
            </span>
          </div>
          <div className="mt-3 space-y-1"><Note>{d.definitions.conversion}</Note><Note>{d.definitions.health}</Note></div>
        </>
      )}</Loadable>
    </Card>
  );
}

function ChurnList({ title, rows, render }: { title: string; rows: ChurnListRow[]; render: (x: ChurnListRow) => string }) {
  return (
    <div>
      <h3 className="text-sm font-bold">{title} <span className="font-normal text-ink-muted">({rows.length})</span></h3>
      {rows.length ? <ul className="mt-1 space-y-1 text-sm">{rows.map((x) => <li key={x.restaurant_id}><Link className="font-semibold hover:underline" to={`/admin/restaurants/${x.restaurant_id}`}>{x.name}</Link> <span className="text-ink-muted">{render(x)}</span></li>)}</ul>
        : <p className="mt-1 text-sm text-ink-muted">Nessuno.</p>}
    </div>
  );
}

function Churn() {
  const r = useRange();
  const c = useAsync(() => api.growth.churn(r.from, r.to), [r.from, r.to]);
  return (
    <Loadable state={c}>{(d) => (
      <div className="space-y-4" data-testid="growth-churn">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat label="Churn rate (ristoranti)" value={d.churn.rate == null ? '—' : pctText(d.churn.rate)} hint={`${n(d.churn.lost)} persi su ${n(d.churn.base)} paganti a inizio periodo`} testId="churn-rate" />
          <Stat label="MRR nuovo" value={euro(d.mrr.new_mrr_cents)} />
          <Stat label="MRR perso" value={euro(d.mrr.churned_mrr_cents)} tone={d.mrr.churned_mrr_cents ? 'bad' : undefined} />
          <Stat label="Espansione / contrazione" value={d.mrr.expansion_available ? `${euro(d.mrr.expansion_mrr_cents)} / ${euro(d.mrr.contraction_mrr_cents)}` : '—'} hint={d.mrr.expansion_available ? undefined : 'Non disponibile'} />
        </div>
        {d.mrr.note && <Note>{d.mrr.note}</Note>}
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Chi sta per andarsene">
            <div className="space-y-4">
              <ChurnList title="Pagamento non riuscito" rows={d.lists.past_due} render={(x) => `· ${x.plan} · ${euro(x.mrr_cents)}/mese`} />
              <ChurnList title="Disdetta a fine periodo" rows={d.lists.cancel_scheduled} render={(x) => `· attivo fino al ${fmtDate(x.until)}`} />
              <ChurnList title="Prove senza accessi da 7 giorni" rows={d.lists.inactive_trials} render={(x) => `· prova fino al ${fmtDate(x.trial_end)} · ultimo accesso ${x.last_login ? fmtDate(x.last_login) : 'mai'}`} />
              <ChurnList title="Health a rischio" rows={d.lists.at_risk} render={(x) => `· ${(x.health?.signals ?? []).map((s) => s.label).join(', ')}`} />
            </div>
          </Card>
          <Card title="Perché disdicono" subtitle={d.definitions.reasons}>
            <BarList rows={d.reasons.map((x) => ({ label: CHURN_REASON_LABELS[x.reason as keyof typeof CHURN_REASON_LABELS] ?? x.reason, value: x.count }))} testId="churn-reasons" empty="Nessuna disdetta con motivo nel periodo." />
            <div className="mt-4"><ChurnList title="Disdetti nel periodo" rows={d.lists.cancelled} render={(x) => `· ${x.plan} · ${fmtDate(x.ended_at)}`} /></div>
          </Card>
        </div>
        <Note>{d.definitions.churn_rate}</Note>
      </div>
    )}</Loadable>
  );
}

function Revenue() {
  const r = useRange();
  const v = useAsync(() => api.growth.revenue(r.from, r.to), [r.from, r.to]);
  return (
    <Loadable state={v}>{(d) => (
      <div className="space-y-4" data-testid="growth-revenue">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
          <Stat label="MRR" value={euro(d.mrr_cents)} testId="rev-mrr" />
          <Stat label="ARR" value={euro(d.arr_cents)} hint="MRR × 12" />
          <Stat label="Ristoranti paganti" value={n(d.paying_restaurants)} />
          <Stat label="ARPA" value={d.arpa_cents == null ? '—' : euro(d.arpa_cents)} hint={d.definitions.arpa} />
          <Stat label="LTV" value={d.ltv_cents == null ? '—' : euro(d.ltv_cents)} hint={d.ltv_reason ?? d.definitions.ltv} testId="rev-ltv" />
        </div>
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Movimenti MRR nel periodo">
            <dl className="grid grid-cols-2 gap-2 text-sm">
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Nuovo</dt><dd className="font-bold">{euro(d.movements.new_mrr_cents)}</dd></div>
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Perso (churn)</dt><dd className="font-bold">{euro(d.movements.churned_mrr_cents)}</dd></div>
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Espansione</dt><dd className="font-bold">{d.movements.expansion_available ? euro(d.movements.expansion_mrr_cents) : '—'}</dd></div>
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Contrazione</dt><dd className="font-bold">{d.movements.expansion_available ? euro(d.movements.contraction_mrr_cents) : '—'}</dd></div>
            </dl>
            {d.movements.note && <div className="mt-2"><Note>{d.movements.note}</Note></div>}
          </Card>
          <Card title="Ricavi della piattaforma per fonte" subtitle="Solo ricavi di AsiaFood (il GMV è incasso dei ristoranti)">
            <BarList rows={d.sources.map((s) => ({ label: s.label, value: s.cents }))} testId="rev-sources" empty="Nessun ricavo registrato nel periodo." />
            <p className="mt-2 text-sm text-ink-muted">Importi in centesimi · GMV ordini: {euro(d.gmv_cents)}</p>
          </Card>
        </div>
        <Note>{d.definitions.mrr}</Note>
      </div>
    )}</Loadable>
  );
}

function Acquisition() {
  const r = useRange();
  const a = useAsync(() => api.growth.acquisition(r.from, r.to), [r.from, r.to]);
  return (
    <Loadable state={a}>{(d) => (
      <div className="space-y-4" data-testid="growth-acquisition">
        <Card title="Canali di acquisizione" subtitle="Quale canale porta utenti e ristoranti che convertono"
          action={<CsvButton filename={`canali-${r.from}-${r.to}.csv`} rows={d.channels.map((x) => ({ ...x, channel: channelLabel(x.channel) }))} columns={[{ key: 'channel', label: 'Canale' },
            { key: 'visits', label: 'Visite' }, { key: 'signups', label: 'Iscrizioni' }, { key: 'activated', label: 'Attivati' }, { key: 'reservations', label: 'Prenotazioni' },
            { key: 'orders', label: 'Ordini' }, { key: 'paying_restaurants', label: 'Ristoranti paganti' }, { key: 'cost_cents', label: 'Costo (cent)' }, { key: 'cac_cents', label: 'CAC (cent)' }]} />}>
          <Table head={['Canale', 'Visite', 'Iscrizioni', 'Attivati', 'Prenotazioni', 'Ordini', 'Ristoranti paganti', 'Costo', 'CAC']} testId="channels-table">
            {d.channels.map((x) => (
              <tr key={x.channel}>
                <td className="py-2 pr-3 font-semibold">{channelLabel(x.channel)}</td>
                {[x.visits, x.signups, x.activated, x.reservations, x.orders, x.paying_restaurants].map((v, i) => <td key={i} className="py-2 pr-3 tabular-nums">{n(v)}</td>)}
                <td className="py-2 pr-3 tabular-nums">{x.cost_cents == null ? '—' : euro(x.cost_cents)}</td>
                <td className="py-2 pr-3 tabular-nums" title={x.cac_reason ?? undefined}>{x.cac_cents == null ? <span className="text-ink-muted">{x.cac_reason ?? 'N/A'}</span> : euro(x.cac_cents)}</td>
              </tr>
            ))}
          </Table>
          <p className="mt-2 text-sm text-ink-muted">Iscrizioni attribuite: {n(d.coverage.signups_attributed)} su {n(d.coverage.signups_total)} (solo con consenso “Statistiche”).</p>
          <div className="mt-2 space-y-1"><Note>{d.definitions.model}</Note><Note>{d.definitions.cac}</Note><Note>{d.definitions.activated}</Note></div>
        </Card>
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Campagne (UTM)" subtitle="Quali campagne portano visite e iscrizioni">
            {d.campaigns.length ? (
              <Table head={['Sorgente', 'Campagna', 'Visite', 'Iscrizioni']}>
                {d.campaigns.map((c, i) => <tr key={i}><td className="py-2 pr-3">{c.utm_source || '—'}</td><td className="py-2 pr-3">{c.utm_campaign || '—'}</td><td className="py-2 pr-3 tabular-nums">{n(c.visits)}</td><td className="py-2 pr-3 tabular-nums">{n(c.signups)}</td></tr>)}
              </Table>
            ) : <p className="text-sm text-ink-muted">Nessuna visita con parametri UTM nel periodo.</p>}
          </Card>
          <Card title="Last touch (canale della sessione di iscrizione)">
            <BarList rows={d.last_touch.map((x) => ({ label: channelLabel(x.channel), value: x.signups }))} empty="Nessuna iscrizione attribuita nel periodo." />
          </Card>
        </div>
      </div>
    )}</Loadable>
  );
}

function Costs() {
  const r = useRange();
  const toast = useToast();
  const c = useAsync(() => api.growth.costs(r.from, r.to), [r.from, r.to]);
  const [form, setForm] = useState({ category: 'infrastructure', amount: '', from: r.from, to: r.to, notes: '' });
  const add = async () => {
    try {
      await api.growth.addCost({ category: form.category, amount_cents: Math.round(Number(form.amount.replace(',', '.')) * 100), period_start: form.from, period_end: form.to, notes: form.notes || null });
      setForm({ ...form, amount: '', notes: '' });
      c.reload();
      toast('Costo registrato', 'success');
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <Loadable state={c}>{(d) => (
      <div className="space-y-4" data-testid="growth-costs">
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Costi nel periodo" subtitle="Solo costi reali o configurati. Le stime sono etichettate come tali.">
            <ul className="divide-y divide-line text-sm">
              {d.costs.map((x) => (
                <li key={x.key} className="flex justify-between gap-3 py-2"><span>{x.label} <span className="text-xs text-ink-muted">({{ computed: 'calcolato', real: 'reale', assumption: 'ipotesi', manual: 'inserito' }[x.source]})</span></span>
                  <span className="tabular-nums font-semibold">{x.cents == null ? '—' : euro(x.cents)}</span></li>
              ))}
            </ul>
          </Card>
          <Card title="Unit economics" subtitle="Approssimazioni con ipotesi dichiarate">
            <dl className="grid grid-cols-2 gap-2 text-sm">
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Ricavo per ristorante pagante</dt><dd className="font-bold">{d.unit.revenue_per_paid_restaurant_cents == null ? '—' : euro(d.unit.revenue_per_paid_restaurant_cents)}</dd></div>
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Costo AI per utente attivo</dt><dd className="font-bold">{d.unit.ai_cost_per_active_user_cents == null ? '—' : euro(d.unit.ai_cost_per_active_user_cents)}</dd></div>
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Costo di incasso per ordine</dt><dd className="font-bold">{d.unit.processing_cost_per_order_cents == null ? '—' : euro(d.unit.processing_cost_per_order_cents)}</dd></div>
              <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Margine di contribuzione (approssimato)</dt><dd className="font-bold">{euro(d.unit.contribution_margin_cents)}</dd></div>
            </dl>
            <div className="mt-2 space-y-1">{d.unit.assumptions.filter(Boolean).map((x, i) => <Note key={i}>{x}</Note>)}</div>
          </Card>
        </div>
        <Card title="Registra un costo operativo" subtitle="Infrastruttura, email, push, mappe, pubblicità… (ripartito in proporzione ai giorni)">
          <div className="grid gap-3 sm:grid-cols-5">
            <Field label="Categoria"><Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{COST_CATEGORIES.map((k) => <option key={k} value={k}>{COST_CATEGORY_LABELS[k]}</option>)}</Select></Field>
            <Field label="Importo (€)"><Input inputMode="decimal" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
            <Field label="Dal"><Input type="date" value={form.from} onChange={(e) => setForm({ ...form, from: e.target.value })} /></Field>
            <Field label="Al"><Input type="date" value={form.to} onChange={(e) => setForm({ ...form, to: e.target.value })} /></Field>
            <Field label="Note"><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
          </div>
          <Button className="mt-3" size="sm" disabled={!(Number(form.amount.replace(',', '.')) > 0)} onClick={() => void add()}>Aggiungi costo</Button>
          {d.manual.length > 0 && (
            <ul className="mt-4 divide-y divide-line text-sm">
              {d.manual.map((m) => (
                <li key={m.id} className="flex items-center justify-between gap-2 py-2">
                  <span>{COST_CATEGORY_LABELS[m.category as keyof typeof COST_CATEGORY_LABELS] ?? m.category} · {euro(m.amount_cents)} · {fmtDate(m.period_start)}–{fmtDate(m.period_end)}{m.notes ? ` · ${m.notes}` : ''}</span>
                  <Button size="sm" variant="ghost" aria-label="Elimina costo" icon={<Trash2 className="h-4 w-4" />} onClick={() => void api.growth.deleteCost(m.id).then(c.reload)} />
                </li>
              ))}
            </ul>
          )}
          {!d.costs.some((x) => x.cents) && <Insufficient>nessun costo registrato nel periodo</Insufficient>}
        </Card>
      </div>
    )}</Loadable>
  );
}
