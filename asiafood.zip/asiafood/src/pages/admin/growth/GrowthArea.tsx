// ─────────────────────────────────────────────────────────────
//  Fase 13 · Growth Command Center (/admin/growth/*)
//  Ogni pagina risponde a una domanda operativa reale; ogni numero viene da dati reali.
// ─────────────────────────────────────────────────────────────
import { lazy, Suspense } from 'react';
import { NavLink, Route, Routes } from 'react-router-dom';
import { PageLoader } from '@/components/ui/Layout';
import { cn } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { GROWTH_BASE, RangeProvider } from './shared';

const CommandCenter = lazy(() => import('./CommandCenter'));
const Funnels = lazy(() => import('./Funnels'));
const Commercial = lazy(() => import('./Commercial'));
const Demand = lazy(() => import('./Demand'));
const Markets = lazy(() => import('./Markets'));
const Operations = lazy(() => import('./Operations'));

const TABS: [string, string][] = [
  ['', 'Command Center'], ['funnels', 'Funnel e retention'], ['restaurants', 'Ristoranti'], ['churn', 'Churn'], ['revenue', 'Ricavi'], ['acquisition', 'Acquisizione'],
  ['search', 'Ricerca e supply gap'], ['engagement', 'Offerte, menu, AI'], ['voice', 'Feedback e supporto'], ['markets', 'Mercati'], ['taranto-review', 'Taranto review'],
  ['alerts', 'Alert'], ['automations', 'Automazioni'], ['experiments', 'Esperimenti'], ['reports', 'Report'], ['tasks', 'Task e apprendimenti'], ['costs', 'Costi'],
  ['forecast', 'Scenari'], ['analyst', 'AI Analyst'], ['data', 'Dati e impostazioni'],
];

export default function GrowthArea() {
  useSeo({ title: 'Growth Command Center', noindex: true });
  return (
    <RangeProvider>
      <div data-testid="growth-area">
        <h1 className="text-2xl font-extrabold">Growth</h1>
        <p className="mt-1 text-sm text-ink-muted">Business Intelligence di AsiaFood: solo dati reali, “Dati insufficienti” quando il campione non basta.</p>
        <nav className="-mx-1 mt-4 flex gap-1 overflow-x-auto pb-1" aria-label="Sezioni Growth">
          {TABS.map(([to, label]) => (
            <NavLink key={to} to={to ? `${GROWTH_BASE}/${to}` : GROWTH_BASE} end={!to}
              className={({ isActive }) => cn('shrink-0 rounded-full px-3.5 py-2 text-sm font-semibold', isActive ? 'bg-ink text-white' : 'text-ink hover:bg-cream')}>
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="mt-5">
          <Suspense fallback={<PageLoader />}>
            <Routes>
              <Route index element={<CommandCenter />} />
              <Route path="funnels" element={<Funnels />} />
              <Route path="restaurants" element={<Commercial view="restaurants" />} />
              <Route path="churn" element={<Commercial view="churn" />} />
              <Route path="revenue" element={<Commercial view="revenue" />} />
              <Route path="acquisition" element={<Commercial view="acquisition" />} />
              <Route path="costs" element={<Commercial view="costs" />} />
              <Route path="search" element={<Demand view="search" />} />
              <Route path="engagement" element={<Demand view="engagement" />} />
              <Route path="voice" element={<Demand view="voice" />} />
              <Route path="markets" element={<Markets view="markets" />} />
              <Route path="taranto-review" element={<Markets view="review" />} />
              <Route path="alerts" element={<Operations view="alerts" />} />
              <Route path="automations" element={<Operations view="automations" />} />
              <Route path="experiments" element={<Operations view="experiments" />} />
              <Route path="reports" element={<Operations view="reports" />} />
              <Route path="tasks" element={<Operations view="tasks" />} />
              <Route path="forecast" element={<Operations view="forecast" />} />
              <Route path="analyst" element={<Operations view="analyst" />} />
              <Route path="data" element={<Operations view="data" />} />
            </Routes>
          </Suspense>
        </div>
      </div>
    </RangeProvider>
  );
}
