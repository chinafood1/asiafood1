import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Pencil } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { formatDate, formatDistance } from '@/lib/format';
import { haversineKm } from '@/lib/geo';
import { InteractiveMap } from '@/lib/maps/InteractiveMap';
import { api } from '@/services';
import type { ChangeRequest, ChangeRequestStatus } from '@/types/domain';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Textarea } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';

const STATUS: Record<ChangeRequestStatus, { label: string; tone: 'amber' | 'green' | 'neutral' }> = {
  pending: { label: 'Da valutare', tone: 'amber' },
  approved: { label: 'Approvata', tone: 'green' },
  rejected: { label: 'Rifiutata', tone: 'neutral' },
};
const FILTERS: [ChangeRequestStatus | undefined, string][] = [['pending', 'Da valutare'], ['approved', 'Approvate'], ['rejected', 'Rifiutate'], [undefined, 'Tutte']];

/** /admin/modifiche — correzioni di indirizzo e posizione proposte dai ristoratori. */
export default function AdminChangeRequests() {
  const [status, setStatus] = useState<ChangeRequestStatus | undefined>('pending');
  const list = useAsync(() => api.listChangeRequests({ status }), [status]);
  useSeo({ title: 'Admin · Modifiche posizione', noindex: true });
  return (
    <div>
      <PageTitle
        title="Modifiche di posizione"
        subtitle="Cambi di indirizzo e spostamenti oltre 300 m proposti dai titolari. Verifica sulle fonti prima di approvare."
      />
      <div className="scrollbar-none mb-5 flex gap-2 overflow-x-auto">
        {FILTERS.map(([v, l]) => (
          <Chip key={l} active={status === v} onClick={() => setStatus(v)}>
            {l}
          </Chip>
        ))}
      </div>
      {list.loading ? (
        <PageLoader />
      ) : (list.data ?? []).length === 0 ? (
        <EmptyState icon="📍" title="Nessuna richiesta" text="Le proposte dei ristoratori compariranno qui." />
      ) : (
        <div className="grid gap-4 xl:grid-cols-2">
          {list.data!.map((c) => (
            <RequestCard key={c.id} c={c} onDone={list.reload} />
          ))}
        </div>
      )}
    </div>
  );
}

function RequestCard({ c, onDone }: { c: ChangeRequest; onDone: () => void }) {
  const toast = useToast();
  const [notes, setNotes] = useState(c.admin_notes ?? '');
  const [busy, setBusy] = useState<'ok' | 'ko' | null>(null);
  const r = c.restaurant;
  const p = c.payload;
  const cur = r?.latitude != null && r.longitude != null ? { lat: r.latitude, lng: r.longitude } : null;
  const next = p.latitude != null && p.longitude != null ? { lat: p.latitude, lng: p.longitude } : null;
  const moved = cur && next ? haversineKm(cur, next) : null;
  const points = [
    ...(cur ? [{ id: 'cur', ...cur, label: 'Posizione attuale', emoji: '📍' }] : []),
    ...(next ? [{ id: 'next', ...next, label: 'Posizione proposta', emoji: '✳️', sponsored: true }] : []),
  ];

  const review = async (approve: boolean) => {
    setBusy(approve ? 'ok' : 'ko');
    try {
      await api.reviewChangeRequest(c.id, approve, notes.trim() || undefined);
      toast(approve ? 'Modifica approvata e applicata' : 'Richiesta rifiutata');
      onDone();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };
  const st = STATUS[c.status];

  return (
    <article className="card overflow-hidden">
      {points.length > 0 && (
        <InteractiveMap points={points} initialView={points.length === 1 ? { center: points[0]!, zoom: 15 } : undefined} selectedId={next ? 'next' : null} interactive={false} clustering={false} controls={false} className="h-44 w-full" ariaLabel="Confronto tra posizione attuale e proposta" />
      )}
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <Link to={`/ristorante/${r?.slug}`} target="_blank" className="block truncate text-lg font-bold hover:text-coral-700">
              {r?.name ?? 'Locale eliminato'}
            </Link>
            <p className="text-xs text-ink-muted">{formatDate(c.created_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
          </div>
          <Badge tone={st.tone}>{st.label}</Badge>
        </div>
        <dl className="mt-3 grid gap-2 text-sm">
          {p.address !== undefined && (
            <div className="rounded-2xl bg-cream p-3">
              <dt className="text-xs font-semibold text-ink-muted">Indirizzo</dt>
              <dd className="mt-0.5 flex flex-wrap items-center gap-1.5">
                <span className="text-ink-muted line-through">{r?.address ?? '—'}</span>
                <ArrowRight className="h-3.5 w-3.5" />
                <strong>{[p.address, p.postal_code].filter(Boolean).join(', ') || '—'}</strong>
              </dd>
            </div>
          )}
          {next && (
            <div className="rounded-2xl bg-cream p-3">
              <dt className="text-xs font-semibold text-ink-muted">Coordinate proposte</dt>
              <dd className="mt-0.5 font-mono text-xs">
                {next.lat.toFixed(6)}, {next.lng.toFixed(6)}
                {moved !== null && <span className="ml-2 font-sans text-ink-muted">(spostamento {formatDistance(moved)})</span>}
              </dd>
            </div>
          )}
          {c.note && <p className="whitespace-pre-line text-ink-soft">“{c.note}”</p>}
        </dl>
        {c.status === 'pending' ? (
          <div className="mt-4 space-y-3">
            <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Nota per il titolare (facoltativa)…" className="!min-h-0" />
            <div className="flex flex-wrap gap-2">
              {r && (
                <Link to={`/admin/restaurants/${r.id}/localizzazione`} className="inline-flex h-9 items-center gap-1.5 rounded-full border border-line px-4 text-sm font-semibold hover:border-ink">
                  <Pencil className="h-4 w-4" /> Apri scheda
                </Link>
              )}
              <Button size="sm" variant="dark" loading={busy === 'ok'} onClick={() => review(true)}>
                Approva e applica
              </Button>
              <Button size="sm" variant="ghost" loading={busy === 'ko'} onClick={() => review(false)}>
                Rifiuta
              </Button>
            </div>
          </div>
        ) : (
          c.admin_notes && <p className="mt-3 text-sm text-ink-muted">Nota: {c.admin_notes}</p>
        )}
      </div>
    </article>
  );
}
