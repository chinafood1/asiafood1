import { useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, ChevronDown, Download, FileJson, FileSpreadsheet, History, Info, Upload, XCircle } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { cn, formatDate } from '@/lib/format';
import { DATA_STATUS } from '@/lib/labels';
import {
  analyzeRows, buildOperation, detectFormat, emptySummary, parseFile, toCsv,
  type ExistingRestaurant, type ImportDecision, type ImportOptions, type ImportRow, type ImportSummary,
} from '@/lib/import';
import { api } from '@/services';
import type { DataStatus, Province } from '@/types/domain';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';

type Stage = 'upload' | 'preview' | 'running' | 'done';
type RowFilter = 'all' | 'new' | 'duplicates' | 'errors' | 'warnings';

const DECISION_LABEL: Record<ImportDecision, string> = {
  create: 'Crea nuovo',
  skip: 'Ignora',
  update: 'Aggiorna esistente',
  merge: 'Unisci (completa i vuoti)',
  create_anyway: 'Crea comunque',
};
const PAGE = 40;

export default function AdminImport() {
  const { cities, categories, ready } = useReferenceData();
  const provinces = useAsync(() => api.list<Province>('provinces'), []);
  const batches = useAsync(() => api.listImportBatches(), []);
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  useSeo({ title: 'Admin · Importa ristoranti', noindex: true });

  const [stage, setStage] = useState<Stage>('upload');
  const [fileName, setFileName] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [format, setFormat] = useState<'csv' | 'json'>('csv');
  const [opts, setOpts] = useState<ImportOptions>({ publish: false, defaultStatus: 'unverified' });
  const [rows, setRows] = useState<ImportRow[]>([]);
  const [existing, setExisting] = useState<ExistingRestaurant[]>([]);
  const [filter, setFilter] = useState<RowFilter>('all');
  const [page, setPage] = useState(1);
  const [progress, setProgress] = useState(0);
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const readFile = async (f: File | undefined) => {
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) return setError('File troppo grande (max 5 MB). Dividilo in più parti.');
    const content = await f.text();
    setFileName(f.name);
    setText(content);
    setFormat(detectFormat(f.name, content));
    setError(null);
  };

  const analyze = async () => {
    setError(null);
    setBusy(true);
    try {
      const raw = parseFile(text, format);
      if (!raw.length) throw new Error('Il file non contiene righe.');
      if (raw.length > 2000) throw new Error('Massimo 2.000 righe per import.');
      const ctx = { cities, categories, provinces: provinces.data ?? [] };
      // Prima passata per sapere quali comuni interessano, poi confronto con i locali esistenti di quei comuni
      const firstPass = analyzeRows(raw, [], ctx);
      const cityIds = Array.from(new Set(firstPass.map((r) => r.record?.city_id).filter((x): x is string => !!x)));
      const ex = await api.getRestaurantsForMatching(cityIds);
      setExisting(ex);
      setRows(analyzeRows(raw, ex, ctx));
      setPage(1);
      setFilter('all');
      setStage('preview');
    } catch (e) {
      setError(e instanceof SyntaxError ? `JSON non valido: ${e.message}` : (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const stats = useMemo(() => {
    const valid = rows.filter((r) => r.record);
    return {
      total: rows.length,
      valid: valid.length,
      errors: rows.length - valid.length,
      warnings: rows.filter((r) => r.warnings.length).length,
      dbDup: rows.filter((r) => r.matches.length).length,
      fileDup: rows.filter((r) => r.duplicateOfRow).length,
      fresh: valid.filter((r) => !r.matches.length && !r.duplicateOfRow).length,
      toWrite: rows.filter((r) => r.record && r.decision !== 'skip').length,
    };
  }, [rows]);

  const filtered = rows.filter((r) =>
    filter === 'all' ? true : filter === 'new' ? r.record && !r.matches.length && !r.duplicateOfRow : filter === 'duplicates' ? r.matches.length || r.duplicateOfRow : filter === 'errors' ? !r.record : r.warnings.length > 0,
  );
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE));

  const setDecision = (index: number, decision: ImportDecision, targetId?: string) =>
    setRows((rs) => rs.map((r) => (r.index === index ? { ...r, decision, targetId: targetId ?? r.targetId } : r)));

  const bulkDuplicates = (decision: ImportDecision) =>
    setRows((rs) => rs.map((r) => (r.record && r.matches.length ? { ...r, decision } : r)));

  const run = async () => {
    if (!confirm(`Importare ${stats.toWrite} righe? Nessun locale esistente verrà eliminato.`)) return;
    setStage('running');
    setProgress(0);
    const sum = emptySummary(rows.length);
    let batchId: string | null = null;
    try {
      batchId = (await api.createImportBatch({ file_name: fileName ?? 'incollato', format, total_rows: rows.length, options: { ...opts } })).id;
    } catch {
      batchId = null; // lo storico è facoltativo: l'import prosegue
    }
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i]!;
      try {
        if (!row.record) {
          sum.skipped += 1;
          sum.errors.push({ row: row.index, message: row.errors.join('; ') });
        } else {
          const target = existing.find((e) => e.id === row.targetId);
          const op = buildOperation(row, target, opts);
          if (!op) sum.skipped += 1;
          else {
            await api.importRestaurant(op, batchId);
            if (op.restaurantId === null) sum.created += 1;
            else if (row.decision === 'merge' || op.notes.length) sum.merged += 1;
            else sum.updated += 1;
          }
        }
      } catch (e) {
        sum.errors.push({ row: row.index, name: row.record?.name, message: (e as Error).message });
      }
      setProgress(Math.round(((i + 1) / rows.length) * 100));
    }
    if (batchId) {
      await api
        .upsert('import_batches', {
          id: batchId, created_count: sum.created, updated_count: sum.updated, merged_count: sum.merged, skipped_count: sum.skipped,
          error_count: sum.errors.length, errors: sum.errors.slice(0, 500),
        })
        .catch(() => undefined);
    }
    setSummary(sum);
    setStage('done');
    batches.reload();
    toast('Import completato');
  };

  const downloadReport = () => {
    const csv = toCsv(
      rows.map((r) => ({
        riga: r.index,
        nome: r.record?.name ?? String(r.raw.name ?? r.raw.nome ?? ''),
        comune: r.record?.city_name ?? '',
        decisione: DECISION_LABEL[r.decision],
        errori: r.errors.join(' | '),
        avvisi: r.warnings.join(' | '),
        possibile_duplicato: r.matches.map((m) => `${m.candidate.name} (${m.score})`).join(' | '),
        esito: summary?.errors.find((e) => e.row === r.index)?.message ?? '',
      })),
    );
    const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `report-import-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const reset = () => {
    setStage('upload');
    setRows([]);
    setSummary(null);
    setText('');
    setFileName(null);
  };

  return (
    <div>
      <PageTitle
        title="Importa ristoranti"
        subtitle="CSV o JSON da fonti pubbliche verificabili. Anteprima, validazione e controllo duplicati prima di scrivere."
        action={<Link to="/admin/restaurants" className="text-sm font-semibold text-coral-700 hover:underline">Vai ai ristoranti →</Link>}
      />

      {stage === 'upload' && (
        <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
          <section className="card p-5 sm:p-7">
            <h2 className="text-lg font-bold">1. Carica il file</h2>
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                readFile(e.dataTransfer.files[0]);
              }}
              className="mt-4 flex flex-col items-center rounded-3xl border-2 border-dashed border-line bg-paper px-6 py-10 text-center"
            >
              <Upload className="h-8 w-8 text-coral" />
              <p className="mt-3 font-semibold">{fileName ?? 'Trascina qui un file .csv o .json'}</p>
              <p className="text-sm text-ink-muted">oppure</p>
              <input ref={fileRef} type="file" accept=".csv,.json,text/csv,application/json" hidden onChange={(e) => readFile(e.target.files?.[0])} />
              <Button variant="outline" size="sm" className="mt-2" onClick={() => fileRef.current?.click()}>Scegli file</Button>
            </div>
            <details className="mt-4">
              <summary className="cursor-pointer text-sm font-semibold text-ink-muted">…oppure incolla il contenuto</summary>
              <Textarea rows={6} value={text} onChange={(e) => { setText(e.target.value); setFormat(detectFormat('', e.target.value)); setFileName(null); }} placeholder='name;city;categories;source_url…' className="mt-2 font-mono text-xs" />
            </details>

            <h2 className="mt-8 text-lg font-bold">2. Opzioni</h2>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              <Field label="Formato">
                <Select value={format} onChange={(e) => setFormat(e.target.value as 'csv' | 'json')}>
                  <option value="csv">CSV (separatore , ; o tab)</option>
                  <option value="json">JSON</option>
                </Select>
              </Field>
              <Field label="Stato dati predefinito" hint="Per i record che non lo specificano.">
                <Select value={opts.defaultStatus} onChange={(e) => setOpts({ ...opts, defaultStatus: e.target.value as DataStatus })}>
                  {(['unverified', 'partially_verified', 'verified'] as DataStatus[]).map((k) => <option key={k} value={k}>{DATA_STATUS[k].label}</option>)}
                </Select>
              </Field>
            </div>
            <div className="mt-2">
              <Toggle label="Pubblica subito i nuovi locali" description="Consigliato: lascia disattivato, verifica le schede e pubblicale dall’elenco ristoranti." checked={opts.publish} onChange={(v) => setOpts({ ...opts, publish: v })} />
            </div>
            {error && <div className="mt-4"><Alert tone="error">{error}</Alert></div>}
            <div className="mt-6 flex justify-end">
              <Button size="lg" loading={busy} disabled={!text.trim() || !ready} onClick={analyze}>Analizza file</Button>
            </div>
          </section>

          <aside className="space-y-4">
            <section className="card p-5">
              <h2 className="font-bold">Modelli</h2>
              <p className="mt-1 text-sm text-ink-muted">Intestazioni in inglese o italiano. Categorie multiple separate da “|”.</p>
              <div className="mt-3 grid gap-2">
                <a href="/templates/ristoranti-template.csv" download className="inline-flex items-center gap-2 rounded-2xl border border-line bg-white px-4 py-2.5 text-sm font-semibold hover:border-ink"><FileSpreadsheet className="h-4 w-4 text-coral" /> Modello CSV <Download className="ml-auto h-4 w-4" /></a>
                <a href="/templates/ristoranti-template.json" download className="inline-flex items-center gap-2 rounded-2xl border border-line bg-white px-4 py-2.5 text-sm font-semibold hover:border-ink"><FileJson className="h-4 w-4 text-coral" /> Modello JSON <Download className="ml-auto h-4 w-4" /></a>
              </div>
            </section>
            <section className="rounded-3xl bg-cream p-5 text-sm text-ink-soft">
              <p className="flex items-center gap-2 font-bold text-ink"><Info className="h-4 w-4 text-coral" /> Regole sui dati</p>
              <ul className="mt-2 list-disc space-y-1 pl-5">
                <li>Solo dati da fonti pubbliche verificabili, con <code>source_url</code>.</li>
                <li>Dato non verificabile = campo vuoto. Mai valori “plausibili”.</li>
                <li>Immagini importate solo con <code>image_rights_confirmed = true</code>.</li>
                <li>Niente descrizioni copiate da Google o siti dei locali.</li>
                <li>I duplicati non vengono mai creati automaticamente.</li>
              </ul>
            </section>
            <History2 batches={batches.data ?? []} />
          </aside>
        </div>
      )}

      {stage === 'preview' && (
        <div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
            <Stat label="Righe" value={stats.total} />
            <Stat label="Valide" value={stats.valid} tone="green" />
            <Stat label="Con errori" value={stats.errors} tone={stats.errors ? 'coral' : undefined} />
            <Stat label="Con avvisi" value={stats.warnings} tone={stats.warnings ? 'amber' : undefined} />
            <Stat label="Già presenti?" value={stats.dbDup} tone={stats.dbDup ? 'amber' : undefined} />
            <Stat label="Doppioni nel file" value={stats.fileDup} tone={stats.fileDup ? 'amber' : undefined} />
            <Stat label="Nuove" value={stats.fresh} tone="dark" />
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-2">
            {(
              [
                ['all', `Tutte (${stats.total})`],
                ['new', `Nuove (${stats.fresh})`],
                ['duplicates', `Duplicati (${stats.dbDup + stats.fileDup})`],
                ['errors', `Errori (${stats.errors})`],
                ['warnings', `Avvisi (${stats.warnings})`],
              ] as [RowFilter, string][]
            ).map(([k, l]) => <Chip key={k} active={filter === k} onClick={() => { setFilter(k); setPage(1); }}>{l}</Chip>)}
          </div>
          {stats.dbDup > 0 && (
            <div className="mt-4 flex flex-wrap items-center gap-2 rounded-3xl border border-amber-200 bg-amber-50 p-4 text-sm">
              <AlertTriangle className="h-4 w-4 text-amber-700" />
              <span className="mr-auto">{stats.dbDup} righe somigliano a locali già presenti. Per tutti:</span>
              <Button size="sm" variant="outline" onClick={() => bulkDuplicates('skip')}>Ignora</Button>
              <Button size="sm" variant="outline" onClick={() => bulkDuplicates('merge')}>Unisci</Button>
              <Button size="sm" variant="outline" onClick={() => bulkDuplicates('update')}>Aggiorna</Button>
            </div>
          )}

          <ul className="mt-4 space-y-3">
            {filtered.slice((page - 1) * PAGE, page * PAGE).map((r) => <RowCard key={r.index} r={r} onDecision={setDecision} />)}
          </ul>
          {pages > 1 && (
            <div className="mt-4 flex items-center justify-center gap-3 text-sm">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(page - 1)}>Precedenti</Button>
              <span>{page} / {pages}</span>
              <Button size="sm" variant="outline" disabled={page >= pages} onClick={() => setPage(page + 1)}>Successive</Button>
            </div>
          )}

          <div className="pb-safe sticky bottom-0 z-10 -mx-4 mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-line bg-paper/95 px-4 py-4 backdrop-blur sm:mx-0 sm:rounded-3xl sm:border sm:px-5">
            <p className="text-sm">
              <strong>{stats.toWrite}</strong> righe verranno scritte · {opts.publish ? 'nuovi locali pubblicati' : 'nuovi locali in bozza'} · stato predefinito “{DATA_STATUS[opts.defaultStatus].label}”
            </p>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={reset}>Annulla</Button>
              <Button variant="outline" icon={<Download className="h-4 w-4" />} onClick={downloadReport}>Report</Button>
              <Button disabled={!stats.toWrite} onClick={run}>Importa</Button>
            </div>
          </div>
        </div>
      )}

      {stage === 'running' && (
        <section className="card mx-auto max-w-lg p-8 text-center">
          <p className="font-bold">Import in corso…</p>
          <div className="mt-4 h-2 overflow-hidden rounded-full bg-cream"><div className="h-full rounded-full bg-coral transition-all" style={{ width: `${progress}%` }} /></div>
          <p className="mt-2 text-sm text-ink-muted tabular-nums">{progress}%</p>
          <p className="mt-4 text-xs text-ink-muted">Non chiudere la pagina.</p>
        </section>
      )}

      {stage === 'done' && summary && (
        <section className="card mx-auto max-w-2xl p-6 sm:p-8">
          <div className="flex items-center gap-3">
            {summary.errors.length ? <AlertTriangle className="h-8 w-8 text-amber-600" /> : <CheckCircle2 className="h-8 w-8 text-leaf" />}
            <h2 className="text-2xl font-extrabold">Import completato</h2>
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-5">
            <Stat label="Creati" value={summary.created} tone="green" />
            <Stat label="Aggiornati" value={summary.updated} />
            <Stat label="Uniti" value={summary.merged} />
            <Stat label="Ignorati" value={summary.skipped} />
            <Stat label="Errori" value={summary.errors.length} tone={summary.errors.length ? 'coral' : undefined} />
          </div>
          {summary.errors.length > 0 && (
            <div className="mt-5 max-h-64 overflow-y-auto rounded-2xl border border-line">
              <table className="w-full text-left text-sm">
                <tbody className="divide-y divide-line">
                  {summary.errors.map((e, i) => (
                    <tr key={i}><td className="w-16 px-3 py-2 text-ink-muted">Riga {e.row}</td><td className="px-3 py-2">{e.name && <strong>{e.name}: </strong>}{e.message}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="mt-6 flex flex-wrap gap-2">
            <Link to="/admin/restaurants?sort=updated&demo=no" className="inline-flex h-11 items-center rounded-full bg-ink px-5 text-sm font-semibold text-white">Rivedi i locali importati</Link>
            <Button variant="outline" icon={<Download className="h-4 w-4" />} onClick={downloadReport}>Scarica report</Button>
            <Button variant="ghost" onClick={reset}>Nuovo import</Button>
          </div>
        </section>
      )}
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone?: 'green' | 'coral' | 'amber' | 'dark' }) {
  const t = { green: 'text-emerald-700', coral: 'text-coral-700', amber: 'text-amber-700', dark: 'text-ink' };
  return (
    <div className="rounded-3xl border border-line bg-white p-4">
      <p className="text-xs text-ink-muted">{label}</p>
      <p className={cn('mt-1 font-display text-2xl font-extrabold tabular-nums', tone && t[tone])}>{value}</p>
    </div>
  );
}

function RowCard({ r, onDecision }: { r: ImportRow; onDecision: (index: number, d: ImportDecision, targetId?: string) => void }) {
  const [open, setOpen] = useState(false);
  const hasMatch = r.matches.length > 0;
  const options: ImportDecision[] = !r.record ? ['skip'] : hasMatch ? ['skip', 'merge', 'update', 'create_anyway'] : r.duplicateOfRow ? ['skip', 'create_anyway'] : ['create', 'skip'];
  const best = r.matches.find((m) => m.candidate.id === r.targetId) ?? r.matches[0];
  return (
    <li className={cn('rounded-3xl border bg-white p-4', !r.record ? 'border-coral-200' : hasMatch || r.duplicateOfRow ? 'border-amber-200' : 'border-line')}>
      <div className="flex flex-wrap items-start gap-3">
        <span className="rounded-full bg-cream px-2 py-0.5 text-xs font-semibold tabular-nums text-ink-muted">#{r.index}</span>
        <div className="min-w-0 flex-1 basis-[calc(100%-3rem)] sm:basis-auto">
          <p className="truncate font-semibold">{r.record?.name ?? String(r.raw.name ?? r.raw.nome ?? '(senza nome)')}</p>
          <p className="truncate text-xs text-ink-muted">
            {r.record ? [r.record.city_name, r.record.address, r.record.category_slugs.join(', ')].filter(Boolean).join(' · ') : 'Riga non valida'}
          </p>
          <div className="mt-1.5 flex flex-wrap gap-1">
            {r.record && <Badge className="whitespace-nowrap" tone={DATA_STATUS[r.record.data_status ?? 'unverified'].tone}>{DATA_STATUS[r.record.data_status ?? 'unverified'].label}</Badge>}
            {r.record?.source_url ? <Badge className="whitespace-nowrap" tone="outline">con fonte</Badge> : r.record && <Badge className="whitespace-nowrap" tone="coral">senza fonte</Badge>}
            {r.errors.length > 0 && <Badge className="whitespace-nowrap" tone="coral" icon={<XCircle className="h-3 w-3" />}>{r.errors.length} errori</Badge>}
            {r.warnings.length > 0 && <Badge className="whitespace-nowrap" tone="amber" icon={<AlertTriangle className="h-3 w-3" />}>{r.warnings.length} avvisi</Badge>}
          </div>
        </div>
        <Select value={r.decision} onChange={(e) => onDecision(r.index, e.target.value as ImportDecision)} disabled={!r.record} className="!h-10 !py-0 text-sm sm:!w-auto" aria-label={`Decisione riga ${r.index}`}>
          {options.map((o) => <option key={o} value={o}>{DECISION_LABEL[o]}</option>)}
        </Select>
      </div>

      {best && (
        <div className="mt-3 rounded-2xl bg-amber-50 p-3 text-sm">
          <p className="font-semibold text-amber-900">
            Possibile duplicato: <Link to={`/admin/restaurants/${best.candidate.id}`} target="_blank" className="underline">{best.candidate.name}</Link>{' '}
            <span className="font-normal">({best.confidence === 'certain' ? 'certo' : best.confidence === 'high' ? 'molto probabile' : 'possibile'} · {best.score}/100)</span>
          </p>
          <p className="text-amber-900/80">{best.reasons.join(' · ')}</p>
          {best.candidate.owner_id && <p className="mt-1 text-xs text-amber-900/80">Locale rivendicato: “Aggiorna” verrà eseguito come “Unisci” per non sovrascrivere i dati del titolare.</p>}
          {r.matches.length > 1 && (
            <Field label="Confronta con" className="mt-2 max-w-sm">
              <Select value={r.targetId} onChange={(e) => onDecision(r.index, r.decision, e.target.value)} className="!h-9 !py-0 text-sm">
                {r.matches.map((m) => <option key={m.candidate.id} value={m.candidate.id}>{m.candidate.name} ({m.score})</option>)}
              </Select>
            </Field>
          )}
        </div>
      )}

      {(r.errors.length > 0 || r.warnings.length > 0) && (
        <button onClick={() => setOpen(!open)} className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-ink-muted">
          <ChevronDown className={cn('h-3.5 w-3.5 transition', open && 'rotate-180')} /> Dettagli
        </button>
      )}
      {open && (
        <ul className="mt-2 space-y-1 text-xs">
          {r.errors.map((e) => <li key={e} className="text-coral-700">✕ {e}</li>)}
          {r.warnings.map((w) => <li key={w} className="text-amber-800">⚠ {w}</li>)}
        </ul>
      )}
    </li>
  );
}

function History2({ batches }: { batches: { id: string; file_name: string | null; created_at: string; created_count: number; updated_count: number; merged_count: number; error_count: number }[] }) {
  if (!batches.length) return null;
  return (
    <section className="card p-5">
      <h2 className="flex items-center gap-2 font-bold"><History className="h-4 w-4 text-coral" /> Ultimi import</h2>
      <ul className="mt-3 divide-y divide-line text-sm">
        {batches.slice(0, 6).map((b) => (
          <li key={b.id} className="py-2">
            <p className="truncate font-medium">{b.file_name ?? 'import'}</p>
            <p className="text-xs text-ink-muted">{formatDate(b.created_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} · +{b.created_count} creati · {b.updated_count + b.merged_count} aggiornati · {b.error_count} errori</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
