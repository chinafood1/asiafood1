import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { AlertTriangle, Play, RefreshCw, RotateCcw, XCircle } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { cn, formatPrice } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api } from '@/services';
import type { AdminOrderDetail, AdminOrderFilters, MarketplaceStats } from '@/types/orders';
import { ISSUE_TYPES, ORDER_STATUS_LABEL, PAYMENT_STATUS_LABEL } from '@/types/orders';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader, Spinner } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PageTitle, StatTile } from '@/components/layout/DashboardLayout';
import { OrderStatusBadge, OrderTimeline, PaymentBadge, PriceSummary, dayTimeOf } from '@/components/orders/OrderParts';

const PAGE = 50;
const pct = (v: number) => `${(v * 100).toFixed(1).replace('.', ',')}%`;

// ═════════════════════════════════════════════════════════════
//  /admin/orders
// ═════════════════════════════════════════════════════════════
export function AdminOrders() {
  useSeo({ title: 'Admin · Ordini', noindex: true });
  const { cities } = useReferenceData();
  const [params, setParams] = useSearchParams();
  const offset = Number(params.get('offset') ?? 0) || 0;
  const filters: AdminOrderFilters = {
    q: params.get('q') || undefined,
    status: params.get('status') || undefined,
    payment_status: params.get('payment') || undefined,
    order_type: params.get('type') || undefined,
    restaurant_id: params.get('restaurant') || undefined,
    city_id: params.get('city') || undefined,
    from: params.get('from') || undefined,
    to: params.get('to') || undefined,
    issues: params.get('issues') === '1' || undefined,
    limit: PAGE,
    offset,
  };
  const list = useAsync(() => api.adminListOrders(filters), [params.toString()]);
  const [openId, setOpenId] = useState<string | null>(params.get('order'));
  const set = (k: string, v: string | undefined) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v);
    else next.delete(k);
    if (k !== 'offset') next.delete('offset');
    setParams(next, { replace: true });
  };
  const rows = list.data?.items ?? [];
  const total = list.data?.total ?? 0;

  return (
    <div>
      <PageTitle title="Ordini" subtitle="Tutti gli ordini del marketplace. Stato pagamento sincronizzato dai webhook Stripe." action={<Link to="/admin/marketplace" className="font-semibold text-coral-700">Dashboard marketplace →</Link>} />
      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Input aria-label="Cerca" placeholder="AF-…, cliente, email" defaultValue={filters.q} onKeyDown={(e) => e.key === 'Enter' && set('q', (e.target as HTMLInputElement).value.trim() || undefined)} />
        <Select aria-label="Stato" value={filters.status ?? ''} onChange={(e) => set('status', e.target.value || undefined)}>
          <option value="">Tutti gli stati</option>
          {Object.entries(ORDER_STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
        <Select aria-label="Pagamento" value={filters.payment_status ?? ''} onChange={(e) => set('payment', e.target.value || undefined)}>
          <option value="">Tutti i pagamenti</option>
          {Object.entries(PAYMENT_STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
        <Select aria-label="Tipo" value={filters.order_type ?? ''} onChange={(e) => set('type', e.target.value || undefined)}>
          <option value="">Ritiro e consegna</option>
          <option value="takeaway">Ritiro</option>
          <option value="delivery">Consegna</option>
        </Select>
        <Select aria-label="Città" value={filters.city_id ?? ''} onChange={(e) => set('city', e.target.value || undefined)}>
          <option value="">Tutte le città</option>
          {cities.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <Field label="Dal"><Input type="date" value={filters.from ?? ''} onChange={(e) => set('from', e.target.value || undefined)} /></Field>
        <Field label="Al"><Input type="date" value={filters.to ?? ''} onChange={(e) => set('to', e.target.value || undefined)} /></Field>
        <div className="flex items-end gap-2">
          <Chip active={!!filters.issues} onClick={() => set('issues', filters.issues ? undefined : '1')}>Con segnalazioni</Chip>
          {filters.restaurant_id && <Chip active onClick={() => set('restaurant', undefined)}>Ristorante ×</Chip>}
        </div>
      </div>

      {list.loading && !list.data ? <PageLoader /> : list.error ? <Alert tone="error">{list.error.message}</Alert> : rows.length === 0 ? (
        <EmptyState icon="🧾" title="Nessun ordine" text="Con questi filtri non ci sono ordini." />
      ) : (
        <>
          <p className="mb-2 text-sm text-ink-muted">{total} ordini</p>
          <div className="overflow-x-auto rounded-4xl border border-line bg-white">
            <table className="w-full min-w-[980px] text-left text-sm" data-testid="admin-orders">
              <thead>
                <tr className="border-b border-line text-xs uppercase tracking-wider text-ink-muted">
                  <th className="px-4 py-3">Ordine</th><th className="px-4 py-3">Ristorante</th><th className="px-4 py-3">Cliente</th><th className="px-4 py-3">Tipo</th>
                  <th className="px-4 py-3 text-right">Totale</th><th className="px-4 py-3">Stato</th><th className="px-4 py-3">Pagamento</th><th className="px-4 py-3 text-right">Commissione</th><th className="px-4 py-3">Note</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((o) => (
                  <tr key={o.id} className="cursor-pointer border-t border-line hover:bg-cream/50" onClick={() => setOpenId(o.id)}>
                    <td className="px-4 py-3"><button type="button" className="font-mono font-bold hover:text-coral-700" onClick={() => setOpenId(o.id)}>{o.order_number}</button><span className="block text-xs text-ink-muted">{dayTimeOf(o.created_at)}</span></td>
                    <td className="px-4 py-3">{o.restaurant.name}<span className="block text-xs text-ink-muted">{o.city ?? ''}</span></td>
                    <td className="px-4 py-3">{o.customer_name}</td>
                    <td className="px-4 py-3">{o.order_type === 'delivery' ? 'Consegna' : 'Ritiro'}</td>
                    <td className="px-4 py-3 text-right font-semibold tabular-nums">{formatPrice(o.total)}{o.amount_refunded > 0 && <span className="block text-xs text-coral-700">−{formatPrice(o.amount_refunded)}</span>}</td>
                    <td className="px-4 py-3"><OrderStatusBadge status={o.status} /></td>
                    <td className="px-4 py-3"><PaymentBadge status={o.payment_status} /></td>
                    <td className="px-4 py-3 text-right tabular-nums">{formatPrice(o.platform_fee + o.service_fee)}</td>
                    <td className="px-4 py-3">
                      {o.risk_flags.length > 0 && <Badge tone="coral" icon={<AlertTriangle className="h-3 w-3" />}>{o.risk_flags.length} rischio</Badge>}
                      {o.open_issues > 0 && <Badge tone="amber">{o.open_issues} segnalaz.</Badge>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex justify-between">
            <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => set('offset', String(Math.max(0, offset - PAGE)))}>Precedenti</Button>
            <Button variant="outline" size="sm" disabled={offset + PAGE >= total} onClick={() => set('offset', String(offset + PAGE))}>Successivi</Button>
          </div>
        </>
      )}
      <AdminOrderSheet id={openId} onClose={() => setOpenId(null)} onChanged={list.reload} />
    </div>
  );
}

function AdminOrderSheet({ id, onClose, onChanged }: { id: string | null; onClose: () => void; onChanged: () => void }) {
  const toast = useToast();
  const [d, setD] = useState<AdminOrderDetail | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [refundAmount, setRefundAmount] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [cancelReason, setCancelReason] = useState('');
  const [cancelRefund, setCancelRefund] = useState(true);

  const load = async (oid: string) => {
    try {
      const x = await api.adminOrderDetail(oid);
      setD(x);
      setNotes(x.internal.internal_notes ?? '');
      setRefundAmount(Math.max(0, x.amount_paid - x.amount_refunded).toFixed(2));
      setErr(null);
    } catch (e) {
      setErr((e as Error).message);
    }
  };
  useEffect(() => {
    setD(null);
    if (id) void load(id);
  }, [id]);

  const run = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    if (!id) return;
    setBusy(key);
    try {
      const res = await fn();
      toast(typeof res === 'string' ? res : ok);
      await load(id);
      onChanged();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };

  const refundable = d ? Math.max(0, d.amount_paid - d.amount_refunded) : 0;
  const rv = Number(refundAmount.replace(',', '.'));
  const closed = d && ['completed', 'rejected', 'cancelled', 'refunded'].includes(d.status);

  return (
    <Sheet open={!!id} onClose={onClose} title={d ? `Ordine ${d.order_number}` : 'Ordine'} wide>
      {err ? <Alert tone="error">{err}</Alert> : !d ? <div className="flex justify-center py-10"><Spinner className="h-8 w-8" /></div> : (
        <div className="space-y-6" data-testid="admin-order-detail">
          <div className="flex flex-wrap items-center gap-2">
            <OrderStatusBadge status={d.status} /><PaymentBadge status={d.payment_status} />
            <Badge tone="neutral">{d.order_type === 'delivery' ? 'Consegna' : 'Ritiro'}</Badge>
            <Badge tone={d.internal.stripe_environment === 'live' ? 'dark' : 'amber'}>{d.internal.payment_mode}{d.internal.stripe_environment ? ` · ${d.internal.stripe_environment}` : ''}</Badge>
            {d.internal.risk_flags.map((f) => <Badge key={f} tone="coral">{f}</Badge>)}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <section>
              <h3 className="mb-2 font-bold">Cronologia</h3>
              <OrderTimeline o={d} />
            </section>
            <section>
              <h3 className="mb-2 font-bold">Importi</h3>
              <PriceSummary q={d} />
              <dl className="mt-3 space-y-1 border-t border-line pt-3 text-sm">
                <div className="flex justify-between"><dt className="text-ink-muted">Commissione ({d.internal.commission_percent}% + {formatPrice(d.internal.commission_fixed)})</dt><dd className="tabular-nums">{formatPrice(d.internal.platform_fee)}</dd></div>
                <div className="flex justify-between"><dt className="text-ink-muted">Lordo ristorante</dt><dd className="tabular-nums">{formatPrice(d.internal.restaurant_gross)}</dd></div>
                <div className="flex justify-between"><dt className="text-ink-muted">Netto stimato ristorante</dt><dd className="tabular-nums">{formatPrice(d.internal.restaurant_net_estimated)}</dd></div>
                <div className="flex justify-between"><dt className="text-ink-muted">Pagato / rimborsato</dt><dd className="tabular-nums">{formatPrice(d.amount_paid)} / {formatPrice(d.amount_refunded)}</dd></div>
                {d.internal.payment_failures > 0 && <div className="flex justify-between"><dt className="text-ink-muted">Tentativi falliti</dt><dd>{d.internal.payment_failures}</dd></div>}
              </dl>
              <p className="mt-2 break-all font-mono text-[11px] text-ink-muted">{d.internal.stripe_payment_intent_id ?? 'nessun PaymentIntent'}{d.internal.payout_destination ? ` → ${d.internal.payout_destination}` : ''}</p>
            </section>
          </div>

          <section>
            <h3 className="mb-2 font-bold">Prodotti</h3>
            <ul className="divide-y divide-line text-sm">
              {d.items.map((it) => (
                <li key={it.id} className="flex justify-between gap-3 py-1.5">
                  <span>{it.quantity}× {it.name}{it.variant ? ` · ${it.variant}` : ''}{it.options.length > 0 && <span className="block text-xs text-ink-muted">{it.options.map((x) => x.name).join(', ')}</span>}</span>
                  <span className="tabular-nums">{formatPrice(it.line_total)}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="grid gap-4 sm:grid-cols-2">
            <div>
              <h3 className="mb-2 font-bold">Cliente</h3>
              <p className="text-sm">{d.customer_name}<span className="block text-ink-muted">{d.customer_email} · {d.customer_phone}</span>{d.internal.user_id ? 'Registrato' : 'Ospite'}</p>
              {d.delivery_address && <p className="mt-1 text-sm text-ink-muted">{[d.delivery_address.address_line_1, d.delivery_address.postal_code, d.delivery_address.city].filter(Boolean).join(', ')}{d.internal.delivery_distance_km != null ? ` · ${d.internal.delivery_distance_km.toFixed(1)} km` : ''}</p>}
            </div>
            <div>
              <h3 className="mb-2 font-bold">Ristorante</h3>
              <p className="text-sm"><Link to={`/admin/restaurants/${d.restaurant.id}`} className="font-semibold hover:text-coral-700">{d.restaurant.name}</Link><span className="block text-ink-muted">{d.restaurant.city}</span></p>
              {d.reject_reason && <p className="mt-1 text-sm text-coral-700">Rifiuto: {d.reject_reason}</p>}
              {d.cancel_reason && <p className="mt-1 text-sm text-coral-700">Annullamento: {d.cancel_reason}</p>}
            </div>
          </section>

          {d.refunds_admin.length > 0 && (
            <section>
              <h3 className="mb-2 font-bold">Rimborsi</h3>
              <ul className="space-y-1 text-sm">
                {d.refunds_admin.map((x) => (
                  <li key={x.id} className="flex flex-wrap justify-between gap-2"><span>{formatPrice(x.amount)} · {x.reason} · {x.requested_by_type}</span><span><Badge tone={x.status === 'succeeded' ? 'green' : x.status === 'failed' ? 'coral' : 'amber'}>{x.status}</Badge>{x.error && <span className="ml-2 text-xs text-coral-700">{x.error}</span>}</span></li>
                ))}
              </ul>
            </section>
          )}

          {d.issues_admin.length > 0 && (
            <section>
              <h3 className="mb-2 font-bold">Segnalazioni</h3>
              <ul className="space-y-3">
                {d.issues_admin.map((i) => <IssueRow key={i.id} issue={i} onSave={(status, resolution) => run(`issue-${i.id}`, () => api.adminOrderUpdate(d.id, { issue_id: i.id, issue_status: status, resolution }), 'Segnalazione aggiornata.')} />)}
              </ul>
            </section>
          )}

          <section className="grid gap-4 rounded-3xl bg-cream/60 p-4 sm:grid-cols-2">
            <div>
              <h3 className="mb-2 font-bold">Rimborso</h3>
              {refundable > 0 ? (
                <div className="space-y-2">
                  <Field label={`Importo (max ${formatPrice(refundable)})`}><Input inputMode="decimal" value={refundAmount} onChange={(e) => setRefundAmount(e.target.value)} /></Field>
                  <Field label="Motivo"><Input value={refundReason} onChange={(e) => setRefundReason(e.target.value)} /></Field>
                  <Button size="sm" disabled={!(rv > 0 && rv <= refundable + 1e-9) || refundReason.trim().length < 3} loading={busy === 'refund'} onClick={() => run('refund', () => api.refundOrder(d.id, Math.round(rv * 100) / 100, refundReason.trim()), 'Rimborso richiesto.')}><RotateCcw className="h-4 w-4" /> Rimborsa</Button>
                </div>
              ) : <p className="text-sm text-ink-muted">Niente da rimborsare.</p>}
            </div>
            <div>
              <h3 className="mb-2 font-bold">Annulla ordine</h3>
              {!closed ? (
                <div className="space-y-2">
                  <Field label="Motivo"><Input value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} /></Field>
                  <Toggle label="Rimborsa quanto pagato" checked={cancelRefund} onChange={setCancelRefund} />
                  <Button size="sm" variant="danger" disabled={cancelReason.trim().length < 3} loading={busy === 'cancel'} onClick={() => run('cancel', () => api.orderAction(d.id, 'cancel', { reason: cancelReason.trim(), refund: cancelRefund }), 'Ordine annullato.')}><XCircle className="h-4 w-4" /> Annulla ordine</Button>
                </div>
              ) : <p className="text-sm text-ink-muted">Ordine concluso.</p>}
            </div>
            <div className="sm:col-span-2">
              <Field label="Note interne (solo Admin)"><Textarea value={notes} maxLength={2000} onChange={(e) => setNotes(e.target.value)} /></Field>
              <div className="mt-2 flex flex-wrap gap-2">
                <Button size="sm" variant="dark" loading={busy === 'notes'} onClick={() => run('notes', () => api.adminOrderUpdate(d.id, { internal_notes: notes }), 'Note salvate.')}>Salva note</Button>
                {d.order_type === 'delivery' && <Link to={`/admin/dispatch?job=${d.id}`} className="inline-flex h-9 items-center rounded-full border border-line bg-white px-4 text-sm font-semibold">Timeline consegna</Link>}
                {d.internal.stripe_payment_intent_id && <Button size="sm" variant="outline" loading={busy === 'resync'} onClick={() => run('resync', () => api.adminResyncPayment(d.id), 'Sincronizzato.')}><RefreshCw className="h-4 w-4" /> Resync pagamento</Button>}
              </div>
            </div>
          </section>

          <section>
            <h3 className="mb-2 font-bold">Eventi (audit)</h3>
            <ol className="max-h-64 space-y-1 overflow-y-auto text-xs">
              {d.events.map((e, i) => <li key={i} className="flex gap-3"><span className="shrink-0 tabular-nums text-ink-muted">{dayTimeOf(e.created_at)}</span><span className="font-semibold">{e.type}</span><span className="text-ink-muted">{e.actor}</span></li>)}
            </ol>
          </section>
        </div>
      )}
    </Sheet>
  );
}

function IssueRow({ issue, onSave }: { issue: AdminOrderDetail['issues_admin'][number]; onSave: (status: string, resolution: string) => void }) {
  const [status, setStatus] = useState(issue.status);
  const [resolution, setResolution] = useState(issue.resolution ?? '');
  return (
    <li className="rounded-2xl border border-line p-3 text-sm">
      <p><strong>{ISSUE_TYPES.find((t) => t.value === issue.type)?.label ?? issue.type}</strong> · {dayTimeOf(issue.created_at)}</p>
      <p className="mt-1 text-ink-soft">{issue.description}</p>
      <div className="mt-2 grid gap-2 sm:grid-cols-[160px_1fr_auto]">
        <Select aria-label="Stato segnalazione" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="open">Aperta</option><option value="in_review">In verifica</option><option value="resolved">Risolta</option><option value="rejected">Respinta</option>
        </Select>
        <Input aria-label="Risoluzione" value={resolution} onChange={(e) => setResolution(e.target.value)} placeholder="Risposta al cliente" />
        <Button size="sm" onClick={() => onSave(status, resolution)}>Salva</Button>
      </div>
    </li>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/marketplace
// ═════════════════════════════════════════════════════════════
export function AdminMarketplace() {
  useSeo({ title: 'Admin · Marketplace', noindex: true });
  const toast = useToast();
  const [days, setDays] = useState(30);
  const stats = useAsync(() => api.getMarketplaceStats(days), [days]);
  const [ticking, setTicking] = useState(false);
  const s = stats.data;
  const tick = async () => {
    setTicking(true);
    try {
      const r = await api.runOrdersTick();
      toast(`Scheduler: ${r.expired} scaduti, ${r.accept_timeouts} senza risposta, ${r.reminders} promemoria, ${r.abandoned_carts} carrelli abbandonati.`);
      stats.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setTicking(false);
    }
  };
  return (
    <div className="space-y-6">
      <PageTitle title="Marketplace" subtitle="Solo ordini reali registrati. Le definizioni di GMV e ricavi sono indicate sotto." action={<Button variant="outline" loading={ticking} onClick={() => void tick()}><Play className="h-4 w-4" /> Esegui scheduler ordini</Button>} />
      <div className="flex gap-2" role="group" aria-label="Periodo">
        {[7, 30, 90].map((d) => <Chip key={d} active={days === d} onClick={() => setDays(d)}>{d} giorni</Chip>)}
      </div>
      {stats.loading && !s ? <PageLoader /> : stats.error ? <Alert tone="error">{stats.error.message}</Alert> : s && <MarketplaceBody s={s} />}
      <CommissionsPanel />
    </div>
  );
}

function MarketplaceBody({ s }: { s: MarketplaceStats }) {
  const typeTotal = s.takeaway + s.delivery;
  return (
    <>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4" data-testid="marketplace-stats">
        <StatTile accent label="GMV" value={formatPrice(s.gmv)} hint={`Netto rimborsi ${formatPrice(s.gmv_net_of_refunds)}`} />
        <StatTile label="Ordini oggi / mese" value={`${s.orders_today} / ${s.orders_month}`} hint={`${s.valid_orders} validi nel periodo`} />
        <StatTile label="Scontrino medio" value={formatPrice(s.aov)} />
        <StatTile label="Ricavi piattaforma" value={formatPrice(s.platform_revenue)} hint={`In maturazione ${formatPrice(s.platform_fees_pending)}`} />
        <StatTile label="Completati" value={s.completed} />
        <StatTile label="Annullati / rifiutati" value={s.cancelled} hint={`${s.unpaid_expired} non pagati scaduti`} />
        <StatTile label="Tasso rimborsi" value={pct(s.refund_rate)} hint={formatPrice(s.refunded_amount)} />
        <StatTile label="Ritiro / Consegna" value={`${s.takeaway} / ${s.delivery}`} hint={typeTotal ? `${Math.round((s.delivery / typeTotal) * 100)}% consegna` : undefined} />
      </div>

      <section className="card p-5 sm:p-7">
        <h2 className="text-lg font-bold">Ordini validi al giorno</h2>
        <DailyChart daily={s.daily} />
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-5 sm:p-7">
          <h2 className="text-lg font-bold">Funnel</h2>
          <p className="mt-1 text-sm text-ink-muted">Eventi registrati e sessioni distinte (non utenti unici). Carrelli abbandonati: {s.abandoned_carts}.</p>
          <Funnel steps={s.funnel} />
        </section>
        <section className="card p-5 sm:p-7">
          <h2 className="text-lg font-bold">Pagamenti e anomalie</h2>
          <dl className="mt-4 grid gap-2 text-sm">
            {([
              ['In attesa di pagamento', s.payments.awaiting_payment], ['In attesa del ristorante', s.payments.awaiting_restaurant], ['Tentativi di pagamento falliti', s.payments.failed_attempts],
              ['Rimborsi in coda', s.payments.refunds_pending], ['Rimborsi falliti', s.payments.refunds_failed], ['Contestazioni', s.payments.disputes],
              ['Ordini con segnali di rischio', s.payments.risk_flagged], ['Segnalazioni aperte', s.payments.open_issues], ['Webhook falliti', s.payments.webhook_failures],
            ] as [string, number][]).map(([l, v]) => (
              <div key={l} className="flex justify-between"><dt className="text-ink-muted">{l}</dt><dd className={cn('font-semibold tabular-nums', v > 0 && /falliti|Contest|rischio/.test(l) && 'text-coral-700')}>{v}</dd></div>
            ))}
          </dl>
          <Link to="/admin/orders?issues=1" className="mt-3 inline-block text-sm font-semibold text-coral-700">Ordini con segnalazioni →</Link>
        </section>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <RankTable title="Categorie principali" rows={s.top_categories} />
        <RankTable title="Città principali" rows={s.top_cities} />
      </div>

      <section className="card p-5 text-sm sm:p-7">
        <h2 className="text-lg font-bold">Definizioni</h2>
        <dl className="mt-3 space-y-2">
          {Object.entries(s.definitions).map(([k, v]) => <div key={k}><dt className="font-semibold">{k}</dt><dd className="text-ink-muted">{v}</dd></div>)}
        </dl>
      </section>
    </>
  );
}

/** Una serie (ordini validi), barre sottili, tooltip al passaggio e tabella per screen reader. */
function DailyChart({ daily }: { daily: MarketplaceStats['daily'] }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(...daily.map((d) => d.orders), 0);
  const label = (day: string) => new Date(`${day}T12:00:00`).toLocaleDateString('it-IT', { day: 'numeric', month: 'short' });
  if (daily.length === 0) return <p className="mt-4 text-sm text-ink-muted">Nessun ordine nel periodo.</p>;
  return (
    <figure className="mt-4">
      <figcaption className="sr-only">Ordini validi al giorno</figcaption>
      <div className="relative flex h-44 items-end gap-[2px] border-b border-line pb-px" onMouseLeave={() => setHover(null)}>
        {daily.map((d, i) => (
          <div key={d.day} className="relative flex h-full flex-1 items-end" onMouseEnter={() => setHover(i)} onFocus={() => setHover(i)} tabIndex={0} role="img" aria-label={`${label(d.day)}: ${d.orders} ordini, ${formatPrice(d.gmv)}`}>
            <div className={cn('w-full rounded-t-[4px] bg-coral/55 transition-colors', hover === i && 'bg-coral')} style={{ height: `${max ? Math.max((d.orders / max) * 100, d.orders ? 2 : 0) : 0}%` }} />
            {hover === i && (
              <div role="tooltip" className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 -translate-x-1/2 whitespace-nowrap rounded-xl bg-ink px-2.5 py-1.5 text-xs font-semibold text-white shadow-lift">
                {label(d.day)} · {d.orders} ordini · {formatPrice(d.gmv)}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="mt-1.5 flex justify-between text-[11px] text-ink-muted"><span>{label(daily[0]!.day)}</span><span>{label(daily[daily.length - 1]!.day)}</span></div>
      <table className="sr-only">
        <thead><tr><th>Giorno</th><th>Ordini</th><th>GMV</th></tr></thead>
        <tbody>{daily.map((d) => <tr key={d.day}><td>{d.day}</td><td>{d.orders}</td><td>{formatPrice(d.gmv)}</td></tr>)}</tbody>
      </table>
    </figure>
  );
}

function Funnel({ steps }: { steps: MarketplaceStats['funnel'] }) {
  const max = Math.max(...steps.map((s) => s.sessions ?? s.events), 1);
  return (
    <ol className="mt-4 space-y-2.5">
      {steps.map((s) => {
        const v = s.sessions ?? s.events;
        return (
          <li key={s.step}>
            <div className="flex justify-between text-sm"><span>{s.label}</span><span className="tabular-nums text-ink-muted">{s.sessions != null ? `${s.sessions} sessioni · ` : ''}{s.events} eventi</span></div>
            <div className="mt-1 h-2 rounded-full bg-cream"><div className="h-2 rounded-full bg-coral" style={{ width: `${(v / max) * 100}%` }} /></div>
          </li>
        );
      })}
    </ol>
  );
}

function RankTable({ title, rows }: { title: string; rows: { name: string; orders: number; gmv: number }[] }) {
  return (
    <section className="card p-5 sm:p-7">
      <h2 className="text-lg font-bold">{title}</h2>
      {rows.length === 0 ? <p className="mt-3 text-sm text-ink-muted">Nessun dato nel periodo.</p> : (
        <table className="mt-3 w-full text-sm">
          <thead><tr className="text-left text-xs uppercase tracking-wider text-ink-muted"><th className="py-1">Nome</th><th className="py-1 text-right">Ordini</th><th className="py-1 text-right">GMV</th></tr></thead>
          <tbody>{rows.map((r) => <tr key={r.name} className="border-t border-line"><td className="py-1.5">{r.name}</td><td className="py-1.5 text-right tabular-nums">{r.orders}</td><td className="py-1.5 text-right tabular-nums">{formatPrice(r.gmv)}</td></tr>)}</tbody>
        </table>
      )}
    </section>
  );
}

function CommissionsPanel() {
  const toast = useToast();
  const c = useAsync(() => api.getCommissionSettings(), []);
  const [g, setG] = useState({ percent: '10', fixed: '0', service_fee_enabled: false, service_fee_amount: '0.99' });
  const [ov, setOv] = useState({ restaurant_id: '', percentage_fee: '8', fixed_fee: '0', note: '' });
  const [q, setQ] = useState('');
  const restaurants = useAsync(() => (q.trim().length >= 2 ? api.adminListRestaurants({ q: q.trim(), page: 1, pageSize: 10 } as Parameters<typeof api.adminListRestaurants>[0]).then((x) => x.rows) : Promise.resolve([])), [q]);
  useEffect(() => {
    if (c.data) setG({ percent: String(c.data.global_percent), fixed: String(c.data.global_fixed), service_fee_enabled: c.data.service_fee_enabled, service_fee_amount: String(c.data.service_fee_amount) });
  }, [c.data]);
  const n = (v: string) => Number(v.replace(',', '.'));
  const saveGlobal = async () => {
    try { await api.saveGlobalCommission({ percent: n(g.percent), fixed: n(g.fixed), service_fee_enabled: g.service_fee_enabled, service_fee_amount: n(g.service_fee_amount) }); toast('Commissione globale salvata (vale per i nuovi ordini).'); c.reload(); } catch (e) { toast((e as Error).message, 'error'); }
  };
  const addOverride = async () => {
    try { await api.addCommissionOverride({ restaurant_id: ov.restaurant_id, percentage_fee: n(ov.percentage_fee), fixed_fee: n(ov.fixed_fee), note: ov.note || null }); toast('Commissione personalizzata aggiunta.'); setOv({ ...ov, restaurant_id: '', note: '' }); c.reload(); } catch (e) { toast((e as Error).message, 'error'); }
  };
  return (
    <section className="card p-5 sm:p-7" data-testid="commissions">
      <h2 className="text-lg font-bold">Commissioni</h2>
      <p className="mt-1 text-sm text-ink-muted">Base di calcolo: subtotale − sconti + consegna. Ogni ordine salva la commissione applicata: le modifiche valgono solo per i nuovi ordini.</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-4">
        <Field label="Percentuale (%)"><Input inputMode="decimal" value={g.percent} onChange={(e) => setG({ ...g, percent: e.target.value })} /></Field>
        <Field label="Quota fissa (€)"><Input inputMode="decimal" value={g.fixed} onChange={(e) => setG({ ...g, fixed: e.target.value })} /></Field>
        <Field label="Costo di servizio (€)"><Input inputMode="decimal" value={g.service_fee_amount} onChange={(e) => setG({ ...g, service_fee_amount: e.target.value })} /></Field>
        <div className="flex items-end"><Toggle label="Costo di servizio attivo" checked={g.service_fee_enabled} onChange={(v) => setG({ ...g, service_fee_enabled: v })} /></div>
      </div>
      <Button className="mt-3" onClick={() => void saveGlobal()}>Salva commissione globale</Button>

      <h3 className="mt-7 font-bold">Personalizzate per ristorante</h3>
      <ul className="mt-2 divide-y divide-line text-sm">
        {(c.data?.overrides ?? []).map((o) => <li key={o.id} className="flex flex-wrap justify-between gap-2 py-2"><span><strong>{o.restaurant_name}</strong> · {o.percentage_fee}% + {formatPrice(o.fixed_fee)}{o.note ? ` · ${o.note}` : ''}</span><span className="text-ink-muted">dal {dayTimeOf(o.effective_from)}</span></li>)}
        {c.data?.overrides.length === 0 && <li className="py-2 text-ink-muted">Nessuna.</li>}
      </ul>
      <div className="mt-3 grid gap-3 sm:grid-cols-5">
        <Field label="Cerca ristorante" className="sm:col-span-2">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nome…" />
          {(restaurants.data ?? []).length > 0 && (
            <Select aria-label="Ristorante" className="mt-2" value={ov.restaurant_id} onChange={(e) => setOv({ ...ov, restaurant_id: e.target.value })}>
              <option value="">Scegli…</option>
              {(restaurants.data ?? []).map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </Select>
          )}
        </Field>
        <Field label="%"><Input inputMode="decimal" value={ov.percentage_fee} onChange={(e) => setOv({ ...ov, percentage_fee: e.target.value })} /></Field>
        <Field label="Fissa (€)"><Input inputMode="decimal" value={ov.fixed_fee} onChange={(e) => setOv({ ...ov, fixed_fee: e.target.value })} /></Field>
        <Field label="Nota"><Input value={ov.note} onChange={(e) => setOv({ ...ov, note: e.target.value })} /></Field>
      </div>
      <Button className="mt-3" variant="outline" disabled={!ov.restaurant_id} onClick={() => void addOverride()}>Aggiungi commissione personalizzata</Button>
    </section>
  );
}
