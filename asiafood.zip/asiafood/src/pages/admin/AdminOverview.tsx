import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, FlaskConical, RotateCcw, Upload } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { formatDate } from '@/lib/format';
import { api, isDemoMode } from '@/services';
import { resetDemoData } from '@/services/demoSource';
import { ClaimStatusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Toggle } from '@/components/ui/Field';
import { PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { PageTitle, StatTile } from '@/components/layout/DashboardLayout';
import { RevenuePanel } from './AdminBillingPages';

export default function AdminOverview() {
  const stats = useAsync(() => api.getAdminStats(), []);
  const claims = useAsync(() => api.listClaims({ status: 'open' }), []);
  const toast = useToast();
  const [savingDemo, setSavingDemo] = useState(false);
  useSeo({ title: 'Admin', noindex: true });
  if (stats.loading && !stats.data) return <PageLoader />;
  const s = (stats.data ?? {}) as Record<string, number>;
  const showDemo = (stats.data?.show_demo_data as boolean | undefined) ?? true;

  const toggleDemo = async (v: boolean) => {
    setSavingDemo(true);
    try {
      await api.setSetting('show_demo_data', v);
      toast(v ? 'Dati demo visibili al pubblico' : 'Dati demo nascosti al pubblico');
      stats.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setSavingDemo(false);
    }
  };

  const tile = (to: string, el: React.ReactNode) => <Link to={to} className="block transition hover:-translate-y-0.5">{el}</Link>;

  return (
    <div>
      <PageTitle
        title="Panoramica"
        subtitle="Lo stato della piattaforma a colpo d’occhio."
        action={<Link to="/admin/import" className="inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-sm font-semibold text-white"><Upload className="h-4 w-4" /> Importa ristoranti</Link>}
      />
      {stats.error && <p className="mb-4 text-sm text-coral-700">{stats.error.message}</p>}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tile('/admin/restaurants?active=yes', <StatTile accent label="Pubblicati" value={s.restaurants_active ?? 0} hint={`${s.restaurants_total ?? 0} schede totali`} />)}
        {tile('/admin/restaurants?active=no&sort=updated', <StatTile label="Bozze da verificare" value={s.restaurants_draft ?? 0} hint="Non visibili al pubblico" />)}
        {tile('/admin/restaurants?demo=no', <StatTile label="Locali reali" value={s.restaurants_real ?? 0} hint={`${s.restaurants_verified ?? 0} verificati · ${s.restaurants_unverified ?? 0} da verificare`} />)}
        {tile('/admin/restaurants?claimed=yes', <StatTile label="Rivendicati" value={s.restaurants_claimed ?? 0} hint={`${s.owners_total ?? 0} ristoratori`} />)}
        {tile('/admin/claims', <StatTile label="Claim da gestire" value={s.claims_pending ?? 0} hint={`${s.claims_more_info ?? 0} in attesa di risposta`} />)}
        {tile('/admin/reports', <StatTile label="Segnalazioni aperte" value={s.reports_open ?? 0} />)}
        {tile('/admin/restaurants?coords=missing', <StatTile label="Coordinate mancanti" value={s.restaurants_no_coords ?? 0} hint="Nell'elenco ma non sulla mappa" />)}
        {tile('/admin/modifiche', <StatTile label="Modifiche posizione" value={s.change_requests_pending ?? 0} hint="Proposte dai titolari" />)}
        {tile('/admin/plans', <StatTile label="Richieste upgrade" value={s.upgrade_requests_open ?? 0} hint={`${s.restaurants_paid ?? 0} locali con piano a pagamento`} />)}
        <StatTile label="Prenotazioni (30 gg)" value={s.reservations_30d ?? 0} hint={`${s.reservations_pending ?? 0} da confermare · ${s.emails_pending ?? 0} email in coda`} />
        <StatTile label="Coupon (30 gg)" value={s.coupons_claimed_30d ?? 0} hint={`${s.coupons_redeemed_30d ?? 0} utilizzati`} />
        <StatTile label="Aperture mappa (30 gg)" value={s.map_opens_30d ?? 0} hint={`${s.near_me_30d ?? 0} ricerche “vicino a me”`} />
        <StatTile label="Utenti" value={s.users_total ?? 0} />
        <StatTile label="Visualizzazioni (30 gg)" value={s.views_30d ?? 0} hint={`${s.events_30d ?? 0} eventi`} />
        {tile('/admin/sponsorships', <StatTile label="Campagne sponsorizzate" value={s.sponsored_active ?? 0} hint="Attive ora" />)}
        {tile('/admin/system/stripe', <StatTile label="Webhook con errore (7 gg)" value={s.webhook_failed_7d ?? 0} hint={`${s.publication_requests ?? 0} richieste di pubblicazione`} />)}
      </div>

      <div className="mt-8"><RevenuePanel /></div>

      <section className="card mt-8 p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold">Rivendicazioni da gestire</h2>
          <Link to="/admin/claims" className="inline-flex items-center gap-1 text-sm font-semibold text-coral-700">Tutte <ArrowRight className="h-4 w-4" /></Link>
        </div>
        {(claims.data ?? []).length === 0 ? (
          <p className="mt-3 text-sm text-ink-muted">Nessuna richiesta aperta. 🎉</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {claims.data!.slice(0, 6).map((c) => (
              <li key={c.id}>
                <Link to={`/admin/claims/${c.id}`} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm hover:text-coral-700">
                  <span><strong>{c.first_name} {c.last_name}</strong> → {c.restaurant?.name}</span>
                  <span className="flex items-center gap-2 text-ink-muted">{formatDate(c.submitted_at, { day: 'numeric', month: 'short' })} <ClaimStatusBadge status={c.status} /></span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      {(s.restaurants_demo ?? 0) > 0 && (
        <section className="mt-6 rounded-3xl border border-dashed border-line bg-white p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
            <FlaskConical className="h-6 w-6 shrink-0 text-coral" />
            <div className="flex-1 text-sm">
              <p className="font-semibold">{s.restaurants_demo} schede DEMO presenti</p>
              <p className="text-ink-muted">Quando iniziano a esserci dati reali, nascondi i demo al pubblico. Restano nel database (is_demo = true) e visibili qui.</p>
              <div className="mt-3 max-w-md">
                <Toggle label="Mostra i dati demo al pubblico" checked={showDemo} disabled={savingDemo} onChange={toggleDemo} />
              </div>
              <p className="mt-2 text-xs text-ink-muted">
                Per eliminarli definitivamente: <code className="rounded bg-cream px-1.5 py-0.5">delete from restaurants where is_demo;</code>
              </p>
            </div>
            {isDemoMode && (
              <Button
                variant="outline"
                size="sm"
                icon={<RotateCcw className="h-4 w-4" />}
                onClick={() => {
                  if (confirm('Ripristinare i dati demo iniziali? Le modifiche locali andranno perse.')) {
                    resetDemoData();
                    window.location.reload();
                  }
                }}
              >
                Ripristina dati demo
              </Button>
            )}
          </div>
        </section>
      )}
    </div>
  );
}
