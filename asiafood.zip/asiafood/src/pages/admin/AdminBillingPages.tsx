import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, ExternalLink, RefreshCw, Wand2 } from 'lucide-react';
import { BILLING } from '@/config/app';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { billingErrorMessage, CAMPAIGN_STATUS, daysUntil, formatCents, formatDay, INTERVAL_LABEL, planName, SUBSCRIPTION_SOURCE } from '@/lib/billing';
import { cn } from '@/lib/format';
import { useSeo } from '@/lib/seo';
import { api, type AdminSubscriptionFilter } from '@/services';
import type { AdminSubscriptionRow, BillingSettings, CampaignStatus, PlanCode, RevenueStats, SponsoredCampaign } from '@/types/domain';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PageTitle, StatTile } from '@/components/layout/DashboardLayout';
import { BillingModeBadge, SubscriptionStatusBadge } from '@/components/billing/BillingUI';
import { CampaignSheet, GrantPlanForm, stripeDashboardUrl } from '@/components/billing/AdminBilling';
import { CampaignStatsTable } from '@/components/billing/Ads';

// ═════════════════════════════════════════════════════════════
//  Ricavi (Panoramica Admin): solo abbonamenti Stripe reali
// ═════════════════════════════════════════════════════════════
const monthLabel = (ym: string) => new Date(`${ym}-15T12:00:00`).toLocaleDateString('it-IT', { month: 'short' });

/** Grafico MRR: una serie, barre sottili, valori al passaggio del mouse e tabella per screen reader. */
function MrrChart({ series }: { series: RevenueStats['mrr_series'] }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(...series.map((x) => x.mrr_cents), 0);
  const last = series.length - 1;
  return (
    <figure className="mt-2">
      <figcaption className="sr-only">MRR degli ultimi 12 mesi</figcaption>
      <div className="relative flex h-44 items-end gap-1.5 border-b border-line pb-px sm:gap-2" onMouseLeave={() => setHover(null)}>
        {series.map((m, i) => {
          const h = max ? Math.max((m.mrr_cents / max) * 100, m.mrr_cents ? 2 : 0) : 0;
          return (
            <div key={m.month} className="group relative flex h-full flex-1 items-end" onMouseEnter={() => setHover(i)} onFocus={() => setHover(i)} tabIndex={0} role="img" aria-label={`${monthLabel(m.month)}: ${formatCents(m.mrr_cents)}`}>
              <div className={cn('w-full rounded-t-[4px] transition-colors', i === last ? 'bg-coral' : 'bg-coral/45', hover === i && 'bg-coral')} style={{ height: `${h}%` }} />
              {hover === i && (
                <div role="tooltip" className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 -translate-x-1/2 whitespace-nowrap rounded-xl bg-ink px-2.5 py-1.5 text-xs font-semibold text-white shadow-lift">
                  {monthLabel(m.month)} · {formatCents(m.mrr_cents)}
                </div>
              )}
            </div>
          );
        })}
        {max === 0 && <p className="absolute inset-0 flex items-center justify-center text-sm text-ink-muted">Ancora nessun ricavo ricorrente: il grafico mostra zero.</p>}
      </div>
      <div className="mt-1.5 flex gap-1.5 text-[11px] text-ink-muted sm:gap-2">
        {series.map((m) => <span key={m.month} className="flex-1 text-center">{monthLabel(m.month)}</span>)}
      </div>
      <table className="sr-only">
        <thead><tr><th>Mese</th><th>MRR</th></tr></thead>
        <tbody>{series.map((m) => <tr key={m.month}><td>{m.month}</td><td>{formatCents(m.mrr_cents)}</td></tr>)}</tbody>
      </table>
    </figure>
  );
}

export function RevenuePanel() {
  const rev = useAsync(() => api.getRevenueStats(), []);
  const { plans } = useReferenceData();
  if (rev.loading && !rev.data) return <div className="skeleton h-64 rounded-4xl" />;
  if (!rev.data) return <Alert tone="error">Impossibile caricare i ricavi.</Alert>;
  const r = rev.data;
  return (
    <section className="card p-5 sm:p-7">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-bold">Ricavi ricorrenti</h2>
        <span className="flex items-center gap-2"><BillingModeBadge />{r.environment && <Badge tone="outline">Stripe {r.environment}</Badge>}</span>
      </div>
      <p className="mt-1 text-sm text-ink-muted">Solo abbonamenti Stripe attivi o in tolleranza; annuali divisi per 12. Free, prove e piani concessi a mano non contano.</p>
      <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatTile accent label="MRR" value={formatCents(r.mrr_cents)} hint={`ARR stimato ${formatCents(r.arr_cents)}`} />
        <StatTile label="Nuovo MRR (mese)" value={formatCents(r.new_mrr_cents)} />
        <StatTile label="MRR perso (mese)" value={formatCents(r.churned_mrr_cents)} />
        <StatTile label="Clienti paganti" value={r.paying_customers} hint={`${r.paying_subscriptions} abbonamenti`} />
        <StatTile label="Prove attive" value={r.trials_active} hint={r.trial_conversion_rate === null ? 'Conversione: nessuna prova conclusa' : `Conversione prova → pagante ${String(r.trial_conversion_rate).replace('.', ',')}%`} />
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_280px]">
        <div>
          <p className="text-sm font-semibold">MRR ultimi 12 mesi</p>
          <MrrChart series={r.mrr_series} />
        </div>
        <div className="grid content-start gap-2 text-sm">
        <dl className="grid content-start gap-2">
          <div className="flex justify-between"><dt className="text-ink-muted">Ristoranti</dt><dd className="font-semibold tabular-nums">{r.restaurants_total}</dd></div>
          <div className="flex justify-between"><dt className="text-ink-muted">Rivendicati</dt><dd className="font-semibold tabular-nums">{r.restaurants_claimed}</dd></div>
          {plans.filter((p) => p.is_active).sort((a, b) => a.sort_order - b.sort_order).map((p) => (
            <div key={p.code} className="flex justify-between"><dt className="text-ink-muted">{p.name}</dt><dd className="font-semibold tabular-nums">{r.plans[p.code] ?? 0}</dd></div>
          ))}
          <div className="flex justify-between"><dt className="text-ink-muted">Cancellate (30 gg)</dt><dd className="font-semibold tabular-nums">{r.cancelled_30d}</dd></div>
          <div className="flex justify-between"><dt className="text-ink-muted">Cancellazioni programmate</dt><dd className="font-semibold tabular-nums">{r.cancel_scheduled}</dd></div>
          <div className="flex justify-between"><dt className="text-ink-muted">Pagamenti in ritardo</dt><dd className={cn('font-semibold tabular-nums', r.past_due > 0 && 'text-coral-700')}>{r.past_due}</dd></div>
          <div className="flex justify-between"><dt className="text-ink-muted">Piani manuali attivi</dt><dd className="font-semibold tabular-nums">{r.manual_active}</dd></div>
        </dl>
          <Link to="/admin/subscriptions" className="mt-2 font-semibold text-coral-700">Tutti gli abbonamenti →</Link>
        </div>
      </div>
    </section>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/subscriptions
// ═════════════════════════════════════════════════════════════
const VIEWS: [NonNullable<AdminSubscriptionFilter['view']>, string][] = [['all', 'Tutti'], ['active', 'Attivi'], ['trial', 'In prova'], ['past_due', 'Pagamento in ritardo'], ['expired', 'Scaduti / cancellati']];

export function AdminSubscriptions() {
  const { plans } = useReferenceData();
  const toast = useToast();
  const [params, setParams] = useSearchParams();
  const filter: AdminSubscriptionFilter = {
    view: (params.get('view') as AdminSubscriptionFilter['view']) ?? 'all',
    plan: (params.get('plan') as PlanCode) || undefined,
    source: params.get('source') || undefined,
    q: params.get('q') || undefined,
  };
  const list = useAsync(() => api.adminListSubscriptions(filter), [params.toString()]);
  const [grantFor, setGrantFor] = useState<AdminSubscriptionRow | null>(null);
  const [extendFor, setExtendFor] = useState<AdminSubscriptionRow | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  useSeo({ title: 'Admin · Abbonamenti', noindex: true });
  const set = (k: string, v: string | undefined) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v);
    else next.delete(k);
    setParams(next, { replace: true });
  };
  const act = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    try {
      await fn();
      toast(ok);
      list.reload();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setBusy(null);
    }
  };
  const rows = list.data ?? [];

  return (
    <div>
      <PageTitle
        title="Abbonamenti"
        subtitle="Stato sincronizzato da Stripe (webhook). Le azioni su Stripe passano dal backend; i piani manuali non creano finte subscription."
        action={<Button variant="outline" loading={busy === 'all'} icon={<RefreshCw className="h-4 w-4" />} onClick={() => act('all', () => api.adminBilling('sync_all'), 'Sincronizzazione completata')}>Sincronizza con Stripe</Button>}
      />
      <div className="mb-4 flex flex-wrap gap-2">
        {VIEWS.map(([v, l]) => <Chip key={v} active={filter.view === v} onClick={() => set('view', v === 'all' ? undefined : v)}>{l}</Chip>)}
      </div>
      <div className="mb-5 grid gap-3 sm:grid-cols-3">
        <Input aria-label="Cerca" placeholder="Ristorante, email, sub_…" defaultValue={filter.q} onKeyDown={(e) => e.key === 'Enter' && set('q', (e.target as HTMLInputElement).value.trim() || undefined)} />
        <Select aria-label="Piano" value={filter.plan ?? ''} onChange={(e) => set('plan', e.target.value || undefined)}>
          <option value="">Tutti i piani</option>
          {plans.map((p) => <option key={p.code} value={p.code}>{p.name}</option>)}
        </Select>
        <Select aria-label="Origine" value={filter.source ?? ''} onChange={(e) => set('source', e.target.value || undefined)}>
          <option value="">Tutte le origini</option>
          {Object.entries(SUBSCRIPTION_SOURCE).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      </div>

      {list.loading && !list.data ? (
        <PageLoader />
      ) : rows.length === 0 ? (
        <EmptyState icon="💳" title="Nessun abbonamento" text="Con questi filtri non ci sono abbonamenti." />
      ) : (
        <div className="overflow-x-auto rounded-4xl border border-line bg-white">
          <table className="w-full min-w-[1080px] text-left text-sm">
            <thead>
              <tr className="border-b border-line text-xs uppercase tracking-wider text-ink-muted">
                <th className="px-4 py-3">Ristorante</th>
                <th className="px-4 py-3">Titolare</th>
                <th className="px-4 py-3">Piano</th>
                <th className="px-4 py-3">Stato</th>
                <th className="px-4 py-3">Prova</th>
                <th className="px-4 py-3">Rinnovo / scadenza</th>
                <th className="px-4 py-3">Stripe</th>
                <th className="px-4 py-3">Ultima fattura</th>
                <th className="px-4 py-3"><span className="sr-only">Azioni</span></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((s) => {
                const trialLeft = s.status === 'trialing' ? daysUntil(s.trial_end) : null;
                return (
                  <tr key={s.id} className="border-t border-line align-top">
                    <td className="px-4 py-3">
                      {s.restaurant ? <Link to={`/admin/restaurants/${s.restaurant.id}/abbonamento`} className="font-semibold hover:text-coral-700">{s.restaurant.name}</Link> : '—'}
                      <span className="block text-xs text-ink-muted">effettivo: {planName(plans, s.restaurant?.subscription_plan)}</span>
                    </td>
                    <td className="px-4 py-3">{s.owner?.full_name ?? '—'}<span className="block text-xs text-ink-muted">{s.owner?.email}</span></td>
                    <td className="px-4 py-3"><strong>{planName(plans, s.plan_code)}</strong><span className="block text-xs text-ink-muted">{SUBSCRIPTION_SOURCE[s.source]}{s.source === 'stripe' ? ` · ${INTERVAL_LABEL[s.billing_interval]}` : ''}</span></td>
                    <td className="px-4 py-3">
                      <SubscriptionStatusBadge status={s.revoked_at ? 'canceled' : s.status} />
                      {s.cancel_at_period_end && <span className="mt-1 block text-xs text-ink-muted">cancella a fine periodo</span>}
                      {s.scheduled_plan_code && <span className="mt-1 block text-xs text-ink-muted">→ {planName(plans, s.scheduled_plan_code)} il {formatDay(s.scheduled_change_at)}</span>}
                    </td>
                    <td className="px-4 py-3">{trialLeft !== null ? `${trialLeft} gg (fino al ${formatDay(s.trial_end)})` : s.trial_end ? 'Conclusa' : '—'}</td>
                    <td className="px-4 py-3">{s.source === 'stripe' ? formatDay(s.current_period_end) : s.expires_at ? formatDay(s.expires_at) : 'Senza scadenza'}</td>
                    <td className="px-4 py-3 font-mono text-[11px]">
                      {s.stripe_customer_id ? <a className="block hover:underline" href={stripeDashboardUrl('customers', s.stripe_customer_id, s.stripe_environment)} target="_blank" rel="noreferrer">{s.stripe_customer_id}</a> : '—'}
                      {s.stripe_subscription_id && <a className="block hover:underline" href={stripeDashboardUrl('subscriptions', s.stripe_subscription_id, s.stripe_environment)} target="_blank" rel="noreferrer">{s.stripe_subscription_id} <ExternalLink className="inline h-3 w-3" /></a>}
                    </td>
                    <td className="px-4 py-3">{s.last_invoice ? <>{formatCents(s.last_invoice.status === 'paid' ? s.last_invoice.amount_paid_cents : s.last_invoice.amount_due_cents)} <Badge tone={s.last_invoice.status === 'paid' ? 'green' : 'coral'}>{s.last_invoice.status}</Badge><span className="block text-xs text-ink-muted">{formatDay(s.last_invoice.stripe_created_at)}</span></> : '—'}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="flex flex-col items-end gap-1.5">
                        {s.source === 'stripe' && <Button size="sm" variant="outline" loading={busy === `sync-${s.id}`} onClick={() => act(`sync-${s.id}`, () => api.adminBilling('sync', { subscription_id: s.id }), 'Sincronizzato con Stripe')}>Sincronizza</Button>}
                        {s.source === 'stripe' && s.status === 'trialing' && <Button size="sm" variant="ghost" onClick={() => setExtendFor(s)}>Estendi prova</Button>}
                        {s.source !== 'stripe' && !s.revoked_at && s.status === 'active' && (
                          <>
                            <Button size="sm" variant="ghost" onClick={() => setExtendFor(s)}>Estendi</Button>
                            <Button size="sm" variant="danger" loading={busy === `rev-${s.id}`} onClick={() => act(`rev-${s.id}`, () => api.adminRevokePlan(s.id), 'Piano revocato')}>Revoca piano manuale</Button>
                          </>
                        )}
                        {s.restaurant && <Button size="sm" variant="ghost" onClick={() => setGrantFor(s)}>Concedi piano manuale</Button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      <Sheet open={!!grantFor} onClose={() => setGrantFor(null)} title={`Concedi piano · ${grantFor?.restaurant?.name ?? ''}`}>
        {grantFor?.restaurant && <GrantPlanForm restaurantId={grantFor.restaurant.id} onDone={() => { setGrantFor(null); list.reload(); }} />}
      </Sheet>
      <ExtendSheet row={extendFor} onClose={() => setExtendFor(null)} onDone={list.reload} />
    </div>
  );
}

function ExtendSheet({ row, onClose, onDone }: { row: AdminSubscriptionRow | null; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [days, setDays] = useState(7);
  const [busy, setBusy] = useState(false);
  const stripe = row?.source === 'stripe';
  const save = async () => {
    if (!row) return;
    setBusy(true);
    try {
      if (stripe) await api.adminBilling('extend_trial', { subscription_id: row.id, days });
      else {
        const base = Math.max(row.expires_at ? Date.parse(row.expires_at) : 0, Date.now());
        await api.adminExtendManualPlan(row.id, new Date(base + days * 86_400_000).toISOString());
      }
      toast(stripe ? `Prova estesa di ${days} giorni (su Stripe)` : `Scadenza estesa di ${days} giorni`);
      onDone();
      onClose();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet open={!!row} onClose={onClose} title={stripe ? 'Estendi prova' : 'Estendi piano manuale'} footer={<div className="flex justify-end gap-3"><Button variant="outline" onClick={onClose}>Annulla</Button><Button loading={busy} onClick={save}>Estendi</Button></div>}>
      <Field label="Giorni" hint={stripe ? 'Massimo 60: la nuova fine prova viene impostata su Stripe' : undefined}>
        <Input type="number" min={1} max={stripe ? 60 : 365} value={days} onChange={(e) => setDays(Math.max(1, Math.min(stripe ? 60 : 365, Number(e.target.value) || 1)))} />
      </Field>
    </Sheet>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/sponsorships
// ═════════════════════════════════════════════════════════════
export function AdminSponsorships() {
  const toast = useToast();
  const [days, setDays] = useState<7 | 30 | 90>(30);
  const stats = useAsync(() => api.getCampaignStats(null, days), [days]);
  const campaigns = useAsync(() => api.list<SponsoredCampaign>('sponsored_campaigns', { orderBy: 'start_date', ascending: false }), []);
  const [editing, setEditing] = useState<Partial<SponsoredCampaign> | null>(null);
  useSeo({ title: 'Admin · Sponsorizzazioni', noindex: true });
  const reload = () => {
    stats.reload();
    campaigns.reload();
  };
  const setStatus = async (id: string, status: CampaignStatus) => {
    const c = campaigns.data?.find((x) => x.id === id);
    if (!c) return;
    try {
      await api.upsert('sponsored_campaigns', { id, restaurant_id: c.restaurant_id, status });
      toast(`Campagna: ${CAMPAIGN_STATUS[status].label.toLowerCase()}`);
      reload();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    }
  };
  const rows = stats.data ?? [];
  const live = rows.filter((c) => c.display_status === 'active').length;
  return (
    <div>
      <PageTitle
        title="Sponsorizzazioni"
        subtitle="AsiaFood Ads, gestione manuale: slot separati dai risultati organici e sempre etichettati. Fatturazione Ads manuale (nessun addebito automatico)."
        action={<Button onClick={() => setEditing({ status: 'draft', placement: 'home_featured', priority: 10 })}>Nuova campagna</Button>}
      />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {([7, 30, 90] as const).map((d) => <Chip key={d} active={days === d} onClick={() => setDays(d)}>{d} giorni</Chip>)}
        <span className="text-sm text-ink-muted">· {live} attive ora</span>
      </div>
      {stats.loading && !stats.data ? (
        <PageLoader />
      ) : rows.length === 0 ? (
        <EmptyState icon="📣" title="Nessuna campagna" text="Crea una campagna per mostrare un locale negli slot sponsorizzati." />
      ) : (
        <div className="card p-4 sm:p-5">
          <CampaignStatsTable
            rows={rows}
            showRestaurant
            actions={(c) => (
              <div className="flex justify-end gap-1">
                <Button size="sm" variant="ghost" onClick={() => setEditing(campaigns.data?.find((x) => x.id === c.campaign_id) ?? null)}>Modifica</Button>
                {c.status === 'active' || c.status === 'scheduled' ? (
                  <Button size="sm" variant="ghost" onClick={() => setStatus(c.campaign_id, 'paused')}>Pausa</Button>
                ) : c.status !== 'ended' ? (
                  <Button size="sm" variant="ghost" onClick={() => setStatus(c.campaign_id, 'active')}>Attiva</Button>
                ) : null}
                {c.status !== 'ended' && <Button size="sm" variant="ghost" onClick={() => setStatus(c.campaign_id, 'ended')}>Termina</Button>}
              </div>
            )}
          />
        </div>
      )}
      {editing && <CampaignSheet campaign={editing} onClose={() => setEditing(null)} onSaved={reload} />}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
//  /admin/system/stripe — configurazione, impostazioni, log webhook
// ═════════════════════════════════════════════════════════════
const SETTING_KEYS: (keyof BillingSettings)[] = [
  'billing_trial_days', 'billing_require_payment_method_for_trial', 'billing_payment_grace_period_days', 'billing_trial_expiring_days',
  'billing_proration_behavior', 'billing_downgrade_timing', 'billing_stripe_environment',
];

export function AdminStripeSystem() {
  const toast = useToast();
  const status = useAsync(() => (BILLING.enabled ? api.adminBilling<Record<string, unknown>>('status').catch((e: Error) => ({ error: e.message })) : Promise.resolve({ error: 'Pagamenti online non attivi nel frontend (VITE_STRIPE_PUBLISHABLE_KEY mancante).' })), []);
  const events = useAsync(() => api.listStripeEvents(100), []);
  const settings = useAsync(async () => Object.fromEntries(await Promise.all(SETTING_KEYS.map(async (k) => [k, await api.getSetting(k)]))) as unknown as BillingSettings, []);
  const [s, setS] = useState<BillingSettings | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  useSeo({ title: 'Admin · Stripe', noindex: true });
  useEffect(() => {
    if (settings.data && !s) setS(settings.data);
  }, [settings.data, s]);

  const save = async () => {
    if (!s) return;
    if (!(s.billing_trial_days >= 0 && s.billing_trial_days <= 90)) return toast('Giorni di prova: da 0 a 90', 'error');
    if (!(s.billing_payment_grace_period_days >= 0 && s.billing_payment_grace_period_days <= 30)) return toast('Tolleranza: da 0 a 30 giorni', 'error');
    setBusy('save');
    try {
      for (const k of SETTING_KEYS.filter((k) => k !== 'billing_stripe_environment')) await api.setSetting(k, s[k]);
      toast('Impostazioni salvate');
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setBusy(null);
    }
  };
  const run = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    try {
      await fn();
      toast(ok);
      events.reload();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setBusy(null);
    }
  };
  const st = status.data as Record<string, unknown> | undefined;
  const failed = (events.data ?? []).filter((e) => e.processing_status === 'failed').length;

  return (
    <div className="space-y-6">
      <PageTitle title="Stripe" subtitle="Stato della configurazione, impostazioni di fatturazione e ultimi webhook ricevuti." action={<BillingModeBadge />} />

      <section className="card p-5 sm:p-7">
        <h2 className="text-lg font-bold">Configurazione</h2>
        {status.loading ? (
          <p className="mt-3 text-sm text-ink-muted">Verifica…</p>
        ) : st?.error ? (
          <Alert tone="error">{String(st.error)}</Alert>
        ) : (
          <ul className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
            {[
              ['Ambiente', st?.simulated ? 'Simulato (DEMO)' : String(st?.environment ?? '—'), true],
              ['Webhook secret', st?.webhook_secret_configured ? 'Configurato' : 'Mancante', !!st?.webhook_secret_configured || !!st?.simulated],
              ['Stripe Tax', st?.tax_enabled ? 'Attivo (automatic_tax)' : 'Disattivo', true],
              ['Customer Portal', st?.portal_configuration === 'custom' ? 'Configurazione dedicata' : 'Configurazione predefinita', true],
              ['URL applicazione', String(st?.app_url ?? '—'), true],
            ].map(([k, v, ok]) => (
              <li key={String(k)} className="flex items-center gap-2">
                {ok ? <CheckCircle2 className="h-4 w-4 text-leaf" /> : <AlertTriangle className="h-4 w-4 text-coral" />}
                <span className="text-ink-muted">{String(k)}:</span> <strong>{String(v)}</strong>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-5 flex flex-wrap gap-2 border-t border-line pt-5">
          <Button variant="outline" loading={busy === 'sync'} icon={<RefreshCw className="h-4 w-4" />} onClick={() => run('sync', () => api.adminBilling('sync_all'), 'Abbonamenti sincronizzati con Stripe')}>Sincronizza con Stripe</Button>
          <Button variant="outline" loading={busy === 'refresh'} onClick={() => run('refresh', () => api.adminBilling('refresh_plans'), 'Piani ricalcolati')}>Ricalcola piani effettivi</Button>
          <Link to="/admin/plans" className="inline-flex h-11 items-center gap-2 rounded-full border border-line px-5 text-[15px] font-semibold hover:border-ink"><Wand2 className="h-4 w-4" /> Prezzi e Price ID</Link>
        </div>
      </section>

      <section className="card p-5 sm:p-7">
        <h2 className="text-lg font-bold">Impostazioni di fatturazione</h2>
        {!s ? (
          <p className="mt-3 text-sm text-ink-muted">Caricamento…</p>
        ) : (
          <>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field label="Durata prova gratuita (giorni)" hint="0 = nessuna prova. Default 30."><Input type="number" min={0} max={90} value={s.billing_trial_days ?? 30} onChange={(e) => setS({ ...s, billing_trial_days: Number(e.target.value) })} /></Field>
              <Field label="Tolleranza pagamento fallito (giorni)" hint="Poi il locale torna alle funzioni Free."><Input type="number" min={0} max={30} value={s.billing_payment_grace_period_days ?? 3} onChange={(e) => setS({ ...s, billing_payment_grace_period_days: Number(e.target.value) })} /></Field>
              <Field label="Avviso fine prova (giorni prima)"><Input type="number" min={1} max={14} value={s.billing_trial_expiring_days ?? 3} onChange={(e) => setS({ ...s, billing_trial_expiring_days: Number(e.target.value) })} /></Field>
              <Field label="Upgrade: addebito della differenza">
                <Select value={s.billing_proration_behavior ?? 'always_invoice'} onChange={(e) => setS({ ...s, billing_proration_behavior: e.target.value as BillingSettings['billing_proration_behavior'] })}>
                  <option value="always_invoice">Subito (fattura immediata)</option>
                  <option value="create_prorations">Nella fattura successiva</option>
                  <option value="none">Nessuna differenza</option>
                </Select>
              </Field>
              <Field label="Downgrade">
                <Select value={s.billing_downgrade_timing ?? 'period_end'} onChange={(e) => setS({ ...s, billing_downgrade_timing: e.target.value as BillingSettings['billing_downgrade_timing'] })}>
                  <option value="period_end">A fine ciclo (consigliato)</option>
                  <option value="immediate">Immediato</option>
                </Select>
              </Field>
              <div className="sm:pt-6">
                <Toggle label="Carta obbligatoria per la prova" description="require_payment_method_for_trial" checked={!!s.billing_require_payment_method_for_trial} onChange={(v) => setS({ ...s, billing_require_payment_method_for_trial: v })} />
              </div>
            </div>
            <div className="mt-5 flex justify-end border-t border-line pt-5"><Button loading={busy === 'save'} onClick={save}>Salva impostazioni</Button></div>
          </>
        )}
      </section>

      <section className="card p-5 sm:p-7">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-bold">Ultimi webhook</h2>
          {failed > 0 && <Badge tone="coral">{failed} con errore</Badge>}
        </div>
        <p className="mt-1 text-sm text-ink-muted">Solo metadati dell’evento: il payload Stripe non viene salvato né mostrato.</p>
        {(events.data ?? []).length === 0 ? (
          <p className="mt-4 text-sm text-ink-muted">Nessun evento ricevuto. Verifica l’endpoint in Stripe → Developers → Webhooks.</p>
        ) : (
          <div className="-mx-2 mt-4 overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead><tr className="text-xs uppercase tracking-wider text-ink-muted"><th className="px-2 py-2">Evento</th><th className="px-2 py-2">Data</th><th className="px-2 py-2">Stato</th><th className="px-2 py-2">Tentativi</th><th className="px-2 py-2">Errore</th></tr></thead>
              <tbody>
                {events.data!.map((e) => (
                  <tr key={e.id} className="border-t border-line">
                    <td className="px-2 py-2"><span className="font-mono text-xs">{e.event_type}</span><span className="block font-mono text-[11px] text-ink-faint">{e.stripe_event_id}</span></td>
                    <td className="whitespace-nowrap px-2 py-2">{new Date(e.created_at).toLocaleString('it-IT', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit' })}</td>
                    <td className="px-2 py-2"><Badge tone={e.processing_status === 'processed' ? 'green' : e.processing_status === 'failed' ? 'coral' : e.processing_status === 'ignored' ? 'neutral' : 'amber'}>{{ processed: 'Elaborato', failed: 'Errore', ignored: 'Ignorato', processing: 'In corso' }[e.processing_status]}</Badge></td>
                    <td className="px-2 py-2 tabular-nums">{e.attempts}</td>
                    <td className="max-w-[320px] truncate px-2 py-2 text-xs text-ink-muted" title={e.error_message ?? ''}>{e.error_message ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
