import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link, Navigate, useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeft,
  BadgeCheck,
  CalendarCheck,
  Check,
  Clock,
  ExternalLink,
  Facebook,
  Flag,
  Globe,
  Infinity as InfinityIcon,
  Instagram,
  Mail,
  Map as MapIcon,
  MapPin,
  MessageCircle,
  Navigation,
  Phone,
  Share2,
  Sparkles,
  ShieldQuestion,
  Store,
  UtensilsCrossed,
  Award,
} from 'lucide-react';
import { APP } from '@/config/app';
import { useAsync } from '@/hooks/useAsync';
import { breadcrumbJsonLd, restaurantJsonLd, useSeo } from '@/lib/seo';
import { cn, formatDate, formatPrice, priceRangeLabel, PRICE_RANGE_TEXT, SERVICE_LABELS, socialUrl, telUrl, whatsappUrl } from '@/lib/format';
import { SOURCE_TYPE } from '@/lib/labels';
import { directionsUrl } from '@/lib/geo';
import { api } from '@/services';
import type { AnalyticsEventType, RestaurantDetail } from '@/types/domain';
import { Badge, DemoBadge, FeaturedBadge, PremiumBadge, SponsoredBadge, VerifiedBadge } from '@/components/ui/Badge';
import { Monogram, SmartImage } from '@/components/ui/SmartImage';
import { IconButton } from '@/components/ui/Button';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { FavoriteButton, OpenStatus } from '@/components/restaurant/Status';
import { CouponCard, OfferInline } from '@/components/restaurant/Offers';
import { Gallery, HoursTable } from '@/components/restaurant/DetailParts';
import { PublicMenu } from '@/components/restaurant/PublicMenu';
import { CartBar, OrderPanel } from '@/components/orders/OrderParts';
import { ProductSheet } from '@/components/orders/ProductSheet';
import type { MenuItemFull } from '@/types/domain';
import type { OrderPublicInfo } from '@/types/orders';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { hasFeature } from '@/lib/entitlements';
import { RestaurantRail } from '@/components/restaurant/RestaurantRail';
import { isOwnerVerified } from '@/components/restaurant/RestaurantCard';
import { ReportSheet } from '@/components/restaurant/ReportSheet';
import { Sheet } from '@/components/ui/Sheet';
import { AI } from '@/config/app';
import { RatingSummaryInline, ReviewsSection } from '@/components/reviews/ReviewsSection';
import { FollowButton } from '@/components/engagement/FollowButton';
import type { RestaurantRating } from '@/types/engagement';
import NotFoundPage from './NotFoundPage';
import { friendlyError } from '@/lib/errors';
import type { FoundingBadge } from '@/types/launch';
// Mappa e assistente sotto la piega: caricati solo quando servono (bundle della scheda più leggero)
const MapView = lazy(() => import('@/lib/maps/MapView').then((m) => ({ default: m.MapView })));
const AssistantChat = lazy(() => import('@/components/ai/AssistantChat').then((m) => ({ default: m.AssistantChat })));

export default function RestaurantPage() {
  const { slug = '' } = useParams();
  // Locale non trovato: si controlla lo storico degli slug (URL cambiato → redirect permanente al nuovo)
  const { data, loading, error } = useAsync(async () => {
    const r = await api.getRestaurantBySlug(slug);
    return { r, redirect: r ? null : await api.getSlugRedirect(slug).catch(() => null) };
  }, [slug]);
  if (loading) return <PageLoader />;
  if (error) return <div className="container-app py-16"><EmptyState icon="⚠️" title="Impossibile caricare il locale" text={friendlyError(error)} /></div>;
  if (data?.redirect) return <Navigate to={`/ristorante/${data.redirect}`} replace />;
  if (!data?.r) return <NotFoundPage what="ristorante" />;
  return <RestaurantView r={data.r} />;
}

function RestaurantView({ r }: { r: RestaurantDetail }) {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();
  const source = (location.state as { source?: string } | null)?.source ?? 'direct';
  const track = useCallback(
    (t: AnalyticsEventType) => {
      api.track(r.id, t, source);
      if (t === 'directions_click') api.trackAppEvent('directions_click', { restaurantId: r.id, source: 'restaurant' });
    },
    [r.id, source],
  );
  const { plans } = useReferenceData();
  const waEnabled = hasFeature(plans, r.subscription_plan, 'whatsapp_enabled');
  const premiumBadge = hasFeature(plans, r.subscription_plan, 'premium_badge');
  const closedNow = r.is_permanently_closed || r.is_temporarily_closed;
  // "Prenota un tavolo" solo se il locale accetta prenotazioni E il piano le include
  const bookable = r.has_reservation && !closedNow && !!r.reservation_settings?.reservation_enabled && hasFeature(plans, r.subscription_plan, 'reservations_enabled');
  // Chi arriva dall'assistente mantiene l'attribuzione anche nella prenotazione
  const bookPath = `/ristorante/${r.slug}/prenota${source === 'ai' ? '?src=ai' : ''}`;
  const [askOpen, setAskOpen] = useState(false);
  const [rating, setRating] = useState<RestaurantRating | null>(null);
  // Fase 12: badge "Partner Fondatore" solo per i ristoranti realmente aderenti (deciso dal server)
  const [founding, setFounding] = useState<FoundingBadge | null>(null);
  useEffect(() => {
    let alive = true;
    void api.launch.foundingBadge(r.id).then((b) => alive && setFounding(b), () => undefined);
    return () => {
      alive = false;
    };
  }, [r.id]);
  // Fase 8: ordini online (takeaway/delivery)
  const orderInfo = useAsync<OrderPublicInfo>(() => (r.is_permanently_closed ? Promise.resolve({ enabled: false }) : api.getOrderInfo(r.id).catch(() => ({ enabled: false }))), [r.id]);
  // Link diretti "#ordina" (es. dall'assistente): scorre alla sezione ordini quando è pronta
  useEffect(() => {
    if (location.hash === '#ordina' && orderInfo.data?.enabled) {
      const t = window.setTimeout(() => document.getElementById('ordina')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150);
      return () => window.clearTimeout(t);
    }
    return undefined;
  }, [location.hash, orderInfo.data?.enabled]);
  const canOrder = !!orderInfo.data?.enabled && !!orderInfo.data.payments_ready;
  const optionGroups = useAsync(() => (canOrder ? api.getMenuOptionGroups(r.id) : Promise.resolve([])), [r.id, canOrder]);
  const [product, setProduct] = useState<MenuItemFull | null>(null);

  useEffect(() => {
    api.track(r.id, 'restaurant_view', source);
  }, [r.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // offer_view: una volta, quando la sezione Offerte diventa visibile
  const offersRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = offersRef.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => {
      if (e?.isIntersecting) {
        api.track(r.id, 'offer_view', source);
        io.disconnect();
      }
    }, { threshold: 0.3 });
    io.observe(el);
    return () => io.disconnect();
  }, [r.id, source]);

  const cityName = r.city?.name ?? '';
  const mainCat = r.categories.find((c) => c.slug !== 'all-you-can-eat') ?? r.categories[0];
  const cuisines = r.categories.filter((c) => c.slug !== 'all-you-can-eat').map((c) => c.name.toLowerCase());
  useSeo({
    title: r.meta_title ?? `${r.name} — ${mainCat?.name ?? 'Ristorante asiatico'} a ${cityName}`,
    description:
      r.meta_description ??
      [
        `${r.name}${cuisines.length ? `, cucina ${cuisines.slice(0, 2).join(' e ')}` : ''} a ${cityName}${r.address ? ` (${r.address})` : ''}.`,
        r.short_description,
        [r.is_all_you_can_eat && 'All You Can Eat', r.has_takeaway && 'asporto', r.has_delivery && 'delivery'].filter(Boolean).join(', ') || null,
        'Orari, contatti e indicazioni.',
      ].filter(Boolean).join(' '),
    path: `/ristorante/${r.slug}`,
    image: r.cover_url,
    type: 'restaurant',
    jsonLd: [
      restaurantJsonLd(r, rating),
      breadcrumbJsonLd([
        { name: 'Home', path: '/' },
        ...(r.city ? [{ name: `Ristoranti ${r.city.name}`, path: `/ristoranti/${r.city.slug}` }] : []),
        { name: r.name, path: `/ristorante/${r.slug}` },
      ]),
    ],
  });

  const similar = useAsync(
    () => api.searchRestaurants({ categorySlug: mainCat?.slug, sort: 'popular', limit: 9 }).then((xs) => xs.filter((x) => x.id !== r.id).slice(0, 8)),
    [r.id],
  );

  const share = async () => {
    const data = { title: r.name, text: r.short_description ?? r.name, url: window.location.href };
    try {
      if (navigator.share) await navigator.share(data);
      else {
        await navigator.clipboard.writeText(data.url);
        toast('Link copiato');
      }
    } catch {
      /* condivisione annullata */
    }
  };

  const [reporting, setReporting] = useState(false);
  const closedForever = r.is_permanently_closed;
  type Action = { key: string; label: string; icon: typeof Phone; href: string; event: AnalyticsEventType; internal?: boolean };
  const actions = useMemo(() => {
    if (closedForever) return [] as Action[];
    const list: (Action | false | null | '')[] = [
      bookable
        ? { key: 'book', label: 'Prenota', icon: CalendarCheck, href: bookPath, event: 'reservation_start', internal: true }
        : r.has_reservation && !r.is_temporarily_closed && !!r.reservation_url && { key: 'book', label: 'Prenota', icon: CalendarCheck, href: r.reservation_url, event: 'reservation_start' },
      r.phone && { key: 'call', label: 'Chiama', icon: Phone, href: telUrl(r.phone), event: 'phone_click' },
      r.whatsapp && waEnabled && { key: 'wa', label: 'WhatsApp', icon: MessageCircle, href: whatsappUrl(r.whatsapp, `Ciao ${r.name}, vi ho trovato su ${APP.name}.`), event: 'whatsapp_click' },
      { key: 'dir', label: 'Indicazioni', icon: Navigation, href: directionsUrl(r), event: 'directions_click' },
    ];
    return list.filter((x): x is Action => !!x);
  }, [r, bookable, bookPath, waEnabled, closedForever]);
  // Barra mobile: Prenota, Chiama, WhatsApp (solo quelli disponibili); Indicazioni se ne restano meno di due
  const mobileActions = (() => {
    const main = actions.filter((a) => a.key !== 'dir');
    return main.length >= 2 ? main : actions.slice(0, 3);
  })();

  const menuItemsCount = r.menus.reduce((a, m) => a + m.sections.reduce((b, s) => b + s.items.length, 0), 0);
  const sections = [
    { id: 'panoramica', label: 'Panoramica', show: true },
    { id: 'ordina', label: 'Ordina', show: !!orderInfo.data?.enabled },
    { id: 'menu', label: 'Menu', show: r.menus.length > 0 },
    { id: 'offerte', label: 'Offerte', show: r.offers.length + r.coupons.length > 0 },
    { id: 'prenota', label: 'Prenota', show: bookable },
    { id: 'recensioni', label: 'Recensioni', show: true },
    { id: 'foto', label: 'Foto', show: r.images.length > 0 },
    { id: 'informazioni', label: 'Informazioni', show: true },
  ].filter((s) => s.show);
  const [activeTab, setActiveTab] = useState('panoramica');
  useEffect(() => {
    const els = sections.map((x) => document.getElementById(x.id)).filter((x): x is HTMLElement => !!x && x.offsetParent !== null);
    const io = new IntersectionObserver(
      (entries) => {
        const top = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (top) setActiveTab(top.target.id);
      },
      { rootMargin: '-130px 0px -60% 0px' },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sections.map((x) => x.id).join()]);

  return (
    <article className="pb-32 md:pb-10">
      {/* ─── COVER ─── */}
      <div className="relative">
        <SmartImage src={r.cover_url} alt={r.name} seed={r.id} emoji={mainCat?.emoji} eager className="h-[300px] w-full sm:h-[380px] lg:h-[440px]" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/5 to-black/25" />
        <div className="container-app absolute inset-x-0 top-4 flex justify-between">
          <IconButton label="Indietro" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate('/restaurants'))}>
            <ArrowLeft className="h-5 w-5" />
          </IconButton>
          <div className="flex gap-2">
            <IconButton label="Condividi" onClick={share}>
              <Share2 className="h-[18px] w-[18px]" />
            </IconButton>
            <FavoriteButton restaurantId={r.id} />
          </div>
        </div>
      </div>

      <div className="container-app relative -mt-20">
        <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
          {/* ─── COLONNA PRINCIPALE ─── */}
          <div className="min-w-0">
            <header className="card animate-fade-up p-5 sm:p-7">
              <div className="flex items-start gap-4">
                <Monogram name={r.name} src={r.logo_url} className="-mt-12 h-20 w-20 shrink-0 border-4 border-white text-2xl shadow-card sm:h-24 sm:w-24" />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap gap-1.5">
                    {isOwnerVerified(r) && <VerifiedBadge label="Profilo verificato" />}
                    {founding && <span data-testid="founding-badge"><Badge tone="dark" icon={<Award className="h-3.5 w-3.5" aria-hidden />}>{founding.label}</Badge></span>}
                    {premiumBadge && <PremiumBadge />}
                    {r.sponsored_now && <SponsoredBadge />}
                    {r.is_featured && !r.sponsored_now && <FeaturedBadge />}
                    {r.is_demo && <DemoBadge />}
                  </div>
                </div>
              </div>
              <h1 className="mt-4 text-3xl font-extrabold leading-tight sm:text-4xl">{r.name}</h1>
              <p className="mt-2 flex flex-wrap items-center gap-x-2 text-[15px] text-ink-muted">
                {r.categories.map((c, i) => (
                  <span key={c.id}>
                    {i > 0 && <span className="mr-2 text-ink-faint">·</span>}
                    <Link to={r.city ? `/${c.slug}/${r.city.slug}` : `/${c.slug}`} className="hover:text-ink">
                      {c.emoji} {c.name}
                    </Link>
                  </span>
                ))}
              </p>
              {(r.is_permanently_closed || r.is_temporarily_closed) && (
                <div className={cn('mt-4 flex items-start gap-2 rounded-2xl px-4 py-3 text-sm font-medium', r.is_permanently_closed ? 'bg-ink text-white' : 'bg-amber-50 text-amber-900')}>
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                  {r.is_permanently_closed ? 'Questa attività risulta chiusa definitivamente.' : 'Questa attività è temporaneamente chiusa. Contatta il locale prima di andare.'}
                </div>
              )}
              <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
                {!r.is_permanently_closed && !r.is_temporarily_closed && <OpenStatus hours={r.hours} tz={r.timezone} className="!text-sm" />}
                <RatingSummaryInline rating={rating} />
                {r.price_range && (
                  <span className="font-semibold">
                    {priceRangeLabel(r.price_range)} <span className="font-normal text-ink-muted">· {PRICE_RANGE_TEXT[r.price_range]}</span>
                  </span>
                )}
                {r.average_price && <span className="text-ink-muted">Prezzo medio ~{formatPrice(r.average_price, true)}</span>}
                {r.city && (
                  <span className="inline-flex items-center gap-1 text-ink-muted">
                    <MapPin className="h-4 w-4" /> {r.city.name}
                  </span>
                )}
              </div>

              <TrustLine r={r} />

              {/* CTA desktop */}
              <div className="mt-6 hidden flex-wrap gap-2 md:flex">
                {actions.map((a, i) => (
                  <ActionLink
                    key={a.key}
                    a={a}
                    onClick={() => !a.internal && track(a.event)}
                    className={cn(
                      'inline-flex h-11 items-center gap-2 rounded-full px-5 text-[15px] font-semibold transition active:scale-95',
                      i === 0 ? 'bg-coral text-white hover:bg-coral-600' : 'border border-line bg-white hover:border-ink',
                    )}
                  >
                    <a.icon className="h-4 w-4" /> {a.key === 'book' && a.internal ? 'Prenota un tavolo' : a.label}
                  </ActionLink>
                ))}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
              {!closedForever && <FollowButton restaurantId={r.id} restaurantSlug={r.slug} />}
              {AI.enabled && !closedForever && (
                <button
                  type="button"
                  onClick={() => setAskOpen(true)}
                  className="inline-flex h-10 items-center gap-2 rounded-full border border-line bg-white px-4 text-sm font-semibold transition hover:border-ink"
                >
                  <Sparkles className="h-4 w-4 text-coral" /> Chiedi informazioni su questo ristorante
                </button>
              )}
              </div>
            </header>
            <Sheet open={askOpen} onClose={() => setAskOpen(false)} title={`Chiedi di ${r.name}`} wide>
              <div className="-mx-6 -mb-6 flex h-[68dvh] flex-col sm:h-[60vh]">
                <Suspense fallback={<PageLoader />}><AssistantChat restaurantId={r.id} restaurantName={r.name} /></Suspense>
              </div>
            </Sheet>

            {/* Tab ancorate */}
            <nav className="scrollbar-none sticky top-16 z-20 -mx-4 mt-6 flex gap-1 overflow-x-auto bg-paper px-4 py-2 sm:mx-0 sm:px-0" aria-label="Sezioni">
              {sections.map((s) => (
                <a
                  key={s.id}
                  href={`#${s.id}`}
                  aria-current={activeTab === s.id ? 'true' : undefined}
                  className={cn(
                    'shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition',
                    activeTab === s.id ? 'bg-ink text-white' : 'text-ink-soft hover:bg-cream hover:text-ink',
                    s.id === 'informazioni' && 'lg:hidden',
                  )}
                >
                  {s.label}
                </a>
              ))}
            </nav>

            {/* Panoramica */}
            <section id="panoramica" className="scroll-mt-32 pt-6">
              {r.is_all_you_can_eat && (
                <div className="mb-6 overflow-hidden rounded-4xl bg-ink p-6 text-white">
                  <p className="flex items-center gap-2 text-sm font-semibold text-coral-400">
                    <InfinityIcon className="h-5 w-5" /> Formula All You Can Eat
                  </p>
                  <div className="mt-4 grid grid-cols-3 gap-3">
                    {[
                      ['Pranzo', r.ayce_lunch_price],
                      ['Cena', r.ayce_dinner_price],
                      ['Weekend', r.ayce_weekend_price],
                    ]
                      .filter(([, v]) => v != null)
                      .map(([label, v]) => (
                        <div key={label as string} className="rounded-2xl bg-white/10 p-3 sm:p-4">
                          <p className="text-xs text-white/60">{label}</p>
                          <p className="font-display text-xl font-bold sm:text-2xl">{formatPrice(v as number)}</p>
                        </div>
                      ))}
                  </div>
                  <p className="mt-3 text-xs text-white/50">Bevande, coperto e dolci potrebbero essere esclusi. Verifica le condizioni con il locale.</p>
                </div>
              )}

              {r.description && (
                <>
                  <h2 className="mb-2 text-xl font-bold">Il locale</h2>
                  <p className="whitespace-pre-line text-pretty text-[16px] leading-relaxed text-ink-soft">{r.description}</p>
                </>
              )}

              <div className="mt-6 grid gap-3 sm:grid-cols-3">
                {[
                  { on: r.has_takeaway, label: 'Asporto', icon: Store },
                  { on: r.has_delivery, label: 'Delivery', icon: UtensilsCrossed },
                  { on: r.has_reservation, label: 'Prenotazione', icon: CalendarCheck },
                ].map((s) => (
                  <div key={s.label} className={cn('flex items-center gap-3 rounded-2xl border p-3.5 text-sm font-medium', s.on ? 'border-line bg-white' : 'border-dashed border-line text-ink-faint')}>
                    <s.icon className={cn('h-5 w-5', s.on ? 'text-coral' : '')} />
                    {s.label}
                    <span className="ml-auto text-xs">{s.on ? 'Sì' : 'No'}</span>
                  </div>
                ))}
              </div>

              {r.services.length > 0 && (
                <div className="mt-6">
                  <h3 className="mb-3 text-base font-bold">Servizi</h3>
                  <ul className="flex flex-wrap gap-2">
                    {r.services.map((s) => (
                      <li key={s} className="inline-flex items-center gap-1.5 rounded-full bg-cream px-3 py-1.5 text-sm">
                        <Check className="h-3.5 w-3.5 text-leaf" /> {SERVICE_LABELS[s] ?? s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </section>

            {orderInfo.data?.enabled && (
              <section id="ordina" className="scroll-mt-32 pt-10">
                <OrderPanel info={orderInfo.data} onBrowse={() => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' })} />
              </section>
            )}

            {r.menus.length > 0 && (
              <section id="menu" className="scroll-mt-32 pt-10">
                <h2 className="mb-4 text-2xl font-bold">
                  Menu <span className="text-base font-medium text-ink-muted">· {menuItemsCount} piatti</span>
                </h2>
                <PublicMenu menus={r.menus} onView={() => track('menu_view')} ordering={canOrder ? { onSelect: setProduct } : null} />
                <ProductSheet item={product} groups={optionGroups.data ?? []} restaurant={{ id: r.id, name: r.name, slug: r.slug }} onClose={() => setProduct(null)} />
              </section>
            )}

            {r.offers.length + r.coupons.length > 0 && (
              <section id="offerte" ref={offersRef} className="scroll-mt-32 pt-10">
                <h2 className="mb-4 text-2xl font-bold">Offerte disponibili</h2>
                <div className="grid gap-3">
                  {r.offers.map((o) => (
                    <OfferInline key={o.id} o={o} />
                  ))}
                  {r.coupons.map((c) => (
                    <CouponCard key={c.id} c={c} restaurantName={r.name} source={source === 'ai' ? 'ai' : 'web'} />
                  ))}
                </div>
              </section>
            )}

            {bookable && (
              <section id="prenota" className="scroll-mt-32 pt-10">
                <div className="flex flex-col gap-4 rounded-4xl bg-ink p-6 text-white sm:flex-row sm:items-center">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/10">
                    <CalendarCheck className="h-6 w-6 text-coral-400" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <h2 className="text-xl font-bold">Prenota un tavolo</h2>
                    <p className="mt-0.5 text-sm text-white/70">
                      Scegli giorno, persone e orario tra quelli disponibili. {r.reservation_settings?.auto_confirm ? 'Conferma immediata.' : 'Il locale conferma la richiesta.'} Non serve registrarsi.
                    </p>
                  </div>
                  <Link
                    to={bookPath}
                    className="inline-flex h-12 shrink-0 items-center justify-center rounded-full bg-coral px-6 text-[15px] font-semibold text-white hover:bg-coral-600"
                  >
                    Prenota un tavolo
                  </Link>
                </div>
              </section>
            )}

            <ReviewsSection restaurantId={r.id} restaurantName={r.name} restaurantSlug={r.slug} onRating={setRating} />

            {r.images.length > 0 && (
              <section id="foto" className="scroll-mt-32 pt-10">
                <h2 className="mb-4 text-2xl font-bold">Foto</h2>
                <Gallery images={r.images} name={r.name} />
              </section>
            )}

            <section id="informazioni" className="scroll-mt-32 pt-10 lg:hidden">
              <h2 className="mb-4 text-2xl font-bold">Informazioni</h2>
              <InfoBlock r={r} track={track} whatsapp={waEnabled} />
            </section>

            <SourcesBlock r={r} onReport={() => setReporting(true)} />

            {!r.owner_id && !r.is_permanently_closed && (
              <section className="mt-6 flex flex-col items-start gap-4 rounded-4xl border border-dashed border-ink/20 bg-white p-6 sm:flex-row sm:items-center">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-coral-50">
                  <Store className="h-6 w-6 text-coral" />
                </div>
                <div className="flex-1">
                  <p className="font-bold">Sei il proprietario di questa attività?</p>
                  <p className="text-sm text-ink-muted">Rivendica la scheda gratuitamente: dopo la verifica potrai aggiornare menu, orari, foto e offerte.</p>
                </div>
                <Link to={`/ristorante/${r.slug}/rivendica`} className="inline-flex h-11 shrink-0 items-center rounded-full bg-ink px-5 text-sm font-semibold text-white hover:bg-ink-soft">
                  Rivendica questa attività
                </Link>
              </section>
            )}
          </div>

          {/* ─── SIDEBAR DESKTOP ─── */}
          <aside className="hidden lg:block">
            <div className="sticky top-24 space-y-4">
              <div className="card p-6">
                <InfoBlock r={r} track={track} whatsapp={waEnabled} />
              </div>
            </div>
          </aside>
        </div>
      </div>

      <RestaurantRail title="Potrebbero piacerti anche" items={similar.data} loading={similar.loading} source="similar" />
      <ReportSheet open={reporting} onClose={() => setReporting(false)} restaurantId={r.id} restaurantName={r.name} />

      <CartBar className={mobileActions.length > 0 ? 'bottom-[calc(80px+env(safe-area-inset-bottom))]' : 'bottom-[calc(12px+env(safe-area-inset-bottom))]'} />
      {/* ─── BARRA AZIONI MOBILE ─── */}
      {mobileActions.length > 0 && <div className="pb-safe fixed inset-x-0 bottom-0 z-50 border-t border-line bg-white/95 px-3 pt-2 shadow-bar backdrop-blur-xl md:hidden">
        <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${mobileActions.length}, minmax(0, 1fr))` }}>
          {mobileActions.map((a, i) => (
            <ActionLink
              key={a.key}
              a={a}
              onClick={() => !a.internal && track(a.event)}
              className={cn(
                'flex h-14 flex-col items-center justify-center gap-0.5 rounded-2xl text-xs font-semibold transition active:scale-95',
                i === 0 ? 'bg-coral text-white' : 'bg-cream text-ink',
              )}
            >
              <a.icon className="h-5 w-5" />
              {a.label}
            </ActionLink>
          ))}
        </div>
      </div>}
    </article>
  );
}

function InfoBlock({ r, track, whatsapp }: { r: RestaurantDetail; track: (t: AnalyticsEventType) => void; whatsapp: boolean }) {
  const point = r.latitude != null && r.longitude != null ? [{ id: r.id, lat: r.latitude, lng: r.longitude, label: r.name, emoji: r.categories[0]?.emoji, highlighted: true }] : [];
  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-2 flex items-center gap-2 text-lg font-bold">
          <Clock className="h-5 w-5 text-coral" /> Orari
        </h2>
        <HoursTable hours={r.hours} tz={r.timezone} />
        {r.hours.length > 0 && r.opening_hours_last_verified_at && (
          <p className="mt-2 text-xs text-ink-muted">Orari confermati il {formatDate(r.opening_hours_last_verified_at)}</p>
        )}
      </div>
      <div>
        <h2 className="mb-2 flex items-center gap-2 text-lg font-bold">
          <MapPin className="h-5 w-5 text-coral" /> Dove siamo
        </h2>
        <p className="text-[15px]">
          {r.address ?? <span className="text-ink-muted">Indirizzo non ancora verificato</span>}
          <br />
          <span className="text-ink-muted">
            {[r.postal_code, r.city?.name, r.province?.code && `(${r.province.code})`].filter(Boolean).join(' ')}
          </span>
        </p>
        {point.length > 0 && (
          <a href={directionsUrl(r)} target="_blank" rel="noopener noreferrer" onClick={() => track('directions_click')} className="mt-3 block overflow-hidden rounded-2xl border border-line">
            <Suspense fallback={<div className="h-44 w-full bg-cream" />}><MapView points={point} center={{ lat: point[0]!.lat, lng: point[0]!.lng }} activeId={r.id} zoom={15} className="h-44 w-full" /></Suspense>
          </a>
        )}
        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
          <a
            href={directionsUrl(r)}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => track('directions_click')}
            className="inline-flex items-center gap-2 text-sm font-semibold text-coral-700 hover:underline"
          >
            <Navigation className="h-4 w-4" /> Ottieni indicazioni
          </a>
          {point.length > 0 && (
            <Link to={`/map?restaurant=${encodeURIComponent(r.slug)}`} className="inline-flex items-center gap-2 text-sm font-semibold text-ink hover:underline">
              <MapIcon className="h-4 w-4" /> Vedi sulla mappa
            </Link>
          )}
        </div>
      </div>
      <div>
        <h2 className="mb-2 text-lg font-bold">Contatti</h2>
        <ul className="space-y-2.5 text-[15px]">
          {r.phone && (
            <ContactRow icon={Phone} href={telUrl(r.phone)} onClick={() => track('phone_click')}>
              {r.phone}
            </ContactRow>
          )}
          {r.whatsapp && whatsapp && (
            <ContactRow icon={MessageCircle} href={whatsappUrl(r.whatsapp)} onClick={() => track('whatsapp_click')}>
              WhatsApp
            </ContactRow>
          )}
          {r.email && (
            <ContactRow icon={Mail} href={`mailto:${r.email}`}>
              {r.email}
            </ContactRow>
          )}
          {r.website && (
            <ContactRow icon={Globe} href={r.website} onClick={() => track('website_click')}>
              {r.website.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '')}
            </ContactRow>
          )}
          {r.instagram && (
            <ContactRow icon={Instagram} href={socialUrl('instagram', r.instagram)} onClick={() => track('instagram_click')}>
              Instagram
            </ContactRow>
          )}
          {r.facebook && (
            <ContactRow icon={Facebook} href={socialUrl('facebook', r.facebook)} onClick={() => track('social_click')}>
              Facebook
            </ContactRow>
          )}
        </ul>
      </div>
    </div>
  );
}

function ContactRow({ icon: Icon, href, onClick, children }: { icon: typeof Phone; href: string; onClick?: () => void; children: React.ReactNode }) {
  return (
    <li>
      <a
        href={href}
        onClick={onClick}
        target={href.startsWith('http') ? '_blank' : undefined}
        rel="noopener noreferrer"
        className="flex items-center gap-3 rounded-xl py-1 transition hover:text-coral-700"
      >
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-cream">
          <Icon className="h-4 w-4" />
        </span>
        <span className="truncate">{children}</span>
      </a>
    </li>
  );
}

/** Trasparenza: chi gestisce le informazioni della scheda. */
function TrustLine({ r }: { r: RestaurantDetail }) {
  if (isOwnerVerified(r)) {
    return (
      <p className="mt-4 flex items-center gap-2 text-sm text-emerald-800">
        <BadgeCheck className="h-4 w-4 shrink-0" /> Profilo verificato: le informazioni sono gestite dal titolare.
      </p>
    );
  }
  return (
    <p className="mt-4 flex items-start gap-2 rounded-2xl bg-cream px-3 py-2 text-[13px] text-ink-soft">
      <ShieldQuestion className="mt-0.5 h-4 w-4 shrink-0 text-ink-muted" />
      <span>
        Informazioni pubbliche — attività non ancora verificata dal proprietario.
        {!r.is_permanently_closed && (
          <>
            {' '}
            <Link to={`/ristorante/${r.slug}/rivendica`} className="font-semibold text-ink underline-offset-2 hover:underline">Sei il titolare?</Link>
          </>
        )}
      </span>
    </p>
  );
}

/** Fonti dei dati, data di verifica e segnalazione errori. */
function SourcesBlock({ r, onReport }: { r: RestaurantDetail; onReport: () => void }) {
  const sources = r.sources.filter((s) => s.source_url || s.source_name);
  return (
    <section className="mt-10 rounded-4xl border border-line bg-white p-5 sm:p-6" aria-labelledby="fonti-title">
      <h2 id="fonti-title" className="text-lg font-bold">Informazioni sulla scheda</h2>
      <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-ink-muted">Ultima verifica dei dati</dt>
          <dd className="font-medium">{r.last_verified_at ? formatDate(r.last_verified_at) : isOwnerVerified(r) ? 'Aggiornati dal titolare' : 'Non ancora verificati'}</dd>
        </div>
        {r.menu_last_verified_at && (
          <div>
            <dt className="text-ink-muted">Menu confermato</dt>
            <dd className="font-medium">{formatDate(r.menu_last_verified_at)}</dd>
          </div>
        )}
      </dl>
      {sources.length > 0 && (
        <div className="mt-4">
          <p className="text-sm text-ink-muted">Fonti</p>
          <ul className="mt-1 flex flex-wrap gap-2">
            {sources.map((s) => (
              <li key={s.id}>
                {s.source_url ? (
                  <a href={s.source_url} target="_blank" rel="nofollow noopener noreferrer" className="inline-flex items-center gap-1 rounded-full border border-line px-3 py-1 text-xs font-medium hover:border-ink">
                    {s.source_name || SOURCE_TYPE[s.source_type]} <ExternalLink className="h-3 w-3" />
                  </a>
                ) : (
                  <Badge tone="outline">{s.source_name}</Badge>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
      {r.is_demo && <p className="mt-3 text-xs text-ink-muted">Scheda dimostrativa: locale di fantasia, dati non reali.</p>}
      <button onClick={onReport} className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-coral-700 hover:underline">
        <Flag className="h-4 w-4" /> Segnala informazioni errate
      </button>
    </section>
  );
}

/** Link azione: interno (prenotazione) con il router, esterno (tel:, WhatsApp, mappe) come <a>. */
function ActionLink({ a, className, onClick, children }: { a: { href: string; internal?: boolean }; className: string; onClick: () => void; children: ReactNode }) {
  if (a.internal) {
    return (
      <Link to={a.href} onClick={onClick} className={className}>
        {children}
      </Link>
    );
  }
  return (
    <a href={a.href} target={a.href.startsWith('http') ? '_blank' : undefined} rel="noopener noreferrer" onClick={onClick} className={className}>
      {children}
    </a>
  );
}
