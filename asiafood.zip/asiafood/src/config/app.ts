// ─────────────────────────────────────────────────────────────
//  Configurazione applicativa centralizzata.
//  Il nome "AsiaFood" è provvisorio: si cambia da VITE_APP_NAME
//  (o qui) senza toccare componenti e pagine.
// ─────────────────────────────────────────────────────────────
// (fallback vuoto: moduli condivisi usati anche da script/test Node senza Vite)
const env = (import.meta.env ?? {}) as Record<string, string | undefined>;

export const APP = {
  name: (env.VITE_APP_NAME as string) || 'AsiaFood',
  tagline: 'Il meglio della cucina asiatica vicino a te.',
  siteUrl: ((env.VITE_SITE_URL as string) || (typeof window !== 'undefined' ? window.location.origin : '')).replace(/\/$/, ''),
  locale: 'it-IT',
  currency: 'EUR',
  timezone: 'Europe/Rome',
  /** Area di lancio mostrata nei testi marketing. */
  launchArea: 'Taranto e provincia',
  defaultCitySlug: (env.VITE_DEFAULT_CITY_SLUG as string) || 'taranto',
  supportEmail: 'info@example.com',
} as const;

export const SUPABASE = {
  url: (env.VITE_SUPABASE_URL as string) || '',
  anonKey: (env.VITE_SUPABASE_ANON_KEY as string) || '',
  bucket: (env.VITE_SUPABASE_STORAGE_BUCKET as string) || 'restaurant-media',
};

export const isSupabaseConfigured = Boolean(SUPABASE.url && SUPABASE.anonKey);

// Stripe: nel frontend SOLO la chiave pubblicabile (pk_…). Le chiavi segrete vivono nelle Netlify Functions.
const stripePk = ((env.VITE_STRIPE_PUBLISHABLE_KEY as string) || '').trim();
const billingFlag = ((env.VITE_BILLING_ENABLED as string) || '').trim().toLowerCase();

export const BILLING = {
  /**
   * Pagamenti online attivi: con Supabase servono la chiave pubblicabile Stripe (e le funzioni server);
   * in modalità DEMO il checkout è simulato. VITE_BILLING_ENABLED=false li disattiva (resta la lista d'attesa).
   */
  enabled: billingFlag === 'false' ? false : isSupabaseConfigured ? /^pk_(test|live)_/.test(stripePk) : true,
  /** true = modalità DEMO: nessun addebito, flussi simulati nel browser. */
  simulated: !isSupabaseConfigured,
  /** Ambiente Stripe dedotto dalla chiave pubblicabile (mai passare in live per errore). */
  mode: (stripePk.startsWith('pk_live_') ? 'live' : 'test') as 'test' | 'live',
  apiBase: '/api/billing',
} as const;

/** Fase 8: ordini online (B2C). Pagamento con Stripe PaymentIntent (chiave pubblicabile) o SIMULATO in DEMO. */
export const ORDERS = {
  simulated: !isSupabaseConfigured,
  stripePublishableKey: /^pk_(test|live)_/.test(stripePk) ? stripePk : '',
  mode: (stripePk.startsWith('pk_live_') ? 'live' : 'test') as 'test' | 'live',
  apiBase: '/api/orders',
} as const;

const aiFlag = ((env.VITE_AI_ENABLED as string) || '').trim().toLowerCase();

export const AI = {
  /** Assistente visibile nell'app (VITE_AI_ENABLED=false lo nasconde). La chiave del modello è solo sul server. */
  enabled: aiFlag !== 'false',
  endpoint: '/api/ai/chat',
  /** Oltre questo tempo si mostra "Riprova" senza perdere il testo scritto. */
  timeoutMs: 30_000,
} as const;

export type MapsProvider = 'none' | 'google' | 'mapbox';

// Token pubblico Mapbox (pk.…): mai chiavi segrete nel frontend.
const mapboxToken = (env.VITE_MAPBOX_ACCESS_TOKEN as string) || (env.VITE_MAPBOX_TOKEN as string) || '';
const explicitProvider = (env.VITE_MAPS_PROVIDER as string) || '';

export const MAPS = {
  /** Mapbox è la prima scelta: si attiva da solo quando c'è il token (salvo VITE_MAPS_PROVIDER esplicito). */
  provider: (explicitProvider || (mapboxToken ? 'mapbox' : 'none')) as MapsProvider,
  googleKey: (env.VITE_GOOGLE_MAPS_API_KEY as string) || '',
  mapboxToken,
  /** Geocoding (indirizzo → coordinate) disponibile solo con Mapbox configurato. */
  geocoding: !!mapboxToken,
};

/** Raggi del filtro distanza (km) e default. */
export const RADIUS_OPTIONS = [1, 3, 5, 10, 20, 50] as const;
export const DEFAULT_RADIUS_KM = 10;

/** Giorni per considerare un locale "nuova apertura". */
export const NEW_OPENING_DAYS = 120;
