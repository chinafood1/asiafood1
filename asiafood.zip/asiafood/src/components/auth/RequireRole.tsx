import type { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import type { UserRole } from '@/types/domain';
import { PageLoader } from '@/components/ui/Layout';
import { EmptyState } from '@/components/ui/Layout';
import { ButtonLink } from '@/components/ui/Button';

/**
 * Protezione lato UI delle rotte riservate. La sicurezza vera è nelle
 * policy RLS: questo guard evita solo di mostrare pagine inutili.
 */
export function RequireRole({ roles, children }: { roles: UserRole[]; children: ReactNode }) {
  const { user, role, loading } = useAuth();
  const location = useLocation();
  if (loading) return <PageLoader />;
  if (!user) return <Navigate to={`/accedi?next=${encodeURIComponent(location.pathname)}`} replace />;
  if (!role || !roles.includes(role)) {
    return (
      <div className="container-app py-16">
        <EmptyState
          icon="🔒"
          title="Accesso non consentito"
          text={
            roles.includes('restaurant_owner')
              ? 'La dashboard è disponibile dopo che l’Admin ha approvato la rivendicazione del tuo locale.'
              : 'Quest’area è riservata agli amministratori.'
          }
          action={<ButtonLink to={roles.includes('restaurant_owner') ? '/per-ristoratori' : '/'}>Continua</ButtonLink>}
        />
      </div>
    );
  }
  return <>{children}</>;
}
