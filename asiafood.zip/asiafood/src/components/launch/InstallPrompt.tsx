// ─────────────────────────────────────────────────────────────
//  Fase 12 · "Aggiungi AsiaFood alla schermata Home" — solo su dispositivi compatibili.
//  Chrome/Edge/Android: prompt nativo (beforeinstallprompt). iPhone/iPad Safari: istruzioni.
//  Nascosto se l'app è già installata o il browser non la supporta. Mai "scarica dall'App Store":
//  AsiaFood non è (ancora) pubblicata sugli store.
// ─────────────────────────────────────────────────────────────
import { useEffect, useState } from 'react';
import { Download, Share } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { api } from '@/services';
import { APP } from '@/config/app';

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

let deferred: BeforeInstallPromptEvent | null = null;
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferred = e as BeforeInstallPromptEvent;
  });
}

const standalone = () => typeof window !== 'undefined' && (window.matchMedia?.('(display-mode: standalone)').matches || (navigator as unknown as { standalone?: boolean }).standalone === true);
const isIos = () => typeof navigator !== 'undefined' && /iphone|ipad|ipod/i.test(navigator.userAgent) && !/crios|fxios/i.test(navigator.userAgent);

export function useInstallState() {
  const [can, setCan] = useState<'native' | 'ios' | null>(null);
  useEffect(() => {
    if (standalone()) return;
    if (deferred) setCan('native');
    else if (isIos()) setCan('ios');
    const on = () => setCan('native');
    window.addEventListener('beforeinstallprompt', on);
    return () => window.removeEventListener('beforeinstallprompt', on);
  }, []);
  return can;
}

export function InstallPrompt({ compact }: { compact?: boolean }) {
  const can = useInstallState();
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (can) api.trackAppEvent('install_prompt_shown', { source: can });
  }, [can]);
  if (!can || done) return null;
  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    const r = await deferred.userChoice;
    if (r.outcome === 'accepted') {
      api.trackAppEvent('install_accepted', { source: 'native' });
      setDone(true);
    }
    deferred = null;
  };
  return (
    <div className={compact ? '' : 'rounded-3xl border border-line bg-white p-5'} data-testid="install-prompt">
      <p className="font-bold">Aggiungi {APP.name} alla schermata Home</p>
      {can === 'native' ? (
        <>
          <p className="mt-1 text-sm text-ink-muted">Si apre come un’app, senza passare dagli store.</p>
          <Button size="sm" className="mt-3" onClick={() => void install()}><Download className="h-4 w-4" /> Aggiungi alla schermata Home</Button>
        </>
      ) : (
        <p className="mt-1 text-sm text-ink-muted">Su iPhone/iPad: tocca <Share className="inline h-4 w-4" aria-label="Condividi" /> “Condividi” in Safari, poi “Aggiungi alla schermata Home”.</p>
      )}
    </div>
  );
}
