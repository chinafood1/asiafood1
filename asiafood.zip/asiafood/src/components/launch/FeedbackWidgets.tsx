// ─────────────────────────────────────────────────────────────
//  Fase 12 · Feedback in-app e NPS.
//  - "Come possiamo migliorare AsiaFood?": sempre facoltativo, anche per ospiti.
//  - NPS: solo se attivo, dopo uso significativo (deciso dal server) e mai più di una volta per sessione;
//    "Non ora" silenzia la richiesta per 30 giorni su questo dispositivo.
// ─────────────────────────────────────────────────────────────
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { MessageSquareHeart, X } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Textarea } from '@/components/ui/Field';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { useAuth } from '@/context/AuthContext';
import { APP } from '@/config/app';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { api } from '@/services';

export function UserFeedbackButton({ className }: { className?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className={cn('inline-flex items-center gap-1.5 hover:underline', className)} onClick={() => { setOpen(true); api.trackAppEvent('feedback_opened', { source: 'user' }); }} data-testid="feedback-open">
        <MessageSquareHeart className="h-4 w-4" aria-hidden /> Suggerimenti
      </button>
      <Sheet open={open} onClose={() => setOpen(false)} title={`Come possiamo migliorare ${APP.name}?`}>
        <UserFeedbackForm onDone={() => setOpen(false)} />
      </Sheet>
    </>
  );
}

function UserFeedbackForm({ onDone }: { onDone: () => void }) {
  const toast = useToast();
  const { pathname } = useLocation();
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    setBusy(true);
    try {
      await api.launch.submitFeedback({ type: 'user_general', message: msg, page: pathname.slice(0, 120) });
      toast('Grazie! Il tuo suggerimento è arrivato.');
      onDone();
    } catch (e) {
      toast(friendlyError(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="space-y-3" data-testid="feedback-form">
      <p className="text-sm text-ink-muted">Cosa manca, cosa non funziona, cosa ti piacerebbe trovare? Non scrivere dati personali: per un problema con un ordine usa la pagina Supporto.</p>
      <Textarea rows={4} value={msg} onChange={(e) => setMsg(e.target.value)} aria-label="Il tuo suggerimento" data-testid="feedback-message" maxLength={2000} />
      <Button disabled={busy || msg.trim().length < 3} onClick={() => void send()} data-testid="feedback-send">Invia</Button>
    </div>
  );
}

const SNOOZE = 'af_nps_snooze';
let askedThisSession = false;

export function NpsPrompt() {
  const { user } = useAuth();
  const toast = useToast();
  const [show, setShow] = useState(false);
  const [score, setScore] = useState<number | null>(null);
  const [msg, setMsg] = useState('');
  useEffect(() => {
    if (!user || askedThisSession) return;
    try {
      const until = Number(localStorage.getItem(SNOOZE) ?? 0);
      if (until > Date.now()) return;
    } catch {
      return;
    }
    const t = setTimeout(() => {
      void api.launch.npsShouldAsk().then((ok) => {
        if (ok && !askedThisSession) {
          askedThisSession = true;
          setShow(true);
        }
      });
    }, 8000);
    return () => clearTimeout(t);
  }, [user]);
  if (!show) return null;
  const later = () => {
    try {
      localStorage.setItem(SNOOZE, String(Date.now() + 30 * 86_400_000));
    } catch {
      /* ignorato */
    }
    setShow(false);
  };
  const send = async () => {
    if (score == null) return;
    try {
      await api.launch.submitFeedback({ type: 'nps', rating: score, message: msg || null });
      toast('Grazie per la risposta!');
      setShow(false);
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <div className="fixed inset-x-3 bottom-24 z-[70] mx-auto max-w-md rounded-3xl border border-line bg-white p-4 shadow-lift md:bottom-6" role="dialog" aria-label="Valuta AsiaFood" data-testid="nps-prompt">
      <div className="flex items-start justify-between gap-3">
        <p className="font-semibold">Quanto consiglieresti {APP.name} a un amico?</p>
        <button type="button" onClick={later} aria-label="Non ora" className="rounded-full p-1 hover:bg-cream"><X className="h-4 w-4" /></button>
      </div>
      <div className="mt-3 grid grid-cols-11 gap-1" role="radiogroup" aria-label="Da 0 a 10">
        {Array.from({ length: 11 }, (_, i) => (
          <button key={i} type="button" role="radio" aria-checked={score === i} onClick={() => setScore(i)}
            className={cn('h-9 rounded-lg border text-sm font-semibold', score === i ? 'border-ink bg-ink text-white' : 'border-line hover:border-ink')}>{i}</button>
        ))}
      </div>
      <div className="mt-1 flex justify-between text-[11px] text-ink-muted"><span>Per niente</span><span>Sicuramente</span></div>
      {score != null && <Textarea className="mt-3" rows={2} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Vuoi dirci perché? (facoltativo)" aria-label="Motivo (facoltativo)" />}
      <div className="mt-3 flex justify-end gap-2"><Button size="sm" variant="ghost" onClick={later}>Non ora</Button><Button size="sm" disabled={score == null} onClick={() => void send()}>Invia</Button></div>
    </div>
  );
}
