// ─────────────────────────────────────────────────────────────
//  Fase 12 · Badge "Founding Foodie" (nessun valore economico) e candidatura AsiaFood Ambassador
//  (volontaria, senza compensi automatici).
// ─────────────────────────────────────────────────────────────
import { useState } from 'react';
import { Award, Megaphone } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Textarea } from '@/components/ui/Field';
import { useToast } from '@/components/ui/Toast';
import { APP } from '@/config/app';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { api } from '@/services';

export function FoundingFoodieBadge() {
  const m = useAsync(() => api.launch.myAmbassador().catch(() => null), []);
  if (!m.data?.founding_foodie_at) return null;
  return (
    <p className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-ink px-3 py-1 text-xs font-bold text-white" data-testid="founding-foodie">
      <Award className="h-3.5 w-3.5" aria-hidden /> Founding Foodie · tra i primi utenti di {APP.name} a Taranto
    </p>
  );
}

export function AmbassadorCard() {
  const toast = useToast();
  const m = useAsync(() => api.launch.myAmbassador().catch(() => null), []);
  const [motivation, setMotivation] = useState('');
  if (!m.data || (!m.data.enabled && !m.data.status)) return null;
  const apply = async () => {
    try {
      await api.launch.ambassadorApply(motivation);
      toast('Candidatura inviata: ti ricontatteremo');
      m.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <section className="rounded-3xl border border-line bg-white p-5" data-testid="ambassador-card">
      <p className="flex items-center gap-2 font-bold"><Megaphone className="h-5 w-5 text-coral" aria-hidden /> {APP.name} Ambassador</p>
      {m.data.status ? (
        <p className="mt-1 text-sm text-ink-muted">Stato della candidatura: <strong className="text-ink">{m.data.status === 'applied' ? 'in valutazione' : m.data.status === 'approved' ? 'approvata' : m.data.status === 'paused' ? 'in pausa' : 'non accolta'}</strong>. Il tuo codice invito: <span className="font-mono">{m.data.referral_code}</span></p>
      ) : (
        <>
          <p className="mt-1 text-sm text-ink-muted">Conosci bene i locali asiatici di Taranto? Aiutaci a farli scoprire: segnala ristoranti, condividi l’app, crea contenuti, invita amici. È un programma volontario: eventuali premi saranno comunicati con un regolamento.</p>
          <Textarea className="mt-3" rows={2} value={motivation} onChange={(e) => setMotivation(e.target.value)} placeholder="Due righe su di te (facoltativo)" aria-label="Motivazione" />
          <Button size="sm" className="mt-2" onClick={() => void apply()} data-testid="ambassador-apply">Candidati</Button>
        </>
      )}
    </section>
  );
}
