// ─────────────────────────────────────────────────────────────
//  Fase 12 · Materiali stampabili (A4 con linee di taglio): table card A6, counter card A5,
//  sticker, sticker piccoli, volantini (clienti / ristoratori), poster partner.
//  "Stampa" apre il dialogo del browser: "Salva come PDF" produce il PDF stampabile.
// ─────────────────────────────────────────────────────────────
import { useRef } from 'react';
import { Printer } from 'lucide-react';
import { QrCode } from '@/components/ui/QrCode';
import { Button } from '@/components/ui/Button';
import { APP } from '@/config/app';

export type PrintKind = 'table_a6' | 'counter_a5' | 'sticker' | 'small_sticker' | 'flyer_customer' | 'flyer_restaurant' | 'poster_partner';

export const PRINT_KINDS: Record<PrintKind, { label: string; perSheet: number; size: string }> = {
  table_a6: { label: 'Table card A6', perSheet: 4, size: '4 per foglio A4' },
  counter_a5: { label: 'Counter card A5', perSheet: 2, size: '2 per foglio A4' },
  sticker: { label: 'Sticker 6 cm', perSheet: 12, size: '12 per foglio A4' },
  small_sticker: { label: 'Sticker piccolo da tavolo 3,5 cm', perSheet: 35, size: '35 per foglio A4' },
  flyer_customer: { label: 'Volantino clienti A5', perSheet: 2, size: '2 per foglio A4' },
  flyer_restaurant: { label: 'Volantino ristoratori A5', perSheet: 2, size: '2 per foglio A4' },
  poster_partner: { label: 'Poster A4 (hotel, B&B, partner)', perSheet: 1, size: '1 per foglio A4' },
};

export interface PrintContent { qrUrl: string; title: string; subtitle?: string | null; cta?: string | null; badge?: string | null }

function Brand({ small }: { small?: boolean }) {
  return <p className={small ? 'text-[9px] font-extrabold tracking-wide' : 'font-display text-lg font-extrabold'}>{APP.name}</p>;
}

function Item({ kind, c }: { kind: PrintKind; c: PrintContent }) {
  const shortUrl = c.qrUrl.replace(/^https?:\/\//, '').replace(/\?.*$/, '');
  if (kind === 'small_sticker') {
    return (
      <div className="flex h-[35mm] w-[35mm] flex-col items-center justify-center rounded-md border border-dashed border-ink/30 p-1 text-center">
        <QrCode value={c.qrUrl} size={78} />
        <Brand small />
      </div>
    );
  }
  if (kind === 'sticker') {
    return (
      <div className="flex h-[60mm] w-[60mm] flex-col items-center justify-center rounded-xl border border-dashed border-ink/30 p-2 text-center">
        <QrCode value={c.qrUrl} size={130} />
        <p className="mt-1 text-[11px] font-bold leading-tight">{c.cta ?? c.title}</p>
        <Brand small />
      </div>
    );
  }
  const big = kind === 'poster_partner';
  const a5 = kind === 'counter_a5' || kind === 'flyer_customer' || kind === 'flyer_restaurant';
  const box = big ? 'h-[270mm] w-[194mm]' : a5 ? 'h-[138mm] w-[194mm] flex-row' : 'h-[138mm] w-[95mm]';
  return (
    <div className={`flex ${a5 ? 'flex-row gap-6 px-8' : 'flex-col px-5'} ${box} items-center justify-center rounded-2xl border border-dashed border-ink/30 bg-white text-center`}>
      <div className={a5 ? 'flex-1 text-left' : ''}>
        <Brand />
        {c.badge && <p className="mt-1 inline-block rounded-full bg-ink px-2 py-0.5 text-[10px] font-bold text-white">{c.badge}</p>}
        <p className={`${big ? 'mt-6 text-5xl' : a5 ? 'mt-3 text-3xl' : 'mt-2 text-xl'} font-display font-extrabold leading-tight`}>{c.title}</p>
        {c.subtitle && <p className={`${big ? 'mt-4 text-2xl' : 'mt-2 text-sm'} text-ink-soft`}>{c.subtitle}</p>}
        {a5 && c.cta && <p className="mt-4 text-lg font-bold">{c.cta}</p>}
      </div>
      <div className="flex flex-col items-center">
        <QrCode value={c.qrUrl} size={big ? 420 : a5 ? 220 : 200} className="mt-3" />
        {!a5 && c.cta && <p className={`${big ? 'mt-6 text-3xl' : 'mt-2 text-base'} font-bold`}>{c.cta}</p>}
        <p className={`${big ? 'mt-3 text-base' : 'mt-1 text-[10px]'} text-ink-muted`}>{shortUrl}</p>
      </div>
    </div>
  );
}

/** Foglio A4 con N copie del materiale. `id` univoco per la stampa del solo foglio scelto. */
export function PrintSheet({ kind, content, testId }: { kind: PrintKind; content: PrintContent; testId?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const count = PRINT_KINDS[kind].perSheet;
  const print = () => {
    const el = ref.current;
    if (!el) return;
    el.dataset.active = 'true';
    const off = () => {
      el.dataset.active = 'false';
      window.removeEventListener('afterprint', off);
    };
    window.addEventListener('afterprint', off);
    window.print();
  };
  const grid = kind === 'small_sticker' ? 'grid-cols-5' : kind === 'sticker' ? 'grid-cols-3' : kind === 'table_a6' ? 'grid-cols-2' : 'grid-cols-1';
  return (
    <div data-testid={testId}>
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm"><strong>{PRINT_KINDS[kind].label}</strong> <span className="text-ink-muted">· {PRINT_KINDS[kind].size}</span></p>
        <Button size="sm" variant="outline" onClick={print}><Printer className="h-4 w-4" /> Stampa / Salva PDF</Button>
      </div>
      <div className="overflow-x-auto rounded-2xl bg-cream/60 p-3" tabIndex={0} role="region" aria-label={`Anteprima: ${PRINT_KINDS[kind].label}`}>
        <div ref={ref} data-active="false" className={`print-sheet mx-auto grid w-[194mm] origin-top-left gap-[4mm] bg-white p-0 shadow-card ${grid}`} style={{ zoom: 0.5 }}>
          {Array.from({ length: count }, (_, i) => <Item key={i} kind={kind} c={content} />)}
        </div>
      </div>
    </div>
  );
}
