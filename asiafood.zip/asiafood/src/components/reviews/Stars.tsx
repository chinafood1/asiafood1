import { Star } from 'lucide-react';
import { cn } from '@/lib/format';

const fmt = (n: number) => n.toLocaleString('it-IT', { minimumFractionDigits: 1, maximumFractionDigits: 1 });

/** Stelle in sola lettura, con etichetta testuale (non solo colore). */
export function StarsDisplay({ value, size = 'sm', className }: { value: number; size?: 'sm' | 'md' | 'lg'; className?: string }) {
  const px = size === 'lg' ? 'h-6 w-6' : size === 'md' ? 'h-5 w-5' : 'h-4 w-4';
  return (
    <span className={cn('inline-flex items-center gap-0.5', className)} role="img" aria-label={`${fmt(value)} su 5`}>
      {[1, 2, 3, 4, 5].map((i) => {
        const fill = Math.max(0, Math.min(1, value - (i - 1)));
        return (
          <span key={i} className={cn('relative inline-block', px)} aria-hidden>
            <Star className={cn('absolute inset-0 text-line', px)} fill="currentColor" strokeWidth={0} />
            {fill > 0 && (
              <span className="absolute inset-0 overflow-hidden" style={{ width: `${fill * 100}%` }}>
                <Star className={cn('text-amber-500', px)} fill="currentColor" strokeWidth={0} />
              </span>
            )}
          </span>
        );
      })}
    </span>
  );
}

/**
 * Valutazione 1–5 accessibile: radio native (frecce da tastiera, lettori di schermo),
 * etichette "1 stella … 5 stelle" e valore scritto accanto.
 */
export function StarInput({ name, label, value, onChange, required, optionalHint }: { name: string; label: string; value: number | null; onChange: (v: number | null) => void; required?: boolean; optionalHint?: boolean }) {
  const words = ['', 'Pessimo', 'Scarso', 'Nella media', 'Buono', 'Eccellente'];
  return (
    <fieldset className="min-w-0">
      <legend className="mb-1 text-sm font-semibold">
        {label}
        {required ? <span className="text-coral-700"> *</span> : optionalHint ? <span className="font-normal text-ink-muted"> (facoltativo)</span> : null}
      </legend>
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex">
          {[1, 2, 3, 4, 5].map((i) => (
            <label key={i} className="cursor-pointer p-0.5">
              <input
                type="radio"
                name={name}
                value={i}
                checked={value === i}
                onChange={() => onChange(i)}
                required={required && i === 1}
                className="peer sr-only"
              />
              <span className="sr-only">{i === 1 ? '1 stella' : `${i} stelle`}</span>
              <Star
                aria-hidden
                className={cn('h-8 w-8 rounded-md transition peer-focus-visible:ring-2 peer-focus-visible:ring-ink', value != null && i <= value ? 'text-amber-500' : 'text-line')}
                fill="currentColor"
                strokeWidth={0}
              />
            </label>
          ))}
        </div>
        <span className="text-sm text-ink-muted" aria-live="polite">{value ? `${value}/5 · ${words[value]}` : 'Nessuna valutazione'}</span>
        {!required && value != null && (
          <button type="button" className="text-xs font-semibold text-ink-muted underline" onClick={() => onChange(null)}>
            Rimuovi
          </button>
        )}
      </div>
    </fieldset>
  );
}

export const ratingLabel = (avg: number | null, count: number) =>
  count === 0 || avg == null ? 'Ancora nessuna recensione' : `${fmt(avg)} · ${count} ${count === 1 ? 'recensione' : 'recensioni'}`;
export { fmt as formatRating };
