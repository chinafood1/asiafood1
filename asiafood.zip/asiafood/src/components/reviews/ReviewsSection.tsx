import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link, useLocation, useSearchParams } from 'react-router-dom';
import { BadgeCheck, Flag, MessageSquareQuote, PenLine, Store, ThumbsUp } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { cn, formatDate } from '@/lib/format';
import { api } from '@/services';
import {
  REVIEW_REPORT_REASONS, SUB_RATINGS, type RestaurantRating, type ReviewFilter, type ReviewFormStatus, type ReviewInput, type ReviewItem,
  type ReviewReportReason, type ReviewSort, type SubRatingKey,
} from '@/types/engagement';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { formatRating, StarInput, StarsDisplay } from './Stars';

const PAGE = 8;
const SORTS: { value: ReviewSort; label: string }[] = [
  { value: 'recent', label: 'Più recenti' },
  { value: 'helpful', label: 'Più utili' },
  { value: 'high', label: 'Valutazione alta' },
  { value: 'low', label: 'Valutazione bassa' },
];
const FILTERS: { value: ReviewFilter; label: string }[] = [
  { value: null, label: 'Tutte' },
  { value: 'verified', label: 'Verificate' },
  { value: '5', label: '5 stelle' },
  { value: '4', label: '4 stelle' },
  { value: '3', label: '3 stelle' },
  { value: '2', label: '2 stelle' },
  { value: '1', label: '1 stella' },
];

/** Media e numero di recensioni (solo dati reali) per l'intestazione della scheda. */
export function RatingSummaryInline({ rating }: { rating: RestaurantRating | null }) {
  if (!rating) return null;
  if (!rating.count || rating.average == null) {
    return <a href="#recensioni" className="text-ink-muted hover:text-ink">Ancora nessuna recensione</a>;
  }
  return (
    <a href="#recensioni" className="inline-flex items-center gap-1.5 font-semibold hover:underline" aria-label={`Valutazione ${formatRating(rating.average)} su 5, ${rating.count} recensioni`}>
      <StarsDisplay value={rating.average} />
      <span>{formatRating(rating.average)}</span>
      <span className="font-normal text-ink-muted">· {rating.count} {rating.count === 1 ? 'recensione' : 'recensioni'}</span>
    </a>
  );
}

export function ReviewsSection({ restaurantId, restaurantName, restaurantSlug, onRating }: { restaurantId: string; restaurantName: string; restaurantSlug: string; onRating?: (r: RestaurantRating) => void }) {
  const { user } = useAuth();
  const toast = useToast();
  const location = useLocation();
  const [params, setParams] = useSearchParams();
  const [rating, setRating] = useState<RestaurantRating | null>(null);
  const [items, setItems] = useState<ReviewItem[]>([]);
  const [total, setTotal] = useState(0);
  const [sort, setSort] = useState<ReviewSort>('recent');
  const [filter, setFilter] = useState<ReviewFilter>(null);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [reporting, setReporting] = useState<string | null>(null);

  const load = useCallback(
    async (reset = true) => {
      setLoading(true);
      try {
        const [r, list] = await Promise.all([api.getRestaurantRating(restaurantId), api.listReviews(restaurantId, { sort, filter, limit: PAGE, offset: reset ? 0 : items.length })]);
        setRating(r);
        onRating?.(r);
        setTotal(list.total);
        setItems((prev) => (reset ? list.items : [...prev, ...list.items]));
      } finally {
        setLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [restaurantId, sort, filter, items.length],
  );
  useEffect(() => {
    void load(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [restaurantId, sort, filter]);

  // Link "Lascia una recensione" (notifica, QR): apre il form
  useEffect(() => {
    if (params.get('review') === '1') {
      setFormOpen(true);
      const p = new URLSearchParams(params);
      p.delete('review');
      setParams(p, { replace: true });
    }
  }, [params, setParams]);

  const vote = async (r: ReviewItem) => {
    if (!user) return toast('Accedi per segnare una recensione come utile.', 'error');
    try {
      const n = await api.voteReview(r.id, !r.my_vote);
      setItems((xs) => xs.map((x) => (x.id === r.id ? { ...x, my_vote: !r.my_vote, helpful_count: n } : x)));
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };

  const loginHref = `/accedi?next=${encodeURIComponent(`/ristorante/${restaurantSlug}?review=1`)}`;
  const dist = rating?.distribution;

  return (
    <section id="recensioni" className="scroll-mt-32 pt-10" aria-labelledby="reviews-title">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h2 id="reviews-title" className="text-2xl font-bold">Recensioni</h2>
        {user ? (
          <Button size="sm" icon={<PenLine className="h-4 w-4" />} onClick={() => setFormOpen(true)}>Scrivi una recensione</Button>
        ) : (
          <Link to={loginHref} state={{ from: location.pathname }} className="inline-flex h-9 items-center gap-2 rounded-full bg-coral px-4 text-sm font-semibold text-white">
            <PenLine className="h-4 w-4" /> Scrivi una recensione
          </Link>
        )}
      </div>

      {rating && rating.count > 0 && rating.average != null ? (
        <div className="mt-4 grid gap-5 rounded-3xl border border-line bg-white p-5 sm:grid-cols-[auto_1fr]">
          <div className="text-center sm:pr-4">
            <p className="font-display text-5xl font-extrabold leading-none">{formatRating(rating.average)}</p>
            <StarsDisplay value={rating.average} size="md" className="mt-2" />
            <p className="mt-1 text-sm text-ink-muted">{rating.count} {rating.count === 1 ? 'recensione' : 'recensioni'}</p>
            {rating.verified_count > 0 && <p className="mt-0.5 text-xs text-emerald-700">{rating.verified_count} con visita verificata</p>}
          </div>
          <div className="space-y-1.5">
            {(['5', '4', '3', '2', '1'] as const).map((k) => (
              <div key={k} className="grid grid-cols-[3.5rem_1fr_2rem] items-center gap-2 text-sm">
                <span className="text-ink-muted">{k} {k === '1' ? 'stella' : 'stelle'}</span>
                <span className="h-2 overflow-hidden rounded-full bg-cream" aria-hidden>
                  <span className="block h-full rounded-full bg-amber-500" style={{ width: `${dist ? (dist[k] / rating.count) * 100 : 0}%` }} />
                </span>
                <span className="text-right tabular-nums">{dist?.[k] ?? 0}</span>
              </div>
            ))}
            <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-sm sm:grid-cols-4">
              {[
                ['Cibo', rating.food],
                ['Servizio', rating.service],
                ['Qualità/prezzo', rating.value],
                ['Atmosfera', rating.atmosphere],
              ].map(([l, v]) => (
                <div key={l as string}>
                  <dt className="text-ink-muted">{l}</dt>
                  <dd className="font-semibold">{v != null ? `${formatRating(v as number)}/5` : '—'}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      ) : (
        !loading && <p className="mt-4 rounded-3xl bg-cream px-5 py-6 text-center text-ink-muted">Ancora nessuna recensione. Sei stato da {restaurantName}? Racconta la tua esperienza.</p>
      )}

      {rating && rating.count > 0 && (
        <div className="mt-5 flex flex-wrap items-center gap-2">
          <div className="scrollbar-none -mx-1 flex max-w-full gap-2 overflow-x-auto px-1" role="group" aria-label="Filtra recensioni">
            {FILTERS.map((f) => (
              <Chip key={String(f.value)} active={filter === f.value} onClick={() => setFilter(f.value)} className="!h-9">{f.label}</Chip>
            ))}
          </div>
          <Select aria-label="Ordina recensioni" value={sort} onChange={(e) => setSort(e.target.value as ReviewSort)} className="!h-9 !w-auto !rounded-full !py-0 text-sm sm:ml-auto">
            {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </Select>
        </div>
      )}

      <ul className="mt-4 space-y-3" aria-live="polite">
        {items.map((r) => (
          <li key={r.id} className="rounded-3xl border border-line bg-white p-5">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink text-sm font-bold text-white" aria-hidden>{r.author.slice(0, 1).toUpperCase()}</span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  <p className="font-semibold">{r.author}{r.is_mine && <span className="font-normal text-ink-muted"> (tu)</span>}</p>
                  {r.is_verified && <Badge tone="green" icon={<BadgeCheck className="h-3.5 w-3.5" />}>{r.verification_source === 'order' ? 'Ordine verificato' : 'Visita verificata'}</Badge>}
                </div>
                <div className="mt-0.5 flex flex-wrap items-center gap-2 text-sm text-ink-muted">
                  <StarsDisplay value={r.rating_overall} />
                  <span>{r.rating_overall}/5</span>
                  <span>· {formatDate(r.published_at ?? r.created_at)}</span>
                  {r.is_edited && <span>· Modificata</span>}
                </div>
              </div>
            </div>
            {r.title && <p className="mt-3 font-semibold">{r.title}</p>}
            <p className="mt-1 whitespace-pre-line text-[15px] leading-relaxed">{r.content}</p>
            {SUB_RATINGS.some((s) => r[s.key] != null) && (
              <p className="mt-2 flex flex-wrap gap-x-3 text-xs text-ink-muted">
                {SUB_RATINGS.filter((s) => r[s.key] != null).map((s) => <span key={s.key}>{s.label} {r[s.key]}/5</span>)}
              </p>
            )}
            {r.response && (
              <div className="mt-3 rounded-2xl bg-cream p-4">
                <p className="flex items-center gap-1.5 text-sm font-semibold"><Store className="h-4 w-4" /> Risposta del ristorante</p>
                <p className="mt-1 whitespace-pre-line text-sm">{r.response.content}</p>
              </div>
            )}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {!r.is_mine && (
                <button type="button" onClick={() => void vote(r)} aria-pressed={r.my_vote} className={cn('inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-sm font-medium', r.my_vote ? 'border-ink bg-ink text-white' : 'border-line hover:border-ink')}>
                  <ThumbsUp className="h-3.5 w-3.5" /> Utile{r.helpful_count ? ` (${r.helpful_count})` : ''}
                </button>
              )}
              {r.is_mine && r.helpful_count > 0 && <span className="text-sm text-ink-muted">{r.helpful_count} {r.helpful_count === 1 ? 'persona l’ha trovata utile' : 'persone l’hanno trovata utile'}</span>}
              {user && !r.is_mine && (
                <button type="button" onClick={() => setReporting(r.id)} className="inline-flex h-8 items-center gap-1 rounded-full px-2 text-sm text-ink-muted hover:text-ink">
                  <Flag className="h-3.5 w-3.5" /> Segnala
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
      {items.length < total && (
        <Button variant="outline" size="sm" className="mt-4" loading={loading} onClick={() => void load(false)}>Mostra altre recensioni</Button>
      )}

      <ReviewFormSheet open={formOpen} onClose={() => setFormOpen(false)} restaurantId={restaurantId} restaurantName={restaurantName} loginHref={loginHref} onDone={() => void load(true)} />
      <ReportSheet reviewId={reporting} onClose={() => setReporting(null)} />
    </section>
  );
}

function ReportSheet({ reviewId, onClose }: { reviewId: string | null; onClose: () => void }) {
  const toast = useToast();
  const [reason, setReason] = useState<ReviewReportReason>('spam');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!reviewId) return;
    setBusy(true);
    try {
      await api.reportReview(reviewId, reason, details || null);
      toast('Segnalazione inviata: la valuterà lo staff.');
      onClose();
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet open={!!reviewId} onClose={onClose} title="Segnala recensione">
      <form onSubmit={submit} className="space-y-4">
        <p className="text-sm text-ink-muted">Una segnalazione non rimuove la recensione: la decisione spetta allo staff di AsiaFood.</p>
        <Field label="Motivo">
          <Select value={reason} onChange={(e) => setReason(e.target.value as ReviewReportReason)}>
            {REVIEW_REPORT_REASONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
          </Select>
        </Field>
        <Field label="Dettagli (facoltativi)">
          <Textarea value={details} maxLength={500} onChange={(e) => setDetails(e.target.value)} />
        </Field>
        <Button type="submit" loading={busy}>Invia segnalazione</Button>
      </form>
    </Sheet>
  );
}

function ReviewFormSheet({ open, onClose, restaurantId, restaurantName, loginHref, onDone }: { open: boolean; onClose: () => void; restaurantId: string; restaurantName: string; loginHref: string; onDone: () => void }) {
  const toast = useToast();
  const [st, setSt] = useState<ReviewFormStatus | null>(null);
  const [form, setForm] = useState<ReviewInput>({ rating_overall: 0, content: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ status: string; is_verified: boolean } | null>(null);

  useEffect(() => {
    if (!open) return;
    setDone(null);
    setError(null);
    void api.getReviewFormStatus(restaurantId).then((s) => {
      setSt(s);
      if (s.existing) setForm({ ...s.existing });
      else setForm({ rating_overall: 0, content: '' });
    });
  }, [open, restaurantId]);

  const editing = !!st?.existing && st.blocked === 'cooldown';
  const min = st?.min_length ?? 20;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!form.rating_overall) return setError('Scegli una valutazione generale da 1 a 5.');
    if (form.content.trim().length < min) return setError(`La recensione deve avere almeno ${min} caratteri.`);
    setBusy(true);
    try {
      const r = editing ? { ...(await api.updateReview(st!.existing!.id, form)), is_verified: st!.existing!.is_verified } : await api.submitReview(restaurantId, { ...form, reservation_id: st?.verification?.source === 'reservation' ? st.verification.id : null });
      setDone(r);
      onDone();
      toast(r.status === 'published' ? 'Recensione pubblicata' : 'Recensione inviata: sarà pubblicata dopo la verifica dello staff');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const setSub = (k: SubRatingKey, v: number | null) => setForm((f) => ({ ...f, [k]: v }));

  let body;
  if (!st) body = <p className="py-8 text-center text-sm text-ink-muted">Caricamento…</p>;
  else if (!st.authenticated) {
    body = (
      <div className="space-y-4 py-4 text-center">
        <p>Per scrivere una recensione serve un account: le recensioni anonime non sono consentite.</p>
        <Link to={loginHref} className="inline-flex h-11 items-center rounded-full bg-ink px-5 font-semibold text-white">Accedi o registrati</Link>
      </div>
    );
  } else if (st.blocked === 'insider') {
    body = <Alert tone="error">Chi gestisce o lavora in questo ristorante non può recensirlo.</Alert>;
  } else if (st.blocked === 'blocked') {
    body = <Alert tone="error">Il tuo account non può pubblicare recensioni.</Alert>;
  } else if (st.blocked === 'unverified_not_allowed') {
    body = <Alert>Puoi recensire {restaurantName} dopo una visita verificata: prenotazione completata tramite AsiaFood o coupon utilizzato.</Alert>;
  } else if (done) {
    body = (
      <div className="space-y-3 py-4 text-center">
        <p className="text-lg font-bold">Grazie!</p>
        <p className="text-ink-muted">{done.status === 'published' ? 'La tua recensione è pubblicata.' : 'La tua recensione sarà visibile dopo la verifica dello staff.'}</p>
        <Button variant="outline" onClick={onClose}>Chiudi</Button>
      </div>
    );
  } else {
    body = (
      <form onSubmit={submit} className="space-y-5" noValidate>
        {st.verification ? (
          <p className="flex items-start gap-2 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
            <BadgeCheck className="mt-0.5 h-4 w-4 shrink-0" />
            <span><strong>Visita verificata</strong> · {st.verification.source === 'reservation' ? 'prenotazione completata' : st.verification.source === 'order' ? 'ordine completato' : 'coupon utilizzato'} il {formatDate(st.verification.date)}. La recensione mostrerà il badge.</span>
          </p>
        ) : editing ? null : (
          <p className="rounded-2xl bg-cream px-4 py-3 text-sm text-ink-soft">
            Non risulta una visita registrata su AsiaFood: puoi recensire comunque, senza badge “Visita verificata”. La recensione sarà pubblicata dopo un controllo dello staff.
          </p>
        )}
        {editing && <Alert>Hai già recensito questo ristorante: stai modificando la tua recensione (sarà indicata come “Modificata”).</Alert>}
        <p className="text-sm text-ink-muted">La recensione deve riferirsi a un’esperienza reale. Apparirà come <strong>{st.display_name}</strong>: niente email né cognome completo.</p>
        <StarInput name="rating_overall" label="Valutazione generale" required value={form.rating_overall || null} onChange={(v) => setForm((f) => ({ ...f, rating_overall: v ?? 0 }))} />
        <div className="grid gap-4 sm:grid-cols-2">
          {SUB_RATINGS.map((s) => (
            <StarInput key={s.key} name={s.key} label={s.label} optionalHint value={(form[s.key] as number | null | undefined) ?? null} onChange={(v) => setSub(s.key, v)} />
          ))}
        </div>
        <Field label="Titolo (facoltativo)">
          <Input value={form.title ?? ''} maxLength={100} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
        </Field>
        <Field label="La tua recensione" hint={`${form.content.trim().length}/2000 · almeno ${min} caratteri. Niente link, email o numeri di telefono.`}>
          <Textarea value={form.content} maxLength={2000} required onChange={(e) => setForm((f) => ({ ...f, content: e.target.value }))} className="min-h-[140px]" />
        </Field>
        {error && <Alert tone="error">{error}</Alert>}
        <Button type="submit" loading={busy} icon={<MessageSquareQuote className="h-4 w-4" />}>{editing ? 'Salva modifiche' : 'Pubblica recensione'}</Button>
      </form>
    );
  }
  return (
    <Sheet open={open} onClose={onClose} title={`Racconta la tua esperienza da ${restaurantName}`} wide>
      {body}
    </Sheet>
  );
}
