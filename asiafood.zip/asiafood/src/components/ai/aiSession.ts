// Sessione dell'assistente nel browser: ID casuale per scheda (sessionStorage), nessun dato personale.
import { api } from '@/services';
import type { AnalyticsEventType } from '@/types/domain';

const KEY = 'af_ai_session';

export function newSessionId() {
  const bytes = new Uint8Array(18);
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/** Un ID per contesto (generale o singolo ristorante), valido finché la scheda resta aperta. */
export function sessionIdFor(scope: string) {
  const k = `${KEY}:${scope}`;
  try {
    const v = sessionStorage.getItem(k);
    if (v && /^[A-Za-z0-9_-]{16,64}$/.test(v)) return v;
    const id = newSessionId();
    sessionStorage.setItem(k, id);
    return id;
  } catch {
    return newSessionId();
  }
}

export function resetSessionId(scope: string) {
  const id = newSessionId();
  try {
    sessionStorage.setItem(`${KEY}:${scope}`, id);
  } catch {
    /* storage non disponibile: resta in memoria */
  }
  return id;
}

/** Eventi dell'assistente: origine "ai", mai testo dei messaggi né coordinate. */
export function trackAi(type: Extract<AnalyticsEventType, `ai_${string}`>, restaurantId: string | null = null, metadata: Record<string, string | number | boolean> = {}) {
  void api.track(restaurantId, type, 'ai', metadata);
}

/** Richiesta che riguarda la posizione dell'utente (la posizione si invia solo in questi casi). */
export const mentionsNearby = (text: string) => /\b(vicin[oiae]|qui intorno|nei dintorni|intorno a me|dove sono|a piedi|entro \d+|nelle vicinanze|più vicin|piu vicin|zona)\b/i.test(text);
