import { Link, useLocation } from 'react-router-dom';
import { Sparkles } from 'lucide-react';
import { AI, APP } from '@/config/app';
import { cn } from '@/lib/format';

/** Pulsante "Chiedi ad AsiaFood": porta all'assistente, facoltativamente con una domanda già pronta. */
export function AskAiButton({ prompt, className, label, from }: { prompt?: string; className?: string; label?: string; from: string }) {
  if (!AI.enabled) return null;
  const to = prompt ? `/assistant?q=${encodeURIComponent(prompt)}` : '/assistant';
  return (
    <Link
      to={to}
      state={{ from }}
      className={cn(
        'inline-flex h-10 items-center gap-2 rounded-full bg-ink px-4 text-sm font-semibold text-white shadow-card transition hover:bg-ink-soft active:scale-[0.97]',
        className,
      )}
    >
      <Sparkles className="h-4 w-4 text-coral-300" />
      {label ?? `Chiedi ad ${APP.name}`}
    </Link>
  );
}

/** Pulsante flottante (solo mobile, Home ed Esplora): discreto, sopra la barra di navigazione. */
export function AiFab() {
  const { pathname } = useLocation();
  if (!AI.enabled || !(pathname === '/' || pathname === '/restaurants')) return null;
  return (
    <Link
      to="/assistant"
      state={{ from: pathname === '/' ? 'home' : 'explore' }}
      aria-label={`AI Food Assistant: chiedi ad ${APP.name}`}
      className="fixed bottom-[calc(76px+env(safe-area-inset-bottom))] right-4 z-40 inline-flex h-12 items-center gap-2 rounded-full bg-ink pl-3.5 pr-4 text-sm font-semibold text-white shadow-lift transition active:scale-95 md:hidden"
    >
      <Sparkles className="h-5 w-5 text-coral-300" /> Chiedi
    </Link>
  );
}
