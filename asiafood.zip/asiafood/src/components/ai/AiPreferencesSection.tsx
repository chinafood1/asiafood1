import { useEffect, useState } from 'react';
import { Sparkles, Trash2 } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { api } from '@/services';
import { DIETARY_OPTIONS, type AiPreferences } from '@/types/ai';
import { Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Select } from '@/components/ui/Field';
import { useToast } from '@/components/ui/Toast';

const EMPTY: AiPreferences = { favorite_categories: [], preferred_price_range: null, dietary_preferences: [], favorite_cities: [] };

/** Preferenze usate dall'assistente (solo utenti registrati): visibili, modificabili, eliminabili. */
export function AiPreferencesSection() {
  const { categories, cities } = useReferenceData();
  const toast = useToast();
  const [prefs, setPrefs] = useState<AiPreferences>(EMPTY);
  const [stored, setStored] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void api.getAiPreferences().then((p) => {
      if (p) {
        setPrefs({ ...EMPTY, ...p });
        setStored(true);
      }
    }).catch(() => undefined);
  }, []);

  const toggle = (key: 'favorite_categories' | 'dietary_preferences' | 'favorite_cities', v: string) =>
    setPrefs((p) => ({ ...p, [key]: p[key].includes(v) ? p[key].filter((x) => x !== v) : [...p[key], v].slice(0, 10) }));

  const save = async () => {
    setBusy(true);
    try {
      await api.saveAiPreferences(prefs);
      setStored(true);
      toast('Preferenze dell’assistente salvate');
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  const remove = async () => {
    setBusy(true);
    try {
      await api.deleteAiPreferences();
      setPrefs(EMPTY);
      setStored(false);
      toast('Preferenze eliminate');
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card mt-6 p-6" aria-labelledby="ai-prefs">
      <h2 id="ai-prefs" className="flex items-center gap-2 text-lg font-bold">
        <Sparkles className="h-5 w-5 text-coral" /> Preferenze dell’assistente
      </h2>
      <p className="mt-1 text-sm text-ink-muted">
        Facoltative: l’assistente le usa per personalizzare i suggerimenti e te lo dice sempre. Non servono ad addestrare modelli.
      </p>
      <div className="mt-5 space-y-5">
        <div>
          <p className="label">Esigenze alimentari</p>
          <div className="flex flex-wrap gap-2">
            {DIETARY_OPTIONS.map((d) => (
              <Chip key={d.value} active={prefs.dietary_preferences.includes(d.value)} onClick={() => toggle('dietary_preferences', d.value)}>{d.label}</Chip>
            ))}
          </div>
        </div>
        <div>
          <p className="label">Cucine preferite</p>
          <div className="flex flex-wrap gap-2">
            {categories.filter((c) => c.is_active).map((c) => (
              <Chip key={c.slug} active={prefs.favorite_categories.includes(c.slug)} onClick={() => toggle('favorite_categories', c.slug)}>{c.emoji} {c.name}</Chip>
            ))}
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Città preferita" hint="Usata quando non condividi la posizione.">
            <Select value={prefs.favorite_cities[0] ?? ''} onChange={(e) => setPrefs({ ...prefs, favorite_cities: e.target.value ? [e.target.value] : [] })}>
              <option value="">—</option>
              {cities.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Fascia di prezzo preferita">
            <Select value={prefs.preferred_price_range ?? ''} onChange={(e) => setPrefs({ ...prefs, preferred_price_range: e.target.value ? Number(e.target.value) : null })}>
              <option value="">—</option>
              <option value="1">€ · economico</option>
              <option value="2">€€ · medio</option>
              <option value="3">€€€ · alto</option>
              <option value="4">€€€€ · molto alto</option>
            </Select>
          </Field>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => void save()} loading={busy}>Salva preferenze</Button>
          {stored && (
            <Button variant="danger" icon={<Trash2 className="h-4 w-4" />} onClick={() => void remove()} disabled={busy}>
              Elimina preferenze
            </Button>
          )}
        </div>
      </div>
    </section>
  );
}
