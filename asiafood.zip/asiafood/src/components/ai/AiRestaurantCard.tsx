import { Link } from 'react-router-dom';
import { CalendarCheck, Infinity as InfinityIcon, MapPin, Navigation, Tag } from 'lucide-react';
import { Badge, DemoBadge, SponsoredBadge } from '@/components/ui/Badge';
import { SmartImage } from '@/components/ui/SmartImage';
import { cn, formatDistance, formatPrice } from '@/lib/format';
import { directionsUrl } from '@/lib/geo';
import type { AiRestaurant, OpenStatus } from '@/types/ai';
import { trackAi } from './aiSession';

export function OpenChip({ status }: { status: OpenStatus }) {
  if (status === 'open') return <Badge tone="green">Aperto</Badge>;
  if (status === 'closed') return <Badge tone="neutral">Chiuso</Badge>;
  return <Badge tone="outline">Orari non disponibili</Badge>;
}

export interface BookingPrefill {
  date: string;
  time: string | null;
  party_size: number;
}

export function bookingHref(slug: string, b: BookingPrefill | null | undefined, slot?: string) {
  const p = new URLSearchParams({ src: 'ai' });
  if (b?.date) p.set('date', b.date);
  const t = slot ?? b?.time;
  if (t) p.set('time', t);
  if (b?.party_size) p.set('party', String(b.party_size));
  return `/ristorante/${slug}/prenota?${p.toString()}`;
}

/**
 * Scheda reale di un ristorante nei risultati dell'assistente: i dati arrivano dal database
 * (il modello restituisce solo ID). Le azioni compaiono solo se disponibili.
 */
export function AiRestaurantCard({ r, booking, sponsored, campaignId }: { r: AiRestaurant; booking?: BookingPrefill | null; sponsored?: boolean; campaignId?: string }) {
  const cats = r.categories.filter((c) => c !== 'All You Can Eat').slice(0, 2);
  const ayce = r.is_all_you_can_eat;
  const price = r.price_per_person;
  const canDirections = r.latitude != null && r.longitude != null;
  const onOpen = () => trackAi('ai_result_click', r.id, { position: 0, ...(sponsored ? { sponsored: true } : {}), ...(campaignId ? { campaign: campaignId.slice(0, 8) } : {}) });
  return (
    <article className="flex w-[78vw] max-w-[300px] shrink-0 snap-start flex-col overflow-hidden rounded-3xl border border-line bg-white shadow-card sm:w-[280px]" aria-label={r.name}>
      <Link to={`/ristorante/${r.slug}`} state={{ source: 'ai' }} onClick={onOpen} className="relative block">
        <SmartImage src={r.cover_url} alt={r.name} seed={r.id} emoji="🥢" className="aspect-[16/9] w-full" />
        <div className="absolute left-2.5 top-2.5 flex flex-wrap gap-1">
          {sponsored && <SponsoredBadge glass />}
          {r.is_demo && <DemoBadge glass />}
        </div>
        <div className="absolute bottom-2.5 right-2.5">
          <OpenChip status={r.open_status} />
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div>
          <h3 className="truncate text-base font-bold">
            <Link to={`/ristorante/${r.slug}`} state={{ source: 'ai' }} onClick={onOpen} className="hover:underline">
              {r.name}
            </Link>
          </h3>
          <p className="truncate text-sm text-ink-muted">{[...cats, r.city].filter(Boolean).join(' · ')}</p>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 text-[13px] font-medium text-ink-soft">
          {r.distance_km != null && (
            <span className="inline-flex items-center gap-1 rounded-full bg-cream px-2 py-0.5 font-semibold text-ink">
              <MapPin className="h-3.5 w-3.5" /> {formatDistance(r.distance_km)}
            </span>
          )}
          {price != null ? (
            <span className="rounded-full bg-cream px-2 py-0.5">~{formatPrice(price, true)} a persona</span>
          ) : (
            <span className="rounded-full bg-cream px-2 py-0.5 text-ink-muted">Prezzo non indicato</span>
          )}
          {ayce && (
            <span className="inline-flex items-center gap-1 rounded-full bg-coral-50 px-2 py-0.5 text-coral-700">
              <InfinityIcon className="h-3.5 w-3.5" /> AYCE
            </span>
          )}
          {r.order_online && (
            <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-emerald-800">
              {r.order_online.order_now ? 'Ordina ora' : 'Ordini online'} · {[r.order_online.delivery && 'consegna', r.order_online.takeaway && 'ritiro'].filter(Boolean).join(' e ')}
            </span>
          )}
        </div>
        {r.offer && (
          <p className="flex items-start gap-1.5 text-[13px] font-medium text-emerald-700">
            <Tag className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <span className="line-clamp-2">{r.offer.title}</span>
          </p>
        )}
        {r.available_slots?.length ? (
          <div className="flex flex-wrap gap-1.5" aria-label="Orari liberi verificati">
            {r.available_slots.slice(0, 4).map((t) => (
              <Link
                key={t}
                to={bookingHref(r.slug, booking, t)}
                state={{ source: 'ai' }}
                onClick={() => trackAi('ai_reservation_click', r.id, { slot: t })}
                className="rounded-full border border-line px-2.5 py-1 text-xs font-semibold hover:border-ink"
              >
                {t}
              </Link>
            ))}
          </div>
        ) : null}
        <div className="mt-auto flex flex-wrap gap-1.5 pt-1">
          <Link
            to={`/ristorante/${r.slug}`}
            state={{ source: 'ai' }}
            onClick={onOpen}
            className="inline-flex h-9 items-center rounded-full bg-ink px-3.5 text-sm font-semibold text-white"
          >
            Vedi ristorante
          </Link>
          {canDirections && (
            <a
              href={directionsUrl({ latitude: r.latitude, longitude: r.longitude, name: r.name })}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => {
                trackAi('ai_result_click', r.id, { action: 'directions' });
              }}
              className="inline-flex h-9 items-center gap-1 rounded-full border border-line px-3 text-sm font-semibold hover:border-ink"
              aria-label={`Indicazioni per ${r.name}`}
            >
              <Navigation className="h-3.5 w-3.5" /> Indicazioni
            </a>
          )}
          {r.order_online && (
            <Link
              to={`/ristorante/${r.slug}#ordina`}
              state={{ source: 'ai' }}
              onClick={() => trackAi('ai_result_click', r.id, { action: 'order' })}
              className="inline-flex h-9 items-center rounded-full border border-coral px-3 text-sm font-semibold text-coral-700 hover:bg-coral-50"
            >
              Ordina
            </Link>
          )}
          {r.reservations_online && (
            <Link
              to={bookingHref(r.slug, booking, r.available_slots?.[0])}
              state={{ source: 'ai' }}
              onClick={() => trackAi('ai_reservation_click', r.id)}
              className={cn('inline-flex h-9 items-center gap-1 rounded-full bg-coral px-3 text-sm font-semibold text-white')}
            >
              <CalendarCheck className="h-3.5 w-3.5" /> Prenota
            </Link>
          )}
        </div>
      </div>
    </article>
  );
}

export function MapLink({ ids }: { ids: string[] }) {
  if (!ids.length) return null;
  return (
    <Link
      to={`/map?ids=${ids.join(',')}`}
      onClick={() => trackAi('ai_map_open', null, { count: ids.length })}
      className="inline-flex h-9 items-center gap-1.5 rounded-full border border-line bg-white px-3.5 text-sm font-semibold hover:border-ink"
    >
      <MapPin className="h-4 w-4" /> Mostra sulla mappa
    </Link>
  );
}
