import { useCallback, useEffect, useRef, useState, type FormEvent, type KeyboardEvent, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, ArrowUp, Info, Leaf, LocateFixed, RotateCcw, Search, Sparkles, Tag, Ticket, Trash2, WifiOff } from 'lucide-react';
import { useGeolocation } from '@/hooks/useGeolocation';
import { cn, formatPrice } from '@/lib/format';
import { api, isDemoMode } from '@/services';
import { AiError, type AiCoupon, type AiMenuItem, type AiOffer, type AiResponse, type AiRestaurantDetail } from '@/types/ai';
import { AiRestaurantCard, MapLink, OpenChip } from './AiRestaurantCard';
import { mentionsNearby, resetSessionId, sessionIdFor, trackAi } from './aiSession';

export const QUICK_PROMPTS = [
  { emoji: '🍣', label: 'Sushi vicino a me', prompt: 'Sushi vicino a me' },
  { emoji: '🥢', label: 'AYCE sotto 25 €', prompt: 'All you can eat sotto 25 €' },
  { emoji: '🍜', label: 'Dove mangiare ramen?', prompt: 'Dove mangiare ramen?' },
  { emoji: '🔥', label: 'Offerte di stasera', prompt: 'Offerte di stasera' },
  { emoji: '🌱', label: 'Opzioni vegetariane', prompt: 'Opzioni vegetariane' },
  { emoji: '📍', label: 'Ristoranti aperti ora', prompt: 'Ristoranti aperti ora' },
];

const RESTAURANT_PROMPTS = [
  { label: 'È aperto ora?', prompt: 'È aperto ora?' },
  { label: 'Quanto costa?', prompt: 'Quanto costa mangiare qui?' },
  { label: 'Piatti vegetariani', prompt: 'Quali piatti vegetariani avete?' },
  { label: 'Posto stasera per 2', prompt: 'Avete posto stasera per 2?' },
];

type Msg =
  | { id: number; role: 'user'; text: string }
  | { id: number; role: 'assistant'; response: AiResponse }
  | { id: number; role: 'error'; text: string; code: string; retry?: string }
  | { id: number; role: 'history'; from: 'user' | 'assistant'; text: string };

const MAX_LEN = 500;
const OFFLINE_TEXT = 'L’assistente richiede una connessione internet.';

function useOnline() {
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  return online;
}

/**
 * Chat dell'assistente. Nessun HTML dal modello: testo semplice + schede renderizzate
 * dall'app a partire dagli ID restituiti dal server.
 */
export function AssistantChat({
  restaurantId,
  restaurantName,
  initialPrompt,
  compact,
}: {
  restaurantId?: string | null;
  restaurantName?: string;
  initialPrompt?: string | null;
  compact?: boolean;
}) {
  const scope = restaurantId ? `r:${restaurantId}` : 'main';
  const [sessionId, setSessionId] = useState(() => sessionIdFor(scope));
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [lastNear, setLastNear] = useState(false);
  const online = useOnline();
  const geo = useGeolocation('assistant');
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const idRef = useRef(0);
  const nextId = () => ++idRef.current;

  useEffect(() => {
    trackAi('ai_chat_open', restaurantId ?? null, { context: restaurantId ? 'restaurant' : 'main' });
  }, [restaurantId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, sending]);

  useEffect(() => () => abortRef.current?.abort(), []);

  // Dopo un ricaricamento della pagina: ultimi messaggi della conversazione (solo testo; le schede si rigenerano chiedendo)
  useEffect(() => {
    if (initialPrompt) return;
    let alive = true;
    void api.aiHistory(sessionId, restaurantId ?? null).then(
      (h) => {
        if (!alive || !h.length) return;
        setMessages((m) => (m.length ? m : h.map((x) => ({ id: nextId(), role: 'history' as const, from: x.role, text: x.content }))));
      },
      () => undefined,
    );
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId]);

  const send = useCallback(
    async (raw: string, opts: { withLocation?: { lat: number; lng: number } | null; denied?: boolean } = {}) => {
      const msg = raw.trim().slice(0, MAX_LEN);
      if (msg.length < 2 || sending) return;
      if (!online) {
        setMessages((m) => [...m, { id: nextId(), role: 'error', text: OFFLINE_TEXT, code: 'OFFLINE', retry: msg }]);
        setText(msg);
        return;
      }
      setMessages((m) => [...m.filter((x) => x.role !== 'error'), { id: nextId(), role: 'user', text: msg }]);
      setText('');
      setSending(true);
      const wantsLoc = mentionsNearby(msg) || lastNear;
      const location = opts.withLocation ?? (wantsLoc && geo.status === 'granted' ? geo.coords : null);
      const ctrl = new AbortController();
      abortRef.current = ctrl;
      trackAi('ai_message_sent', restaurantId ?? null, { context: restaurantId ? 'restaurant' : 'main', length: Math.min(msg.length, 500) });
      try {
        const { response } = await api.aiChat(
          { session_id: sessionId, message: msg, restaurant_id: restaurantId ?? null, location, location_denied: opts.denied ?? geo.status === 'denied' },
          ctrl.signal,
        );
        setLastNear(!!response.filters.near_me);
        setMessages((m) => [...m, { id: nextId(), role: 'assistant', response }]);
        const empty = !response.restaurants.length && !response.offers.length && !response.coupons.length && !response.comparison?.length && !response.needs_location && response.intent !== 'general_food_question' && response.intent !== 'menu_question';
        if (empty) trackAi('ai_no_results', restaurantId ?? null, { intent: response.intent });
      } catch (e) {
        if (ctrl.signal.aborted && !(e instanceof AiError && e.code === 'TIMEOUT')) return;
        const err = e instanceof AiError ? e : new AiError('AI_ERROR', 'L’assistente non è disponibile in questo momento. Puoi continuare a usare la ricerca.');
        const text =
          err.code === 'TIMEOUT'
            ? 'La risposta sta impiegando troppo tempo. Il tuo messaggio non è andato perso: puoi riprovare.'
            : err.code === 'OFFLINE'
              ? OFFLINE_TEXT
              : err.message;
        const retriable = ['TIMEOUT', 'NETWORK', 'AI_ERROR', 'OFFLINE', 'HTTP_502', 'HTTP_503', 'HTTP_504'].includes(err.code) || err.status >= 500;
        setMessages((m) => [...m, { id: nextId(), role: 'error', text, code: err.code, retry: retriable ? msg : undefined }]);
        // Il testo resta nel campo: niente da riscrivere
        if (retriable || err.code === 'TOO_LONG') setText(msg);
      } finally {
        setSending(false);
        abortRef.current = null;
      }
    },
    [sending, online, sessionId, restaurantId, geo.status, geo.coords, lastNear],
  );

  // Prompt iniziale (da un pulsante "Chiedi…" o da /assistant?q=)
  const started = useRef(false);
  useEffect(() => {
    if (initialPrompt && !started.current) {
      started.current = true;
      void send(initialPrompt);
    }
  }, [initialPrompt, send]);

  const locateAndRetry = async (retryText: string) => {
    const c = geo.coords ?? (await geo.request());
    if (c) void send(retryText, { withLocation: c });
    else void send(retryText, { denied: true });
  };

  const newConversation = async () => {
    abortRef.current?.abort();
    try {
      await api.aiDeleteSession(sessionId);
    } catch {
      /* la conversazione scade comunque */
    }
    setSessionId(resetSessionId(scope));
    setMessages([]);
    setLastNear(false);
    setText('');
    inputRef.current?.focus();
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    void send(text);
  };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      void send(text);
    }
  };

  const lastUserText = [...messages].reverse().find((m) => m.role === 'user') as Extract<Msg, { role: 'user' }> | undefined;
  const prompts = restaurantId ? RESTAURANT_PROMPTS : QUICK_PROMPTS.map((q) => ({ label: `${q.emoji} ${q.label}`, prompt: q.prompt }));

  return (
    <div className={cn('flex min-h-0 flex-1 flex-col', compact && 'h-[70dvh] sm:h-[60vh]')}>
      {!online && (
        <p className="mx-4 mt-3 flex items-center gap-2 rounded-2xl bg-amber-50 px-4 py-2.5 text-sm font-medium text-amber-900" role="status">
          <WifiOff className="h-4 w-4 shrink-0" /> {OFFLINE_TEXT} La ricerca dei ristoranti già caricati resta disponibile.
        </p>
      )}

      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 pb-4 pt-4" role="log" aria-live="polite" aria-relevant="additions" aria-label="Conversazione con l’assistente">
        {messages.length === 0 && (
          <div className="mx-auto max-w-xl py-6 text-center">
            <span className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-coral-50 text-coral-700">
              <Sparkles className="h-6 w-6" />
            </span>
            <p className="text-lg font-bold">{restaurantId ? `Chiedimi di ${restaurantName ?? 'questo ristorante'}` : 'Dimmi cosa hai voglia di mangiare.'}</p>
            <p className="mt-1 text-sm text-ink-muted">
              {restaurantId
                ? 'Orari, prezzi, menu, offerte e posti liberi: rispondo solo con i dati pubblicati.'
                : 'Cerco tra i ristoranti, i menu e le offerte pubblicati: niente informazioni inventate.'}
            </p>
            <div className="mt-5 flex flex-wrap justify-center gap-2">
              {prompts.map((p) => (
                <button
                  key={p.prompt}
                  type="button"
                  onClick={() => void send(p.prompt)}
                  className="rounded-full border border-line bg-white px-3.5 py-2 text-sm font-medium transition hover:border-ink"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <ol className="mx-auto flex max-w-3xl flex-col gap-4">
          {messages.map((m) => (
            <li key={m.id}>
              {m.role === 'history' && (
                <div className={cn('w-fit max-w-[85%] rounded-3xl px-4 py-2.5 text-[15px] opacity-80', m.from === 'user' ? 'ml-auto rounded-br-lg bg-ink text-white' : 'rounded-bl-lg bg-white shadow-card')}>
                  <span className="sr-only">{m.from === 'user' ? 'Tu (in precedenza): ' : 'Assistente (in precedenza): '}</span>
                  {m.text}
                </div>
              )}
              {m.role === 'user' && (
                <div className="ml-auto w-fit max-w-[85%] rounded-3xl rounded-br-lg bg-ink px-4 py-2.5 text-[15px] text-white">
                  <span className="sr-only">Tu: </span>
                  {m.text}
                </div>
              )}
              {m.role === 'assistant' && <AssistantReply contextId={restaurantId ?? null} r={m.response} onPrompt={(p) => void send(p)} onLocate={() => lastUserText && void locateAndRetry(lastUserText.text)} geoDenied={geo.status === 'denied'} />}
              {m.role === 'error' && (
                <div className="flex max-w-[90%] flex-col gap-2 rounded-3xl rounded-bl-lg border border-coral-200 bg-coral-50 px-4 py-3 text-[15px] text-coral-800" role="alert">
                  <p className="flex items-start gap-2">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /> {m.text}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {m.retry && (
                      <button type="button" onClick={() => void send(m.retry!)} className="inline-flex h-9 items-center gap-1.5 rounded-full bg-ink px-4 text-sm font-semibold text-white">
                        <RotateCcw className="h-4 w-4" /> Riprova
                      </button>
                    )}
                    <Link to="/restaurants" className="inline-flex h-9 items-center gap-1.5 rounded-full border border-coral-200 bg-white px-4 text-sm font-semibold text-ink">
                      <Search className="h-4 w-4" /> Usa la ricerca
                    </Link>
                  </div>
                </div>
              )}
            </li>
          ))}
          {sending && (
            <li className="flex items-center gap-2 text-sm font-medium text-ink-muted" role="status">
              <span className="flex gap-1" aria-hidden>
                <span className="h-2 w-2 animate-bounce rounded-full bg-coral [animation-delay:-0.2s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-coral [animation-delay:-0.1s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-coral" />
              </span>
              Sto cercando tra i ristoranti disponibili…
            </li>
          )}
        </ol>
        <div ref={endRef} />
      </div>

      <form onSubmit={submit} className="border-t border-line bg-paper/95 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-end gap-2">
          <label htmlFor={`ai-input-${scope}`} className="sr-only">
            Scrivi la tua richiesta
          </label>
          <textarea
            id={`ai-input-${scope}`}
            ref={inputRef}
            value={text}
            onChange={(e) => setText(e.target.value.slice(0, MAX_LEN))}
            onKeyDown={onKey}
            rows={1}
            maxLength={MAX_LEN}
            enterKeyHint="send"
            placeholder={restaurantId ? 'Es. Avete opzioni senza glutine?' : 'Es. Sushi AYCE sotto 25 € vicino a me…'}
            className="max-h-32 min-h-[48px] flex-1 resize-none rounded-3xl border border-line bg-white px-4 py-3 text-[16px] leading-snug outline-none transition placeholder:text-[14px] focus:border-ink sm:placeholder:text-[16px]"
          />
          <button
            type="submit"
            disabled={sending || text.trim().length < 2}
            className="mb-0.5 inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-coral text-white transition disabled:opacity-40"
            aria-label="Invia"
          >
            <ArrowUp className="h-5 w-5" />
          </button>
        </div>
        <div className="mx-auto mt-1.5 flex max-w-3xl items-start justify-between gap-3 px-1 text-[11px] text-ink-faint">
          <p>
            {isDemoMode ? 'Modalità DEMO: risposte calcolate dai dati di prova, senza modello AI. ' : 'Risposte basate sui dati pubblicati su AsiaFood: verifica sempre con il locale. '}
            <Link to="/restaurants" className="underline">Ricerca classica</Link>
          </p>
          {messages.length > 0 && (
            <button type="button" onClick={() => void newConversation()} className="inline-flex shrink-0 items-center gap-1 font-semibold text-ink-muted hover:text-ink" title="Elimina questa conversazione e ricomincia">
              <Trash2 className="h-3.5 w-3.5" /> Nuova conversazione
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

function AssistantReply({ r, onPrompt, onLocate, geoDenied, contextId }: { r: AiResponse; onPrompt: (p: string) => void; onLocate: () => void; geoDenied: boolean; contextId: string | null }) {
  // Nella scheda di un ristorante non si ripete la sua card (salvo orari liberi da prenotare)
  const cards = r.restaurants.filter((x) => x.id !== contextId || !!x.available_slots?.length);
  const mapIds = contextId ? [] : r.actions.map_ids ?? [];
  const sponsoredSeen = useRef(false);
  useEffect(() => {
    if (sponsoredSeen.current) return;
    sponsoredSeen.current = true;
    r.sponsored.forEach((s) => api.trackSponsored(s.campaign_id, 'sponsored_impression', 'search_top'));
  }, [r.sponsored]);

  return (
    <div className="flex flex-col gap-3">
      <div className="max-w-[92%] rounded-3xl rounded-bl-lg bg-white px-4 py-3 text-[15px] leading-relaxed shadow-card">
        <span className="sr-only">Assistente: </span>
        <p className="whitespace-pre-line">{r.message}</p>
        {r.date_label && r.filters.date && <p className="mt-1 text-xs font-medium text-ink-muted">Data considerata: {r.date_label}{r.filters.time ? `, ore ${r.filters.time}` : ''}</p>}
      </div>

      {r.needs_location && !geoDenied && (
        <button type="button" onClick={onLocate} className="inline-flex h-10 w-fit items-center gap-2 rounded-full bg-ink px-4 text-sm font-semibold text-white">
          <LocateFixed className="h-4 w-4" /> Usa la mia posizione
        </button>
      )}

      {cards.length > 0 && (
        <div className="-mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-1 scrollbar-none" role="list" aria-label="Ristoranti suggeriti">
          {cards.map((x) => (
            <div role="listitem" key={x.id} className="contents">
              <AiRestaurantCard r={x} booking={r.actions.booking} />
            </div>
          ))}
        </div>
      )}

      {r.comparison && r.comparison.length >= 2 && <ComparisonTable rows={r.comparison} />}

      {r.menu_items.length > 0 && <MenuList items={r.menu_items} />}

      {(r.offers.length > 0 || r.coupons.length > 0) && <OffersList offers={r.offers} coupons={r.coupons} />}

      {r.notices.length > 0 && (
        <ul className="flex max-w-[92%] flex-col gap-1.5">
          {r.notices.map((n) => (
            <li key={n} className="flex items-start gap-2 text-[13px] text-ink-muted">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {n}
            </li>
          ))}
        </ul>
      )}

      {r.sponsored.length > 0 && (
        <section aria-label="Sponsorizzato" className="rounded-3xl border border-dashed border-line p-3">
          <p className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-ink-muted">Sponsorizzato</p>
          <div className="flex gap-3 overflow-x-auto scrollbar-none">
            {r.sponsored.map((s) => (
              <div key={s.campaign_id} onClickCapture={() => api.trackSponsored(s.campaign_id, 'sponsored_click', 'search_top')}>
                <AiRestaurantCard r={s.restaurant} sponsored campaignId={s.campaign_id} booking={r.actions.booking} />
              </div>
            ))}
          </div>
        </section>
      )}

      {(mapIds.length > 0 || r.follow_ups.length > 0) && (
        <div className="flex flex-wrap gap-2">
          <MapLink ids={mapIds} />
          {r.follow_ups
            .filter((f) => !(mapIds.length && /mappa/i.test(f.label)))
            .map((f) => (
              <button key={f.label} type="button" onClick={() => onPrompt(f.prompt)} className="h-9 rounded-full bg-cream px-3.5 text-sm font-medium transition hover:bg-line">
                {f.label}
              </button>
            ))}
        </div>
      )}
    </div>
  );
}

const DAY = ['', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];

function ComparisonTable({ rows }: { rows: AiRestaurantDetail[] }) {
  const price = (d: AiRestaurantDetail) =>
    d.is_all_you_can_eat && (d.ayce_dinner_price ?? d.ayce_lunch_price) != null
      ? `AYCE ${formatPrice(d.ayce_dinner_price ?? d.ayce_lunch_price)}`
      : d.average_price != null
        ? `~${formatPrice(d.average_price, true)} a persona`
        : 'Non indicato';
  const yes = (b: boolean) => (b ? 'Sì' : 'No');
  const lines: [string, (d: AiRestaurantDetail) => ReactNode][] = [
    ['Prezzo', price],
    ['Stato', (d) => <OpenChip status={d.open_status} />],
    ['Prenotazione online', (d) => yes(d.reservations_online)],
    ['Consegna / asporto', (d) => `${yes(d.has_delivery)} / ${yes(d.has_takeaway)}`],
    ['Piatti vegetariani', (d) => (d.menu_summary.items ? String(d.menu_summary.vegetarian) : 'Menu non pubblicato')],
    ['Offerte attive', (d) => yes(d.has_offers)],
    ['Giorni di apertura', (d) => (d.hours.length ? [...new Set(d.hours.filter((h) => !h.is_closed).map((h) => h.day))].map((x) => DAY[x]).join(' ') : 'Orari non disponibili')],
  ];
  return (
    <div className="max-w-full overflow-x-auto rounded-3xl border border-line bg-white">
      <table className="w-full min-w-[420px] text-left text-sm">
        <caption className="sr-only">Confronto basato sui dati pubblicati</caption>
        <thead>
          <tr className="border-b border-line">
            <th scope="col" className="px-4 py-2.5 font-semibold text-ink-muted">Dato</th>
            {rows.map((d) => (
              <th key={d.id} scope="col" className="px-4 py-2.5 font-bold">
                <Link to={`/ristorante/${d.slug}`} state={{ source: 'ai' }} onClick={() => trackAi('ai_result_click', d.id, { action: 'compare' })} className="hover:underline">
                  {d.name}
                </Link>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {lines.map(([label, fn]) => (
            <tr key={label} className="border-b border-line last:border-0">
              <th scope="row" className="px-4 py-2 font-medium text-ink-muted">{label}</th>
              {rows.map((d) => (
                <td key={d.id} className="px-4 py-2">{fn(d)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function MenuList({ items }: { items: AiMenuItem[] }) {
  return (
    <div className="max-w-xl rounded-3xl border border-line bg-white p-2">
      <p className="px-3 pb-1 pt-2 text-xs font-semibold uppercase tracking-wider text-ink-muted">Dai menu pubblicati</p>
      <ul>
        {items.map((i) => {
          const p = i.discount_price ?? i.price;
          return (
            <li key={i.id} className="flex items-start justify-between gap-3 rounded-2xl px-3 py-2 hover:bg-cream">
              <div className="min-w-0">
                <p className="font-semibold">
                  {i.name}
                  {(i.is_vegan || i.is_vegetarian) && <Leaf className="ml-1 inline h-3.5 w-3.5 text-emerald-600" aria-label={i.is_vegan ? 'vegano' : 'vegetariano'} />}
                  {i.is_gluten_free && <span className="ml-1 rounded bg-cream px-1 text-[10px] font-bold text-ink-soft">GF</span>}
                </p>
                <Link to={`/ristorante/${i.restaurant.slug}#menu`} state={{ source: 'ai' }} onClick={() => trackAi('ai_result_click', i.restaurant.id, { action: 'menu' })} className="text-[13px] text-ink-muted hover:underline">
                  {i.restaurant.name}
                  {i.restaurant.city ? ` · ${i.restaurant.city}` : ''}
                </Link>
              </div>
              {p != null && <span className="shrink-0 text-sm font-semibold">{formatPrice(p)}</span>}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function OffersList({ offers, coupons }: { offers: AiOffer[]; coupons: AiCoupon[] }) {
  const cond = (o: { minimum_spend: number | null }) => (o.minimum_spend != null ? ` · spesa minima ${formatPrice(o.minimum_spend)}` : '');
  return (
    <div className="flex max-w-xl flex-col gap-2">
      {offers.map((o) => (
        <div key={o.id} className="rounded-3xl border border-line bg-white p-4">
          <p className="flex items-center gap-1.5 font-semibold">
            <Tag className="h-4 w-4 text-coral" /> {o.title}
          </p>
          <p className="mt-0.5 text-[13px] text-ink-muted">
            {o.restaurant.name}
            {o.start_time && o.end_time ? ` · dalle ${o.start_time} alle ${o.end_time}` : ''}
            {cond(o)}
          </p>
          {o.terms && <p className="mt-1 text-xs text-ink-faint">{o.terms}</p>}
          <Link to={`/ristorante/${o.restaurant.slug}#offerte`} state={{ source: 'ai' }} onClick={() => trackAi('ai_offer_click', o.restaurant.id, { kind: 'offer' })} className="mt-2 inline-flex h-9 items-center rounded-full border border-line px-3.5 text-sm font-semibold hover:border-ink">
            Vedi offerta
          </Link>
        </div>
      ))}
      {coupons.map((c) => (
        <div key={c.id} className="rounded-3xl border border-emerald-200 bg-emerald-50/50 p-4">
          <p className="flex items-center gap-1.5 font-semibold">
            <Ticket className="h-4 w-4 text-emerald-700" /> {c.title}
          </p>
          <p className="mt-0.5 text-[13px] text-ink-muted">
            {c.restaurant.name}
            {cond(c)}
            {c.valid_until ? ` · valido fino al ${new Date(c.valid_until).toLocaleDateString('it-IT', { day: 'numeric', month: 'long' })}` : ''}
          </p>
          <Link to={`/ristorante/${c.restaurant.slug}#offerte`} state={{ source: 'ai' }} onClick={() => trackAi('ai_offer_click', c.restaurant.id, { kind: 'coupon' })} className="mt-2 inline-flex h-9 items-center rounded-full bg-emerald-700 px-3.5 text-sm font-semibold text-white">
            Ottieni coupon
          </Link>
        </div>
      ))}
    </div>
  );
}
