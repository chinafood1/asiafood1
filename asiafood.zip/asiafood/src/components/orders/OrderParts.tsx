import { Link, useLocation } from 'react-router-dom';
import { Bike, Check, Clock, PauseCircle, ShoppingBag, Store } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useOrderable } from '@/hooks/useOrderable';
import { cn, formatPrice } from '@/lib/format';
import type { OrderPublicInfo, OrderStatus, OrderView, PaymentStatus, Quote } from '@/types/orders';
import { ORDER_STATUS_LABEL, PAYMENT_STATUS_LABEL } from '@/types/orders';
import { Badge } from '@/components/ui/Badge';

export const timeOf = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleTimeString('it-IT', { timeZone: 'Europe/Rome', hour: '2-digit', minute: '2-digit' }) : '';
export const dayTimeOf = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleString('it-IT', { timeZone: 'Europe/Rome', weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';

const STATUS_TONE: Partial<Record<OrderStatus, 'neutral' | 'green' | 'amber' | 'coral' | 'dark'>> = {
  pending_payment: 'amber', pending_restaurant: 'amber', accepted: 'green', preparing: 'green', ready: 'green', out_for_delivery: 'green',
  completed: 'dark', rejected: 'coral', cancelled: 'coral', refunded: 'neutral', partially_refunded: 'neutral',
};
export function OrderStatusBadge({ status }: { status: OrderStatus }) {
  return <Badge tone={STATUS_TONE[status] ?? 'neutral'}>{ORDER_STATUS_LABEL[status]}</Badge>;
}
export function PaymentBadge({ status }: { status: PaymentStatus }) {
  return <Badge tone={status === 'paid' ? 'green' : status === 'failed' ? 'coral' : 'neutral'}>{PAYMENT_STATUS_LABEL[status]}</Badge>;
}

/** Riepilogo importi (sempre dal server). */
export function PriceSummary({ q, deliveryPending }: { q: Pick<Quote, 'subtotal' | 'coupon_discount' | 'loyalty_discount' | 'delivery_fee' | 'service_fee' | 'total' | 'order_type'>; deliveryPending?: boolean }) {
  const row = (label: string, v: number | undefined, opts: { neg?: boolean; bold?: boolean; hint?: string } = {}) => (
    <div className={cn('flex justify-between gap-3', opts.bold && 'border-t border-line pt-2 text-base font-bold')}>
      <dt className={opts.bold ? '' : 'text-ink-muted'}>{label}{opts.hint && <span className="block text-xs font-normal text-ink-faint">{opts.hint}</span>}</dt>
      <dd className="tabular-nums">{opts.neg ? '−' : ''}{formatPrice(v ?? 0)}</dd>
    </div>
  );
  return (
    <dl className="space-y-1.5 text-sm" data-testid="price-summary">
      {row('Subtotale', q.subtotal)}
      {(q.coupon_discount ?? 0) > 0 && row('Sconto coupon', q.coupon_discount, { neg: true })}
      {(q.loyalty_discount ?? 0) > 0 && row('Premio AsiaPoints', q.loyalty_discount, { neg: true })}
      {q.order_type === 'delivery' && (deliveryPending ? (
        <div className="flex justify-between gap-3"><dt className="text-ink-muted">Consegna</dt><dd className="text-ink-faint">calcolata con l’indirizzo</dd></div>
      ) : row('Consegna', q.delivery_fee))}
      {(q.service_fee ?? 0) > 0 && row('Costo di servizio', q.service_fee, { hint: 'Trattenuto da AsiaFood per il servizio' })}
      {row('Totale', q.total, { bold: true })}
    </dl>
  );
}

/** Stato ordini online nella scheda ristorante. */
export function OrderPanel({ info, onBrowse }: { info: OrderPublicInfo; onBrowse: () => void }) {
  if (!info.enabled) return null;
  const paused = !!info.paused_until;
  const next = info.takeaway?.next_slot ?? info.delivery?.next_slot;
  const state = !info.payments_ready ? 'Ordini online in arrivo: il ristorante sta attivando i pagamenti.'
    : paused ? 'Ordini momentaneamente in pausa.'
      : info.open_now ? `Aperto · pronto in circa ${info.preparation_minutes} min${info.busy ? ' (molto richiesto ora)' : ''}`
        : next && info.allow_scheduled ? `Chiuso · puoi programmare l’ordine${next.date && next.date !== new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome' }).format(new Date()) ? ` per ${new Date(next.at).toLocaleDateString('it-IT', { timeZone: 'Europe/Rome', weekday: 'long' })} alle` : ' per le'} ${next.time}`
          : 'Chiuso in questo momento.';
  return (
    <div className="rounded-4xl border border-line bg-white p-5 sm:p-6" data-testid="order-panel">
      <div className="flex flex-wrap items-start gap-4">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-coral-50 text-coral-700"><ShoppingBag className="h-6 w-6" /></span>
        <div className="min-w-0 flex-1">
          <h2 className="text-xl font-bold">Ordina online</h2>
          <p className={cn('mt-0.5 flex items-center gap-1.5 text-sm font-medium', info.open_now && !paused ? 'text-emerald-700' : 'text-ink-muted')}>
            {paused ? <PauseCircle className="h-4 w-4" /> : <Clock className="h-4 w-4" />} {state}
          </p>
          <div className="mt-3 flex flex-wrap gap-2 text-sm">
            {info.takeaway?.enabled && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-cream px-3 py-1.5"><Store className="h-4 w-4" /> Ritiro {info.takeaway.state === 'paused' ? '(in pausa)' : ''} · minimo {formatPrice(info.takeaway.minimum_order)}</span>
            )}
            {info.delivery?.enabled && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-cream px-3 py-1.5">
                <Bike className="h-4 w-4" /> Consegna {info.delivery.state === 'paused' ? '(in pausa)' : ''} · minimo {formatPrice(info.delivery.minimum_order)}
                {info.delivery.zones.length > 0 ? ` · ${formatPrice(Math.min(...info.delivery.zones.map((z) => z.fee)))}–${formatPrice(Math.max(...info.delivery.zones.map((z) => z.fee)))}` : info.delivery.fee_type === 'free' ? ' · gratuita' : ` · ${formatPrice(info.delivery.fee)}`}
              </span>
            )}
          </div>
          {info.delivery?.enabled && info.delivery.zones.length > 0 && (
            <p className="mt-2 text-xs text-ink-muted">
              Consegna gestita dal ristorante: {info.delivery.zones.map((z) => `${z.min_km}–${z.max_km} km ${formatPrice(z.fee)}`).join(' · ')}
              {info.delivery.free_threshold != null && ` · gratuita da ${formatPrice(info.delivery.free_threshold)}`}
            </p>
          )}
          {(info.service_fee ?? 0) > 0 && <p className="mt-1 text-xs text-ink-muted">Costo di servizio AsiaFood: {formatPrice(info.service_fee)} per ordine.</p>}
        </div>
        {info.payments_ready && (
          <button type="button" onClick={onBrowse} className="inline-flex h-11 items-center rounded-full bg-coral px-5 text-[15px] font-semibold text-white hover:bg-coral-600">
            Scegli dal menu
          </button>
        )}
      </div>
    </div>
  );
}

/** Pulsante carrello fisso su mobile: "Carrello · 3 articoli · 31,50 €". */
export function CartBar({ className }: { className?: string }) {
  const { cart, count, estimate } = useCart();
  const { pathname } = useLocation();
  if (!cart || count === 0 || pathname.startsWith('/cart') || pathname.startsWith('/checkout') || pathname.startsWith('/orders')) return null;
  return (
    <div className={cn('fixed inset-x-0 z-40 px-3 md:hidden', className)}>
      <Link to="/cart" className="flex h-14 items-center justify-between gap-3 rounded-2xl bg-ink px-4 text-white shadow-lift" data-testid="cart-bar">
        <span className="flex items-center gap-2 font-semibold"><ShoppingBag className="h-5 w-5" /> Carrello · {count} {count === 1 ? 'articolo' : 'articoli'}</span>
        <span className="font-bold tabular-nums">{formatPrice(estimate)}</span>
      </Link>
    </div>
  );
}

export function CartButton() {
  const { count } = useCart();
  if (!count) return null;
  return (
    <Link to="/cart" aria-label={`Carrello, ${count} articoli`} className="relative inline-flex h-10 w-10 items-center justify-center rounded-full text-ink transition hover:bg-cream">
      <ShoppingBag className="h-5 w-5" />
      <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-coral px-1 text-[11px] font-bold text-white">{count}</span>
    </Link>
  );
}

/** Timeline con orari reali (dal server). */
export function OrderTimeline({ o }: { o: OrderView }) {
  const steps: { label: string; at: string | null; show: boolean }[] = [
    { label: 'Ordine ricevuto', at: o.created_at, show: true },
    { label: 'Pagamento confermato', at: o.paid_at, show: true },
    { label: 'Accettato', at: o.accepted_at, show: !o.rejected_at },
    { label: 'In preparazione', at: o.preparing_at, show: !o.rejected_at && !o.cancelled_at },
    { label: o.order_type === 'takeaway' ? 'Pronto per il ritiro' : 'Pronto per la consegna', at: o.ready_at, show: !o.rejected_at && !o.cancelled_at },
    { label: 'In consegna', at: o.out_for_delivery_at, show: o.order_type === 'delivery' && !o.rejected_at && !o.cancelled_at },
    { label: o.order_type === 'takeaway' ? 'Ritirato' : 'Consegnato', at: o.completed_at, show: !o.rejected_at && !o.cancelled_at },
    { label: 'Rifiutato dal ristorante', at: o.rejected_at, show: !!o.rejected_at },
    { label: 'Annullato', at: o.cancelled_at, show: !!o.cancelled_at },
  ];
  const visible = steps.filter((s) => s.show);
  const lastDone = visible.map((s) => !!s.at).lastIndexOf(true);
  return (
    <ol className="space-y-0" aria-label="Avanzamento dell’ordine">
      {visible.map((s, i) => {
        const done = !!s.at;
        const current = i === lastDone;
        return (
          <li key={s.label} className="relative flex gap-3 pb-4 last:pb-0">
            {i < visible.length - 1 && <span className={cn('absolute left-[11px] top-6 h-full w-0.5', done && i < lastDone ? 'bg-emerald-500' : 'bg-line')} aria-hidden />}
            <span className={cn('relative z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2',
              done ? (s.label.startsWith('Rifiutato') || s.label === 'Annullato' ? 'border-coral bg-coral text-white' : 'border-emerald-500 bg-emerald-500 text-white') : 'border-line bg-white')}>
              {done && <Check className="h-3.5 w-3.5" />}
            </span>
            <div className={cn('min-w-0 pt-0.5', !done && 'text-ink-faint')}>
              <p className={cn('text-sm', current ? 'font-bold' : 'font-medium')}>{s.label}{!done && <span className="sr-only"> (non ancora)</span>}</p>
              {s.at && <p className="text-xs text-ink-muted">{dayTimeOf(s.at)}</p>}
            </div>
          </li>
        );
      })}
    </ol>
  );
}

/** Badge "Ordina online" per card e mappa (solo ristoranti con ordini e pagamenti attivi). */
export function OrderOnlineBadge({ restaurantId, glass }: { restaurantId: string; glass?: boolean }) {
  const map = useOrderable();
  const o = map?.get(restaurantId);
  if (!o || !o.payments_ready || (!o.takeaway && !o.delivery)) return null;
  const label = o.order_now ? 'Ordina ora' : 'Ordina online';
  const detail = [o.delivery && 'consegna', o.takeaway && 'ritiro'].filter(Boolean).join(' e ');
  return (
    <span
      className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold', glass ? 'bg-white/95 text-coral-700 shadow-card' : 'bg-coral-50 text-coral-700')}
      title={`Ordini online: ${detail}`}
      data-testid="order-online-badge"
    >
      <ShoppingBag className="h-3 w-3" /> {label}<span className="sr-only"> ({detail})</span>
    </span>
  );
}
