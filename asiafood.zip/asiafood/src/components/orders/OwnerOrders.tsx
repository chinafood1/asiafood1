import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell, BellOff, Bike, CheckCircle2, ChefHat, CircleSlash, Clock, CreditCard, ExternalLink, Package, PauseCircle, PlayCircle, Plus, Printer,
  RefreshCw, RotateCcw, Store, Trash2, XCircle,
} from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { useAuth } from '@/context/AuthContext';
import { cn, formatPrice } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import { api } from '@/services';
import type {
  DeliveryZone, MenuOptionGroup, PayoutStatus, RejectReason, RestaurantOrder, RestaurantOrderSettings, RestaurantOrderTab, RestaurantOrdersPage,
} from '@/types/orders';
import { REJECT_REASONS } from '@/types/orders';
import type { RestaurantDelivery } from '@/types/logistics';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert, EmptyState, Spinner } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { StatTile } from '@/components/layout/DashboardLayout';
import { Panel, type EditorTabProps } from '@/components/editor/form';
import { OrderStatusBadge, PaymentBadge, dayTimeOf, timeOf } from './OrderParts';
import { safeAssign } from '@/lib/safeRedirect';

const TABS: { key: RestaurantOrderTab; label: string }[] = [
  { key: 'new', label: 'Nuovi' },
  { key: 'preparing', label: 'In preparazione' },
  { key: 'ready', label: 'Pronti' },
  { key: 'delivering', label: 'In consegna' },
  { key: 'completed', label: 'Completati' },
  { key: 'cancelled', label: 'Annullati' },
];
const PREP_CHOICES = [15, 20, 30, 45, 60];
const isPaused = (until: string | null | undefined) => !!until && (until === 'infinity' || Date.parse(until) > Date.now());
const untilLabel = (until: string | null | undefined) => (until === 'infinity' ? 'fino a riattivazione' : until ? `fino alle ${timeOf(until)}` : '');

/** Breve segnale acustico (Web Audio): attivato solo dopo un clic dell'utente, come richiesto dai browser. */
function useBeep() {
  const ctx = useRef<AudioContext | null>(null);
  const enable = useCallback(() => {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return false;
    ctx.current ??= new AC();
    void ctx.current.resume();
    return true;
  }, []);
  const beep = useCallback(() => {
    const c = ctx.current;
    if (!c) return;
    [0, 0.25].forEach((t) => {
      const o = c.createOscillator();
      const g = c.createGain();
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, c.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.25, c.currentTime + t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t + 0.2);
      o.connect(g).connect(c.destination);
      o.start(c.currentTime + t);
      o.stop(c.currentTime + t + 0.22);
    });
  }, []);
  return { enable, beep };
}

// ═════════════════════════════════════════════════════════════
//  Terminale ordini (/dashboard/restaurants/:id/orders)
// ═════════════════════════════════════════════════════════════
export function OrdersTerminal({ r }: EditorTabProps) {
  const toast = useToast();
  const [tab, setTab] = useState<RestaurantOrderTab>('new');
  const [page, setPage] = useState<RestaurantOrdersPage | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [accepting, setAccepting] = useState<RestaurantOrder | null>(null);
  const [rejecting, setRejecting] = useState<RestaurantOrder | null>(null);
  const [refunding, setRefunding] = useState<RestaurantOrder | null>(null);
  const [printing, setPrinting] = useState<RestaurantOrder | null>(null);
  const [sound, setSound] = useState(false);
  const { enable, beep } = useBeep();
  const lastNew = useRef<number | null>(null);
  const [deliveries, setDeliveries] = useState<Map<string, RestaurantDelivery>>(new Map());

  const load = useCallback(async () => {
    try {
      const [p, dl] = await Promise.all([api.listRestaurantOrders(r.id, tab), api.getRestaurantDeliveries(r.id).catch(() => [] as RestaurantDelivery[])]);
      setPage(p);
      setDeliveries(new Map(dl.map((x) => [x.order_id, x])));
      setError(null);
      if (lastNew.current != null && p.counts.new > lastNew.current && sound) beep();
      lastNew.current = p.counts.new;
    } catch (e) {
      setError((e as Error).message);
    }
  }, [r.id, tab, sound, beep]);

  useEffect(() => {
    void load();
    const t = window.setInterval(() => void load(), 15_000);
    let channel: ReturnType<NonNullable<typeof supabase>['channel']> | null = null;
    if (supabase) {
      channel = supabase.channel(`restaurant-orders-${r.id}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'order_realtime', filter: `restaurant_id=eq.${r.id}` }, () => void load())
        .subscribe();
    }
    return () => {
      window.clearInterval(t);
      if (channel) void supabase?.removeChannel(channel);
    };
  }, [load, r.id]);

  const act = async (o: RestaurantOrder, action: Parameters<typeof api.orderAction>[1], payload?: Record<string, unknown>) => {
    setBusyId(o.id);
    try {
      const res = await api.orderAction(o.id, action, payload);
      toast(res.refund_pending ? 'Ordine aggiornato. Il rimborso al cliente è in elaborazione.' : 'Ordine aggiornato.');
      await load();
      return true;
    } catch (e) {
      toast((e as Error).message, 'error');
      return false;
    } finally {
      setBusyId(null);
    }
  };

  const toggleSound = () => {
    if (!sound && !enable()) {
      toast('Il tuo browser non supporta gli avvisi sonori.', 'error');
      return;
    }
    setSound(!sound);
    if (!sound) beep();
  };

  return (
    <div className="space-y-5" data-testid="orders-terminal">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">Ordini</h2>
          <p className="text-sm text-ink-muted">Aggiornamento automatico in tempo reale. I dati del cliente sono limitati a quelli utili per l’ordine.</p>
        </div>
        <div className="flex gap-2">
          <Button variant={sound ? 'dark' : 'outline'} size="sm" onClick={toggleSound} aria-pressed={sound}>
            {sound ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />} Suono {sound ? 'attivo' : 'spento'}
          </Button>
          <Button variant="outline" size="sm" onClick={() => void load()} aria-label="Aggiorna ordini"><RefreshCw className="h-4 w-4" /></Button>
        </div>
      </div>

      <PausePanel restaurantId={r.id} />

      <div className="scrollbar-none -mx-1 flex gap-2 overflow-x-auto px-1" role="tablist" aria-label="Stato ordini">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            role="tab"
            aria-selected={tab === t.key}
            onClick={() => setTab(t.key)}
            className={cn('inline-flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold transition',
              tab === t.key ? 'border-ink bg-ink text-white' : 'border-line bg-white hover:border-ink')}
            data-testid={`orders-tab-${t.key}`}
          >
            {t.label}
            {page && page.counts[t.key] > 0 && (
              <span className={cn('min-w-5 rounded-full px-1.5 text-xs', t.key === 'new' ? 'bg-coral text-white' : tab === t.key ? 'bg-white/20' : 'bg-cream')}>{page.counts[t.key]}</span>
            )}
          </button>
        ))}
      </div>

      {error && <Alert tone="error">{error}</Alert>}
      {!page && !error && <div className="flex justify-center py-12"><Spinner className="h-8 w-8" /></div>}
      {page && page.items.length === 0 && (
        <EmptyState icon="🧾" title={tab === 'new' ? 'Nessun nuovo ordine' : 'Nessun ordine qui'} text={tab === 'new' ? 'Quando arriva un ordine pagato lo vedi subito qui.' : undefined} />
      )}
      <div className="grid gap-4 xl:grid-cols-2">
        {page?.items.map((o) => (
          <OrderCard
            key={o.id}
            o={o}
            delivery={deliveries.get(o.id) ?? null}
            busy={busyId === o.id}
            canRefund={page.can_refund}
            onAccept={() => setAccepting(o)}
            onReject={() => setRejecting(o)}
            onRefund={() => setRefunding(o)}
            onPrint={() => setPrinting(o)}
            onAction={(a) => void act(o, a)}
          />
        ))}
      </div>

      <AcceptSheet order={accepting} onClose={() => setAccepting(null)} onConfirm={async (min, note) => { if (accepting && await act(accepting, 'accept', { preparation_minutes: min, note })) setAccepting(null); }} />
      <RejectSheet order={rejecting} onClose={() => setRejecting(null)} onConfirm={async (reason, note) => { if (rejecting && await act(rejecting, 'reject', { reason, note })) setRejecting(null); }} />
      <RefundSheet order={refunding} onClose={() => setRefunding(null)} onDone={() => { setRefunding(null); void load(); }} />
      <PrintSheet order={printing} restaurantName={r.name} pickupCode={printing ? deliveries.get(printing.id)?.pickup_code ?? null : null} onClose={() => setPrinting(null)} />
    </div>
  );
}

function OrderCard({ o, delivery, busy, canRefund, onAccept, onReject, onRefund, onPrint, onAction }: {
  o: RestaurantOrder; delivery: RestaurantDelivery | null; busy: boolean; canRefund: boolean;
  onAccept: () => void; onReject: () => void; onRefund: () => void; onPrint: () => void;
  onAction: (a: 'preparing' | 'ready' | 'out_for_delivery' | 'complete') => void;
}) {
  const refundable = Math.max(0, o.amount_paid - o.amount_refunded);
  const due = o.scheduled_for ?? o.estimated_ready_at;
  // Consegna con Rider AsiaFood: "in consegna" e "consegnato" li aggiorna il Rider
  const riderManaged = !!delivery && !['failed', 'cancelled'].includes(delivery.status);
  return (
    <article className={cn('card p-5', o.status === 'pending_restaurant' && 'ring-2 ring-coral')} data-testid="restaurant-order" aria-label={`Ordine ${o.order_number}`}>
      <header className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-mono text-lg font-extrabold">{o.order_number}</p>
          <p className="text-sm text-ink-muted">
            Ricevuto alle {timeOf(o.paid_at ?? o.created_at)} · {o.customer_name}{o.is_repeat_customer ? ' · cliente abituale' : ''}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge tone={o.order_type === 'delivery' ? 'amber' : 'neutral'} icon={o.order_type === 'delivery' ? <Bike className="h-3.5 w-3.5" /> : <Store className="h-3.5 w-3.5" />}>
            {o.order_type === 'delivery' ? 'Consegna' : 'Ritiro'}
          </Badge>
          <OrderStatusBadge status={o.status} />
          <PaymentBadge status={o.payment_status} />
        </div>
      </header>

      {due && (
        <p className={cn('mt-3 flex items-center gap-2 rounded-2xl px-3 py-2 text-sm font-semibold', o.scheduled_for ? 'bg-amber-50 text-amber-900' : 'bg-cream')}>
          <Clock className="h-4 w-4" /> {o.scheduled_for ? `Programmato per ${dayTimeOf(o.scheduled_for)}` : `Pronto previsto alle ${timeOf(o.estimated_ready_at)}`}
        </p>
      )}

      <ul className="mt-3 divide-y divide-line text-sm">
        {o.items.map((it, i) => (
          <li key={i} className="py-2">
            <div className="flex justify-between gap-3">
              <span><strong className="tabular-nums">{it.quantity}×</strong> {it.name}{it.variant ? ` · ${it.variant}` : ''}</span>
              <span className="tabular-nums text-ink-muted">{formatPrice(it.line_total)}</span>
            </div>
            {it.options.length > 0 && <p className="text-xs text-ink-muted">{it.options.map((x) => `${x.group ? `${x.group}: ` : ''}${x.name}${x.quantity > 1 ? ` ×${x.quantity}` : ''}`).join(' · ')}</p>}
            {it.notes && <p className="text-xs font-semibold text-amber-800">Nota: {it.notes}</p>}
          </li>
        ))}
      </ul>

      {o.customer_notes && <p className="mt-2 rounded-2xl bg-amber-50 px-3 py-2 text-sm text-amber-900"><strong>Note del cliente:</strong> {o.customer_notes}</p>}
      {o.order_type === 'delivery' && o.delivery_address && (
        <p className="mt-2 text-sm">
          <strong>Consegna:</strong> {[o.delivery_address.address_line_1, o.delivery_address.address_line_2, o.delivery_address.postal_code, o.delivery_address.city].filter(Boolean).join(', ')}
          {o.delivery_distance_km != null && <span className="text-ink-muted"> · {o.delivery_distance_km.toFixed(1)} km</span>}
          {o.delivery_address.delivery_notes && <span className="block text-xs text-ink-muted">{o.delivery_address.delivery_notes}</span>}
        </p>
      )}
      {o.customer_phone && <p className="mt-1 text-sm"><strong>Telefono:</strong> <a href={`tel:${o.customer_phone}`} className="underline">{o.customer_phone}</a></p>}
      {o.reject_reason && <p className="mt-2 text-sm text-coral-700">Motivo: {o.reject_reason}</p>}
      {o.cancel_reason && <p className="mt-2 text-sm text-coral-700">Annullato: {o.cancel_reason}</p>}
      {o.open_issues > 0 && <p className="mt-2 text-sm font-semibold text-coral-700">Segnalazioni aperte: {o.open_issues}</p>}

      {delivery && <RiderBox d={delivery} />}

      <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 rounded-2xl bg-cream/60 p-3 text-sm">
        <dt className="text-ink-muted">Totale pagato dal cliente</dt><dd className="text-right font-bold tabular-nums">{formatPrice(o.total)}</dd>
        {o.discount_total > 0 && <><dt className="text-ink-muted">Sconti{o.coupon_code ? ` (${o.coupon_code})` : ''}</dt><dd className="text-right tabular-nums">−{formatPrice(o.discount_total)}</dd></>}
        <dt className="text-ink-muted">Commissione AsiaFood</dt><dd className="text-right tabular-nums">−{formatPrice(o.platform_fee)}</dd>
        <dt className="text-ink-muted">Netto stimato</dt><dd className="text-right font-semibold tabular-nums">{formatPrice(o.restaurant_net_estimated)}</dd>
        {o.amount_refunded > 0 && <><dt className="text-ink-muted">Rimborsato</dt><dd className="text-right tabular-nums text-coral-700">{formatPrice(o.amount_refunded)}</dd></>}
      </dl>

      <div className="mt-4 flex flex-wrap gap-2">
        {o.status === 'pending_restaurant' && (
          <>
            <Button size="lg" className="flex-1" onClick={onAccept} loading={busy} data-testid="accept-order"><CheckCircle2 className="h-5 w-5" /> Accetta</Button>
            <Button size="lg" variant="danger" onClick={onReject} disabled={busy} data-testid="reject-order"><XCircle className="h-5 w-5" /> Rifiuta</Button>
          </>
        )}
        {o.status === 'accepted' && <Button size="lg" variant="dark" className="flex-1" loading={busy} onClick={() => onAction('preparing')} data-testid="order-preparing"><ChefHat className="h-5 w-5" /> In preparazione</Button>}
        {(o.status === 'accepted' || o.status === 'preparing') && <Button size="lg" className="flex-1" loading={busy} onClick={() => onAction('ready')} data-testid="order-ready"><Package className="h-5 w-5" /> Pronto</Button>}
        {o.status === 'ready' && o.order_type === 'delivery' && !riderManaged && <Button size="lg" className="flex-1" loading={busy} onClick={() => onAction('out_for_delivery')} data-testid="order-out"><Bike className="h-5 w-5" /> In consegna</Button>}
        {((o.status === 'ready' && o.order_type === 'takeaway') || (o.status === 'out_for_delivery' && !riderManaged)) && (
          <Button size="lg" variant="dark" className="flex-1" loading={busy} onClick={() => onAction('complete')} data-testid="order-complete">
            <CheckCircle2 className="h-5 w-5" /> {o.order_type === 'takeaway' ? 'Ritirato' : 'Consegnato'}
          </Button>
        )}
        <Button variant="outline" onClick={onPrint} aria-label={`Stampa ordine ${o.order_number}`}><Printer className="h-4 w-4" /></Button>
        {canRefund && refundable > 0 && !['pending_restaurant', 'pending_payment'].includes(o.status) && (
          <Button variant="outline" onClick={onRefund}><RotateCcw className="h-4 w-4" /> Rimborso</Button>
        )}
      </div>
    </article>
  );
}

/** Stato del Rider AsiaFood per l'ordine: ricerca, assegnato, in arrivo, arrivato, ritirato. */
function RiderBox({ d }: { d: RestaurantDelivery }) {
  const mins = d.eta_pickup_at ? Math.max(1, Math.round((Date.parse(d.eta_pickup_at) - Date.now()) / 60_000)) : null;
  const text = ['waiting_assignment', 'offered'].includes(d.status) ? 'Ricerca Rider in corso'
    : ['assigned', 'rider_to_restaurant'].includes(d.status) ? `Rider in arrivo${mins ? ` tra circa ${mins} min` : ''}`
      : d.status === 'arrived_restaurant' ? 'Rider arrivato: consegna l’ordine e comunica il codice di ritiro'
        : ['picked_up', 'rider_to_customer', 'arrived_customer'].includes(d.status) ? 'Ordine ritirato dal Rider'
          : d.status === 'delivered' ? 'Consegnato dal Rider' : d.status === 'failed' ? 'Consegna non riuscita: il supporto AsiaFood ti contatterà' : 'Consegna annullata';
  return (
    <div className={cn('mt-3 rounded-2xl border p-3 text-sm', d.status === 'arrived_restaurant' ? 'border-emerald-500 bg-emerald-50' : 'border-line')} data-testid="rider-box">
      <p className="flex items-center gap-2 font-semibold"><Bike className="h-4 w-4 text-coral" /> Rider AsiaFood · {text}</p>
      {d.rider && <p className="mt-1">{d.rider.name}</p>}
      {d.pickup_code && !['picked_up', 'rider_to_customer', 'arrived_customer', 'delivered', 'failed', 'cancelled'].includes(d.status) && (
        <p className="mt-2">Codice di ritiro da comunicare al Rider: <strong className="font-mono text-lg tracking-widest" data-testid="pickup-code-restaurant">{d.pickup_code}</strong></p>
      )}
    </div>
  );
}

function AcceptSheet({ order, onClose, onConfirm }: { order: RestaurantOrder | null; onClose: () => void; onConfirm: (min: number, note: string) => Promise<void> }) {
  const [min, setMin] = useState<number | 'custom'>(20);
  const [custom, setCustom] = useState('25');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (order) { setMin(order.preparation_minutes && PREP_CHOICES.includes(order.preparation_minutes) ? order.preparation_minutes : 20); setNote(''); }
  }, [order]);
  const value = min === 'custom' ? Number(custom) : min;
  const valid = Number.isInteger(value) && value >= 5 && value <= 240;
  return (
    <Sheet open={!!order} onClose={onClose} title={`Accetta ${order?.order_number ?? ''}`}
      footer={<Button size="lg" className="w-full" disabled={!valid} loading={busy} data-testid="confirm-accept" onClick={async () => { setBusy(true); await onConfirm(value, note); setBusy(false); }}>Accetta · pronto tra {valid ? value : '…'} min</Button>}>
      <p className="mb-3 text-sm text-ink-muted">{order?.scheduled_for ? `Ordine programmato per ${dayTimeOf(order.scheduled_for)}. Indica comunque il tempo di preparazione.` : 'Tra quanto sarà pronto? Il cliente vedrà l’orario stimato.'}</p>
      <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Tempo di preparazione">
        {PREP_CHOICES.map((m) => (
          <button key={m} type="button" role="radio" aria-checked={min === m} onClick={() => setMin(m)}
            className={cn('h-14 rounded-2xl border text-lg font-bold', min === m ? 'border-ink bg-ink text-white' : 'border-line bg-white')}>{m} min</button>
        ))}
        <button type="button" role="radio" aria-checked={min === 'custom'} onClick={() => setMin('custom')}
          className={cn('h-14 rounded-2xl border font-bold', min === 'custom' ? 'border-ink bg-ink text-white' : 'border-line bg-white')}>Altro</button>
      </div>
      {min === 'custom' && <Field label="Minuti (5–240)" className="mt-3" error={valid ? null : 'Inserisci un numero tra 5 e 240.'}><Input inputMode="numeric" value={custom} onChange={(e) => setCustom(e.target.value.replace(/\D/g, ''))} /></Field>}
      <Field label="Nota interna (facoltativa)" className="mt-3"><Input value={note} maxLength={300} onChange={(e) => setNote(e.target.value)} /></Field>
    </Sheet>
  );
}

function RejectSheet({ order, onClose, onConfirm }: { order: RestaurantOrder | null; onClose: () => void; onConfirm: (reason: RejectReason, note: string) => Promise<void> }) {
  const [reason, setReason] = useState<RejectReason>('too_busy');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (order) { setReason('too_busy'); setNote(''); } }, [order]);
  const paid = order && order.amount_paid > 0;
  return (
    <Sheet open={!!order} onClose={onClose} title={`Rifiuta ${order?.order_number ?? ''}`}
      footer={<Button size="lg" variant="danger" className="w-full" loading={busy} data-testid="confirm-reject" disabled={reason === 'other' && !note.trim()} onClick={async () => { setBusy(true); await onConfirm(reason, note); setBusy(false); }}>Rifiuta ordine</Button>}>
      <fieldset className="space-y-2">
        <legend className="mb-2 text-sm font-semibold">Motivo (visibile al cliente)</legend>
        {REJECT_REASONS.map((x) => (
          <label key={x.value} className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border px-4 py-3', reason === x.value ? 'border-ink' : 'border-line')}>
            <input type="radio" name="reject" checked={reason === x.value} onChange={() => setReason(x.value)} className="accent-coral" /> {x.label}
          </label>
        ))}
      </fieldset>
      <Field label={reason === 'other' ? 'Spiega il motivo' : 'Dettagli (facoltativi)'} className="mt-3"><Textarea value={note} maxLength={200} onChange={(e) => setNote(e.target.value)} /></Field>
      {paid && <p className="mt-3 text-sm text-ink-muted">Il cliente ha già pagato: riceverà automaticamente il rimborso completo.</p>}
    </Sheet>
  );
}

function RefundSheet({ order, onClose, onDone }: { order: RestaurantOrder | null; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const max = order ? Math.max(0, order.amount_paid - order.amount_refunded) : 0;
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { if (order) { setAmount(max.toFixed(2)); setReason(''); setErr(null); } }, [order, max]);
  const value = Number(amount.replace(',', '.'));
  const valid = value > 0 && value <= max + 1e-9 && reason.trim().length >= 3;
  return (
    <Sheet open={!!order} onClose={onClose} title={`Rimborso ${order?.order_number ?? ''}`}
      footer={<Button size="lg" className="w-full" disabled={!valid} loading={busy} onClick={async () => {
        if (!order) return;
        setBusy(true); setErr(null);
        try { await api.refundOrder(order.id, Math.round(value * 100) / 100, reason.trim()); toast('Rimborso richiesto: verrà elaborato tramite Stripe.'); onDone(); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
      }}>Rimborsa {valid ? formatPrice(value) : ''}</Button>}>
      <p className="mb-3 text-sm text-ink-muted">Puoi rimborsare al massimo {formatPrice(max)} (importo pagato meno i rimborsi già eseguiti).</p>
      <Field label="Importo (€)" error={value > max ? `Massimo ${formatPrice(max)}` : null}><Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
      <Field label="Motivo" className="mt-3"><Input value={reason} maxLength={200} onChange={(e) => setReason(e.target.value)} placeholder="Es. prodotto mancante" /></Field>
      {err && <div className="mt-3"><Alert tone="error">{err}</Alert></div>}
    </Sheet>
  );
}

/** Vista di stampa (comanda). Nessun dato non necessario. */
function PrintSheet({ order, restaurantName, pickupCode, onClose }: { order: RestaurantOrder | null; restaurantName: string; pickupCode: string | null; onClose: () => void }) {
  if (!order) return null;
  return (
    <Sheet open onClose={onClose} title={`Comanda ${order.order_number}`} footer={<Button className="w-full" onClick={() => window.print()}><Printer className="h-4 w-4" /> Stampa</Button>}>
      <div id="print-area" className="print-ticket font-mono text-sm">
        <p className="text-center font-bold">{restaurantName}</p>
        <p className="text-center text-xl font-extrabold">{order.order_number}</p>
        <p className="text-center">{order.order_type === 'delivery' ? 'CONSEGNA' : 'RITIRO'} · {dayTimeOf(order.scheduled_for ?? order.estimated_ready_at ?? order.created_at)}</p>
        <p className="mt-2">Cliente: {order.customer_name}</p>
        <hr className="my-2 border-dashed border-ink" />
        {order.items.map((it, i) => (
          <div key={i} className="mb-1">
            <p className="font-bold">{it.quantity}× {it.name}{it.variant ? ` (${it.variant})` : ''}</p>
            {it.options.map((x, j) => <p key={j} className="pl-4">+ {x.name}{x.quantity > 1 ? ` ×${x.quantity}` : ''}</p>)}
            {it.notes && <p className="pl-4">NOTA: {it.notes}</p>}
          </div>
        ))}
        <hr className="my-2 border-dashed border-ink" />
        {order.customer_notes && <p>Note: {order.customer_notes}</p>}
        {order.order_type === 'delivery' && order.delivery_address && <p>Indirizzo: {[order.delivery_address.address_line_1, order.delivery_address.address_line_2, order.delivery_address.city].filter(Boolean).join(', ')}</p>}
        <p className="mt-2 text-right font-bold">Totale {formatPrice(order.total)} · {order.payment_status === 'paid' ? 'PAGATO ONLINE' : order.payment_status}</p>
        {pickupCode && <p className="mt-2 text-center text-lg font-bold">CODICE RITIRO RIDER: {pickupCode}</p>}
        <p className="mt-2 text-center text-xs">Documento non fiscale</p>
      </div>
    </Sheet>
  );
}

// ─── Pausa / molto occupato / disponibilità prodotti ────────────
function PausePanel({ restaurantId }: { restaurantId: string }) {
  const toast = useToast();
  const s = useAsync(() => api.getOrderSettings(restaurantId), [restaurantId]);
  const [busy, setBusy] = useState(false);
  const st = s.data?.settings;
  if (!st) return null;
  const run = async (kind: 'all' | 'delivery' | 'takeaway' | 'busy', minutes: number | null, msg: string) => {
    setBusy(true);
    try { await api.setOrderPause(restaurantId, kind, minutes); toast(msg); s.reload(); } catch (e) { toast((e as Error).message, 'error'); } finally { setBusy(false); }
  };
  const allPaused = isPaused(st.orders_paused_until);
  return (
    <div className={cn('rounded-3xl border p-4', allPaused ? 'border-coral bg-coral-50' : 'border-line bg-white')} data-testid="pause-panel">
      <div className="flex flex-wrap items-center gap-2">
        {allPaused ? (
          <>
            <p className="flex items-center gap-2 font-semibold text-coral-700"><PauseCircle className="h-5 w-5" /> Ordini in pausa {untilLabel(st.orders_paused_until)}</p>
            <Button size="sm" onClick={() => void run('all', 0, 'Ordini riattivati.')} loading={busy}><PlayCircle className="h-4 w-4" /> Riprendi ordini</Button>
          </>
        ) : (
          <>
            <span className="text-sm font-semibold">Pausa ordini:</span>
            {[15, 30, 60].map((m) => <Chip key={m} onClick={() => void run('all', m, `Ordini in pausa per ${m} minuti.`)}>{m} min</Chip>)}
            <Chip onClick={() => void run('all', null, 'Ordini in pausa fino a riattivazione.')}>Fino a riattivazione</Chip>
          </>
        )}
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
        <span className="font-semibold">Molto occupato:</span>
        {[0, 10, 20, 30].map((m) => (
          <Chip key={m} active={st.busy_extra_minutes === m} onClick={() => void run('busy', m, m ? `Tempi di preparazione +${m} min.` : 'Tempi normali.')}>{m ? `+${m} min` : 'No'}</Chip>
        ))}
      </div>
      {!allPaused && (
        <div className="mt-3 flex flex-wrap gap-2 text-sm">
          {st.takeaway_enabled && (isPaused(st.takeaway_paused_until)
            ? <Button size="sm" variant="outline" onClick={() => void run('takeaway', 0, 'Ritiro riattivato.')}>Riattiva ritiro</Button>
            : <Button size="sm" variant="ghost" onClick={() => void run('takeaway', 60, 'Ritiro in pausa per 60 minuti.')}>Pausa solo ritiro (60 min)</Button>)}
          {st.delivery_enabled && (isPaused(st.delivery_paused_until)
            ? <Button size="sm" variant="outline" onClick={() => void run('delivery', 0, 'Consegna riattivata.')}>Riattiva consegna</Button>
            : <Button size="sm" variant="ghost" onClick={() => void run('delivery', 60, 'Consegna in pausa per 60 minuti.')}>Pausa solo consegna (60 min)</Button>)}
        </div>
      )}
    </div>
  );
}

/** Disponibilità rapida dei prodotti ("Non disponibile oggi"). */
export function ItemAvailability({ r, reload }: EditorTabProps) {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const items = useMemo(() => r.menus.flatMap((m) => m.sections.flatMap((s) => s.items.map((i) => ({ ...i, section: s.name })))), [r.menus]);
  const shown = items.filter((i) => !q || i.name.toLowerCase().includes(q.toLowerCase())).slice(0, 60);
  const set = async (id: string, mode: 'today' | 'off' | 'on') => {
    setBusy(id);
    try { await api.setMenuItemAvailability(id, mode); toast(mode === 'on' ? 'Prodotto di nuovo disponibile.' : mode === 'today' ? 'Non disponibile fino a domani.' : 'Prodotto disattivato.'); reload(); } catch (e) { toast((e as Error).message, 'error'); } finally { setBusy(null); }
  };
  return (
    <Panel title="Disponibilità prodotti" description="“Non disponibile oggi” torna disponibile automaticamente domani.">
      <Input placeholder="Cerca un piatto" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Cerca un piatto" />
      <ul className="mt-3 divide-y divide-line">
        {shown.map((i) => {
          const today = !!i.unavailable_until && Date.parse(i.unavailable_until) > Date.now();
          const off = !i.is_available;
          return (
            <li key={i.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
              <span className="min-w-0">
                <span className="font-medium">{i.name}</span> <span className="text-xs text-ink-muted">{i.section}</span>
                {today && <Badge tone="amber" className="ml-2">Non disponibile oggi</Badge>}
                {off && <Badge tone="coral" className="ml-2">Disattivato</Badge>}
              </span>
              <span className="flex gap-1.5">
                {(today || off) ? (
                  <Button size="sm" variant="outline" loading={busy === i.id} onClick={() => void set(i.id, 'on')}>Rendi disponibile</Button>
                ) : (
                  <>
                    <Button size="sm" variant="soft" loading={busy === i.id} onClick={() => void set(i.id, 'today')} data-testid="item-unavailable-today">Non disponibile oggi</Button>
                    <Button size="sm" variant="ghost" disabled={busy === i.id} onClick={() => void set(i.id, 'off')}><CircleSlash className="h-4 w-4" /></Button>
                  </>
                )}
              </span>
            </li>
          );
        })}
      </ul>
      {items.length === 0 && <p className="text-sm text-ink-muted">Aggiungi prima i piatti nella sezione Menu.</p>}
    </Panel>
  );
}

// ═════════════════════════════════════════════════════════════
//  Impostazioni ordini, zone di consegna, scelte del menu
// ═════════════════════════════════════════════════════════════
const DEFAULT_SETTINGS: Partial<RestaurantOrderSettings> = {
  orders_enabled: false, takeaway_enabled: true, delivery_enabled: false, minimum_order_amount: 0, takeaway_minimum_order: null, delivery_minimum_order: null,
  default_preparation_minutes: 20, busy_extra_minutes: 0, delivery_estimated_minutes: 30, slot_interval_minutes: 15, max_orders_per_slot: null,
  accept_orders_automatically: false, allow_scheduled_orders: true, max_advance_days: 2, delivery_radius_km: 5, free_delivery_threshold: null,
  delivery_fee_type: 'fixed', delivery_fee: 2.5, delivery_provider_type: 'restaurant', pickup_instructions: null,
};

export function OrderSettingsSection(p: EditorTabProps) {
  const { r } = p;
  const toast = useToast();
  const data = useAsync(() => api.getOrderSettings(r.id), [r.id]);
  const { isAdmin } = useAuth();
  const [f, setF] = useState<Partial<RestaurantOrderSettings>>(DEFAULT_SETTINGS);
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (data.data) setF({ ...DEFAULT_SETTINGS, ...(data.data.settings ?? {}) }); }, [data.data]);
  const set = <K extends keyof RestaurantOrderSettings>(k: K, v: RestaurantOrderSettings[K]) => setF((x) => ({ ...x, [k]: v }));
  const numOrNull = (v: string) => (v.trim() === '' ? null : Number(v.replace(',', '.')));

  const save = async () => {
    setSaving(true);
    try {
      const { id: _id, restaurant_id: _r, created_at: _c, updated_at: _u, orders_paused_until: _a, delivery_paused_until: _b, takeaway_paused_until: _t, service_fee_enabled: _s, ...patch } = f;
      await api.saveOrderSettings(r.id, patch);
      toast('Impostazioni ordini salvate.');
      data.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setSaving(false);
    }
  };

  if (data.loading && !data.data) return <div className="flex justify-center py-12"><Spinner className="h-8 w-8" /></div>;
  if (data.error) return <Alert tone="error">{data.error.message}</Alert>;
  return (
    <div className="space-y-6">
      <Panel title="Ordini online" description="Takeaway e consegna gestita dal tuo locale. I pagamenti arrivano tramite Stripe (sezione Pagamenti)."
        footer={<Button onClick={() => void save()} loading={saving} data-testid="save-order-settings">Salva impostazioni</Button>}>
        <div className="divide-y divide-line">
          <Toggle label="Accetta ordini online" checked={!!f.orders_enabled} onChange={(v) => set('orders_enabled', v)} />
          <Toggle label="Ritiro al locale (takeaway)" checked={!!f.takeaway_enabled} onChange={(v) => set('takeaway_enabled', v)} />
          <Toggle label="Consegna a domicilio" description="Consegna effettuata dal tuo personale." checked={!!f.delivery_enabled} onChange={(v) => set('delivery_enabled', v)} />
          <Toggle label="Ordini programmati" description="I clienti possono scegliere un orario futuro." checked={!!f.allow_scheduled_orders} onChange={(v) => set('allow_scheduled_orders', v)} />
          <Toggle label="Accetta automaticamente" description="Gli ordini pagati vengono accettati con il tempo di preparazione predefinito." checked={!!f.accept_orders_automatically} onChange={(v) => set('accept_orders_automatically', v)} />
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Ordine minimo (€)"><Input inputMode="decimal" value={f.minimum_order_amount ?? 0} onChange={(e) => set('minimum_order_amount', Number(e.target.value.replace(',', '.')) || 0)} /></Field>
          <Field label="Minimo ritiro (€)" hint="Vuoto = ordine minimo"><Input inputMode="decimal" value={f.takeaway_minimum_order ?? ''} onChange={(e) => set('takeaway_minimum_order', numOrNull(e.target.value))} /></Field>
          <Field label="Minimo consegna (€)" hint="Vuoto = ordine minimo"><Input inputMode="decimal" value={f.delivery_minimum_order ?? ''} onChange={(e) => set('delivery_minimum_order', numOrNull(e.target.value))} /></Field>
          <Field label="Preparazione (min)"><Input inputMode="numeric" value={f.default_preparation_minutes ?? 20} onChange={(e) => set('default_preparation_minutes', Number(e.target.value) || 0)} /></Field>
          <Field label="Intervallo orari (min)"><Select value={f.slot_interval_minutes ?? 15} onChange={(e) => set('slot_interval_minutes', Number(e.target.value))}>{[10, 15, 20, 30].map((m) => <option key={m} value={m}>{m}</option>)}</Select></Field>
          <Field label="Max ordini per orario" hint="Vuoto = nessun limite"><Input inputMode="numeric" value={f.max_orders_per_slot ?? ''} onChange={(e) => set('max_orders_per_slot', numOrNull(e.target.value))} /></Field>
          <Field label="Giorni di anticipo max"><Input inputMode="numeric" value={f.max_advance_days ?? 2} onChange={(e) => set('max_advance_days', Number(e.target.value) || 0)} /></Field>
          <Field label="Istruzioni per il ritiro" className="sm:col-span-2"><Input value={f.pickup_instructions ?? ''} maxLength={300} onChange={(e) => set('pickup_instructions', e.target.value || null)} placeholder="Es. suona al campanello laterale" /></Field>
        </div>
        {f.delivery_enabled && (
          <div className="mt-6 grid gap-4 border-t border-line pt-5 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Tipo costo consegna">
              <Select value={f.delivery_fee_type} onChange={(e) => set('delivery_fee_type', e.target.value as RestaurantOrderSettings['delivery_fee_type'])}>
                <option value="fixed">Fisso</option><option value="distance">Per distanza (zone)</option><option value="zone">Per zona</option><option value="free">Gratuita</option>
              </Select>
            </Field>
            {f.delivery_fee_type === 'fixed' && <Field label="Costo consegna (€)"><Input inputMode="decimal" value={f.delivery_fee ?? 0} onChange={(e) => set('delivery_fee', Number(e.target.value.replace(',', '.')) || 0)} /></Field>}
            <Field label="Raggio massimo (km)"><Input inputMode="decimal" value={f.delivery_radius_km ?? ''} onChange={(e) => set('delivery_radius_km', numOrNull(e.target.value))} /></Field>
            <Field label="Consegna gratuita da (€)" hint="Vuoto = mai"><Input inputMode="decimal" value={f.free_delivery_threshold ?? ''} onChange={(e) => set('free_delivery_threshold', numOrNull(e.target.value))} /></Field>
            <Field label="Tempo di consegna (min)"><Input inputMode="numeric" value={f.delivery_estimated_minutes ?? 30} onChange={(e) => set('delivery_estimated_minutes', Number(e.target.value) || 0)} /></Field>
            <Field label="Chi consegna" hint={f.asiafood_delivery_enabled ? 'Con i Rider AsiaFood la consegna è gestita dalla piattaforma (ricerca Rider, tracking, prova di consegna).' : 'I Rider AsiaFood vanno abilitati dallo staff AsiaFood.'}>
              <Select value={f.delivery_provider_type} onChange={(e) => set('delivery_provider_type', e.target.value as RestaurantOrderSettings['delivery_provider_type'])} data-testid="delivery-provider">
                <option value="restaurant">Il mio locale</option>
                {(f.asiafood_delivery_enabled || f.delivery_provider_type === 'asiafood') && <option value="asiafood">Rider AsiaFood</option>}
              </Select>
            </Field>
          </div>
        )}
      </Panel>
      {isAdmin && (
        <Panel title="Rider AsiaFood (solo staff)" description="Abilita il ristorante alla consegna con i Rider AsiaFood. Il ristorante sceglie poi «Chi consegna» nelle sue impostazioni.">
          <Toggle label="Consegne con Rider AsiaFood abilitate" checked={!!f.asiafood_delivery_enabled} onChange={async (v) => {
            try { await api.adminSetRestaurantLogistics(r.id, v); toast(v ? 'Rider AsiaFood abilitati.' : 'Rider AsiaFood disabilitati.'); data.reload(); } catch (e) { toast((e as Error).message, 'error'); }
          }} />
        </Panel>
      )}
      {f.delivery_enabled && <ZonesPanel restaurantId={r.id} zones={data.data?.zones ?? []} onChange={data.reload} />}
      <OptionGroupsPanel {...p} />
      <ItemAvailability {...p} />
    </div>
  );
}

function ZonesPanel({ restaurantId, zones, onChange }: { restaurantId: string; zones: DeliveryZone[]; onChange: () => void }) {
  const toast = useToast();
  const [draft, setDraft] = useState<Partial<DeliveryZone> | null>(null);
  const save = async () => {
    if (!draft) return;
    try { await api.saveDeliveryZone(restaurantId, { zone_type: 'distance', is_active: true, ...draft }); toast('Zona salvata.'); setDraft(null); onChange(); } catch (e) { toast((e as Error).message, 'error'); }
  };
  const del = async (id: string) => {
    try { await api.deleteDeliveryZone(restaurantId, id); toast('Zona eliminata.'); onChange(); } catch (e) { toast((e as Error).message, 'error'); }
  };
  const n = (v: string) => (v.trim() === '' ? null : Number(v.replace(',', '.')));
  return (
    <Panel title="Zone di consegna" description="Fasce di distanza dal locale con costo, minimo e tempi. Se non configuri zone vale il raggio massimo con il costo fisso.">
      <ul className="divide-y divide-line">
        {zones.map((z) => (
          <li key={z.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm">
            <span><strong>{z.name}</strong> · {z.min_distance_km ?? 0}–{z.max_distance_km ?? z.radius_km ?? '?'} km · {formatPrice(z.delivery_fee)} · minimo {formatPrice(z.minimum_order)} · {z.estimated_delivery_minutes} min {!z.is_active && <Badge tone="neutral">Disattiva</Badge>}</span>
            <span className="flex gap-1">
              <Button size="sm" variant="ghost" onClick={() => setDraft(z)}>Modifica</Button>
              <Button size="sm" variant="ghost" onClick={() => void del(z.id)} aria-label={`Elimina ${z.name}`}><Trash2 className="h-4 w-4" /></Button>
            </span>
          </li>
        ))}
      </ul>
      {zones.length === 0 && <p className="text-sm text-ink-muted">Nessuna zona configurata.</p>}
      {draft ? (
        <div className="mt-4 grid gap-3 rounded-3xl bg-cream/60 p-4 sm:grid-cols-3">
          <Field label="Nome"><Input value={draft.name ?? ''} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Da km"><Input inputMode="decimal" value={draft.min_distance_km ?? ''} onChange={(e) => setDraft({ ...draft, min_distance_km: n(e.target.value) })} /></Field>
          <Field label="A km"><Input inputMode="decimal" value={draft.max_distance_km ?? ''} onChange={(e) => setDraft({ ...draft, max_distance_km: n(e.target.value) })} /></Field>
          <Field label="Costo (€)"><Input inputMode="decimal" value={draft.delivery_fee ?? ''} onChange={(e) => setDraft({ ...draft, delivery_fee: n(e.target.value) ?? 0 })} /></Field>
          <Field label="Minimo (€)"><Input inputMode="decimal" value={draft.minimum_order ?? ''} onChange={(e) => setDraft({ ...draft, minimum_order: n(e.target.value) ?? 0 })} /></Field>
          <Field label="Tempo (min)"><Input inputMode="numeric" value={draft.estimated_delivery_minutes ?? ''} onChange={(e) => setDraft({ ...draft, estimated_delivery_minutes: n(e.target.value) ?? 30 })} /></Field>
          <div className="flex gap-2 sm:col-span-3">
            <Button onClick={() => void save()}>Salva zona</Button>
            <Button variant="ghost" onClick={() => setDraft(null)}>Annulla</Button>
          </div>
        </div>
      ) : (
        <Button variant="outline" className="mt-4" onClick={() => setDraft({ name: `Zona ${zones.length + 1}`, min_distance_km: 0, max_distance_km: 3, delivery_fee: 2, minimum_order: 15, estimated_delivery_minutes: 30 })}><Plus className="h-4 w-4" /> Aggiungi zona</Button>
      )}
    </Panel>
  );
}

type GroupDraft = Omit<Partial<MenuOptionGroup>, 'options'> & { menu_item_id: string; options: { id?: string; name: string; price: number; is_available?: boolean }[] };

function OptionGroupsPanel({ r }: EditorTabProps) {
  const toast = useToast();
  const groups = useAsync(() => api.listAllOptionGroups(r.id), [r.id]);
  const items = useMemo(() => r.menus.flatMap((m) => m.sections.flatMap((s) => s.items)), [r.menus]);
  const [draft, setDraft] = useState<GroupDraft | null>(null);
  const nameOf = (id: string) => items.find((i) => i.id === id)?.name ?? 'Piatto';
  const save = async () => {
    if (!draft) return;
    try { await api.saveOptionGroup(r.id, { ...draft, options: draft.options.filter((o) => o.name.trim()) }); toast('Scelte salvate.'); setDraft(null); groups.reload(); } catch (e) { toast((e as Error).message, 'error'); }
  };
  const del = async (id: string) => {
    try { await api.deleteOptionGroup(r.id, id); toast('Gruppo eliminato.'); groups.reload(); } catch (e) { toast((e as Error).message, 'error'); }
  };
  return (
    <Panel title="Scelte e personalizzazioni" description="Gruppi di opzioni per piatto (es. Base: riso bianco / integrale). Varianti ed extra si gestiscono nella sezione Menu.">
      <ul className="divide-y divide-line">
        {(groups.data ?? []).map((g) => (
          <li key={g.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm">
            <span><strong>{nameOf(g.menu_item_id)}</strong> · {g.name} ({g.required ? 'obbligatorio' : 'facoltativo'}, {g.min_select}–{g.max_select}) · {g.options.map((o) => `${o.name}${o.price ? ` +${formatPrice(o.price)}` : ''}`).join(', ')}</span>
            <span className="flex gap-1">
              <Button size="sm" variant="ghost" onClick={() => setDraft({ ...g, options: g.options.map((o) => ({ id: o.id, name: o.name, price: o.price, is_available: o.is_available })) })}>Modifica</Button>
              <Button size="sm" variant="ghost" onClick={() => void del(g.id)} aria-label={`Elimina ${g.name}`}><Trash2 className="h-4 w-4" /></Button>
            </span>
          </li>
        ))}
      </ul>
      {groups.data?.length === 0 && <p className="text-sm text-ink-muted">Nessun gruppo di scelte.</p>}
      {draft ? (
        <div className="mt-4 space-y-3 rounded-3xl bg-cream/60 p-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Piatto"><Select value={draft.menu_item_id} onChange={(e) => setDraft({ ...draft, menu_item_id: e.target.value })}>{items.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</Select></Field>
            <Field label="Nome gruppo"><Input value={draft.name ?? ''} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Es. Base" /></Field>
            <Field label="Minimo scelte"><Input inputMode="numeric" value={draft.min_select ?? 0} onChange={(e) => setDraft({ ...draft, min_select: Number(e.target.value) || 0 })} /></Field>
            <Field label="Massimo scelte"><Input inputMode="numeric" value={draft.max_select ?? 1} onChange={(e) => setDraft({ ...draft, max_select: Number(e.target.value) || 1 })} /></Field>
          </div>
          <Toggle label="Scelta obbligatoria" checked={!!draft.required} onChange={(v) => setDraft({ ...draft, required: v, min_select: v ? Math.max(1, draft.min_select ?? 1) : 0 })} />
          {draft.options.map((o, i) => (
            <div key={i} className="flex gap-2">
              <Input aria-label="Opzione" value={o.name} onChange={(e) => setDraft({ ...draft, options: draft.options.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)) })} placeholder="Nome opzione" />
              <Input aria-label="Prezzo extra" className="w-28" inputMode="decimal" value={o.price} onChange={(e) => setDraft({ ...draft, options: draft.options.map((x, j) => (j === i ? { ...x, price: Number(e.target.value.replace(',', '.')) || 0 } : x)) })} />
              <Button variant="ghost" onClick={() => setDraft({ ...draft, options: draft.options.filter((_, j) => j !== i) })} aria-label="Rimuovi opzione"><Trash2 className="h-4 w-4" /></Button>
            </div>
          ))}
          <Button variant="ghost" size="sm" onClick={() => setDraft({ ...draft, options: [...draft.options, { name: '', price: 0 }] })}><Plus className="h-4 w-4" /> Opzione</Button>
          <div className="flex gap-2">
            <Button onClick={() => void save()}>Salva gruppo</Button>
            <Button variant="ghost" onClick={() => setDraft(null)}>Annulla</Button>
          </div>
        </div>
      ) : items.length > 0 && (
        <Button variant="outline" className="mt-4" onClick={() => setDraft({ menu_item_id: items[0]!.id, name: '', min_select: 1, max_select: 1, required: true, options: [{ name: '', price: 0 }, { name: '', price: 0 }] })}><Plus className="h-4 w-4" /> Nuovo gruppo</Button>
      )}
    </Panel>
  );
}

// ═════════════════════════════════════════════════════════════
//  Pagamenti (Stripe Connect Express)
// ═════════════════════════════════════════════════════════════
export function PayoutsSection({ r }: EditorTabProps) {
  const toast = useToast();
  const st = useAsync<PayoutStatus>(() => api.getPayoutStatus(r.id), [r.id]);
  const [busy, setBusy] = useState<string | null>(null);
  const run = async (key: string, fn: () => Promise<void>) => {
    setBusy(key);
    try { await fn(); } catch (e) { toast((e as Error).message, 'error'); } finally { setBusy(null); }
  };
  const onboard = () => run('onboard', async () => {
    const res = await api.startPayoutOnboarding(r.id);
    if (res.url) safeAssign(res.url);
    else { toast('Configurazione simulata completata (DEMO).'); st.reload(); }
  });
  const s = st.data;
  const a = s?.account;
  const ready = !!a?.charges_enabled && !!a?.payouts_enabled;
  return (
    <div className="space-y-6" data-testid="payouts">
      <Panel title="Pagamenti degli ordini" description="Gli incassi degli ordini online arrivano sul tuo conto tramite Stripe Connect. I dati bancari e d’identità li inserisci direttamente su Stripe: AsiaFood non li vede.">
        {st.loading && !s ? <Spinner className="h-6 w-6" /> : st.error ? <Alert tone="error">{st.error.message}</Alert> : s && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              {ready ? <Badge tone="green" icon={<CheckCircle2 className="h-3.5 w-3.5" />}>Pagamenti attivi</Badge>
                : a ? <Badge tone="amber">Configurazione da completare</Badge> : <Badge tone="neutral">Non configurato</Badge>}
              <Badge tone={s.environment === 'live' ? 'dark' : 'amber'}>{s.environment === 'live' ? 'LIVE' : 'Modalità TEST'}</Badge>
              {s.simulated && <Badge tone="amber">Simulato (DEMO)</Badge>}
            </div>
            {a && (
              <dl className="grid gap-2 text-sm sm:grid-cols-3">
                <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Dati inviati</dt><dd className="font-semibold">{a.details_submitted ? 'Sì' : 'No'}</dd></div>
                <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Incassi</dt><dd className="font-semibold">{a.charges_enabled ? 'Abilitati' : 'Non ancora'}</dd></div>
                <div className="rounded-2xl bg-cream/60 p-3"><dt className="text-ink-muted">Bonifici</dt><dd className="font-semibold">{a.payouts_enabled ? 'Abilitati' : 'Non ancora'}</dd></div>
              </dl>
            )}
            {a && a.requirements_due.length > 0 && <Alert>Stripe richiede ancora {a.requirements_due.length} informazioni. Continua la configurazione per completarle.</Alert>}
            {!ready && s.platform_collection_test && <Alert>In modalità TEST la piattaforma può incassare gli ordini di prova anche senza conto collegato. In LIVE serve la configurazione completa.</Alert>}
            <div className="flex flex-wrap gap-2">
              {!ready && <Button onClick={() => void onboard()} loading={busy === 'onboard'} data-testid="setup-payouts"><CreditCard className="h-4 w-4" /> {a ? 'Continua configurazione' : 'Configura pagamenti'}</Button>}
              {a && <Button variant="outline" onClick={() => void run('refresh', async () => { await api.refreshPayoutStatus(r.id); st.reload(); toast('Stato aggiornato.'); })} loading={busy === 'refresh'}><RefreshCw className="h-4 w-4" /> Aggiorna stato</Button>}
              {ready && !s.simulated && <Button variant="outline" onClick={() => void run('dash', async () => { const x = await api.openPayoutDashboard(r.id); if (x.url) window.open(x.url, '_blank', 'noopener'); })} loading={busy === 'dash'}><ExternalLink className="h-4 w-4" /> Dashboard Stripe</Button>}
            </div>
          </div>
        )}
      </Panel>
      <Panel title="Come funziona">
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-ink-soft">
          <li>Il cliente paga online; l’importo, meno la commissione AsiaFood, viene trasferito al tuo conto Stripe.</li>
          <li>La commissione è calcolata su subtotale − sconti + consegna, ed è indicata su ogni ordine.</li>
          <li>Rimborsi: vengono stornati dal tuo conto (insieme alla quota di commissione corrispondente).</li>
          <li>AsiaFood non emette fatture per tuo conto: la ricevuta dell’ordine non è un documento fiscale.</li>
        </ul>
      </Panel>
    </div>
  );
}

// ─── Statistiche ordini (nessun dato personale) ─────────────────
export function OrderStatsPanel({ restaurantId, days }: { restaurantId: string; days: number }) {
  const s = useAsync(() => api.getRestaurantOrderStats(restaurantId, days).catch(() => null), [restaurantId, days]);
  const d = s.data;
  if (!d || d.orders === 0) return null;
  return (
    <Panel title="Ordini online" description="Solo ordini validi (pagati e non annullati). Nessun dato personale dei clienti.">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile accent label="Ordini" value={d.orders} />
        <StatTile label="Incasso lordo" value={formatPrice(d.gross)} />
        <StatTile label="Netto stimato" value={formatPrice(d.net_estimated)} hint={`Commissioni ${formatPrice(d.commission)}`} />
        <StatTile label="Scontrino medio" value={formatPrice(d.aov)} />
      </div>
      <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
        <div className="flex justify-between"><dt className="text-ink-muted">Ritiro / Consegna</dt><dd className="font-semibold tabular-nums">{d.takeaway} / {d.delivery}</dd></div>
        <div className="flex justify-between"><dt className="text-ink-muted">Tasso di annullamento</dt><dd className="font-semibold tabular-nums">{(d.cancel_rate * 100).toFixed(1)}%</dd></div>
        <div className="flex justify-between"><dt className="text-ink-muted">Clienti che tornano</dt><dd className="font-semibold tabular-nums">{d.repeat_customers} su {d.customers}</dd></div>
        <div className="flex justify-between"><dt className="text-ink-muted">Ordini con coupon</dt><dd className="font-semibold tabular-nums">{d.coupon_orders}</dd></div>
        <div className="flex justify-between"><dt className="text-ink-muted">Rimborsato</dt><dd className="font-semibold tabular-nums">{formatPrice(d.refunded)}</dd></div>
        <div className="flex justify-between"><dt className="text-ink-muted">Preparazione media</dt><dd className="font-semibold tabular-nums">{d.avg_prep_minutes != null ? `${Math.round(d.avg_prep_minutes)} min` : '—'}</dd></div>
      </dl>
      {d.top_items.length > 0 && (
        <div className="mt-4">
          <p className="mb-2 text-sm font-semibold">Piatti più ordinati</p>
          <ol className="space-y-1 text-sm">
            {d.top_items.slice(0, 5).map((t, i) => (
              <li key={t.name} className="flex justify-between"><span>{i + 1}. {t.name}</span><span className="tabular-nums text-ink-muted">{t.quantity} · {formatPrice(t.revenue)}</span></li>
            ))}
          </ol>
        </div>
      )}
    </Panel>
  );
}

