import { useEffect, useRef, useState, type FormEvent } from 'react';
import { CreditCard, FlaskConical, Lock } from 'lucide-react';
import type { Stripe, StripeElements } from '@stripe/stripe-js';
import { ORDERS } from '@/config/app';
import { formatPrice } from '@/lib/format';
import { api } from '@/services';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Layout';

/**
 * Pagamento dell'ordine.
 * - DEMO: pagamento SIMULATO (nessun addebito, nessun dato di carta salvato o inviato).
 * - Supabase + Stripe: Payment Element di Stripe (i dati della carta vanno solo a Stripe).
 *   L'ordine risulta pagato SOLO quando arriva il webhook: qui si mostra solo l'esito lato cliente.
 */
export function OrderPayment({ orderNumber, token, total, clientSecret, onPaid }: {
  orderNumber: string;
  token: string | null;
  total: number;
  clientSecret: string | null;
  onPaid: () => void;
}) {
  if (ORDERS.simulated) return <DemoCardForm orderNumber={orderNumber} token={token} total={total} onPaid={onPaid} />;
  if (!clientSecret || !ORDERS.stripePublishableKey) {
    return <Alert tone="error">Il pagamento online non è disponibile in questo momento. Nessun addebito è stato effettuato.</Alert>;
  }
  return <StripePaymentForm orderNumber={orderNumber} token={token} total={total} clientSecret={clientSecret} onPaid={onPaid} />;
}

function DemoCardForm({ orderNumber, token, total, onPaid }: { orderNumber: string; token: string | null; total: number; onPaid: () => void }) {
  const [card, setCard] = useState('4242 4242 4242 4242');
  const [exp, setExp] = useState('12/30');
  const [cvc, setCvc] = useState('123');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      // Solo il numero serve alla simulazione (carte di prova Stripe); scadenza e CVC non vengono usati né salvati
      await api.demoPayOrder(orderNumber, token, card);
      onPaid();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <form onSubmit={submit} className="space-y-4" aria-describedby="demo-pay-note">
      <p id="demo-pay-note" className="flex items-start gap-2 rounded-2xl bg-amber-50 px-4 py-3 text-sm text-amber-900">
        <FlaskConical className="mt-0.5 h-4 w-4 shrink-0" />
        <span><strong>Pagamento simulato (DEMO)</strong> · nessun addebito. Carte di prova: 4242 4242 4242 4242 (riuscito), 4000 0000 0000 0002 (rifiutato).</span>
      </p>
      <label className="block">
        <span className="mb-1 block text-sm font-semibold">Numero carta</span>
        <input inputMode="numeric" autoComplete="off" value={card} onChange={(e) => setCard(e.target.value)} className="h-12 w-full rounded-2xl border border-line bg-white px-4 font-mono tracking-wider focus:border-ink focus:outline-none" aria-invalid={!!error} aria-describedby={error ? 'pay-error' : undefined} />
      </label>
      <div className="grid grid-cols-2 gap-3">
        <label className="block"><span className="mb-1 block text-sm font-semibold">Scadenza</span><input autoComplete="off" value={exp} onChange={(e) => setExp(e.target.value)} className="h-12 w-full rounded-2xl border border-line bg-white px-4 focus:border-ink focus:outline-none" /></label>
        <label className="block"><span className="mb-1 block text-sm font-semibold">CVC</span><input autoComplete="off" inputMode="numeric" value={cvc} onChange={(e) => setCvc(e.target.value)} className="h-12 w-full rounded-2xl border border-line bg-white px-4 focus:border-ink focus:outline-none" /></label>
      </div>
      {error && <p id="pay-error" role="alert" className="rounded-2xl bg-coral-50 px-4 py-3 text-sm font-medium text-coral-700">{error}</p>}
      <Button type="submit" size="lg" className="w-full" loading={busy} data-testid="pay-button"><Lock className="h-4 w-4" /> Paga {formatPrice(total)}</Button>
    </form>
  );
}

function StripePaymentForm({ orderNumber, token, total, clientSecret, onPaid }: { orderNumber: string; token: string | null; total: number; clientSecret: string; onPaid: () => void }) {
  const box = useRef<HTMLDivElement>(null);
  const stripeRef = useRef<Stripe | null>(null);
  const elementsRef = useRef<StripeElements | null>(null);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const { loadStripe } = await import('@stripe/stripe-js');
        const stripe = await loadStripe(ORDERS.stripePublishableKey, { locale: 'it' });
        if (!alive || !stripe || !box.current) return;
        const elements = stripe.elements({ clientSecret, appearance: { theme: 'stripe', variables: { colorPrimary: '#16161A', borderRadius: '14px' } } });
        const pe = elements.create('payment', { layout: 'tabs' });
        pe.mount(box.current);
        pe.on('ready', () => alive && setReady(true));
        stripeRef.current = stripe;
        elementsRef.current = elements;
      } catch {
        if (alive) setError('Impossibile caricare il modulo di pagamento. Controlla la connessione e riprova.');
      }
    })();
    return () => {
      alive = false;
    };
  }, [clientSecret]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const stripe = stripeRef.current;
    const elements = elementsRef.current;
    if (!stripe || !elements || busy) return;
    setBusy(true);
    setError(null);
    const returnUrl = `${window.location.origin}/orders/${orderNumber}${token ? `?t=${encodeURIComponent(token)}` : ''}`;
    const res = await stripe.confirmPayment({ elements, confirmParams: { return_url: returnUrl }, redirect: 'if_required' });
    setBusy(false);
    if (res.error) {
      setError(res.error.type === 'card_error' || res.error.type === 'validation_error' ? res.error.message ?? 'Pagamento non riuscito.' : 'Pagamento non riuscito. Riprova tra poco.');
      return;
    }
    // Lo stato "pagato" lo conferma il webhook: la pagina dell'ordine si aggiorna da sola
    onPaid();
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <p className="flex items-center gap-2 text-sm text-ink-muted"><CreditCard className="h-4 w-4" /> Pagamento sicuro con Stripe{ORDERS.mode === 'test' ? ' · modalità TEST' : ''}. AsiaFood non vede né salva i dati della carta.</p>
      <div ref={box} className="min-h-[120px]" />
      {error && <p role="alert" className="rounded-2xl bg-coral-50 px-4 py-3 text-sm font-medium text-coral-700">{error}</p>}
      <Button type="submit" size="lg" className="w-full" loading={busy} disabled={!ready} data-testid="pay-button"><Lock className="h-4 w-4" /> Paga {formatPrice(total)}</Button>
    </form>
  );
}
