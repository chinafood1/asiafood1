import { useEffect, useMemo, useState } from 'react';
import { Minus, Plus } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { cn, formatPrice } from '@/lib/format';
import { ALLERGEN_BY_CODE } from '@/lib/menu';
import { api } from '@/services';
import type { AllergenCode, MenuItemFull } from '@/types/domain';
import type { MenuOptionGroup } from '@/types/orders';
import { Button } from '@/components/ui/Button';
import { Sheet } from '@/components/ui/Sheet';
import { SmartImage } from '@/components/ui/SmartImage';
import { useToast } from '@/components/ui/Toast';
import { sumMoney } from '@shared/money';

/**
 * Personalizzazione del piatto: variante, scelte (base, proteina, salse), extra, quantità e note.
 * Il prezzo mostrato è indicativo: il server lo ricalcola al carrello e al checkout.
 */
export function ProductSheet({ item, groups, restaurant, onClose }: {
  item: MenuItemFull | null;
  groups: MenuOptionGroup[];
  restaurant: { id: string; name: string; slug: string };
  onClose: () => void;
}) {
  const cart = useCart();
  const toast = useToast();
  const [variant, setVariant] = useState<string | null>(null);
  const [addons, setAddons] = useState<Record<string, boolean>>({});
  const [choices, setChoices] = useState<Record<string, string[]>>({});
  const [qty, setQty] = useState(1);
  const [notes, setNotes] = useState('');
  const [tried, setTried] = useState(false);

  const variants = useMemo(() => item?.variants.filter((v) => v.is_available) ?? [], [item]);
  const extras = useMemo(() => item?.addons.filter((a) => a.is_available) ?? [], [item]);
  const myGroups = useMemo(() => groups.filter((g) => g.menu_item_id === item?.id && g.is_active), [groups, item]);

  useEffect(() => {
    if (!item) return;
    setVariant(variants.length === 1 ? variants[0]!.id : null);
    setAddons({});
    setChoices({});
    setQty(1);
    setNotes('');
    setTried(false);
    void api.track(item.restaurant_id, 'menu_item_view', 'web', { item: item.id });
  }, [item, variants]);

  if (!item) return <Sheet open={false} onClose={onClose} title="">{null}</Sheet>;

  const v = variants.find((x) => x.id === variant);
  const base = v?.price ?? (item.discount_price != null && item.price != null && item.discount_price < item.price ? item.discount_price : item.price) ?? 0;
  const extrasTotal = sumMoney([
    ...extras.filter((a) => addons[a.id]).map((a) => a.price ?? 0),
    ...myGroups.flatMap((g) => g.options.filter((o) => (choices[g.id] ?? []).includes(o.id)).map((o) => o.price)),
  ]);
  const unit = sumMoney([base, extrasTotal]);
  const missingVariant = variants.length > 0 && !v;
  const groupErrors = myGroups.filter((g) => {
    const n = (choices[g.id] ?? []).length;
    return n < Math.max(g.min_select, g.required ? 1 : 0) || n > g.max_select;
  });

  const toggleChoice = (g: MenuOptionGroup, id: string) => {
    setChoices((c) => {
      const cur = c[g.id] ?? [];
      if (g.max_select === 1) return { ...c, [g.id]: cur.includes(id) && !g.required ? [] : [id] };
      if (cur.includes(id)) return { ...c, [g.id]: cur.filter((x) => x !== id) };
      if (cur.length >= g.max_select) return c;
      return { ...c, [g.id]: [...cur, id] };
    });
  };

  const add = () => {
    setTried(true);
    if (missingVariant || groupErrors.length) return;
    const res = cart.add(restaurant, {
      menu_item_id: item.id, name: item.name, image_url: item.image_url, variant_id: v?.id ?? null, variant_name: v?.name ?? null,
      addons: extras.filter((a) => addons[a.id]).map((a) => ({ id: a.id, name: a.name, price: a.price ?? 0, quantity: 1 })),
      options: myGroups.flatMap((g) => g.options.filter((o) => (choices[g.id] ?? []).includes(o.id)).map((o) => ({ id: o.id, group: g.name, name: o.name, price: o.price }))),
      quantity: qty, notes: notes.trim() || null, unit_price: unit,
    });
    if (res === 'added') toast(`${item.name} aggiunto al carrello`);
    onClose();
  };

  return (
    <Sheet open={!!item} onClose={onClose} title={item.name}
      footer={
        <div className="flex items-center gap-3">
          <div className="flex items-center rounded-full border border-line" role="group" aria-label="Quantità">
            <button type="button" aria-label="Diminuisci quantità" onClick={() => setQty((q) => Math.max(1, q - 1))} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-cream"><Minus className="h-4 w-4" /></button>
            <span className="w-8 text-center font-semibold tabular-nums" aria-live="polite">{qty}</span>
            <button type="button" aria-label="Aumenta quantità" onClick={() => setQty((q) => Math.min(20, q + 1))} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-cream"><Plus className="h-4 w-4" /></button>
          </div>
          <Button className="flex-1" size="lg" onClick={add} data-testid="add-to-cart">Aggiungi · {formatPrice(unit * qty)}</Button>
        </div>
      }
    >
      <div className="space-y-5">
        {item.image_url && <SmartImage src={item.image_url} alt={item.name} className="h-44 w-full rounded-3xl" />}
        {item.description && <p className="text-ink-soft">{item.description}</p>}
        {item.allergens.length > 0 && (
          <p className="text-xs text-ink-muted">
            <strong>Allergeni:</strong> {item.allergens.map((a) => ALLERGEN_BY_CODE[a as AllergenCode]?.name ?? a).join(', ')}. Per allergie contatta il ristorante.
          </p>
        )}

        {variants.length > 0 && (
          <fieldset>
            <legend className="mb-2 font-semibold">Formato <span className="text-sm font-normal text-coral-700">· obbligatorio</span></legend>
            <div className="grid gap-2">
              {variants.map((x) => (
                <label key={x.id} className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border p-3', variant === x.id ? 'border-ink bg-cream' : 'border-line')}>
                  <input type="radio" name="variant" className="h-4 w-4 accent-coral" checked={variant === x.id} onChange={() => setVariant(x.id)} />
                  <span className="flex-1">{x.name}</span>
                  {x.price != null && <span className="font-semibold tabular-nums">{formatPrice(x.price)}</span>}
                </label>
              ))}
            </div>
            {tried && missingVariant && <p role="alert" className="mt-1 text-sm text-coral-700">Scegli un formato.</p>}
          </fieldset>
        )}

        {myGroups.map((g) => {
          const multi = g.max_select > 1;
          const sel = choices[g.id] ?? [];
          const bad = tried && groupErrors.includes(g);
          const hint = g.required || g.min_select > 0 ? (multi ? `scegli da ${Math.max(1, g.min_select)} a ${g.max_select}` : 'obbligatorio') : multi ? `facoltativo, max ${g.max_select}` : 'facoltativo';
          return (
            <fieldset key={g.id} aria-describedby={bad ? `err-${g.id}` : undefined}>
              <legend className="mb-2 font-semibold">{g.name} <span className={cn('text-sm font-normal', g.required ? 'text-coral-700' : 'text-ink-muted')}>· {hint}</span></legend>
              <div className="grid gap-2">
                {g.options.map((o) => {
                  const on = sel.includes(o.id);
                  return (
                    <label key={o.id} className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border p-3', on ? 'border-ink bg-cream' : 'border-line')}>
                      <input type={multi ? 'checkbox' : 'radio'} name={`g-${g.id}`} className="h-4 w-4 accent-coral" checked={on} onChange={() => toggleChoice(g, o.id)} />
                      <span className="flex-1">{o.name}</span>
                      {o.price > 0 && <span className="text-sm tabular-nums text-ink-muted">+{formatPrice(o.price)}</span>}
                    </label>
                  );
                })}
              </div>
              {bad && <p id={`err-${g.id}`} role="alert" className="mt-1 text-sm text-coral-700">Completa la scelta «{g.name}».</p>}
            </fieldset>
          );
        })}

        {extras.length > 0 && (
          <fieldset>
            <legend className="mb-2 font-semibold">Extra <span className="text-sm font-normal text-ink-muted">· facoltativi</span></legend>
            <div className="grid gap-2">
              {extras.map((a) => (
                <label key={a.id} className={cn('flex cursor-pointer items-center gap-3 rounded-2xl border p-3', addons[a.id] ? 'border-ink bg-cream' : 'border-line')}>
                  <input type="checkbox" className="h-4 w-4 accent-coral" checked={!!addons[a.id]} onChange={(e) => setAddons({ ...addons, [a.id]: e.target.checked })} />
                  <span className="flex-1">{a.name}</span>
                  {a.price != null && <span className="text-sm tabular-nums text-ink-muted">+{formatPrice(a.price)}</span>}
                </label>
              ))}
            </div>
          </fieldset>
        )}

        <label className="block">
          <span className="mb-1 block font-semibold">Note per la cucina <span className="text-sm font-normal text-ink-muted">· facoltative</span></span>
          <textarea value={notes} maxLength={200} rows={2} onChange={(e) => setNotes(e.target.value)} placeholder="Es. senza cipolla" className="w-full rounded-2xl border border-line bg-white px-4 py-3 text-[15px] focus:border-ink focus:outline-none" />
        </label>
        <p className="text-xs text-ink-faint">Il prezzo finale viene confermato dal ristorante al checkout.</p>
      </div>
    </Sheet>
  );
}
