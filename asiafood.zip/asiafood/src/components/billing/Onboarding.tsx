import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check, Circle, Lock, PartyPopper, Rocket } from 'lucide-react';
import { useState } from 'react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { billingErrorMessage, COMPLETION_LABELS, planName } from '@/lib/billing';
import { FEATURES, requiredPlanFor, type FeatureKey } from '@/lib/entitlements';
import { cn } from '@/lib/format';
import { api } from '@/services';
import type { CompletionKey, ProfileCompletion } from '@/types/domain';
import { Badge } from '@/components/ui/Badge';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { Panel, type EditorTabProps } from '@/components/editor/form';
import { AyceSection, CategoriesSection, ContactsSection, HoursSection, ImagesSection, InfoSection, MenuSection, PricesSection, ServicesSection } from '@/components/editor/sections';
import { ChoosePlan } from './BillingSection';

/** Sezione dell'editor da cui completare ciascuna voce. */
const ITEM_SECTION: Record<CompletionKey, string> = {
  name: 'profilo', phone: 'profilo', address: 'profilo', logo: 'foto', cover: 'foto', hours: 'orari', categories: 'profilo',
  menu: 'menu', photos: 'foto', offer: 'offerte', reservations: 'reservations',
};

export function ProgressBar({ value, label }: { value: number; label?: string }) {
  return (
    <div>
      <div className="flex items-center justify-between text-sm">
        <span className="font-semibold">{label}</span>
        <span className="font-bold tabular-nums" data-testid="completion-pct">{value}%</span>
      </div>
      <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-line" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={value} aria-label={label ?? 'Avanzamento'}>
        <div className="h-full rounded-full bg-leaf transition-all" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

/** "Completa il tuo profilo": percentuale calcolata dai dati reali (mai un valore manuale). */
export function ProfileChecklist({ restaurantId, base, compact, data }: { restaurantId: string; base: string; compact?: boolean; data?: ProfileCompletion | null }) {
  const { plans } = useReferenceData();
  const q = useAsync(() => (data ? Promise.resolve(data) : api.getProfileCompletion(restaurantId)), [restaurantId, data]);
  const c = q.data;
  if (!c) return null;
  if (compact) {
    return (
      <div className="rounded-3xl bg-cream p-4">
        <ProgressBar value={c.profile_completion_percentage} label="Completa il tuo profilo" />
        {c.profile_completion_percentage < 100 && <Link to={`${base}/onboarding`} className="mt-2 inline-flex text-sm font-semibold text-coral-700">Continua la configurazione →</Link>}
      </div>
    );
  }
  return (
    <section className="card p-5 sm:p-6" aria-labelledby="checklist-title">
      <h2 id="checklist-title" className="sr-only">Completa il tuo profilo</h2>
      <ProgressBar value={c.profile_completion_percentage} label="Completa il tuo profilo" />
      <ul className="mt-4 grid gap-1.5 sm:grid-cols-2">
        {c.items.map((i) => {
          const locked = !i.available;
          const plan = locked && i.feature ? requiredPlanFor(plans, i.feature as FeatureKey) : undefined;
          return (
            <li key={i.key}>
              <Link
                to={`${base}/${ITEM_SECTION[i.key]}`}
                className={cn('flex items-center gap-2.5 rounded-2xl px-3 py-2 text-sm transition hover:bg-cream', i.done && 'text-ink-muted')}
              >
                {i.done ? <Check className="h-4 w-4 shrink-0 text-leaf" aria-label="Completato" /> : locked ? <Lock className="h-4 w-4 shrink-0 text-ink-faint" aria-label="Non incluso nel piano" /> : <Circle className="h-4 w-4 shrink-0 text-ink-faint" aria-label="Da completare" />}
                <span className={cn('flex-1', i.done && 'line-through decoration-ink-faint/50')}>{COMPLETION_LABELS[i.key]}</span>
                {locked && plan && <Badge tone="outline">{plan.name}</Badge>}
              </Link>
            </li>
          );
        })}
      </ul>
      <p className="mt-3 text-xs text-ink-muted">Le voci con il lucchetto non sono incluse nel piano attuale e non contano nella percentuale.</p>
    </section>
  );
}

const STEPS = ['Informazioni attività', 'Logo e cover', 'Orari', 'Categorie', 'Menu', 'Servizi', 'Scegli piano', 'Pubblica'] as const;

/** Onboarding guidato in 8 passi (/dashboard/restaurants/:id/onboarding?step=N). */
export function OnboardingWizard(p: EditorTabProps & { base: string }) {
  const { r, base, reload } = p;
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const toast = useToast();
  const { plans } = useReferenceData();
  const step = Math.min(Math.max(Number(params.get('step') ?? 1) || 1, 1), STEPS.length);
  const completion = useAsync(() => api.getProfileCompletion(r.id), [r.id, step]);
  const overview = useAsync(() => (step === 7 ? api.getBillingOverview(r.id) : Promise.resolve(null)), [r.id, step]);
  const [busy, setBusy] = useState(false);
  const go = (n: number) => {
    setParams({ step: String(n) }, { replace: false });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const pct = Math.round((step / STEPS.length) * 100);
  const has = (k: FeatureKey) => !!plans.find((x) => x.code === r.subscription_plan)?.plan_features.find((f) => f.feature_key === k)?.enabled;

  const finish = async () => {
    setBusy(true);
    try {
      if (!r.is_active) {
        const res = await api.requestPublication(r.id);
        toast(res === 'requested' ? 'Richiesta di pubblicazione inviata allo staff' : res === 'already_requested' ? 'Richiesta già inviata: lo staff la sta verificando' : 'La scheda è online');
      }
      await api.completeOnboarding(r.id);
      reload();
      navigate(`${base}/panoramica`);
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  };

  let body: React.ReactNode;
  switch (step) {
    case 1:
      body = <div className="space-y-6"><InfoSection {...p} /><ContactsSection {...p} /></div>;
      break;
    case 2:
      body = <ImagesSection {...p} />;
      break;
    case 3:
      body = <HoursSection {...p} />;
      break;
    case 4:
      body = <CategoriesSection {...p} />;
      break;
    case 5:
      body = has('menu_enabled') ? (
        <MenuSection {...p} />
      ) : (
        <Panel title="Menu digitale" description={`Il menu digitale è incluso da ${requiredPlanFor(plans, 'menu_enabled')?.name ?? 'Business'}. Puoi attivarlo al passo 7 o saltare questo passo.`}>
          <p className="text-sm text-ink-muted">{FEATURES.menu_enabled.description}.</p>
        </Panel>
      );
      break;
    case 6:
      body = <div className="space-y-6"><ServicesSection {...p} /><PricesSection {...p} /><AyceSection {...p} /></div>;
      break;
    case 7:
      body = overview.loading ? (
        <PageLoader />
      ) : overview.data?.stripe && ['trialing', 'active', 'past_due'].includes(overview.data.stripe.status) ? (
        <Panel title="Il tuo piano">
          <p>Piano attivo: <strong>{planName(plans, overview.data.effective_plan)}</strong>. Puoi cambiarlo quando vuoi da <Link to={`${base}/billing`} className="font-semibold text-coral-700">Fatturazione</Link>.</p>
        </Panel>
      ) : (
        <div className="space-y-4">
          <Alert>Puoi restare sul piano <strong>Free</strong>: la scheda resta pubblica. Scegli un piano solo se ti servono menu, prenotazioni, coupon o statistiche.</Alert>
          {overview.data?.can_manage_billing !== false && (
            <ChoosePlan restaurantId={r.id} currentPlan={overview.data?.effective_plan ?? r.subscription_plan} trialDays={overview.data?.trial_eligible ? overview.data.trial_days : 0} plans={plans} compact />
          )}
        </div>
      );
      break;
    default:
      body = (
        <div className="space-y-6">
          <Panel title={r.is_active ? 'La tua scheda è online' : 'Pubblica la scheda'} description={r.is_active ? 'Controlla le ultime voci e completa la configurazione.' : 'Lo staff verifica i dati principali e pubblica la scheda. Riceverai una notifica.'}>
            <div className="flex items-center gap-3">
              {r.is_active ? <PartyPopper className="h-8 w-8 text-coral" /> : <Rocket className="h-8 w-8 text-coral" />}
              <p className="text-[15px]">{r.is_active ? <>La scheda è visibile su <a href={`/ristorante/${r.slug}`} target="_blank" rel="noreferrer" className="font-semibold text-coral-700">/ristorante/{r.slug}</a>.</> : completion.data?.publication_requested_at ? 'Richiesta di pubblicazione già inviata.' : 'Servono almeno telefono e indirizzo.'}</p>
            </div>
          </Panel>
          <ProfileChecklist restaurantId={r.id} base={base} data={completion.data} />
        </div>
      );
  }

  return (
    <div className="space-y-6">
      <div className="card p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-semibold text-ink-muted">Configurazione guidata · passo {step} di {STEPS.length}</p>
          {completion.data && <p className="text-sm text-ink-muted">Profilo completo al <strong className="text-ink">{completion.data.profile_completion_percentage}%</strong></p>}
        </div>
        <h2 className="mt-1 text-2xl font-extrabold" data-testid="onboarding-step">{STEPS[step - 1]}</h2>
        <div className="mt-3"><ProgressBar value={pct} label="Avanzamento" /></div>
        <ol className="scrollbar-none mt-4 flex gap-1.5 overflow-x-auto" aria-label="Passi">
          {STEPS.map((s, i) => (
            <li key={s}>
              <button type="button" onClick={() => go(i + 1)} aria-current={i + 1 === step ? 'step' : undefined}
                className={cn('whitespace-nowrap rounded-full border px-3 py-1.5 text-xs font-semibold transition', i + 1 === step ? 'border-ink bg-ink text-white' : i + 1 < step ? 'border-line bg-cream text-ink' : 'border-line bg-white text-ink-muted')}>
                {i + 1}. {s}
              </button>
            </li>
          ))}
        </ol>
      </div>

      {body}

      <div className="sticky bottom-3 z-10 flex items-center justify-between gap-3 rounded-full border border-line bg-white/95 p-2 shadow-lg backdrop-blur sm:static sm:rounded-none sm:border-0 sm:bg-transparent sm:p-0 sm:shadow-none">
        <Button variant="ghost" disabled={step === 1} onClick={() => go(step - 1)} icon={<ArrowLeft className="h-4 w-4" />}>Indietro</Button>
        {step < STEPS.length ? (
          <Button onClick={() => go(step + 1)}>Avanti <ArrowRight className="h-4 w-4" /></Button>
        ) : (
          <Button loading={busy} onClick={finish}>{r.is_active ? 'Completa configurazione' : 'Invia per la pubblicazione'}</Button>
        )}
      </div>
      <p className="text-center text-xs text-ink-muted">Ricorda di salvare ogni sezione prima di andare avanti. <ButtonLink to={`${base}/panoramica`} variant="ghost" size="sm">Esci dalla guida</ButtonLink></p>
    </div>
  );
}
