import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CalendarClock, CreditCard, FlaskConical, RefreshCw, RotateCcw, Settings2, XCircle } from 'lucide-react';
import { BILLING } from '@/config/app';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { billingErrorMessage, billingNotice, daysUntil, formatDay, INTERVAL_LABEL, planName, planPrice, SUBSCRIPTION_SOURCE } from '@/lib/billing';
import { formatPrice } from '@/lib/format';
import { api } from '@/services';
import type { BillingInterval, PlanWithFeatures } from '@/types/domain';
import { Button, ButtonLink } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { CANCELLATION_REASONS } from '@/types/launch';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { Panel, type EditorTabProps } from '@/components/editor/form';
import { ActivityList, BillingModeBadge, BillingNoticeBanner, ChangePlanSheet, IntervalToggle, InvoicesTable, PlanCards, SubscriptionStatusBadge } from './BillingUI';
import { safeAssign } from '@/lib/safeRedirect';

const LIVE = ['trialing', 'active', 'past_due', 'unpaid', 'paused'];

/** /dashboard/restaurants/:id/billing — abbonamento del locale. Lettura dal DB sincronizzato. */
export function BillingSection({ r, reload }: EditorTabProps) {
  const { plans } = useReferenceData();
  const toast = useToast();
  const navigate = useNavigate();
  const ov = useAsync(() => api.getBillingOverview(r.id), [r.id]);
  const [changeOpen, setChangeOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  // Fase 12: motivo della disdetta, sempre facoltativo (non impedisce mai la cancellazione)
  const [cancelReason, setCancelReason] = useState('');
  const [cancelNote, setCancelNote] = useState('');
  const [busy, setBusy] = useState<string | null>(null);

  if (ov.loading && !ov.data) return <PageLoader />;
  if (ov.error || !ov.data) return <Alert tone="error">Impossibile caricare la fatturazione. Riprova tra poco.</Alert>;
  const o = ov.data;
  const s = o.stripe && LIVE.includes(o.stripe.status) ? o.stripe : null;
  const eff = o.effective;
  const refresh = () => {
    ov.reload();
    reload();
  };
  const run = async (key: string, fn: () => Promise<unknown>, ok?: string) => {
    setBusy(key);
    try {
      await fn();
      if (ok) toast(ok);
      refresh();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setBusy(null);
    }
  };
  const portal = async (flow?: 'payment_method_update') => {
    setBusy(flow ?? 'portal');
    try {
      const { url } = await api.openBillingPortal(r.id, flow ?? null);
      if (url.startsWith('/')) navigate(url);
      else safeAssign(url);
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
      setBusy(null);
    }
  };
  const notice = billingNotice(o, plans);
  const price = s ? (s.unit_amount_cents != null ? s.unit_amount_cents / 100 : planPrice(plans, s.plan_code, s.billing_interval)) : 0;
  const trialLeft = s?.status === 'trialing' ? daysUntil(s.trial_end) : null;

  return (
    <div className="space-y-6">
      <BillingNoticeBanner notice={notice} restaurantId={r.id} />

      <Panel
        title="Piano attuale"
        description={<span className="inline-flex flex-wrap items-center gap-2">Lo stato arriva da Stripe tramite webhook: nessun pagamento è considerato riuscito finché Stripe non lo conferma. <BillingModeBadge /></span>}
      >
        <div className="grid gap-5 md:grid-cols-[1fr_auto]">
          <dl className="grid gap-x-8 gap-y-3 text-sm sm:grid-cols-2">
            <div>
              <dt className="text-ink-muted">Piano</dt>
              <dd className="mt-0.5 flex items-center gap-2 text-2xl font-extrabold" data-testid="current-plan">{planName(plans, o.effective_plan)}</dd>
            </div>
            <div>
              <dt className="text-ink-muted">Stato</dt>
              <dd className="mt-1">{s ? <SubscriptionStatusBadge status={s.status} /> : eff && eff.source !== 'stripe' ? <SubscriptionStatusBadge status="active" /> : <SubscriptionStatusBadge status="free" />}</dd>
            </div>
            {s ? (
              <>
                <div>
                  <dt className="text-ink-muted">Prezzo</dt>
                  <dd className="mt-0.5 font-semibold">{formatPrice(price)} {s.billing_interval === 'year' ? '/anno' : '/mese'} <span className="font-normal text-ink-muted">· {INTERVAL_LABEL[s.billing_interval]}</span></dd>
                </div>
                <div>
                  <dt className="text-ink-muted">{s.cancel_at_period_end ? 'Attivo fino al' : s.status === 'trialing' ? 'Fine prova' : 'Prossimo rinnovo'}</dt>
                  <dd className="mt-0.5 font-semibold">{formatDay(s.status === 'trialing' ? s.trial_end : s.current_period_end)}</dd>
                </div>
                {trialLeft !== null && (
                  <div>
                    <dt className="text-ink-muted">Prova residua</dt>
                    <dd className="mt-0.5 font-semibold" data-testid="trial-left">{trialLeft} {trialLeft === 1 ? 'giorno' : 'giorni'}</dd>
                  </div>
                )}
                <div>
                  <dt className="text-ink-muted">Metodo di pagamento</dt>
                  <dd className="mt-0.5 font-semibold">
                    {s.pm_last4 ? (
                      <span className="inline-flex flex-wrap items-center gap-x-1.5 whitespace-nowrap"><CreditCard className="h-4 w-4" /> <span className="capitalize">{s.pm_brand}</span> <span>•••• {s.pm_last4}</span>{s.pm_exp_month ? <span className="font-normal text-ink-muted"> · scad. {String(s.pm_exp_month).padStart(2, '0')}/{String(s.pm_exp_year).slice(-2)}</span> : null}</span>
                    ) : (
                      <span className="text-ink-muted">Nessuno {s.status === 'trialing' ? '(prova senza carta)' : ''}</span>
                    )}
                  </dd>
                </div>
                {s.scheduled_plan_code && (
                  <div className="sm:col-span-2">
                    <dt className="text-ink-muted">Cambio programmato</dt>
                    <dd className="mt-0.5 font-semibold">Il tuo piano passerà a {planName(plans, s.scheduled_plan_code)}{s.scheduled_interval ? ` (${INTERVAL_LABEL[s.scheduled_interval].toLowerCase()})` : ''} il {formatDay(s.scheduled_change_at)}.</dd>
                  </div>
                )}
              </>
            ) : eff && eff.source !== 'stripe' ? (
              <div className="sm:col-span-2">
                <dt className="text-ink-muted">Origine</dt>
                <dd className="mt-0.5">{SUBSCRIPTION_SOURCE[eff.source]} — piano assegnato dallo staff{eff.expires_at ? ` fino al ${formatDay(eff.expires_at)}` : ''}. Nessun addebito tramite Stripe.</dd>
              </div>
            ) : (
              <div className="sm:col-span-2">
                <dt className="text-ink-muted">Cosa include</dt>
                <dd className="mt-0.5">Profilo base, presenza nella ricerca e sulla mappa, telefono, orari e categorie. La scheda Free può restare pubblica.</dd>
              </div>
            )}
          </dl>
          {s && o.can_manage_billing && (
            <div className="flex flex-col gap-2 md:w-56">
              <Button onClick={() => setChangeOpen(true)} icon={<Settings2 className="h-4 w-4" />}>Cambia piano</Button>
              <Button variant="outline" loading={busy === 'portal'} onClick={() => portal()} icon={<CreditCard className="h-4 w-4" />}>Gestisci pagamento</Button>
              {s.scheduled_plan_code && (
                <Button variant="outline" loading={busy === 'unschedule'} onClick={() => run('unschedule', () => api.cancelScheduledChange(r.id), 'Cambio programmato annullato')} icon={<RotateCcw className="h-4 w-4" />}>Annulla cambio programmato</Button>
              )}
              {s.cancel_at_period_end ? (
                <Button variant="dark" loading={busy === 'resume'} onClick={() => run('resume', () => api.resumeSubscription(r.id), 'Abbonamento riattivato')} icon={<RotateCcw className="h-4 w-4" />}>Riattiva abbonamento</Button>
              ) : (
                <Button variant="danger" onClick={() => setCancelOpen(true)} icon={<XCircle className="h-4 w-4" />}>Cancella abbonamento</Button>
              )}
            </div>
          )}
        </div>
        {!o.can_manage_billing && <p className="mt-4 text-sm text-ink-muted">Solo il titolare può modificare l’abbonamento e i pagamenti.</p>}
      </Panel>

      {!s && o.can_manage_billing && <ChoosePlan restaurantId={r.id} currentPlan={o.effective_plan} trialDays={o.trial_eligible ? o.trial_days : 0} plans={plans} />}

      <Panel
        title="Fatture"
        description="Importi IVA esclusa, fatture emesse da Stripe. Il PDF si scarica da Stripe (non viene salvato sui nostri server)."
        footer={
          s || o.invoices.length ? (
            <>
              <Button variant="ghost" size="sm" loading={busy === 'invoices'} onClick={() => run('invoices', () => api.refreshInvoices(r.id), 'Fatture aggiornate')} icon={<RefreshCw className="h-4 w-4" />}>Aggiorna</Button>
              {o.can_manage_billing && <Button variant="outline" size="sm" onClick={() => portal()}>Dati di fatturazione e storico completo</Button>}
            </>
          ) : undefined
        }
      >
        <InvoicesTable invoices={o.invoices} />
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Cronologia"><ActivityList items={o.activity} /></Panel>
        <Panel title="Dati di fatturazione" description="Ragione sociale, P.IVA, codice destinatario e PEC valgono per tutti i tuoi locali.">
          <ButtonLink variant="outline" to="/dashboard/billing">Modifica dati di fatturazione</ButtonLink>
        </Panel>
      </div>

      {api.mode === 'demo' && s && <DemoSimulator restaurantId={r.id} status={s.status} onDone={refresh} />}

      {s && (
        <>
          <ChangePlanSheet open={changeOpen} onClose={() => setChangeOpen(false)} restaurantId={r.id} currentPlan={s.plan_code} currentInterval={s.billing_interval} onDone={refresh} />
          <Sheet
            open={cancelOpen}
            onClose={() => setCancelOpen(false)}
            title="Cancella abbonamento"
            footer={
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setCancelOpen(false)}>Mantieni {planName(plans, s.plan_code)}</Button>
                <Button
                  variant="danger"
                  loading={busy === 'cancel'}
                  onClick={() => run('cancel', async () => {
                    if (cancelReason || cancelNote.trim()) void api.launch.submitFeedback({ type: 'cancellation', restaurant_id: r.id, reason: cancelReason || null, message: cancelNote.trim() || null, page: 'billing' }).catch(() => undefined);
                    await api.cancelSubscription(r.id);
                    setCancelOpen(false);
                  }, 'Cancellazione programmata a fine periodo')}
                >
                  Conferma cancellazione
                </Button>
              </div>
            }
          >
            <div className="space-y-3 text-[15px]">
              <p>Potrai continuare a usare <strong>{planName(plans, s.plan_code)}</strong> fino al <strong>{formatDay(s.status === 'trialing' ? s.trial_end : s.current_period_end)}</strong>. Nessun altro addebito.</p>
              <p className="text-ink-muted">Dopo questa data il locale torna al piano Free: la scheda resta pubblica, le funzioni a pagamento (es. prenotazioni, coupon) si disattivano. Puoi riattivare l’abbonamento prima della scadenza con un clic.</p>
              <Field label="Vuoi dirci perché? (facoltativo)">
                <Select value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} data-testid="cancel-reason">
                  <option value="">Preferisco non dirlo</option>
                  {Object.entries(CANCELLATION_REASONS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </Select>
              </Field>
              <Textarea rows={2} value={cancelNote} onChange={(e) => setCancelNote(e.target.value)} placeholder="Un suggerimento per migliorare (facoltativo)" aria-label="Suggerimento facoltativo" />
            </div>
          </Sheet>
        </>
      )}
    </div>
  );
}

/** Nessun abbonamento Stripe attivo: scelta del piano → checkout. */
export function ChoosePlan({ restaurantId, currentPlan, trialDays, plans, compact }: { restaurantId: string; currentPlan: string; trialDays: number; plans: PlanWithFeatures[]; compact?: boolean }) {
  const toast = useToast();
  const navigate = useNavigate();
  const [interval, setInterval] = useState<BillingInterval>('month');
  const [busyCode, setBusyCode] = useState<string | null>(null);
  const [promo, setPromo] = useState('');
  const [showPromo, setShowPromo] = useState(false);
  if (!BILLING.enabled) {
    return (
      <Panel title="Scegli un piano" description="I pagamenti online arriveranno a breve.">
        <ButtonLink to={`/dashboard/plans?restaurant=${restaurantId}`}>Scopri i piani</ButtonLink>
      </Panel>
    );
  }
  const start = async (code: string) => {
    setBusyCode(code);
    try {
      const { url } = await api.startCheckout({ restaurant_id: restaurantId, plan: code as PlanWithFeatures['code'], billing_interval: interval, promotion_code: promo.trim() || null });
      if (url.startsWith('/')) navigate(url);
      else safeAssign(url);
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
      setBusyCode(null);
    }
  };
  return (
    <Panel title="Scegli un piano" description={trialDays ? `Prova gratuita di ${trialDays} giorni sui piani a pagamento. Puoi cancellare quando vuoi.` : 'Pagamento sicuro con Stripe. Puoi cancellare quando vuoi.'}>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <IntervalToggle value={interval} onChange={setInterval} plans={plans} />
        {showPromo ? (
          <Field className="w-52"><Input aria-label="Codice promozionale" placeholder="Codice promo" value={promo} onChange={(e) => setPromo(e.target.value.toUpperCase())} maxLength={30} /></Field>
        ) : (
          <button type="button" className="text-sm font-semibold text-coral-700" onClick={() => setShowPromo(true)}>Hai un codice promozionale?</button>
        )}
      </div>
      <PlanCards
        plans={plans}
        interval={interval}
        current={currentPlan as PlanWithFeatures['code']}
        trialDays={trialDays}
        busyCode={busyCode}
        compact={compact}
        onSelect={(p) => start(p.code)}
        ctaLabel={(p) => (p.code === 'free' || p.code === currentPlan ? null : trialDays && p.trial_enabled !== false ? `Prova ${p.name} gratis` : `Passa a ${p.name}`)}
      />
      <p className="mt-3 text-xs text-ink-muted">Prezzi IVA esclusa. Verrai reindirizzato alla pagina di pagamento sicura di Stripe; il piano si attiva quando Stripe conferma l’operazione.</p>
    </Panel>
  );
}

/** Solo DEMO: simula quello che in produzione fanno il tempo, la banca o il cliente su Stripe. */
function DemoSimulator({ restaurantId, status, onDone }: { restaurantId: string; status: string; onDone: () => void }) {
  const toast = useToast();
  const act = async (action: Parameters<NonNullable<typeof api.simulateBilling>>[0], label: string) => {
    try {
      await api.simulateBilling!(action, { restaurantId });
      toast(label);
      onDone();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    }
  };
  return (
    <Panel title="Simulazioni (solo modalità DEMO)" description="In produzione questi eventi arrivano da Stripe tramite webhook.">
      <div className="flex flex-wrap gap-2">
        {status === 'trialing' && <Button size="sm" variant="soft" icon={<FlaskConical className="h-4 w-4" />} onClick={() => act('end_trial', 'Fine prova simulata')}>Simula fine prova</Button>}
        {status === 'active' && <Button size="sm" variant="soft" icon={<FlaskConical className="h-4 w-4" />} onClick={() => act('fail_payment', 'Pagamento fallito simulato')}>Simula pagamento fallito</Button>}
        {(status === 'past_due' || status === 'unpaid') && <Button size="sm" variant="soft" icon={<FlaskConical className="h-4 w-4" />} onClick={() => act('pay_invoice', 'Pagamento recuperato')}>Simula pagamento riuscito</Button>}
        <Button size="sm" variant="soft" icon={<CalendarClock className="h-4 w-4" />} onClick={() => act('reach_period_end', 'Fine periodo simulata')}>Simula fine periodo</Button>
      </div>
      <p className="mt-3 text-xs text-ink-muted">Nessun addebito reale. <Link to="/admin/system/stripe" className="font-semibold">Registro eventi</Link> visibile all’Admin.</p>
    </Panel>
  );
}
