import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ArrowRight, Check, Clock, CreditCard, Download, ExternalLink, FileText, Minus, Sparkles } from 'lucide-react';
import { BILLING } from '@/config/app';
import { useReferenceData } from '@/context/ReferenceDataContext';
import {
  ACTIVITY_LABELS,
  billingErrorMessage,
  formatCents,
  formatDay,
  formatDayShort,
  INTERVAL_LABEL,
  planPrice,
  SUBSCRIPTION_STATUS,
  yearlySaving,
  type BillingNotice,
} from '@/lib/billing';
import { FEATURE_ORDER, FEATURES, featureValueLabel } from '@/lib/entitlements';
import { cn, formatPrice } from '@/lib/format';
import { api } from '@/services';
import type { BillingActivity, BillingInterval, BillingInvoice, ChangePreview, PlanCode, PlanWithFeatures, SubscriptionStatus } from '@/types/domain';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { safeAssign } from '@/lib/safeRedirect';

export function SubscriptionStatusBadge({ status }: { status: SubscriptionStatus }) {
  const s = SUBSCRIPTION_STATUS[status] ?? SUBSCRIPTION_STATUS.free;
  return <Badge tone={s.tone} className="whitespace-nowrap">{s.label}</Badge>;
}

/** Etichetta ambiente: in test nessun addebito reale; in demo tutto è simulato. */
export function BillingModeBadge() {
  if (BILLING.simulated) return <Badge tone="amber">Pagamenti simulati (DEMO)</Badge>;
  if (BILLING.mode === 'test') return <Badge tone="amber">Stripe in modalità test</Badge>;
  return null;
}

// ─── Avvisi (pagamento fallito, fine prova, cancellazione, cambio programmato) ───
export function BillingNoticeBanner({ notice, restaurantId, compact }: { notice: BillingNotice | null; restaurantId: string; compact?: boolean }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (!notice) return null;
  const openPortal = async () => {
    setBusy(true);
    try {
      const { url } = await api.openBillingPortal(restaurantId, 'payment_method_update');
      safeAssign(url);
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
      setBusy(false);
    }
  };
  const billingLink = `/dashboard/restaurants/${restaurantId}/billing`;
  const box = (tone: 'coral' | 'amber' | 'neutral', icon: React.ReactNode, title: string, text: string, action: React.ReactNode) => (
    <div
      role={tone === 'coral' ? 'alert' : 'status'}
      className={cn(
        'flex flex-wrap items-center gap-3 rounded-3xl border px-4 py-3',
        tone === 'coral' ? 'border-coral-200 bg-coral-50' : tone === 'amber' ? 'border-amber-200 bg-amber-50' : 'border-line bg-cream',
        compact && 'py-2.5',
      )}
    >
      <span className="shrink-0">{icon}</span>
      <div className="min-w-0 flex-1">
        <p className="font-semibold">{title}</p>
        {!compact && <p className="text-sm text-ink-soft">{text}</p>}
      </div>
      {action}
    </div>
  );
  switch (notice.kind) {
    case 'payment_failed':
      return box(
        'coral',
        <AlertTriangle className="h-5 w-5 text-coral-700" />,
        'Problema con il pagamento del tuo abbonamento.',
        `Aggiorna il metodo di pagamento per continuare a usare ${notice.plan}.${notice.until ? ` Le funzioni restano attive fino al ${formatDay(notice.until)}.` : ''}`,
        <Button size="sm" loading={busy} onClick={openPortal} icon={<CreditCard className="h-4 w-4" />}>Aggiorna metodo di pagamento</Button>,
      );
    case 'trial_expiring':
      return box(
        'amber',
        <Clock className="h-5 w-5 text-amber-700" />,
        notice.days === 0 ? `La prova ${notice.plan} termina oggi.` : `Mancano ${notice.days} ${notice.days === 1 ? 'giorno' : 'giorni'} alla fine della prova ${notice.plan}.`,
        notice.hasPaymentMethod
          ? `Alla fine della prova l’abbonamento si attiva automaticamente con il metodo di pagamento salvato.`
          : `Aggiungi un metodo di pagamento per non perdere le funzioni ${notice.plan}.`,
        notice.hasPaymentMethod ? (
          <Link to={billingLink} className="inline-flex h-9 items-center gap-1 rounded-full bg-ink px-4 text-sm font-semibold text-white">Gestisci <ArrowRight className="h-4 w-4" /></Link>
        ) : (
          <Button size="sm" loading={busy} onClick={openPortal}>Continua con {notice.plan}</Button>
        ),
      );
    case 'cancel_scheduled':
      return box(
        'neutral',
        <Clock className="h-5 w-5 text-ink-muted" />,
        `Potrai continuare a usare ${notice.plan} fino al ${formatDay(notice.until)}.`,
        'Dopo questa data il locale torna al piano Free. Puoi riattivare l’abbonamento in qualsiasi momento prima della scadenza.',
        <Link to={billingLink} className="inline-flex h-9 items-center gap-1 rounded-full border border-line bg-white px-4 text-sm font-semibold hover:border-ink">Riattiva abbonamento</Link>,
      );
    case 'change_scheduled':
      return box(
        'neutral',
        <Clock className="h-5 w-5 text-ink-muted" />,
        `Il tuo piano passerà a ${notice.to} il ${formatDay(notice.at)}.`,
        `Fino ad allora mantieni tutte le funzioni ${notice.plan} già pagate.`,
        <Link to={billingLink} className="inline-flex h-9 items-center gap-1 rounded-full border border-line bg-white px-4 text-sm font-semibold hover:border-ink">Dettagli</Link>,
      );
  }
}

// ─── Scelta piano (dashboard, fatturazione, onboarding) ───
export function IntervalToggle({ value, onChange, plans }: { value: BillingInterval; onChange: (v: BillingInterval) => void; plans: PlanWithFeatures[] }) {
  const maxSaving = Math.max(0, ...plans.map((p) => yearlySaving(plans, p.code)));
  return (
    <div className="flex items-center gap-1.5" role="group" aria-label="Periodo di fatturazione">
      <Chip active={value === 'month'} onClick={() => onChange('month')} className="!h-9">Mensile</Chip>
      <Chip active={value === 'year'} onClick={() => onChange('year')} className="!h-9">
        Annuale{maxSaving ? <span className={cn('ml-1 text-xs font-bold', value === 'year' ? 'text-white/80' : 'text-leaf')}>−{maxSaving}%</span> : null}
      </Chip>
    </div>
  );
}

export function PlanCards({
  plans,
  interval,
  current,
  trialDays,
  onSelect,
  busyCode,
  ctaLabel,
  compact,
}: {
  plans: PlanWithFeatures[];
  interval: BillingInterval;
  current?: PlanCode | null;
  trialDays?: number;
  onSelect?: (p: PlanWithFeatures) => void;
  busyCode?: string | null;
  ctaLabel?: (p: PlanWithFeatures) => string | null;
  compact?: boolean;
}) {
  const active = plans.filter((p) => p.is_active).sort((a, b) => a.sort_order - b.sort_order);
  return (
    <div className={cn('grid gap-4', compact ? 'sm:grid-cols-2 xl:grid-cols-4' : 'sm:grid-cols-2 xl:grid-cols-4')}>
      {active.map((p) => {
        const price = planPrice(plans, p.code, interval);
        const isCurrent = p.code === current;
        const label = ctaLabel ? ctaLabel(p) : null;
        const saving = interval === 'year' ? yearlySaving(plans, p.code) : 0;
        return (
          <div
            key={p.code}
            data-plan={p.code}
            className={cn(
              'flex flex-col rounded-4xl border p-5',
              isCurrent ? 'border-ink bg-ink text-white' : p.code === 'premium' ? 'border-coral bg-white ring-1 ring-coral' : 'border-line bg-white',
            )}
          >
            <div className="flex items-center justify-between gap-2">
              <p className="text-lg font-bold">{p.name}</p>
              {isCurrent ? <Badge tone="glass">Piano attuale</Badge> : p.code === 'premium' ? <Badge tone="coral" icon={<Sparkles className="h-3.5 w-3.5" />}>Consigliato</Badge> : null}
            </div>
            <p className="mt-3 font-display text-3xl font-extrabold tabular-nums">
              {price ? formatPrice(price) : 'Gratis'}
              <span className="text-sm font-medium opacity-60">{price ? (interval === 'year' ? ' /anno' : ' /mese') : ''}</span>
            </p>
            <p className={cn('mt-1 h-5 text-xs', isCurrent ? 'text-white/70' : 'text-ink-muted')}>
              {price && interval === 'year' ? `${formatPrice(price / 12)} al mese${saving ? ` · risparmi ${saving}%` : ''}` : price ? 'IVA esclusa' : ''}
            </p>
            {!compact && <p className={cn('mt-2 text-sm', isCurrent ? 'text-white/75' : 'text-ink-muted')}>{p.description}</p>}
            {trialDays && price && p.trial_enabled !== false && !isCurrent ? (
              <p className={cn('mt-3 text-sm font-semibold', isCurrent ? 'text-white' : 'text-leaf')}>{trialDays} giorni di prova gratuita</p>
            ) : null}
            <div className="mt-auto pt-5">
              {label && onSelect ? (
                <Button
                  variant={p.code === 'premium' ? 'primary' : 'outline'}
                  className="w-full"
                  loading={busyCode === p.code}
                  disabled={!!busyCode}
                  onClick={() => onSelect(p)}
                >
                  {label}
                </Button>
              ) : null}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/** Tabella di confronto: righe = funzioni (dal DB), colonne = piani. */
export function PlanComparisonTable({ plans, current }: { plans: PlanWithFeatures[]; current?: string | null }) {
  const active = plans.filter((p) => p.is_active).sort((a, b) => a.sort_order - b.sort_order);
  const groups = Array.from(new Set(FEATURE_ORDER.map((k) => FEATURES[k].group)));
  return (
    <div className="overflow-x-auto rounded-4xl border border-line bg-white">
      <table className="w-full min-w-[640px] text-left text-sm">
        <caption className="sr-only">Confronto delle funzioni per piano</caption>
        <thead>
          <tr className="border-b border-line">
            <th scope="col" className="px-4 py-3 font-semibold">Funzione</th>
            {active.map((p) => <th scope="col" key={p.code} className={cn('px-4 py-3 text-center font-bold', p.code === current && 'bg-cream')}>{p.name}</th>)}
          </tr>
        </thead>
        {groups.map((g) => (
          <tbody key={g}>
            <tr><th colSpan={active.length + 1} scope="colgroup" className="bg-paper px-4 pb-1 pt-4 text-xs font-bold uppercase tracking-wider text-ink-muted">{g}</th></tr>
            {FEATURE_ORDER.filter((k) => FEATURES[k].group === g).map((k) => (
              <tr key={k} className="border-t border-line">
                <th scope="row" className="px-4 py-2.5 font-normal">
                  <span className="font-medium">{FEATURES[k].label}</span>
                  <span className="block text-xs text-ink-muted">{FEATURES[k].description}</span>
                </th>
                {active.map((p) => {
                  const v = featureValueLabel(plans, p.code, k);
                  return (
                    <td key={p.code} className={cn('px-4 py-2.5 text-center', p.code === current && 'bg-cream/60')}>
                      {v === true ? <Check className="mx-auto h-5 w-5 text-leaf" aria-label="Incluso" /> : v === false ? <Minus className="mx-auto h-4 w-4 text-ink-faint" aria-label="Non incluso" /> : <span className="font-semibold">{v}</span>}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        ))}
      </table>
    </div>
  );
}

// ─── Cambio piano: anteprima (addebito o data) + conferma ───
export function ChangePlanSheet({
  open,
  onClose,
  restaurantId,
  currentPlan,
  currentInterval,
  onDone,
}: {
  open: boolean;
  onClose: () => void;
  restaurantId: string;
  currentPlan: PlanCode;
  currentInterval: BillingInterval;
  onDone: () => void;
}) {
  const { plans } = useReferenceData();
  const toast = useToast();
  const [interval, setInterval] = useState<BillingInterval>(currentInterval);
  const [target, setTarget] = useState<PlanCode | null>(null);
  const [preview, setPreview] = useState<ChangePreview | null>(null);
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const paid = plans.filter((p) => p.is_active && p.code !== 'free');

  const choose = async (p: PlanWithFeatures) => {
    setLoading(p.code);
    setError(null);
    try {
      setTarget(p.code);
      setPreview(await api.previewPlanChange(restaurantId, p.code, interval));
    } catch (e) {
      setError(billingErrorMessage(e));
      setTarget(null);
    } finally {
      setLoading(null);
    }
  };
  const confirm = async () => {
    if (!target) return;
    setLoading('confirm');
    setError(null);
    try {
      const r = await api.changePlan(restaurantId, target, interval);
      toast(r.status === 'scheduled' ? `Cambio programmato per il ${formatDayShort(r.effective_at)}` : 'Piano aggiornato');
      setPreview(null);
      setTarget(null);
      onDone();
      onClose();
    } catch (e) {
      setError(billingErrorMessage(e));
    } finally {
      setLoading(null);
    }
  };
  const reset = () => {
    setPreview(null);
    setTarget(null);
    setError(null);
  };

  return (
    <Sheet
      open={open}
      onClose={() => { reset(); onClose(); }}
      title="Cambia piano"
      footer={
        preview ? (
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={reset}>Indietro</Button>
            <Button loading={loading === 'confirm'} onClick={confirm}>{preview.immediate ? 'Conferma cambio' : 'Programma il cambio'}</Button>
          </div>
        ) : undefined
      }
    >
      <div className="space-y-4">
        {error && <Alert tone="error">{error}</Alert>}
        {!preview ? (
          <>
            <IntervalToggle value={interval} onChange={setInterval} plans={plans} />
            <ul className="space-y-2">
              {paid.sort((a, b) => a.sort_order - b.sort_order).map((p) => {
                const same = p.code === currentPlan && interval === currentInterval;
                return (
                  <li key={p.code}>
                    <button
                      type="button"
                      disabled={same || !!loading}
                      onClick={() => choose(p)}
                      className={cn('flex w-full items-center justify-between gap-3 rounded-3xl border px-4 py-3 text-left transition', same ? 'border-ink bg-cream' : 'border-line bg-white hover:border-ink disabled:opacity-60')}
                    >
                      <span>
                        <span className="font-bold">{p.name}</span>
                        {same && <span className="ml-2 text-xs font-semibold text-ink-muted">piano attuale</span>}
                        <span className="block text-sm text-ink-muted">{formatPrice(planPrice(plans, p.code, interval))} {interval === 'year' ? '/anno' : '/mese'}</span>
                      </span>
                      {loading === p.code ? <span className="text-sm text-ink-muted">Calcolo…</span> : !same && <ArrowRight className="h-5 w-5 text-ink-muted" />}
                    </button>
                  </li>
                );
              })}
            </ul>
            <p className="text-xs text-ink-muted">Upgrade: attivo subito, con addebito proporzionale ai giorni restanti. Downgrade e passaggio da annuale a mensile: dal prossimo rinnovo, senza perdere le funzioni già pagate.</p>
          </>
        ) : (
          <ChangeSummary preview={preview} currentInterval={currentInterval} />
        )}
      </div>
    </Sheet>
  );
}

function ChangeSummary({ preview, currentInterval }: { preview: ChangePreview; currentInterval: BillingInterval }) {
  const { target } = preview;
  return (
    <div className="space-y-3">
      <div className="rounded-3xl border border-line p-4">
        <p className="text-sm text-ink-muted">Nuovo piano</p>
        <p className="text-xl font-bold">{target.plan_name} · {INTERVAL_LABEL[target.interval]}</p>
        <p className="text-sm text-ink-muted">{formatPrice(target.amount)} {target.interval === 'year' ? '/anno' : '/mese'} (IVA esclusa){target.interval !== currentInterval ? ' · cambia il periodo di fatturazione' : ''}</p>
      </div>
      {preview.immediate ? (
        <div className="rounded-3xl bg-cream p-4" data-testid="change-charge">
          {preview.trialing ? (
            <p><strong>Nessun addebito ora:</strong> sei in prova. Il nuovo piano vale da subito e verrà addebitato a fine prova.</p>
          ) : preview.amount_due_cents > 0 ? (
            <p>
              <strong>Addebito {preview.charged_now === false ? 'nella prossima fattura' : 'oggi'}: {formatCents(preview.amount_due_cents, preview.currency)}</strong>
              <span className="block text-sm text-ink-muted">Importo proporzionale ai giorni restanti del periodo in corso, al netto di quanto già pagato.</span>
            </p>
          ) : (
            <p><strong>Nessun addebito aggiuntivo ora.</strong></p>
          )}
        </div>
      ) : (
        <div className="rounded-3xl bg-cream p-4" data-testid="change-scheduled">
          <p><strong>Il tuo piano passerà a {target.plan_name} il {formatDay(preview.effective_at)}.</strong></p>
          <p className="text-sm text-ink-muted">Fino ad allora mantieni tutte le funzioni già pagate. Nessun addebito oggi.</p>
        </div>
      )}
    </div>
  );
}

// ─── Fatture e cronologia ───
export function InvoicesTable({ invoices }: { invoices: BillingInvoice[] }) {
  if (!invoices.length) return <p className="text-sm text-ink-muted">Nessuna fattura ancora. Durante la prova gratuita non vengono emesse fatture.</p>;
  return (
    <div className="-mx-2 overflow-x-auto">
      <table className="w-full min-w-[520px] text-left text-sm">
        <thead>
          <tr className="text-xs uppercase tracking-wider text-ink-muted">
            <th className="px-2 py-2 font-semibold">Data</th>
            <th className="px-2 py-2 font-semibold">Numero</th>
            <th className="px-2 py-2 font-semibold">Stato</th>
            <th className="px-2 py-2 text-right font-semibold">Importo</th>
            <th className="px-2 py-2 text-right font-semibold"><span className="sr-only">Azioni</span></th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((i) => (
            <tr key={i.id} className="border-t border-line">
              <td className="whitespace-nowrap px-2 py-2.5">{formatDay(i.stripe_created_at)}</td>
              <td className="px-2 py-2.5 font-mono text-xs">{i.number ?? '—'}</td>
              <td className="px-2 py-2.5">
                <Badge tone={i.status === 'paid' ? 'green' : i.status === 'open' ? 'coral' : 'neutral'}>
                  {i.status === 'paid' ? 'Pagata' : i.status === 'open' ? 'Da pagare' : i.status === 'void' ? 'Annullata' : i.status === 'uncollectible' ? 'Non riscossa' : i.status}
                </Badge>
              </td>
              <td className="whitespace-nowrap px-2 py-2.5 text-right tabular-nums">{formatCents(i.status === 'paid' ? i.amount_paid_cents : i.amount_due_cents, i.currency)}</td>
              <td className="whitespace-nowrap px-2 py-2.5 text-right">
                {i.invoice_pdf ? (
                  <a href={i.invoice_pdf} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold text-coral-700 hover:underline"><Download className="h-4 w-4" /> Scarica fattura</a>
                ) : i.hosted_invoice_url ? (
                  <a href={i.hosted_invoice_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold text-coral-700 hover:underline">{i.status === 'open' ? 'Paga ora' : 'Apri'} <ExternalLink className="h-3.5 w-3.5" /></a>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs text-ink-faint"><FileText className="h-3.5 w-3.5" /> DEMO, nessun PDF</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function ActivityList({ items }: { items: BillingActivity[] }) {
  if (!items.length) return <p className="text-sm text-ink-muted">Nessun evento.</p>;
  return (
    <ol className="space-y-2">
      {items.map((a, i) => (
        <li key={i} className="flex items-start gap-3 text-sm">
          <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-ink-faint" />
          <span className="min-w-0 flex-1">{ACTIVITY_LABELS[a.event] ?? a.event}</span>
          <time className="shrink-0 text-xs text-ink-muted" dateTime={a.created_at}>{new Date(a.created_at).toLocaleString('it-IT', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</time>
        </li>
      ))}
    </ol>
  );
}
