import { useState } from 'react';
import { Megaphone } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { CAMPAIGN_STATUS, formatDayShort, PLACEMENT_LABELS } from '@/lib/billing';
import { cn, formatPrice } from '@/lib/format';
import { api } from '@/services';
import type { CampaignStats } from '@/types/domain';
import { Badge, Chip } from '@/components/ui/Badge';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { Panel, type EditorTabProps } from '@/components/editor/form';

const RANGES = [7, 30, 90] as const;

export function CampaignStatsTable({ rows, showRestaurant, actions }: { rows: CampaignStats[]; showRestaurant?: boolean; actions?: (c: CampaignStats) => React.ReactNode }) {
  return (
    <div className="-mx-2 overflow-x-auto">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead>
          <tr className="text-xs uppercase tracking-wider text-ink-muted">
            <th className="px-2 py-2 font-semibold">Campagna</th>
            {showRestaurant && <th className="px-2 py-2 font-semibold">Ristorante</th>}
            <th className="px-2 py-2 font-semibold">Stato</th>
            <th className="px-2 py-2 font-semibold">Periodo</th>
            <th className="px-2 py-2 text-right font-semibold">Impression</th>
            <th className="px-2 py-2 text-right font-semibold">Click</th>
            <th className="px-2 py-2 text-right font-semibold">CTR</th>
            <th className="px-2 py-2 text-right font-semibold">Spesa</th>
            {actions && <th className="px-2 py-2"><span className="sr-only">Azioni</span></th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((c) => (
            <tr key={c.campaign_id} className="border-t border-line">
              <td className="px-2 py-2.5">
                <p className="font-semibold">{c.name}</p>
                <p className="text-xs text-ink-muted">{PLACEMENT_LABELS[c.placement]} · priorità {c.priority}</p>
              </td>
              {showRestaurant && <td className="px-2 py-2.5">{c.restaurant_name}</td>}
              <td className="px-2 py-2.5"><Badge tone={CAMPAIGN_STATUS[c.display_status].tone}>{CAMPAIGN_STATUS[c.display_status].label}</Badge></td>
              <td className="whitespace-nowrap px-2 py-2.5 text-ink-muted">{formatDayShort(c.start_date)} → {c.end_date ? formatDayShort(c.end_date) : 'senza scadenza'}</td>
              <td className="px-2 py-2.5 text-right tabular-nums">{c.impressions}</td>
              <td className="px-2 py-2.5 text-right tabular-nums">{c.clicks}</td>
              <td className="px-2 py-2.5 text-right tabular-nums">{c.impressions ? `${Number(c.ctr).toLocaleString('it-IT', { maximumFractionDigits: 2 })}%` : '—'}</td>
              <td className="whitespace-nowrap px-2 py-2.5 text-right tabular-nums">
                {formatPrice(Number(c.spend))}
                {c.total_budget != null && <span className="block text-xs text-ink-muted">su {formatPrice(Number(c.total_budget))}</span>}
              </td>
              {actions && <td className="whitespace-nowrap px-2 py-2.5 text-right">{actions(c)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** /dashboard/restaurants/:id/ads — campagne del locale (piano Top). Dati reali: impression e click registrati. */
export function AdsSection({ r }: EditorTabProps) {
  const [days, setDays] = useState<(typeof RANGES)[number]>(30);
  const stats = useAsync(() => api.getCampaignStats(r.id, days), [r.id, days]);
  if (stats.loading && !stats.data) return <PageLoader />;
  const rows = stats.data ?? [];
  const tot = rows.reduce((a, c) => ({ i: a.i + Number(c.impressions), c: a.c + Number(c.clicks), s: a.s + Number(c.spend) }), { i: 0, c: 0, s: 0 });
  return (
    <div className="space-y-6">
      <Panel
        title="Sponsorizzazioni"
        description="Le campagne sono gestite dallo staff AsiaFood. Ogni posizione sponsorizzata è etichettata come “Sponsorizzato” ed è separata dai risultati organici. La spesa è fatturata a parte (nessun addebito automatico)."
      >
        <div className="mb-4 flex gap-1.5" role="group" aria-label="Periodo">
          {RANGES.map((d) => <Chip key={d} active={days === d} onClick={() => setDays(d)} className="!h-9">{d} giorni</Chip>)}
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            ['Impression', tot.i.toLocaleString('it-IT')],
            ['Click', tot.c.toLocaleString('it-IT')],
            ['CTR', tot.i ? `${((tot.c * 100) / tot.i).toLocaleString('it-IT', { maximumFractionDigits: 2 })}%` : '—'],
            ['Spesa', formatPrice(tot.s)],
          ].map(([l, v]) => (
            <div key={l} className="rounded-3xl bg-cream px-4 py-3">
              <p className="text-xs font-semibold uppercase tracking-wider text-ink-muted">{l}</p>
              <p className={cn('mt-1 font-display text-2xl font-extrabold tabular-nums')}>{v}</p>
            </div>
          ))}
        </div>
      </Panel>
      <Panel title="Campagne">
        {rows.length === 0 ? (
          <EmptyState icon={<Megaphone className="h-8 w-8 text-ink-faint" />} title="Nessuna campagna" text="Contatta lo staff per attivare una sponsorizzazione in home, ricerca, mappa o offerte." />
        ) : (
          <CampaignStatsTable rows={rows} />
        )}
        <p className="mt-3 text-xs text-ink-muted">Impression: card sponsorizzata visibile almeno per metà per un secondo, contata al massimo una volta ogni 30 minuti per sessione. Nessun fingerprint.</p>
      </Panel>
    </div>
  );
}
