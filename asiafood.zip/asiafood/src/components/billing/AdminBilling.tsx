import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { billingErrorMessage, formatDay, INTERVAL_LABEL, PLACEMENT_LABELS, planName, SUBSCRIPTION_SOURCE } from '@/lib/billing';
import { api } from '@/services';
import type { CampaignStatus, PlanCode, SponsoredCampaign, SponsoredPlacement } from '@/types/domain';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { Panel, type EditorTabProps } from '@/components/editor/form';
import { ActivityList, SubscriptionStatusBadge } from './BillingUI';
import { CampaignStatsTable } from './Ads';

/** Link alla dashboard Stripe (test/live) per un oggetto. */
export function stripeDashboardUrl(kind: 'subscriptions' | 'customers' | 'events', id: string, env: 'test' | 'live' | null) {
  return `https://dashboard.stripe.com/${env === 'live' ? '' : 'test/'}${kind}/${id}`;
}

/** Form "Concedi piano manuale" (nessuna finta subscription Stripe). */
export function GrantPlanForm({ restaurantId, onDone }: { restaurantId: string; onDone: () => void }) {
  const { plans } = useReferenceData();
  const toast = useToast();
  const [plan, setPlan] = useState<PlanCode>('premium');
  const [until, setUntil] = useState('');
  const [source, setSource] = useState<'manual' | 'admin' | 'promo'>('manual');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const grant = async () => {
    setBusy(true);
    try {
      await api.adminGrantPlan(restaurantId, plan, until ? new Date(`${until}T23:59:00`).toISOString() : null, source, note.trim() || null);
      toast(plan === 'free' ? 'Concessioni manuali revocate' : `Piano ${planName(plans, plan)} concesso`);
      setNote('');
      onDone();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <Field label="Piano">
        <Select value={plan} onChange={(e) => setPlan(e.target.value as PlanCode)}>
          {plans.filter((p) => p.is_active).sort((a, b) => a.sort_order - b.sort_order).map((p) => <option key={p.code} value={p.code}>{p.name}{p.code === 'free' ? ' (revoca concessioni)' : ''}</option>)}
        </Select>
      </Field>
      <Field label="Scadenza" hint="Vuoto = senza scadenza"><Input type="date" value={until} min={new Date(Date.now() + 86_400_000).toISOString().slice(0, 10)} onChange={(e) => setUntil(e.target.value)} /></Field>
      <Field label="Origine">
        <Select value={source} onChange={(e) => setSource(e.target.value as typeof source)}>
          <option value="manual">Manuale (accordo commerciale)</option>
          <option value="promo">Promozione</option>
          <option value="admin">Admin</option>
        </Select>
      </Field>
      <Field label="Nota interna"><Input value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} placeholder="Es. pagamento con bonifico" /></Field>
      <div className="sm:col-span-2"><Button loading={busy} onClick={grant}>{plan === 'free' ? 'Revoca piano manuale' : 'Concedi piano'}</Button></div>
    </div>
  );
}

/** Editor Admin → Abbonamento: stato reale, concessioni manuali, cronologia. */
export function AdminSubscriptionSection({ r, reload }: EditorTabProps) {
  const { plans } = useReferenceData();
  const toast = useToast();
  const ov = useAsync(() => api.getBillingOverview(r.id), [r.id]);
  const subs = useAsync(() => api.adminListSubscriptions({}).then((l) => l.filter((s) => s.restaurant_id === r.id)), [r.id]);
  const refresh = () => {
    ov.reload();
    subs.reload();
    reload();
  };
  const revoke = async (id: string) => {
    try {
      await api.adminRevokePlan(id);
      toast('Piano revocato');
      refresh();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    }
  };
  return (
    <div className="space-y-6">
      <Panel title="Piano effettivo" description="Deriva dagli abbonamenti: Stripe (fonte autorevole per i pagamenti) o concessioni manuali. Non si imposta a mano.">
        <p className="text-2xl font-extrabold">{planName(plans, ov.data?.effective_plan ?? r.subscription_plan)}</p>
        <Link to={`/admin/subscriptions?q=${encodeURIComponent(r.name)}`} className="mt-2 inline-flex text-sm font-semibold text-coral-700">Vedi in Abbonamenti →</Link>
      </Panel>
      <Panel title="Abbonamenti e concessioni">
        {(subs.data ?? []).length === 0 ? (
          <p className="text-sm text-ink-muted">Nessun abbonamento: il locale è sul piano Free.</p>
        ) : (
          <ul className="divide-y divide-line">
            {subs.data!.map((s) => (
              <li key={s.id} className="flex flex-wrap items-center gap-3 py-3 text-sm">
                <span className="min-w-0 flex-1">
                  <strong>{planName(plans, s.plan_code)}</strong> · {SUBSCRIPTION_SOURCE[s.source]}{s.source === 'stripe' ? ` · ${INTERVAL_LABEL[s.billing_interval]}` : ''}
                  <span className="block text-xs text-ink-muted">
                    {s.source === 'stripe' ? `Rinnovo/fine: ${formatDay(s.status === 'trialing' ? s.trial_end : s.current_period_end)}` : s.expires_at ? `Scade il ${formatDay(s.expires_at)}` : 'Senza scadenza'}
                    {s.revoked_at ? ` · revocato il ${formatDay(s.revoked_at)}` : ''}
                  </span>
                </span>
                <SubscriptionStatusBadge status={s.revoked_at ? 'canceled' : s.status} />
                {s.source === 'stripe' && s.stripe_subscription_id && (
                  <a href={stripeDashboardUrl('subscriptions', s.stripe_subscription_id, s.stripe_environment)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs font-semibold text-ink-muted hover:text-ink">Stripe <ExternalLink className="h-3 w-3" /></a>
                )}
                {s.source !== 'stripe' && !s.revoked_at && s.status === 'active' && <Button size="sm" variant="danger" onClick={() => revoke(s.id)}>Revoca</Button>}
              </li>
            ))}
          </ul>
        )}
      </Panel>
      <Panel title="Concedi piano manuale" description="Per accordi commerciali, promozioni o test. Non crea abbonamenti Stripe e non genera ricavi nell'MRR.">
        <GrantPlanForm restaurantId={r.id} onDone={refresh} />
      </Panel>
      <Panel title="Cronologia fatturazione"><ActivityList items={ov.data?.activity ?? []} /></Panel>
    </div>
  );
}

const STATUSES: CampaignStatus[] = ['draft', 'active', 'paused', 'ended'];
const PLACEMENTS: SponsoredPlacement[] = ['home_featured', 'search_top', 'category_top', 'city_top', 'map_featured', 'offers_featured'];

/** Crea/modifica campagna sponsorizzata (solo Admin; fatturazione Ads manuale). */
export function CampaignSheet({ campaign, onClose, onSaved, restaurantId }: { campaign: Partial<SponsoredCampaign> | null; onClose: () => void; onSaved: () => void; restaurantId?: string }) {
  const { cities, categories } = useReferenceData();
  const toast = useToast();
  const [c, setC] = useState<Partial<SponsoredCampaign>>(campaign ?? {});
  const [busy, setBusy] = useState(false);
  const restaurants = useAsync(() => (restaurantId ? Promise.resolve([]) : api.adminListRestaurants({ pageSize: 500, active: 'yes' }).then((p) => p.rows)), [restaurantId]);
  const set = <K extends keyof SponsoredCampaign>(k: K, v: SponsoredCampaign[K]) => setC((x) => ({ ...x, [k]: v }));
  const save = async () => {
    const rid = restaurantId ?? c.restaurant_id;
    if (!rid || !c.name?.trim()) return toast('Indica ristorante e nome della campagna', 'error');
    if (c.end_date && c.start_date && c.end_date < c.start_date) return toast('La data di fine precede l’inizio', 'error');
    setBusy(true);
    try {
      await api.upsert('sponsored_campaigns', {
        ...(c.id ? { id: c.id } : {}),
        restaurant_id: rid, name: c.name.trim(), status: c.status ?? 'draft', placement: c.placement ?? 'home_featured',
        start_date: c.start_date ?? new Date().toISOString().slice(0, 10), end_date: c.end_date || null,
        daily_budget: c.daily_budget ?? null, total_budget: c.total_budget ?? null, spend: c.spend ?? 0, priority: c.priority ?? 0,
        target_cities: c.target_cities ?? [], target_categories: c.target_categories ?? [], notes: c.notes || null,
      });
      toast('Campagna salvata');
      onSaved();
      onClose();
    } catch (e) {
      toast(billingErrorMessage(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const num = (v: string) => (v.trim() === '' ? null : Math.max(0, Number(v.replace(',', '.'))));
  return (
    <Sheet open={!!campaign} onClose={onClose} title={c.id ? 'Modifica campagna' : 'Nuova campagna'} footer={<div className="flex justify-end gap-3"><Button variant="outline" onClick={onClose}>Annulla</Button><Button loading={busy} onClick={save}>Salva</Button></div>}>
      <div className="grid gap-4">
        {!restaurantId && (
          <Field label="Ristorante">
            <Select value={c.restaurant_id ?? ''} onChange={(e) => set('restaurant_id', e.target.value)}>
              <option value="">Seleziona…</option>
              {(restaurants.data ?? []).map((r) => <option key={r.id} value={r.id}>{r.name}{r.city ? ` · ${r.city.name}` : ''}</option>)}
            </Select>
          </Field>
        )}
        <Field label="Nome campagna"><Input value={c.name ?? ''} onChange={(e) => set('name', e.target.value)} maxLength={120} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Posizionamento">
            <Select value={c.placement ?? 'home_featured'} onChange={(e) => set('placement', e.target.value as SponsoredPlacement)}>
              {PLACEMENTS.map((p) => <option key={p} value={p}>{PLACEMENT_LABELS[p]}</option>)}
            </Select>
          </Field>
          <Field label="Stato">
            <Select value={c.status ?? 'draft'} onChange={(e) => set('status', e.target.value as CampaignStatus)}>
              {STATUSES.map((s) => <option key={s} value={s}>{{ draft: 'Bozza', active: 'Attiva', paused: 'In pausa', ended: 'Terminata', scheduled: 'Programmata' }[s]}</option>)}
            </Select>
          </Field>
          <Field label="Inizio"><Input type="date" value={c.start_date ?? new Date().toISOString().slice(0, 10)} onChange={(e) => set('start_date', e.target.value)} /></Field>
          <Field label="Fine" hint="Vuoto = senza scadenza"><Input type="date" value={c.end_date ?? ''} onChange={(e) => set('end_date', e.target.value || null)} /></Field>
          <Field label="Priorità (0–100)"><Input type="number" min={0} max={100} value={c.priority ?? 0} onChange={(e) => set('priority', Math.min(100, Math.max(0, Number(e.target.value) || 0)))} /></Field>
          <Field label="Spesa registrata (€)" hint="Aggiornata a mano"><Input inputMode="decimal" value={c.spend ?? 0} onChange={(e) => set('spend', num(e.target.value) ?? 0)} /></Field>
          <Field label="Budget giornaliero (€)"><Input inputMode="decimal" value={c.daily_budget ?? ''} onChange={(e) => set('daily_budget', num(e.target.value))} /></Field>
          <Field label="Budget totale (€)" hint="Raggiunto = campagna non più mostrata"><Input inputMode="decimal" value={c.total_budget ?? ''} onChange={(e) => set('total_budget', num(e.target.value))} /></Field>
        </div>
        <Field label="Comuni (vuoto = tutti)">
          <Select multiple className="!h-28" value={c.target_cities ?? []} onChange={(e) => set('target_cities', Array.from(e.target.selectedOptions).map((o) => o.value))}>
            {cities.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </Select>
        </Field>
        <Field label="Categorie (vuoto = tutte)">
          <Select multiple className="!h-28" value={c.target_categories ?? []} onChange={(e) => set('target_categories', Array.from(e.target.selectedOptions).map((o) => o.value))}>
            {categories.map((x) => <option key={x.id} value={x.id}>{x.emoji} {x.name}</option>)}
          </Select>
        </Field>
        <Field label="Note interne"><Textarea rows={2} value={c.notes ?? ''} onChange={(e) => set('notes', e.target.value)} maxLength={500} /></Field>
        <Alert>Le campagne compaiono in spazi dedicati con l’etichetta “Sponsorizzato”, separati dai risultati organici. Budget e spesa non sono mai pubblici; nessun addebito automatico.</Alert>
      </div>
    </Sheet>
  );
}

/** Editor Admin → Sponsorizzazione del singolo locale. */
export function AdminRestaurantCampaigns({ r }: EditorTabProps) {
  const stats = useAsync(() => api.getCampaignStats(null, 30).then((l) => l.filter((c) => c.restaurant_id === r.id)), [r.id]);
  const all = useAsync(() => api.list<SponsoredCampaign>('sponsored_campaigns', { match: { restaurant_id: r.id } }), [r.id]);
  const [editing, setEditing] = useState<Partial<SponsoredCampaign> | null>(null);
  const reload = () => {
    stats.reload();
    all.reload();
  };
  return (
    <Panel title="Campagne sponsorizzate" description="Ultimi 30 giorni: impression e click reali." footer={<Button onClick={() => setEditing({ restaurant_id: r.id, status: 'draft', placement: 'home_featured', priority: 10 })}>Nuova campagna</Button>}>
      {(stats.data ?? []).length === 0 ? (
        <p className="text-sm text-ink-muted">Nessuna campagna.</p>
      ) : (
        <CampaignStatsTable rows={stats.data!} actions={(c) => <Button size="sm" variant="ghost" onClick={() => setEditing(all.data?.find((x) => x.id === c.campaign_id) ?? null)}>Modifica</Button>} />
      )}
      {r.is_sponsored && <p className="mt-3"><Badge tone="outline">Flag “Sponsorizzato” manuale attivo</Badge></p>}
      {editing && <CampaignSheet campaign={editing} restaurantId={r.id} onClose={() => setEditing(null)} onSaved={reload} />}
    </Panel>
  );
}
