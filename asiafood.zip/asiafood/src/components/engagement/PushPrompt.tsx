import { useEffect, useState } from 'react';
import { BellRing, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { dismissPrompt, enablePush, promptDismissed, pushPermission } from '@/lib/push';
import { api } from '@/services';
import { Button } from '@/components/ui/Button';
import { useToast } from '@/components/ui/Toast';

/**
 * Invito contestuale alle notifiche push (mai all'apertura del sito).
 * Se l'utente dice "Non ora" o rifiuta, non viene riproposto.
 */
export function PushPrompt({ text = 'Vuoi ricevere conferme e promemoria delle prenotazioni?', className }: { text?: string; className?: string }) {
  const { user } = useAuth();
  const toast = useToast();
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const perm = pushPermission();
    if (!user || promptDismissed() || perm === 'denied' || perm === 'unsupported') return setShow(false);
    let alive = true;
    void api.getNotificationPrefs().then((p) => alive && setShow(!p.push_enabled && !p.push_prompt_dismissed_at), () => undefined);
    return () => {
      alive = false;
    };
  }, [user]);

  if (!show) return null;
  const enable = async () => {
    setBusy(true);
    const r = await enablePush().catch((e: Error) => ({ ok: false, message: e.message }));
    setBusy(false);
    toast(r.message, r.ok ? undefined : 'error');
    setShow(false);
  };
  return (
    <div className={`flex items-start gap-3 rounded-3xl border border-line bg-white p-4 shadow-card ${className ?? ''}`} role="region" aria-label="Notifiche push">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-coral-50 text-coral-700"><BellRing className="h-5 w-5" /></span>
      <div className="min-w-0 flex-1">
        <p className="font-semibold">{text}</p>
        <p className="text-sm text-ink-muted">Solo comunicazioni utili: puoi scegliere cosa ricevere e disattivarle quando vuoi.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button size="sm" loading={busy} onClick={() => void enable()}>Attiva notifiche</Button>
          <Button size="sm" variant="ghost" onClick={() => { dismissPrompt(); setShow(false); }}>Non ora</Button>
        </div>
      </div>
      <button type="button" aria-label="Chiudi" onClick={() => { dismissPrompt(); setShow(false); }} className="rounded-full p-1.5 text-ink-muted hover:bg-cream"><X className="h-4 w-4" /></button>
    </div>
  );
}
