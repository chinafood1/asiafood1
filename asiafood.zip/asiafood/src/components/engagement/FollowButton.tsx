import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BellPlus, BellRing } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { cn } from '@/lib/format';
import { api } from '@/services';
import { useToast } from '@/components/ui/Toast';

/** "Segui questo ristorante": scelta esplicita per ricevere offerte e novità (mai attivata in automatico). */
export function FollowButton({ restaurantId, restaurantSlug, className }: { restaurantId: string; restaurantSlug: string; className?: string }) {
  const { user } = useAuth();
  const toast = useToast();
  const [following, setFollowing] = useState(false);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!user) return setFollowing(false);
    void api.getFollowState(restaurantId).then((s) => setFollowing(s.following), () => undefined);
  }, [user, restaurantId]);

  const base = 'inline-flex h-10 items-center gap-2 rounded-full border px-4 text-sm font-semibold transition';
  if (!user) {
    return (
      <Link to={`/accedi?next=${encodeURIComponent(`/ristorante/${restaurantSlug}`)}`} className={cn(base, 'border-line bg-white hover:border-ink', className)} title="Ricevi offerte e novità di questo ristorante">
        <BellPlus className="h-4 w-4" /> Segui
      </Link>
    );
  }
  const toggle = async () => {
    setBusy(true);
    try {
      const on = await api.setFollow(restaurantId, !following);
      setFollowing(on);
      toast(on ? 'Ora segui questo ristorante: riceverai offerte e novità (massimo un avviso al giorno).' : 'Non riceverai più avvisi da questo ristorante.');
      window.dispatchEvent(new Event('af:favorites'));
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <button type="button" onClick={() => void toggle()} disabled={busy} aria-pressed={following} title="Ricevi offerte e novità di questo ristorante"
      className={cn(base, following ? 'border-ink bg-ink text-white' : 'border-line bg-white hover:border-ink', className)}>
      {following ? <BellRing className="h-4 w-4" /> : <BellPlus className="h-4 w-4" />}
      {following ? 'Segui già' : 'Segui'}
    </button>
  );
}
