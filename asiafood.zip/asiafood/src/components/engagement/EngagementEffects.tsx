import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { restorePushHandler } from '@/lib/push';
import { api } from '@/services';
import { useToast } from '@/components/ui/Toast';

const REF_KEY = 'af_ref';
const REF_TTL = 30 * 86_400_000;

/** Memorizza il codice invito (30 giorni, solo in questo browser, nessun tracciamento). */
export function storeReferralCode(code: string) {
  try {
    localStorage.setItem(REF_KEY, JSON.stringify({ code: code.toUpperCase().slice(0, 12), at: Date.now() }));
  } catch {
    /* storage non disponibile */
  }
}
export function storedReferralCode(): string | null {
  try {
    const v = JSON.parse(localStorage.getItem(REF_KEY) ?? 'null') as { code: string; at: number } | null;
    if (!v || Date.now() - v.at > REF_TTL) return null;
    return v.code;
  } catch {
    return null;
  }
}
const clearReferral = () => {
  try {
    localStorage.removeItem(REF_KEY);
  } catch {
    /* noop */
  }
};

/**
 * Effetti globali della fidelizzazione:
 *  - attività giornaliera (DAU/WAU/MAU) per utenti registrati;
 *  - attribuzione dell'invito dopo registrazione/accesso (anche dopo redirect);
 *  - click sulle campagne (?cd=…), senza perdere la pagina;
 *  - notifiche in tempo reale (Supabase Realtime, solo le proprie grazie alle RLS).
 */
export function EngagementEffects() {
  const { user } = useAuth();
  const toast = useToast();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => restorePushHandler(), []);

  useEffect(() => {
    if (!user) return;
    const key = `af_activity_${user.id}`;
    const today = new Date().toISOString().slice(0, 10);
    try {
      if (localStorage.getItem(key) === today) return;
      localStorage.setItem(key, today);
    } catch {
      /* noop */
    }
    void api.recordActivity();
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const code = storedReferralCode();
    if (!code) return;
    void api.applyReferralCode(code).then(
      () => {
        clearReferral();
        toast('Invito registrato: riceverete i punti dopo la tua prima visita.');
      },
      (e: Error) => {
        clearReferral();
        if (!/già usato/.test(e.message)) toast(e.message, 'error');
      },
    );
  }, [user, toast]);

  useEffect(() => {
    const p = new URLSearchParams(location.search);
    const cd = p.get('cd');
    if (!cd || !/^[0-9a-f-]{36}$/i.test(cd)) return;
    void api.trackCampaignClick(cd);
    p.delete('cd');
    navigate({ pathname: location.pathname, search: p.toString() ? `?${p}` : '', hash: location.hash }, { replace: true, state: location.state });
  }, [location, navigate]);

  useEffect(() => {
    if (!user || !supabase) return;
    const ch = supabase
      .channel(`notifications:${user.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` }, () => {
        window.dispatchEvent(new Event('af:notifications'));
      })
      .subscribe();
    return () => {
      void supabase?.removeChannel(ch);
    };
  }, [user]);

  return null;
}
