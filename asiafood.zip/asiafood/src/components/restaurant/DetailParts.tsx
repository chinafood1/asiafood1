import { useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { createPortal } from 'react-dom';
import { cn } from '@/lib/format';
import { DAY_NAMES, hoursByDay, shortTime, zonedNow } from '@/lib/hours';
import type { RestaurantHour, RestaurantImage } from '@/types/domain';
import { SmartImage } from '@/components/ui/SmartImage';

export function HoursTable({ hours, tz }: { hours: RestaurantHour[]; tz: string }) {
  const today = zonedNow(tz).day;
  const days = hoursByDay(hours);
  if (!hours.length) return <p className="text-sm text-ink-muted">Orari non ancora comunicati.</p>;
  return (
    <ul className="divide-y divide-line">
      {days.map((d) => (
        <li key={d.day} className={cn('flex justify-between gap-4 py-2.5 text-[15px]', d.day === today && 'font-semibold')}>
          <span className="flex items-center gap-2">
            {d.day === today && <span className="h-1.5 w-1.5 rounded-full bg-coral" />}
            {DAY_NAMES[d.day - 1]}
          </span>
          <span className={cn('flex flex-wrap justify-end gap-x-2 text-right text-[14px] tabular-nums', d.closed && 'text-ink-muted')}>
            {d.closed
              ? 'Chiuso'
              : d.slots.map((s) => (
                  <span key={s.id} className="whitespace-nowrap">
                    {shortTime(s.opens_at)}–{shortTime(s.closes_at)}
                  </span>
                ))}
          </span>
        </li>
      ))}
    </ul>
  );
}

export function Gallery({ images, name }: { images: RestaurantImage[]; name: string }) {
  const [open, setOpen] = useState<number | null>(null);
  if (!images.length) return null;
  const shown = images.slice(0, 5);
  return (
    <>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 sm:grid-rows-2">
        {shown.map((img, i) => (
          <button
            key={img.id}
            onClick={() => setOpen(i)}
            className={cn('group relative overflow-hidden rounded-2xl', i === 0 && 'col-span-2 row-span-2')}
            aria-label={`Apri foto ${i + 1}`}
          >
            <SmartImage src={img.url} alt={img.alt ?? name} className={cn('w-full transition duration-500 group-hover:scale-105', i === 0 ? 'aspect-square' : 'aspect-[4/3] sm:aspect-square')} />
            {i === shown.length - 1 && images.length > shown.length && (
              <span className="absolute inset-0 flex items-center justify-center bg-ink/50 font-semibold text-white">+{images.length - shown.length} foto</span>
            )}
          </button>
        ))}
      </div>
      {open !== null &&
        createPortal(
          <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/90 p-4" role="dialog" aria-modal="true" onClick={() => setOpen(null)}>
            <button className="absolute right-4 top-4 rounded-full bg-white/10 p-2.5 text-white" aria-label="Chiudi">
              <X className="h-6 w-6" />
            </button>
            <button
              className="absolute left-3 rounded-full bg-white/10 p-3 text-white"
              aria-label="Precedente"
              onClick={(e) => {
                e.stopPropagation();
                setOpen((open - 1 + images.length) % images.length);
              }}
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <img src={images[open]!.url} alt={images[open]!.alt ?? name} className="max-h-[85vh] max-w-full rounded-2xl object-contain" onClick={(e) => e.stopPropagation()} />
            <button
              className="absolute right-3 rounded-full bg-white/10 p-3 text-white"
              aria-label="Successiva"
              onClick={(e) => {
                e.stopPropagation();
                setOpen((open + 1) % images.length);
              }}
            >
              <ChevronRight className="h-6 w-6" />
            </button>
            <p className="absolute bottom-5 text-sm text-white/70">
              {open + 1} / {images.length}
            </p>
          </div>,
          document.body,
        )}
    </>
  );
}
