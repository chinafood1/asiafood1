import { useEffect, useRef } from 'react';
import { Info, Megaphone } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { cn } from '@/lib/format';
import { api } from '@/services';
import type { SponsoredPlacement, SponsoredSlot } from '@/types/domain';
import { RestaurantCard, RestaurantRow } from './RestaurantCard';

const IMPRESSION_TTL_MS = 30 * 60_000;

/**
 * Impression "ragionevole": card visibile almeno al 50% per 1 secondo, una sola volta
 * per montaggio e al massimo una ogni 30 minuti per sessione (anche il server deduplica).
 * Nessun fingerprint: solo l'ID di sessione anonimo già usato dagli analytics.
 */
function useImpression(slot: SponsoredSlot) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;
    const key = `af_imp_${slot.campaign_id}_${slot.placement}`;
    const seen = () => {
      try {
        const t = Number(sessionStorage.getItem(key) ?? 0);
        return Date.now() - t < IMPRESSION_TTL_MS;
      } catch {
        return false;
      }
    };
    if (seen()) return;
    let timer: ReturnType<typeof setTimeout> | null = null;
    let done = false;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (done) return;
        if (e?.isIntersecting && e.intersectionRatio >= 0.5) {
          timer ??= setTimeout(() => {
            if (done || seen()) return;
            done = true;
            try {
              sessionStorage.setItem(key, String(Date.now()));
            } catch {
              /* storage non disponibile: resta la deduplica server */
            }
            api.trackSponsored(slot.campaign_id, 'sponsored_impression', slot.placement);
            obs.disconnect();
          }, 1000);
        } else if (timer) {
          clearTimeout(timer);
          timer = null;
        }
      },
      { threshold: [0, 0.5, 1] },
    );
    obs.observe(el);
    return () => {
      done = true;
      if (timer) clearTimeout(timer);
      obs.disconnect();
    };
  }, [slot.campaign_id, slot.placement]);
  return ref;
}

function Slot({ slot, variant, dark }: { slot: SponsoredSlot; variant: 'card' | 'row'; dark?: boolean }) {
  const ref = useImpression(slot);
  const r = { ...slot.restaurant, sponsored_now: true };
  return (
    <div ref={ref} data-sponsored-slot={slot.placement} onClickCapture={() => api.trackSponsored(slot.campaign_id, 'sponsored_click', slot.placement)}>
      {variant === 'row' ? <RestaurantRow r={r} /> : <RestaurantCard r={r} source={`sponsored_${slot.placement}`} dark={dark} />}
    </div>
  );
}

/**
 * Slot sponsorizzati: sempre separati dai risultati organici e sempre etichettati.
 * `onlyIds` = limita ai locali presenti nei risultati (lo sponsor non scavalca la pertinenza).
 */
export function SponsoredSlots({
  placement,
  citySlug,
  categorySlug,
  limit = 2,
  onlyIds,
  variant = 'card',
  className,
  title = 'Sponsorizzati',
  prefetched,
}: {
  placement: SponsoredPlacement;
  citySlug?: string | null;
  categorySlug?: string | null;
  limit?: number;
  onlyIds?: string[] | null;
  variant?: 'card' | 'row';
  className?: string;
  title?: string;
  /** Slot già caricati dalla pagina insieme ai risultati (evita layout shift). */
  prefetched?: SponsoredSlot[];
}) {
  const q = useAsync(
    () => (prefetched ? Promise.resolve(prefetched) : api.getSponsoredSlots(placement, { citySlug, categorySlug, limit }).catch(() => [] as SponsoredSlot[])),
    [placement, citySlug, categorySlug, limit, prefetched],
  );
  const ids = onlyIds ? new Set(onlyIds) : null;
  const slots = (q.data ?? []).filter((s) => !ids || ids.has(s.restaurant.id));
  if (!slots.length) return null;
  return (
    <section aria-label={title} className={cn('rounded-[28px] border border-dashed border-line bg-white/60 p-3 sm:p-4', className)}>
      <div className="mb-3 flex items-center justify-between gap-2 px-1">
        <p className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-ink-muted">
          <Megaphone className="h-3.5 w-3.5" /> {title}
        </p>
        <span className="inline-flex items-center gap-1 text-xs text-ink-faint" title="Posizione a pagamento, separata dai risultati: non cambia l’ordine della ricerca.">
          <Info className="h-3.5 w-3.5" /> Contenuto a pagamento
        </span>
      </div>
      <div className={cn(variant === 'row' ? 'space-y-3' : 'grid gap-5 sm:grid-cols-2 lg:grid-cols-3')}>
        {slots.map((s) => <Slot key={s.campaign_id} slot={s} variant={variant} />)}
      </div>
    </section>
  );
}
