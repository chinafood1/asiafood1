import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarDays, Check, Clock, Copy, Mail, MapPin, Star, Ticket } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useUpgrade } from '@/context/UpgradeContext';
import { SmartImage } from '@/components/ui/SmartImage';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';
import { QrCode } from '@/components/ui/QrCode';
import { Sheet } from '@/components/ui/Sheet';
import { api } from '@/services';
import { cn, formatDate, formatDistance, formatPrice } from '@/lib/format';
import { DAY_SHORT } from '@/lib/hours';
import { EMAIL_RE } from '@/lib/reservations';
import type { ClaimCouponResult, Coupon, Offer, OfferType, OfferWithRestaurant } from '@/types/domain';
import { sessionConversion } from '@/lib/experiments';

export const OFFER_TYPE_LABELS: Record<OfferType, string> = {
  percentage: 'Sconto %',
  fixed_amount: 'Sconto in €',
  special_menu: 'Menu speciale',
  two_for_one: '2x1',
  happy_hour: 'Happy hour',
  ayce_promo: 'Promo AYCE',
  free_dish: 'Omaggio',
  other: 'Altro',
};

export function discountLabel(o: { discount_type: string; discount_value: number | null; offer_type?: OfferType }): string | null {
  if (o.offer_type === 'two_for_one') return '2x1';
  if (o.discount_value == null) return o.discount_type === 'free_item' || o.offer_type === 'free_dish' ? 'Omaggio' : null;
  switch (o.discount_type) {
    case 'percent':
      return `-${o.discount_value}%`;
    case 'amount':
      return `-${formatPrice(o.discount_value, true)}`;
    case 'fixed_price':
      return formatPrice(o.discount_value);
    default:
      return null;
  }
}

export const daysText = (days: number[]) => (!days.length || days.length === 7 ? 'Tutti i giorni' : days.map((d) => DAY_SHORT[d - 1]).join(', '));
const timeText = (o: Pick<Offer, 'start_time' | 'end_time'>) => (o.start_time && o.end_time ? `${o.start_time.slice(0, 5)}–${o.end_time.slice(0, 5)}` : null);

/** Card offerta con locale (home e pagina Offerte). */
export function OfferCard({ o }: { o: OfferWithRestaurant }) {
  const label = discountLabel(o);
  const time = timeText(o);
  return (
    <Link
      to={`/ristorante/${o.restaurant.slug}#offerte`}
      state={{ source: 'offers' }}
      onClick={() => api.track(o.restaurant.id, 'offer_view', 'offers', { offer_id: o.id })}
      className="group flex h-full animate-fade-up flex-col overflow-hidden rounded-3xl border border-line bg-white transition hover:shadow-card"
    >
      <div className="relative">
        <SmartImage src={o.image_url ?? o.restaurant.cover_url} alt={o.restaurant.name} seed={o.restaurant.id} className="aspect-[16/9] w-full" />
        {label && <span className="absolute left-3 top-3 rounded-full bg-coral px-3 py-1.5 font-display text-sm font-bold text-white shadow-lg">{label}</span>}
        {o.is_featured && (
          <span className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/95 px-2.5 py-1 text-xs font-semibold shadow-sm">
            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" /> In evidenza
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-ink-muted">
          {o.restaurant.name}
          {o.restaurant.city_name && ` · ${o.restaurant.city_name}`}
          {o.distance_km !== undefined && <span className="normal-case"> · {formatDistance(o.distance_km)}</span>}
        </p>
        <h3 className="mt-1 text-lg font-bold leading-snug">{o.title}</h3>
        {o.description && <p className="mt-1 line-clamp-2 text-sm text-ink-muted">{o.description}</p>}
        <div className="mt-auto flex flex-wrap items-center gap-x-3 gap-y-1 pt-3 text-xs text-ink-muted">
          <span className="rounded-full bg-cream px-2 py-0.5 font-semibold text-ink-soft">{OFFER_TYPE_LABELS[o.offer_type]}</span>
          <span className="inline-flex items-center gap-1">
            <CalendarDays className="h-3.5 w-3.5" /> {daysText(o.days_of_week)}
          </span>
          {time && (
            <span className="inline-flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" /> {time}
            </span>
          )}
          {o.ends_at && <span>fino al {formatDate(o.ends_at, { day: 'numeric', month: 'short' })}</span>}
        </div>
      </div>
    </Link>
  );
}

/** Offerta nella scheda del ristorante. */
export function OfferInline({ o }: { o: Offer }) {
  const label = discountLabel(o);
  const time = timeText(o);
  return (
    <div className="flex gap-4 rounded-3xl border border-line bg-white p-4">
      <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-coral-50 text-center font-display text-sm font-bold leading-tight text-coral-700">
        {label ?? '%'}
      </div>
      <div className="min-w-0">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-muted">{OFFER_TYPE_LABELS[o.offer_type]}</p>
        <h4 className="font-bold">{o.title}</h4>
        {o.description && <p className="mt-0.5 text-sm text-ink-muted">{o.description}</p>}
        <p className="mt-1.5 text-xs text-ink-muted">
          {daysText(o.days_of_week)}
          {time && ` · ${time}`}
          {o.minimum_spend ? ` · spesa minima ${formatPrice(o.minimum_spend, true)}` : ''}
          {o.ends_at && ` · valida fino al ${formatDate(o.ends_at)}`}
        </p>
        {o.terms && <p className="mt-1 text-xs text-ink-faint">{o.terms}</p>}
      </div>
    </div>
  );
}

/** Coupon: "Ottieni coupon" genera un codice personale (con account o con email). */
export function CouponCard({ c, restaurantName, source = 'web' }: { c: Coupon; restaurantName: string; source?: 'web' | 'ai' }) {
  const { user } = useAuth();
  const { handleError } = useUpgrade();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ClaimCouponResult | null>(null);
  const label = discountLabel(c);
  const soldOut = c.max_redemptions != null && c.claims_count >= c.max_redemptions;

  const claim = async () => {
    setError(null);
    if (!user && !EMAIL_RE.test(email.trim())) return setError('Inserisci un indirizzo email valido.');
    setBusy(true);
    try {
      setResult(await api.claimCoupon(c.id, user ? null : email.trim(), source));
      sessionConversion('coupon_claimed', c.restaurant_id);
      setOpen(true);
    } catch (e) {
      if (open) setError((e as Error).message);
      else handleError(e);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="relative flex overflow-hidden rounded-3xl border border-line bg-white">
        <div className="flex w-24 shrink-0 flex-col items-center justify-center bg-ink px-2 text-center text-white">
          <Ticket className="mb-1 h-5 w-5 text-coral-400" />
          <span className="font-display text-lg font-bold leading-tight">{label ?? 'Coupon'}</span>
        </div>
        <span className="absolute left-[88px] top-1/2 h-4 w-4 -translate-y-1/2 rounded-full bg-paper" aria-hidden />
        <div className="min-w-0 flex-1 p-4 pl-6">
          <h4 className="font-bold">{c.title}</h4>
          {c.description && <p className="text-sm text-ink-muted">{c.description}</p>}
          <p className="mt-1 text-xs text-ink-faint">
            {c.minimum_spend ? `Spesa minima ${formatPrice(c.minimum_spend, true)} · ` : ''}
            {c.valid_until ? `Scade il ${formatDate(c.valid_until)}` : 'Senza scadenza'}
            {c.max_redemptions != null && !soldOut && ` · ${Math.max(c.max_redemptions - c.claims_count, 0)} disponibili`}
          </p>
          <div className="mt-3">
            {soldOut ? (
              <span className="inline-flex rounded-full bg-cream px-3 py-1.5 text-sm font-semibold text-ink-muted">Coupon esaurito</span>
            ) : (
              <Button size="sm" loading={busy && !open} onClick={() => (user ? claim() : setOpen(true))}>
                Ottieni coupon
              </Button>
            )}
          </div>
        </div>
      </div>

      <Sheet open={open} onClose={() => { setOpen(false); setResult(null); setError(null); }} title={result ? 'Il tuo coupon' : 'Ottieni il coupon'}>
        {result ? (
          <ClaimedCoupon r={result} />
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void claim();
            }}
            className="space-y-4"
            noValidate
          >
            <p className="text-[15px] text-ink-soft">
              <strong>{c.title}</strong> da {restaurantName}. Ricevi un codice personale da mostrare in cassa.
            </p>
            <Field label="La tua email" error={error} hint="Serve solo per evitare codici duplicati. Nessuna newsletter.">
              <Input type="email" autoComplete="email" inputMode="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="nome@email.it" aria-invalid={!!error} />
            </Field>
            <Button type="submit" className="w-full" loading={busy} icon={<Mail className="h-4 w-4" />}>
              Ottieni coupon
            </Button>
            <p className="text-center text-sm text-ink-muted">
              Hai un account? <Link to="/accedi" className="font-semibold text-coral-700 hover:underline">Accedi</Link> per ritrovare i coupon nella tua area.
            </p>
          </form>
        )}
      </Sheet>
    </>
  );
}

/** Codice personale del coupon con QR, da mostrare in cassa. */
export function ClaimedCoupon({ r }: { r: Pick<ClaimCouponResult, 'claim_code' | 'title' | 'restaurant_name' | 'valid_until' | 'already'> & { status?: string } }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(r.claim_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard non disponibile */
    }
  };
  return (
    <div className="flex flex-col items-center text-center">
      {r.already && <p className="mb-3 rounded-2xl bg-cream px-4 py-2 text-sm">Avevi già ottenuto questo coupon: ecco il tuo codice.</p>}
      <p className="text-sm text-ink-muted">{r.restaurant_name}</p>
      <p className="text-lg font-bold">{r.title}</p>
      <div className="mt-4 rounded-3xl border border-line bg-white p-3">
        <QrCode value={r.claim_code} />
      </div>
      <button
        type="button"
        onClick={copy}
        className={cn('mt-4 inline-flex items-center gap-2 rounded-2xl border-2 border-dashed px-4 py-2 font-mono text-xl font-bold tracking-wider', copied ? 'border-leaf text-emerald-700' : 'border-ink/30')}
        aria-label={`Copia il codice ${r.claim_code}`}
      >
        {r.claim_code} {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
      </button>
      <p className="mt-3 text-sm text-ink-muted">
        Mostra il codice o il QR alla cassa.{r.valid_until ? ` Valido fino al ${formatDate(r.valid_until)}.` : ''}
      </p>
    </div>
  );
}

export function DistanceTag({ km }: { km?: number }) {
  if (km === undefined) return null;
  return (
    <span className="inline-flex items-center gap-1 text-xs text-ink-muted">
      <MapPin className="h-3 w-3" /> {formatDistance(km)}
    </span>
  );
}
