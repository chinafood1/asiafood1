import { useEffect, useMemo, useRef, useState } from 'react';
import { AlertCircle, Flame, Infinity as InfinityIcon, Leaf, Plus, Search, Star, WheatOff, X } from 'lucide-react';
import { cn, formatPrice } from '@/lib/format';
import { ALLERGEN_BY_CODE, ALLERGEN_DISCLAIMER, DIET_FILTERS, type DietFilter } from '@/lib/menu';
import { normalizeText } from '@/lib/searchQuery';
import type { AllergenCode, MenuItemFull, MenuWithSections } from '@/types/domain';
import { SmartImage } from '@/components/ui/SmartImage';

const PAGE = 30;

/**
 * Menu pubblico: più menu, categorie sticky con scroll automatico, ricerca
 * "Cerca nel menu", filtri dietetici, varianti, extra, ingredienti e allergeni.
 */
/** Ordini online (Fase 8): se presente, i piatti ordinabili mostrano "Aggiungi". */
export interface MenuOrdering {
  onSelect: (it: MenuItemFull) => void;
}

export const isOrderable = (it: MenuItemFull, menuType: string) =>
  menuType !== 'all_you_can_eat' && it.is_available && (!it.unavailable_until || Date.parse(it.unavailable_until) <= Date.now())
  && (it.price != null || it.variants.some((v) => v.is_available && v.price != null));

export function PublicMenu({ menus, onView, stickyTop = 116, ordering }: { menus: MenuWithSections[]; onView?: () => void; stickyTop?: number; ordering?: MenuOrdering | null }) {
  const [menuIdx, setMenuIdx] = useState(0);
  const [q, setQ] = useState('');
  const [diet, setDiet] = useState<DietFilter[]>([]);
  const [activeCat, setActiveCat] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const rootRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLDivElement>(null);
  const viewed = useRef(false);
  const menu = menus[Math.min(menuIdx, menus.length - 1)];

  // menu_view: una volta sola, quando il menu entra davvero nello schermo
  useEffect(() => {
    const el = rootRef.current;
    if (!el || !onView) return;
    const io = new IntersectionObserver(([e]) => {
      if (e?.isIntersecting && !viewed.current) {
        viewed.current = true;
        onView();
        io.disconnect();
      }
    }, { threshold: 0.15 });
    io.observe(el);
    return () => io.disconnect();
  }, [onView]);

  const text = normalizeText(q);
  const sections = useMemo(() => {
    if (!menu) return [];
    return menu.sections
      .map((s) => ({
        ...s,
        items: s.items.filter((it) => {
          if (diet.some((d) => !it[DIET_FILTERS.find((f) => f.key === d)!.field])) return false;
          if (!text) return true;
          const hay = normalizeText([it.name, it.description, s.name, ...it.ingredients].filter(Boolean).join(' '));
          return text.split(' ').every((w) => hay.includes(w));
        }),
      }))
      .filter((s) => s.items.length > 0);
  }, [menu, diet, text]);
  const total = sections.reduce((a, s) => a + s.items.length, 0);

  // Evidenzia la categoria visibile (scroll spy)
  useEffect(() => {
    const els = sections.map((s) => document.getElementById(`menu-sec-${s.id}`)).filter((x): x is HTMLElement => !!x);
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        const top = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (top) setActiveCat(top.target.id.replace('menu-sec-', ''));
      },
      { rootMargin: `-${stickyTop + 60}px 0px -55% 0px` },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [sections, stickyTop]);

  // La chip attiva resta visibile nella barra orizzontale
  useEffect(() => {
    if (!activeCat) return;
    const chip = navRef.current?.querySelector<HTMLElement>(`[data-cat="${activeCat}"]`);
    const nav = navRef.current;
    if (chip && nav) nav.scrollTo({ left: chip.offsetLeft - nav.clientWidth / 2 + chip.clientWidth / 2, behavior: 'smooth' });
  }, [activeCat]);

  const goTo = (id: string) => {
    const el = document.getElementById(`menu-sec-${id}`);
    if (!el) return;
    setActiveCat(id);
    window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - stickyTop - 64, behavior: 'smooth' });
  };

  if (!menu) return null;
  const isAyceMenu = menu.menu_type === 'all_you_can_eat';

  return (
    <div ref={rootRef}>
      {menus.length > 1 && (
        <div className="scrollbar-none -mx-1 mb-4 flex gap-2 overflow-x-auto px-1" role="tablist" aria-label="Menu disponibili">
          {menus.map((m, i) => (
            <button
              key={m.id}
              role="tab"
              aria-selected={i === menuIdx}
              onClick={() => {
                setMenuIdx(i);
                setExpanded({});
              }}
              className={cn('inline-flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold transition', i === menuIdx ? 'bg-ink text-white' : 'bg-cream text-ink-soft hover:bg-line')}
            >
              {m.menu_type === 'all_you_can_eat' && <InfinityIcon className="h-4 w-4" />}
              {m.name}
            </button>
          ))}
        </div>
      )}

      {(menu.description || menu.price != null) && (
        <p className="mb-4 rounded-2xl bg-cream px-4 py-3 text-sm text-ink-soft">
          {menu.price != null && <strong className="mr-1 text-ink">{isAyceMenu ? 'Formula' : 'Prezzo fisso'} {formatPrice(menu.price)}.</strong>}
          {menu.description}
        </p>
      )}

      {/* Ricerca e filtri */}
      <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center">
        <label className="relative flex-1">
          <span className="sr-only">Cerca nel menu</span>
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cerca nel menu (es. ramen, sashimi, nigiri)"
            className="h-11 w-full rounded-full border border-line bg-white pl-10 pr-10 text-[15px] focus:border-ink focus:outline-none"
          />
          {q && (
            <button type="button" aria-label="Cancella ricerca" onClick={() => setQ('')} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-ink-muted hover:bg-cream">
              <X className="h-4 w-4" />
            </button>
          )}
        </label>
        <div className="scrollbar-none flex gap-1.5 overflow-x-auto" role="group" aria-label="Filtri alimentari">
          {DIET_FILTERS.map((f) => {
            const on = diet.includes(f.key);
            return (
              <button
                key={f.key}
                type="button"
                aria-pressed={on}
                onClick={() => setDiet(on ? diet.filter((d) => d !== f.key) : [...diet, f.key])}
                className={cn('inline-flex h-9 shrink-0 items-center gap-1 rounded-full border px-3 text-[13px] font-semibold transition', on ? 'border-ink bg-ink text-white' : 'border-line bg-white hover:border-ink/40')}
              >
                {f.key === 'spicy' ? <Flame className="h-3.5 w-3.5" /> : f.key === 'gluten_free' ? <WheatOff className="h-3.5 w-3.5" /> : <Leaf className="h-3.5 w-3.5" />}
                {f.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Categorie sticky con scroll automatico */}
      {sections.length > 1 && (
        <nav
          ref={navRef}
          aria-label="Categorie del menu"
          className="scrollbar-none sticky z-10 -mx-4 mb-2 flex gap-1 overflow-x-auto border-b border-line bg-paper px-4 py-2 sm:mx-0 sm:px-0"
          style={{ top: stickyTop }}
        >
          {sections.map((s) => (
            <button
              key={s.id}
              type="button"
              data-cat={s.id}
              onClick={() => goTo(s.id)}
              aria-current={activeCat === s.id ? 'true' : undefined}
              className={cn('shrink-0 rounded-full px-3.5 py-1.5 text-sm font-semibold transition', activeCat === s.id ? 'bg-coral text-white' : 'text-ink-soft hover:bg-cream')}
            >
              {s.name}
            </button>
          ))}
        </nav>
      )}

      {(q || diet.length > 0) && (
        <p className="mb-3 text-sm text-ink-muted" aria-live="polite">
          {total ? `${total} ${total === 1 ? 'piatto trovato' : 'piatti trovati'}` : 'Nessun piatto corrisponde alla ricerca.'}
          {total === 0 && (
            <button type="button" onClick={() => { setQ(''); setDiet([]); }} className="ml-2 font-semibold text-coral-700 hover:underline">
              Azzera
            </button>
          )}
        </p>
      )}

      <div className="space-y-8">
        {sections.map((s) => {
          const all = expanded[s.id];
          const items = all ? s.items : s.items.slice(0, PAGE);
          return (
            <section key={s.id} id={`menu-sec-${s.id}`} aria-labelledby={`menu-h-${s.id}`}>
              <h3 id={`menu-h-${s.id}`} className="mb-2 font-display text-lg font-bold">
                {s.name} <span className="text-sm font-medium text-ink-muted">· {s.items.length}</span>
              </h3>
              {s.description && <p className="mb-2 text-sm text-ink-muted">{s.description}</p>}
              <ul className="divide-y divide-line rounded-3xl border border-line bg-white">
                {items.map((it) => (
                  <MenuItemRow key={it.id} it={it} ayce={isAyceMenu || it.is_ayce_included} onOrder={ordering && isOrderable(it, menu.menu_type) ? () => ordering.onSelect(it) : undefined}
                    unavailableToday={!!ordering && it.is_available && !!it.unavailable_until && Date.parse(it.unavailable_until) > Date.now()} />
                ))}
              </ul>
              {s.items.length > PAGE && !all && (
                <button type="button" onClick={() => setExpanded({ ...expanded, [s.id]: true })} className="mt-2 text-sm font-semibold text-coral-700 hover:underline">
                  Mostra altri {s.items.length - PAGE} piatti
                </button>
              )}
            </section>
          );
        })}
      </div>

      <p className="mt-5 flex items-start gap-2 rounded-2xl bg-amber-50 px-4 py-3 text-sm text-amber-900">
        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
        <span>
          <strong>{ALLERGEN_DISCLAIMER}</strong> Gli allergeni sono indicati dal locale e possono cambiare. Prezzi comunicati dal locale.
        </span>
      </p>
    </div>
  );
}

function MenuItemRow({ it, ayce, onOrder, unavailableToday }: { it: MenuItemFull; ayce: boolean; onOrder?: () => void; unavailableToday?: boolean }) {
  const variants = it.variants.filter((v) => v.is_available);
  const addons = it.addons.filter((v) => v.is_available);
  const hasDiscount = it.discount_price != null && it.price != null && it.discount_price < it.price;
  return (
    <li className={cn('flex gap-4 p-4', !it.is_available && 'bg-cream/40')}>
      {it.image_url && <SmartImage src={it.image_url} alt={it.name} className={cn('h-20 w-20 shrink-0 rounded-2xl sm:h-24 sm:w-24', !it.is_available && 'opacity-50 grayscale')} />}
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-3">
          <p className="font-semibold">
            {it.is_featured && <Star className="mr-1 inline h-3.5 w-3.5 -translate-y-px fill-amber-400 text-amber-400" aria-label="Consigliato" />}
            {it.name}
            {it.pieces && <span className="ml-1.5 text-xs font-medium text-ink-muted">{it.pieces} pz</span>}
          </p>
          <p className="shrink-0 text-right font-semibold tabular-nums">
            {it.price != null ? (
              hasDiscount ? (
                <>
                  <span className="mr-1.5 text-sm font-normal text-ink-faint line-through">{formatPrice(it.price)}</span>
                  <span className="text-coral-700">{formatPrice(it.discount_price)}</span>
                </>
              ) : (
                formatPrice(it.price)
              )
            ) : ayce ? (
              <span className="text-xs font-semibold text-coral-700">Compreso nel menu AYCE</span>
            ) : null}
          </p>
        </div>
        {it.description && <p className="mt-0.5 text-sm text-ink-muted">{it.description}</p>}
        {it.ingredients.length > 0 && <p className="mt-1 text-xs text-ink-faint">Ingredienti: {it.ingredients.join(', ')}</p>}
        {variants.length > 0 && (
          <p className="mt-1.5 flex flex-wrap gap-1.5 text-xs">
            {variants.map((v) => (
              <span key={v.id} className="rounded-full border border-line px-2 py-0.5 font-medium">
                {v.name}
                {v.price != null && <strong className="ml-1">{formatPrice(v.price)}</strong>}
              </span>
            ))}
          </p>
        )}
        {addons.length > 0 && (
          <p className="mt-1 text-xs text-ink-muted">
            Extra: {addons.map((a) => `${a.name}${a.price != null ? ` +${formatPrice(a.price)}` : ''}`).join(' · ')}
          </p>
        )}
        {(!it.is_available || unavailableToday || it.is_vegan || it.is_vegetarian || it.is_gluten_free || it.is_spicy || it.allergens.length > 0) && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {!it.is_available && <span className="rounded-full bg-cream px-2 py-0.5 text-[11px] font-semibold text-ink-soft">Non disponibile</span>}
            {unavailableToday && <span className="rounded-full bg-cream px-2 py-0.5 text-[11px] font-semibold text-ink-soft">Non disponibile oggi</span>}
            {it.is_vegan ? <Tag tone="green" icon={<Leaf className="h-3 w-3" />}>Vegano</Tag> : it.is_vegetarian && <Tag tone="green" icon={<Leaf className="h-3 w-3" />}>Vegetariano</Tag>}
            {it.is_gluten_free && <Tag tone="green" icon={<WheatOff className="h-3 w-3" />}>Gluten free</Tag>}
            {it.is_spicy && <Tag tone="coral" icon={<Flame className="h-3 w-3" />}>Piccante</Tag>}
            {it.allergens.length > 0 && (
              <span className="inline-flex flex-wrap items-center gap-1 text-[11px] text-ink-muted">
                <span className="font-semibold">Allergeni:</span>
                {it.allergens.map((a) => {
                  const info = ALLERGEN_BY_CODE[a as AllergenCode];
                  return info ? (
                    <span key={a} className="rounded-full bg-amber-50 px-1.5 py-0.5 text-amber-900" title={`Allergene UE n. ${info.eu}`}>
                      {info.name}
                    </span>
                  ) : null;
                })}
              </span>
            )}
          </div>
        )}
      </div>
      {onOrder && (
        <button type="button" onClick={onOrder} aria-label={`Aggiungi ${it.name} al carrello`}
          className="flex h-10 w-10 shrink-0 items-center justify-center self-center rounded-full bg-coral text-white shadow-card transition hover:bg-coral-600 active:scale-95">
          <Plus className="h-5 w-5" />
        </button>
      )}
    </li>
  );
}

function Tag({ tone, icon, children }: { tone: 'green' | 'coral'; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold', tone === 'green' ? 'bg-emerald-50 text-emerald-700' : 'bg-coral-50 text-coral-700')}>
      {icon}
      {children}
    </span>
  );
}
