import { useState, type FormEvent } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { REPORT_TYPE } from '@/lib/labels';
import { api } from '@/services';
import type { ReportType } from '@/types/domain';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';

/** "Segnala informazioni errate": funziona anche senza account (email facoltativa). */
export function ReportSheet({ open, onClose, restaurantId, restaurantName }: { open: boolean; onClose: () => void; restaurantId: string; restaurantName: string }) {
  const { user } = useAuth();
  const [type, setType] = useState<ReportType>('wrong_hours');
  const [description, setDescription] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const close = () => {
    onClose();
    setTimeout(() => {
      setSent(false);
      setDescription('');
      setError(null);
    }, 300);
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (description.trim().length < 5) return setError('Descrivi il problema (almeno 5 caratteri).');
    if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return setError('Email non valida.');
    setError(null);
    setBusy(true);
    try {
      await api.createReport({ restaurant_id: restaurantId, user_id: user?.id ?? null, report_type: type, description: description.trim(), email: email.trim() || user?.email || null });
      setSent(true);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet open={open} onClose={close} title="Segnala informazioni errate">
      {sent ? (
        <div className="py-6 text-center">
          <CheckCircle2 className="mx-auto h-12 w-12 text-leaf" />
          <p className="mt-3 text-lg font-bold">Grazie per la segnalazione</p>
          <p className="mt-1 text-sm text-ink-muted">La verificheremo sulle fonti e aggiorneremo la scheda di {restaurantName}.</p>
          <Button className="mt-5" onClick={close}>Chiudi</Button>
        </div>
      ) : (
        <form onSubmit={submit} className="grid gap-4">
          <p className="text-sm text-ink-muted">Aiutaci a mantenere corretta la scheda di <strong>{restaurantName}</strong>.</p>
          {error && <Alert tone="error">{error}</Alert>}
          <Field label="Cosa non è corretto?">
            <Select value={type} onChange={(e) => setType(e.target.value as ReportType)}>
              {(Object.keys(REPORT_TYPE) as ReportType[]).map((k) => <option key={k} value={k}>{REPORT_TYPE[k]}</option>)}
            </Select>
          </Field>
          <Field label="Descrizione">
            <Textarea required minLength={5} maxLength={2000} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Es. la domenica è chiuso a pranzo; il nuovo numero è…" />
          </Field>
          {!user && (
            <Field label="Email (facoltativa)" hint="Solo se vuoi essere ricontattato.">
              <Input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </Field>
          )}
          <Button type="submit" loading={busy}>Invia segnalazione</Button>
        </form>
      )}
    </Sheet>
  );
}
