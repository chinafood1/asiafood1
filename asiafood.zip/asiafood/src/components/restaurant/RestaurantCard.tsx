import { Link } from 'react-router-dom';
import { ArrowRight, Bike, ChevronRight, Infinity as InfinityIcon, MapPin, ShoppingBag } from 'lucide-react';
import { OrderOnlineBadge } from '@/components/orders/OrderParts';
import { Badge, DemoBadge, SponsoredBadge, VerifiedBadge } from '@/components/ui/Badge';
import { Monogram, SmartImage } from '@/components/ui/SmartImage';
import { cn, formatDistance, formatPrice, priceRangeLabel } from '@/lib/format';
import type { RestaurantSummary } from '@/types/domain';
import { FavoriteButton, OpenStatus } from './Status';

const primaryEmoji = (r: RestaurantSummary) => r.categories[0]?.emoji ?? '🥢';
/** "Profilo verificato" solo per schede rivendicate e approvate. */
export const isOwnerVerified = (r: Pick<RestaurantSummary, 'is_verified' | 'owner_id'>) => r.is_verified && !!r.owner_id;

function Meta({ r, dark }: { r: RestaurantSummary; dark?: boolean }) {
  const cats = r.categories.filter((c) => c.slug !== 'all-you-can-eat').slice(0, 2).map((c) => c.name);
  return (
    <p className={cn('truncate text-sm', dark ? 'text-white/60' : 'text-ink-muted')}>
      {[...cats, r.city?.name].filter(Boolean).join(' · ')}
      {r.distance_km !== undefined && <span className={cn('font-semibold', dark ? 'text-white' : 'text-ink')}> · {formatDistance(r.distance_km)}</span>}
    </p>
  );
}

function Perks({ r, compact, dark }: { r: RestaurantSummary; compact?: boolean; dark?: boolean }) {
  const ayceFrom = Math.min(...[r.ayce_lunch_price, r.ayce_dinner_price].filter((x): x is number => x != null));
  return (
    <div className={cn('flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[13px] font-medium', dark ? 'text-white/80' : 'text-ink-soft', compact && 'gap-x-2')}>
      {r.price_range && (
        <span aria-label={`Fascia di prezzo ${r.price_range} su 4`}>
          <span className={dark ? 'text-white' : 'text-ink'}>{priceRangeLabel(r.price_range)}</span>
          <span className={dark ? 'text-white/30' : 'text-ink-faint'}>{'€'.repeat(4 - r.price_range)}</span>
        </span>
      )}
      {r.is_all_you_can_eat && (
        <span className="inline-flex items-center gap-1 rounded-full bg-coral-50 px-2 py-0.5 text-coral-700">
          <InfinityIcon className="h-3.5 w-3.5" /> AYCE{Number.isFinite(ayceFrom) && !compact ? ` da ${formatPrice(ayceFrom)}` : ''}
        </span>
      )}
      {r.has_delivery && (
        <span className="inline-flex items-center gap-1" title="Consegna a domicilio">
          <Bike className="h-3.5 w-3.5" /> {!compact && 'Delivery'}
        </span>
      )}
      {r.has_takeaway && (
        <span className="inline-flex items-center gap-1" title="Asporto">
          <ShoppingBag className="h-3.5 w-3.5" /> {!compact && 'Asporto'}
        </span>
      )}
    </div>
  );
}

function StatusChip({ r }: { r: RestaurantSummary }) {
  if (r.is_permanently_closed) return <Badge tone="dark">Chiuso definitivamente</Badge>;
  if (r.is_temporarily_closed) return <Badge tone="glass" className="!text-amber-800">Chiuso temporaneamente</Badge>;
  return <OpenStatus hours={r.hours} tz={r.timezone} glass />;
}

/** Card grande con foto protagonista. */
export function RestaurantCard({ r, className, eager, source, dark }: { r: RestaurantSummary; className?: string; eager?: boolean; source?: string; dark?: boolean }) {
  return (
    <Link to={`/ristorante/${r.slug}`} state={source ? { source } : undefined} className={cn('group flex min-w-0 animate-fade-up flex-col', className)}>
      <div className="relative overflow-hidden rounded-3xl">
        <SmartImage
          src={r.cover_url}
          alt={r.name}
          seed={r.id}
          emoji={primaryEmoji(r)}
          eager={eager}
          className="aspect-[4/3] w-full transition duration-700 group-hover:scale-[1.04] [&_img]:transition-transform"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-transparent" />
        <div className="absolute left-3 top-3 flex flex-wrap gap-1.5">
          {r.sponsored_now && <SponsoredBadge glass />}
          {r.is_demo && <DemoBadge glass />}
          <OrderOnlineBadge restaurantId={r.id} glass />
        </div>
        <FavoriteButton restaurantId={r.id} className="absolute right-3 top-3" />
        <div className="absolute bottom-3 right-3">
          <StatusChip r={r} />
        </div>
      </div>
      <div className="relative flex flex-1 gap-3 px-1 pt-3">
        <Monogram name={r.name} src={r.logo_url} className={cn('-mt-8 h-12 w-12 shrink-0 border-[3px] text-sm shadow-card', dark ? 'border-ink' : 'border-paper')} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className={cn('truncate text-[17px] font-bold leading-tight', dark ? 'text-white group-hover:text-coral-400' : 'group-hover:text-coral-700')}>{r.name}</h3>
            {isOwnerVerified(r) && <VerifiedBadge glass={dark} />}
          </div>
          <Meta r={r} dark={dark} />
          <div className="mt-2 flex min-w-0 items-end justify-between gap-2">
            <Perks r={r} dark={dark} />
            <span className={cn('inline-flex shrink-0 items-center gap-1 text-sm font-semibold transition group-hover:gap-1.5', dark ? 'text-coral-400' : 'text-coral-700')}>
              Scopri <ArrowRight className="h-4 w-4" />
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}

/** Riga compatta per la vista lista. */
export function RestaurantRow({ r }: { r: RestaurantSummary }) {
  return (
    <Link to={`/ristorante/${r.slug}`} className="group flex animate-fade-up items-center gap-4 rounded-3xl border border-line bg-white p-3 transition hover:border-ink/20 hover:shadow-card">
      <SmartImage src={r.cover_url} alt={r.name} seed={r.id} emoji={primaryEmoji(r)} className="h-24 w-24 shrink-0 rounded-2xl sm:h-28 sm:w-36" />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <h3 className="truncate text-base font-bold">{r.name}</h3>
          {isOwnerVerified(r) && <VerifiedBadge />}
        </div>
        <Meta r={r} />
        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
          {r.sponsored_now && <SponsoredBadge />}
          {r.is_demo && <DemoBadge />}
          {r.is_temporarily_closed ? <Badge tone="amber">Chiuso temporaneamente</Badge> : <OpenStatus hours={r.hours} tz={r.timezone} />}
        </div>
        <div className="mt-1.5">
          <Perks r={r} compact />
        </div>
      </div>
      <div className="hidden flex-col items-end gap-2 sm:flex">
        <FavoriteButton restaurantId={r.id} variant="plain" />
        <ChevronRight className="h-5 w-5 text-ink-faint transition group-hover:translate-x-0.5 group-hover:text-ink" />
      </div>
    </Link>
  );
}

/** Mini card usata sulla mappa. */
export function RestaurantMini({ r, onClick, active }: { r: RestaurantSummary; onClick?: () => void; active?: boolean }) {
  return (
    <Link
      to={`/ristorante/${r.slug}`}
      onClick={onClick}
      className={cn('flex w-72 shrink-0 snap-start items-center gap-3 rounded-3xl border bg-white p-2.5 shadow-card transition', active ? 'border-ink' : 'border-line')}
    >
      <Monogram name={r.name} src={r.logo_url} className="h-14 w-14 shrink-0 text-lg" />
      <div className="min-w-0">
        <p className="truncate font-bold">{r.name}</p>
        <p className="truncate text-xs text-ink-muted">
          <MapPin className="mr-0.5 inline h-3 w-3" />
          {r.city?.name}
          {r.distance_km !== undefined && ` · ${formatDistance(r.distance_km)}`}
        </p>
        <OpenStatus hours={r.hours} tz={r.timezone} className="mt-0.5" />
      </div>
    </Link>
  );
}

export function CardSkeleton() {
  return (
    <div>
      <div className="skeleton aspect-[4/3] w-full rounded-3xl" />
      <div className="skeleton mt-3 h-5 w-2/3" />
      <div className="skeleton mt-2 h-4 w-1/2" />
    </div>
  );
}
