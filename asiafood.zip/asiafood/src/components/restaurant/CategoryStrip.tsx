import { Link } from 'react-router-dom';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { cn } from '@/lib/format';

/** Slug categorie mostrate come "icone grafiche" sotto l'hero (ordine da brief). */
export const HOME_CATEGORY_SLUGS = ['sushi', 'ramen', 'cinese', 'giapponese', 'poke', 'thai', 'coreano', 'fusion'];

const SHORT_NAMES: Record<string, string> = { fusion: 'Fusion', 'street-food': 'Street food', 'all-you-can-eat': 'AYCE' };

export function CategoryStrip({ citySlug, activeSlug, className }: { citySlug?: string; activeSlug?: string; className?: string }) {
  const { categories } = useReferenceData();
  const list = HOME_CATEGORY_SLUGS.map((s) => categories.find((c) => c.slug === s)).filter((c): c is NonNullable<typeof c> => !!c);
  return (
    <nav aria-label="Categorie" className={cn('scrollbar-none -mx-4 flex gap-3 overflow-x-auto px-4 sm:-mx-6 sm:px-6 lg:mx-0 lg:grid lg:grid-cols-8 lg:px-0', className)}>
      {(list.length ? list : Array.from({ length: 8 }, () => null)).map((c, i) =>
        c ? (
          <Link
            key={c.id}
            to={citySlug ? `/${c.slug}/${citySlug}` : `/${c.slug}`}
            className={cn(
              'group flex w-[84px] shrink-0 flex-col items-center gap-2 rounded-3xl border bg-white px-2 pb-3 pt-4 transition hover:-translate-y-0.5 hover:shadow-card lg:w-auto',
              activeSlug === c.slug ? 'border-ink' : 'border-line',
            )}
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cream text-[28px] transition group-hover:scale-110 group-hover:bg-coral-50">
              {c.emoji}
            </span>
            <span className="text-center text-[13px] font-semibold leading-tight">{SHORT_NAMES[c.slug] ?? c.name}</span>
          </Link>
        ) : (
          <div key={i} className="skeleton h-[104px] w-[84px] shrink-0 rounded-3xl lg:w-auto" />
        ),
      )}
    </nav>
  );
}
