import { useRef, type ReactNode } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { SectionHeader } from '@/components/ui/Layout';
import type { RestaurantSummary } from '@/types/domain';
import { CardSkeleton, RestaurantCard } from './RestaurantCard';

/** Carosello orizzontale (swipe su mobile, frecce su desktop). */
export function Rail({ children, label }: { children: ReactNode; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: 1 | -1) => ref.current?.scrollBy({ left: dir * ref.current.clientWidth * 0.85, behavior: 'smooth' });
  return (
    <div className="group/rail relative">
      <div
        ref={ref}
        aria-label={label}
        className="scrollbar-none -mx-4 flex snap-x-mandatory gap-4 overflow-x-auto scroll-px-4 px-4 pb-2 sm:-mx-6 sm:scroll-px-6 sm:px-6 lg:mx-0 lg:scroll-px-0 lg:px-0"
      >
        {children}
      </div>
      <button
        aria-label="Precedenti"
        onClick={() => scroll(-1)}
        className="absolute -left-5 top-[38%] hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-white shadow-card transition hover:border-ink lg:group-hover/rail:flex"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button
        aria-label="Successivi"
        onClick={() => scroll(1)}
        className="absolute -right-5 top-[38%] hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-white shadow-card transition hover:border-ink lg:group-hover/rail:flex"
      >
        <ChevronRight className="h-5 w-5" />
      </button>
    </div>
  );
}

export function RestaurantRail({
  title,
  eyebrow,
  subtitle,
  to,
  items,
  loading,
  action,
  source,
  empty,
  dark,
}: {
  title: string;
  eyebrow?: string;
  subtitle?: string;
  to?: string;
  items: RestaurantSummary[] | undefined;
  loading?: boolean;
  action?: ReactNode;
  source?: string;
  empty?: ReactNode;
  dark?: boolean;
}) {
  if (!loading && items && items.length === 0 && !empty) return null;
  const body = (
    <>
      <SectionHeader eyebrow={eyebrow} title={title} subtitle={subtitle} to={to} action={action} dark={dark} />
      {!loading && items?.length === 0 ? (
        empty
      ) : (
        <Rail label={title}>
          {loading || !items
            ? Array.from({ length: 4 }, (_, i) => (
                <div key={i} className="w-[78%] shrink-0 snap-start sm:w-[45%] lg:w-[calc(25%-12px)]">
                  <CardSkeleton />
                </div>
              ))
            : items.map((r, i) => (
                <div key={r.id} className="w-[78%] shrink-0 snap-start sm:w-[45%] lg:w-[calc(25%-12px)]">
                  <RestaurantCard r={r} eager={i < 2} source={source} dark={dark} />
                </div>
              ))}
        </Rail>
      )}
    </>
  );
  if (dark) {
    return (
      <section className="container-app py-4">
        <div className="overflow-hidden rounded-[36px] bg-ink px-4 py-8 text-white sm:px-8 sm:py-10">{body}</div>
      </section>
    );
  }
  return <section className="container-app py-7 sm:py-9">{body}</section>;
}
