import { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';
import { useFavorites } from '@/context/FavoritesContext';
import { cn } from '@/lib/format';
import { openState, openStateLabel, type OpenState } from '@/lib/hours';
import type { RestaurantHour } from '@/types/domain';

export function FavoriteButton({ restaurantId, className, variant = 'glass' }: { restaurantId: string; className?: string; variant?: 'glass' | 'plain' }) {
  const { isFavorite, toggle } = useFavorites();
  const [bump, setBump] = useState(false);
  const active = isFavorite(restaurantId);
  return (
    <button
      type="button"
      aria-label={active ? 'Rimuovi dai preferiti' : 'Salva nei preferiti'}
      aria-pressed={active}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setBump(true);
        toggle(restaurantId);
      }}
      onAnimationEnd={() => setBump(false)}
      className={cn(
        'inline-flex h-10 w-10 items-center justify-center rounded-full transition active:scale-90',
        variant === 'glass' ? 'bg-white/90 shadow-sm backdrop-blur hover:bg-white' : 'border border-line bg-white hover:border-ink',
        bump && 'animate-pop',
        className,
      )}
    >
      <Heart className={cn('h-[18px] w-[18px] transition', active ? 'fill-coral text-coral' : 'text-ink')} />
    </button>
  );
}

/** Stato apertura calcolato e aggiornato ogni minuto. */
export function useOpenState(hours: RestaurantHour[], tz?: string): OpenState {
  const [state, setState] = useState(() => openState(hours, tz));
  useEffect(() => {
    setState(openState(hours, tz));
    const t = setInterval(() => setState(openState(hours, tz)), 60_000);
    return () => clearInterval(t);
  }, [hours, tz]);
  return state;
}

export function OpenStatus({ hours, tz, className, glass }: { hours: RestaurantHour[]; tz?: string; className?: string; glass?: boolean }) {
  const state = useOpenState(hours, tz);
  if (state.kind === 'unknown') return null;
  const open = state.kind === 'open';
  const soon = open && state.closingSoon;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 text-xs font-semibold',
        glass && 'rounded-full bg-white/90 px-2.5 py-1 shadow-sm backdrop-blur',
        className,
      )}
    >
      <span className={cn('h-2 w-2 rounded-full', soon ? 'bg-amber-500' : open ? 'bg-leaf' : 'bg-ink-faint')}>
        {open && !soon && <span className="block h-2 w-2 animate-ping rounded-full bg-leaf/60" />}
      </span>
      <span className={cn(soon ? 'text-amber-700' : open ? 'text-emerald-700' : 'text-ink-muted')}>{openStateLabel(state)}</span>
    </span>
  );
}
