import { NavLink } from 'react-router-dom';
import { Compass, Heart, Home, Map, User } from 'lucide-react';
import { cn } from '@/lib/format';

const ITEMS = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/restaurants', label: 'Esplora', icon: Compass },
  { to: '/map', label: 'Mappa', icon: Map },
  { to: '/preferiti', label: 'Preferiti', icon: Heart },
  { to: '/profilo', label: 'Profilo', icon: User },
];

/** Bottom navigation mobile (nascosta da md in su). */
export function BottomNav() {
  return (
    <nav
      aria-label="Navigazione principale"
      className="pb-safe fixed inset-x-0 bottom-0 z-50 border-t border-line bg-white/90 shadow-bar backdrop-blur-xl md:hidden"
    >
      <ul className="mx-auto flex max-w-md items-stretch justify-around px-2 pt-1.5">
        {ITEMS.map(({ to, label, icon: Icon, end }) => (
          <li key={to} className="flex-1">
            <NavLink
              to={to}
              end={end}
              className={({ isActive }) =>
                cn('flex flex-col items-center gap-0.5 rounded-2xl py-1.5 text-[11px] font-semibold transition', isActive ? 'text-ink' : 'text-ink-faint')
              }
            >
              {({ isActive }) => (
                <>
                  <span className={cn('flex h-8 w-12 items-center justify-center rounded-full transition', isActive && 'bg-coral-50')}>
                    <Icon className={cn('h-[22px] w-[22px]', isActive && 'text-coral')} strokeWidth={isActive ? 2.4 : 2} />
                  </span>
                  {label}
                </>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
