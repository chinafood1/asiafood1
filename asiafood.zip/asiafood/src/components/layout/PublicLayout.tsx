import { useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { FlaskConical } from 'lucide-react';
import { isDemoMode } from '@/services';
import { cn } from '@/lib/format';
import { AiFab } from '@/components/ai/AiEntry';
import { BottomNav } from './BottomNav';
import { Footer } from './Footer';
import { Header } from './Header';
import { CartBar } from '@/components/orders/OrderParts';

export function DemoBanner() {
  if (!isDemoMode) return null;
  return (
    <div className="bg-ink text-white">
      <div className="container-app flex items-center justify-center gap-2 py-1.5 text-center text-xs">
        <FlaskConical className="h-3.5 w-3.5 shrink-0 text-coral-400" />
        <span>
          <strong>Modalità DEMO</strong> · locali di fantasia, non attività reali. Collega Supabase per usare i dati veri.
        </span>
      </div>
    </div>
  );
}

/** Reimposta lo scroll a ogni cambio pagina (rispettando le ancore #). */
function ScrollToTop() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const el = document.getElementById(hash.slice(1));
      if (el) return el.scrollIntoView({ behavior: 'smooth' });
    }
    window.scrollTo(0, 0);
  }, [pathname, hash]);
  return null;
}

export function PublicLayout() {
  const { pathname } = useLocation();
  // Nella scheda ristorante la barra azioni sostituisce la bottom nav su mobile
  const detail = pathname.startsWith('/ristorante/');
  // Mappa e assistente occupano tutta l'altezza: niente footer, niente scroll di pagina
  const assistant = pathname === '/assistant';
  const fullBleed = pathname === '/map' || assistant;
  return (
    <div className={cn('flex flex-col', fullBleed ? 'h-dvh overflow-hidden' : 'min-h-dvh')}>
      <ScrollToTop />
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[90] focus:rounded-full focus:bg-ink focus:px-4 focus:py-2 focus:text-white">Vai al contenuto</a>
      <DemoBanner />
      <Header />
      <main id="main" tabIndex={-1} className={cn('flex-1 outline-none', !fullBleed && 'min-h-[100dvh]', fullBleed && 'relative flex min-h-0', fullBleed && !assistant && 'pb-[calc(68px+env(safe-area-inset-bottom))] md:pb-0', assistant && 'flex-col')}>
        <Outlet />
      </main>
      {!fullBleed && <Footer />}
      {/* Nell'assistente il campo di testo resta in basso (sopra la tastiera): niente bottom nav */}
      {!detail && !assistant && <BottomNav />}
      {!detail && !fullBleed && <CartBar className="bottom-[calc(76px+env(safe-area-inset-bottom))]" />}
      <AiFab />
    </div>
  );
}
