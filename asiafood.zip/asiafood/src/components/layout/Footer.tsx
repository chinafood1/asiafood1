import { UserFeedbackButton } from '@/components/launch/FeedbackWidgets';
import { Link } from 'react-router-dom';
import { APP } from '@/config/app';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { Logo } from './Logo';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { openConsentPreferences } from '@/lib/consent';

/** Footer con link SEO interni (categoria × comune, comuni). */
export function Footer() {
  const { categories, cities } = useReferenceData();
  const launch = cities.find((c) => c.slug === APP.defaultCitySlug) ?? cities[0];
  return (
    <footer className="mt-16 border-t border-line bg-white pb-28 pt-12 md:pb-12">
      <div className="container-app grid gap-10 md:grid-cols-[1.3fr_1fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-3 max-w-xs text-sm text-ink-muted">
            La guida ai ristoranti asiatici: sushi, ramen, cucina cinese, thai, coreana e poke. Partiamo da {APP.launchArea}.
          </p>
          <Link to="/per-ristoratori" className="mt-5 inline-flex rounded-full bg-coral-50 px-4 py-2 text-sm font-semibold text-coral-700">
            Sei un ristoratore? Inizia gratis
          </Link>
        </div>
        {launch && (
          <FooterCol title={`Cucine a ${launch.name}`}>
            {categories.slice(0, 8).map((c) => (
              <Link key={c.id} to={`/${c.slug}/${launch.slug}`} className="hover:text-ink">
                {c.name} {launch.name}
              </Link>
            ))}
          </FooterCol>
        )}
        <FooterCol title="Comuni">
          {cities.slice(0, 13).map((c) => (
            <Link key={c.id} to={`/ristoranti/${c.slug}`} className="hover:text-ink">
              Ristoranti asiatici {c.name}
            </Link>
          ))}
        </FooterCol>
        <FooterCol title={APP.name}>
          <Link to="/restaurants" className="hover:text-ink">Esplora</Link>
          <Link to="/all-you-can-eat" className="hover:text-ink">All You Can Eat</Link>
          <Link to="/offers" className="hover:text-ink">Offerte e coupon</Link>
          <Link to="/ristoranti" className="hover:text-ink">Tutte le città</Link>
          <Link to="/per-ristoratori" className="hover:text-ink">Per i ristoratori</Link>
          <Link to="/rider/apply" className="hover:text-ink">Diventa Rider</Link>
          <Link to="/business/pricing" className="hover:text-ink">Prezzi per ristoratori</Link>
          <Link to="/support" className="hover:text-ink">Supporto</Link>
          <Link to="/taranto" className="hover:text-ink">Cucina asiatica a Taranto</Link>
          <Link to="/app" className="hover:text-ink">Installa l’app</Link>
          <Link to="/press" className="hover:text-ink">Stampa</Link>
          <UserFeedbackButton className="text-left hover:text-ink" />
        </FooterCol>
      </div>
      <div className="container-app mt-10 border-t border-line pt-6 text-xs text-ink-faint">
        <nav aria-label="Informazioni legali" className="flex flex-wrap gap-x-4 gap-y-2 text-ink-muted">
          <Link to="/privacy" className="hover:text-ink">Privacy</Link>
          <Link to="/cookie-policy" className="hover:text-ink">Cookie policy</Link>
          <button type="button" onClick={openConsentPreferences} className="hover:text-ink" data-testid="footer-cookie-prefs">Preferenze cookie</button>
          <Link to="/terms" className="hover:text-ink">Termini</Link>
          <Link to="/business-terms" className="hover:text-ink">Condizioni ristoratori</Link>
          <Link to="/rider-privacy" className="hover:text-ink">Privacy Rider</Link>
          <Link to="/settings/privacy" className="hover:text-ink">I miei dati</Link>
        </nav>
        <CompanyInfo />
        <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} {APP.name}. Informazioni fornite dai locali o raccolte da fonti pubbliche: verifica sempre orari e prezzi.</p>
          <p>Fatto con cura in Puglia.</p>
        </div>
      </div>
    </footer>
  );
}

/** Dati societari da Admin (impostazioni legal_*): segnaposto finché non sono compilati, mai dati inventati. */
function CompanyInfo() {
  const { setting } = useRuntimeConfig();
  const v = (k: string) => setting<string | null>(k, null) || null;
  const missing = '[da completare]';
  return (
    <p className="mt-3" data-testid="company-info">
      {v('legal_company_name') ?? `Ragione sociale ${missing}`} · P.IVA {v('legal_vat_number') ?? missing} · Sede {v('legal_address') ?? missing}
      {' · '}Email {v('legal_email') ?? v('support_email') ?? missing}{v('legal_pec') ? ` · PEC ${v('legal_pec')}` : ''}
    </p>
  );
}

function FooterCol({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-3 font-sans text-xs font-bold uppercase tracking-wider text-ink">{title}</h3>
      <div className="flex flex-col gap-2 text-sm text-ink-muted">{children}</div>
    </div>
  );
}
