import { Suspense, type ReactNode } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { ArrowUpRight, type LucideIcon } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { cn } from '@/lib/format';
import { DemoBanner } from './PublicLayout';
import { Logo } from './Logo';
import { NotificationBell } from './NotificationBell';

export interface DashNavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  end?: boolean;
  badge?: ReactNode;
}

/** Layout area riservata: sidebar su desktop, tab scorrevoli su mobile. */
export function DashboardLayout({ title, nav }: { title: string; nav: DashNavItem[] }) {
  const { profile, user } = useAuth();
  return (
    <div className="min-h-dvh bg-paper">
      <DemoBanner />
      <div className="lg:grid lg:grid-cols-[264px_1fr]">
        <aside className="hidden border-r border-line bg-white lg:block">
          <div className="sticky top-0 flex h-dvh flex-col p-5">
            <div className="flex items-center justify-between gap-2">
              <Logo />
              <NotificationBell />
            </div>
            <p className="mt-6 px-3 text-xs font-bold uppercase tracking-wider text-ink-faint">{title}</p>
            <nav className="mt-2 flex flex-col gap-0.5" aria-label={title}>
              {nav.map((n) => (
                <NavLink
                  key={n.to}
                  to={n.to}
                  end={n.end}
                  className={({ isActive }) =>
                    cn('flex items-center gap-3 rounded-2xl px-3 py-2.5 text-[15px] font-medium transition', isActive ? 'bg-ink text-white' : 'text-ink-soft hover:bg-cream')
                  }
                >
                  <n.icon className="h-[18px] w-[18px]" />
                  <span className="flex-1">{n.label}</span>
                  {n.badge}
                </NavLink>
              ))}
            </nav>
            <div className="mt-auto rounded-3xl bg-cream p-4">
              <p className="truncate text-sm font-semibold">{profile?.full_name || user?.email}</p>
              <p className="truncate text-xs text-ink-muted">{user?.email}</p>
              <Link to="/" className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-coral-700">
                Vai al sito <ArrowUpRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </aside>

        <div className="min-w-0">
          {/* Header mobile */}
          <header className="pt-safe sticky top-0 z-40 border-b border-line bg-white/90 backdrop-blur-xl lg:hidden">
            <div className="flex h-14 items-center justify-between px-4">
              <Logo />
              <div className="flex items-center gap-1">
                <NotificationBell />
                <Link to="/" className="px-2 text-sm font-semibold text-coral-700">
                  Sito
                </Link>
              </div>
            </div>
            <nav className="scrollbar-none flex gap-1 overflow-x-auto px-3 pb-2" aria-label={title}>
              {nav.map((n) => (
                <NavLink
                  key={n.to}
                  to={n.to}
                  end={n.end}
                  className={({ isActive }) =>
                    cn('inline-flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-medium', isActive ? 'bg-ink text-white' : 'bg-cream text-ink-soft')
                  }
                >
                  <n.icon className="h-4 w-4" /> {n.label}
                  {n.badge}
                </NavLink>
              ))}
            </nav>
          </header>
          <main className="mx-auto w-full max-w-6xl px-4 pb-16 pt-6 sm:px-6 lg:px-10 lg:pt-10">
            <Suspense fallback={<div className="flex min-h-[40vh] items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-line border-t-coral" /></div>}>
              <Outlet />
            </Suspense>
          </main>
        </div>
      </div>
    </div>
  );
}

export function PageTitle({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-extrabold sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-ink-muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function StatTile({ label, value, hint, accent }: { label: string; value: ReactNode; hint?: string; accent?: boolean }) {
  return (
    <div className={cn('rounded-3xl border p-5', accent ? 'border-ink bg-ink text-white' : 'border-line bg-white')}>
      <p className={cn('text-sm', accent ? 'text-white/60' : 'text-ink-muted')}>{label}</p>
      <p className="mt-1 font-display text-3xl font-extrabold tabular-nums">{value}</p>
      {hint && <p className={cn('mt-1 text-xs', accent ? 'text-white/50' : 'text-ink-faint')}>{hint}</p>}
    </div>
  );
}
