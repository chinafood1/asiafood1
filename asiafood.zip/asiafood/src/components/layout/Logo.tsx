import { Link } from 'react-router-dom';
import { APP } from '@/config/app';
import { cn } from '@/lib/format';

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      <rect width="64" height="64" rx="16" fill="#16161A" />
      <path d="M14 34h36a18 18 0 0 1-36 0z" fill="#FF5A4E" />
      <path d="M22 12l12 18M30 10l10 20" stroke="#FAF8F5" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  );
}

export function Logo({ className, light }: { className?: string; light?: boolean }) {
  return (
    <Link to="/" className={cn('inline-flex items-center gap-2', className)} aria-label={`${APP.name} — Home`}>
      <LogoMark className="h-8 w-8" />
      <span className={cn('font-display text-xl font-bold tracking-tight', light ? 'text-white' : 'text-ink')}>{APP.name}</span>
    </Link>
  );
}
