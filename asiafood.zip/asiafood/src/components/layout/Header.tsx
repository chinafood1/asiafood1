import { useEffect, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Gift, LayoutDashboard, LogOut, Search, Shield, ShoppingBag, Sparkles, User, UserPlus, Bike } from 'lucide-react';
import { AI, APP } from '@/config/app';
import { useAuth } from '@/context/AuthContext';
import { cn } from '@/lib/format';
import { Logo } from './Logo';
import { NotificationBell } from './NotificationBell';
import { CartButton } from '@/components/orders/OrderParts';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { t } from '@/i18n';

const NAV = [
  { to: '/restaurants', label: 'Esplora' },
  { to: '/all-you-can-eat', label: 'All You Can Eat' },
  { to: '/map', label: 'Mappa' },
  { to: '/offers', label: 'Offerte' },
];

function BetaBadge() {
  const { setting } = useRuntimeConfig();
  if (setting<boolean>('beta_mode', false) !== true) return null;
  // Sovrapposto al logo (non occupa spazio nella barra); affiancato solo su schermi larghi
  return <span className="pointer-events-none absolute -right-2 -top-1.5 rounded-full bg-coral-50 px-1.5 py-px text-[9px] font-bold uppercase tracking-wide text-coral-700 ring-2 ring-paper xl:static xl:px-2 xl:py-0.5 xl:text-[11px] xl:ring-0" data-testid="beta-badge">{t('beta.badge')}</span>;
}

export function Header() {
  const { user, profile, role, isAdmin, isOwner, signOut } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);

  return (
    <header
      className={cn(
        'pt-safe sticky top-0 z-40 transition-[background,box-shadow] duration-300',
        scrolled ? 'bg-paper/85 shadow-[0_1px_0_#E9E4DC] backdrop-blur-xl' : 'bg-paper',
      )}
    >
      <div className="container-app flex h-16 items-center gap-6">
        <span className="relative flex items-center gap-2">
          <Logo />
          <BetaBadge />
        </span>
        <nav className="hidden items-center gap-1 md:flex" aria-label="Principale">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              className={({ isActive }) =>
                cn('rounded-full px-4 py-2 text-[15px] font-medium transition', isActive ? 'bg-ink text-white' : 'text-ink-soft hover:bg-cream')
              }
            >
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {AI.enabled && (
            <Link
              to="/assistant"
              state={{ from: 'header' }}
              className="hidden h-10 items-center gap-1.5 rounded-full border border-line bg-white px-3.5 text-sm font-semibold transition hover:border-ink md:inline-flex"
            >
              <Sparkles className="h-4 w-4 text-coral" /> Chiedi ad {APP.name}
            </Link>
          )}
          <Link
            to="/restaurants"
            aria-label="Cerca"
            className="inline-flex h-10 w-10 items-center justify-center rounded-full text-ink transition hover:bg-cream"
          >
            <Search className="h-5 w-5" />
          </Link>
          <Link to="/per-ristoratori" className="hidden rounded-full px-4 py-2 text-sm font-semibold text-coral-700 transition hover:bg-coral-50 lg:inline-flex">
            Sei un ristoratore?
          </Link>
          <CartButton />
          {user && <NotificationBell />}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setMenu((m) => !m)}
                className="flex h-10 items-center gap-2 rounded-full border border-line bg-white pl-1.5 pr-3 transition hover:border-ink"
                aria-expanded={menu}
                aria-haspopup="menu"
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ink text-xs font-bold text-white">
                  {(profile?.full_name || user.email || '?').slice(0, 1).toUpperCase()}
                </span>
                <span className="hidden max-w-[120px] truncate text-sm font-medium sm:block">{profile?.full_name || 'Profilo'}</span>
              </button>
              {menu && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setMenu(false)} />
                  <div role="menu" className="absolute right-0 z-50 mt-2 w-56 animate-fade-up rounded-3xl border border-line bg-white p-2 shadow-lift">
                    <MenuLink to="/profilo" icon={<User className="h-4 w-4" />} onClick={() => setMenu(false)}>
                      Il mio profilo
                    </MenuLink>
                    <MenuLink to="/profile/orders" icon={<ShoppingBag className="h-4 w-4" />} onClick={() => setMenu(false)}>
                      I miei ordini
                    </MenuLink>
                    {role === 'rider' && (
                      <MenuLink to="/rider" icon={<Bike className="h-4 w-4" />} onClick={() => setMenu(false)}>
                        App Rider
                      </MenuLink>
                    )}
                    <MenuLink to="/profile/loyalty" icon={<Gift className="h-4 w-4" />} onClick={() => setMenu(false)}>
                      I miei punti
                    </MenuLink>
                    <MenuLink to="/profile/referrals" icon={<UserPlus className="h-4 w-4" />} onClick={() => setMenu(false)}>
                      Invita un amico
                    </MenuLink>
                    <MenuLink to="/dashboard" icon={<LayoutDashboard className="h-4 w-4" />} onClick={() => setMenu(false)}>
                      {isOwner ? 'I miei locali' : 'Le mie richieste'}
                    </MenuLink>
                    {isAdmin && (
                      <MenuLink to="/admin" icon={<Shield className="h-4 w-4" />} onClick={() => setMenu(false)}>
                        Pannello Admin
                      </MenuLink>
                    )}
                    <button
                      onClick={async () => {
                        setMenu(false);
                        await signOut();
                        navigate('/');
                      }}
                      className="flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left text-sm text-ink-soft hover:bg-cream"
                    >
                      <LogOut className="h-4 w-4" /> Esci
                    </button>
                  </div>
                </>
              )}
            </div>
          ) : (
            <Link to="/accedi" className="inline-flex h-10 items-center rounded-full bg-ink px-5 text-sm font-semibold text-white transition hover:bg-ink-soft">
              Accedi
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}

function MenuLink({ to, icon, children, onClick }: { to: string; icon: React.ReactNode; children: React.ReactNode; onClick: () => void }) {
  return (
    <Link to={to} onClick={onClick} role="menuitem" className="flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm text-ink hover:bg-cream">
      {icon}
      {children}
    </Link>
  );
}
