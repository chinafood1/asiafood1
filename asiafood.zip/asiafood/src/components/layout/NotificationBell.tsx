import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bell, CheckCheck } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { cn, formatDate } from '@/lib/format';
import { setAppBadge } from '@/lib/push';
import { api } from '@/services';
import type { AppNotification } from '@/types/domain';

/** Campanella notifiche: badge non lette, anteprima (desktop), pagina completa su mobile. */
export function NotificationBell({ className }: { className?: string }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [unread, setUnread] = useState(0);
  const [items, setItems] = useState<AppNotification[]>([]);
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);

  const load = useCallback(() => {
    if (!user) return;
    void api.listNotificationsPage({ limit: 6, offset: 0 }).then(
      (r) => {
        setUnread(r.unread);
        setItems(r.items);
        setAppBadge(r.unread);
      },
      () => undefined,
    );
  }, [user]);

  useEffect(() => {
    if (!user) return;
    load();
    const t = window.setInterval(load, 120_000);
    window.addEventListener('af:notifications', load);
    return () => {
      window.clearInterval(t);
      window.removeEventListener('af:notifications', load);
    };
  }, [user, load]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => !wrap.current?.contains(e.target as Node) && setOpen(false);
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  if (!user) return null;
  const label = unread ? `Notifiche, ${unread} da leggere` : 'Notifiche';
  const openItem = async (n: AppNotification) => {
    setOpen(false);
    if (!n.read_at) await api.markNotificationsRead([n.id]).catch(() => undefined);
    window.dispatchEvent(new Event('af:notifications'));
    navigate(n.link ?? '/notifications');
  };

  return (
    <div ref={wrap} className={cn('relative', className)}>
      <button
        type="button"
        aria-label={label}
        aria-expanded={open}
        aria-haspopup="true"
        onClick={() => (window.matchMedia('(min-width: 768px)').matches ? setOpen((o) => !o) : navigate('/notifications'))}
        className="relative inline-flex h-10 w-10 items-center justify-center rounded-full text-ink-soft transition hover:bg-cream hover:text-ink"
      >
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-coral px-1 text-[11px] font-bold text-white" aria-hidden>
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>
      {open && (
        <div role="dialog" aria-label="Notifiche" className="absolute right-0 z-50 mt-2 w-[360px] animate-fade-up overflow-hidden rounded-3xl border border-line bg-white shadow-lift">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <p className="font-bold">Notifiche</p>
            {unread > 0 && (
              <button type="button" className="inline-flex items-center gap-1 text-xs font-semibold text-coral-700 hover:underline" onClick={async () => { await api.markNotificationsRead(); window.dispatchEvent(new Event('af:notifications')); }}>
                <CheckCheck className="h-3.5 w-3.5" /> Segna tutte come lette
              </button>
            )}
          </div>
          {items.length === 0 ? (
            <p className="px-4 py-8 text-center text-sm text-ink-muted">Nessuna notifica</p>
          ) : (
            <ul className="max-h-[380px] divide-y divide-line overflow-y-auto">
              {items.map((n) => (
                <li key={n.id}>
                  <button type="button" onClick={() => void openItem(n)} className={cn('flex w-full gap-3 px-4 py-3 text-left hover:bg-cream', !n.read_at && 'bg-coral-50/40')}>
                    <span className={cn('mt-1.5 h-2 w-2 shrink-0 rounded-full', n.read_at ? 'bg-transparent' : 'bg-coral')} aria-hidden />
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-semibold">{n.title}{!n.read_at && <span className="sr-only"> (da leggere)</span>}</span>
                      {n.body && <span className="line-clamp-2 block text-[13px] text-ink-muted">{n.body}</span>}
                      <span className="mt-0.5 block text-[11px] text-ink-faint">{formatDate(n.created_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
          <Link to="/notifications" onClick={() => setOpen(false)} className="block border-t border-line px-4 py-3 text-center text-sm font-semibold text-coral-700 hover:bg-cream">
            Vedi tutte
          </Link>
        </div>
      )}
    </div>
  );
}
