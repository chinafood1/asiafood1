import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { cn } from '@/lib/format';

export type SheetSnap = 'closed' | 'half' | 'full';

/**
 * Bottom sheet trascinabile per la mappa mobile, con tre stati:
 * chiuso (solo maniglia e conteggio), metà schermo, schermo intero.
 * Si posiziona in assoluto dentro il contenitore della mappa.
 */
export function BottomSheet({
  snap,
  onSnapChange,
  header,
  children,
  peek = 88,
  topGap = 76,
  bottomOffset = 0,
  className,
}: {
  snap: SheetSnap;
  onSnapChange: (s: SheetSnap) => void;
  /** Sempre visibile (anche da chiuso): titolo, conteggio, azioni rapide. */
  header: ReactNode;
  children: ReactNode;
  /** Altezza visibile in stato "chiuso". */
  peek?: number;
  /** Spazio lasciato libero in alto in stato "pieno" (barra di ricerca). */
  topGap?: number;
  /** Spazio occupato in basso da altri elementi (bottom nav). */
  bottomOffset?: number;
  className?: string;
}) {
  const rootRef = useRef<HTMLDivElement>(null);
  const [containerH, setContainerH] = useState(0);
  const [drag, setDrag] = useState<number | null>(null);
  const start = useRef<{ y: number; visible: number; t: number } | null>(null);
  const moved = useRef(false);

  useLayoutEffect(() => {
    const parent = rootRef.current?.parentElement;
    if (!parent) return;
    const update = () => setContainerH(parent.clientHeight);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(parent);
    return () => ro.disconnect();
  }, []);

  const usable = Math.max(0, containerH - bottomOffset);
  const heights: Record<SheetSnap, number> = {
    closed: peek,
    half: Math.round(usable * 0.5),
    full: Math.max(peek, usable - topGap),
  };
  const maxH = heights.full;
  const visible = drag ?? heights[snap];

  // Esc riduce il foglio
  useEffect(() => {
    if (snap === 'closed') return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onSnapChange(snap === 'full' ? 'half' : 'closed');
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [snap, onSnapChange]);

  const onPointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('button:not([data-sheet-handle]),a,input,select')) return;
    start.current = { y: e.clientY, visible: heights[snap], t: performance.now() };
    moved.current = false;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!start.current) return;
    const dy = start.current.y - e.clientY;
    if (Math.abs(dy) > 4) moved.current = true;
    if (moved.current) setDrag(Math.min(maxH, Math.max(peek * 0.6, start.current.visible + dy)));
  };
  const onPointerUp = (e: React.PointerEvent) => {
    const s = start.current;
    start.current = null;
    if (!s) return;
    if (!moved.current) {
      setDrag(null);
      return;
    }
    const dy = s.y - e.clientY;
    const v = dy / Math.max(1, performance.now() - s.t); // px/ms, positivo = verso l'alto
    const cur = Math.min(maxH, Math.max(peek, s.visible + dy));
    const order: SheetSnap[] = ['closed', 'half', 'full'];
    let next: SheetSnap;
    if (Math.abs(v) > 0.5) {
      const idx = order.indexOf(snap);
      next = order[Math.min(2, Math.max(0, idx + (v > 0 ? 1 : -1)))];
    } else {
      next = order.reduce((best, k) => (Math.abs(heights[k] - cur) < Math.abs(heights[best] - cur) ? k : best), 'closed' as SheetSnap);
    }
    setDrag(null);
    onSnapChange(next);
  };

  const cycle = () => onSnapChange(snap === 'closed' ? 'half' : snap === 'half' ? 'full' : 'closed');
  const label = snap === 'closed' ? 'Espandi elenco' : snap === 'half' ? 'Espandi a tutto schermo' : 'Riduci elenco';

  return (
    <div
      ref={rootRef}
      className={cn('absolute inset-x-0 z-30 flex flex-col rounded-t-[28px] bg-paper shadow-[0_-8px_30px_rgba(20,20,30,.14)]', className)}
      style={{
        bottom: bottomOffset,
        height: maxH || undefined,
        transform: `translateY(${Math.max(0, maxH - visible)}px)`,
        transition: drag === null ? 'transform .28s cubic-bezier(.2,.8,.2,1)' : 'none',
        visibility: containerH ? 'visible' : 'hidden',
      }}
      role="region"
      aria-label="Elenco ristoranti"
    >
      <div
        className="shrink-0 cursor-grab touch-none select-none active:cursor-grabbing"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      >
        <button
          type="button"
          data-sheet-handle
          onClick={() => !moved.current && cycle()}
          aria-label={label}
          aria-expanded={snap !== 'closed'}
          className="mx-auto flex h-6 w-full items-center justify-center"
        >
          <span className="h-1.5 w-10 rounded-full bg-line" />
        </button>
        <div className="px-4 pb-2">{header}</div>
      </div>
      <div
        // Da chiuso il contenuto è fuori schermo: "invisible" lo toglie anche da tab e screen reader
        className={cn('min-h-0 flex-1 overscroll-contain px-4 pb-4', snap === 'closed' && drag === null ? 'invisible overflow-hidden' : 'overflow-y-auto')}
      >
        {children}
      </div>
    </div>
  );
}
