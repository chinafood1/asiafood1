import { forwardRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Bike, Infinity as InfinityIcon, MapPinOff, Navigation, ShoppingBag, X } from 'lucide-react';
import { cn, formatDistance, formatPrice, priceRangeLabel } from '@/lib/format';
import { directionsUrl } from '@/lib/geo';
import { api } from '@/services';
import type { RestaurantSummary } from '@/types/domain';
import { OrderOnlineBadge } from '@/components/orders/OrderParts';
import { Badge, SponsoredBadge, VerifiedBadge } from '@/components/ui/Badge';
import { Monogram, SmartImage } from '@/components/ui/SmartImage';
import { isOwnerVerified } from '@/components/restaurant/RestaurantCard';

type Variant = 'list' | 'popup' | 'carousel';

/**
 * Card ristorante per la mappa (lista, popup desktop, carosello mobile).
 * Mostra solo i dati presenti: nessun campo vuoto, nessun rating.
 */
export const RestaurantMapCard = forwardRef<HTMLElement, {
  r: RestaurantSummary;
  variant?: Variant;
  active?: boolean;
  onClose?: () => void;
  onActivate?: () => void;
  onHover?: (on: boolean) => void;
  source?: string;
}>(function RestaurantMapCard({ r, variant = 'list', active, onClose, onActivate, onHover, source = 'map' }, ref) {
  const cats = r.categories.filter((c) => c.slug !== 'all-you-can-eat').slice(0, 2);
  const ayce = Math.min(...[r.ayce_lunch_price, r.ayce_dinner_price].filter((x): x is number => x != null));
  const hasCoords = r.latitude != null && r.longitude != null;
  const compact = variant !== 'list';
  const href = `/ristorante/${r.slug}`;

  return (
    <article
      ref={ref}
      data-id={r.id}
      onMouseEnter={() => onHover?.(true)}
      onMouseLeave={() => onHover?.(false)}
      onClick={(e) => {
        if ((e.target as HTMLElement).closest('a,button')) return;
        onActivate?.();
      }}
      aria-current={active ? 'true' : undefined}
      className={cn(
        'group relative flex gap-3 rounded-3xl border bg-white transition',
        variant === 'list' && 'cursor-pointer p-2.5 hover:shadow-card',
        variant === 'popup' && 'w-[380px] max-w-[calc(100vw-2rem)] p-3 shadow-lift',
        variant === 'carousel' && 'w-[min(86vw,360px)] shrink-0 snap-center p-2.5 shadow-lift',
        active ? 'border-ink ring-1 ring-ink' : 'border-line',
      )}
    >
      <Link to={href} state={{ source }} tabIndex={-1} aria-hidden className="relative shrink-0">
        <SmartImage src={r.cover_url} alt="" seed={r.id} emoji={r.categories[0]?.emoji} className={cn('rounded-2xl', compact ? 'h-[104px] w-[96px]' : 'h-[108px] w-[112px]')} />
        {r.logo_url && <Monogram name={r.name} src={r.logo_url} className="absolute -bottom-1 -right-1 h-8 w-8 border-2 border-white text-[10px]" />}
      </Link>
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start gap-2 pr-6">
          <h3 className="min-w-0 truncate text-[15px] font-bold leading-tight">
            <Link to={href} state={{ source }} className="hover:text-coral-700 focus-visible:underline">{r.name}</Link>
          </h3>
        </div>
        {(isOwnerVerified(r) || r.sponsored_now) && (
          <div className="mt-1 flex flex-wrap gap-1">
            {isOwnerVerified(r) && <VerifiedBadge />}
            {r.sponsored_now && <SponsoredBadge />}
          </div>
        )}
        <p className="mt-1 truncate text-[13px] text-ink-muted">
          {[...cats.map((c) => c.name), r.city?.name].filter(Boolean).join(' · ')}
          {r.distance_km !== undefined && <span className="font-semibold text-ink"> · {formatDistance(r.distance_km)}</span>}
        </p>
        <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[12px] font-medium text-ink-soft">
          {r.price_range && <span aria-label={`Fascia di prezzo ${r.price_range} su 4`}>{priceRangeLabel(r.price_range)}</span>}
          {r.is_all_you_can_eat && (
            <span className="inline-flex items-center gap-1 rounded-full bg-coral-50 px-2 py-0.5 text-coral-700">
              <InfinityIcon className="h-3 w-3" /> AYCE{Number.isFinite(ayce) ? ` ${formatPrice(ayce)}` : ''}
            </span>
          )}
          {r.has_delivery && <span className="inline-flex items-center gap-1"><Bike className="h-3.5 w-3.5" /> Delivery</span>}
          {r.has_takeaway && <span className="inline-flex items-center gap-1"><ShoppingBag className="h-3.5 w-3.5" /> Asporto</span>}
          <OrderOnlineBadge restaurantId={r.id} />
          {r.is_temporarily_closed && <Badge tone="amber">Chiuso temp.</Badge>}
        </div>
        {!hasCoords && variant === 'list' && (
          <p className="mt-1 inline-flex items-center gap-1 text-[11px] text-ink-faint"><MapPinOff className="h-3 w-3" /> Non ancora sulla mappa</p>
        )}
        <div className="mt-auto flex items-center justify-between gap-2 pt-2">
          <Link to={href} state={{ source }} className="inline-flex items-center gap-1 whitespace-nowrap text-sm font-semibold text-coral-700 hover:gap-1.5">
            Vedi ristorante <ArrowRight className="h-4 w-4" />
          </Link>
          {variant !== 'list' && hasCoords && (
            <a
              href={directionsUrl(r)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`Indicazioni per ${r.name}`}
              onClick={() => {
                api.track(r.id, 'directions_click', source);
                api.trackAppEvent('directions_click', { restaurantId: r.id, source });
              }}
              className={cn('inline-flex h-8 shrink-0 items-center justify-center gap-1 rounded-full bg-cream text-xs font-semibold hover:bg-line', variant === 'carousel' ? 'w-8' : 'px-3')}
            >
              <Navigation className="h-3.5 w-3.5" />
              {variant !== 'carousel' && ' Indicazioni'}
            </a>
          )}
        </div>
      </div>
      {onClose && (
        <button type="button" aria-label="Chiudi" onClick={onClose} className="absolute right-2 top-2 rounded-full p-1.5 text-ink-muted hover:bg-cream hover:text-ink">
          <X className="h-4 w-4" />
        </button>
      )}
    </article>
  );
});

export function MapCardSkeleton({ variant = 'list' }: { variant?: Variant }) {
  return (
    <div className={cn('flex gap-3 rounded-3xl border border-line bg-white p-2.5', variant === 'carousel' && 'w-[min(86vw,360px)] shrink-0')} aria-hidden>
      <div className="skeleton h-[104px] w-[100px] shrink-0 rounded-2xl" />
      <div className="flex-1 space-y-2 py-1">
        <div className="skeleton h-4 w-2/3" />
        <div className="skeleton h-3 w-1/2" />
        <div className="skeleton h-3 w-1/3" />
      </div>
    </div>
  );
}
