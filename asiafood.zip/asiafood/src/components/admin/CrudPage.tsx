import { useMemo, useState } from 'react';
import { Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { cn } from '@/lib/format';
import { api, type Row, type TableName } from '@/services';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { PageTitle } from '@/components/layout/DashboardLayout';

export type CrudFieldType = 'text' | 'number' | 'textarea' | 'boolean' | 'select' | 'date' | 'json' | 'slug';

export interface CrudField {
  key: string;
  label: string;
  type: CrudFieldType;
  required?: boolean;
  /** Mostra la colonna in tabella */
  list?: boolean;
  hint?: string;
  options?: { value: string; label: string }[];
  /** Opzioni caricate da un'altra tabella */
  optionsFrom?: { table: TableName; value: string; label: string; orderBy?: string };
  /** Opzioni caricate da una funzione custom (es. ristoranti) */
  loadOptions?: () => Promise<{ value: string; label: string }[]>;
  nullable?: boolean;
  /** Per slug: campo da cui generarlo */
  from?: string;
  readOnlyOnEdit?: boolean;
}

export interface CrudConfig {
  table: TableName;
  title: string;
  subtitle?: string;
  primaryKey?: string;
  fields: CrudField[];
  defaults?: Row;
  orderBy?: string;
  ascending?: boolean;
  searchKeys?: string[];
}

const slugify = (s: string) =>
  s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

function useOptions(fields: CrudField[]) {
  return useAsync(async () => {
    const out: Record<string, { value: string; label: string }[]> = {};
    await Promise.all(
      fields.map(async (f) => {
        if (f.options) out[f.key] = f.options;
        else if (f.loadOptions) out[f.key] = await f.loadOptions();
        else if (f.optionsFrom) {
          const rows = await api.list<Row>(f.optionsFrom.table, { orderBy: f.optionsFrom.orderBy ?? f.optionsFrom.label });
          out[f.key] = rows.map((r) => ({ value: String(r[f.optionsFrom!.value]), label: String(r[f.optionsFrom!.label]) }));
        }
      }),
    );
    return out;
  }, []);
}

/** Pagina CRUD generica per tabelle di riferimento/gestione (protetta da RLS). */
export function CrudPage({ config }: { config: CrudConfig }) {
  const pk = config.primaryKey ?? 'id';
  const toast = useToast();
  const rows = useAsync(() => api.list<Row>(config.table, { orderBy: config.orderBy, ascending: config.ascending }), [config.table]);
  const options = useOptions(config.fields);
  const [editing, setEditing] = useState<{ row: Row; isNew: boolean } | null>(null);
  const [q, setQ] = useState('');
  const [saving, setSaving] = useState(false);

  const filtered = useMemo(() => {
    const list = rows.data ?? [];
    if (!q) return list;
    const keys = config.searchKeys ?? config.fields.filter((f) => f.list).map((f) => f.key);
    return list.filter((r) => keys.some((k) => String(r[k] ?? '').toLowerCase().includes(q.toLowerCase())));
  }, [rows.data, q, config]);

  const listFields = config.fields.filter((f) => f.list);
  const labelFor = (f: CrudField, v: unknown) => {
    if (v === null || v === undefined || v === '') return '—';
    if (f.type === 'boolean') return v ? 'Sì' : 'No';
    if (f.type === 'date') return new Date(String(v)).toLocaleDateString('it-IT');
    if (f.type === 'json') return JSON.stringify(v).slice(0, 40);
    const opt = options.data?.[f.key]?.find((o) => o.value === String(v));
    return opt?.label ?? String(v);
  };

  const save = async () => {
    if (!editing) return;
    for (const f of config.fields) {
      if (f.required && (editing.row[f.key] === undefined || editing.row[f.key] === null || editing.row[f.key] === '')) {
        return toast(`Il campo “${f.label}” è obbligatorio`, 'error');
      }
    }
    setSaving(true);
    try {
      const data: Row = { ...editing.row };
      for (const f of config.fields) {
        if (f.type === 'json' && typeof data[f.key] === 'string') data[f.key] = JSON.parse(String(data[f.key]) || '{}');
        if (f.nullable && data[f.key] === '') data[f.key] = null;
      }
      await api.upsert(config.table, data, pk);
      toast('Salvato');
      setEditing(null);
      rows.reload();
    } catch (e) {
      toast(e instanceof SyntaxError ? 'JSON non valido' : (e as Error).message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const del = async (r: Row) => {
    if (!confirm('Eliminare definitivamente questo elemento?')) return;
    try {
      await api.remove(config.table, String(r[pk]), pk);
      toast('Eliminato');
      rows.reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };

  const set = (k: string, v: unknown) => setEditing((e) => (e ? { ...e, row: { ...e.row, [k]: v } } : e));

  return (
    <div>
      <PageTitle
        title={config.title}
        subtitle={config.subtitle}
        action={
          <Button icon={<Plus className="h-4 w-4" />} onClick={() => setEditing({ row: { ...(config.defaults ?? {}) }, isNew: true })}>
            Aggiungi
          </Button>
        }
      />
      <div className="mb-4 flex max-w-sm items-center gap-2 rounded-full border border-line bg-white px-4">
        <Search className="h-4 w-4 text-ink-muted" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filtra…" className="h-11 flex-1 bg-transparent text-sm focus:outline-none" />
      </div>

      {rows.loading ? (
        <PageLoader />
      ) : rows.error ? (
        <EmptyState icon="⚠️" title="Errore di caricamento" text={rows.error.message} />
      ) : filtered.length === 0 ? (
        <EmptyState icon="📭" title="Nessun elemento" />
      ) : (
        <div className="overflow-x-auto rounded-3xl border border-line bg-white">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="border-b border-line bg-cream/60 text-xs uppercase tracking-wider text-ink-muted">
              <tr>
                {listFields.map((f) => (
                  <th key={f.key} className="px-4 py-3 font-semibold">{f.label}</th>
                ))}
                <th className="w-24 px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {filtered.map((r) => (
                <tr key={String(r[pk])} className="hover:bg-paper">
                  {listFields.map((f) => (
                    <td key={f.key} className={cn('max-w-[260px] truncate px-4 py-3', f.type === 'boolean' && (r[f.key] ? 'text-emerald-700' : 'text-ink-faint'))}>
                      {labelFor(f, r[f.key])}
                    </td>
                  ))}
                  <td className="px-2 py-2 text-right">
                    <button aria-label="Modifica" onClick={() => setEditing({ row: { ...r }, isNew: false })} className="rounded-full p-2 text-ink-muted hover:bg-cream hover:text-ink"><Pencil className="h-4 w-4" /></button>
                    <button aria-label="Elimina" onClick={() => del(r)} className="rounded-full p-2 text-ink-muted hover:bg-coral-50 hover:text-coral-700"><Trash2 className="h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Sheet
        open={!!editing}
        onClose={() => setEditing(null)}
        title={editing?.isNew ? 'Nuovo elemento' : 'Modifica'}
        wide
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setEditing(null)}>Annulla</Button>
            <Button loading={saving} onClick={save}>Salva</Button>
          </div>
        }
      >
        {editing && (
          <div className="grid gap-4 sm:grid-cols-2">
            {config.fields.map((f) => {
              const v = editing.row[f.key];
              const disabled = f.readOnlyOnEdit && !editing.isNew;
              const wide = f.type === 'textarea' || f.type === 'json';
              if (f.type === 'boolean') {
                return (
                  <div key={f.key} className="sm:col-span-1">
                    <Toggle label={f.label} description={f.hint} checked={!!v} onChange={(x) => set(f.key, x)} disabled={disabled} />
                  </div>
                );
              }
              return (
                <Field key={f.key} label={`${f.label}${f.required ? ' *' : ''}`} hint={f.hint} className={wide ? 'sm:col-span-2' : undefined}>
                  {f.type === 'textarea' ? (
                    <Textarea rows={3} value={String(v ?? '')} onChange={(e) => set(f.key, e.target.value)} disabled={disabled} />
                  ) : f.type === 'json' ? (
                    <Textarea rows={4} className="font-mono text-xs" value={typeof v === 'string' ? v : JSON.stringify(v ?? {}, null, 2)} onChange={(e) => set(f.key, e.target.value)} disabled={disabled} />
                  ) : f.type === 'select' ? (
                    <Select value={String(v ?? '')} onChange={(e) => set(f.key, e.target.value || null)} disabled={disabled}>
                      <option value="">{f.nullable ? '— Nessuno —' : 'Seleziona…'}</option>
                      {(options.data?.[f.key] ?? []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </Select>
                  ) : f.type === 'number' ? (
                    <Input type="number" step="any" value={v === null || v === undefined ? '' : String(v)} onChange={(e) => set(f.key, e.target.value === '' ? null : Number(e.target.value))} disabled={disabled} />
                  ) : f.type === 'date' ? (
                    <Input type="date" value={v ? String(v).slice(0, 10) : ''} onChange={(e) => set(f.key, e.target.value ? new Date(`${e.target.value}T00:00:00`).toISOString() : null)} disabled={disabled} />
                  ) : (
                    <div className="flex gap-2">
                      <Input value={String(v ?? '')} onChange={(e) => set(f.key, f.type === 'slug' ? slugify(e.target.value) : e.target.value)} disabled={disabled} />
                      {f.type === 'slug' && f.from && (
                        <Button type="button" variant="soft" size="sm" className="!h-auto" onClick={() => set(f.key, slugify(String(editing.row[f.from!] ?? '')))}>
                          Genera
                        </Button>
                      )}
                    </div>
                  )}
                </Field>
              );
            })}
          </div>
        )}
      </Sheet>
    </div>
  );
}
