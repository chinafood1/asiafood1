// ─────────────────────────────────────────────────────────────
//  Fase 13 · "AsiaFood Performance" e Business Copilot del ristoratore.
//  Solo i dati del proprio locale (autorizzazione nel database: restaurant_performance).
//  Il Copilot risponde in modo deterministico dal payload autorizzato: niente concorrenti,
//  niente numeri inventati, nessuna garanzia di risultato.
// ─────────────────────────────────────────────────────────────
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bot, Lightbulb, Send, TrendingDown, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Chip } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Field';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { api } from '@/services';
import { COPILOT_SUGGESTIONS, copilotAnswer, pctChange, PERF_LABELS, restaurantInsights, restaurantRecommendations, type PerfCounts, type RestaurantPerformance } from '@shared/growth';
import type { EditorTabProps } from '@/components/editor/form';

const euro = (c: number) => (c / 100).toLocaleString('it-IT', { style: 'currency', currency: 'EUR' });
const KEYS: (keyof PerfCounts)[] = ['impressions', 'views', 'menu_views', 'calls', 'whatsapp', 'directions', 'bookings', 'orders', 'coupon_redemptions', 'revenue_cents'];

function usePerf(id: string) {
  return useAsync(() => api.growth.performance(id), [id]);
}

function Tile({ k, cur, prev, complete }: { k: keyof PerfCounts; cur: number; prev: number; complete: boolean }) {
  const ch = pctChange(cur, prev, complete);
  const label = PERF_LABELS[k];
  return (
    <div className="rounded-3xl border border-line bg-white p-4" data-testid={`perf-${k}`}>
      <p className="text-xs text-ink-muted">{label[0]!.toUpperCase() + label.slice(1)}</p>
      <p className="mt-1 font-display text-2xl font-extrabold tabular-nums">{k === 'revenue_cents' ? euro(cur) : cur.toLocaleString('it-IT')}</p>
      {ch != null ? (
        <p className={cn('mt-0.5 inline-flex items-center gap-1 text-xs font-semibold', ch > 0 ? 'text-emerald-700' : ch < 0 ? 'text-coral-700' : 'text-ink-muted')}>
          {ch > 0 ? <TrendingUp className="h-3.5 w-3.5" aria-hidden /> : ch < 0 ? <TrendingDown className="h-3.5 w-3.5" aria-hidden /> : null}{ch > 0 ? '+' : ''}{ch.toLocaleString('it-IT')}% vs periodo precedente
        </p>
      ) : <p className="mt-0.5 text-xs text-ink-muted">{prev === 0 && cur > 0 ? 'Nuovo rispetto al periodo precedente' : 'Confronto non disponibile'}</p>}
    </div>
  );
}

export function PerformanceSection({ r, base }: EditorTabProps & { base: string }) {
  const p = usePerf(r.id);
  const [days, setDays] = useState<'7' | '30'>('30');
  if (p.loading && !p.data) return <PageLoader />;
  if (p.error || !p.data) return <Alert tone="error">{friendlyError(p.error)}</Alert>;
  const d = p.data;
  const per = d.periods[days];
  const insights = restaurantInsights(d);
  const recs = restaurantRecommendations(d);
  return (
    <div className="space-y-5" data-testid="restaurant-performance">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex gap-2" role="group" aria-label="Periodo">
          <Chip active={days === '7'} onClick={() => setDays('7')}>7 giorni</Chip>
          <Chip active={days === '30'} onClick={() => setDays('30')}>30 giorni</Chip>
        </div>
        <p className="text-xs text-ink-muted">{d.freshness ? `Aggiornato ${new Date(d.freshness).toLocaleString('it-IT', { dateStyle: 'short', timeStyle: 'short' })}` : ''} · confronto con i {days} giorni precedenti</p>
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        {KEYS.map((k) => <Tile key={k} k={k} cur={per.current[k]} prev={per.previous[k]} complete={per.previous_complete} />)}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-3xl border border-line bg-white p-5" aria-labelledby="perf-ins">
          <h2 id="perf-ins" className="text-lg font-bold">Cosa dicono i tuoi dati</h2>
          {insights.length ? (
            <ul className="mt-3 space-y-2" data-testid="perf-insights">
              {insights.map((i) => <li key={i.key} className={cn('rounded-2xl px-3 py-2 text-sm', i.tone === 'good' ? 'bg-emerald-50 text-emerald-800' : i.tone === 'warn' ? 'bg-amber-50 text-amber-900' : 'bg-cream/60')}>{i.text}</li>)}
            </ul>
          ) : <p className="mt-2 text-sm text-ink-muted">Non ci sono ancora abbastanza dati per suggerimenti affidabili.</p>}
          <dl className="mt-4 grid grid-cols-2 gap-2 text-sm">
            <div><dt className="text-ink-muted">Clienti tornati (90 giorni)</dt><dd className="font-bold">{d.repeat_customers_90d}</dd></div>
            <div><dt className="text-ink-muted">Recensioni</dt><dd className="font-bold">{d.reviews.count}{d.reviews.avg != null ? ` · media ${d.reviews.avg.toLocaleString('it-IT')}` : ''}</dd></div>
            <div><dt className="text-ink-muted">Profilo completo</dt><dd className="font-bold">{d.completion?.score ?? '—'}%</dd></div>
            <div><dt className="text-ink-muted">Offerte e coupon attivi</dt><dd className="font-bold">{d.offers_active}</dd></div>
          </dl>
        </section>
        <section className="rounded-3xl border border-line bg-white p-5" aria-labelledby="perf-rec">
          <h2 id="perf-rec" className="flex items-center gap-2 text-lg font-bold"><Lightbulb className="h-5 w-5" aria-hidden />Cosa puoi migliorare</h2>
          {recs.length ? (
            <ul className="mt-3 space-y-2" data-testid="perf-recommendations">
              {recs.map((x) => (
                <li key={x.key} className="flex items-start justify-between gap-3 rounded-2xl border border-line p-3 text-sm">
                  <span><strong>{x.title}</strong><span className="block text-ink-muted">{x.why}</span></span>
                  <Link to={`${base}/${x.section}`} className="shrink-0 font-semibold text-coral-700 hover:underline">Vai</Link>
                </li>
              ))}
            </ul>
          ) : <p className="mt-2 text-sm text-ink-muted">Il profilo è completo: continua ad aggiornare menu e offerte.</p>}
          <p className="mt-3 text-xs text-ink-muted">Suggerimenti pratici, non garanzie di risultato.</p>
        </section>
      </div>
      {d.menu.top.some((t) => t.views > 0) && (
        <section className="rounded-3xl border border-line bg-white p-5">
          <h2 className="text-lg font-bold">Piatti più visti (30 giorni)</h2>
          <div className="-mx-5 mt-2 overflow-x-auto px-5" tabIndex={0} role="region" aria-label="Piatti più visti">
            <table className="w-full min-w-[480px] text-left text-sm">
              <thead className="text-xs uppercase tracking-wide text-ink-muted"><tr><th className="py-2">Piatto</th><th>Viste</th><th>Nel carrello</th><th>Ordinati</th><th>Foto</th></tr></thead>
              <tbody className="divide-y divide-line">
                {d.menu.top.filter((t) => t.views > 0).map((t) => <tr key={t.id}><td className="py-2">{t.name}</td><td>{t.views}</td><td>{t.add_to_cart}</td><td>{t.ordered}</td><td>{t.has_image ? 'Sì' : 'No'}</td></tr>)}
              </tbody>
            </table>
          </div>
        </section>
      )}
      <p className="text-xs text-ink-muted">Definizioni: apparizioni = volte in cui il locale è comparso nei risultati di una ricerca registrata; incasso = ordini online pagati. Solo i dati del tuo locale.</p>
    </div>
  );
}

export function CopilotSection({ r }: EditorTabProps & { base: string }) {
  const p = usePerf(r.id);
  const [q, setQ] = useState('');
  const [chat, setChat] = useState<{ q: string; a: string; sources: string[] }[]>([]);
  const ask = (question: string, data: RestaurantPerformance) => {
    const res = copilotAnswer(question, data);
    setChat((c) => [...c, { q: question, a: res.answer, sources: res.sources }].slice(-10));
    setQ('');
  };
  if (p.loading && !p.data) return <PageLoader />;
  if (p.error || !p.data) return <Alert tone="error">{friendlyError(p.error)}</Alert>;
  const d = p.data;
  return (
    <div className="space-y-4" data-testid="restaurant-copilot">
      <div className="rounded-3xl border border-line bg-white p-5">
        <h2 className="flex items-center gap-2 text-lg font-bold"><Bot className="h-5 w-5" aria-hidden />Copilot di {d.restaurant.name}</h2>
        <p className="mt-1 text-sm text-ink-muted">Risponde solo con i dati del tuo locale su AsiaFood. Non ha dati su altri ristoranti e non promette risultati.</p>
        <div className="mt-3 flex flex-wrap gap-1.5">{COPILOT_SUGGESTIONS.map((s) => <Chip key={s} onClick={() => ask(s, d)}>{s}</Chip>)}</div>
        <ul className="mt-4 space-y-3" aria-live="polite">
          {chat.map((m, i) => (
            <li key={i} className="space-y-1.5">
              <p className="ml-auto w-fit max-w-[85%] rounded-2xl bg-ink px-3 py-2 text-sm text-white">{m.q}</p>
              <div className="max-w-[85%] rounded-2xl bg-cream/70 px-3 py-2 text-sm" data-testid="copilot-answer">{m.a}
                {m.sources.length > 0 && <p className="mt-1 text-xs text-ink-muted">Fonte: {m.sources.join(', ')}</p>}</div>
            </li>
          ))}
        </ul>
        <form className="mt-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (q.trim().length >= 3) ask(q.trim(), d); }}>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Chiedi qualcosa sul tuo locale" aria-label="Domanda al Copilot" maxLength={200} />
          <Button type="submit" icon={<Send className="h-4 w-4" />} disabled={q.trim().length < 3}>Chiedi</Button>
        </form>
      </div>
    </div>
  );
}
