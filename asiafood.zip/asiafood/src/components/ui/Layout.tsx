import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/format';

export function SectionHeader({
  eyebrow,
  title,
  subtitle,
  to,
  action,
  className,
  dark,
  linkLabel = 'Vedi tutti',
}: {
  dark?: boolean;
  linkLabel?: string;
  eyebrow?: string;
  title: string;
  subtitle?: string;
  to?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('mb-5 flex items-end justify-between gap-4', className)}>
      <div>
        {eyebrow && <p className={cn('mb-1 text-xs font-semibold uppercase tracking-[0.16em]', dark ? 'text-coral-400' : 'text-coral')}>{eyebrow}</p>}
        <h2 className="text-2xl font-bold sm:text-[28px]">{title}</h2>
        {subtitle && <p className={cn('mt-1 text-[15px]', dark ? 'text-white/60' : 'text-ink-muted')}>{subtitle}</p>}
      </div>
      {action}
      {to && !action && (
        <Link to={to} className={cn('group inline-flex shrink-0 items-center gap-1 text-sm font-semibold hover:text-coral', dark ? 'text-white' : 'text-ink')}>
          {linkLabel} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
        </Link>
      )}
    </div>
  );
}

export function EmptyState({ icon, title, text, action }: { icon?: ReactNode; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center rounded-4xl border border-dashed border-line bg-white/60 px-6 py-14 text-center">
      {icon && <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-cream text-2xl">{icon}</div>}
      <h3 className="text-lg font-bold">{title}</h3>
      {text && <p className="mt-1 max-w-sm text-[15px] text-ink-muted">{text}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <div className={cn('h-6 w-6 animate-spin rounded-full border-2 border-line border-t-coral', className)} />;
}

export function PageLoader() {
  return (
    <div className="flex min-h-[50vh] items-center justify-center">
      <Spinner className="h-8 w-8" />
    </div>
  );
}

export function Alert({ tone = 'info', children }: { tone?: 'info' | 'error' | 'success'; children: ReactNode }) {
  const t = {
    info: 'bg-cream text-ink-soft',
    error: 'bg-coral-50 text-coral-700',
    success: 'bg-emerald-50 text-emerald-800',
  }[tone];
  return <div className={cn('rounded-2xl px-4 py-3 text-sm', t)}>{children}</div>;
}
