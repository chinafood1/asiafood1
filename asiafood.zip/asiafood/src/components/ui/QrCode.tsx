import { useEffect, useState } from 'react';

type QrFactory = typeof import('qrcode-generator');
let lib: Promise<QrFactory> | null = null;
const loadLib = () => (lib ??= import('qrcode-generator').then((m) => (m as unknown as { default: QrFactory }).default ?? (m as unknown as QrFactory)));

/** QR code in SVG (nessuna immagine esterna, funziona offline nella PWA). La libreria si carica solo quando serve. */
export function QrCode({ value, size = 168, className }: { value: string; size?: number; className?: string }) {
  const [svg, setSvg] = useState<{ path: string; count: number } | null>(null);
  useEffect(() => {
    let alive = true;
    void loadLib().then((qrcode) => {
      const qr = qrcode(0, 'M');
      qr.addData(value);
      qr.make();
      const n = qr.getModuleCount();
      let d = '';
      for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) d += `M${c + 2},${r + 2}h1v1h-1z`;
      if (alive) setSvg({ path: d, count: n + 4 });
    });
    return () => {
      alive = false;
    };
  }, [value]);
  const count = svg?.count ?? 29;
  return (
    <svg viewBox={`0 0 ${count} ${count}`} width={size} height={size} className={className} role="img" aria-label={`Codice QR: ${value}`} shapeRendering="crispEdges">
      <rect width={count} height={count} fill="#fff" />
      {svg && <path d={svg.path} fill="#16161A" />}
    </svg>
  );
}
