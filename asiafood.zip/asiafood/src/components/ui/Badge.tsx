import type { ReactNode } from 'react';
import { BadgeCheck, Crown, FlaskConical, Megaphone, Sparkles } from 'lucide-react';
import { cn } from '@/lib/format';
import { CLAIM_STATUS, DATA_STATUS } from '@/lib/labels';
import type { ClaimStatus, DataStatus } from '@/types/domain';

type Tone = 'neutral' | 'coral' | 'dark' | 'green' | 'amber' | 'glass' | 'outline';

const tones: Record<Tone, string> = {
  neutral: 'bg-cream text-ink-soft',
  coral: 'bg-coral-50 text-coral-700',
  dark: 'bg-ink text-white',
  green: 'bg-emerald-50 text-emerald-700',
  amber: 'bg-amber-50 text-amber-800',
  glass: 'bg-white/90 text-ink backdrop-blur shadow-sm',
  outline: 'border border-line bg-white text-ink-soft',
};

export function Badge({ tone = 'neutral', icon, children, className }: { tone?: Tone; icon?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold leading-none', tones[tone], className)}>
      {icon}
      {children}
    </span>
  );
}

/** Solo per profili rivendicati e approvati dall'Admin. */
export const VerifiedBadge = ({ glass, label = 'Verificato' }: { glass?: boolean; label?: string }) => (
  <Badge tone={glass ? 'glass' : 'green'} icon={<BadgeCheck className="h-3.5 w-3.5 text-emerald-600" />}>
    {label}
  </Badge>
);

export const DataStatusBadge = ({ status }: { status: DataStatus }) => (
  <Badge tone={DATA_STATUS[status].tone} className="whitespace-nowrap">{DATA_STATUS[status].label}</Badge>
);

export const ClaimStatusBadge = ({ status }: { status: ClaimStatus }) => (
  <Badge tone={CLAIM_STATUS[status].tone} className="whitespace-nowrap">{CLAIM_STATUS[status].label}</Badge>
);

export const SponsoredBadge = ({ glass }: { glass?: boolean }) => (
  <Badge tone={glass ? 'glass' : 'outline'} icon={<Megaphone className="h-3.5 w-3.5" />}>
    Sponsorizzato
  </Badge>
);

export const FeaturedBadge = () => (
  <Badge tone="coral" icon={<Sparkles className="h-3.5 w-3.5" />}>
    In evidenza
  </Badge>
);

export const DemoBadge = ({ glass }: { glass?: boolean }) => (
  <Badge
    tone={glass ? 'glass' : 'outline'}
    className="!text-[10px] uppercase tracking-wider"
    icon={<FlaskConical className="h-3 w-3" />}
  >
    Demo
  </Badge>
);

export function Chip({
  active,
  children,
  onClick,
  icon,
  className,
}: {
  active?: boolean;
  children: ReactNode;
  onClick?: () => void;
  icon?: ReactNode;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'inline-flex h-10 shrink-0 items-center gap-2 rounded-full border px-4 text-sm font-medium transition active:scale-95',
        active ? 'border-ink bg-ink text-white' : 'border-line bg-white text-ink hover:border-ink/40',
        className,
      )}
    >
      {icon}
      {children}
    </button>
  );
}

/** Badge del piano Premium/Top (funzione a pagamento, sempre dichiarata come tale). */
export const PremiumBadge = ({ glass }: { glass?: boolean }) => (
  <Badge tone={glass ? 'glass' : 'amber'} icon={<Crown className="h-3.5 w-3.5 text-amber-600" />}>
    Premium
  </Badge>
);
