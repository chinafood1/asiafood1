import { useState } from 'react';
import { cn, initials } from '@/lib/format';

const PALETTES = [
  ['#FFE0DC', '#A82C24'],
  ['#F3EFE9', '#16161A'],
  ['#E7F1EC', '#237A55'],
  ['#FFF0D6', '#935A00'],
  ['#E9E8F6', '#4B45A1'],
];

const hash = (s: string) => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);

/**
 * Immagine con fallback elegante: se l'URL manca o fallisce mostra
 * un fondo generativo con emoji/iniziali (mai "immagine rotta").
 */
const TRANSFORM = ((import.meta.env ?? {}) as Record<string, string | undefined>).VITE_SUPABASE_IMAGE_TRANSFORM === 'true';
const WIDTHS = [400, 800, 1200];

/** srcset responsive: Unsplash (parametro w) e Supabase Storage con trasformazioni immagine (piano Pro, flag VITE_SUPABASE_IMAGE_TRANSFORM). */
export function responsiveSrcSet(src: string): string | undefined {
  try {
    const u = new URL(src);
    if (u.hostname === 'images.unsplash.com') {
      return WIDTHS.map((w) => {
        u.searchParams.set('w', String(w));
        u.searchParams.set('auto', 'format');
        return `${u.toString()} ${w}w`;
      }).join(', ');
    }
    if (TRANSFORM && u.pathname.includes('/storage/v1/object/public/')) {
      return WIDTHS.map((w) => `${u.origin}${u.pathname.replace('/object/public/', '/render/image/public/')}?width=${w}&quality=75 ${w}w`).join(', ');
    }
  } catch {
    /* URL relativo o data: nessun srcset */
  }
  return undefined;
}

export function SmartImage({
  src,
  alt,
  className,
  seed,
  emoji,
  sizes,
  eager,
}: {
  src?: string | null;
  alt: string;
  className?: string;
  seed?: string;
  emoji?: string | null;
  sizes?: string;
  eager?: boolean;
}) {
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const pal = PALETTES[hash(seed ?? alt) % PALETTES.length]!;

  if (!src || failed) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={cn('relative flex items-center justify-center overflow-hidden', className)}
        style={{ background: `radial-gradient(120% 90% at 20% 10%, ${pal[0]} 0%, #F7F3EE 70%)` }}
      >
        <span className="select-none text-5xl opacity-80 drop-shadow-sm">{emoji ?? '🥢'}</span>
        <span className="absolute bottom-3 right-4 font-display text-xs font-semibold uppercase tracking-widest" style={{ color: pal[1] }}>
          {initials(alt)}
        </span>
      </div>
    );
  }

  return (
    <div className={cn('relative overflow-hidden bg-cream', className)}>
      {!loaded && <div className="skeleton absolute inset-0 rounded-none" />}
      <img
        src={src}
        alt={alt}
        srcSet={responsiveSrcSet(src)}
        sizes={sizes ?? '(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 400px'}
        loading={eager ? 'eager' : 'lazy'}
        fetchPriority={eager ? 'high' : 'auto'}
        decoding="async"
        onLoad={() => setLoaded(true)}
        onError={() => setFailed(true)}
        className={cn('h-full w-full object-cover transition-[opacity,transform] duration-500', loaded ? 'opacity-100' : 'opacity-0')}
      />
    </div>
  );
}

/** Logo del ristorante o monogramma generato. */
export function Monogram({ name, src, className }: { name: string; src?: string | null; className?: string }) {
  const [failed, setFailed] = useState(false);
  const pal = PALETTES[hash(name) % PALETTES.length]!;
  if (src && !failed) {
    return <img src={src} alt={`Logo ${name}`} onError={() => setFailed(true)} className={cn('rounded-2xl bg-white object-cover', className)} />;
  }
  return (
    <div
      aria-hidden
      className={cn('flex items-center justify-center rounded-2xl font-display font-bold', className)}
      style={{ background: pal[0], color: pal[1] }}
    >
      {initials(name)}
    </div>
  );
}
