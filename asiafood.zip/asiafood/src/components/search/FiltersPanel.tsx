import { useMemo, useState } from 'react';
import { SlidersHorizontal, X } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import type { RestaurantFilters, SortKey } from '@/services';
import { Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Select, Toggle } from '@/components/ui/Field';
import { Sheet } from '@/components/ui/Sheet';
import { cn } from '@/lib/format';
import { RADIUS_OPTIONS } from '@/config/app';

export const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: 'relevance', label: 'Pertinenza' },
  { value: 'distance', label: 'Più vicini' },
  { value: 'popular', label: 'Più popolari' },
  { value: 'price_asc', label: 'Prezzo crescente' },
  { value: 'price_desc', label: 'Prezzo decrescente' },
  { value: 'newest', label: 'Nuove attività' },
];

export const DISTANCES = RADIUS_OPTIONS;

export interface FilterState extends RestaurantFilters {
  radiusKm?: number;
  useLocation?: boolean;
}

export function countActive(f: FilterState) {
  return [
    f.categorySlug,
    f.citySlug,
    f.priceRanges?.length,
    f.ayce,
    f.delivery,
    f.takeaway,
    f.reservation,
    f.openNow,
    f.hasOffers,
    f.radiusKm,
    f.featured,
    f.verified,
    f.orderMode,
  ].filter(Boolean).length;
}

export function FiltersForm({
  value,
  onChange,
  geoAvailable,
  onRequestLocation,
  hideCity,
}: {
  value: FilterState;
  onChange: (f: FilterState) => void;
  geoAvailable: boolean;
  onRequestLocation: () => void;
  /** Nasconde il selettore del comune (es. mappa, dove l'area si sceglie dalla ricerca). */
  hideCity?: boolean;
}) {
  const { categories, cities } = useReferenceData();
  const set = (patch: Partial<FilterState>) => onChange({ ...value, ...patch });
  const togglePrice = (p: number) => {
    const cur = value.priceRanges ?? [];
    set({ priceRanges: cur.includes(p) ? cur.filter((x) => x !== p) : [...cur, p].sort() });
  };

  return (
    <div className="space-y-7">
      <fieldset>
        <legend className="mb-3 text-sm font-bold">Categoria</legend>
        <div className="flex flex-wrap gap-2">
          <Chip active={!value.categorySlug} onClick={() => set({ categorySlug: undefined })}>
            Tutte
          </Chip>
          {categories.map((c) => (
            <Chip key={c.id} active={value.categorySlug === c.slug} onClick={() => set({ categorySlug: value.categorySlug === c.slug ? undefined : c.slug })}>
              <span>{c.emoji}</span> {c.name}
            </Chip>
          ))}
        </div>
      </fieldset>

      {!hideCity && <fieldset>
        <legend className="mb-3 text-sm font-bold">Comune</legend>
        <Select value={value.citySlug ?? ''} onChange={(e) => set({ citySlug: e.target.value || undefined })} aria-label="Comune">
          <option value="">Tutti i comuni</option>
          {cities.map((c) => (
            <option key={c.id} value={c.slug}>
              {c.name}
            </option>
          ))}
        </Select>
      </fieldset>}

      <fieldset>
        <legend className="mb-3 text-sm font-bold">Distanza</legend>
        {!geoAvailable ? (
          <div>
            <Button type="button" variant="outline" size="sm" onClick={onRequestLocation}>
              Usa la mia posizione
            </Button>
            <p className="mt-2 text-xs text-ink-muted">La posizione resta sul tuo dispositivo: la distanza viene calcolata nel browser.</p>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            <Chip active={!value.radiusKm} onClick={() => set({ radiusKm: undefined })}>
              Qualsiasi
            </Chip>
            {DISTANCES.map((d) => (
              <Chip key={d} active={value.radiusKm === d} onClick={() => set({ radiusKm: d, useLocation: true })}>
                {'< '}{d} km
              </Chip>
            ))}
          </div>
        )}
      </fieldset>

      <fieldset>
        <legend className="mb-3 text-sm font-bold">Fascia di prezzo</legend>
        <div className="grid grid-cols-4 gap-2">
          {[1, 2, 3, 4].map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => togglePrice(p)}
              aria-pressed={value.priceRanges?.includes(p)}
              className={cn(
                'h-11 rounded-2xl border text-sm font-bold transition',
                value.priceRanges?.includes(p) ? 'border-ink bg-ink text-white' : 'border-line bg-white hover:border-ink/40',
              )}
            >
              {'€'.repeat(p)}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="divide-y divide-line">
        <legend className="mb-1 text-sm font-bold">Servizi</legend>
        <Toggle label="Aperto ora" description="Solo locali con orari disponibili" checked={!!value.openNow} onChange={(v) => set({ openNow: v || undefined })} />
        <Toggle label="All You Can Eat" checked={!!value.ayce} onChange={(v) => set({ ayce: v || undefined })} />
        <Toggle label="Offerte attive" checked={!!value.hasOffers} onChange={(v) => set({ hasOffers: v || undefined })} />
        <Toggle label="Delivery" checked={!!value.delivery} onChange={(v) => set({ delivery: v || undefined })} />
        <Toggle label="Asporto" checked={!!value.takeaway} onChange={(v) => set({ takeaway: v || undefined })} />
        <Toggle label="Prenotazione" checked={!!value.reservation} onChange={(v) => set({ reservation: v || undefined })} />
        <Toggle label="Profilo verificato" description="Schede gestite dal titolare" checked={!!value.verified} onChange={(v) => set({ verified: v || undefined })} />
      </fieldset>

      <fieldset className="divide-y divide-line">
        <legend className="mb-1 text-sm font-bold">Ordina online su AsiaFood</legend>
        <Toggle label="Ordina ora" description="Accettano ordini in questo momento" checked={value.orderMode === 'now'} onChange={(v) => set({ orderMode: v ? 'now' : undefined })} />
        <Toggle label="Delivery disponibile" checked={value.orderMode === 'delivery'} onChange={(v) => set({ orderMode: v ? 'delivery' : undefined })} />
        <Toggle label="Takeaway disponibile" checked={value.orderMode === 'takeaway'} onChange={(v) => set({ orderMode: v ? 'takeaway' : undefined })} />
      </fieldset>
    </div>
  );
}

/** Pannello filtri: sidebar su desktop, bottom sheet su mobile. */
export function FiltersPanel(props: {
  value: FilterState;
  onChange: (f: FilterState) => void;
  geoAvailable: boolean;
  onRequestLocation: () => void;
  /** "button" = pulsante + bottom sheet (mobile), "sidebar" = pannello fisso (desktop) */
  mode: 'button' | 'sidebar';
}) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<FilterState>(props.value);
  const active = useMemo(() => countActive(props.value), [props.value]);
  const reset = (): FilterState => ({ q: props.value.q, sort: props.value.sort });

  if (props.mode === 'sidebar') {
    return (
      <aside>
        <div className="sticky top-24 rounded-4xl border border-line bg-white p-6">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="text-lg font-bold">Filtri</h2>
            {active > 0 && (
              <button onClick={() => props.onChange(reset())} className="inline-flex items-center gap-1 text-sm font-semibold text-coral-700">
                <X className="h-4 w-4" /> Azzera
              </button>
            )}
          </div>
          <FiltersForm value={props.value} onChange={props.onChange} geoAvailable={props.geoAvailable} onRequestLocation={props.onRequestLocation} />
        </div>
      </aside>
    );
  }

  return (
    <>
      <button
        onClick={() => {
          setDraft(props.value);
          setOpen(true);
        }}
        className="inline-flex h-10 shrink-0 items-center gap-2 rounded-full border border-ink bg-ink px-4 text-sm font-semibold text-white lg:hidden"
      >
        <SlidersHorizontal className="h-4 w-4" /> Filtri
        {active > 0 && <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-coral px-1.5 text-xs">{active}</span>}
      </button>

      <Sheet
        open={open}
        onClose={() => setOpen(false)}
        title="Filtri"
        footer={
          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={() => setDraft(reset())}>
              Azzera
            </Button>
            <Button
              className="flex-[2]"
              onClick={() => {
                props.onChange(draft);
                setOpen(false);
              }}
            >
              Mostra risultati
            </Button>
          </div>
        }
      >
        <FiltersForm value={draft} onChange={setDraft} geoAvailable={props.geoAvailable} onRequestLocation={props.onRequestLocation} />
      </Sheet>

    </>
  );
}
