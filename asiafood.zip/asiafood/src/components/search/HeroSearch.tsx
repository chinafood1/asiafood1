import { useEffect, useRef, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { LocateFixed, MapPin, Search } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { cn } from '@/lib/format';
import { parseSearchQuery } from '@/lib/searchQuery';

export const NEAR_ME = '__near__';

/** Grande barra "Cosa vuoi mangiare?" + "Dove?" dell'hero. */
export function HeroSearch({ className }: { className?: string }) {
  const { categories, cities } = useReferenceData();
  const navigate = useNavigate();
  const [what, setWhat] = useState('');
  const [where, setWhere] = useState('');
  const [focused, setFocused] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => !boxRef.current?.contains(e.target as Node) && setFocused(false);
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  const submit = (e?: FormEvent, override?: string) => {
    e?.preventDefault();
    const q = (override ?? what).trim();
    // "Sushi Taranto" → categoria + comune; il campo "Dove?" ha la precedenza
    const parsed = parseSearchQuery(q, categories, cities);
    const catSlug = parsed.categorySlug;
    const citySlug = where && where !== NEAR_ME ? where : parsed.citySlug;
    const params = new URLSearchParams();
    if (where === NEAR_ME) params.set('near', '1');
    // URL SEO puliti quando possibile: /sushi/taranto, /ristoranti/massafra
    if (!parsed.text && !parsed.ayce && where !== NEAR_ME) {
      if (catSlug && citySlug) return navigate(`/${catSlug}/${citySlug}`);
      if (!catSlug && citySlug) return navigate(`/ristoranti/${citySlug}`);
    }
    if (catSlug) params.set('category', catSlug);
    if (citySlug) params.set('city', citySlug);
    if (parsed.ayce) params.set('ayce', '1');
    if (parsed.text) params.set('q', q);
    navigate(`/restaurants${params.toString() ? `?${params}` : ''}`);
  };

  const suggestions = categories.filter((c) => !what || c.name.toLowerCase().includes(what.toLowerCase())).slice(0, 6);

  return (
    <form onSubmit={submit} className={cn('relative w-full', className)} role="search">
      <div className="flex flex-col gap-2 rounded-[28px] border border-line bg-white p-2 shadow-lift sm:flex-row sm:items-center sm:gap-0 sm:rounded-full">
        <div ref={boxRef} className="relative flex flex-1 items-center gap-3 rounded-full px-4 py-2.5 sm:py-1.5">
          <Search className="h-5 w-5 shrink-0 text-coral" />
          <div className="min-w-0 flex-1">
            <label htmlFor="hero-what" className="block text-[11px] font-bold uppercase tracking-wider text-ink">
              Cosa vuoi mangiare?
            </label>
            <input
              id="hero-what"
              type="search"
              autoComplete="off"
              value={what}
              onChange={(e) => setWhat(e.target.value)}
              onFocus={() => setFocused(true)}
              placeholder="Sushi, ramen, “cinese Massafra”, nome del locale…"
              className="w-full bg-transparent text-[15px] text-ink placeholder:text-ink-faint focus:outline-none"
            />
          </div>
          {focused && suggestions.length > 0 && (
            <div className="absolute left-0 right-0 top-full z-30 mt-3 animate-fade-up rounded-3xl border border-line bg-white p-2 shadow-lift">
              {suggestions.map((c) => (
                <button
                  type="button"
                  key={c.id}
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => {
                    setWhat(c.name);
                    setFocused(false);
                  }}
                  className="flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left text-[15px] hover:bg-cream"
                >
                  <span className="text-xl">{c.emoji}</span>
                  {c.name}
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="hidden h-10 w-px bg-line sm:block" />
        <div className="flex flex-1 items-center gap-3 rounded-full px-4 py-2.5 sm:py-1.5">
          {where === NEAR_ME ? <LocateFixed className="h-5 w-5 shrink-0 text-coral" /> : <MapPin className="h-5 w-5 shrink-0 text-coral" />}
          <div className="min-w-0 flex-1">
            <label htmlFor="hero-where" className="block text-[11px] font-bold uppercase tracking-wider text-ink">
              Dove?
            </label>
            <select
              id="hero-where"
              value={where}
              onChange={(e) => setWhere(e.target.value)}
              className="w-full appearance-none bg-transparent text-[15px] text-ink focus:outline-none"
            >
              <option value="">Tutta la provincia</option>
              <option value={NEAR_ME}>📍 Vicino a me</option>
              {cities.map((c) => (
                <option key={c.id} value={c.slug}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
        <button
          type="submit"
          className="flex h-14 items-center justify-center gap-2 rounded-full bg-coral px-7 font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,90,78,0.9)] transition hover:bg-coral-600 active:scale-[0.98]"
        >
          <Search className="h-5 w-5" /> Trova ristoranti
        </button>
      </div>
    </form>
  );
}
