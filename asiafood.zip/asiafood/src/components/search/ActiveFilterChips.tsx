import { ORDER_MODE_LABEL } from '@/hooks/useOrderable';
import { X } from 'lucide-react';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { cn } from '@/lib/format';
import type { FilterState } from './FiltersPanel';

export interface ExtraChip {
  key: string;
  label: string;
  onRemove: () => void;
}

/** Filtri attivi come chip removibili ("Sushi ×", "AYCE ×", "< 5 km ×") + "Cancella filtri". */
export function ActiveFilterChips({
  value,
  onChange,
  onClear,
  extra = [],
  className,
  glass,
}: {
  value: FilterState;
  onChange: (f: FilterState) => void;
  onClear: () => void;
  extra?: ExtraChip[];
  className?: string;
  glass?: boolean;
}) {
  const { categoryBySlug, cityBySlug } = useReferenceData();
  const cat = categoryBySlug(value.categorySlug);
  const city = cityBySlug(value.citySlug);
  const chips: ExtraChip[] = [
    ...extra,
    value.q ? { key: 'q', label: `“${value.q}”`, onRemove: () => onChange({ ...value, q: undefined }) } : null,
    cat ? { key: 'cat', label: `${cat.emoji ?? ''} ${cat.name}`.trim(), onRemove: () => onChange({ ...value, categorySlug: undefined }) } : null,
    city ? { key: 'city', label: city.name, onRemove: () => onChange({ ...value, citySlug: undefined }) } : null,
    value.radiusKm && value.useLocation ? { key: 'km', label: `< ${value.radiusKm} km`, onRemove: () => onChange({ ...value, radiusKm: undefined, useLocation: undefined }) } : null,
    value.ayce ? { key: 'ayce', label: 'AYCE', onRemove: () => onChange({ ...value, ayce: undefined }) } : null,
    ...(value.priceRanges ?? []).map((p) => ({ key: `p${p}`, label: '€'.repeat(p), onRemove: () => onChange({ ...value, priceRanges: value.priceRanges!.filter((x) => x !== p) }) })),
    value.openNow ? { key: 'open', label: 'Aperto ora', onRemove: () => onChange({ ...value, openNow: undefined }) } : null,
    value.delivery ? { key: 'del', label: 'Delivery', onRemove: () => onChange({ ...value, delivery: undefined }) } : null,
    value.takeaway ? { key: 'take', label: 'Asporto', onRemove: () => onChange({ ...value, takeaway: undefined }) } : null,
    value.reservation ? { key: 'res', label: 'Prenotazione', onRemove: () => onChange({ ...value, reservation: undefined }) } : null,
    value.hasOffers ? { key: 'off', label: 'Offerte', onRemove: () => onChange({ ...value, hasOffers: undefined }) } : null,
    value.verified ? { key: 'ver', label: 'Verificati', onRemove: () => onChange({ ...value, verified: undefined }) } : null,
    value.orderMode ? { key: 'order', label: ORDER_MODE_LABEL[value.orderMode], onRemove: () => onChange({ ...value, orderMode: undefined }) } : null,
    value.featured ? { key: 'feat', label: 'In evidenza', onRemove: () => onChange({ ...value, featured: undefined }) } : null,
  ].filter((x): x is ExtraChip => !!x);

  if (!chips.length) return null;
  return (
    <div className={cn('scrollbar-none flex items-center gap-1.5 overflow-x-auto', className)} aria-label="Filtri attivi">
      {chips.map((c) => (
        <button
          key={c.key}
          type="button"
          onClick={c.onRemove}
          aria-label={`Rimuovi filtro ${c.label}`}
          className={cn(
            'inline-flex h-8 shrink-0 items-center gap-1 rounded-full pl-3 pr-2 text-[13px] font-semibold transition',
            glass ? 'bg-white/95 shadow-card backdrop-blur hover:bg-white' : 'bg-ink text-white hover:bg-ink-soft',
          )}
        >
          {c.label} <X className="h-3.5 w-3.5 opacity-70" />
        </button>
      ))}
      <button type="button" onClick={onClear} className={cn('h-8 shrink-0 rounded-full px-3 text-[13px] font-semibold text-coral-700 underline-offset-2 hover:underline', glass && 'bg-white/95 shadow-card')}>
        Cancella filtri
      </button>
    </div>
  );
}
