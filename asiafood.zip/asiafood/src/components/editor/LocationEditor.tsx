// Localizzazione nell'editor: mappa con marker trascinabile, geocoding su richiesta,
// e flusso di approvazione per i cambi importanti proposti dai ristoratori.
import { useState } from 'react';
import { Crosshair, ExternalLink, MapPinned, Search, Send } from 'lucide-react';
import { MAPS } from '@/config/app';
import { useAuth } from '@/context/AuthContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { formatDate, formatDistance } from '@/lib/format';
import { haversineKm } from '@/lib/geo';
import { geocodeAddress, type GeocodeResult } from '@/lib/maps/geocode';
import { InteractiveMap } from '@/lib/maps/InteractiveMap';
import { LAUNCH_BOUNDS, type LatLng } from '@/lib/maps/types';
import { api } from '@/services';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { num, Panel, str, useRestaurantForm, type EditorTabProps } from './form';

/** Spostamento massimo che il titolare può salvare senza approvazione (deve coincidere col trigger DB). */
export const OWNER_MAX_MOVE_KM = 0.3;
const round6 = (x: number) => Math.round(x * 1e6) / 1e6;

export function LocationSection({ r, reload }: EditorTabProps) {
  const { cities } = useReferenceData();
  const { isAdmin, user } = useAuth();
  const toast = useToast();
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['address', 'city_id', 'postal_code', 'latitude', 'longitude']);
  const [placing, setPlacing] = useState(false);
  const [geo, setGeo] = useState<{ busy: boolean; result?: GeocodeResult | null; error?: string }>({ busy: false });
  const [note, setNote] = useState('');
  const [sending, setSending] = useState(false);
  const requests = useAsync(() => (isAdmin ? Promise.resolve([]) : api.listChangeRequests({ restaurantId: r.id })), [r.id, isAdmin]);

  const city = cities.find((c) => c.id === form.city_id);
  const pos: LatLng | null = form.latitude != null && form.longitude != null ? { lat: form.latitude, lng: form.longitude } : null;
  const orig: LatLng | null = r.latitude != null && r.longitude != null ? { lat: r.latitude, lng: r.longitude } : null;
  const setPos = (p: LatLng) => {
    set('latitude', round6(p.lat));
    set('longitude', round6(p.lng));
    setPlacing(false);
  };
  const coordsFromCity = pos != null && city?.latitude === pos.lat && city?.longitude === pos.lng;

  // Regole per il titolare (identiche al trigger protect_restaurant_admin_fields)
  const moveKm = orig && pos ? haversineKm(orig, pos) : null;
  const addressChanged = (form.address ?? null) !== (r.address ?? null) || (form.postal_code ?? null) !== (r.postal_code ?? null);
  const coordsChanged = JSON.stringify(pos) !== JSON.stringify(orig);
  const smallMove = !!orig && !!pos && moveKm! <= OWNER_MAX_MOVE_KM;
  const needsApproval = !isAdmin && (addressChanged || (coordsChanged && !smallMove));
  const pending = (requests.data ?? []).filter((c) => c.status === 'pending');

  const findCoords = async () => {
    const q = [form.address, form.postal_code, city?.name].filter(Boolean).join(', ');
    setGeo({ busy: true });
    try {
      const result = await geocodeAddress(q);
      setGeo({ busy: false, result });
      // Senza coordinate esistenti si applica subito; altrimenti serve una conferma esplicita
      if (result && !pos) setPos(result);
    } catch (e) {
      setGeo({ busy: false, error: (e as Error).message });
    }
  };

  const saveOwnerSmallMove = async () => {
    try {
      await api.updateRestaurant(r.id, { latitude: form.latitude, longitude: form.longitude });
      toast('Posizione aggiornata');
      reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
  const sendRequest = async () => {
    if (!user) return;
    setSending(true);
    try {
      await api.createChangeRequest({
        restaurant_id: r.id,
        user_id: user.id,
        payload: {
          ...(addressChanged ? { address: form.address ?? null, postal_code: form.postal_code ?? null } : {}),
          ...(coordsChanged && pos ? { latitude: pos.lat, longitude: pos.lng } : {}),
        },
        note: note.trim() || null,
      });
      toast('Proposta inviata: lo staff la verificherà a breve');
      setNote('');
      requests.reload();
      reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setSending(false);
    }
  };

  const footer = isAdmin ? (
    <Button loading={saving} disabled={!dirty} onClick={() => save(undefined, reload)}>
      Salva
    </Button>
  ) : needsApproval ? (
    <Button loading={sending} icon={<Send className="h-4 w-4" />} onClick={sendRequest}>
      Proponi correzione
    </Button>
  ) : (
    <Button disabled={!coordsChanged} onClick={saveOwnerSmallMove}>
      Salva posizione
    </Button>
  );

  return (
    <Panel
      title="Localizzazione"
      description={isAdmin ? undefined : 'Puoi spostare il segnaposto di poche decine di metri. Per cambiare indirizzo o spostamenti maggiori invia una proposta: la verifica lo staff.'}
      footer={footer}
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Indirizzo" className="sm:col-span-2">
          <Input value={form.address ?? ''} onChange={(e) => set('address', str(e.target.value))} placeholder="Via, numero civico" />
        </Field>
        <Field label="Comune" hint={isAdmin ? undefined : 'Per cambiare comune contatta lo staff.'}>
          <Select value={form.city_id} disabled={!isAdmin} onChange={(e) => set('city_id', e.target.value)}>
            {cities.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="CAP">
          <Input inputMode="numeric" maxLength={5} value={form.postal_code ?? ''} onChange={(e) => set('postal_code', str(e.target.value))} />
        </Field>

        {/* Mappa con segnaposto trascinabile */}
        <div className="sm:col-span-2">
          <div className="relative overflow-hidden rounded-3xl border border-line">
            <InteractiveMap
              points={[]}
              editable={{ position: pos, placing, onChange: setPos }}
              initialView={
                pos
                  ? { center: pos, zoom: 16 }
                  : city?.latitude != null && city.longitude != null
                    ? { center: { lat: city.latitude, lng: city.longitude }, zoom: 13 }
                    : { bounds: LAUNCH_BOUNDS }
              }
              clustering={false}
              className="h-72 w-full"
              ariaLabel="Mappa per posizionare il locale: trascina il segnaposto"
            />
            {placing && (
              <p className="pointer-events-none absolute inset-x-0 top-3 mx-auto w-fit rounded-full bg-ink px-4 py-1.5 text-xs font-semibold text-white shadow-lift">
                Tocca la mappa nel punto esatto dell'ingresso
              </p>
            )}
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button type="button" size="sm" variant={placing ? 'dark' : 'outline'} icon={<Crosshair className="h-4 w-4" />} onClick={() => setPlacing((v) => !v)}>
              {placing ? 'Annulla' : 'Posiziona sulla mappa'}
            </Button>
            <Button
              type="button"
              size="sm"
              variant="outline"
              icon={<Search className="h-4 w-4" />}
              loading={geo.busy}
              disabled={!MAPS.geocoding || !form.address}
              onClick={findCoords}
              title={MAPS.geocoding ? undefined : 'Configura VITE_MAPBOX_ACCESS_TOKEN per attivare il geocoding'}
            >
              Trova coordinate
            </Button>
            {form.address && (
              <a
                className="inline-flex h-9 items-center gap-1.5 rounded-full border border-line px-4 text-sm font-semibold hover:border-ink"
                target="_blank"
                rel="noreferrer"
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${form.address} ${city?.name ?? ''}`)}`}
              >
                Verifica su Google Maps <ExternalLink className="h-3.5 w-3.5" />
              </a>
            )}
          </div>
          {!MAPS.geocoding && <p className="mt-2 text-xs text-ink-muted">“Trova coordinate” richiede un provider di geocoding (VITE_MAPBOX_ACCESS_TOKEN). Puoi sempre posizionare il locale a mano.</p>}
          {geo.error && <p className="mt-2 text-sm text-coral-700">{geo.error}</p>}
          {geo.result === null && <p className="mt-2 text-sm text-ink-muted">Nessun risultato per questo indirizzo: posiziona il locale a mano.</p>}
          {geo.result && pos && (geo.result.lat !== pos.lat || geo.result.lng !== pos.lng) && (
            <div className="mt-3 rounded-2xl border border-amber-200 bg-amber-50 p-3 text-sm">
              <p>
                Trovato: <strong>{geo.result.label}</strong>
                {geo.result.accuracy && <span className="text-ink-muted"> · precisione {geo.result.accuracy}</span>}
                <span className="text-ink-muted"> · {formatDistance(haversineKm(pos, geo.result))} dalla posizione attuale</span>
              </p>
              <p className="mt-1 text-xs text-ink-muted">Le coordinate attuali verranno sostituite. Controlla sulla mappa prima di salvare.</p>
              <div className="mt-2 flex gap-2">
                <Button size="sm" variant="dark" onClick={() => setPos(geo.result!)}>
                  Sostituisci coordinate
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setGeo({ busy: false })}>
                  Mantieni attuali
                </Button>
              </div>
            </div>
          )}
        </div>

        <Field label="Latitudine">
          <Input inputMode="decimal" value={form.latitude ?? ''} onChange={(e) => set('latitude', num(e.target.value))} />
        </Field>
        <Field label="Longitudine">
          <Input inputMode="decimal" value={form.longitude ?? ''} onChange={(e) => set('longitude', num(e.target.value))} />
        </Field>

        {coordsFromCity && (
          <div className="sm:col-span-2">
            <Alert>Le coordinate coincidono con il centro del comune: distanza e mappa saranno approssimative.</Alert>
          </div>
        )}
        {!pos && <p className="text-xs text-ink-muted sm:col-span-2">Senza coordinate il locale resta nell'elenco ma non compare sulla mappa né nei risultati “vicino a te”.</p>}

        {!isAdmin && coordsChanged && moveKm !== null && (
          <p className="text-sm sm:col-span-2">
            Spostamento: <strong>{formatDistance(moveKm)}</strong>{' '}
            {smallMove ? <span className="text-emerald-700">· puoi salvarlo direttamente</span> : <span className="text-amber-800">· oltre {OWNER_MAX_MOVE_KM * 1000} m serve l'approvazione dello staff</span>}
          </p>
        )}
        {needsApproval && (
          <Field label="Nota per lo staff (facoltativa)" className="sm:col-span-2" hint="Es. «ci siamo trasferiti», «il segnaposto era sull'isolato sbagliato».">
            <Textarea rows={2} value={note} maxLength={500} onChange={(e) => setNote(e.target.value)} />
          </Field>
        )}

        {!isAdmin && (requests.data ?? []).length > 0 && (
          <div className="space-y-2 sm:col-span-2">
            <p className="flex items-center gap-1.5 text-sm font-bold">
              <MapPinned className="h-4 w-4" /> Proposte inviate
            </p>
            {(requests.data ?? []).slice(0, 5).map((c) => (
              <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-cream px-3 py-2 text-sm">
                <span className="min-w-0 truncate">
                  {c.payload.address ?? (c.payload.latitude != null ? 'Nuova posizione sulla mappa' : 'Correzione')} · {formatDate(c.created_at)}
                </span>
                <Badge tone={c.status === 'pending' ? 'amber' : c.status === 'approved' ? 'green' : 'neutral'}>
                  {c.status === 'pending' ? 'In verifica' : c.status === 'approved' ? 'Approvata' : 'Non approvata'}
                </Badge>
                {c.admin_notes && <p className="w-full text-xs text-ink-muted">Staff: {c.admin_notes}</p>}
              </div>
            ))}
            {pending.length > 0 && <p className="text-xs text-ink-muted">Finché la proposta è in verifica la scheda pubblica mostra i dati attuali.</p>}
          </div>
        )}
      </div>
    </Panel>
  );
}
