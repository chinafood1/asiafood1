import { useEffect, useState, type ReactNode } from 'react';
import { cn } from '@/lib/format';
import { api } from '@/services';
import type { Restaurant, RestaurantDetail } from '@/types/domain';
import { useToast } from '@/components/ui/Toast';

export interface EditorTabProps {
  r: RestaurantDetail;
  reload: () => void;
}

export function Panel({ title, description, children, footer, className }: { title?: string; description?: ReactNode; children: ReactNode; footer?: ReactNode; className?: string }) {
  return (
    <section className={cn('card p-5 sm:p-7', className)}>
      {title && <h2 className="text-lg font-bold">{title}</h2>}
      {description && <div className="mt-1 text-sm text-ink-muted">{description}</div>}
      <div className={cn(title && 'mt-5')}>{children}</div>
      {footer && <div className="mt-6 flex flex-wrap justify-end gap-3 border-t border-line pt-5">{footer}</div>}
    </section>
  );
}

/** Stato locale di un sottoinsieme di campi del ristorante + salvataggio. */
export function useRestaurantForm<K extends keyof Restaurant>(r: Restaurant, keys: K[]) {
  const pick = () => Object.fromEntries(keys.map((k) => [k, r[k]])) as Pick<Restaurant, K>;
  const [form, setForm] = useState(pick);
  const [saving, setSaving] = useState(false);
  const toast = useToast();
  useEffect(() => setForm(pick()), [r]); // eslint-disable-line react-hooks/exhaustive-deps
  const set = <F extends K>(k: F, v: Restaurant[F]) => setForm((f) => ({ ...f, [k]: v }));
  const dirty = keys.some((k) => JSON.stringify(form[k]) !== JSON.stringify(r[k]));
  const save = async (extra?: () => Promise<void>, reload?: () => void, message = 'Modifiche salvate') => {
    setSaving(true);
    try {
      await api.updateRestaurant(r.id, form as Partial<Restaurant>);
      await extra?.();
      toast(message);
      reload?.();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setSaving(false);
    }
  };
  return { form, set, save, saving, dirty };
}

export const num = (v: string) => (v === '' ? null : Number(v.replace(',', '.')));
export const str = (v: string) => (v.trim() === '' ? null : v);
