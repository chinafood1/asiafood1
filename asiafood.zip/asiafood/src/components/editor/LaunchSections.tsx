// ─────────────────────────────────────────────────────────────
//  Fase 12 · Dashboard ristoratore:
//   /dashboard/restaurants/:id/qr-kit      QR profilo, menu, recensioni, prenotazione, offerte (PNG, SVG, PDF stampabile)
//   /dashboard/restaurants/:id/launch-kit  checklist di lancio, starter kit, prima offerta, lancio social, feedback
//  I QR contengono solo URL pubblici (mai dati personali) e registrano la scansione per tipo.
// ─────────────────────────────────────────────────────────────
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Circle, Copy, Download, FileImage, FileCode2, MessageSquarePlus } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Chip } from '@/components/ui/Badge';
import { Textarea } from '@/components/ui/Field';
import { Alert, PageLoader } from '@/components/ui/Layout';
import { QrCode } from '@/components/ui/QrCode';
import { useToast } from '@/components/ui/Toast';
import { PRINT_KINDS, PrintSheet, type PrintKind } from '@/components/launch/PrintMaterials';
import { APP } from '@/config/app';
import { useAsync } from '@/hooks/useAsync';
import { friendlyError } from '@/lib/errors';
import { cn } from '@/lib/format';
import { downloadBlob, qrPng, qrSvg } from '@/lib/qrExport';
import { api } from '@/services';
import type { QrKind } from '@/types/launch';
import { Panel, type EditorTabProps } from './form';

const QR_DEFS: { kind: QrKind; title: string; cta: string; path: (slug: string) => string }[] = [
  { kind: 'profile', title: 'Profilo', cta: `Scopri il nostro locale su ${APP.name}`, path: (s) => `/r/${s}` },
  { kind: 'menu', title: 'Menu', cta: `Scopri il nostro menu su ${APP.name}`, path: (s) => `/r/${s}/menu` },
  { kind: 'review', title: 'Recensioni', cta: 'Racconta la tua esperienza', path: (s) => `/r/${s}/review` },
  { kind: 'booking', title: 'Prenotazione', cta: 'Prenota il tuo tavolo', path: (s) => `/r/${s}/booking` },
  { kind: 'offer', title: 'Offerte', cta: 'Scopri le nostre offerte', path: (s) => `/r/${s}/offer` },
];
const base = () => APP.siteUrl || window.location.origin;

export function QrKitSection({ r }: EditorTabProps) {
  const toast = useToast();
  const kit = useAsync(() => api.launch.launchKit(r.id).catch(() => null), [r.id]);
  const [pick, setPick] = useState<QrKind>('menu');
  const [tpl, setTpl] = useState<PrintKind>('table_a6');
  const def = QR_DEFS.find((d) => d.kind === pick)!;
  const url = `${base()}${def.path(r.slug)}`;
  const mark = () => {
    void api.launch.markLaunchKit(r.id, 'qr_kit_downloaded').catch(() => undefined);
    api.trackAppEvent('qr_kit_download', { restaurantId: r.id, source: pick });
  };
  const dl = async (d: (typeof QR_DEFS)[number], fmt: 'png' | 'svg') => {
    try {
      const u = `${base()}${d.path(r.slug)}`;
      const blob = fmt === 'png' ? await qrPng(u) : new Blob([await qrSvg(u)], { type: 'image/svg+xml' });
      downloadBlob(blob, `${r.slug}-qr-${d.kind}.${fmt}`);
      mark();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  const copy = (u: string) => void navigator.clipboard.writeText(u).then(() => toast('Link copiato'), () => toast('Copia non riuscita', 'error'));
  const founding = kit.data?.founding;
  return (
    <div className="space-y-6" data-testid="qr-kit">
      <Alert>
        Il QR “Racconta la tua esperienza” invita a lasciare un’opinione sincera. Non offrire sconti o premi in cambio di recensioni positive: è vietato e le recensioni verrebbero rimosse.
      </Alert>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {QR_DEFS.map((d) => {
          const u = `${base()}${d.path(r.slug)}`;
          return (
            <div key={d.kind} className="card flex flex-col items-center p-4 text-center" data-testid={`qr-${d.kind}`}>
              <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">{d.title}</p>
              <QrCode value={u} size={140} className="mt-2" />
              <p className="mt-2 font-display text-base font-extrabold leading-tight">{d.cta}</p>
              <p className="mt-1 break-all text-[11px] text-ink-muted">{u.replace(/^https?:\/\//, '')}</p>
              <div className="mt-2 flex flex-wrap justify-center gap-1">
                <Button size="sm" variant="ghost" onClick={() => void dl(d, 'png')} aria-label={`Scarica PNG ${d.title}`}><FileImage className="h-4 w-4" /> PNG</Button>
                <Button size="sm" variant="ghost" onClick={() => void dl(d, 'svg')} aria-label={`Scarica SVG ${d.title}`}><FileCode2 className="h-4 w-4" /> SVG</Button>
                <Button size="sm" variant="ghost" onClick={() => copy(u)} aria-label={`Copia link ${d.title}`}><Copy className="h-4 w-4" /></Button>
              </div>
            </div>
          );
        })}
      </div>
      <Panel title="Materiali stampabili" description="Scegli il QR e il formato, poi “Stampa / Salva PDF”. Ogni scansione viene contata nelle statistiche (solo il tipo di QR, nessun dato del cliente).">
        <div className="flex flex-wrap gap-2">{QR_DEFS.map((d) => <Chip key={d.kind} active={pick === d.kind} onClick={() => setPick(d.kind)}>{d.title}</Chip>)}</div>
        <div className="mt-2 flex flex-wrap gap-2">{(['table_a6', 'counter_a5', 'sticker', 'small_sticker'] as PrintKind[]).map((k) => <Chip key={k} active={tpl === k} onClick={() => setTpl(k)}>{PRINT_KINDS[k].label}</Chip>)}</div>
        <div className="mt-4" onClickCapture={(e) => { if ((e.target as HTMLElement).closest('button')) mark(); }}>
          <PrintSheet kind={tpl} content={{ qrUrl: url, title: r.name, subtitle: tpl === 'counter_a5' ? `Menu, orari e offerte su ${APP.name}` : null, cta: def.cta, badge: founding ? founding.label : null }} testId="qr-print" />
        </div>
      </Panel>
    </div>
  );
}

const STEP_LABELS: Record<string, { label: string; to: string | null; hint: string }> = {
  profile: { label: 'Profilo completo', to: 'profilo', hint: 'Descrizione, contatti, servizi, prezzi' },
  menu: { label: 'Menu', to: 'menu', hint: 'Anche solo i piatti principali, con prezzi' },
  hours: { label: 'Orari', to: 'orari', hint: 'Orari di apertura e chiusure straordinarie' },
  photos: { label: 'Foto', to: 'foto', hint: 'Logo, copertina e qualche piatto' },
  qr: { label: 'QR sui tavoli', to: 'qr-kit', hint: 'Scarica o stampa il kit QR' },
  first_offer: { label: 'Prima offerta', to: 'offerte', hint: 'Condizioni decise da voi' },
  reservations: { label: 'Prenotazioni', to: 'reservations', hint: 'Facoltative: attivale se ti servono' },
  notifications: { label: 'Notifiche', to: null, hint: 'Attiva le notifiche per prenotazioni e ordini' },
  social_launch: { label: 'Annuncio sui vostri social', to: null, hint: 'Un post per dire che siete su AsiaFood' },
};
const OFFER_IDEAS = ['10% sull’asporto', 'Drink incluso', 'Dessert omaggio', 'Promo pranzo', 'Promo AYCE'];

export function LaunchKitSection({ r }: EditorTabProps) {
  const toast = useToast();
  const kit = useAsync(() => api.launch.launchKit(r.id), [r.id]);
  useEffect(() => {
    void api.launch.markLaunchKit(r.id, 'starter_kit_viewed').catch(() => undefined);
  }, [r.id]);
  if (kit.loading && !kit.data) return <PageLoader />;
  if (kit.error || !kit.data) return <Alert tone="error">{friendlyError(kit.error)}</Alert>;
  const k = kit.data;
  const done = k.steps.filter((s) => s.done).length;
  const profileUrl = `${base()}/ristorante/${r.slug}?utm_source=restaurant_social&utm_medium=social&utm_campaign=partner_launch`;
  const post = `Ci trovate anche su ${APP.name}, la piattaforma dedicata alla cucina asiatica di Taranto e provincia: menu, orari e offerte in un tocco 👉 ${profileUrl}`;
  const toggleSocial = async () => {
    try {
      await api.launch.markLaunchKit(r.id, k.progress?.social_launch_at ? 'social_launch_undo' : 'social_launch');
      kit.reload();
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <div className="space-y-6" data-testid="launch-kit">
      <Panel title={`Kit di lancio · ${done}/${k.steps.length} completati`} description="I passi che rendono la scheda utile ai clienti fin dal primo giorno.">
        {k.founding && (
          <p className="mb-4 rounded-2xl bg-ink px-4 py-3 text-sm text-white" data-testid="founding-status">
            <strong>{k.founding.label} n. {k.founding.number}</strong>{k.founding.status === 'active' && k.founding.benefit_ends_at ? ` · piano ${k.founding.plan} gratuito fino al ${new Date(k.founding.benefit_ends_at).toLocaleDateString('it-IT')}, poi scade senza addebiti` : ''}
          </p>
        )}
        <div className="h-2 overflow-hidden rounded-full bg-cream" role="progressbar" aria-valuenow={done} aria-valuemin={0} aria-valuemax={k.steps.length} aria-label="Avanzamento kit di lancio">
          <div className="h-full rounded-full bg-ink" style={{ width: `${(done / k.steps.length) * 100}%` }} />
        </div>
        <ul className="mt-4 grid gap-2 sm:grid-cols-2">
          {k.steps.map((s) => {
            const l = STEP_LABELS[s.key]!;
            const inner = (
              <span className="flex items-start gap-3">
                {s.done ? <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-700" aria-label="Fatto" /> : <Circle className="mt-0.5 h-5 w-5 shrink-0 text-ink-muted" aria-label="Da fare" />}
                <span><span className={cn('font-semibold', s.done && 'text-ink-muted')}>{l.label}</span><span className="block text-xs text-ink-muted">{l.hint}</span></span>
              </span>
            );
            return (
              <li key={s.key} className="rounded-2xl border border-line p-3" data-testid={`kit-step-${s.key}`}>
                {l.to ? <Link to={`../${l.to}`} relative="path" className="block">{inner}</Link>
                  : s.key === 'notifications' ? <Link to="/settings/notifications" className="block">{inner}</Link>
                    : <button type="button" className="block w-full text-left" onClick={() => void toggleSocial()}>{inner}</button>}
              </li>
            );
          })}
        </ul>
      </Panel>

      <Panel title="La tua prima offerta" description="Un’offerta chiara aiuta i nuovi clienti a provarvi. Siete voi a decidere condizioni, giorni e durata.">
        <div className="flex flex-wrap gap-2">{OFFER_IDEAS.map((x) => <span key={x} className="rounded-full bg-cream px-3 py-1.5 text-sm">{x}</span>)}</div>
        <Link to="../offerte" relative="path" className="mt-3 inline-flex font-semibold text-coral-700">Crea l’offerta</Link>
      </Panel>

      <Panel title="Starter kit" description="Materiali e istruzioni per iniziare.">
        <ul className="space-y-3 text-sm">
          <li><strong>Link della vostra scheda:</strong> <a href={`/ristorante/${r.slug}`} className="break-all font-semibold text-coral-700">{base()}/ristorante/{r.slug}</a></li>
          <li><strong>Logo {APP.name}</strong> per i vostri materiali: <a href="/icons/icon-512.png" download className="inline-flex items-center gap-1 font-semibold text-coral-700"><Download className="h-4 w-4" /> PNG</a></li>
          {k.founding && k.founding.status !== 'revoked' && <li><strong>Badge</strong>: “{k.founding.label}” compare sulla vostra scheda e sui materiali QR.</li>}
          <li><strong>Come aggiornare il menu:</strong> sezione Menu → aggiungi categorie e piatti, prezzi e allergeni; i piatti esauriti si nascondono con un tocco.</li>
          <li><strong>Come creare offerte e coupon:</strong> sezioni Offerte e Coupon; le condizioni sono sempre mostrate al cliente.</li>
          <li><strong>Come vedere le statistiche:</strong> sezione Statistiche: visite, chiamate, indicazioni, prenotazioni e scansioni QR.</li>
        </ul>
      </Panel>

      <Panel title="Annuncio sui vostri social" description="Testo pronto da copiare (con link tracciato). Pubblicatelo voi quando volete.">
        <pre className="whitespace-pre-wrap [overflow-wrap:anywhere] rounded-2xl bg-cream/60 p-3 font-sans text-sm">{post}</pre>
        <div className="mt-2 flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={() => void navigator.clipboard.writeText(post).then(() => toast('Testo copiato'), () => toast('Copia non riuscita', 'error'))}><Copy className="h-4 w-4" /> Copia</Button>
          <Button size="sm" variant={k.progress?.social_launch_at ? 'soft' : 'dark'} onClick={() => void toggleSocial()} data-testid="social-done">{k.progress?.social_launch_at ? 'Segnato come pubblicato' : 'Segna come pubblicato'}</Button>
        </div>
      </Panel>

      <RestaurantFeedback restaurantId={r.id} />
    </div>
  );
}

/** "Cosa manca alla dashboard?" — facoltativo, mai bloccante. */
export function RestaurantFeedback({ restaurantId }: { restaurantId: string }) {
  const toast = useToast();
  const [msg, setMsg] = useState('');
  const [sent, setSent] = useState(false);
  const send = async () => {
    try {
      await api.launch.submitFeedback({ type: 'restaurant_dashboard', restaurant_id: restaurantId, message: msg, page: 'dashboard' });
      setSent(true);
      setMsg('');
    } catch (e) {
      toast(friendlyError(e), 'error');
    }
  };
  return (
    <Panel title="Cosa manca alla dashboard?" description="Il vostro feedback decide le prossime funzioni.">
      {sent ? <p className="text-sm font-semibold text-emerald-700" data-testid="restaurant-feedback-sent">Grazie! L’abbiamo ricevuto.</p> : (
        <>
          <Textarea rows={3} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Es. vorrei esportare le prenotazioni…" aria-label="Cosa manca alla dashboard?" data-testid="restaurant-feedback" />
          <Button size="sm" className="mt-2" disabled={msg.trim().length < 3} onClick={() => void send()}><MessageSquarePlus className="h-4 w-4" /> Invia</Button>
        </>
      )}
    </Panel>
  );
}
