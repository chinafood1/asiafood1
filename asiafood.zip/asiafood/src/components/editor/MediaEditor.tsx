import { useRef, useState } from 'react';
import { ArrowDown, ArrowUp, ImagePlus, Trash2, Upload } from 'lucide-react';
import { api, isDemoMode } from '@/services';
import type { RestaurantImage } from '@/types/domain';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Layout';
import { Monogram, SmartImage } from '@/components/ui/SmartImage';
import { useToast } from '@/components/ui/Toast';
import { Panel, type EditorTabProps } from './form';

const MAX_MB = 5;
const ACCEPT = 'image/jpeg,image/png,image/webp,image/avif';

function validate(file: File): string | null {
  if (!ACCEPT.split(',').includes(file.type)) return 'Formato non supportato (usa JPG, PNG, WebP o AVIF).';
  if (file.size > MAX_MB * 1024 * 1024) return `L’immagine supera ${MAX_MB} MB.`;
  return null;
}

/** Logo, cover e galleria (Supabase Storage: <restaurant_id>/<cartella>/file). */
export function MediaEditor({ r, reload }: EditorTabProps) {
  const toast = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const logoRef = useRef<HTMLInputElement>(null);
  const coverRef = useRef<HTMLInputElement>(null);
  const galleryRef = useRef<HTMLInputElement>(null);

  const upload = async (files: FileList | null, folder: 'logo' | 'cover' | 'gallery') => {
    if (!files?.length) return;
    setBusy(folder);
    try {
      for (const file of Array.from(files)) {
        const err = validate(file);
        if (err) throw new Error(err);
        const { url, path } = await api.uploadImage(r.id, file, folder);
        if (folder === 'logo') await api.updateRestaurant(r.id, { logo_url: url });
        else if (folder === 'cover') await api.updateRestaurant(r.id, { cover_url: url });
        else await api.upsert('restaurant_images', { restaurant_id: r.id, url, storage_path: path, alt: r.name, kind: 'gallery', sort_order: r.images.length });
      }
      toast('Immagine caricata');
      reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };

  const removeImage = async (img: RestaurantImage) => {
    if (!confirm('Eliminare questa foto?')) return;
    await api.remove('restaurant_images', img.id);
    reload();
  };

  const move = async (i: number, dir: -1 | 1) => {
    const a = r.images[i];
    const b = r.images[i + dir];
    if (!a || !b) return;
    await Promise.all([api.upsert('restaurant_images', { ...a, sort_order: b.sort_order }), api.upsert('restaurant_images', { ...b, sort_order: a.sort_order })]);
    reload();
  };

  return (
    <div className="space-y-6">
      {isDemoMode && <Alert>In modalità demo le immagini caricate restano solo in questo browser.</Alert>}
      <div className="grid gap-6 md:grid-cols-[240px_1fr]">
        <Panel title="Logo">
          <Monogram name={r.name} src={r.logo_url} className="mx-auto h-32 w-32 text-4xl" />
          <input ref={logoRef} type="file" accept={ACCEPT} hidden onChange={(e) => upload(e.target.files, 'logo')} />
          <div className="mt-4 flex flex-col gap-2">
            <Button variant="outline" size="sm" loading={busy === 'logo'} icon={<Upload className="h-4 w-4" />} onClick={() => logoRef.current?.click()}>
              Carica logo
            </Button>
            {r.logo_url && (
              <Button variant="ghost" size="sm" onClick={async () => { await api.updateRestaurant(r.id, { logo_url: null }); reload(); }}>
                Rimuovi
              </Button>
            )}
          </div>
        </Panel>
        <Panel title="Immagine di copertina" description="Formato orizzontale, almeno 1600×900 px.">
          <SmartImage src={r.cover_url} alt={r.name} seed={r.id} className="aspect-[16/7] w-full rounded-3xl" />
          <input ref={coverRef} type="file" accept={ACCEPT} hidden onChange={(e) => upload(e.target.files, 'cover')} />
          <Button className="mt-4" variant="outline" size="sm" loading={busy === 'cover'} icon={<Upload className="h-4 w-4" />} onClick={() => coverRef.current?.click()}>
            Sostituisci copertina
          </Button>
        </Panel>
      </div>

      <Panel title="Galleria" description={`Piatti, sala, esterni. JPG/PNG/WebP fino a ${MAX_MB} MB.`}>
        <input ref={galleryRef} type="file" accept={ACCEPT} multiple hidden onChange={(e) => upload(e.target.files, 'gallery')} />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {r.images.map((img, i) => (
            <div key={img.id} className="group relative overflow-hidden rounded-2xl">
              <SmartImage src={img.url} alt={img.alt ?? r.name} className="aspect-square w-full" />
              <div className="absolute inset-x-0 bottom-0 flex justify-end gap-1 bg-gradient-to-t from-black/60 p-2 opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100">
                <button aria-label="Sposta prima" onClick={() => move(i, -1)} disabled={i === 0} className="rounded-full bg-white/90 p-1.5 disabled:opacity-40"><ArrowUp className="h-4 w-4" /></button>
                <button aria-label="Sposta dopo" onClick={() => move(i, 1)} disabled={i === r.images.length - 1} className="rounded-full bg-white/90 p-1.5 disabled:opacity-40"><ArrowDown className="h-4 w-4" /></button>
                <button aria-label="Elimina" onClick={() => removeImage(img)} className="rounded-full bg-white/90 p-1.5 text-coral-700"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          ))}
          <button
            onClick={() => galleryRef.current?.click()}
            disabled={busy === 'gallery'}
            className="flex aspect-square flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-line text-sm font-semibold text-ink-muted transition hover:border-coral hover:text-coral-700"
          >
            <ImagePlus className="h-7 w-7" />
            {busy === 'gallery' ? 'Caricamento…' : 'Aggiungi foto'}
          </button>
        </div>
      </Panel>
    </div>
  );
}
