// Sezioni dell'editor riservate all'Admin: fonti, stato, proprietario,
// abbonamento, sponsorizzazione. Tutte protette anche dalle RLS.
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, Pencil, Plus, Star, Trash2, UserMinus, UserPlus } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { cn, formatDate } from '@/lib/format';
import { DATA_STATUS, MEMBER_ROLE, SOURCE_TYPE } from '@/lib/labels';
import { api } from '@/services';
import type { DataStatus, MemberRole, Profile, RestaurantSource, SourceType } from '@/types/domain';
import { Badge, ClaimStatusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { Panel, str, useRestaurantForm, type EditorTabProps } from './form';

const toDateInput = (iso: string | null | undefined) => (iso ? iso.slice(0, 10) : '');
const fromDateInput = (v: string) => (v ? new Date(`${v}T12:00:00`).toISOString() : null);

// ─── Fonti ─────────────────────────────────────────────────────
export function SourcesSection({ r, reload }: EditorTabProps) {
  const toast = useToast();
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['source_name', 'source_url', 'external_id', 'google_place_id']);
  const [editing, setEditing] = useState<Partial<RestaurantSource> | null>(null);
  const [busy, setBusy] = useState(false);

  const saveSource = async () => {
    if (!editing) return;
    if (!editing.source_url && !editing.source_name) return toast('Indica almeno nome o URL della fonte', 'error');
    if (editing.source_url && !/^https?:\/\//.test(editing.source_url)) return toast('L’URL deve iniziare con https://', 'error');
    setBusy(true);
    try {
      if (editing.is_primary) {
        for (const s of r.sources.filter((x) => x.is_primary && x.id !== editing.id)) await api.upsert('restaurant_sources', { id: s.id, restaurant_id: r.id, is_primary: false });
      }
      await api.upsert('restaurant_sources', { ...editing, restaurant_id: r.id, last_checked_at: editing.last_checked_at ?? new Date().toISOString() });
      toast('Fonte salvata');
      setEditing(null);
      reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const del = async (s: RestaurantSource) => {
    if (!confirm('Eliminare questa fonte?')) return;
    await api.remove('restaurant_sources', s.id);
    reload();
  };

  return (
    <div className="space-y-6">
      <Panel
        title="Fonti pubbliche"
        description="Da dove provengono i dati della scheda. Una fonte per ogni riscontro verificabile (Google Business Profile, sito ufficiale, Facebook…)."
        footer={<Button icon={<Plus className="h-4 w-4" />} onClick={() => setEditing({ source_type: 'official_website', is_primary: r.sources.length === 0 })}>Aggiungi fonte</Button>}
      >
        {r.sources.length === 0 ? (
          <p className="text-sm text-ink-muted">Nessuna fonte registrata: la scheda non può essere considerata verificata.</p>
        ) : (
          <ul className="divide-y divide-line">
            {r.sources.map((s) => (
              <li key={s.id} className="flex flex-wrap items-center gap-3 py-3">
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2 font-semibold">
                    {s.source_name || SOURCE_TYPE[s.source_type]}
                    {s.is_primary && <Badge tone="dark" icon={<Star className="h-3 w-3" />}>Principale</Badge>}
                    <Badge tone="outline">{SOURCE_TYPE[s.source_type]}</Badge>
                  </p>
                  {s.source_url && (
                    <a href={s.source_url} target="_blank" rel="noopener noreferrer" className="inline-flex max-w-full items-center gap-1 truncate text-sm text-coral-700 hover:underline">
                      <span className="truncate">{s.source_url}</span> <ExternalLink className="h-3 w-3 shrink-0" />
                    </a>
                  )}
                  <p className="text-xs text-ink-muted">Ultimo controllo: {s.last_checked_at ? formatDate(s.last_checked_at) : '—'}{s.external_id ? ` · ID ${s.external_id}` : ''}</p>
                </div>
                <div className="flex gap-1">
                  <button aria-label="Modifica fonte" onClick={() => setEditing(s)} className="rounded-full p-2 text-ink-muted hover:bg-cream hover:text-ink"><Pencil className="h-4 w-4" /></button>
                  <button aria-label="Elimina fonte" onClick={() => del(s)} className="rounded-full p-2 text-ink-muted hover:bg-coral-50 hover:text-coral-700"><Trash2 className="h-4 w-4" /></button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel title="Identificativi" description="Usati dalla deduplicazione dell’import e dalla futura integrazione Google Places." footer={<Button loading={saving} disabled={!dirty} onClick={() => save(undefined, reload)}>Salva</Button>}>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Fonte principale (nome)"><Input value={form.source_name ?? ''} onChange={(e) => set('source_name', str(e.target.value))} /></Field>
          <Field label="Fonte principale (URL)"><Input type="url" value={form.source_url ?? ''} onChange={(e) => set('source_url', str(e.target.value))} placeholder="https://" /></Field>
          <Field label="ID esterno"><Input value={form.external_id ?? ''} onChange={(e) => set('external_id', str(e.target.value))} /></Field>
          <Field label="Google Place ID" hint="Univoco: impedisce duplicati."><Input value={form.google_place_id ?? ''} onChange={(e) => set('google_place_id', str(e.target.value))} /></Field>
        </div>
      </Panel>

      <Sheet open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Modifica fonte' : 'Nuova fonte'}
        footer={<div className="flex justify-end gap-3"><Button variant="outline" onClick={() => setEditing(null)}>Annulla</Button><Button loading={busy} onClick={saveSource}>Salva</Button></div>}>
        {editing && (
          <div className="grid gap-4">
            <Field label="Tipo">
              <Select value={editing.source_type ?? 'other'} onChange={(e) => setEditing({ ...editing, source_type: e.target.value as SourceType })}>
                {(Object.keys(SOURCE_TYPE) as SourceType[]).map((k) => <option key={k} value={k}>{SOURCE_TYPE[k]}</option>)}
              </Select>
            </Field>
            <Field label="Nome"><Input value={editing.source_name ?? ''} onChange={(e) => setEditing({ ...editing, source_name: e.target.value || null })} placeholder="Es. Google Business Profile" /></Field>
            <Field label="URL"><Input type="url" value={editing.source_url ?? ''} onChange={(e) => setEditing({ ...editing, source_url: e.target.value || null })} placeholder="https://" /></Field>
            <Field label="ID esterno"><Input value={editing.external_id ?? ''} onChange={(e) => setEditing({ ...editing, external_id: e.target.value || null })} /></Field>
            <Field label="Data ultimo controllo"><Input type="date" value={toDateInput(editing.last_checked_at)} onChange={(e) => setEditing({ ...editing, last_checked_at: fromDateInput(e.target.value) })} /></Field>
            <Field label="Note"><Textarea rows={2} value={editing.notes ?? ''} onChange={(e) => setEditing({ ...editing, notes: e.target.value || null })} className="!min-h-0" /></Field>
            <Toggle label="Fonte principale" checked={!!editing.is_primary} onChange={(v) => setEditing({ ...editing, is_primary: v })} />
          </div>
        )}
      </Sheet>
    </div>
  );
}

// ─── Stato (pubblicazione, verifica, chiusure) ────────────────
export function StatusSection({ r, reload }: EditorTabProps) {
  const toast = useToast();
  const { form, set, save, saving, dirty } = useRestaurantForm(r, [
    'is_active', 'data_status', 'last_verified_at', 'verification_notes', 'is_temporarily_closed', 'is_permanently_closed', 'is_demo', 'opened_at', 'popularity_score',
  ]);
  const verifyNow = async (publish: boolean) => {
    if (!r.sources.length && !r.source_url) return toast('Aggiungi prima almeno una fonte verificabile', 'error');
    try {
      await api.updateRestaurant(r.id, {
        data_status: r.owner_id ? 'claimed' : 'verified',
        last_verified_at: new Date().toISOString(),
        ...(publish ? { is_active: true } : {}),
      });
      toast(publish ? 'Verificato e pubblicato' : 'Segnato come verificato oggi');
      reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
  return (
    <div className="space-y-6">
      <Panel title="Verifica rapida" description="Usala dopo aver controllato i dati sulle fonti pubbliche indicate nella sezione Fonti.">
        <div className="flex flex-wrap gap-2">
          <Button variant="dark" onClick={() => verifyNow(true)}>Verifica e pubblica</Button>
          <Button variant="outline" onClick={() => verifyNow(false)}>Segna verificato oggi</Button>
        </div>
      </Panel>
      <Panel title="Stato della scheda" footer={<Button loading={saving} disabled={!dirty} onClick={() => save(undefined, reload)}>Salva</Button>}>
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="divide-y divide-line">
            <Toggle label="Pubblicato" description="Visibile al pubblico" checked={form.is_active} onChange={(v) => set('is_active', v)} />
            <Toggle label="Chiuso temporaneamente" checked={form.is_temporarily_closed} onChange={(v) => set('is_temporarily_closed', v)} />
            <Toggle label="Chiuso definitivamente" description="Esce dai risultati di ricerca" checked={form.is_permanently_closed} onChange={(v) => set('is_permanently_closed', v)} />
            <Toggle label="Dati DEMO" description="Scheda dimostrativa, non reale" checked={form.is_demo} onChange={(v) => set('is_demo', v)} />
          </div>
          <div className="grid gap-4">
            <Field label="Stato dati">
              <Select value={form.data_status} onChange={(e) => set('data_status', e.target.value as DataStatus)}>
                {(Object.keys(DATA_STATUS) as DataStatus[]).map((k) => <option key={k} value={k} disabled={k === 'claimed' && !r.owner_id}>{DATA_STATUS[k].label}</option>)}
              </Select>
            </Field>
            <Field label="Ultima verifica"><Input type="date" value={toDateInput(form.last_verified_at)} onChange={(e) => set('last_verified_at', fromDateInput(e.target.value))} /></Field>
            <Field label="Note di verifica" hint="Interne, non pubbliche."><Textarea rows={3} value={form.verification_notes ?? ''} onChange={(e) => set('verification_notes', str(e.target.value))} className="!min-h-0" /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Data apertura" hint="Per “Nuove aperture”."><Input type="date" value={form.opened_at ?? ''} onChange={(e) => set('opened_at', e.target.value || null)} /></Field>
              <Field label="Popolarità" hint="Ordinamento interno."><Input type="number" value={form.popularity_score} onChange={(e) => set('popularity_score', Number(e.target.value))} /></Field>
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
}

// ─── Proprietario e team ──────────────────────────────────────
export function OwnerSection({ r, reload }: EditorTabProps) {
  const toast = useToast();
  const members = useAsync(() => api.listMembers(r.id), [r.id, r.owner_id]);
  const claims = useAsync(() => api.listClaims({ restaurantId: r.id }), [r.id, r.owner_id]);
  const [picker, setPicker] = useState<{ mode: 'transfer' | 'member' } | null>(null);
  const [q, setQ] = useState('');
  const [role, setRole] = useState<MemberRole>('manager');
  const users = useAsync(() => (picker ? api.listProfiles(q || undefined) : Promise.resolve([] as Profile[])), [picker?.mode, q]);
  const refresh = () => {
    members.reload();
    claims.reload();
    reload();
  };
  const run = async (fn: () => Promise<void>, msg: string) => {
    try {
      await fn();
      toast(msg);
      setPicker(null);
      refresh();
    } catch (e) {
      toast((e as Error).message, 'error');
    }
  };
  const active = (members.data ?? []).filter((m) => m.status === 'active');
  const owner = active.find((m) => m.role === 'owner');

  return (
    <div className="space-y-6">
      <Panel
        title="Titolare"
        footer={
          <>
            {owner && <Button variant="danger" icon={<UserMinus className="h-4 w-4" />} onClick={() => confirm('Revocare la proprietà? Il titolare e il suo team perderanno l’accesso.') && run(() => api.revokeOwnership(r.id), 'Proprietà revocata')}>Revoca proprietà</Button>}
            <Button variant="dark" icon={<UserPlus className="h-4 w-4" />} onClick={() => setPicker({ mode: 'transfer' })}>{owner ? 'Trasferisci proprietà' : 'Assegna titolare'}</Button>
          </>
        }
      >
        {owner ? (
          <div className="text-sm">
            <p className="font-semibold">{owner.profile?.full_name || owner.profile?.email}</p>
            <p className="text-ink-muted">{owner.profile?.email} · rivendicato il {r.claimed_at ? formatDate(r.claimed_at) : '—'}</p>
          </div>
        ) : (
          <p className="text-sm text-ink-muted">Nessun titolare: la scheda è rivendicabile dal pubblico.</p>
        )}
      </Panel>

      <Panel title="Team" description="Gestori e staff (predisposto: lo staff per ora ha sola lettura)." footer={<Button variant="outline" icon={<Plus className="h-4 w-4" />} onClick={() => setPicker({ mode: 'member' })}>Aggiungi membro</Button>}>
        {(members.data ?? []).length === 0 ? (
          <p className="text-sm text-ink-muted">Nessun membro.</p>
        ) : (
          <ul className="divide-y divide-line">
            {members.data!.map((m) => (
              <li key={m.id} className={cn('flex items-center justify-between gap-3 py-2.5 text-sm', m.status !== 'active' && 'opacity-50')}>
                <span className="min-w-0 truncate">{m.profile?.full_name || m.profile?.email || m.user_id}</span>
                <span className="flex shrink-0 items-center gap-2">
                  <Badge>{MEMBER_ROLE[m.role]}</Badge>
                  {m.status !== 'active' ? <Badge tone="outline">Revocato</Badge> : (
                    <button aria-label="Rimuovi membro" onClick={() => confirm('Rimuovere questo membro?') && run(() => api.removeMember(m.id), 'Membro rimosso')} className="rounded-full p-1.5 text-ink-muted hover:bg-coral-50 hover:text-coral-700"><Trash2 className="h-4 w-4" /></button>
                  )}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel title="Rivendicazioni per questo locale">
        {(claims.data ?? []).length === 0 ? (
          <p className="text-sm text-ink-muted">Nessuna richiesta.</p>
        ) : (
          <ul className="divide-y divide-line">
            {claims.data!.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm">
                <Link to={`/admin/claims/${c.id}`} className="font-semibold hover:text-coral-700">{c.first_name} {c.last_name}</Link>
                <span className="flex items-center gap-2 text-ink-muted">{formatDate(c.submitted_at, { day: 'numeric', month: 'short' })} <ClaimStatusBadge status={c.status} /></span>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Sheet open={!!picker} onClose={() => setPicker(null)} title={picker?.mode === 'transfer' ? 'Scegli il nuovo titolare' : 'Aggiungi membro'}>
        {picker?.mode === 'member' && (
          <Field label="Ruolo" className="mb-3">
            <Select value={role} onChange={(e) => setRole(e.target.value as MemberRole)}>
              <option value="manager">{MEMBER_ROLE.manager}</option>
              <option value="staff">{MEMBER_ROLE.staff}</option>
            </Select>
          </Field>
        )}
        <Input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cerca per nome o email…" />
        <ul className="mt-3 max-h-80 divide-y divide-line overflow-y-auto">
          {(users.data ?? []).map((p) => (
            <li key={p.id}>
              <button
                className="flex w-full items-center justify-between gap-3 px-1 py-2.5 text-left text-sm hover:bg-cream"
                onClick={() =>
                  picker?.mode === 'transfer'
                    ? confirm(`Assegnare “${r.name}” a ${p.full_name || p.email}?`) && run(() => api.transferOwnership(r.id, p.id), 'Proprietà assegnata')
                    : run(() => api.setMember(r.id, p.id, role), 'Membro aggiunto')
                }
              >
                <span className="min-w-0"><span className="block truncate font-semibold">{p.full_name || '—'}</span><span className="block truncate text-ink-muted">{p.email}</span></span>
                <Badge tone="outline">{p.role}</Badge>
              </button>
            </li>
          ))}
        </ul>
      </Sheet>
    </div>
  );
}

// Abbonamento e sponsorizzazione: vedi components/billing/AdminBilling.tsx (Fase 5)
export { AdminSubscriptionSection as SubscriptionSection, AdminRestaurantCampaigns as SponsorshipSection } from '@/components/billing/AdminBilling';
