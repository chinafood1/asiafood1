import { useMemo, useState } from 'react';
import { CalendarPlus, Check, ChevronLeft, ChevronRight, Clock, MessageSquare, Phone, Plus, Settings2, Trash2, Users, X } from 'lucide-react';
import { useEntitlements, useUpgrade } from '@/context/UpgradeContext';
import { useAsync } from '@/hooks/useAsync';
import { api } from '@/services';
import { cn, telUrl } from '@/lib/format';
import { DAY_NAMES, DAY_SHORT } from '@/lib/hours';
import { addDays, formatDay, localNow, NEXT_STATUSES, RESERVATION_STATUS } from '@/lib/reservations';
import type { Reservation, ReservationSettings, ReservationSlot, ReservationStatus, RestaurantClosure } from '@/types/domain';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { Panel, type EditorTabProps } from './form';

type Tab = 'today' | 'tomorrow' | 'upcoming' | 'past' | 'cancelled' | 'week';
const TABS: [Tab, string][] = [['today', 'Oggi'], ['tomorrow', 'Domani'], ['upcoming', 'Prossime'], ['week', 'Settimana'], ['past', 'Passate'], ['cancelled', 'Cancellate']];
const ACTION_LABEL: Partial<Record<ReservationStatus, string>> = { confirmed: 'Conferma', rejected: 'Rifiuta', completed: 'Completata', no_show: 'No show', cancelled: 'Cancella' };
const CLOSED: ReservationStatus[] = ['cancelled', 'rejected'];

/** Prenotazioni: agenda semplice da smartphone + impostazioni di disponibilità. */
export function ReservationsManager(p: EditorTabProps) {
  const [view, setView] = useState<'agenda' | 'settings'>('agenda');
  return (
    <div className="space-y-4">
      <div className="flex gap-2" role="tablist">
        <Chip active={view === 'agenda'} onClick={() => setView('agenda')} icon={<CalendarPlus className="h-4 w-4" />}>Agenda</Chip>
        <Chip active={view === 'settings'} onClick={() => setView('settings')} icon={<Settings2 className="h-4 w-4" />}>Impostazioni</Chip>
      </div>
      {view === 'agenda' ? <Agenda {...p} onSettings={() => setView('settings')} /> : <ReservationSettingsPanel {...p} />}
    </div>
  );
}

function Agenda({ r, onSettings }: EditorTabProps & { onSettings: () => void }) {
  const toast = useToast();
  const { handleError } = useUpgrade();
  const today = localNow(r.timezone).date;
  const [tab, setTab] = useState<Tab>('today');
  const [weekStart, setWeekStart] = useState(today);
  const [busy, setBusy] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const data = useAsync(() => api.listReservations(r.id, { from: addDays(today, -90), to: addDays(today, 180) }), [r.id]);
  const config = useAsync(() => api.getReservationConfig(r.id), [r.id]);
  const all = useMemo(() => data.data ?? [], [data.data]);

  const pending = all.filter((x) => x.status === 'pending' && x.reservation_date >= today).length;
  const list = useMemo(() => {
    const active = (x: Reservation) => !CLOSED.includes(x.status);
    switch (tab) {
      case 'today': return all.filter((x) => x.reservation_date === today && active(x));
      case 'tomorrow': return all.filter((x) => x.reservation_date === addDays(today, 1) && active(x));
      case 'upcoming': return all.filter((x) => x.reservation_date > today && active(x));
      case 'past': return all.filter((x) => x.reservation_date < today && active(x)).reverse();
      case 'cancelled': return all.filter((x) => CLOSED.includes(x.status)).reverse();
      default: return all.filter((x) => x.reservation_date >= weekStart && x.reservation_date <= addDays(weekStart, 6) && active(x));
    }
  }, [all, tab, today, weekStart]);

  const act = async (x: Reservation, status: ReservationStatus) => {
    if ((status === 'cancelled' || status === 'rejected') && !confirm(`${ACTION_LABEL[status]} la prenotazione di ${x.guest_name} ${x.guest_surname}? Il cliente riceverà una notifica.`)) return;
    setBusy(x.id + status);
    try {
      await api.setReservationStatus(x.id, status);
      toast(`Prenotazione: ${RESERVATION_STATUS[status].label.toLowerCase()}`);
      data.reload();
    } catch (e) {
      handleError(e, r.id, r.subscription_plan);
    } finally {
      setBusy(null);
    }
  };

  if (data.loading && !data.data) return <PageLoader />;
  const enabled = !!config.data?.settings?.reservation_enabled;
  const covers = list.filter((x) => x.status === 'pending' || x.status === 'confirmed').reduce((a, x) => a + x.party_size, 0);
  const byDay = list.reduce<Record<string, Reservation[]>>((acc, x) => ((acc[x.reservation_date] ??= []).push(x), acc), {});

  return (
    <div className="space-y-4">
      {!enabled && config.data && (
        <div className="flex flex-wrap items-center gap-3 rounded-3xl bg-amber-50 px-4 py-3 text-sm text-amber-900">
          <span className="flex-1">Le prenotazioni online sono <strong>disattivate</strong>: i clienti non vedono il pulsante “Prenota un tavolo”.</span>
          <Button size="sm" variant="dark" onClick={onSettings}>Attiva</Button>
        </div>
      )}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="scrollbar-none -mx-1 flex gap-1.5 overflow-x-auto px-1" role="tablist" aria-label="Periodo">
          {TABS.map(([k, label]) => (
            <button
              key={k}
              role="tab"
              aria-selected={tab === k}
              onClick={() => setTab(k)}
              className={cn('inline-flex h-10 shrink-0 items-center gap-1.5 rounded-full px-4 text-sm font-semibold transition', tab === k ? 'bg-ink text-white' : 'bg-white text-ink-soft ring-1 ring-line hover:ring-ink/40')}
            >
              {label}
              {k === 'upcoming' && pending > 0 && <span className="rounded-full bg-coral px-1.5 text-[11px] text-white">{pending}</span>}
            </button>
          ))}
        </div>
        <Button size="sm" icon={<Plus className="h-4 w-4" />} onClick={() => setAdding(true)}>Nuova</Button>
      </div>

      {tab === 'week' && (
        <div className="flex items-center gap-2">
          <button aria-label="Settimana precedente" onClick={() => setWeekStart(addDays(weekStart, -7))} className="rounded-full p-2 hover:bg-cream"><ChevronLeft className="h-5 w-5" /></button>
          <div className="grid flex-1 grid-cols-7 gap-1">
            {Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)).map((d) => {
              const n = all.filter((x) => x.reservation_date === d && !CLOSED.includes(x.status));
              return (
                <a key={d} href={`#day-${d}`} className={cn('rounded-2xl border p-1.5 text-center', d === today ? 'border-ink' : 'border-line', n.length ? 'bg-white' : 'bg-cream/50')}>
                  <span className="block text-[10px] font-semibold uppercase text-ink-muted">{formatDay(d, { weekday: 'short' })}</span>
                  <span className="block font-display text-lg font-bold leading-tight">{Number(d.slice(8))}</span>
                  <span className="block text-[11px] text-ink-muted">{n.length ? `${n.reduce((a, x) => a + x.party_size, 0)} cop.` : '—'}</span>
                </a>
              );
            })}
          </div>
          <button aria-label="Settimana successiva" onClick={() => setWeekStart(addDays(weekStart, 7))} className="rounded-full p-2 hover:bg-cream"><ChevronRight className="h-5 w-5" /></button>
        </div>
      )}

      <p className="text-sm text-ink-muted" aria-live="polite">
        {list.length} {list.length === 1 ? 'prenotazione' : 'prenotazioni'}
        {tab !== 'cancelled' && tab !== 'past' && covers > 0 && ` · ${covers} coperti`}
      </p>

      {list.length === 0 ? (
        <EmptyState icon="📅" title="Nessuna prenotazione" text={tab === 'today' ? 'Oggi non ci sono prenotazioni.' : 'Nessuna prenotazione in questo periodo.'} />
      ) : (
        Object.entries(byDay).map(([day, rows]) => (
          <section key={day} id={`day-${day}`} className="scroll-mt-24">
            {(tab === 'upcoming' || tab === 'past' || tab === 'cancelled' || tab === 'week') && (
              <h3 className="mb-2 mt-4 text-sm font-bold uppercase tracking-wider text-ink-muted">{day === today ? 'Oggi' : formatDay(day, { weekday: 'long', day: 'numeric', month: 'long' })}</h3>
            )}
            <ul className="space-y-2">
              {rows.map((x) => (
                <li key={x.id} className={cn('card flex flex-wrap gap-3 p-4', x.status === 'pending' && 'ring-2 ring-amber-300')}>
                  <div className="flex w-16 shrink-0 flex-col items-center justify-center rounded-2xl bg-cream py-2">
                    <Clock className="h-4 w-4 text-ink-muted" />
                    <span className="font-display text-lg font-bold tabular-nums">{x.reservation_time.slice(0, 5)}</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-bold">{x.guest_name} {x.guest_surname}</p>
                      <Badge tone={RESERVATION_STATUS[x.status].tone}>{RESERVATION_STATUS[x.status].label}</Badge>
                      {x.source !== 'web' && x.source !== 'app' && <Badge tone="outline">Inserita dal locale</Badge>}
                    </div>
                    <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-ink-soft">
                      <span className="inline-flex items-center gap-1"><Users className="h-4 w-4" /> {x.party_size} {x.party_size === 1 ? 'persona' : 'persone'}</span>
                      <a href={telUrl(x.guest_phone)} className="inline-flex items-center gap-1 font-semibold text-coral-700 hover:underline"><Phone className="h-4 w-4" /> {x.guest_phone}</a>
                      <span className="font-mono text-xs text-ink-muted">{x.confirmation_code}</span>
                    </p>
                    {x.notes && <p className="mt-1.5 flex items-start gap-1.5 rounded-xl bg-cream px-3 py-2 text-sm"><MessageSquare className="mt-0.5 h-4 w-4 shrink-0" /> {x.notes}</p>}
                    {NEXT_STATUSES[x.status].length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {NEXT_STATUSES[x.status].map((s) => {
                          const early = (s === 'completed' || s === 'no_show') && x.reservation_date > today;
                          if (early) return null;
                          return (
                            <Button
                              key={s}
                              size="sm"
                              variant={s === 'confirmed' ? 'dark' : s === 'completed' ? 'soft' : s === 'no_show' ? 'outline' : 'danger'}
                              loading={busy === x.id + s}
                              onClick={() => act(x, s)}
                              icon={s === 'confirmed' ? <Check className="h-4 w-4" /> : s === 'rejected' || s === 'cancelled' ? <X className="h-4 w-4" /> : undefined}
                            >
                              {ACTION_LABEL[s]}
                            </Button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </section>
        ))
      )}

      <ManualReservation open={adding} onClose={() => setAdding(false)} r={r} onDone={() => { setAdding(false); data.reload(); }} />
    </div>
  );
}

function ManualReservation({ open, onClose, r, onDone }: { open: boolean; onClose: () => void; r: EditorTabProps['r']; onDone: () => void }) {
  const toast = useToast();
  const { handleError } = useUpgrade();
  const today = localNow(r.timezone).date;
  const [f, setF] = useState({ date: today, time: '20:00', party: 2, name: '', surname: '', phone: '', email: '', notes: '' });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!f.name.trim() || !f.surname.trim() || !f.phone.trim()) return toast('Nome, cognome e telefono sono obbligatori', 'error');
    setBusy(true);
    try {
      const res = await api.createReservation({
        restaurant_id: r.id, date: f.date, time: f.time, party_size: f.party, guest_name: f.name, guest_surname: f.surname,
        guest_email: f.email, guest_phone: f.phone, notes: f.notes || null, source: 'restaurant',
      });
      toast(`Prenotazione ${res.code} inserita`);
      setF({ ...f, name: '', surname: '', phone: '', email: '', notes: '' });
      onDone();
    } catch (e) {
      handleError(e, r.id, r.subscription_plan);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet open={open} onClose={onClose} title="Nuova prenotazione" footer={<div className="flex justify-end gap-3"><Button variant="outline" onClick={onClose}>Annulla</Button><Button loading={busy} onClick={save}>Salva</Button></div>}>
      <p className="mb-4 text-sm text-ink-muted">Per le prenotazioni ricevute al telefono o al banco. Viene confermata subito.</p>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Data"><Input type="date" min={today} value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></Field>
        <Field label="Ora"><Input type="time" value={f.time} onChange={(e) => setF({ ...f, time: e.target.value })} /></Field>
        <Field label="Persone"><Input type="number" min={1} max={100} inputMode="numeric" value={f.party} onChange={(e) => setF({ ...f, party: Math.max(1, Number(e.target.value) || 1) })} /></Field>
        <Field label="Telefono *"><Input type="tel" inputMode="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
        <Field label="Nome *"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Cognome *"><Input value={f.surname} onChange={(e) => setF({ ...f, surname: e.target.value })} /></Field>
        <Field label="Email (facoltativa)" className="col-span-2"><Input type="email" inputMode="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label="Note" className="col-span-2"><Textarea rows={2} maxLength={500} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
      </div>
    </Sheet>
  );
}

const NOTICE_OPTIONS: [number, string][] = [[0, 'Nessuno'], [30, '30 minuti'], [60, '1 ora'], [120, '2 ore'], [240, '4 ore'], [1440, '1 giorno']];

function ReservationSettingsPanel({ r, reload }: EditorTabProps) {
  const toast = useToast();
  const { handleError, openUpgrade } = useUpgrade();
  const ent = useEntitlements(r.subscription_plan);
  const cfg = useAsync(() => api.getReservationConfig(r.id), [r.id]);
  const [draft, setDraft] = useState<ReservationSettings | null>(null);
  const [saving, setSaving] = useState(false);
  const [slotForm, setSlotForm] = useState<{ days: number[]; start: string; end: string; interval: number; maxRes: string; maxGuests: string; label: string } | null>(null);
  const [closure, setClosure] = useState<{ date: string; whole: boolean; start: string; end: string; reason: string } | null>(null);
  const onErr = (e: unknown) => handleError(e, r.id, r.subscription_plan);

  if (cfg.loading && !cfg.data) return <PageLoader />;
  const settings: ReservationSettings = draft ?? cfg.data?.settings ?? {
    restaurant_id: r.id, reservation_enabled: false, min_party_size: 1, max_party_size: 8, slot_duration_minutes: 90,
    booking_notice_minutes: 60, max_advance_days: 30, auto_confirm: false, guest_message: null,
  };
  const set = (patch: Partial<ReservationSettings>) => setDraft({ ...settings, ...patch });
  const slots = cfg.data?.slots ?? [];
  const closures = cfg.data?.closures ?? [];

  const saveSettings = async () => {
    if (settings.max_party_size < settings.min_party_size) return toast('Il massimo di persone deve essere almeno pari al minimo', 'error');
    if (settings.reservation_enabled && !slots.some((s) => s.is_active)) return toast('Aggiungi almeno una fascia oraria prima di attivare le prenotazioni', 'error');
    setSaving(true);
    try {
      await api.saveReservationSettings(settings);
      if (settings.reservation_enabled !== r.has_reservation && settings.reservation_enabled) await api.updateRestaurant(r.id, { has_reservation: true });
      toast('Impostazioni salvate');
      setDraft(null);
      cfg.reload();
      reload();
    } catch (e) {
      onErr(e);
    } finally {
      setSaving(false);
    }
  };

  const addSlots = async () => {
    if (!slotForm) return;
    if (!slotForm.days.length) return toast('Scegli almeno un giorno', 'error');
    if (slotForm.end <= slotForm.start) return toast('L’ora di fine deve seguire quella di inizio', 'error');
    try {
      for (const d of slotForm.days) {
        await api.upsert('reservation_slots', {
          restaurant_id: r.id, day_of_week: d, start_time: slotForm.start, end_time: slotForm.end, slot_interval_minutes: slotForm.interval,
          max_reservations: slotForm.maxRes ? Number(slotForm.maxRes) : null, max_guests: slotForm.maxGuests ? Number(slotForm.maxGuests) : null,
          is_active: true, label: slotForm.label || null,
        });
      }
      toast('Fasce aggiunte');
      setSlotForm(null);
      cfg.reload();
    } catch (e) {
      onErr(e);
    }
  };
  const removeRow = async (table: 'reservation_slots' | 'restaurant_closures', id: string) => {
    try {
      await api.remove(table, id);
      cfg.reload();
    } catch (e) {
      onErr(e);
    }
  };
  const toggleSlot = async (s: ReservationSlot) => {
    try {
      await api.upsert('reservation_slots', { ...s, is_active: !s.is_active });
      cfg.reload();
    } catch (e) {
      onErr(e);
    }
  };
  const addClosure = async () => {
    if (!closure?.date) return toast('Scegli la data', 'error');
    if (!closure.whole && closure.end <= closure.start) return toast('L’ora di fine deve seguire quella di inizio', 'error');
    try {
      await api.upsert('restaurant_closures', {
        restaurant_id: r.id, date: closure.date, start_time: closure.whole ? null : closure.start, end_time: closure.whole ? null : closure.end, reason: closure.reason || null,
      });
      toast('Chiusura aggiunta');
      setClosure(null);
      cfg.reload();
    } catch (e) {
      onErr(e);
    }
  };

  return (
    <div className="space-y-6">
      <Panel title="Prenotazioni online" footer={<Button loading={saving} disabled={!draft} onClick={saveSettings}>Salva</Button>}>
        <Toggle
          label="Accetta prenotazioni online"
          description="Mostra “Prenota un tavolo” nella scheda pubblica"
          checked={settings.reservation_enabled}
          onChange={(v) => (v && !ent.can('reservations_enabled') ? openUpgrade('reservations_enabled', { restaurantId: r.id, plan: r.subscription_plan }) : set({ reservation_enabled: v }))}
        />
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="Persone minime"><Input type="number" min={1} max={50} inputMode="numeric" value={settings.min_party_size} onChange={(e) => set({ min_party_size: Math.max(1, Number(e.target.value) || 1) })} /></Field>
          <Field label="Persone massime"><Input type="number" min={1} max={100} inputMode="numeric" value={settings.max_party_size} onChange={(e) => set({ max_party_size: Math.max(1, Number(e.target.value) || 1) })} /></Field>
          <Field label="Preavviso minimo">
            <Select value={settings.booking_notice_minutes} onChange={(e) => set({ booking_notice_minutes: Number(e.target.value) })}>
              {NOTICE_OPTIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </Select>
          </Field>
          <Field label="Prenotabile fino a (giorni)"><Input type="number" min={1} max={365} inputMode="numeric" value={settings.max_advance_days} onChange={(e) => set({ max_advance_days: Math.min(365, Math.max(1, Number(e.target.value) || 1)) })} /></Field>
          <Field label="Durata media del tavolo (minuti)" hint="Informativa per il locale"><Input type="number" min={15} max={480} step={15} inputMode="numeric" value={settings.slot_duration_minutes} onChange={(e) => set({ slot_duration_minutes: Math.min(480, Math.max(15, Number(e.target.value) || 90)) })} /></Field>
          <Field label="Messaggio per i clienti (facoltativo)"><Input maxLength={300} value={settings.guest_message ?? ''} onChange={(e) => set({ guest_message: e.target.value || null })} placeholder="Es. teniamo il tavolo 15 minuti" /></Field>
        </div>
        <div className="mt-2">
          <Toggle label="Conferma automatica" description="Se attiva la prenotazione è subito confermata; altrimenti la confermi tu dall’agenda." checked={settings.auto_confirm} onChange={(v) => set({ auto_confirm: v })} />
        </div>
      </Panel>

      <Panel
        title="Fasce orarie"
        description="Per ogni servizio: orari prenotabili ogni N minuti, prenotazioni per orario e coperti per fascia. Oltre questi limiti l’orario risulta “Completo”."
        footer={<Button variant="outline" icon={<Plus className="h-4 w-4" />} onClick={() => setSlotForm({ days: [], start: '19:30', end: '22:30', interval: 30, maxRes: '4', maxGuests: '40', label: 'Cena' })}>Aggiungi fascia</Button>}
      >
        {slots.length === 0 ? (
          <p className="text-sm text-ink-muted">Nessuna fascia: aggiungi ad esempio “Cena 19:30–22:30”.</p>
        ) : (
          <ul className="divide-y divide-line">
            {[1, 2, 3, 4, 5, 6, 7].map((d) => {
              const ds = slots.filter((s) => s.day_of_week === d);
              return (
                <li key={d} className="flex flex-wrap items-start gap-3 py-3">
                  <span className="w-24 shrink-0 pt-1 text-sm font-semibold">{DAY_NAMES[d - 1]}</span>
                  <div className="flex flex-1 flex-wrap gap-2">
                    {ds.length === 0 && <span className="pt-1 text-sm text-ink-faint">Chiuso alle prenotazioni</span>}
                    {ds.map((s) => (
                      <span key={s.id} className={cn('inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-sm', s.is_active ? 'border-line bg-white' : 'border-dashed border-line text-ink-faint')}>
                        <button type="button" onClick={() => toggleSlot(s)} className="font-semibold" title={s.is_active ? 'Disattiva' : 'Attiva'}>
                          {s.label ? `${s.label} ` : ''}{s.start_time.slice(0, 5)}–{s.end_time.slice(0, 5)}
                        </button>
                        <span className="text-xs text-ink-muted">· ogni {s.slot_interval_minutes}′{s.max_guests ? ` · ${s.max_guests} cop.` : ''}{s.max_reservations ? ` · ${s.max_reservations}/orario` : ''}</span>
                        <button type="button" aria-label="Elimina fascia" onClick={() => removeRow('reservation_slots', s.id)} className="rounded-full p-0.5 text-ink-muted hover:text-coral-700"><X className="h-3.5 w-3.5" /></button>
                      </span>
                    ))}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Panel>

      <Panel
        title="Chiusure straordinarie"
        description="Festività, ferie, eventi privati: in queste date (o fasce) non si può prenotare."
        footer={<Button variant="outline" icon={<Plus className="h-4 w-4" />} onClick={() => setClosure({ date: localNow().date, whole: true, start: '12:00', end: '15:00', reason: '' })}>Aggiungi chiusura</Button>}
      >
        {closures.length === 0 ? (
          <p className="text-sm text-ink-muted">Nessuna chiusura in programma.</p>
        ) : (
          <ul className="divide-y divide-line">
            {closures.map((c: RestaurantClosure) => (
              <li key={c.id} className="flex items-center gap-3 py-2.5 text-sm">
                <span className="font-semibold">{formatDay(c.date, { weekday: 'short', day: 'numeric', month: 'long' })}</span>
                <span className="text-ink-muted">{c.start_time ? `${c.start_time.slice(0, 5)}–${c.end_time?.slice(0, 5)}` : 'Tutto il giorno'}</span>
                <span className="min-w-0 flex-1 truncate">{c.reason}</span>
                <button aria-label="Elimina chiusura" onClick={() => removeRow('restaurant_closures', c.id)} className="rounded-full p-2 text-ink-muted hover:bg-coral-50 hover:text-coral-700"><Trash2 className="h-4 w-4" /></button>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Sheet open={!!slotForm} onClose={() => setSlotForm(null)} title="Nuova fascia oraria" footer={<div className="flex justify-end gap-3"><Button variant="outline" onClick={() => setSlotForm(null)}>Annulla</Button><Button onClick={addSlots}>Aggiungi</Button></div>}>
        {slotForm && (
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <span className="label">Giorni</span>
              <div className="flex flex-wrap gap-1.5">
                {DAY_SHORT.map((d, i) => (
                  <button key={d} type="button" aria-pressed={slotForm.days.includes(i + 1)} onClick={() => setSlotForm({ ...slotForm, days: slotForm.days.includes(i + 1) ? slotForm.days.filter((x) => x !== i + 1) : [...slotForm.days, i + 1] })}
                    className={cn('h-10 w-12 rounded-xl border text-sm font-semibold', slotForm.days.includes(i + 1) ? 'border-ink bg-ink text-white' : 'border-line bg-white')}>{d}</button>
                ))}
                <button type="button" onClick={() => setSlotForm({ ...slotForm, days: [1, 2, 3, 4, 5, 6, 7] })} className="px-2 text-sm font-semibold text-coral-700">Tutti</button>
              </div>
            </div>
            <Field label="Nome (facoltativo)" className="col-span-2"><Input value={slotForm.label} onChange={(e) => setSlotForm({ ...slotForm, label: e.target.value })} placeholder="Pranzo, Cena…" /></Field>
            <Field label="Dalle"><Input type="time" value={slotForm.start} onChange={(e) => setSlotForm({ ...slotForm, start: e.target.value })} /></Field>
            <Field label="Alle (ultimo orario)"><Input type="time" value={slotForm.end} onChange={(e) => setSlotForm({ ...slotForm, end: e.target.value })} /></Field>
            <Field label="Ogni (minuti)">
              <Select value={slotForm.interval} onChange={(e) => setSlotForm({ ...slotForm, interval: Number(e.target.value) })}>
                {[15, 30, 45, 60].map((v) => <option key={v} value={v}>{v}</option>)}
              </Select>
            </Field>
            <Field label="Prenotazioni per orario" hint="Vuoto = senza limite"><Input type="number" min={1} inputMode="numeric" value={slotForm.maxRes} onChange={(e) => setSlotForm({ ...slotForm, maxRes: e.target.value })} /></Field>
            <Field label="Coperti per fascia" hint="Vuoto = senza limite" className="col-span-2"><Input type="number" min={1} inputMode="numeric" value={slotForm.maxGuests} onChange={(e) => setSlotForm({ ...slotForm, maxGuests: e.target.value })} /></Field>
          </div>
        )}
      </Sheet>

      <Sheet open={!!closure} onClose={() => setClosure(null)} title="Nuova chiusura" footer={<div className="flex justify-end gap-3"><Button variant="outline" onClick={() => setClosure(null)}>Annulla</Button><Button onClick={addClosure}>Aggiungi</Button></div>}>
        {closure && (
          <div className="grid grid-cols-2 gap-4">
            <Field label="Data" className="col-span-2"><Input type="date" min={localNow().date} value={closure.date} onChange={(e) => setClosure({ ...closure, date: e.target.value })} /></Field>
            <div className="col-span-2"><Toggle label="Tutto il giorno" checked={closure.whole} onChange={(v) => setClosure({ ...closure, whole: v })} /></div>
            {!closure.whole && (
              <>
                <Field label="Dalle"><Input type="time" value={closure.start} onChange={(e) => setClosure({ ...closure, start: e.target.value })} /></Field>
                <Field label="Alle"><Input type="time" value={closure.end} onChange={(e) => setClosure({ ...closure, end: e.target.value })} /></Field>
              </>
            )}
            <Field label="Motivo (facoltativo)" className="col-span-2"><Input maxLength={200} value={closure.reason} onChange={(e) => setClosure({ ...closure, reason: e.target.value })} placeholder="Festività, evento privato…" /></Field>
          </div>
        )}
      </Sheet>
    </div>
  );
}
