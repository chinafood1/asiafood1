// Dashboard commerciale del ristoratore: panoramica attività, azioni consigliate, statistiche.
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CalendarCheck, Eye, Lock, MessageCircle, Phone, Rocket, Sparkles, Ticket } from 'lucide-react';
import { ProfileChecklist } from '@/components/billing/Onboarding';
import { useEntitlements, useUpgrade } from '@/context/UpgradeContext';
import { useAsync } from '@/hooks/useAsync';
import { isPlanError } from '@/lib/entitlements';
import { cn, formatDate } from '@/lib/format';
import { addDays, formatDay, localNow, RESERVATION_STATUS } from '@/lib/reservations';
import { api } from '@/services';
import type { RestaurantAnalytics } from '@/types/domain';
import { Badge, Chip, DataStatusBadge } from '@/components/ui/Badge';
import { Alert, EmptyState } from '@/components/ui/Layout';
import { StatTile } from '@/components/layout/DashboardLayout';
import { OrderStatsPanel } from '@/components/orders/OwnerOrders';
import { Panel, type EditorTabProps } from './form';
import { EngagementStatsPanel } from './EngagementSections';

const SOURCE_LABELS: Record<string, string> = {
  direct: 'Accesso diretto', home: 'Home', home_near: 'Home · Vicino a te', home_ayce: 'Home · AYCE', home_popular: 'Home · Popolari',
  home_featured: 'Home · In evidenza', explore: 'Esplora', map: 'Mappa', map_popup: 'Mappa', map_carousel: 'Mappa', offers: 'Offerte',
  similar: 'Locali simili', seo_city: 'Pagina città', favorites: 'Preferiti', ai: 'Assistente AI',
};

/** "Clienti arrivati dall'AI" (Premium/Top): solo eventi reali con origine "ai". */
function AiArrivals({ restaurantId, days }: { restaurantId: string; days: number }) {
  const s = useAsync(() => api.getRestaurantAiStats(restaurantId, days), [restaurantId, days]);
  if (s.error) return null;
  const d = s.data;
  const rows: [string, number | undefined][] = [
    ['Clic dai suggerimenti', d?.result_clicks],
    ['Visite alla scheda', d?.profile_views],
    ['Indicazioni stradali', d?.directions_clicks],
    ['Telefonate', d?.phone_clicks],
    ['Prenotazioni', d?.reservations],
    ['Coupon ottenuti', d?.coupon_claims],
  ];
  return (
    <Panel title="Clienti arrivati dall’AI">
      <p className="mb-3 text-sm text-ink-muted">Persone che hanno trovato il locale tramite l’assistente di ricerca. Solo dati reali: se è zero si mostra zero.</p>
      <dl className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {rows.map(([label, v]) => (
          <div key={label} className="rounded-2xl bg-cream p-3">
            <dt className="text-xs text-ink-muted">{label}</dt>
            <dd className="mt-0.5 text-xl font-extrabold tabular-nums">{v ?? '…'}</dd>
          </div>
        ))}
      </dl>
    </Panel>
  );
}

/** Panoramica attività: KPI, prenotazioni di oggi, azioni consigliate, completezza scheda. */
export function OwnerOverviewSection({ r, base }: EditorTabProps & { base: string }) {
  const ent = useEntitlements(r.subscription_plan);
  const { openUpgrade } = useUpgrade();
  const today = localNow(r.timezone).date;
  const stats = useAsync(() => (ent.can('analytics_enabled') ? api.getRestaurantAnalytics(r.id, 30) : Promise.resolve(null)), [r.id, ent.can('analytics_enabled')]);
  const todayRes = useAsync(
    () => (ent.can('reservations_enabled') ? api.listReservations(r.id, { from: today, to: addDays(today, 1), statuses: ['pending', 'confirmed'] }) : Promise.resolve([])),
    [r.id],
  );
  const itemsCount = r.menus.reduce((a, m) => a + m.sections.reduce((b, s) => b + s.items.length, 0), 0);
  const settingsOn = !!r.reservation_settings?.reservation_enabled;

  // Azioni consigliate: solo quelle utili ora, con invito all'upgrade se la funzione non è nel piano
  const actions = [
    { show: r.menus.length === 0 || itemsCount < 5, label: 'Completa il menu', text: 'I clienti guardano il menu prima di scegliere dove andare.', section: 'menu', feature: 'menu_enabled' as const },
    { show: !r.cover_url || r.images.length < 3, label: 'Aggiungi una foto', text: 'Le schede con foto ricevono più visite.', section: 'foto' },
    { show: r.hours.length === 0, label: 'Inserisci gli orari', text: 'Senza orari il locale non compare in “Aperto ora”.', section: 'orari' },
    { show: r.offers.length === 0, label: 'Crea la tua prima offerta', text: 'Compari nella pagina Offerte e in home.', section: 'offerte', feature: 'offers_enabled' as const },
    { show: !settingsOn, label: 'Attiva le prenotazioni', text: 'Ricevi prenotazioni 24/7 senza telefonate.', section: 'reservations', feature: 'reservations_enabled' as const },
    { show: r.coupons.length === 0, label: 'Crea un coupon di benvenuto', text: 'Porta nuovi clienti e misura quanti tornano.', section: 'coupon', feature: 'coupons_enabled' as const },
  ].filter((a) => a.show);
  const pending = (todayRes.data ?? []).filter((x) => x.status === 'pending').length;

  const e = stats.data?.events ?? {};
  const kpi = [
    { label: 'Visualizzazioni', value: e.restaurant_view ?? 0, icon: Eye },
    { label: 'Telefonate', value: e.phone_click ?? 0, icon: Phone },
    { label: 'WhatsApp', value: e.whatsapp_click ?? 0, icon: MessageCircle },
    { label: 'Prenotazioni', value: stats.data?.reservations.total ?? 0, icon: CalendarCheck },
    { label: 'Coupon utilizzati', value: stats.data?.coupons.redeemed ?? 0, icon: Ticket },
  ];

  return (
    <div className="space-y-6">
      {!r.is_active && <Alert tone="error">La scheda non è pubblicata: lo staff la renderà visibile dopo i controlli.</Alert>}
      {!r.onboarding_completed_at && (
        <Link to={`${base}/onboarding`} className="flex items-center gap-4 rounded-3xl bg-ink p-5 text-white hover:bg-ink-soft">
          <Rocket className="h-7 w-7 shrink-0 text-coral-400" />
          <span className="min-w-0 flex-1">
            <strong className="block text-lg">Configura il tuo locale in 8 passi</strong>
            <span className="text-sm text-white/70">Informazioni, foto, orari, categorie, menu, servizi, piano e pubblicazione.</span>
          </span>
          <ArrowRight className="h-5 w-5 shrink-0" />
        </Link>
      )}
      <div>
        <h2 className="mb-3 text-lg font-bold">Panoramica attività <span className="text-sm font-medium text-ink-muted">· ultimi 30 giorni</span></h2>
        {ent.can('analytics_enabled') ? (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
            {kpi.map((k, i) => (
              <StatTile key={k.label} accent={i === 0} label={k.label} value={stats.loading ? '…' : k.value} />
            ))}
          </div>
        ) : (
          <button type="button" onClick={() => openUpgrade('analytics_enabled', { restaurantId: r.id, plan: r.subscription_plan })} className="flex w-full items-center gap-4 rounded-3xl border border-dashed border-line bg-white p-5 text-left hover:border-ink/40">
            <Lock className="h-6 w-6 shrink-0 text-coral" />
            <span>
              <strong className="block">Visualizzazioni, telefonate, WhatsApp, prenotazioni e coupon</strong>
              <span className="text-sm text-ink-muted">Le statistiche sono incluse dal piano {ent.required('analytics_enabled')?.name ?? 'Business'}.</span>
            </span>
          </button>
        )}
      </div>

      {ent.can('reservations_enabled') && (todayRes.data?.length ?? 0) > 0 && (
        <Panel title="Oggi e domani" description={pending ? `${pending} da confermare` : undefined}>
          <ul className="divide-y divide-line">
            {todayRes.data!.slice(0, 8).map((x) => (
              <li key={x.id} className="flex items-center gap-3 py-2.5 text-sm">
                <span className="w-20 shrink-0 font-semibold tabular-nums">{x.reservation_date === today ? 'Oggi' : 'Domani'} {x.reservation_time.slice(0, 5)}</span>
                <span className="min-w-0 flex-1 truncate">{x.guest_name} {x.guest_surname} · {x.party_size} pers.</span>
                <Badge tone={RESERVATION_STATUS[x.status].tone}>{RESERVATION_STATUS[x.status].label}</Badge>
              </li>
            ))}
          </ul>
          <Link to={`${base}/reservations`} className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-coral-700">Apri l’agenda <ArrowRight className="h-4 w-4" /></Link>
        </Panel>
      )}

      {actions.length > 0 && (
        <Panel title="Azioni consigliate">
          <ul className="grid gap-3 sm:grid-cols-2">
            {actions.map((a) => {
              const locked = a.feature && !ent.can(a.feature);
              const inner = (
                <>
                  <span className={cn('flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl', locked ? 'bg-cream text-ink-muted' : 'bg-coral-50 text-coral-700')}>
                    {locked ? <Lock className="h-5 w-5" /> : <Sparkles className="h-5 w-5" />}
                  </span>
                  <span className="min-w-0">
                    <span className="block font-semibold">{a.label}</span>
                    <span className="block text-sm text-ink-muted">{locked ? `Disponibile con il piano ${ent.required(a.feature!)?.name ?? 'superiore'}.` : a.text}</span>
                  </span>
                </>
              );
              return (
                <li key={a.label}>
                  {locked ? (
                    <button type="button" onClick={() => openUpgrade(a.feature!, { restaurantId: r.id, plan: r.subscription_plan })} className="flex w-full items-start gap-3 rounded-3xl border border-line bg-white p-4 text-left hover:shadow-card">{inner}</button>
                  ) : (
                    <Link to={`${base}/${a.section}`} className="flex items-start gap-3 rounded-3xl border border-line bg-white p-4 hover:shadow-card">{inner}</Link>
                  )}
                </li>
              );
            })}
          </ul>
        </Panel>
      )}

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <ProfileChecklist restaurantId={r.id} base={base} />
        <Panel title="Stato">
          <dl className="space-y-3 text-sm">
            <div className="flex items-center justify-between gap-2"><dt className="text-ink-muted">Dati</dt><dd><DataStatusBadge status={r.data_status} /></dd></div>
            <div className="flex items-center justify-between gap-2"><dt className="text-ink-muted">Piano</dt><dd><Link to={`${base}/billing`} className="font-semibold uppercase text-coral-700 hover:underline">{r.subscription_plan}</Link></dd></div>
            <div className="flex items-center justify-between gap-2"><dt className="text-ink-muted">Orari confermati</dt><dd>{r.opening_hours_last_verified_at ? formatDate(r.opening_hours_last_verified_at, { day: 'numeric', month: 'short' }) : '—'}</dd></div>
            <div className="flex items-center justify-between gap-2"><dt className="text-ink-muted">Menu confermato</dt><dd>{r.menu_last_verified_at ? formatDate(r.menu_last_verified_at, { day: 'numeric', month: 'short' }) : '—'}</dd></div>
          </dl>
        </Panel>
      </div>
    </div>
  );
}

const METRICS: { key: string; label: string; get: (a: RestaurantAnalytics) => number }[] = [
  { key: 'views', label: 'Visualizzazioni profilo', get: (a) => a.events.restaurant_view ?? 0 },
  { key: 'phone', label: 'Click telefono', get: (a) => a.events.phone_click ?? 0 },
  { key: 'wa', label: 'Click WhatsApp', get: (a) => a.events.whatsapp_click ?? 0 },
  { key: 'dir', label: 'Richieste indicazioni', get: (a) => a.events.directions_click ?? 0 },
  { key: 'menu', label: 'Visualizzazioni menu', get: (a) => a.events.menu_view ?? 0 },
  { key: 'res', label: 'Prenotazioni', get: (a) => a.reservations.total },
  { key: 'cclaim', label: 'Coupon richiesti', get: (a) => a.coupons.claimed },
  { key: 'credeem', label: 'Coupon utilizzati', get: (a) => a.coupons.redeemed },
];

/** Statistiche 7 / 30 / 90 giorni. Solo dati reali: se è zero si mostra zero. */
export function AnalyticsSection({ r }: EditorTabProps) {
  const [days, setDays] = useState(30);
  const stats = useAsync(() => api.getRestaurantAnalytics(r.id, days), [r.id, days]);
  const a = stats.data;
  if (stats.error && isPlanError(stats.error)) return null;
  const views = a?.events.restaurant_view ?? 0;
  const contacts = a ? (a.events.phone_click ?? 0) + (a.events.whatsapp_click ?? 0) + (a.events.directions_click ?? 0) : 0;
  return (
    <div className="space-y-6">
      <div className="flex gap-2" role="group" aria-label="Periodo">
        {[7, 30, 90].map((d) => <Chip key={d} active={days === d} onClick={() => setDays(d)}>{d} giorni</Chip>)}
      </div>
      {stats.error ? (
        <EmptyState icon="📊" title="Statistiche non disponibili" text="Controlla la connessione e riprova." />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {METRICS.map((m, i) => (
              <StatTile key={m.key} accent={i === 0} label={m.label} value={a ? m.get(a) : '…'} />
            ))}
          </div>
          <OrderStatsPanel restaurantId={r.id} days={days} />
          {a && (
            <div className="grid gap-4 lg:grid-cols-2">
              <Panel title="Conversioni">
                <dl className="space-y-2 text-sm">
                  <Ratio label="Contatti su visualizzazioni" num={contacts} den={views} />
                  <Ratio label="Prenotazioni su visualizzazioni" num={a.reservations.total} den={views} />
                  <Ratio label="Coupon utilizzati su richiesti" num={a.coupons.redeemed} den={a.coupons.claimed} />
                  <div className="flex justify-between border-t border-line pt-2"><dt className="text-ink-muted">Coperti confermati</dt><dd className="font-semibold tabular-nums">{a.reservations.covers}</dd></div>
                  <div className="flex justify-between"><dt className="text-ink-muted">No show</dt><dd className="font-semibold tabular-nums">{a.reservations.no_show}</dd></div>
                  <div className="flex justify-between"><dt className="text-ink-muted">Cancellate o rifiutate</dt><dd className="font-semibold tabular-nums">{a.reservations.cancelled}</dd></div>
                </dl>
              </Panel>
              <Panel title="Da dove arrivano le visite">
                {a.advanced ? (
                  Object.keys(a.sources).length ? (
                    <ul className="space-y-2 text-sm">
                      {Object.entries(a.sources).sort((x, y) => y[1] - x[1]).slice(0, 8).map(([k, v]) => (
                        <li key={k} className="grid grid-cols-[1fr_auto] items-center gap-3">
                          <span className="truncate">{SOURCE_LABELS[k] ?? k}</span>
                          <span className="font-semibold tabular-nums">{v}</span>
                          <span className="col-span-2 h-1.5 overflow-hidden rounded-full bg-cream"><span className="block h-full rounded-full bg-coral" style={{ width: `${(v / Math.max(1, views)) * 100}%` }} /></span>
                        </li>
                      ))}
                    </ul>
                  ) : <p className="text-sm text-ink-muted">Nessuna visita nel periodo.</p>
                ) : (
                  <p className="text-sm text-ink-muted">Provenienza e andamento giornaliero sono inclusi nelle statistiche avanzate (piano Premium).</p>
                )}
              </Panel>
            </div>
          )}
          <EngagementStatsPanel restaurantId={r.id} days={days} />
          {a?.advanced && <AiArrivals restaurantId={r.id} days={days} />}
          {a?.advanced && <DailyChart data={a.daily} />}
        </>
      )}
    </div>
  );
}

function Ratio({ label, num, den }: { label: string; num: number; den: number }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-ink-muted">{label}</dt>
      <dd className="font-semibold tabular-nums">{den && num <= den ? `${Math.round((num / den) * 1000) / 10}%` : '—'}</dd>
    </div>
  );
}

/** Visualizzazioni al giorno: una sola serie, barre sottili, tooltip al passaggio e tabella alternativa. */
function DailyChart({ data }: { data: RestaurantAnalytics['daily'] }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...data.map((d) => d.views));
  const h = hover !== null ? data[hover] : null;
  return (
    <Panel title="Visualizzazioni al giorno">
      <div className="relative">
        <div className="mb-2 h-5 text-sm" aria-live="polite">
          {h ? <span><strong>{formatDay(h.date, { day: 'numeric', month: 'short' })}</strong> · {h.views} visualizzazioni · {h.contacts} contatti</span> : <span className="text-ink-muted">Passa sulle barre per i dettagli</span>}
        </div>
        <div className="flex h-40 items-end gap-[2px] border-b border-line" onMouseLeave={() => setHover(null)}>
          {data.map((d, i) => (
            <button
              key={d.date}
              type="button"
              aria-label={`${formatDay(d.date, { day: 'numeric', month: 'short' })}: ${d.views} visualizzazioni`}
              onMouseEnter={() => setHover(i)}
              onFocus={() => setHover(i)}
              className="group flex h-full min-w-0 flex-1 items-end"
            >
              <span
                className={cn('block w-full rounded-t-[4px] transition-colors', hover === i ? 'bg-ink' : 'bg-coral')}
                style={{ height: `${d.views ? Math.max(2, (d.views / max) * 100) : 0}%` }}
              />
            </button>
          ))}
        </div>
        <div className="mt-1 flex justify-between text-xs text-ink-muted">
          <span>{formatDay(data[0]!.date, { day: 'numeric', month: 'short' })}</span>
          <span>max {max}</span>
          <span>{formatDay(data[data.length - 1]!.date, { day: 'numeric', month: 'short' })}</span>
        </div>
      </div>
      <details className="mt-3 text-sm">
        <summary className="cursor-pointer font-semibold text-ink-soft">Vedi come tabella</summary>
        <table className="mt-2 w-full text-left">
          <thead className="text-xs text-ink-muted"><tr><th className="py-1">Giorno</th><th className="py-1 text-right">Visualizzazioni</th><th className="py-1 text-right">Contatti</th></tr></thead>
          <tbody>
            {data.filter((d) => d.views || d.contacts).map((d) => (
              <tr key={d.date} className="border-t border-line"><td className="py-1">{formatDay(d.date)}</td><td className="py-1 text-right tabular-nums">{d.views}</td><td className="py-1 text-right tabular-nums">{d.contacts}</td></tr>
            ))}
          </tbody>
        </table>
      </details>
    </Panel>
  );
}
