import { useState } from 'react';
import { Copy, Plus, Trash2 } from 'lucide-react';
import { api } from '@/services';
import { DAY_NAMES, hoursByDay, shortTime } from '@/lib/hours';
import type { RestaurantHour } from '@/types/domain';
import { Button } from '@/components/ui/Button';
import { Toggle } from '@/components/ui/Field';
import { useToast } from '@/components/ui/Toast';
import { Panel, type EditorTabProps } from './form';

interface Slot {
  opens_at: string;
  closes_at: string;
  label: string;
}
interface Day {
  closed: boolean;
  slots: Slot[];
}

const DEFAULT_SLOTS: Slot[] = [
  { opens_at: '12:00', closes_at: '15:00', label: 'Pranzo' },
  { opens_at: '19:00', closes_at: '23:30', label: 'Cena' },
];

/** Editor orari settimanali con più fasce per giorno e chiusura dopo mezzanotte. */
export function HoursEditor({ r, reload }: EditorTabProps) {
  const toast = useToast();
  const [saving, setSaving] = useState(false);
  const [days, setDays] = useState<Day[]>(() =>
    hoursByDay(r.hours).map((d) => ({
      closed: r.hours.length > 0 && d.closed,
      slots: d.slots.length
        ? d.slots.map((s) => ({ opens_at: shortTime(s.opens_at), closes_at: shortTime(s.closes_at), label: s.label ?? '' }))
        : r.hours.length
          ? []
          : DEFAULT_SLOTS.map((s) => ({ ...s })),
    })),
  );

  const update = (i: number, fn: (d: Day) => Day) => setDays((ds) => ds.map((d, k) => (k === i ? fn({ ...d, slots: d.slots.map((s) => ({ ...s })) }) : d)));

  const copyToAll = (i: number) => setDays((ds) => ds.map(() => ({ closed: ds[i]!.closed, slots: ds[i]!.slots.map((s) => ({ ...s })) })));

  const save = async () => {
    for (const d of days) {
      for (const s of d.slots) if (!s.opens_at || !s.closes_at) return toast('Completa tutti gli orari', 'error');
    }
    setSaving(true);
    try {
      type HourInput = Omit<RestaurantHour, 'id' | 'restaurant_id'>;
      const rows = days.flatMap((d, i): HourInput[] =>
        d.closed || d.slots.length === 0
          ? [{ day_of_week: i + 1, opens_at: null, closes_at: null, is_closed: true, label: null }]
          : d.slots.map((s) => ({ day_of_week: i + 1, opens_at: s.opens_at, closes_at: s.closes_at, is_closed: false, label: s.label || null })),
      );
      await api.replaceHours(r.id, rows);
      // Chi salva gli orari (titolare o Admin) ne conferma l'attualità
      await api.updateRestaurant(r.id, { opening_hours_last_verified_at: new Date().toISOString() });
      toast('Orari salvati');
      reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Panel
      title="Orari di apertura"
      description="Puoi aggiungere più fasce per giorno. Se l’orario di chiusura è precedente all’apertura (es. 19:00–00:30) viene considerato dopo la mezzanotte."
      footer={<Button loading={saving} onClick={save}>Salva orari</Button>}
    >
      <ul className="divide-y divide-line">
        {days.map((d, i) => (
          <li key={i} className="grid gap-3 py-4 sm:grid-cols-[140px_1fr_auto] sm:items-start">
            <div className="flex items-center justify-between sm:block">
              <p className="font-semibold">{DAY_NAMES[i]}</p>
              <div className="sm:mt-1">
                <Toggle label="Chiuso" checked={d.closed} onChange={(v) => update(i, (x) => ({ ...x, closed: v, slots: v ? x.slots : x.slots.length ? x.slots : DEFAULT_SLOTS.map((s) => ({ ...s })) }))} />
              </div>
            </div>
            {!d.closed ? (
              <div className="space-y-2">
                {d.slots.map((s, k) => (
                  <div key={k} className="flex flex-wrap items-center gap-2">
                    <input
                      aria-label="Etichetta fascia"
                      value={s.label}
                      placeholder="Fascia"
                      onChange={(e) => update(i, (x) => ((x.slots[k]!.label = e.target.value), x))}
                      className="input !w-28 !py-2"
                    />
                    <input type="time" aria-label="Apertura" value={s.opens_at} onChange={(e) => update(i, (x) => ((x.slots[k]!.opens_at = e.target.value), x))} className="input !w-[120px] !py-2" />
                    <span className="text-ink-muted">–</span>
                    <input type="time" aria-label="Chiusura" value={s.closes_at} onChange={(e) => update(i, (x) => ((x.slots[k]!.closes_at = e.target.value), x))} className="input !w-[120px] !py-2" />
                    <button aria-label="Rimuovi fascia" onClick={() => update(i, (x) => ({ ...x, slots: x.slots.filter((_, j) => j !== k) }))} className="rounded-full p-2 text-ink-muted hover:bg-coral-50 hover:text-coral-700">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
                <button
                  onClick={() => update(i, (x) => ({ ...x, slots: [...x.slots, { opens_at: '19:00', closes_at: '23:00', label: '' }] }))}
                  className="inline-flex items-center gap-1 text-sm font-semibold text-coral-700"
                >
                  <Plus className="h-4 w-4" /> Aggiungi fascia
                </button>
              </div>
            ) : (
              <p className="text-sm text-ink-muted">Chiuso tutto il giorno</p>
            )}
            <button onClick={() => copyToAll(i)} className="inline-flex items-center gap-1 self-start rounded-full px-3 py-1.5 text-xs font-semibold text-ink-muted hover:bg-cream hover:text-ink">
              <Copy className="h-3.5 w-3.5" /> Copia su tutti
            </button>
          </li>
        ))}
      </ul>
    </Panel>
  );
}
