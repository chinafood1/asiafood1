import type { ReactNode } from 'react';
import { Link, NavLink, Navigate, useParams } from 'react-router-dom';
import {
  ArrowLeft, BarChart3, Bot, LineChart, BookOpen, CalendarCheck, CalendarClock, ScanLine, CreditCard, ExternalLink, FileSearch, Gauge, Globe2, Image, Infinity as InfinityIcon,
  LayoutGrid, Link2, MessageSquareText, QrCode as QrIcon, BellRing, MapPin, Megaphone, Phone, Rocket, Search, Settings, Shapes, ShieldCheck, Sparkles, Store, Tag, Ticket, UserCog, Wallet, ShoppingBag, SlidersHorizontal, Landmark,
  type LucideIcon,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useAsync } from '@/hooks/useAsync';
import { useSeo } from '@/lib/seo';
import { cn } from '@/lib/format';
import { api } from '@/services';
import { DataStatusBadge, DemoBadge, VerifiedBadge, Badge } from '@/components/ui/Badge';
import { EmptyState, PageLoader } from '@/components/ui/Layout';
import { PromoEditor } from './PromoEditor';
import type { EditorTabProps } from './form';
import type { FeatureKey } from '@/lib/entitlements';
import {
  AyceSection, CategoriesSection, ContactsSection, HoursSection, ImagesSection, InfoSection, LocationSection, MenuSection,
  OwnerProfileSection, PricesSection, SeoSection, ServicesSection, SettingsSection, SocialSection,
} from './sections';
import { AnalyticsSection, OwnerOverviewSection } from './CommercialSections';
import { ReservationsManager } from './ReservationsManager';
import { OwnerCampaignsSection, OwnerReviewsSection } from './EngagementSections';
import { LaunchKitSection, QrKitSection } from './LaunchSections';
import { CopilotSection, PerformanceSection } from '@/components/growth/RestaurantGrowth';
import { OrderSettingsSection, OrdersTerminal, PayoutsSection } from '@/components/orders/OwnerOrders';
import { FeatureGate } from '@/context/UpgradeContext';
import { OwnerSection, SourcesSection, SponsorshipSection, StatusSection, SubscriptionSection } from './adminSections';
import { BillingSection } from '@/components/billing/BillingSection';
import { AdsSection } from '@/components/billing/Ads';
import { OnboardingWizard } from '@/components/billing/Onboarding';
import { BillingNoticeBanner } from '@/components/billing/BillingUI';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { billingNotice } from '@/lib/billing';
import type { RestaurantDetail } from '@/types/domain';

export { Panel, type EditorTabProps } from './form';

interface SectionDef {
  key: string;
  label: string;
  icon: LucideIcon;
  group?: string;
  /** Nascosta dal menu (resta raggiungibile dall'URL). */
  hidden?: (r: RestaurantDetail) => boolean;
  render: (p: EditorTabProps & { base: string }) => ReactNode;
}

/** Editor Admin: tutte le sezioni richieste, raggruppate. */
const ADMIN_SECTIONS: SectionDef[] = [
  { key: 'info', label: 'Informazioni principali', icon: Store, group: 'Scheda', render: (p) => <InfoSection {...p} /> },
  { key: 'localizzazione', label: 'Localizzazione', icon: MapPin, group: 'Scheda', render: (p) => <LocationSection {...p} /> },
  { key: 'contatti', label: 'Contatti', icon: Phone, group: 'Scheda', render: (p) => <ContactsSection {...p} /> },
  { key: 'categorie', label: 'Categorie', icon: Shapes, group: 'Scheda', render: (p) => <CategoriesSection {...p} /> },
  { key: 'servizi', label: 'Servizi', icon: Sparkles, group: 'Scheda', render: (p) => <ServicesSection {...p} /> },
  { key: 'prezzi', label: 'Prezzi', icon: Wallet, group: 'Scheda', render: (p) => <PricesSection {...p} /> },
  { key: 'ayce', label: 'All You Can Eat', icon: InfinityIcon, group: 'Scheda', render: (p) => <AyceSection {...p} /> },
  { key: 'orari', label: 'Orari', icon: CalendarClock, group: 'Scheda', render: (p) => <HoursSection {...p} /> },
  { key: 'social', label: 'Social', icon: Globe2, group: 'Scheda', render: (p) => <SocialSection {...p} /> },
  { key: 'immagini', label: 'Immagini', icon: Image, group: 'Contenuti', render: (p) => <ImagesSection {...p} /> },
  { key: 'menu', label: 'Menu', icon: BookOpen, group: 'Contenuti', render: (p) => <Gate p={p} feature="menu_enabled"><MenuSection {...p} /></Gate> },
  { key: 'offerte', label: 'Offerte', icon: Tag, group: 'Contenuti', render: (p) => <Gate p={p} feature="offers_enabled"><PromoEditor {...p} only="offers" /></Gate> },
  { key: 'coupon', label: 'Coupon', icon: Ticket, group: 'Contenuti', render: (p) => <Gate p={p} feature="coupons_enabled"><PromoEditor {...p} only="coupons" /></Gate> },
  { key: 'order-settings', label: 'Ordini online', icon: SlidersHorizontal, group: 'Contenuti', render: (p) => <OrderSettingsSection {...p} /> },
  { key: 'reservations', label: 'Prenotazioni', icon: CalendarCheck, group: 'Contenuti', render: (p) => <Gate p={p} feature="reservations_enabled"><ReservationsManager {...p} /></Gate> },
  { key: 'fonti', label: 'Fonti', icon: Link2, group: 'Dati e verifica', render: (p) => <SourcesSection {...p} /> },
  { key: 'seo', label: 'SEO', icon: Search, group: 'Dati e verifica', render: (p) => <SeoSection {...p} /> },
  { key: 'stato', label: 'Stato', icon: ShieldCheck, group: 'Dati e verifica', render: (p) => <StatusSection {...p} /> },
  { key: 'proprietario', label: 'Proprietario', icon: UserCog, group: 'Business', render: (p) => <OwnerSection {...p} /> },
  { key: 'abbonamento', label: 'Abbonamento', icon: CreditCard, group: 'Business', render: (p) => <SubscriptionSection {...p} /> },
  { key: 'sponsorizzazione', label: 'Sponsorizzazione', icon: Megaphone, group: 'Business', render: (p) => <SponsorshipSection {...p} /> },
  { key: 'analytics', label: 'Statistiche', icon: BarChart3, group: 'Business', render: (p) => <Gate p={p} feature="analytics_enabled"><AnalyticsSection {...p} /></Gate> },
  { key: 'performance', label: 'AsiaFood Performance', icon: LineChart, group: 'Business', render: (p) => <PerformanceSection {...p} /> },
  { key: 'copilot', label: 'Copilot', icon: Bot, group: 'Business', render: (p) => <CopilotSection {...p} /> },
  { key: 'launch-kit', label: 'Kit di lancio', icon: Rocket, group: 'Business', render: (p) => <LaunchKitSection {...p} /> },
  { key: 'qr-kit', label: 'Kit QR', icon: QrIcon, group: 'Business', render: (p) => <QrKitSection {...p} /> },
];

/** Dashboard ristoratore: Menu, Orari, Foto e Profilo realmente modificabili. */
const OWNER_SECTIONS: SectionDef[] = [
  { key: 'panoramica', label: 'Panoramica', icon: Gauge, render: (p) => <OwnerOverviewSection {...p} /> },
  // Fase 13: risultati del locale su AsiaFood + Copilot (solo i propri dati)
  { key: 'performance', label: 'AsiaFood Performance', icon: LineChart, render: (p) => <PerformanceSection {...p} /> },
  { key: 'copilot', label: 'Copilot', icon: Bot, render: (p) => <CopilotSection {...p} /> },
  { key: 'orders', label: 'Ordini', icon: ShoppingBag, render: (p) => <OrdersTerminal {...p} /> },
  { key: 'reservations', label: 'Prenotazioni', icon: CalendarCheck, render: (p) => <Gate p={p} feature="reservations_enabled"><ReservationsManager {...p} /></Gate> },
  { key: 'order-settings', label: 'Impostazioni ordini', icon: SlidersHorizontal, render: (p) => <OrderSettingsSection {...p} /> },
  { key: 'payouts', label: 'Pagamenti ordini', icon: Landmark, render: (p) => <PayoutsSection {...p} /> },
  { key: 'menu', label: 'Menu', icon: BookOpen, render: (p) => <Gate p={p} feature="menu_enabled" title="Menu digitale"><MenuSection {...p} /></Gate> },
  { key: 'offerte', label: 'Offerte', icon: Tag, render: (p) => <Gate p={p} feature="offers_enabled"><PromoEditor {...p} only="offers" /></Gate> },
  { key: 'coupon', label: 'Coupon', icon: Ticket, render: (p) => <Gate p={p} feature="coupons_enabled"><PromoEditor {...p} only="coupons" /></Gate> },
  { key: 'valida-coupon', label: 'Valida coupon', icon: ScanLine, render: (p) => <Gate p={p} feature="coupons_enabled"><PromoEditor {...p} only="redeem" /></Gate> },
  { key: 'reviews', label: 'Recensioni', icon: MessageSquareText, render: (p) => <OwnerReviewsSection {...p} /> },
  { key: 'campaigns', label: 'Campagne', icon: BellRing, render: (p) => <Gate p={p} feature="push_campaigns_enabled" title="Campagne push"><OwnerCampaignsSection {...p} /></Gate> },
  { key: 'launch-kit', label: 'Kit di lancio', icon: Rocket, render: (p) => <LaunchKitSection {...p} /> },
  { key: 'qr-kit', label: 'Kit QR', icon: QrIcon, render: (p) => <QrKitSection {...p} /> },
  { key: 'analytics', label: 'Statistiche', icon: BarChart3, render: (p) => <Gate p={p} feature="analytics_enabled"><AnalyticsSection {...p} /></Gate> },
  { key: 'profilo', label: 'Profilo attività', icon: Store, render: (p) => <OwnerProfileSection {...p} /> },
  { key: 'orari', label: 'Orari', icon: CalendarClock, render: (p) => <HoursSection {...p} /> },
  { key: 'foto', label: 'Foto', icon: Image, render: (p) => <ImagesSection {...p} /> },
  { key: 'billing', label: 'Fatturazione', icon: CreditCard, render: (p) => <BillingSection {...p} /> },
  { key: 'ads', label: 'Sponsorizzazioni', icon: Megaphone, render: (p) => <Gate p={p} feature="sponsored_ads" title="Sponsorizzazioni"><AdsSection {...p} /></Gate> },
  { key: 'impostazioni', label: 'Impostazioni', icon: Settings, render: (p) => <SettingsSection {...p} /> },
  { key: 'onboarding', label: 'Configurazione guidata', icon: Rocket, hidden: (r) => !!r.onboarding_completed_at, render: (p) => <OnboardingWizard {...p} /> },
];

/** Sezioni legate al piano: contenuto o invito all'upgrade (mai un errore tecnico). */
function Gate({ p, feature, title, children }: { p: EditorTabProps & { base: string }; feature: FeatureKey; title?: string; children: ReactNode }) {
  return <FeatureGate plan={p.r.subscription_plan} feature={feature} restaurantId={p.r.id} title={title}>{children}</FeatureGate>;
}

/** Vecchi indirizzi delle sezioni (Fase 1–3) → nuovi. */
const SECTION_ALIASES: Record<string, string> = { qr: 'qr-kit', recensioni: 'reviews', campagne: 'campaigns', statistiche: 'analytics', risultati: 'performance', assistente: 'copilot', prenotazioni: 'reservations', piano: 'billing', fatturazione: 'billing', abbonamento: 'billing' };

/** Editor della scheda: Admin (/admin/restaurants/:id/:section) e ristoratore (/dashboard/restaurants/:id/:section). */
export default function RestaurantEditor({ mode }: { mode: 'admin' | 'owner' }) {
  const { id = '', section } = useParams();
  const { isAdmin, user } = useAuth();
  const { data: r, loading, reload } = useAsync(() => api.getRestaurantForEdit(id), [id]);
  const managed = useAsync(() => (mode === 'owner' && user ? api.getManagedRestaurants(user.id) : Promise.resolve([])), [mode, user?.id]);
  useSeo({ title: r ? `Modifica ${r.name}` : 'Modifica ristorante', noindex: true });

  const base = mode === 'admin' ? `/admin/restaurants/${id}` : `/dashboard/restaurants/${id}`;
  const allSections = mode === 'admin' ? ADMIN_SECTIONS : OWNER_SECTIONS;

  if ((loading && !r) || managed.loading) return <PageLoader />;
  // Difesa in profondità: le RLS bloccano già le scritture, qui evitiamo anche di mostrare l'editor.
  const membership = managed.data?.find((m) => m.id === id);
  // Lo staff vede solo il terminale ordini (permesso orders.view/orders.manage); owner e manager tutto.
  const staffOrders = mode === 'owner' && !!membership && membership.member_role === 'staff';
  const canManage = !!r && (mode === 'admin' ? isAdmin : !!membership && (membership.member_role === 'owner' || membership.member_role === 'manager' || staffOrders));
  if (!r || !canManage) {
    return <EmptyState icon="🔎" title="Ristorante non trovato o non autorizzato" action={<Link to={mode === 'admin' ? '/admin/restaurants' : '/dashboard/restaurants'} className="font-semibold text-coral-700">Torna all’elenco</Link>} />;
  }
  const sections = staffOrders ? allSections.filter((s) => s.key === 'orders') : allSections;
  const current = sections.find((s) => s.key === section);
  if (!current) return <Navigate to={`${base}/${(section && SECTION_ALIASES[section] && sections.some((x) => x.key === SECTION_ALIASES[section]) ? SECTION_ALIASES[section] : null) || sections[0]!.key}`} replace />;

  const groups = Array.from(new Set(sections.map((s) => s.group ?? '')));

  return (
    <div>
      <Link to={mode === 'admin' ? '/admin/restaurants' : '/dashboard/restaurants'} className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-ink-muted hover:text-ink">
        <ArrowLeft className="h-4 w-4" /> {mode === 'admin' ? 'Tutti i ristoranti' : 'I miei locali'}
      </Link>
      <header className="mb-6 flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-2xl font-extrabold sm:text-3xl">{r.name}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <DataStatusBadge status={r.data_status} />
            {r.is_verified && r.owner_id && <VerifiedBadge label="Profilo verificato" />}
            {r.is_demo && <DemoBadge />}
            {!r.is_active && <Badge tone="coral">Non pubblicato</Badge>}
            {r.is_temporarily_closed && <Badge tone="amber">Chiuso temporaneamente</Badge>}
            {r.is_permanently_closed && <Badge tone="dark">Chiuso definitivamente</Badge>}
            <span className="text-xs text-ink-muted">/ristorante/{r.slug} · piano <strong className="uppercase">{r.subscription_plan}</strong></span>
          </div>
        </div>
        <div className="flex gap-2">
          {mode === 'admin' && (
            <Link to={`/admin/claims?restaurant=${r.id}`} className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-4 py-2 text-sm font-semibold hover:border-ink">
              <FileSearch className="h-4 w-4" /> Claim
            </Link>
          )}
          {r.is_active && (
            <a href={`/ristorante/${r.slug}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-4 py-2 text-sm font-semibold hover:border-ink">
              Scheda pubblica <ExternalLink className="h-4 w-4" />
            </a>
          )}
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        {/* Navigazione sezioni: chip scorrevoli su mobile, colonna su desktop */}
        <nav aria-label="Sezioni editor" className="scrollbar-none -mx-4 flex gap-2 overflow-x-auto px-4 lg:sticky lg:top-6 lg:mx-0 lg:flex-col lg:gap-0.5 lg:self-start lg:overflow-visible lg:px-0">
          {groups.map((g) => (
            <div key={g || 'all'} className="contents lg:mb-3 lg:block">
              {g && <p className="hidden px-3 pb-1 pt-2 text-[11px] font-bold uppercase tracking-wider text-ink-faint lg:block">{g}</p>}
              {sections.filter((s) => (s.group ?? '') === g && (!s.hidden?.(r) || s.key === current.key)).map((s) => (
                <NavLink
                  key={s.key}
                  to={`${base}/${s.key}`}
                  className={({ isActive }) =>
                    cn(
                      'inline-flex shrink-0 items-center gap-2 rounded-full border px-3.5 py-2 text-sm font-medium transition lg:flex lg:rounded-2xl lg:border-0 lg:px-3',
                      isActive ? 'border-ink bg-ink text-white' : 'border-line bg-white text-ink-soft hover:bg-cream lg:bg-transparent',
                    )
                  }
                >
                  <s.icon className="h-4 w-4 shrink-0" /> {s.label}
                </NavLink>
              ))}
            </div>
          ))}
          {mode === 'owner' && (
            <Link to="/dashboard/claims" className="hidden items-center gap-2 rounded-2xl px-3 py-2 text-sm text-ink-muted hover:bg-cream lg:mt-3 lg:flex">
              <LayoutGrid className="h-4 w-4" /> Le mie richieste
            </Link>
          )}
        </nav>
        <div key={current.key} className="min-w-0 animate-fade-up">
          {mode === 'owner' && current.key !== 'billing' && <EditorBillingBanner restaurantId={r.id} />}
          {current.render({ r, reload, base })}
        </div>
      </div>
    </div>
  );
}

/** Avvisi di fatturazione (pagamento fallito, fine prova…) in cima a ogni sezione del ristoratore. */
function EditorBillingBanner({ restaurantId }: { restaurantId: string }) {
  const { plans } = useReferenceData();
  const ov = useAsync(() => api.getBillingOverview(restaurantId).catch(() => null), [restaurantId]);
  const notice = billingNotice(ov.data, plans);
  if (!notice || notice.kind === 'change_scheduled') return null;
  return <div className="mb-5"><BillingNoticeBanner notice={notice} restaurantId={restaurantId} compact={notice.kind !== 'payment_failed'} /></div>;
}
