import { useRef, useState } from 'react';
import { CheckCircle2, ImagePlus, Pencil, Plus, ScanLine, Search, Trash2, XCircle } from 'lucide-react';
import { useEntitlements, useUpgrade } from '@/context/UpgradeContext';
import { useAsync } from '@/hooks/useAsync';
import { api } from '@/services';
import { isOfferActiveNow } from '@/services/filters';
import { cn, formatDate, formatPrice } from '@/lib/format';
import { DAY_SHORT } from '@/lib/hours';
import type { Coupon, CouponCheck, DiscountType, Offer, OfferType } from '@/types/domain';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { discountLabel, OFFER_TYPE_LABELS } from '@/components/restaurant/Offers';
import { Panel, type EditorTabProps } from './form';

const DISCOUNT_TYPES: Record<DiscountType, string> = {
  percent: 'Percentuale (%)',
  amount: 'Importo (€)',
  fixed_price: 'Prezzo fisso (€)',
  free_item: 'Omaggio',
  other: 'Altro',
};
/** Tipo di offerta → sconto suggerito (modificabile). */
const DEFAULT_DISCOUNT: Record<OfferType, DiscountType> = {
  percentage: 'percent', fixed_amount: 'amount', special_menu: 'fixed_price', two_for_one: 'free_item',
  happy_hour: 'percent', ayce_promo: 'fixed_price', free_dish: 'free_item', other: 'other',
};

const toLocalInput = (iso: string | null | undefined) => (iso ? new Date(iso).toISOString().slice(0, 10) : '');
const fromLocalInput = (v: string, endOfDay = false) => (v ? new Date(`${v}T${endOfDay ? '23:59:59' : '00:00:00'}`).toISOString() : null);
const numOrNull = (v: string) => (v === '' ? null : Math.max(0, Number(v.replace(',', '.'))));
const couponLive = (c: Coupon) => isOfferActiveNow({ is_active: c.is_active, starts_at: c.valid_from, ends_at: c.valid_until });

type Editing = { kind: 'offer'; data: Partial<Offer> } | { kind: 'coupon'; data: Partial<Coupon> } | null;

/** Offerte, coupon e validazione codici; `only` mostra una sola sezione (voci separate nella dashboard). */
export function PromoEditor({ r, reload, only }: EditorTabProps & { only?: 'offers' | 'coupons' | 'redeem' }) {
  const toast = useToast();
  const { handleError: onError, openUpgrade } = useUpgrade();
  const handleError = (e: unknown) => onError(e, r.id, r.subscription_plan);
  const ent = useEntitlements(r.subscription_plan);
  const [editing, setEditing] = useState<Editing>(null);
  const [saving, setSaving] = useState(false);
  const liveOffers = r.offers.filter((o) => isOfferActiveNow(o)).length;
  const liveCoupons = r.coupons.filter(couponLive).length;

  const save = async () => {
    if (!editing) return;
    const d = { ...editing.data } as Record<string, unknown>;
    if (!String(d.title ?? '').trim()) return toast('Il titolo è obbligatorio', 'error');
    if (editing.kind === 'coupon' && !/^[A-Z0-9][A-Z0-9-]{2,23}$/.test(String(d.code ?? ''))) return toast('Codice: 3–24 caratteri tra lettere, numeri e trattino', 'error');
    if (editing.kind === 'offer' && !!d.start_time !== !!d.end_time) return toast('Indica sia l’ora di inizio sia quella di fine', 'error');
    setSaving(true);
    try {
      await api.upsert(editing.kind === 'offer' ? 'offers' : 'coupons', { ...d, restaurant_id: r.id });
      toast('Salvato');
      setEditing(null);
      reload();
    } catch (e) {
      handleError(e);
    } finally {
      setSaving(false);
    }
  };

  const del = async (table: 'offers' | 'coupons', id: string) => {
    if (!confirm('Eliminare definitivamente?')) return;
    try {
      await api.remove(table, id);
      reload();
    } catch (e) {
      handleError(e);
    }
  };

  const newOffer = () => {
    if (!ent.can('offers_enabled')) return openUpgrade('offers_enabled', { restaurantId: r.id, plan: r.subscription_plan });
    if (!ent.within('max_active_offers', liveOffers)) return openUpgrade('max_active_offers', { restaurantId: r.id, kind: 'limit', plan: r.subscription_plan });
    setEditing({ kind: 'offer', data: { title: '', offer_type: 'percentage', discount_type: 'percent', days_of_week: [], is_active: true, is_featured: false, starts_at: new Date().toISOString() } });
  };
  const newCoupon = () => {
    if (!ent.can('coupons_enabled')) return openUpgrade('coupons_enabled', { restaurantId: r.id, plan: r.subscription_plan });
    if (!ent.within('max_active_coupons', liveCoupons)) return openUpgrade('max_active_coupons', { restaurantId: r.id, kind: 'limit', plan: r.subscription_plan });
    setEditing({ kind: 'coupon', data: { title: '', code: '', discount_type: 'percent', is_active: true, valid_from: new Date().toISOString(), max_redemptions_per_user: 1 } });
  };

  const offerLimit = ent.limit('max_active_offers');
  const couponLimit = ent.limit('max_active_coupons');

  return (
    <div className="space-y-6">
      {only === 'redeem' && <CouponValidator restaurantId={r.id} />}

      {(!only || only === 'offers') && (
        <Panel
          title="Offerte"
          description={`Promozioni visibili nella scheda e nella pagina Offerte.${offerLimit !== null && ent.has('offers_enabled') ? ` Attive: ${liveOffers}/${offerLimit}.` : ''}`}
          footer={<Button icon={<Plus className="h-4 w-4" />} onClick={newOffer}>Crea offerta</Button>}
        >
          {r.offers.length === 0 ? (
            <p className="text-sm text-ink-muted">Nessuna offerta. Crea la prima: ad esempio un menu pranzo, un happy hour o una promo AYCE.</p>
          ) : (
            <PromoList
              rows={r.offers.map((o) => ({
                id: o.id, title: o.title, label: discountLabel(o), active: isOfferActiveNow(o), until: o.ends_at, featured: o.is_featured,
                sub: [OFFER_TYPE_LABELS[o.offer_type], o.days_of_week.length && o.days_of_week.length < 7 ? o.days_of_week.map((d) => DAY_SHORT[d - 1]).join(' ') : null, o.start_time ? `${o.start_time.slice(0, 5)}–${o.end_time?.slice(0, 5)}` : null].filter(Boolean).join(' · '),
              }))}
              onEdit={(id) => setEditing({ kind: 'offer', data: r.offers.find((o) => o.id === id)! })}
              onDelete={(id) => del('offers', id)}
            />
          )}
        </Panel>
      )}

      {(!only || only === 'coupons') && (
        <>
          <Panel
            title="Coupon"
            description={`Il cliente preme “Ottieni coupon” e riceve un codice personale (es. SUSHI20-X7P4) da mostrare in cassa.${couponLimit !== null && ent.has('coupons_enabled') ? ` Attivi: ${liveCoupons}/${couponLimit}.` : ''}`}
            footer={<Button icon={<Plus className="h-4 w-4" />} onClick={newCoupon}>Crea coupon</Button>}
          >
            {r.coupons.length === 0 ? (
              <p className="text-sm text-ink-muted">Nessun coupon.</p>
            ) : (
              <PromoList
                rows={r.coupons.map((c) => ({
                  id: c.id, title: `${c.title} · ${c.code}`, label: discountLabel(c), active: couponLive(c), until: c.valid_until,
                  sub: `${c.claims_count} ottenuti${c.max_redemptions ? ` su ${c.max_redemptions}` : ''} · ${c.redemptions_count} utilizzati${c.minimum_spend ? ` · min. ${formatPrice(c.minimum_spend, true)}` : ''}`,
                }))}
                onEdit={(id) => setEditing({ kind: 'coupon', data: r.coupons.find((c) => c.id === id)! })}
                onDelete={(id) => del('coupons', id)}
              />
            )}
          </Panel>
          {ent.can('coupons_enabled') && <CouponValidator restaurantId={r.id} compact />}
        </>
      )}

      <Sheet
        open={!!editing}
        onClose={() => setEditing(null)}
        wide
        title={editing?.kind === 'offer' ? (editing.data.id ? 'Modifica offerta' : 'Nuova offerta') : editing?.data.id ? 'Modifica coupon' : 'Nuovo coupon'}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setEditing(null)}>Annulla</Button>
            <Button loading={saving} onClick={save}>Salva</Button>
          </div>
        }
      >
        {editing?.kind === 'offer' && <OfferForm data={editing.data} onChange={(data) => setEditing({ kind: 'offer', data })} canFeature={ent.can('featured_listing')} restaurantId={r.id} />}
        {editing?.kind === 'coupon' && <CouponForm data={editing.data} onChange={(data) => setEditing({ kind: 'coupon', data })} offers={r.offers} />}
      </Sheet>
    </div>
  );
}

function PromoList({ rows, onEdit, onDelete }: { rows: { id: string; title: string; sub: string | null; label: string | null; active: boolean; until: string | null; featured?: boolean }[]; onEdit: (id: string) => void; onDelete: (id: string) => void }) {
  return (
    <ul className="divide-y divide-line">
      {rows.map((x) => (
        <li key={x.id} className="flex flex-wrap items-center gap-3 py-3">
          <span className="flex h-11 w-14 shrink-0 items-center justify-center rounded-xl bg-coral-50 text-xs font-bold text-coral-700">{x.label ?? '%'}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-semibold">{x.title}</p>
            <p className="truncate text-xs text-ink-muted">
              {x.sub}
              {x.until && ` · fino al ${formatDate(x.until)}`}
            </p>
          </div>
          {x.featured && <Badge tone="amber">In evidenza</Badge>}
          <Badge tone={x.active ? 'green' : 'neutral'}>{x.active ? 'Attivo' : 'Non attivo'}</Badge>
          <button aria-label="Modifica" onClick={() => onEdit(x.id)} className="rounded-full p-2 text-ink-muted hover:bg-cream hover:text-ink"><Pencil className="h-4 w-4" /></button>
          <button aria-label="Elimina" onClick={() => onDelete(x.id)} className="rounded-full p-2 text-ink-muted hover:bg-coral-50 hover:text-coral-700"><Trash2 className="h-4 w-4" /></button>
        </li>
      ))}
    </ul>
  );
}

function DiscountFields<T extends { discount_type?: DiscountType; discount_value?: number | null }>({ data, onChange }: { data: T; onChange: (d: T) => void }) {
  return (
    <>
      <Field label="Tipo di sconto">
        <Select value={data.discount_type} onChange={(e) => onChange({ ...data, discount_type: e.target.value as DiscountType })}>
          {Object.entries(DISCOUNT_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      </Field>
      <Field label="Valore">
        <Input type="number" min={0} step="0.1" inputMode="decimal" value={data.discount_value ?? ''} disabled={data.discount_type === 'free_item' || data.discount_type === 'other'}
          onChange={(e) => onChange({ ...data, discount_value: numOrNull(e.target.value) })} />
      </Field>
    </>
  );
}

function OfferForm({ data, onChange, canFeature, restaurantId }: { data: Partial<Offer>; onChange: (d: Partial<Offer>) => void; canFeature: boolean; restaurantId: string }) {
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const days = data.days_of_week ?? [];
  const upload = async (file: File) => {
    if (!file.type.startsWith('image/') || file.size > 5 * 1024 * 1024) return toast('Carica un’immagine fino a 5 MB', 'error');
    setUploading(true);
    try {
      onChange({ ...data, image_url: (await api.uploadImage(restaurantId, file, 'gallery')).url });
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setUploading(false);
    }
  };
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Titolo" className="sm:col-span-2"><Input autoFocus maxLength={120} value={data.title ?? ''} onChange={(e) => onChange({ ...data, title: e.target.value })} placeholder="Es. Martedì AYCE a € 19,90" /></Field>
      <Field label="Descrizione" className="sm:col-span-2"><Textarea rows={2} value={data.description ?? ''} onChange={(e) => onChange({ ...data, description: e.target.value || null })} /></Field>
      <Field label="Tipo di offerta">
        <Select value={data.offer_type} onChange={(e) => { const t = e.target.value as OfferType; onChange({ ...data, offer_type: t, discount_type: DEFAULT_DISCOUNT[t] }); }}>
          {Object.entries(OFFER_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      </Field>
      <Field label="Spesa minima (€)"><Input type="number" min={0} inputMode="decimal" value={data.minimum_spend ?? ''} onChange={(e) => onChange({ ...data, minimum_spend: numOrNull(e.target.value) })} /></Field>
      <DiscountFields data={data} onChange={onChange} />
      <div className="sm:col-span-2">
        <span className="label">Giorni validi (nessuno = tutti)</span>
        <div className="flex flex-wrap gap-1.5">
          {DAY_SHORT.map((d, i) => (
            <button key={d} type="button" aria-pressed={days.includes(i + 1)} onClick={() => onChange({ ...data, days_of_week: days.includes(i + 1) ? days.filter((x) => x !== i + 1) : [...days, i + 1].sort() })}
              className={cn('h-10 w-12 rounded-xl border text-sm font-semibold', days.includes(i + 1) ? 'border-ink bg-ink text-white' : 'border-line bg-white')}>
              {d}
            </button>
          ))}
        </div>
      </div>
      <Field label="Dalle ore (facoltativo)" hint="Es. happy hour"><Input type="time" value={data.start_time?.slice(0, 5) ?? ''} onChange={(e) => onChange({ ...data, start_time: e.target.value || null })} /></Field>
      <Field label="Alle ore"><Input type="time" value={data.end_time?.slice(0, 5) ?? ''} onChange={(e) => onChange({ ...data, end_time: e.target.value || null })} /></Field>
      <Field label="Dal"><Input type="date" value={toLocalInput(data.starts_at)} onChange={(e) => onChange({ ...data, starts_at: fromLocalInput(e.target.value) ?? new Date().toISOString() })} /></Field>
      <Field label="Al (facoltativo)"><Input type="date" value={toLocalInput(data.ends_at)} onChange={(e) => onChange({ ...data, ends_at: fromLocalInput(e.target.value, true) })} /></Field>
      <Field label="Utilizzi massimi (facoltativo)"><Input type="number" min={1} inputMode="numeric" value={data.max_redemptions ?? ''} onChange={(e) => onChange({ ...data, max_redemptions: e.target.value === '' ? null : Math.max(1, Number(e.target.value)) })} /></Field>
      <div>
        <span className="label">Immagine (facoltativa)</span>
        <div className="flex items-center gap-3">
          {data.image_url && <img src={data.image_url} alt="" className="h-12 w-16 rounded-xl object-cover" />}
          <Button type="button" variant="outline" size="sm" loading={uploading} icon={<ImagePlus className="h-4 w-4" />} onClick={() => fileRef.current?.click()}>{data.image_url ? 'Cambia' : 'Carica'}</Button>
          <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
        </div>
      </div>
      <Field label="Condizioni" className="sm:col-span-2"><Input value={data.terms ?? ''} onChange={(e) => onChange({ ...data, terms: e.target.value || null })} placeholder="Es. bevande escluse, non cumulabile" /></Field>
      <div className="divide-y divide-line sm:col-span-2">
        <Toggle label="Attiva" checked={data.is_active ?? true} onChange={(v) => onChange({ ...data, is_active: v })} />
        <Toggle label="In evidenza" description={canFeature ? 'Prima nelle liste offerte e in home' : 'Disponibile con il piano Top'} checked={!!data.is_featured} onChange={(v) => canFeature && onChange({ ...data, is_featured: v })} />
      </div>
    </div>
  );
}

function CouponForm({ data, onChange, offers }: { data: Partial<Coupon>; onChange: (d: Partial<Coupon>) => void; offers: Offer[] }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Titolo"><Input autoFocus maxLength={120} value={data.title ?? ''} onChange={(e) => onChange({ ...data, title: e.target.value })} placeholder="Es. -10% sul conto" /></Field>
      <Field label="Codice (prefisso)" hint="Il cliente riceve un codice personale, es. SUSHI20-X7P4">
        <Input value={data.code ?? ''} maxLength={24} onChange={(e) => onChange({ ...data, code: e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, '') })} placeholder="SUSHI20" />
      </Field>
      <Field label="Descrizione" className="sm:col-span-2"><Input value={data.description ?? ''} onChange={(e) => onChange({ ...data, description: e.target.value || null })} /></Field>
      <DiscountFields data={data} onChange={onChange} />
      <Field label="Spesa minima (€)"><Input type="number" min={0} inputMode="decimal" value={data.minimum_spend ?? ''} onChange={(e) => onChange({ ...data, minimum_spend: numOrNull(e.target.value) })} /></Field>
      <Field label="Collegato all’offerta (facoltativo)">
        <Select value={data.offer_id ?? ''} onChange={(e) => onChange({ ...data, offer_id: e.target.value || null })}>
          <option value="">Nessuna</option>
          {offers.map((o) => <option key={o.id} value={o.id}>{o.title}</option>)}
        </Select>
      </Field>
      <Field label="Codici disponibili in totale" hint="Vuoto = senza limite"><Input type="number" min={1} inputMode="numeric" value={data.max_redemptions ?? ''} onChange={(e) => onChange({ ...data, max_redemptions: e.target.value === '' ? null : Math.max(1, Number(e.target.value)) })} /></Field>
      <Field label="Codici per persona" hint="Anti-abuso: limite per account o email"><Input type="number" min={1} max={20} inputMode="numeric" value={data.max_redemptions_per_user ?? 1} onChange={(e) => onChange({ ...data, max_redemptions_per_user: Math.min(20, Math.max(1, Number(e.target.value) || 1)) })} /></Field>
      <Field label="Valido dal"><Input type="date" value={toLocalInput(data.valid_from)} onChange={(e) => onChange({ ...data, valid_from: fromLocalInput(e.target.value) ?? new Date().toISOString() })} /></Field>
      <Field label="Valido fino al"><Input type="date" value={toLocalInput(data.valid_until)} onChange={(e) => onChange({ ...data, valid_until: fromLocalInput(e.target.value, true) })} /></Field>
      <Field label="Condizioni" className="sm:col-span-2"><Input value={data.terms ?? ''} onChange={(e) => onChange({ ...data, terms: e.target.value || null })} /></Field>
      <div className="sm:col-span-2"><Toggle label="Attivo" checked={data.is_active ?? true} onChange={(v) => onChange({ ...data, is_active: v })} /></div>
    </div>
  );
}

/** Validazione in cassa: inserisci (o detta) il codice, verifica, segna come utilizzato. */
export function CouponValidator({ restaurantId, compact }: { restaurantId: string; compact?: boolean }) {
  const toast = useToast();
  const [code, setCode] = useState('');
  const [check, setCheck] = useState<CouponCheck | null>(null);
  const [busy, setBusy] = useState<'check' | 'redeem' | null>(null);
  const claims = useAsync(() => api.listCouponClaims(restaurantId, 20), [restaurantId]);

  const verify = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (code.trim().length < 5) return;
    setBusy('check');
    try {
      setCheck(await api.checkCouponClaim(restaurantId, code));
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };
  const redeem = async () => {
    setBusy('redeem');
    try {
      setCheck(await api.redeemCoupon(restaurantId, code));
      toast('Coupon segnato come utilizzato');
      claims.reload();
    } catch (err) {
      toast((err as Error).message, 'error');
      void verify();
    } finally {
      setBusy(null);
    }
  };

  const status = check?.found ? check.status : null;
  return (
    <Panel title="Valida coupon" description="Chiedi al cliente il codice (o leggilo dal QR sul suo telefono) e segnalo come utilizzato.">
      <form onSubmit={verify} className="flex gap-2">
        <label className="relative flex-1">
          <span className="sr-only">Codice coupon</span>
          <ScanLine className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-muted" />
          <input
            value={code}
            onChange={(e) => { setCode(e.target.value.toUpperCase().replace(/\s+/g, '')); setCheck(null); }}
            placeholder="Es. SUSHI20-X7P4"
            autoCapitalize="characters"
            autoComplete="off"
            className="h-12 w-full rounded-full border border-line bg-white pl-11 pr-4 font-mono text-lg tracking-wider focus:border-ink focus:outline-none"
          />
        </label>
        <Button type="submit" size="lg" loading={busy === 'check'} icon={<Search className="h-4 w-4" />}>Verifica</Button>
      </form>

      {check && (
        <div className="mt-4 rounded-3xl border border-line p-4" role="status">
          {!check.found ? (
            <p className="flex items-center gap-2 font-semibold text-coral-700"><XCircle className="h-5 w-5" /> Codice non trovato per questo ristorante.</p>
          ) : (
            <>
              <p className={cn('flex items-center gap-2 font-semibold', status === 'claimed' ? 'text-emerald-700' : 'text-coral-700')}>
                {status === 'claimed' ? <CheckCircle2 className="h-5 w-5" /> : <XCircle className="h-5 w-5" />}
                {status === 'claimed' ? 'Coupon valido' : status === 'redeemed' ? `Già utilizzato il ${formatDate(check.redeemed_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}` : status === 'expired' ? 'Coupon scaduto' : 'Coupon non valido'}
              </p>
              <p className="mt-1 text-lg font-bold">{check.title}</p>
              <p className="text-sm text-ink-muted">
                {[check.discount_type && discountLabel({ discount_type: check.discount_type, discount_value: check.discount_value ?? null }), check.minimum_spend ? `spesa minima ${formatPrice(check.minimum_spend, true)}` : null, check.valid_until ? `valido fino al ${formatDate(check.valid_until)}` : null].filter(Boolean).join(' · ')}
              </p>
              {status === 'claimed' && check.coupon_active !== false && (
                <Button className="mt-3 w-full sm:w-auto" size="lg" loading={busy === 'redeem'} onClick={redeem}>Segna come utilizzato</Button>
              )}
            </>
          )}
        </div>
      )}

      {!compact && (claims.data?.length ?? 0) > 0 && (
        <div className="mt-6">
          <p className="mb-2 text-sm font-bold">Ultimi coupon</p>
          <ul className="divide-y divide-line text-sm">
            {claims.data!.map((x) => (
              <li key={x.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                <span className="font-mono">{x.claim_code}</span>
                <span className="text-ink-muted">{x.coupon?.title}</span>
                <Badge tone={x.status === 'redeemed' ? 'neutral' : x.status === 'claimed' ? 'green' : 'amber'}>
                  {x.status === 'redeemed' ? `Usato ${formatDate(x.redeemed_at, { day: 'numeric', month: 'short' })}` : x.status === 'claimed' ? 'Da usare' : 'Scaduto'}
                </Badge>
              </li>
            ))}
          </ul>
        </div>
      )}
    </Panel>
  );
}
