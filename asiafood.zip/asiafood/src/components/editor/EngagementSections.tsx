import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { BadgeCheck, Flag, Megaphone, MessageSquareReply, Send, UserPlus, Users } from 'lucide-react';
import { useEntitlements, useUpgrade } from '@/context/UpgradeContext';
import { useAsync } from '@/hooks/useAsync';
import { formatDate } from '@/lib/format';
import { APP } from '@/config/app';
import { api } from '@/services';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { Alert, EmptyState, Spinner } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import { StatTile } from '@/components/layout/DashboardLayout';
import { StarsDisplay, formatRating } from '@/components/reviews/Stars';
import {
  REVIEW_REPORT_REASONS, RESTAURANT_TARGETS,
  type Campaign, type CampaignChannel, type CampaignTarget, type ManagedReview, type PushCampaignStats, type ReviewReportReason,
} from '@/types/engagement';
import { Panel, type EditorTabProps } from './form';

const REVIEW_STATUS: Record<string, { label: string; tone: 'neutral' | 'green' | 'amber' | 'coral' | 'dark' }> = {
  published: { label: 'Pubblicata', tone: 'green' },
  pending: { label: 'In moderazione', tone: 'amber' },
  flagged: { label: 'Segnalata', tone: 'amber' },
  hidden: { label: 'Nascosta', tone: 'dark' },
  rejected: { label: 'Rifiutata', tone: 'coral' },
};

// ─── Recensioni (ristoratore) ────────────────────────────────
/** Il ristoratore legge, risponde (una risposta ufficiale) e segnala. Non può modificare né eliminare. */
export function OwnerReviewsSection({ r }: EditorTabProps) {
  const [page, setPage] = useState(0);
  const PAGE = 10;
  const data = useAsync(() => api.listManagedReviews(r.id, { limit: PAGE, offset: page * PAGE }), [r.id, page]);
  const [reply, setReply] = useState<ManagedReview | null>(null);
  const [report, setReport] = useState<ManagedReview | null>(null);
  const rating = data.data?.rating;
  const items = data.data?.items ?? [];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile accent label="Valutazione media" value={rating?.average != null ? formatRating(rating.average) : '—'} hint={rating?.count ? undefined : 'Ancora nessuna recensione'} />
        <StatTile label="Recensioni pubblicate" value={rating?.count ?? '…'} />
        <StatTile label="Verificate" value={rating?.verified_count ?? '…'} hint="Legate a una visita reale" />
        <StatTile label="Con risposta" value={items.filter((i) => i.response).length} hint="In questa pagina" />
      </div>
      <Alert>
        Puoi rispondere a ogni recensione una sola volta (la risposta resta modificabile) e segnalare contenuti inappropriati: la decisione finale spetta allo staff {APP.name}. Non è possibile modificare o eliminare le recensioni dei clienti.
      </Alert>
      <Panel title="Recensioni ricevute">
        {data.loading && !data.data ? (
          <div className="flex justify-center py-8"><Spinner /></div>
        ) : data.error ? (
          <EmptyState icon="⚠️" title="Recensioni non disponibili" text="Riprova tra qualche istante." />
        ) : items.length === 0 ? (
          <EmptyState icon="💬" title="Ancora nessuna recensione" text="Stampa il QR “Racconta la tua esperienza” dalla sezione QR code per invitare i clienti a lasciare un’opinione." />
        ) : (
          <ul className="divide-y divide-line" data-testid="owner-reviews">
            {items.map((v) => {
              const st = REVIEW_STATUS[v.status] ?? REVIEW_STATUS.pending!;
              return (
                <li key={v.id} className="py-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <StarsDisplay value={v.rating_overall} size="sm" />
                    <span className="font-semibold">{v.author}</span>
                    {v.is_verified && <Badge tone="green" icon={<BadgeCheck className="h-3.5 w-3.5" />}>Visita verificata</Badge>}
                    <Badge tone={st.tone}>{st.label}</Badge>
                    {v.is_edited && <span className="text-xs text-ink-faint">Modificata</span>}
                    <span className="ml-auto text-xs text-ink-muted">{v.published_at ? formatDate(v.published_at) : ''}</span>
                  </div>
                  {v.title && <p className="mt-2 font-semibold">{v.title}</p>}
                  <p className="mt-1 whitespace-pre-line text-sm text-ink-soft">{v.content}</p>
                  {v.response && (
                    <div className="mt-3 rounded-2xl bg-cream p-3 text-sm">
                      <p className="text-xs font-bold uppercase tracking-wide text-ink-muted">La tua risposta</p>
                      <p className="mt-1 whitespace-pre-line">{v.response.content}</p>
                    </div>
                  )}
                  <div className="mt-3 flex flex-wrap gap-2">
                    {v.status === 'published' && (
                      <Button size="sm" variant="outline" onClick={() => setReply(v)}>
                        <MessageSquareReply className="h-4 w-4" /> {v.response ? 'Modifica risposta' : 'Rispondi'}
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" disabled={v.my_report} onClick={() => setReport(v)}>
                      <Flag className="h-4 w-4" /> {v.my_report ? 'Segnalata' : 'Segnala'}
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
        {(page > 0 || items.length === PAGE) && (
          <div className="mt-4 flex justify-between">
            <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Precedenti</Button>
            <Button size="sm" variant="outline" disabled={items.length < PAGE} onClick={() => setPage((p) => p + 1)}>Successive</Button>
          </div>
        )}
      </Panel>
      <ReplySheet review={reply} onClose={() => setReply(null)} onDone={() => { setReply(null); data.reload(); }} />
      <ReportSheet review={report} onClose={() => setReport(null)} onDone={() => { setReport(null); data.reload(); }} />
    </div>
  );
}

function ReplySheet({ review, onClose, onDone }: { review: ManagedReview | null; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => setText(review?.response?.content ?? ''), [review]);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!review) return;
    setBusy(true);
    try {
      await api.respondToReview(review.id, text.trim());
      toast('Risposta pubblicata');
      onDone();
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet open={!!review} onClose={onClose} title="Risposta ufficiale">
      <form onSubmit={submit} className="space-y-4">
        {review && <p className="rounded-2xl bg-cream p-3 text-sm text-ink-soft">“{review.content.slice(0, 240)}{review.content.length > 240 ? '…' : ''}”</p>}
        <Field label="La tua risposta" hint="Visibile a tutti sotto la recensione. Mantieni un tono cortese: niente dati personali del cliente.">
          <Textarea required minLength={5} maxLength={1500} rows={5} value={text} onChange={(e) => setText(e.target.value)} />
        </Field>
        <Button type="submit" loading={busy} className="w-full"><Send className="h-4 w-4" /> Pubblica risposta</Button>
      </form>
    </Sheet>
  );
}

function ReportSheet({ review, onClose, onDone }: { review: ManagedReview | null; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [reason, setReason] = useState<ReviewReportReason>('spam');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!review) return;
    setBusy(true);
    try {
      await api.reportReview(review.id, reason, details.trim() || null);
      toast('Segnalazione inviata allo staff');
      setDetails('');
      onDone();
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet open={!!review} onClose={onClose} title="Segnala recensione">
      <form onSubmit={submit} className="space-y-4">
        <Field label="Motivo">
          <Select value={reason} onChange={(e) => setReason(e.target.value as ReviewReportReason)}>
            {REVIEW_REPORT_REASONS.map((x) => <option key={x.value} value={x.value}>{x.label}</option>)}
          </Select>
        </Field>
        <Field label="Dettagli (facoltativo)">
          <Textarea maxLength={500} rows={3} value={details} onChange={(e) => setDetails(e.target.value)} />
        </Field>
        <p className="text-xs text-ink-muted">Una segnalazione non rimuove automaticamente la recensione: la valuta lo staff.</p>
        <Button type="submit" loading={busy} className="w-full">Invia segnalazione</Button>
      </form>
    </Sheet>
  );
}

// ─── Campagne (ristoratore) ──────────────────────────────────
const STATUS_LABEL: Record<string, { label: string; tone: 'neutral' | 'green' | 'amber' | 'coral' | 'dark' }> = {
  draft: { label: 'Bozza', tone: 'neutral' },
  scheduled: { label: 'Programmata', tone: 'amber' },
  sending: { label: 'In invio', tone: 'amber' },
  sent: { label: 'Inviata', tone: 'green' },
  cancelled: { label: 'Annullata', tone: 'dark' },
  failed: { label: 'Non inviata', tone: 'coral' },
};

export function campaignStatus(s: string) {
  const x = STATUS_LABEL[s] ?? STATUS_LABEL.draft!;
  return <Badge tone={x.tone}>{x.label}</Badge>;
}

/** Campagne verso chi segue il locale: solo numeri aggregati, mai email, telefoni o endpoint push. */
export function OwnerCampaignsSection({ r }: EditorTabProps) {
  const ent = useEntitlements(r.subscription_plan);
  const list = useAsync(() => api.listCampaigns({ scope: 'restaurant', restaurantId: r.id }), [r.id]);
  const limit = ent.limit('monthly_campaign_limit');
  const monthStart = useMemo(() => { const d = new Date(); d.setDate(1); d.setHours(0, 0, 0, 0); return d.getTime(); }, []);
  const used = (list.data ?? []).filter((c) => ['scheduled', 'sending', 'sent'].includes(c.status) && new Date(c.created_at).getTime() >= monthStart).length;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        <StatTile accent label="Campagne questo mese" value={limit == null ? used : `${used}/${limit}`} hint={limit == null ? 'Nessun limite nel piano' : 'Limite del piano'} />
        <StatTile label="Destinatari totali" value={(list.data ?? []).reduce((a, c) => a + c.recipients_count, 0)} hint="Solo utenti con consenso" />
        <StatTile label="Frequenza massima" value="1/giorno" hint="Per proteggere i clienti" />
      </div>
      <CampaignForm r={r} disabled={limit != null && used >= limit} onCreated={list.reload} />
      <Panel title="Le tue campagne">
        <CampaignList items={list.data} loading={list.loading} onChange={list.reload} />
      </Panel>
      <BusinessReferralPanel restaurantId={r.id} />
    </div>
  );
}

function CampaignForm({ r, disabled, onCreated }: { r: EditorTabProps['r']; disabled: boolean; onCreated: () => void }) {
  const toast = useToast();
  const { handleError } = useUpgrade();
  const [f, setF] = useState({ title: '', message: '', action_url: `/ristorante/${r.slug}`, target: 'followers' as CampaignTarget, push: true, send_at: '' });
  const [audience, setAudience] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    setAudience(null);
    api.campaignAudienceCount('restaurant', r.id, f.target).then((n) => alive && setAudience(n), () => alive && setAudience(0));
    return () => { alive = false; };
  }, [r.id, f.target]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const channels: CampaignChannel[] = f.push ? ['in_app', 'push'] : ['in_app'];
      const res = await api.createCampaign({
        scope: 'restaurant', restaurant_id: r.id, title: f.title.trim(), message: f.message.trim(),
        action_url: f.action_url.trim() || null, target: f.target, channels,
        send_at: f.send_at ? new Date(f.send_at).toISOString() : null,
      });
      toast(`Campagna programmata · ${res.audience} destinatari`);
      setF((x) => ({ ...x, title: '', message: '', send_at: '' }));
      onCreated();
    } catch (err) {
      handleError(err, r.id, r.subscription_plan);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Panel title="Nuova campagna" description="Notifica in-app (e push per chi l’ha attivata) alle persone che hanno scelto di ricevere le tue novità.">
      <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2" data-testid="campaign-form">
        <Field label="Titolo" className="sm:col-span-2">
          <Input required minLength={3} maxLength={60} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="Es. Nuovo menu degustazione" />
        </Field>
        <Field label="Messaggio" hint={`${f.message.length}/180`} className="sm:col-span-2">
          <Textarea required minLength={5} maxLength={180} rows={3} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} />
        </Field>
        <Field label="Destinatari" hint={RESTAURANT_TARGETS.find((t) => t.value === f.target)?.hint}>
          <Select value={f.target} onChange={(e) => setF({ ...f, target: e.target.value as CampaignTarget })}>
            {RESTAURANT_TARGETS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
          </Select>
        </Field>
        <Field label="Invio" hint="Vuoto = appena possibile (entro 15 minuti)">
          <Input type="datetime-local" value={f.send_at} onChange={(e) => setF({ ...f, send_at: e.target.value })} />
        </Field>
        <Field label="Link (percorso interno)" className="sm:col-span-2">
          <Input value={f.action_url} pattern="/[A-Za-z0-9_#?=&.\/\-]*" onChange={(e) => setF({ ...f, action_url: e.target.value })} />
        </Field>
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" checked={f.push} onChange={(e) => setF({ ...f, push: e.target.checked })} className="h-4 w-4 accent-coral" />
          Invia anche come notifica push a chi l’ha attivata
        </label>
        <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
          <p className="flex items-center gap-1.5 text-sm" data-testid="campaign-audience">
            <Users className="h-4 w-4 text-coral" /> Destinatari stimati: <strong className="tabular-nums">{audience ?? '…'}</strong>
          </p>
          <Button type="submit" loading={busy} disabled={disabled || audience === 0} className="ml-auto"><Megaphone className="h-4 w-4" /> Programma campagna</Button>
        </div>
        {disabled && <p className="text-sm text-coral-700 sm:col-span-2">Hai raggiunto il limite mensile di campagne del tuo piano.</p>}
        {audience === 0 && <p className="text-sm text-ink-muted sm:col-span-2">Nessun destinatario idoneo per ora: le persone devono seguire il locale o aver acconsentito alle comunicazioni.</p>}
      </form>
    </Panel>
  );
}

export function CampaignList({ items, loading, onChange }: { items: Campaign[] | null | undefined; loading: boolean; onChange: () => void }) {
  const toast = useToast();
  const [open, setOpen] = useState<string | null>(null);
  if (loading && !items) return <div className="flex justify-center py-6"><Spinner /></div>;
  if (!items?.length) return <p className="text-sm text-ink-muted">Nessuna campagna ancora.</p>;
  const cancel = async (id: string) => {
    try {
      await api.cancelCampaign(id);
      toast('Campagna annullata');
      onChange();
    } catch (err) {
      toast((err as Error).message, 'error');
    }
  };
  return (
    <ul className="divide-y divide-line" data-testid="campaign-list">
      {items.map((c) => (
        <li key={c.id} className="py-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold">{c.title}</span>
            {campaignStatus(c.status)}
            <span className="text-xs text-ink-muted">{formatDate(c.send_at)} · {c.channels.join(' + ')}</span>
            <span className="ml-auto flex gap-2">
              {['draft', 'scheduled'].includes(c.status) && <Button size="sm" variant="ghost" onClick={() => void cancel(c.id)}>Annulla</Button>}
              {['sent', 'sending'].includes(c.status) && <Button size="sm" variant="outline" onClick={() => setOpen(open === c.id ? null : c.id)}>{open === c.id ? 'Chiudi' : 'Risultati'}</Button>}
            </span>
          </div>
          <p className="mt-1 text-sm text-ink-soft">{c.message}</p>
          {c.error && <p className="mt-1 text-xs text-coral-700">{c.error}</p>}
          {open === c.id && <CampaignStatsView id={c.id} />}
        </li>
      ))}
    </ul>
  );
}

function CampaignStatsView({ id }: { id: string }) {
  const s = useAsync<PushCampaignStats>(() => api.getPushCampaignStats(id), [id]);
  if (!s.data) return <div className="py-3"><Spinner /></div>;
  const d = s.data;
  const rows: [string, number | string, string][] = [
    ['Destinatari', d.recipients, 'Utenti idonei al momento dell’invio'],
    ['Inviate', d.sent, 'Notifiche consegnate al canale (in-app o servizio push)'],
    ['Aperte', d.opened, 'Notifiche in-app lette'],
    ['Clic', d.clicked, 'Aperture del link della campagna'],
    ['CTR', `${Math.round(d.ctr * 1000) / 10}%`, 'Clic su inviate'],
    ['Saltate', d.skipped, 'Limite di frequenza o preferenze'],
    ['Errori', d.failed, 'Invii non riusciti'],
  ];
  return (
    <dl className="mt-3 grid grid-cols-2 gap-2 rounded-2xl bg-cream p-3 text-sm sm:grid-cols-4" data-testid="campaign-stats">
      {rows.map(([k, v, t]) => (
        <div key={k} title={t}>
          <dt className="text-ink-muted">{k}</dt>
          <dd className="font-semibold tabular-nums">{v}</dd>
        </div>
      ))}
      <p className="col-span-full text-xs text-ink-faint">“Consegnate” non viene stimato: il browser non conferma la ricezione delle push.</p>
    </dl>
  );
}

function BusinessReferralPanel({ restaurantId }: { restaurantId: string }) {
  const toast = useToast();
  const list = useAsync(() => api.listBusinessReferrals(restaurantId), [restaurantId]);
  const [f, setF] = useState({ email: '', name: '' });
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.createBusinessReferral(restaurantId, f.email.trim(), f.name.trim() || null);
      toast('Invito registrato');
      setF({ email: '', name: '' });
      list.reload();
    } catch (err) {
      toast((err as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };
  const LABEL: Record<string, string> = { invited: 'Invitato', registered: 'Registrato', qualified: 'Idoneo', approved: 'Approvato', rewarded: 'Premiato', rejected: 'Non valido' };
  return (
    <Panel title="Invita un ristorante" description="Consiglia AsiaFood a un collega. L’eventuale premio viene valutato e approvato dallo staff dopo l’attivazione del nuovo locale: nessun accredito automatico.">
      <form onSubmit={submit} className="grid gap-3 sm:grid-cols-[1fr_1fr_auto]">
        <Input type="email" required placeholder="Email del ristorante" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} aria-label="Email del ristorante" />
        <Input placeholder="Nome del locale (facoltativo)" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="Nome del locale" />
        <Button type="submit" loading={busy}><UserPlus className="h-4 w-4" /> Invita</Button>
      </form>
      {(list.data?.length ?? 0) > 0 && (
        <ul className="mt-4 divide-y divide-line text-sm">
          {list.data!.map((b) => (
            <li key={b.id} className="flex flex-wrap items-center gap-2 py-2">
              <span className="font-medium">{b.referred_business_name || b.referred_business_email}</span>
              <Badge>{LABEL[b.status] ?? b.status}</Badge>
              <span className="ml-auto text-xs text-ink-muted">{formatDate(b.created_at)}</span>
            </li>
          ))}
        </ul>
      )}
    </Panel>
  );
}

// QR: vedi LaunchSections.tsx (Fase 12 · Kit QR con PNG/SVG/PDF e tracciamento scansioni)

// ─── Statistiche fidelizzazione (senza dati personali) ───────
export function EngagementStatsPanel({ restaurantId, days }: { restaurantId: string; days: number }) {
  const s = useAsync(() => api.getRestaurantEngagementStats(restaurantId, days).catch(() => null), [restaurantId, days]);
  const d = s.data;
  if (!d) return null;
  return (
    <Panel title="Fidelizzazione" description={`Ultimi ${days} giorni. Solo numeri aggregati: nessun dato personale dei clienti.`}>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4" data-testid="engagement-stats">
        <Mini label="Valutazione" value={d.rating.average != null ? formatRating(d.rating.average) : '—'} hint={d.rating.count ? `${d.rating.count} recensioni · ${d.rating.verified_count} verificate` : 'Ancora nessuna recensione'} />
        <Mini label="Follower" value={d.followers} hint={`${d.favorites} nei preferiti`} />
        <Mini label="Clienti che tornano" value={d.returning_customers} hint={`su ${d.customers} clienti con visita completata`} />
        <Mini label="Coupon utilizzati" value={d.coupon_redemptions} />
        <Mini label="Notifiche campagne inviate" value={d.campaign_sends} />
        <Mini label="Clic dalle campagne" value={d.campaign_clicks} />
      </div>
    </Panel>
  );
}

function Mini({ label, value, hint }: { label: string; value: number | string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-line p-3">
      <p className="text-xs text-ink-muted">{label}</p>
      <p className="font-display text-2xl font-extrabold tabular-nums">{value}</p>
      {hint && <p className="text-[11px] text-ink-faint">{hint}</p>}
    </div>
  );
}

