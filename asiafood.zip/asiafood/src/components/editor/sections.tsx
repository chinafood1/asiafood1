// Sezioni dell'editor condivise tra Admin e ristoratore.
import { useState } from 'react';
import { AlertTriangle, Info } from 'lucide-react';
import { APP } from '@/config/app';
import { useAuth } from '@/context/AuthContext';
import { useReferenceData } from '@/context/ReferenceDataContext';
import { useAsync } from '@/hooks/useAsync';
import { cn, formatDate, SERVICE_LABELS } from '@/lib/format';
import { MEMBER_ROLE } from '@/lib/labels';
import { api } from '@/services';
import type { Restaurant } from '@/types/domain';
import { Badge, Chip } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { Alert } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';
import { HoursEditor } from './HoursEditor';
import { LocationSection } from './LocationEditor';
import { MediaEditor } from './MediaEditor';
import { MenuEditor } from './MenuEditor';
import { num, Panel, str, useRestaurantForm, type EditorTabProps } from './form';

const SaveButton = ({ saving, onClick, dirty = true }: { saving: boolean; onClick: () => void; dirty?: boolean }) => (
  <Button loading={saving} disabled={!dirty} onClick={onClick}>Salva</Button>
);

// ─── Informazioni principali ───────────────────────────────────
export function InfoSection({ r, reload }: EditorTabProps) {
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['name', 'short_description', 'description']);
  return (
    <Panel title="Informazioni principali" footer={<SaveButton saving={saving} dirty={dirty} onClick={() => save(undefined, reload)} />}>
      <div className="grid gap-4">
        <Field label="Nome attività"><Input value={form.name} maxLength={120} onChange={(e) => set('name', e.target.value)} /></Field>
        <Field label="Descrizione breve" hint="Appare nelle card e nei risultati (max 160 caratteri).">
          <Input maxLength={160} value={form.short_description ?? ''} onChange={(e) => set('short_description', str(e.target.value))} />
        </Field>
        <Field label="Descrizione" hint="Scrivi un testo originale basato su fatti: non copiare descrizioni da Google o da altri siti.">
          <Textarea rows={6} maxLength={3000} value={form.description ?? ''} onChange={(e) => set('description', str(e.target.value))} />
        </Field>
      </div>
    </Panel>
  );
}

// ─── Localizzazione ────────────────────────────────────────────
export { LocationSection };

// ─── Contatti ──────────────────────────────────────────────────
export function ContactsSection({ r, reload }: EditorTabProps) {
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['phone', 'whatsapp', 'email', 'website']);
  return (
    <Panel title="Contatti" footer={<SaveButton saving={saving} dirty={dirty} onClick={() => save(undefined, reload)} />}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Telefono"><Input type="tel" value={form.phone ?? ''} onChange={(e) => set('phone', str(e.target.value))} placeholder="+39 099 …" /></Field>
        <Field label="WhatsApp" hint="Con prefisso internazionale, es. 393331234567"><Input inputMode="tel" value={form.whatsapp ?? ''} onChange={(e) => set('whatsapp', str(e.target.value?.replace(/[^\d]/g, '')))} /></Field>
        <Field label="Email"><Input type="email" value={form.email ?? ''} onChange={(e) => set('email', str(e.target.value))} /></Field>
        <Field label="Sito web"><Input type="url" placeholder="https://" value={form.website ?? ''} onChange={(e) => set('website', str(e.target.value))} /></Field>
      </div>
    </Panel>
  );
}

// ─── Social ────────────────────────────────────────────────────
export function SocialSection({ r, reload }: EditorTabProps) {
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['instagram', 'facebook', 'tiktok']);
  return (
    <Panel title="Social" footer={<SaveButton saving={saving} dirty={dirty} onClick={() => save(undefined, reload)} />}>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Instagram" hint="@profilo o URL"><Input value={form.instagram ?? ''} onChange={(e) => set('instagram', str(e.target.value))} /></Field>
        <Field label="Facebook" hint="Nome pagina o URL"><Input value={form.facebook ?? ''} onChange={(e) => set('facebook', str(e.target.value))} /></Field>
        <Field label="TikTok"><Input value={form.tiktok ?? ''} onChange={(e) => set('tiktok', str(e.target.value))} /></Field>
      </div>
    </Panel>
  );
}

// ─── Categorie ─────────────────────────────────────────────────
export function CategoriesSection({ r, reload }: EditorTabProps) {
  const { categories } = useReferenceData();
  const toast = useToast();
  const [cats, setCats] = useState<string[]>(r.categories.map((c) => c.id));
  const [primary, setPrimary] = useState<string | null>(r.categories[0]?.id ?? null);
  const [saving, setSaving] = useState(false);
  const toggle = (id: string) =>
    setCats((cs) => {
      const next = cs.includes(id) ? cs.filter((x) => x !== id) : [...cs, id];
      if (!next.includes(primary ?? '')) setPrimary(next[0] ?? null);
      return next;
    });
  const save = async () => {
    setSaving(true);
    try {
      await api.setRestaurantCategories(r.id, cats, primary);
      const ayce = categories.find((c) => c.slug === 'all-you-can-eat');
      if (ayce && cats.includes(ayce.id) && !r.is_all_you_can_eat) await api.updateRestaurant(r.id, { is_all_you_can_eat: true });
      toast('Categorie salvate');
      reload();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setSaving(false);
    }
  };
  return (
    <Panel title="Categorie" description="Un locale può avere più categorie (es. Sushi + Giapponese + All You Can Eat)." footer={<Button loading={saving} onClick={save}>Salva</Button>}>
      <div className="flex flex-wrap gap-2">
        {categories.map((c) => (
          <Chip key={c.id} active={cats.includes(c.id)} onClick={() => toggle(c.id)}>{c.emoji} {c.name}</Chip>
        ))}
      </div>
      {cats.length > 1 && (
        <Field label="Categoria principale" className="mt-5 max-w-xs">
          <Select value={primary ?? ''} onChange={(e) => setPrimary(e.target.value)}>
            {cats.map((id) => <option key={id} value={id}>{categories.find((c) => c.id === id)?.name}</option>)}
          </Select>
        </Field>
      )}
    </Panel>
  );
}

// ─── Servizi ───────────────────────────────────────────────────
export function ServicesSection({ r, reload }: EditorTabProps) {
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['has_takeaway', 'has_delivery', 'has_reservation', 'reservation_url', 'services']);
  const toggleService = (s: string) => set('services', form.services.includes(s) ? form.services.filter((x) => x !== s) : [...form.services, s]);
  return (
    <Panel title="Servizi" footer={<SaveButton saving={saving} dirty={dirty} onClick={() => save(undefined, reload)} />}>
      <div className="grid gap-8 lg:grid-cols-2">
        <div>
          <div className="divide-y divide-line">
            <Toggle label="Asporto" checked={form.has_takeaway} onChange={(v) => set('has_takeaway', v)} />
            <Toggle label="Delivery" description="Consegna gestita dal locale o da piattaforme esterne" checked={form.has_delivery} onChange={(v) => set('has_delivery', v)} />
            <Toggle label="Prenotazione tavolo" checked={form.has_reservation} onChange={(v) => set('has_reservation', v)} />
          </div>
          {form.has_reservation && (
            <Field label="Link prenotazione (facoltativo)" hint="Se vuoto, “Prenota” apre WhatsApp o il telefono." className="mt-3">
              <Input type="url" value={form.reservation_url ?? ''} onChange={(e) => set('reservation_url', str(e.target.value))} />
            </Field>
          )}
        </div>
        <div>
          <span className="label">Altri servizi</span>
          <div className="flex flex-wrap gap-2">
            {Object.entries(SERVICE_LABELS).map(([k, label]) => (
              <Chip key={k} active={form.services.includes(k)} onClick={() => toggleService(k)} className="!h-9 !text-[13px]">{label}</Chip>
            ))}
          </div>
        </div>
      </div>
    </Panel>
  );
}

// ─── Prezzi ────────────────────────────────────────────────────
export function PricesSection({ r, reload }: EditorTabProps) {
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['price_range', 'average_price']);
  return (
    <Panel title="Prezzi" footer={<SaveButton saving={saving} dirty={dirty} onClick={() => save(undefined, reload)} />}>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <span className="label">Fascia di prezzo</span>
          <div className="grid grid-cols-5 gap-2">
            {[null, 1, 2, 3, 4].map((p) => (
              <button key={p ?? 0} type="button" onClick={() => set('price_range', p as Restaurant['price_range'])}
                className={cn('h-11 rounded-2xl border text-sm font-bold', form.price_range === p ? 'border-ink bg-ink text-white' : 'border-line bg-white')}>
                {p ? '€'.repeat(p) : '—'}
              </button>
            ))}
          </div>
        </div>
        <Field label="Prezzo medio a persona (€)" hint="Lascia vuoto se non verificato."><Input type="number" min={0} step="0.5" value={form.average_price ?? ''} onChange={(e) => set('average_price', num(e.target.value))} /></Field>
      </div>
    </Panel>
  );
}

// ─── All You Can Eat ───────────────────────────────────────────
export function AyceSection({ r, reload }: EditorTabProps) {
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['is_all_you_can_eat', 'ayce_lunch_price', 'ayce_dinner_price', 'ayce_weekend_price']);
  return (
    <Panel title="All You Can Eat" footer={<SaveButton saving={saving} dirty={dirty} onClick={() => save(undefined, reload)} />}>
      <Toggle label="Formula All You Can Eat" description="Prezzo fisso a persona" checked={form.is_all_you_can_eat} onChange={(v) => set('is_all_you_can_eat', v)} />
      {form.is_all_you_can_eat && (
        <div className="mt-4 grid grid-cols-3 gap-3">
          <Field label="Pranzo €"><Input type="number" min={0} step="0.1" value={form.ayce_lunch_price ?? ''} onChange={(e) => set('ayce_lunch_price', num(e.target.value))} /></Field>
          <Field label="Cena €"><Input type="number" min={0} step="0.1" value={form.ayce_dinner_price ?? ''} onChange={(e) => set('ayce_dinner_price', num(e.target.value))} /></Field>
          <Field label="Weekend €"><Input type="number" min={0} step="0.1" value={form.ayce_weekend_price ?? ''} onChange={(e) => set('ayce_weekend_price', num(e.target.value))} /></Field>
        </div>
      )}
      <p className="mt-3 text-xs text-ink-muted">Inserisci solo prezzi confermati: i campi vuoti non vengono mostrati.</p>
    </Panel>
  );
}

// ─── SEO ───────────────────────────────────────────────────────
export function SeoSection({ r, reload }: EditorTabProps) {
  const { isAdmin } = useAuth();
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['meta_title', 'meta_description', 'slug']);
  return (
    <Panel title="SEO" description="Se vuoti, titolo e descrizione vengono generati automaticamente da nome, cucina e comune." footer={<SaveButton saving={saving} dirty={dirty} onClick={() => save(undefined, reload)} />}>
      <div className="grid gap-4">
        {isAdmin && (
          <Field label="Slug URL" hint="Cambiarlo modifica l’URL indicizzato: fallo solo se necessario.">
            <Input value={form.slug} onChange={(e) => set('slug', e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-'))} />
          </Field>
        )}
        <Field label="Meta title" hint={`${(form.meta_title ?? '').length}/70`}><Input maxLength={70} value={form.meta_title ?? ''} onChange={(e) => set('meta_title', str(e.target.value))} /></Field>
        <Field label="Meta description" hint={`${(form.meta_description ?? '').length}/170`}><Textarea rows={3} maxLength={170} value={form.meta_description ?? ''} onChange={(e) => set('meta_description', str(e.target.value))} /></Field>
      </div>
    </Panel>
  );
}

// ─── Menu, orari, immagini (con conferma di aggiornamento) ─────
function VerifiedStamp({ r, reload, field, label }: EditorTabProps & { field: 'menu_last_verified_at' | 'opening_hours_last_verified_at'; label: string }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-line bg-white px-5 py-3 text-sm">
      <span className="text-ink-muted">{r[field] ? `${label} confermati il ${formatDate(r[field])}` : `${label} non ancora confermati`}</span>
      <Button size="sm" variant="soft" loading={busy} onClick={async () => {
        setBusy(true);
        try {
          await api.updateRestaurant(r.id, { [field]: new Date().toISOString() });
          toast('Grazie: dati confermati');
          reload();
        } catch (e) {
          toast((e as Error).message, 'error');
        } finally {
          setBusy(false);
        }
      }}>Confermo che sono aggiornati</Button>
    </div>
  );
}

export function MenuSection(p: EditorTabProps) {
  return (
    <div className="space-y-4">
      <VerifiedStamp {...p} field="menu_last_verified_at" label="Menu e prezzi" />
      <MenuEditor {...p} />
    </div>
  );
}

export function HoursSection(p: EditorTabProps) {
  return (
    <div className="space-y-4">
      {p.r.hours.length === 0 && <Alert>Nessun orario inserito: il locale non comparirà nel filtro “Aperto ora”.</Alert>}
      <VerifiedStamp {...p} field="opening_hours_last_verified_at" label="Orari" />
      <HoursEditor {...p} />
    </div>
  );
}

export function ImagesSection(p: EditorTabProps) {
  return (
    <div className="space-y-4">
      <div className="flex gap-3 rounded-3xl bg-cream p-4 text-sm text-ink-soft">
        <Info className="h-5 w-5 shrink-0 text-coral" />
        Carica solo foto di cui possiedi i diritti (scattate da te o con licenza). Non copiare immagini da Google, TripAdvisor o social di terzi.
      </div>
      <MediaEditor {...p} />
    </div>
  );
}

// ─── Ristoratore: profilo attività (tutto in una pagina) ──────
export function OwnerProfileSection(p: EditorTabProps) {
  return (
    <div className="space-y-6">
      <InfoSection {...p} />
      <CategoriesSection {...p} />
      <LocationSection {...p} />
      <ContactsSection {...p} />
      <SocialSection {...p} />
      <ServicesSection {...p} />
      <PricesSection {...p} />
      <AyceSection {...p} />
    </div>
  );
}

// ─── Ristoratore: impostazioni ─────────────────────────────────
export function SettingsSection({ r, reload }: EditorTabProps) {
  const { form, set, save, saving, dirty } = useRestaurantForm(r, ['is_temporarily_closed']);
  const members = useAsync(() => api.listMembers(r.id), [r.id]);
  return (
    <div className="space-y-6">
      <Panel title="Disponibilità" footer={<SaveButton saving={saving} dirty={dirty} onClick={() => save(undefined, reload)} />}>
        <Toggle
          label="Chiuso temporaneamente"
          description="Ferie, lavori o chiusura straordinaria: la scheda resta visibile con un avviso e non compare in “Aperto ora”."
          checked={form.is_temporarily_closed}
          onChange={(v) => set('is_temporarily_closed', v)}
        />
        {r.is_permanently_closed && (
          <p className="mt-3 flex items-center gap-2 text-sm text-coral-700"><AlertTriangle className="h-4 w-4" /> Lo staff ha segnato l’attività come chiusa definitivamente. Se non è corretto, contattaci.</p>
        )}
      </Panel>
      <Panel title="Chi gestisce la scheda" description="Per aggiungere collaboratori o trasferire la proprietà contatta lo staff.">
        <ul className="divide-y divide-line">
          {(members.data ?? []).filter((m) => m.status === 'active').map((m) => (
            <li key={m.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
              <span>{m.profile?.full_name || m.profile?.email || 'Utente'}</span>
              <Badge>{MEMBER_ROLE[m.role]}</Badge>
            </li>
          ))}
        </ul>
        <a href={`mailto:${APP.supportEmail}?subject=${encodeURIComponent(`Gestione team — ${r.name}`)}`} className="mt-4 inline-flex text-sm font-semibold text-coral-700 hover:underline">Contatta lo staff</a>
      </Panel>
    </div>
  );
}

