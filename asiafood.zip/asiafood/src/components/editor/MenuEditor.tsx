import { useRef, useState } from 'react';
import {
  ArrowDown, ArrowUp, ChevronDown, Copy, Download, Eye, EyeOff, FileUp, ImagePlus, Pencil, Plus, Trash2, X,
} from 'lucide-react';
import { useUpgrade, useEntitlements } from '@/context/UpgradeContext';
import { api } from '@/services';
import type { MenuImportRow } from '@/services/types';
import { cn, formatPrice } from '@/lib/format';
import { ALLERGENS, isMenuPublicToday, MENU_TYPE_LABELS } from '@/lib/menu';
import { MENU_CSV_TEMPLATE, parseMenuFile, type MenuImportPreview } from '@/lib/import/menuImport';
import type { Menu, MenuCategory, MenuItemFull, MenuType, MenuWithSections } from '@/types/domain';
import { Button } from '@/components/ui/Button';
import { Chip } from '@/components/ui/Badge';
import { Field, Input, Select, Textarea, Toggle } from '@/components/ui/Field';
import { EmptyState } from '@/components/ui/Layout';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/components/ui/Toast';
import type { EditorTabProps } from './form';

type Opt = { name: string; price: number | null };
type ItemDraft = Partial<MenuItemFull> & { variantsDraft?: Opt[]; addonsDraft?: Opt[] };
type Editing =
  | { kind: 'menu'; data: Partial<Menu> }
  | { kind: 'section'; data: Partial<MenuCategory> }
  | { kind: 'item'; data: ItemDraft }
  | null;

const numOrNull = (v: string) => (v === '' ? null : Math.max(0, Number(v.replace(',', '.'))));

/** Gestione menu → categorie → piatti, pensata anche per lo smartphone. */
export function MenuEditor({ r, reload }: EditorTabProps) {
  const toast = useToast();
  const { handleError: onError, openUpgrade } = useUpgrade();
  const handleError = (e: unknown) => onError(e, r.id, r.subscription_plan);
  const ent = useEntitlements(r.subscription_plan);
  const limitReached = () => openUpgrade('max_menu_items', { restaurantId: r.id, kind: 'limit', plan: r.subscription_plan });
  const [editing, setEditing] = useState<Editing>(null);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState<string | null>(r.menus[0]?.id ?? null);
  const [importing, setImporting] = useState(false);
  const itemsCount = r.menus.reduce((a, m) => a + m.sections.reduce((b, s) => b + s.items.length, 0), 0);
  const itemLimit = ent.limit('max_menu_items');

  const run = async (fn: () => Promise<unknown>, msg: string, close = true) => {
    setSaving(true);
    try {
      await fn();
      toast(msg);
      if (close) setEditing(null);
      reload();
    } catch (e) {
      handleError(e);
    } finally {
      setSaving(false);
    }
  };

  const remove = (table: 'menus' | 'menu_categories' | 'menu_items', id: string, label: string) => {
    if (!confirm(`Eliminare ${label}? L'operazione non si può annullare.`)) return;
    void run(() => api.remove(table, id), 'Eliminato', false);
  };

  const move = <T extends { id: string }>(table: 'menus' | 'menu_categories' | 'menu_items', list: T[], index: number, dir: -1 | 1) => {
    const j = index + dir;
    if (j < 0 || j >= list.length) return;
    const ids = list.map((x) => x.id);
    [ids[index], ids[j]] = [ids[j]!, ids[index]!];
    void run(() => api.reorderMenuRows(table, ids), 'Ordine aggiornato', false);
  };

  const newItem = (s: MenuCategory & { items: MenuItemFull[] }) => {
    if (!ent.within('max_menu_items', itemsCount)) return limitReached();
    setEditing({
      kind: 'item',
      data: {
        menu_category_id: s.id, name: '', price: null, allergens: [], ingredients: [], is_available: true, is_ayce_included: false,
        sort_order: s.items.length, variantsDraft: [], addonsDraft: [],
      },
    });
  };

  const saveEditing = async () => {
    if (!editing) return;
    const d = { ...editing.data } as Record<string, unknown>;
    if (!String(d.name ?? '').trim()) return toast('Il nome è obbligatorio', 'error');
    if (editing.kind === 'menu' && d.valid_from && d.valid_until && String(d.valid_until) < String(d.valid_from)) return toast('La data di fine precede quella di inizio', 'error');
    const variants = (d.variantsDraft as Opt[] | undefined) ?? [];
    const addons = (d.addonsDraft as Opt[] | undefined) ?? [];
    ['sections', 'items', 'variants', 'addons', 'variantsDraft', 'addonsDraft'].forEach((k) => delete d[k]);
    const table = editing.kind === 'menu' ? 'menus' : editing.kind === 'section' ? 'menu_categories' : 'menu_items';
    await run(async () => {
      const saved = await api.upsert<{ id: string }>(table, { ...d, restaurant_id: r.id });
      if (editing.kind === 'item') await api.replaceItemOptions(saved.id, variants, addons);
    }, 'Salvato');
  };

  const quick = (table: 'menus' | 'menu_categories' | 'menu_items', row: { id: string }, patch: Record<string, unknown>, msg: string) =>
    run(() => api.upsert(table, { id: row.id, ...patch, restaurant_id: r.id }), msg, false);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-ink-muted">
          {itemsCount} {itemsCount === 1 ? 'piatto' : 'piatti'}
          {itemLimit !== null && !ent.bypass && <> su {itemLimit} disponibili nel piano</>}
        </p>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" icon={<FileUp className="h-4 w-4" />} onClick={() => setImporting(true)}>
            Importa CSV/JSON
          </Button>
          <Button icon={<Plus className="h-4 w-4" />} onClick={() => setEditing({ kind: 'menu', data: { name: '', menu_type: 'a_la_carte', is_active: true, is_public: true, sort_order: r.menus.length } })}>
            Nuovo menu
          </Button>
        </div>
      </div>

      {r.menus.length === 0 && <EmptyState icon="📋" title="Nessun menu" text="Crea il primo menu (principale, pranzo, All You Can Eat…) oppure importalo da un file CSV o JSON." />}

      {r.menus.map((m, mi) => {
        const live = isMenuPublicToday(m);
        return (
          <section key={m.id} className="card overflow-hidden">
            <header className="flex flex-wrap items-center gap-2 p-4 sm:p-5">
              <button onClick={() => setOpen(open === m.id ? null : m.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left" aria-expanded={open === m.id}>
                <ChevronDown className={cn('h-5 w-5 shrink-0 transition', open === m.id && 'rotate-180')} />
                <div className="min-w-0">
                  <p className="font-bold">
                    {m.name}{' '}
                    {!live && <span className="ml-1 rounded-full bg-cream px-2 py-0.5 text-xs font-semibold text-ink-muted">{!m.is_public || !m.is_active ? 'Nascosto' : 'Fuori periodo'}</span>}
                  </p>
                  <p className="text-xs text-ink-muted">
                    {MENU_TYPE_LABELS[m.menu_type]} · {m.sections.length} categorie · {m.sections.reduce((a, s) => a + s.items.length, 0)} piatti
                    {m.price != null && ` · ${formatPrice(m.price)}`}
                    {(m.valid_from || m.valid_until) && ` · ${m.valid_from ?? '…'} → ${m.valid_until ?? '…'}`}
                  </p>
                </div>
              </button>
              <div className="flex items-center">
                <IconAction label="Sposta su" onClick={() => move('menus', r.menus, mi, -1)} icon={<ArrowUp className="h-4 w-4" />} disabled={mi === 0} />
                <IconAction label="Sposta giù" onClick={() => move('menus', r.menus, mi, 1)} icon={<ArrowDown className="h-4 w-4" />} disabled={mi === r.menus.length - 1} />
                <IconAction label={m.is_public ? 'Nascondi menu' : 'Mostra menu'} onClick={() => quick('menus', m, { is_public: !m.is_public }, m.is_public ? 'Menu nascosto' : 'Menu visibile')} icon={m.is_public ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />} />
                <IconAction label="Duplica menu" onClick={() => run(() => api.duplicateMenu(m.id), 'Menu duplicato (nascosto finché non lo pubblichi)', false)} icon={<Copy className="h-4 w-4" />} />
                <IconAction label="Modifica menu" onClick={() => setEditing({ kind: 'menu', data: stripMenu(m) })} icon={<Pencil className="h-4 w-4" />} />
                <IconAction label="Elimina menu" danger onClick={() => remove('menus', m.id, `il menu “${m.name}” e tutti i suoi piatti`)} icon={<Trash2 className="h-4 w-4" />} />
              </div>
            </header>

            {open === m.id && (
              <div className="space-y-4 border-t border-line bg-paper/60 p-3 sm:p-5">
                {m.sections.map((s, si) => (
                  <div key={s.id} className={cn('rounded-3xl border border-line bg-white', !s.is_active && 'opacity-70')}>
                    <div className="flex flex-wrap items-center gap-1 border-b border-line px-3 py-2.5 sm:px-4">
                      <p className="min-w-0 flex-1 font-semibold">
                        {s.name} <span className="text-xs font-normal text-ink-muted">· {s.items.length}</span>
                        {!s.is_active && <span className="ml-2 text-xs font-semibold text-ink-muted">(nascosta)</span>}
                      </p>
                      <IconAction label="Sposta su" onClick={() => move('menu_categories', m.sections, si, -1)} icon={<ArrowUp className="h-4 w-4" />} disabled={si === 0} />
                      <IconAction label="Sposta giù" onClick={() => move('menu_categories', m.sections, si, 1)} icon={<ArrowDown className="h-4 w-4" />} disabled={si === m.sections.length - 1} />
                      <IconAction label={s.is_active ? 'Nascondi categoria' : 'Mostra categoria'} onClick={() => quick('menu_categories', s, { is_active: !s.is_active, menu_id: s.menu_id }, s.is_active ? 'Categoria nascosta' : 'Categoria visibile')} icon={s.is_active ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />} />
                      <IconAction label="Rinomina categoria" onClick={() => setEditing({ kind: 'section', data: { id: s.id, menu_id: s.menu_id, name: s.name, description: s.description, is_active: s.is_active, sort_order: s.sort_order } })} icon={<Pencil className="h-4 w-4" />} />
                      <IconAction label="Elimina categoria" danger onClick={() => remove('menu_categories', s.id, `la categoria “${s.name}” e i suoi piatti`)} icon={<Trash2 className="h-4 w-4" />} />
                    </div>
                    <ul className="divide-y divide-line">
                      {s.items.map((it, ii) => (
                        <ItemRow
                          key={it.id}
                          it={it}
                          first={ii === 0}
                          last={ii === s.items.length - 1}
                          onMove={(dir) => move('menu_items', s.items, ii, dir)}
                          onToggle={() => quick('menu_items', it, { is_available: !it.is_available, menu_category_id: it.menu_category_id }, it.is_available ? 'Segnato come non disponibile' : 'Di nuovo disponibile')}
                          onPrice={(price) => quick('menu_items', it, { price, menu_category_id: it.menu_category_id }, 'Prezzo aggiornato')}
                          onDuplicate={() => (ent.within('max_menu_items', itemsCount) ? void run(() => api.duplicateMenuItem(it.id), 'Piatto duplicato', false) : limitReached())}
                          onEdit={() => setEditing({ kind: 'item', data: { ...it, variantsDraft: it.variants.map(({ name, price }) => ({ name, price })), addonsDraft: it.addons.map(({ name, price }) => ({ name, price })) } })}
                          onDelete={() => remove('menu_items', it.id, `“${it.name}”`)}
                        />
                      ))}
                    </ul>
                    <button onClick={() => newItem(s)} className="flex w-full items-center gap-1.5 px-4 py-3 text-sm font-semibold text-coral-700 hover:bg-coral-50/50">
                      <Plus className="h-4 w-4" /> Aggiungi piatto
                    </button>
                  </div>
                ))}
                <Button variant="outline" size="sm" icon={<Plus className="h-4 w-4" />} onClick={() => setEditing({ kind: 'section', data: { menu_id: m.id, name: '', is_active: true, sort_order: m.sections.length } })}>
                  Aggiungi categoria
                </Button>
              </div>
            )}
          </section>
        );
      })}

      <Sheet
        open={!!editing}
        onClose={() => setEditing(null)}
        wide={editing?.kind === 'item'}
        title={editing?.kind === 'menu' ? (editing.data.id ? 'Modifica menu' : 'Nuovo menu') : editing?.kind === 'section' ? 'Categoria' : editing?.data.id ? 'Modifica piatto' : 'Nuovo piatto'}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setEditing(null)}>Annulla</Button>
            <Button loading={saving} onClick={saveEditing}>Salva</Button>
          </div>
        }
      >
        {editing?.kind === 'menu' && <MenuForm data={editing.data} onChange={(data) => setEditing({ kind: 'menu', data })} />}
        {editing?.kind === 'section' && (
          <div className="grid gap-4">
            <Field label="Nome categoria">
              <Input autoFocus value={editing.data.name ?? ''} maxLength={80} onChange={(e) => setEditing({ kind: 'section', data: { ...editing.data, name: e.target.value } })} placeholder="Es. Antipasti, Uramaki, Ramen, Dolci" />
            </Field>
            <Field label="Descrizione (facoltativa)">
              <Input value={editing.data.description ?? ''} onChange={(e) => setEditing({ kind: 'section', data: { ...editing.data, description: e.target.value || null } })} />
            </Field>
          </div>
        )}
        {editing?.kind === 'item' && (
          <ItemForm data={editing.data} onChange={(data) => setEditing({ kind: 'item', data })} ayce={r.is_all_you_can_eat} restaurantId={r.id} />
        )}
      </Sheet>

      <ImportSheet open={importing} onClose={() => setImporting(false)} restaurantId={r.id} onDone={reload} />
    </div>
  );
}

const stripMenu = (m: MenuWithSections): Partial<Menu> => {
  const { sections: _s, ...rest } = m;
  void _s;
  return rest;
};

function ItemRow({
  it, first, last, onMove, onToggle, onPrice, onDuplicate, onEdit, onDelete,
}: {
  it: MenuItemFull; first: boolean; last: boolean;
  onMove: (d: -1 | 1) => void; onToggle: () => void; onPrice: (p: number | null) => void; onDuplicate: () => void; onEdit: () => void; onDelete: () => void;
}) {
  const [price, setPrice] = useState<string | null>(null);
  const commit = () => {
    if (price === null) return;
    const v = numOrNull(price);
    setPrice(null);
    if (v !== it.price && (v === null || Number.isFinite(v))) onPrice(v);
  };
  return (
    <li className="flex flex-wrap items-center gap-2 px-3 py-2.5 sm:px-4">
      <button
        type="button"
        role="switch"
        aria-checked={it.is_available}
        aria-label={it.is_available ? `${it.name}: disponibile` : `${it.name}: non disponibile`}
        onClick={onToggle}
        className={cn('relative h-6 w-10 shrink-0 rounded-full transition', it.is_available ? 'bg-leaf' : 'bg-line')}
      >
        <span className={cn('absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition', it.is_available ? 'left-[18px]' : 'left-0.5')} />
      </button>
      <div className="min-w-0 flex-1">
        <p className={cn('truncate text-sm font-medium', !it.is_available && 'text-ink-faint line-through')}>{it.name}</p>
        <p className="truncate text-xs text-ink-muted">
          {[it.variants.length ? `${it.variants.length} varianti` : null, it.addons.length ? `${it.addons.length} extra` : null, it.allergens.length ? `${it.allergens.length} allergeni` : 'allergeni non indicati'].filter(Boolean).join(' · ')}
        </p>
      </div>
      {price === null ? (
        <button type="button" onClick={() => setPrice(it.price != null ? String(it.price) : '')} className="rounded-xl px-2 py-1 text-sm font-semibold tabular-nums hover:bg-cream" aria-label={`Modifica prezzo di ${it.name}`}>
          {it.price != null ? formatPrice(it.price) : '—'}
        </button>
      ) : (
        <input
          autoFocus
          inputMode="decimal"
          aria-label={`Prezzo di ${it.name}`}
          className="h-9 w-20 rounded-xl border border-ink px-2 text-right text-sm tabular-nums"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          onBlur={commit}
          onKeyDown={(e) => {
            if (e.key === 'Enter') commit();
            if (e.key === 'Escape') setPrice(null);
          }}
        />
      )}
      <div className="flex">
        <IconAction label="Sposta su" onClick={() => onMove(-1)} icon={<ArrowUp className="h-4 w-4" />} disabled={first} />
        <IconAction label="Sposta giù" onClick={() => onMove(1)} icon={<ArrowDown className="h-4 w-4" />} disabled={last} />
        <IconAction label="Duplica piatto" onClick={onDuplicate} icon={<Copy className="h-4 w-4" />} />
        <IconAction label="Modifica piatto" onClick={onEdit} icon={<Pencil className="h-4 w-4" />} />
        <IconAction label="Elimina piatto" danger onClick={onDelete} icon={<Trash2 className="h-4 w-4" />} />
      </div>
    </li>
  );
}

function IconAction({ label, icon, onClick, danger, disabled }: { label: string; icon: React.ReactNode; onClick: () => void; danger?: boolean; disabled?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      disabled={disabled}
      className={cn('rounded-full p-2 text-ink-muted transition disabled:pointer-events-none disabled:opacity-30', danger ? 'hover:bg-coral-50 hover:text-coral-700' : 'hover:bg-cream hover:text-ink')}
    >
      {icon}
    </button>
  );
}

function MenuForm({ data, onChange }: { data: Partial<Menu>; onChange: (d: Partial<Menu>) => void }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Nome" className="sm:col-span-2"><Input autoFocus maxLength={80} value={data.name ?? ''} onChange={(e) => onChange({ ...data, name: e.target.value })} placeholder="Es. Menu principale, Pranzo, Menu stagionale" /></Field>
      <Field label="Tipo">
        <Select value={data.menu_type} onChange={(e) => onChange({ ...data, menu_type: e.target.value as MenuType })}>
          {Object.entries(MENU_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      </Field>
      <Field label="Prezzo fisso (facoltativo)" hint="Per menu pranzo o All You Can Eat.">
        <Input type="number" min={0} step="0.1" inputMode="decimal" value={data.price ?? ''} onChange={(e) => onChange({ ...data, price: numOrNull(e.target.value) })} />
      </Field>
      <Field label="Valido dal (facoltativo)"><Input type="date" value={data.valid_from ?? ''} onChange={(e) => onChange({ ...data, valid_from: e.target.value || null })} /></Field>
      <Field label="Valido fino al (facoltativo)"><Input type="date" value={data.valid_until ?? ''} onChange={(e) => onChange({ ...data, valid_until: e.target.value || null })} /></Field>
      <Field label="Note per i clienti" className="sm:col-span-2"><Textarea rows={3} value={data.description ?? ''} onChange={(e) => onChange({ ...data, description: e.target.value || null })} placeholder="Es. coperto, orari, condizioni AYCE" /></Field>
      <div className="divide-y divide-line sm:col-span-2">
        <Toggle label="Visibile al pubblico" description="Se disattivato il menu resta una bozza visibile solo a te." checked={data.is_public ?? true} onChange={(v) => onChange({ ...data, is_public: v })} />
      </div>
    </div>
  );
}

function ItemForm({ data, onChange, ayce, restaurantId }: { data: ItemDraft; onChange: (d: ItemDraft) => void; ayce: boolean; restaurantId: string }) {
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const allergens = data.allergens ?? [];
  const set = (patch: Partial<ItemDraft>) => onChange({ ...data, ...patch });
  const upload = async (file: File) => {
    if (!file.type.startsWith('image/')) return toast('Carica un’immagine (JPG, PNG o WebP)', 'error');
    if (file.size > 5 * 1024 * 1024) return toast('Immagine troppo grande (max 5 MB)', 'error');
    setUploading(true);
    try {
      const { url } = await api.uploadImage(restaurantId, file, 'menu');
      set({ image_url: url });
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setUploading(false);
    }
  };
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Nome piatto" className="sm:col-span-2"><Input autoFocus maxLength={120} value={data.name ?? ''} onChange={(e) => set({ name: e.target.value })} /></Field>
      <Field label="Descrizione" className="sm:col-span-2"><Textarea rows={2} maxLength={500} value={data.description ?? ''} onChange={(e) => set({ description: e.target.value || null })} /></Field>
      <Field label="Prezzo (€)" hint={ayce ? 'Vuoto = compreso nel menu AYCE' : 'Vuoto = prezzo non indicato'}>
        <Input type="number" min={0} step="0.1" inputMode="decimal" value={data.price ?? ''} onChange={(e) => set({ price: numOrNull(e.target.value) })} />
      </Field>
      <Field label="Prezzo scontato (€)" hint="Facoltativo: mostra il prezzo barrato">
        <Input type="number" min={0} step="0.1" inputMode="decimal" value={data.discount_price ?? ''} onChange={(e) => set({ discount_price: numOrNull(e.target.value) })} />
      </Field>
      <Field label="Pezzi"><Input type="number" min={0} inputMode="numeric" value={data.pieces ?? ''} onChange={(e) => set({ pieces: e.target.value === '' ? null : Number(e.target.value) })} /></Field>
      <div>
        <span className="label">Foto (facoltativa)</span>
        <div className="flex items-center gap-3">
          {data.image_url && <img src={data.image_url} alt="" className="h-14 w-14 rounded-xl object-cover" loading="lazy" />}
          <Button type="button" variant="outline" size="sm" loading={uploading} icon={<ImagePlus className="h-4 w-4" />} onClick={() => fileRef.current?.click()}>
            {data.image_url ? 'Cambia' : 'Carica'}
          </Button>
          {data.image_url && <button type="button" onClick={() => set({ image_url: null })} className="text-sm text-coral-700">Rimuovi</button>}
          <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
        </div>
      </div>
      <Field label="Ingredienti" hint="Separati da virgola" className="sm:col-span-2">
        <Input value={(data.ingredients ?? []).join(', ')} onChange={(e) => set({ ingredients: e.target.value.split(',').map((x) => x.trimStart()) })} onBlur={() => set({ ingredients: (data.ingredients ?? []).map((x) => x.trim()).filter(Boolean) })} />
      </Field>
      <fieldset className="sm:col-span-2">
        <legend className="label">Allergeni (Reg. UE 1169/2011)</legend>
        <div className="flex flex-wrap gap-1.5">
          {ALLERGENS.map((a) => (
            <Chip key={a.code} active={allergens.includes(a.code)} onClick={() => set({ allergens: allergens.includes(a.code) ? allergens.filter((x) => x !== a.code) : [...allergens, a.code] })} className="!h-9 !px-3 !text-[13px]">
              {a.icon} {a.name}
            </Chip>
          ))}
        </div>
        <p className="mt-1.5 text-xs text-ink-muted">Indica solo allergeni verificati. Ai clienti mostriamo sempre: “Per allergie o intolleranze contatta direttamente il ristorante.”</p>
      </fieldset>
      <div className="grid gap-x-6 sm:col-span-2 sm:grid-cols-2">
        <Toggle label="Vegetariano" checked={!!data.is_vegetarian} onChange={(v) => set({ is_vegetarian: v, is_vegan: v ? data.is_vegan : false })} />
        <Toggle label="Vegano" checked={!!data.is_vegan} onChange={(v) => set({ is_vegan: v, is_vegetarian: v || data.is_vegetarian })} />
        <Toggle label="Gluten free" checked={!!data.is_gluten_free} onChange={(v) => set({ is_gluten_free: v })} />
        <Toggle label="Piccante" checked={!!data.is_spicy} onChange={(v) => set({ is_spicy: v })} />
        <Toggle label="Consigliato" description="Stella accanto al nome" checked={!!data.is_featured} onChange={(v) => set({ is_featured: v })} />
        <Toggle label="Disponibile" checked={data.is_available ?? true} onChange={(v) => set({ is_available: v })} />
        {ayce && <Toggle label="Incluso nell’All You Can Eat" checked={!!data.is_ayce_included} onChange={(v) => set({ is_ayce_included: v })} />}
      </div>
      <OptionsEditor className="sm:col-span-2" title="Varianti" hint="Es. 4 pezzi / 8 pezzi, Small / Large" rows={data.variantsDraft ?? []} onChange={(v) => set({ variantsDraft: v })} />
      <OptionsEditor className="sm:col-span-2" title="Extra" hint="Es. Extra salmone, Salsa speciale" rows={data.addonsDraft ?? []} onChange={(v) => set({ addonsDraft: v })} />
    </div>
  );
}

function OptionsEditor({ title, hint, rows, onChange, className }: { title: string; hint: string; rows: Opt[]; onChange: (r: Opt[]) => void; className?: string }) {
  return (
    <fieldset className={className}>
      <legend className="label">{title}</legend>
      <div className="space-y-2">
        {rows.map((o, i) => (
          <div key={i} className="flex gap-2">
            <Input aria-label={`${title} ${i + 1}: nome`} placeholder="Nome" value={o.name} maxLength={60} onChange={(e) => onChange(rows.map((x, k) => (k === i ? { ...x, name: e.target.value } : x)))} />
            <Input aria-label={`${title} ${i + 1}: prezzo`} placeholder="€" className="!w-28" type="number" min={0} step="0.1" inputMode="decimal" value={o.price ?? ''} onChange={(e) => onChange(rows.map((x, k) => (k === i ? { ...x, price: numOrNull(e.target.value) } : x)))} />
            <button type="button" aria-label={`Rimuovi ${title.toLowerCase()} ${i + 1}`} onClick={() => onChange(rows.filter((_, k) => k !== i))} className="rounded-full p-2 text-ink-muted hover:bg-coral-50 hover:text-coral-700">
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
        <button type="button" onClick={() => onChange([...rows, { name: '', price: null }])} className="inline-flex items-center gap-1 text-sm font-semibold text-coral-700">
          <Plus className="h-4 w-4" /> Aggiungi {title.toLowerCase() === 'extra' ? 'extra' : 'variante'}
        </button>
        <p className="text-xs text-ink-muted">{hint}</p>
      </div>
    </fieldset>
  );
}

/** Import menu: file CSV/JSON → anteprima con errori → conferma. */
function ImportSheet({ open, onClose, restaurantId, onDone }: { open: boolean; onClose: () => void; restaurantId: string; onDone: () => void }) {
  const toast = useToast();
  const { handleError } = useUpgrade();
  const [preview, setPreview] = useState<(MenuImportPreview & { file: string }) | null>(null);
  const [busy, setBusy] = useState(false);
  const read = async (file: File) => {
    if (file.size > 2 * 1024 * 1024) return toast('File troppo grande (max 2 MB)', 'error');
    setPreview({ ...parseMenuFile(await file.text(), file.name), file: file.name });
  };
  const confirmImport = async (rows: MenuImportRow[]) => {
    setBusy(true);
    try {
      const res = await api.importMenu(restaurantId, rows);
      toast(`Importati ${res.items} piatti (${res.categories} nuove categorie, ${res.menus} nuovi menu)`);
      setPreview(null);
      onClose();
      onDone();
    } catch (e) {
      handleError(e, restaurantId);
    } finally {
      setBusy(false);
    }
  };
  const template = () => {
    const url = URL.createObjectURL(new Blob(['\uFEFF' + MENU_CSV_TEMPLATE], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'modello-menu-asiafood.csv';
    a.click();
    URL.revokeObjectURL(url);
  };
  return (
    <Sheet
      open={open}
      onClose={() => { setPreview(null); onClose(); }}
      title="Importa menu"
      wide
      footer={
        preview && preview.rows.length > 0 ? (
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setPreview(null)}>Scegli un altro file</Button>
            <Button loading={busy} disabled={preview.errors.length > 0} onClick={() => confirmImport(preview.rows)}>Importa {preview.rows.length} piatti</Button>
          </div>
        ) : undefined
      }
    >
      {!preview ? (
        <div className="space-y-4">
          <p className="text-[15px] text-ink-soft">
            Carica un file <strong>CSV</strong> (separatore “;” o “,”) o <strong>JSON</strong>. Colonne: menu, categoria, nome, descrizione, prezzo, prezzo_scontato, allergeni, ingredienti,
            vegetariano, vegano, senza_glutine, piccante, disponibile, consigliato, varianti (es. “4 pezzi=5,50|8 pezzi=9”), extra. I piatti si aggiungono a quelli esistenti.
          </p>
          <div className="flex flex-wrap gap-2">
            <label className="inline-flex h-11 cursor-pointer items-center gap-2 rounded-full bg-ink px-5 text-[15px] font-semibold text-white hover:bg-ink-soft">
              <FileUp className="h-4 w-4" /> Scegli file
              <input type="file" accept=".csv,.json,text/csv,application/json" className="sr-only" onChange={(e) => e.target.files?.[0] && read(e.target.files[0])} />
            </label>
            <Button variant="outline" icon={<Download className="h-4 w-4" />} onClick={template}>Scarica modello CSV</Button>
          </div>
          <p className="text-xs text-ink-muted">L’import da PDF o foto del menu arriverà in una versione successiva.</p>
        </div>
      ) : (
        <div className="space-y-4">
          <p className="text-sm text-ink-muted">{preview.file}: {preview.rows.length} piatti validi{preview.errors.length ? `, ${preview.errors.length} errori` : ''}.</p>
          {preview.errors.length > 0 && (
            <ul className="space-y-1 rounded-2xl bg-coral-50 p-4 text-sm text-coral-800" role="alert">
              {preview.errors.slice(0, 20).map((e, i) => <li key={i}>{e.row ? `Riga ${e.row}: ` : ''}{e.message}</li>)}
              <li className="pt-1 font-semibold">Correggi il file e riprova: nessun piatto viene importato finché ci sono errori.</li>
            </ul>
          )}
          {preview.rows.length > 0 && (
            <div className="overflow-x-auto rounded-2xl border border-line">
              <table className="w-full text-left text-sm">
                <thead className="bg-cream text-xs uppercase text-ink-muted">
                  <tr><th className="px-3 py-2">Menu</th><th className="px-3 py-2">Categoria</th><th className="px-3 py-2">Piatto</th><th className="px-3 py-2 text-right">Prezzo</th><th className="px-3 py-2">Allergeni</th></tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {preview.rows.slice(0, 30).map((x, i) => (
                    <tr key={i}>
                      <td className="px-3 py-2">{x.menu}</td>
                      <td className="px-3 py-2">{x.category}</td>
                      <td className="px-3 py-2 font-medium">{x.name}{x.variants?.length ? <span className="text-xs text-ink-muted"> · {x.variants.length} varianti</span> : null}</td>
                      <td className="px-3 py-2 text-right tabular-nums">{x.price != null ? formatPrice(x.price) : '—'}</td>
                      <td className="px-3 py-2 text-xs">{x.allergens?.length ? x.allergens.map((a) => ALLERGENS.find((y) => y.code === a)?.name).join(', ') : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {preview.rows.length > 30 && <p className="px-3 py-2 text-xs text-ink-muted">… e altri {preview.rows.length - 30}</p>}
            </div>
          )}
        </div>
      )}
    </Sheet>
  );
}
