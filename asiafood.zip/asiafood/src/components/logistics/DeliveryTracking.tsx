import { useCallback, useEffect, useState } from 'react';
import { Bike, KeyRound, Star } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { api } from '@/services';
import type { OrderDeliveryView } from '@/types/logistics';
import { JOB_STATUS_LABEL, VEHICLE_LABEL } from '@/types/logistics';
import { Button } from '@/components/ui/Button';
import { Textarea } from '@/components/ui/Field';
import { useToast } from '@/components/ui/Toast';
import { DeliveryMap, JobStatusBadge, etaRangeText } from './LogisticsParts';

/**
 * Tracking della consegna con Rider AsiaFood (pagina ordine).
 * Il cliente vede: ristorante, la propria destinazione, il Rider assegnato (nome e iniziale, veicolo)
 * e la sua posizione SOLO dopo il ritiro. Nessun contatto privato del Rider.
 */
export function DeliveryTracking({ orderNumber, token, canRate }: { orderNumber: string; token: string | null; canRate: boolean }) {
  const toast = useToast();
  const [d, setD] = useState<OrderDeliveryView | null>(null);
  const [now, setNow] = useState(Date.now());
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [sending, setSending] = useState(false);

  const load = useCallback(async () => {
    try {
      setD(await api.getOrderDelivery(orderNumber, token));
      setNow(Date.now());
    } catch {
      /* il tracking non blocca la pagina ordine */
    }
  }, [orderNumber, token]);
  const jobActive = !!d?.job && !['delivered', 'failed', 'cancelled'].includes(d.job.status);

  useEffect(() => {
    void load();
  }, [load]);
  // Realtime (utenti registrati) con polling di riserva leggero; ospiti: polling
  useEffect(() => {
    if (!jobActive) return;
    let channel: ReturnType<NonNullable<typeof supabase>['channel']> | null = null;
    if (supabase && !token) {
      channel = supabase.channel(`delivery-${orderNumber}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'delivery_realtime' }, () => void load())
        .subscribe();
    }
    const t = window.setInterval(() => void load(), channel ? 30_000 : 10_000);
    return () => {
      window.clearInterval(t);
      if (channel) void supabase?.removeChannel(channel);
    };
  }, [jobActive, orderNumber, token, load]);

  if (!d?.job) return null;
  const j = d.job;
  const eta = etaRangeText(j.eta_min_at, j.eta_max_at, now);
  const showEta = !['delivered', 'failed', 'cancelled'].includes(j.status) && eta;

  const rate = async () => {
    setSending(true);
    try {
      await api.rateDelivery(orderNumber, rating, comment || null);
      toast('Grazie per la valutazione!');
      await load();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setSending(false);
    }
  };

  return (
    <section className="card mt-4 space-y-4 p-5" aria-label="Consegna con Rider AsiaFood" data-testid="delivery-tracking">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="flex items-center gap-2 text-lg font-bold"><Bike className="h-5 w-5 text-coral" /> Consegna AsiaFood</h2>
        <JobStatusBadge status={j.status} />
      </div>
      {showEta && (
        <p className="text-2xl font-extrabold" data-testid="delivery-eta" aria-live="polite">
          Consegna stimata {eta}
          <span className="block text-xs font-normal text-ink-muted">Tempo stimato{j.eta_source === 'routing' ? ' in base al percorso' : ''}: può variare con traffico e preparazione.</span>
        </p>
      )}
      {j.rider ? (
        <p className="flex items-center gap-3 rounded-2xl bg-cream/70 p-3 text-sm" data-testid="delivery-rider">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-lg" aria-hidden>🛵</span>
          <span><strong>{j.rider.name}</strong> · {VEHICLE_LABEL[j.rider.vehicle_type]}<span className="block text-ink-muted">{JOB_STATUS_LABEL[j.status]}</span></span>
        </p>
      ) : !['delivered', 'failed', 'cancelled'].includes(j.status) && (
        <p className="rounded-2xl bg-cream/70 p-3 text-sm">Stiamo cercando un Rider disponibile vicino al ristorante…</p>
      )}
      {j.delivery_code && (
        <p className="flex items-center gap-3 rounded-2xl border-2 border-dashed border-coral p-3" data-testid="delivery-code-customer">
          <KeyRound className="h-5 w-5 text-coral" />
          <span className="text-sm">Codice di consegna: <strong className="font-mono text-xl tracking-widest">{j.delivery_code}</strong><span className="block text-xs text-ink-muted">Comunicalo al Rider solo quando ricevi l’ordine.</span></span>
        </p>
      )}
      {!['delivered', 'failed', 'cancelled'].includes(j.status) && (
        <DeliveryMap ariaLabel="Mappa della consegna" markers={[
          { id: 'restaurant', lat: j.restaurant.latitude, lng: j.restaurant.longitude, label: j.restaurant.name, emoji: '🍣' },
          { id: 'home', lat: j.destination.latitude, lng: j.destination.longitude, label: 'Tu', emoji: '🏠' },
          ...(j.rider_position ? [{ id: 'rider', lat: j.rider_position.latitude, lng: j.rider_position.longitude, label: j.rider?.name ?? 'Rider', emoji: '🛵' }] : []),
        ]} />
      )}
      {!j.rider_position && ['assigned', 'rider_to_restaurant', 'arrived_restaurant'].includes(j.status) && (
        <p className="text-xs text-ink-muted">La posizione del Rider sarà visibile dopo il ritiro del tuo ordine.</p>
      )}
      {canRate && j.can_rate && (
        <div className="rounded-2xl border border-line p-4" data-testid="rate-delivery">
          <p className="text-sm font-semibold">Com’è andata la consegna?</p>
          <p className="text-xs text-ink-muted">Valutazione separata dal ristorante, usata solo per la qualità interna (non è pubblica).</p>
          <div className="mt-2 flex gap-1" role="radiogroup" aria-label="Voto consegna">
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} type="button" role="radio" aria-checked={rating === n} aria-label={`${n} stelle`} onClick={() => setRating(n)}>
                <Star className={n <= rating ? 'h-7 w-7 fill-amber-400 text-amber-400' : 'h-7 w-7 text-line'} />
              </button>
            ))}
          </div>
          {rating > 0 && <Textarea className="mt-2 min-h-[70px]" placeholder="Commento (facoltativo)" maxLength={500} value={comment} onChange={(e) => setComment(e.target.value)} />}
          <Button size="sm" className="mt-2" disabled={!rating} loading={sending} onClick={() => void rate()}>Invia valutazione</Button>
        </div>
      )}
      {j.rated && <p className="text-sm text-emerald-700">Grazie, hai valutato questa consegna.</p>}
    </section>
  );
}
