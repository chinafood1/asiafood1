import { useMemo } from 'react';
import { InteractiveMap } from '@/lib/maps/InteractiveMap';
import type { GeoBounds, MapPoint } from '@/lib/maps/types';
import type { DeliveryJobStatus, RiderStatus } from '@/types/logistics';
import { JOB_STATUS_LABEL, RIDER_STATUS_LABEL } from '@/types/logistics';
import { Badge } from '@/components/ui/Badge';

export interface MapMarker {
  id: string;
  lat: number | null | undefined;
  lng: number | null | undefined;
  label: string;
  emoji: string;
}

/** Mappa logistica (tracking cliente, Rider, control center Admin). Nessuna posizione viene salvata dal browser. */
export function DeliveryMap({ markers, className, ariaLabel, selectedId, onSelect }: {
  markers: MapMarker[];
  className?: string;
  ariaLabel: string;
  selectedId?: string | null;
  onSelect?: (id: string | null) => void;
}) {
  const points: MapPoint[] = useMemo(
    () => markers.filter((m) => m.lat != null && m.lng != null).map((m) => ({ id: m.id, lat: m.lat!, lng: m.lng!, label: m.label, emoji: m.emoji })),
    [markers],
  );
  const bounds: GeoBounds | null = useMemo(() => {
    if (!points.length) return null;
    const lats = points.map((p) => p.lat);
    const lngs = points.map((p) => p.lng);
    const pad = 0.006;
    return { north: Math.max(...lats) + pad, south: Math.min(...lats) - pad, east: Math.max(...lngs) + pad, west: Math.min(...lngs) - pad };
  }, [points]);
  // La mappa si ricentra solo quando cambia l'insieme dei punti (non a ogni spostamento del Rider)
  const key = points.map((p) => p.id).join('|');
  if (!bounds) return null;
  return (
    <div className={className ?? 'relative h-64 overflow-hidden rounded-3xl border border-line'}>
      <InteractiveMap
        key={key}
        points={points}
        selectedId={selectedId}
        onSelect={onSelect}
        initialView={{ bounds }}
        clustering={false}
        controls
        ariaLabel={ariaLabel}
        className="absolute inset-0 h-full w-full"
      />
    </div>
  );
}

const JOB_TONE: Partial<Record<DeliveryJobStatus, 'neutral' | 'green' | 'amber' | 'coral' | 'dark'>> = {
  waiting_assignment: 'amber', offered: 'amber', assigned: 'green', rider_to_restaurant: 'green', arrived_restaurant: 'green', picked_up: 'green',
  rider_to_customer: 'green', arrived_customer: 'green', delivered: 'dark', failed: 'coral', cancelled: 'coral',
};
export function JobStatusBadge({ status }: { status: DeliveryJobStatus }) {
  return <Badge tone={JOB_TONE[status] ?? 'neutral'}>{JOB_STATUS_LABEL[status]}</Badge>;
}
export function RiderStatusBadge({ status }: { status: RiderStatus }) {
  const tone = status === 'active' || status === 'approved' ? 'green' : status === 'pending' ? 'amber' : status === 'suspended' || status === 'rejected' ? 'coral' : 'neutral';
  return <Badge tone={tone}>{RIDER_STATUS_LABEL[status]}</Badge>;
}

/** "20–30 min": intervallo arrotondato a 5 minuti (mai un orario esatto). */
export function etaRangeText(minAt: string | null | undefined, maxAt: string | null | undefined, now = Date.now()) {
  if (!minAt || !maxAt) return null;
  const lo = Math.max(5, Math.floor((Date.parse(minAt) - now) / 60_000 / 5) * 5);
  const hi = Math.max(lo + 5, Math.ceil((Date.parse(maxAt) - now) / 60_000 / 5) * 5);
  if (Date.parse(maxAt) - now <= 5 * 60_000) return 'pochi minuti';
  return `${lo}–${hi} min`;
}
export const minutesUntil = (iso: string | null | undefined, now = Date.now()) => (iso ? Math.max(1, Math.round((Date.parse(iso) - now) / 60_000)) : null);
