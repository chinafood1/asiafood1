// Banner cookie: "Accetta tutti", "Rifiuta non necessari", "Personalizza" con la stessa evidenza visiva (niente dark pattern).
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Cookie } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Sheet } from '@/components/ui/Sheet';
import { Toggle } from '@/components/ui/Field';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { CONSENT_DEFAULT, needsConsent, OPEN_CONSENT_EVENT, readConsent, writeConsent } from '@/lib/consent';
import { t } from '@/i18n';
import { api } from '@/services';
import type { ConsentChoices } from '@/types/platform';

export function ConsentBanner() {
  const { config } = useRuntimeConfig();
  const version = String(config.settings.consent_policy_version ?? '2026-10-01');
  const [show, setShow] = useState(() => needsConsent(version));
  const [custom, setCustom] = useState(false);
  const [choices, setChoices] = useState<ConsentChoices>(() => readConsent()?.choices ?? CONSENT_DEFAULT);

  useEffect(() => setShow(needsConsent(version)), [version]);
  useEffect(() => {
    const open = () => {
      setChoices(readConsent()?.choices ?? CONSENT_DEFAULT);
      setCustom(true);
    };
    window.addEventListener(OPEN_CONSENT_EVENT, open);
    return () => window.removeEventListener(OPEN_CONSENT_EVENT, open);
  }, []);

  const save = (c: ConsentChoices, source: 'banner' | 'settings' = 'banner') => {
    const stored = writeConsent(c, version);
    setShow(false);
    setCustom(false);
    // Prova del consenso nel database (asincrona: la scelta vale subito anche se la rete non risponde)
    void api.recordConsent(stored.choices, stored.anonymous_id, source).catch(() => undefined);
  };

  return (
    <>
      {show && !custom && (
        <div role="region" aria-label="Preferenze cookie" data-testid="consent-banner"
          className="fixed inset-x-3 bottom-[calc(80px+env(safe-area-inset-bottom))] z-[65] mx-auto max-w-3xl rounded-3xl border border-line bg-white p-5 shadow-lift md:bottom-6">
          <div className="flex items-start gap-3">
            <Cookie className="mt-0.5 h-5 w-5 shrink-0 text-coral" aria-hidden />
            <div className="min-w-0">
              <h2 className="text-base font-bold">{t('consent.title')}</h2>
              <p className="mt-1 text-sm text-ink-muted">
                {t('consent.body')}{' '}
                <Link to="/cookie-policy" className="font-semibold text-ink underline">{t('consent.policy_link')}</Link> ·{' '}
                <Link to="/privacy" className="font-semibold text-ink underline">{t('consent.privacy_link')}</Link>
              </p>
            </div>
          </div>
          {/* Tre scelte con peso visivo comparabile */}
          <div className="mt-4 grid gap-2 sm:grid-cols-3">
            <Button variant="outline" onClick={() => save(CONSENT_DEFAULT)} data-testid="consent-reject">{t('consent.reject')}</Button>
            <Button variant="outline" onClick={() => setCustom(true)} data-testid="consent-customize">{t('consent.customize')}</Button>
            <Button variant="outline" onClick={() => save({ analytics: true, marketing: true, personalization: true })} data-testid="consent-accept">{t('consent.accept_all')}</Button>
          </div>
        </div>
      )}
      <Sheet open={custom} onClose={() => setCustom(false)} title="Preferenze cookie"
        footer={<div className="grid gap-2 sm:grid-cols-2">
          <Button variant="outline" onClick={() => save(CONSENT_DEFAULT, 'settings')}>{t('consent.reject')}</Button>
          <Button variant="dark" onClick={() => save(choices, 'settings')} data-testid="consent-save">{t('consent.save')}</Button>
        </div>}>
        <div className="divide-y divide-line">
          <Toggle checked disabled onChange={() => undefined} label={t('consent.necessary')} description={t('consent.necessary_desc')} />
          {(['analytics', 'marketing', 'personalization'] as const).map((k) => (
            <Toggle key={k} checked={choices[k]} onChange={(v) => setChoices((c) => ({ ...c, [k]: v }))} label={t(`consent.${k}`)} description={t(`consent.${k}_desc`)} />
          ))}
        </div>
        <p className="mt-3 text-xs text-ink-muted">Versione informativa: {version}. Puoi modificare le scelte in qualsiasi momento dal footer («Preferenze cookie»).</p>
      </Sheet>
    </>
  );
}
