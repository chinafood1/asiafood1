// Beta su invito: il codice inserito alla registrazione viene riscattato al primo accesso disponibile.
import { useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/services';

const KEY = 'af_beta_invite';
export function storePendingInvite(code: string) {
  try {
    localStorage.setItem(KEY, code.slice(0, 80));
  } catch {
    /* ignorato */
  }
}

export function BetaInviteRedeemer() {
  const { user } = useAuth();
  useEffect(() => {
    if (!user) return;
    let code: string | null = null;
    try {
      code = localStorage.getItem(KEY);
    } catch {
      code = null;
    }
    if (!code) return;
    void api.redeemBetaInvite(code).then(() => {
      try {
        localStorage.removeItem(KEY);
      } catch {
        /* ignorato */
      }
    }, () => undefined);
  }, [user]);
  return null;
}
