// Cloudflare Turnstile (anti-bot) — solo se VITE_TURNSTILE_SITE_KEY è impostata; il token è verificato dal backend.
import { useEffect, useRef } from 'react';

const SITE_KEY = (((import.meta.env ?? {}) as Record<string, string | undefined>).VITE_TURNSTILE_SITE_KEY ?? '').trim();
export const turnstileEnabled = () => Boolean(SITE_KEY);

type TurnstileApi = { render(el: HTMLElement, o: Record<string, unknown>): string; remove(id: string): void };
declare global {
  interface Window {
    turnstile?: TurnstileApi;
  }
}

let loading: Promise<void> | null = null;
function loadScript() {
  loading ??= new Promise<void>((res, rej) => {
    const s = document.createElement('script');
    s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
    s.async = true;
    s.onload = () => res();
    s.onerror = () => rej(new Error('turnstile'));
    document.head.appendChild(s);
  });
  return loading;
}

export function TurnstileWidget({ onToken }: { onToken: (token: string | null) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!SITE_KEY || !ref.current) return;
    let id: string | null = null;
    let cancelled = false;
    void loadScript().then(() => {
      if (cancelled || !ref.current || !window.turnstile) return;
      id = window.turnstile.render(ref.current, {
        sitekey: SITE_KEY, language: 'it', appearance: 'interaction-only',
        callback: (t: string) => onToken(t), 'expired-callback': () => onToken(null), 'error-callback': () => onToken(null),
      });
    }).catch(() => onToken(null));
    return () => {
      cancelled = true;
      if (id && window.turnstile) window.turnstile.remove(id);
    };
  }, [onToken]);
  if (!SITE_KEY) return null;
  return <div ref={ref} className="min-h-[1px]" aria-label="Verifica anti-bot" />;
}
