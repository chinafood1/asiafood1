// Elementi di piattaforma dell'app: aggiornamento PWA, stato offline, manutenzione, error boundary.
import { Component, useEffect, useState, type ErrorInfo, type ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { RefreshCw, WifiOff, Wrench } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/context/AuthContext';
import { useRuntimeConfig } from '@/context/RuntimeConfigContext';
import { captureError } from '@/lib/monitoring';
import { t } from '@/i18n';

/** true se il browser è online (aggiornato in tempo reale). */
export function useOnline() {
  const [on, setOn] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));
  useEffect(() => {
    const up = () => setOn(true);
    const down = () => setOn(false);
    window.addEventListener('online', up);
    window.addEventListener('offline', down);
    return () => {
      window.removeEventListener('online', up);
      window.removeEventListener('offline', down);
    };
  }, []);
  return on;
}

export function OfflineBanner() {
  const online = useOnline();
  if (online) return null;
  return (
    <div role="status" data-testid="offline-banner" className="sticky top-0 z-[60] bg-amber-100 text-amber-900">
      <div className="container-app flex items-center gap-2 py-2 text-sm">
        <WifiOff className="h-4 w-4 shrink-0" aria-hidden /> {t('pwa.offline')}
      </div>
    </div>
  );
}

/** "È disponibile un aggiornamento" + "Aggiorna" (service worker in modalità prompt: niente app bloccata su JS vecchio). */
export function UpdatePrompt() {
  const [update, setUpdate] = useState<null | ((reload?: boolean) => Promise<void>)>(null);
  useEffect(() => {
    if (import.meta.env.DEV || !('serviceWorker' in navigator)) return;
    let cancelled = false;
    void import('virtual:pwa-register').then(({ registerSW }) => {
      if (cancelled) return;
      const fn = registerSW({
        onNeedRefresh: () => setUpdate(() => fn),
        onRegisteredSW: (_url, reg) => {
          // Controllo periodico degli aggiornamenti (ogni ora) per chi tiene l'app aperta a lungo
          if (reg) setInterval(() => void reg.update().catch(() => undefined), 60 * 60_000);
        },
      });
    }).catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);
  if (!update) return null;
  return (
    <div role="status" data-testid="update-prompt" className="fixed inset-x-3 top-3 z-[80] mx-auto flex max-w-md items-center gap-3 rounded-2xl bg-ink p-3 pl-4 text-sm text-white shadow-lift">
      <RefreshCw className="h-4 w-4 shrink-0 text-coral-300" aria-hidden />
      <span className="flex-1">{t('pwa.update_available')}</span>
      <Button size="sm" onClick={() => void update(true)}>{t('pwa.update')}</Button>
    </div>
  );
}

/** Manutenzione: il pubblico vede la pagina dedicata; Admin (e pagina di accesso) passano. */
export function MaintenanceGate({ children }: { children: ReactNode }) {
  const { setting } = useRuntimeConfig();
  const { isAdmin } = useAuth();
  const { pathname } = useLocation();
  const on = setting<boolean>('maintenance_mode', false) === true;
  if (!on || isAdmin || pathname.startsWith('/accedi') || pathname.startsWith('/admin')) return <>{children}</>;
  const msg = setting<string | null>('maintenance_message', null);
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center bg-paper px-6 text-center" data-testid="maintenance-page">
      <Wrench className="h-10 w-10 text-coral" aria-hidden />
      <h1 className="mt-5 text-3xl font-extrabold">{t('maintenance.title')}</h1>
      <p className="mt-2 max-w-md text-ink-muted">{msg || t('maintenance.body')}</p>
      <Link to="/accedi" className="mt-8 text-xs text-ink-faint underline">Accesso staff</Link>
    </main>
  );
}

/** Errore di rendering: messaggio comprensibile, segnalazione (senza PII), niente pagina bianca. */
export class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    void info;
    captureError(error, 'ReactErrorBoundary');
  }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <main className="flex min-h-[70vh] flex-col items-center justify-center px-6 text-center" role="alert">
        <p className="text-6xl" aria-hidden>🥢</p>
        <h1 className="mt-4 text-2xl font-extrabold">Qualcosa non ha funzionato</h1>
        <p className="mt-2 max-w-md text-ink-muted">Abbiamo registrato il problema. Ricarica la pagina o torna alla home.</p>
        <div className="mt-6 flex gap-3">
          <Button onClick={() => window.location.reload()}>Ricarica</Button>
          <Button variant="outline" onClick={() => window.location.assign('/')}>Home</Button>
        </div>
      </main>
    );
  }
}
