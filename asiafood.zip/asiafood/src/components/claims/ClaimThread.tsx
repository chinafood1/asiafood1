import { useRef, useState } from 'react';
import { Paperclip, Send, X } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { cn, formatDate } from '@/lib/format';
import { api } from '@/services';
import { OPEN_CLAIM_STATUSES, type ClaimWithRestaurant } from '@/types/domain';
import { Button } from '@/components/ui/Button';
import { Textarea } from '@/components/ui/Field';
import { Alert } from '@/components/ui/Layout';
import { useToast } from '@/components/ui/Toast';

/** Apre un documento privato tramite URL firmato a scadenza (mai link pubblici). */
export function DocumentLink({ path, label = 'Apri documento' }: { path: string; label?: string }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button"
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        try {
          window.open(await api.getClaimDocumentUrl(path), '_blank', 'noopener');
        } catch (e) {
          toast((e as Error).message, 'error');
        } finally {
          setBusy(false);
        }
      }}
      className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1.5 text-xs font-semibold hover:border-ink disabled:opacity-50"
    >
      <Paperclip className="h-3.5 w-3.5" /> {label}
    </button>
  );
}

/** Conversazione Admin ⇄ richiedente su una rivendicazione. */
export function ClaimThread({ claim, viewer, userId, onChanged }: { claim: ClaimWithRestaurant; viewer: 'claimant' | 'admin'; userId?: string; onChanged?: () => void }) {
  const toast = useToast();
  const messages = useAsync(() => api.getClaimMessages(claim.id), [claim.id, claim.status]);
  const [text, setText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const canReply = viewer === 'claimant' && OPEN_CLAIM_STATUSES.includes(claim.status);
  const list = messages.data ?? [];

  const send = async () => {
    if (!text.trim() || !userId) return;
    setBusy(true);
    try {
      const path = file ? await api.uploadClaimDocument(userId, file) : null;
      await api.respondToClaim(claim.id, text.trim(), path);
      setText('');
      setFile(null);
      toast('Risposta inviata');
      messages.reload();
      onChanged?.();
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      {list.length > 0 && (
        <ul className="space-y-3">
          {list.map((m) => {
            const mine = (viewer === 'admin') === (m.author_role === 'admin');
            return (
              <li key={m.id} className={cn('flex', mine ? 'justify-end' : 'justify-start')}>
                <div className={cn('max-w-[85%] rounded-3xl px-4 py-3 text-sm', m.author_role === 'admin' ? 'bg-ink text-white' : 'bg-cream text-ink')}>
                  <p className={cn('mb-1 text-[11px] font-semibold uppercase tracking-wide', m.author_role === 'admin' ? 'text-white/60' : 'text-ink-muted')}>
                    {m.author_role === 'admin' ? 'Staff' : 'Richiedente'} · {formatDate(m.created_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </p>
                  <p className="whitespace-pre-line">{m.body}</p>
                  {m.attachment_path && <div className="mt-2"><DocumentLink path={m.attachment_path} label="Allegato" /></div>}
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {canReply && (
        <div className="mt-4 space-y-2">
          {claim.status === 'more_information_required' && <Alert tone="error">Informazioni aggiuntive richieste: rispondi qui sotto per far proseguire la verifica.</Alert>}
          <Textarea rows={3} value={text} maxLength={4000} onChange={(e) => setText(e.target.value)} placeholder="Scrivi la tua risposta…" className="!min-h-0" />
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <input ref={fileRef} type="file" hidden accept="application/pdf,image/jpeg,image/png,image/webp" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
              {file ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-cream px-3 py-1.5 text-xs">
                  {file.name}
                  <button aria-label="Rimuovi allegato" onClick={() => setFile(null)}><X className="h-3.5 w-3.5" /></button>
                </span>
              ) : (
                <Button type="button" size="sm" variant="ghost" icon={<Paperclip className="h-4 w-4" />} onClick={() => fileRef.current?.click()}>Allega documento</Button>
              )}
            </div>
            <Button size="sm" loading={busy} disabled={!text.trim()} icon={<Send className="h-4 w-4" />} onClick={send}>Invia</Button>
          </div>
        </div>
      )}
    </div>
  );
}
