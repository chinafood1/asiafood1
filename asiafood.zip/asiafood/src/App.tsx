import { lazy, Suspense } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { PublicLayout } from '@/components/layout/PublicLayout';
import { PageLoader } from '@/components/ui/Layout';
import HomePage from '@/pages/HomePage';
import ExplorePage from '@/pages/ExplorePage';
import RestaurantPage from '@/pages/RestaurantPage';
import ListingPage from '@/pages/ListingPage';
import NotFoundPage from '@/pages/NotFoundPage';
import { EngagementEffects } from '@/components/engagement/EngagementEffects';
import { ErrorBoundary, MaintenanceGate, OfflineBanner, UpdatePrompt } from '@/components/platform/AppShell';
import { ConsentBanner } from '@/components/platform/ConsentBanner';
import { BetaInviteRedeemer } from '@/components/platform/BetaInvite';
import { NpsPrompt } from '@/components/launch/FeedbackWidgets';

// Pagine secondarie e aree riservate caricate on-demand (bundle iniziale leggero)
const CitiesPage = lazy(() => import('@/pages/CitiesPage'));
const OffersPage = lazy(() => import('@/pages/OffersPage'));
const MapPage = lazy(() => import('@/pages/MapPage'));
const ReservationPage = lazy(() => import('@/pages/ReservationPage'));
const ManageReservationPage = lazy(() => import('@/pages/ManageReservationPage'));
const FavoritesPage = lazy(() => import('@/pages/FavoritesPage'));
const ProfilePage = lazy(() => import('@/pages/ProfilePage'));
const ClaimPage = lazy(() => import('@/pages/ClaimPage'));
const ForRestaurantsPage = lazy(() => import('@/pages/ForRestaurantsPage'));
const PricingPage = lazy(() => import('@/pages/business/PricingPage'));
const AssistantPage = lazy(() => import('@/pages/AssistantPage'));
const TarantoLanding = lazy(() => import('@/pages/launch/TarantoLanding'));
const PressPage = lazy(() => import('@/pages/launch/PressAndAppPages').then((m) => ({ default: m.PressPage })));
const AppInstallPage = lazy(() => import('@/pages/launch/PressAndAppPages').then((m) => ({ default: m.AppInstallPage })));
const LoginPage = lazy(() => import('@/pages/AuthPages').then((m) => ({ default: m.LoginPage })));
const RegisterPage = lazy(() => import('@/pages/AuthPages').then((m) => ({ default: m.RegisterPage })));
const ResetPasswordPage = lazy(() => import('@/pages/AuthPages').then((m) => ({ default: m.ResetPasswordPage })));
const OwnerArea = lazy(() => import('@/pages/owner/OwnerArea'));
const AdminArea = lazy(() => import('@/pages/admin/AdminArea'));
const eng = () => import('@/pages/EngagementPages');
const NotificationsCenterPage = lazy(() => eng().then((m) => ({ default: m.NotificationsCenterPage })));
const NotificationSettingsPage = lazy(() => eng().then((m) => ({ default: m.NotificationSettingsPage })));
const LoyaltyPage = lazy(() => eng().then((m) => ({ default: m.LoyaltyPage })));
const RewardsPage = lazy(() => eng().then((m) => ({ default: m.RewardsPage })));
const ReferralsPage = lazy(() => eng().then((m) => ({ default: m.ReferralsPage })));
const InvitePage = lazy(() => eng().then((m) => ({ default: m.InvitePage })));
const QrRedirect = lazy(() => eng().then((m) => ({ default: m.QrRedirect })));
const ordersPages = () => import('@/pages/orders/OrderPages');
const CartPage = lazy(() => ordersPages().then((m) => ({ default: m.CartPage })));
const CheckoutPage = lazy(() => ordersPages().then((m) => ({ default: m.CheckoutPage })));
const OrderPage = lazy(() => ordersPages().then((m) => ({ default: m.OrderPage })));
const MyOrdersPage = lazy(() => ordersPages().then((m) => ({ default: m.MyOrdersPage })));
const riderPages = () => import('@/pages/rider/RiderPages');
const RiderArea = lazy(() => riderPages().then((m) => ({ default: m.RiderArea })));
const RiderHomePage = lazy(() => riderPages().then((m) => ({ default: m.RiderHomePage })));
const RiderDeliveryPage = lazy(() => riderPages().then((m) => ({ default: m.RiderDeliveryPage })));
const RiderEarningsPage = lazy(() => riderPages().then((m) => ({ default: m.RiderEarningsPage })));
const RiderApplyPage = lazy(() => riderPages().then((m) => ({ default: m.RiderApplyPage })));

const legal = () => import('@/pages/platform/LegalPages');
const PrivacyPage = lazy(() => legal().then((m) => ({ default: m.PrivacyPage })));
const CookiePolicyPage = lazy(() => legal().then((m) => ({ default: m.CookiePolicyPage })));
const TermsPage = lazy(() => legal().then((m) => ({ default: m.TermsPage })));
const BusinessTermsPage = lazy(() => legal().then((m) => ({ default: m.BusinessTermsPage })));
const RiderPrivacyPage = lazy(() => legal().then((m) => ({ default: m.RiderPrivacyPage })));
const RiderTermsPage = lazy(() => legal().then((m) => ({ default: m.RiderTermsPage })));
const privSup = () => import('@/pages/platform/PrivacySupportPages');
const PrivacySettingsPage = lazy(() => privSup().then((m) => ({ default: m.PrivacySettingsPage })));
const SupportPage = lazy(() => privSup().then((m) => ({ default: m.SupportPage })));

/** Vecchi indirizzi (/mappa, /offerte…) → nuovi, conservando i parametri di ricerca. */
function RedirectTo({ to }: { to: string }) {
  const { search } = useLocation();
  return <Navigate to={`${to}${search}`} replace />;
}

export default function App() {
  return (
    <ErrorBoundary>
    <Suspense fallback={<PageLoader />}>
      <EngagementEffects />
      <UpdatePrompt />
      <OfflineBanner />
      <ConsentBanner />
      <BetaInviteRedeemer />
      <NpsPrompt />
      <MaintenanceGate>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route index element={<HomePage />} />
          <Route path="restaurants" element={<ExplorePage />} />
          <Route path="esplora" element={<Navigate to="/restaurants" replace />} />
          <Route path="ristoranti" element={<CitiesPage />} />
          <Route path="ristoranti/:city" element={<ListingPage kind="city" />} />
          <Route path="ristorante/:slug" element={<RestaurantPage />} />
          <Route path="ristorante/:slug/rivendica" element={<ClaimPage />} />
          <Route path="ristorante/:slug/prenota" element={<ReservationPage />} />
          <Route path="prenotazione" element={<ManageReservationPage />} />
          <Route path="offers" element={<OffersPage />} />
          <Route path="offerte" element={<RedirectTo to="/offers" />} />
          <Route path="map" element={<MapPage />} />
          <Route path="assistant" element={<AssistantPage />} />
          {/* Mai ID di sessione negli URL: vecchi link → pagina dell'assistente (noindex) */}
          <Route path="assistant/session/*" element={<Navigate to="/assistant" replace />} />
          <Route path="assistente" element={<RedirectTo to="/assistant" />} />
          <Route path="mappa" element={<RedirectTo to="/map" />} />
          <Route path="restaurants/map" element={<RedirectTo to="/map" />} />
          <Route path="preferiti" element={<FavoritesPage />} />
          <Route path="profilo" element={<ProfilePage />} />
          <Route path="notifications" element={<NotificationsCenterPage />} />
          <Route path="settings/notifications" element={<NotificationSettingsPage />} />
          <Route path="settings/privacy" element={<PrivacySettingsPage />} />
          <Route path="support" element={<SupportPage />} />
          <Route path="supporto" element={<RedirectTo to="/support" />} />
          <Route path="privacy" element={<PrivacyPage />} />
          <Route path="cookie-policy" element={<CookiePolicyPage />} />
          <Route path="terms" element={<TermsPage />} />
          <Route path="business-terms" element={<BusinessTermsPage />} />
          <Route path="rider-privacy" element={<RiderPrivacyPage />} />
          <Route path="rider-terms" element={<RiderTermsPage />} />
          <Route path="profile/loyalty" element={<LoyaltyPage />} />
          <Route path="profile/referrals" element={<ReferralsPage />} />
          <Route path="rewards" element={<RewardsPage />} />
          <Route path="cart" element={<CartPage />} />
          <Route path="checkout" element={<CheckoutPage />} />
          <Route path="orders/:orderNumber" element={<OrderPage />} />
          <Route path="profile/orders" element={<MyOrdersPage />} />
          <Route path="rider/apply" element={<RiderApplyPage />} />
          <Route path="invite/:code" element={<InvitePage />} />
          <Route path="r/:slug" element={<QrRedirect />} />
          <Route path="r/:slug/:kind" element={<QrRedirect />} />
          <Route path="accedi" element={<LoginPage />} />
          <Route path="registrati" element={<RegisterPage />} />
          <Route path="reimposta-password" element={<ResetPasswordPage />} />
          <Route path="per-ristoratori" element={<ForRestaurantsPage />} />
          <Route path="business" element={<RedirectTo to="/per-ristoratori" />} />
          <Route path="taranto" element={<TarantoLanding />} />
          <Route path="launch/taranto" element={<RedirectTo to="/taranto" />} />
          <Route path="press" element={<PressPage />} />
          <Route path="app" element={<AppInstallPage />} />
          <Route path="business/pricing" element={<PricingPage />} />
          <Route path="prezzi" element={<RedirectTo to="/business/pricing" />} />
          {/* SEO: /sushi, /all-you-can-eat, /sushi/taranto … (validati contro le categorie) */}
          <Route path=":category" element={<ListingPage kind="category" />} />
          <Route path=":category/:city" element={<ListingPage kind="category-city" />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
        <Route path="rider" element={<RiderArea />}>
          <Route index element={<RiderHomePage />} />
          <Route path="delivery/:id" element={<RiderDeliveryPage />} />
          <Route path="earnings" element={<RiderEarningsPage />} />
        </Route>
        <Route path="dashboard/*" element={<OwnerArea />} />
        <Route path="admin/*" element={<AdminArea />} />
      </Routes>
      </MaintenanceGate>
    </Suspense>
    </ErrorBoundary>
  );
}
