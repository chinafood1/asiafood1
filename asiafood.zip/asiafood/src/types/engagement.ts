// ─────────────────────────────────────────────────────────────
//  Fase 7 · Fidelizzazione: tipi condivisi da UI e data source.
//  Tutti i valori "che contano" (punti, verificata, badge, referral
//  completato, invii) sono calcolati dal server: qui solo letture.
// ─────────────────────────────────────────────────────────────

export type ReviewStatus = 'pending' | 'published' | 'rejected' | 'hidden' | 'flagged';
export type ReviewSort = 'recent' | 'helpful' | 'high' | 'low';
export type ReviewFilter = 'verified' | '1' | '2' | '3' | '4' | '5' | null;
export type ReviewReportReason = 'spam' | 'offensive' | 'false_info' | 'conflict_of_interest' | 'personal_data' | 'other';

export const REVIEW_REPORT_REASONS: { value: ReviewReportReason; label: string }[] = [
  { value: 'spam', label: 'Spam o pubblicità' },
  { value: 'offensive', label: 'Linguaggio offensivo' },
  { value: 'false_info', label: 'Informazioni false' },
  { value: 'conflict_of_interest', label: 'Conflitto di interessi' },
  { value: 'personal_data', label: 'Contenuti personali' },
  { value: 'other', label: 'Altro' },
];

export const SUB_RATINGS = [
  { key: 'rating_food', label: 'Cibo' },
  { key: 'rating_service', label: 'Servizio' },
  { key: 'rating_value', label: 'Qualità/prezzo' },
  { key: 'rating_atmosphere', label: 'Atmosfera' },
] as const;
export type SubRatingKey = (typeof SUB_RATINGS)[number]['key'];

export interface RestaurantRating {
  count: number;
  average: number | null;
  verified_count: number;
  distribution: Record<'1' | '2' | '3' | '4' | '5', number>;
  food: number | null;
  service: number | null;
  value: number | null;
  atmosphere: number | null;
}

export interface ReviewItem {
  id: string;
  author: string;
  is_verified: boolean;
  verification_source: 'reservation' | 'coupon' | 'order' | null;
  rating_overall: number;
  rating_food: number | null;
  rating_service: number | null;
  rating_value: number | null;
  rating_atmosphere: number | null;
  title: string | null;
  content: string;
  is_edited: boolean;
  helpful_count: number;
  published_at: string | null;
  created_at: string;
  is_mine: boolean;
  my_vote: boolean;
  response: { content: string; updated_at: string } | null;
}

export interface ReviewInput {
  rating_overall: number;
  rating_food?: number | null;
  rating_service?: number | null;
  rating_value?: number | null;
  rating_atmosphere?: number | null;
  title?: string | null;
  content: string;
  reservation_id?: string | null;
}

export interface ReviewFormStatus {
  authenticated: boolean;
  blocked?: 'insider' | 'blocked' | 'cooldown' | 'unverified_not_allowed' | null;
  verification?: { source: 'reservation' | 'coupon' | 'order'; id: string; date: string } | null;
  allow_unverified?: boolean;
  cooldown_days?: number;
  min_length?: number;
  display_name?: string;
  existing?: (ReviewInput & { id: string; status: ReviewStatus; is_verified: boolean; created_at: string }) | null;
}

export interface ManagedReview {
  id: string;
  author: string;
  is_verified: boolean;
  rating_overall: number;
  title: string | null;
  content: string;
  status: ReviewStatus;
  is_edited: boolean;
  published_at: string | null;
  helpful_count: number;
  my_report: boolean;
  response: { content: string; updated_at: string } | null;
}

export interface AdminReview {
  id: string;
  restaurant: { id: string; name: string; slug: string };
  author: string;
  user_id: string;
  rating_overall: number;
  title: string | null;
  content: string;
  is_verified: boolean;
  verification_source: string | null;
  status: ReviewStatus;
  moderation_flags: string[];
  moderation_note: string | null;
  is_edited: boolean;
  created_at: string;
  published_at: string | null;
  reports_open: number;
  reports: { reason: ReviewReportReason; details: string | null; status: string; created_at: string }[];
}

// ─── Loyalty ─────────────────────────────────────────────────
export interface LoyaltyTransaction {
  id: string;
  type: 'earn' | 'redeem' | 'expire' | 'adjustment' | 'bonus' | 'referral';
  points: number;
  balance_after: number;
  event_key: string;
  source_type: string;
  description: string | null;
  created_at: string;
  expires_at: string | null;
}

export interface LoyaltyWallet {
  program_name: string;
  enabled: boolean;
  balance: number;
  lifetime: number;
  level: string;
  level_min: number | null;
  next_level: { name: string; min: number; missing: number } | null;
  expire_months: number | null;
  expiring_soon: number;
  transactions: LoyaltyTransaction[];
  transactions_total: number;
  redemptions: { id: string; redemption_code: string; status: 'claimed' | 'used' | 'expired' | 'cancelled'; points_spent: number; created_at: string; expires_at: string | null; title: string; reward_type: string; restaurant_slug: string | null }[];
  rules: { event_key: string; points: number; description: string | null }[];
}

export type RewardType = 'platform_coupon' | 'restaurant_coupon' | 'bonus' | 'perk' | 'other';
export interface Reward {
  id: string;
  title: string;
  description: string | null;
  points_cost: number;
  reward_type: RewardType;
  restaurant_id: string | null;
  coupon_id: string | null;
  stock: number | null;
  per_user_limit: number | null;
  starts_at: string;
  ends_at: string | null;
  is_active: boolean;
  image_url: string | null;
  terms: string | null;
}

export interface RedeemResult {
  redemption_id: string;
  code: string;
  title: string;
  points_spent: number;
  balance: number;
  expires_at: string | null;
}

export interface Achievement {
  id: string;
  key: string;
  name: string;
  description: string | null;
  icon: string | null;
  points_bonus: number;
  earned_at: string | null;
}

// ─── Referral ────────────────────────────────────────────────
export interface ReferralSummary {
  code: string;
  enabled: boolean;
  registered: number;
  qualified: number;
  points: number;
  reward_points: number | null;
  welcome_points: number | null;
  referred_by_me: boolean;
  items: { status: string; registered_at: string | null; qualified_at: string | null; name: string | null }[];
}

export interface AdminReferral {
  id: string;
  status: 'invited' | 'registered' | 'qualified' | 'rewarded' | 'invalid';
  code: string;
  created_at: string;
  registered_at: string | null;
  qualified_at: string | null;
  rewarded_at: string | null;
  invalid_reason: string | null;
  referrer: string;
  referrer_id: string;
  referred: string | null;
  referred_id: string | null;
  email_verified: boolean | null;
}

export interface BusinessReferral {
  id: string;
  referrer_restaurant_id: string;
  referred_business_email: string;
  referred_business_name: string | null;
  referred_restaurant_id: string | null;
  code: string;
  status: 'invited' | 'registered' | 'qualified' | 'approved' | 'rewarded' | 'rejected';
  qualified_at: string | null;
  reward_type: 'trial_extension' | 'promo_months' | 'sponsorship_credits' | 'manual_admin_reward' | null;
  reward_value: number | null;
  admin_note: string | null;
  created_at: string;
}

// ─── Notifiche ───────────────────────────────────────────────
export interface NotificationPrefs {
  reservation_updates: boolean;
  reservation_reminders: boolean;
  coupon_expiry: boolean;
  loyalty_updates: boolean;
  referral_updates: boolean;
  new_offers: boolean;
  favorite_restaurants: boolean;
  marketing: boolean;
  push_enabled: boolean;
  email_enabled: boolean;
  push_prompt_dismissed_at: string | null;
}

export const DEFAULT_PREFS: NotificationPrefs = {
  reservation_updates: true,
  reservation_reminders: true,
  coupon_expiry: true,
  loyalty_updates: true,
  referral_updates: true,
  new_offers: false,
  favorite_restaurants: false,
  marketing: false,
  push_enabled: false,
  email_enabled: true,
  push_prompt_dismissed_at: null,
};

export interface PushSubscriptionInput {
  endpoint: string;
  p256dh: string;
  auth: string;
  device?: string | null;
  platform?: string | null;
}

// ─── Campagne ────────────────────────────────────────────────
export type CampaignTarget =
  | 'followers' | 'coupon_users' | 'past_customers' | 'all_eligible'
  | 'all_users' | 'city' | 'favorite_category' | 'upcoming_reservation' | 'active_users' | 'loyalty_level';
export type CampaignChannel = 'in_app' | 'push' | 'email';
export type CampaignStatus = 'draft' | 'scheduled' | 'sending' | 'sent' | 'cancelled' | 'failed';

export const RESTAURANT_TARGETS: { value: CampaignTarget; label: string; hint: string }[] = [
  { value: 'followers', label: 'Chi segue il locale', hint: 'Persone che hanno scelto di ricevere le tue novità' },
  { value: 'coupon_users', label: 'Chi ha usato i tuoi coupon', hint: 'Solo chi ha accettato le comunicazioni promozionali' },
  { value: 'past_customers', label: 'Clienti passati', hint: 'Visite completate, solo con consenso promozionale' },
  { value: 'all_eligible', label: 'Tutti i contatti idonei', hint: 'Unione dei gruppi precedenti, sempre con consenso' },
];
export const PLATFORM_TARGETS: { value: CampaignTarget; label: string }[] = [
  { value: 'all_users', label: 'Tutti gli utenti (con consenso)' },
  { value: 'city', label: 'Comune' },
  { value: 'favorite_category', label: 'Categoria nei preferiti' },
  { value: 'upcoming_reservation', label: 'Con prenotazione nei prossimi 7 giorni' },
  { value: 'active_users', label: 'Attivi negli ultimi 30 giorni' },
  { value: 'loyalty_level', label: 'Livello AsiaPoints' },
];

export interface Campaign {
  id: string;
  scope: 'platform' | 'restaurant';
  restaurant_id: string | null;
  title: string;
  message: string;
  action_url: string | null;
  target: CampaignTarget;
  targeting: Record<string, string>;
  channels: CampaignChannel[];
  send_at: string;
  status: CampaignStatus;
  recipients_count: number;
  error: string | null;
  created_at: string;
  sent_at: string | null;
}

export interface CampaignInput {
  scope: 'platform' | 'restaurant';
  restaurant_id?: string | null;
  title: string;
  message: string;
  action_url?: string | null;
  target: CampaignTarget;
  targeting?: Record<string, string>;
  channels: CampaignChannel[];
  send_at?: string | null;
  status?: 'draft' | 'scheduled';
}

export interface PushCampaignStats {
  recipients: number;
  sent: number;
  delivered: number;
  opened: number;
  clicked: number;
  skipped: number;
  failed: number;
  ctr: number;
  by_channel: Record<string, number>;
}

// ─── Statistiche ─────────────────────────────────────────────
export interface RetentionStats {
  definitions: Record<string, string>;
  dau: number;
  wau: number;
  mau: number;
  returning_users: number;
  previous_period_users: number;
  repeat_reservation_users: number;
  reservation_users: number;
  completed_reservations: number;
  reviews_published: number;
  reviews_verified: number;
  reviews_pending: number;
  referral_signups: number;
  referral_qualified: number;
  points_issued: number;
  points_redeemed: number;
  rewards_redeemed: number;
  push_subscribers: number;
  coupon_users: number;
  coupon_repeat_users: number;
  followers: number;
  daily: { day: string; active: number }[];
}

export interface RestaurantEngagementStats {
  rating: RestaurantRating;
  followers: number;
  favorites: number;
  customers: number;
  returning_customers: number;
  coupon_redemptions: number;
  campaign_sends: number;
  campaign_clicks: number;
}

export interface EngagementTickResult {
  reservation_reminders: number;
  guest_reminders: number;
  coupon_reminders: number;
  review_requests: number;
  referrals_qualified: number;
  campaigns: number;
  points_expired: number;
}
