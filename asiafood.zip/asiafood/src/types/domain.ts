// ─────────────────────────────────────────────────────────────
//  Tipi di dominio — rispecchiano 1:1 le tabelle Supabase
//  (snake_case volutamente mantenuto per evitare mapping).
// ─────────────────────────────────────────────────────────────

export type UUID = string;
export type ISODate = string;

export type UserRole = 'customer' | 'restaurant_owner' | 'admin' | 'rider';
export type ClaimStatus = 'pending' | 'under_review' | 'more_information_required' | 'approved' | 'rejected';
export const OPEN_CLAIM_STATUSES: ClaimStatus[] = ['pending', 'under_review', 'more_information_required'];
export type DataStatus = 'verified' | 'partially_verified' | 'unverified' | 'claimed' | 'outdated';
export type VerificationMethod = 'email' | 'phone' | 'document' | 'manual';
export type MemberRole = 'owner' | 'manager' | 'staff';
export type MemberStatus = 'active' | 'invited' | 'revoked';
export type SourceType = 'google_business' | 'official_website' | 'facebook' | 'instagram' | 'directory' | 'owner' | 'admin' | 'import' | 'other';
export type ReportType = 'wrong_address' | 'wrong_phone' | 'wrong_hours' | 'closed' | 'wrong_menu' | 'wrong_price' | 'other';
export type ReportStatus = 'open' | 'in_progress' | 'resolved' | 'dismissed';
export type AppEventType =
  | 'map_open'
  // Fase 13: sessione, preferito, condivisione invito, conversione (solo funnel per sessione)
  | 'session_started'
  | 'favorite_added'
  | 'referral_shared'
  | 'conversion'
  | 'location_permission_requested'
  | 'location_permission_granted'
  | 'location_permission_denied'
  | 'restaurant_marker_click'
  | 'directions_click'
  | 'near_me_search'
  | 'map_area_search'
  // Fase 12
  | 'search'
  | 'landing_view'
  | 'install_prompt_shown'
  | 'install_accepted'
  | 'experiment_exposure'
  | 'qr_kit_download'
  | 'feedback_opened';
export type ChangeRequestStatus = 'pending' | 'approved' | 'rejected';
export type DiscountType = 'percent' | 'amount' | 'fixed_price' | 'free_item' | 'other';
export type SponsoredPlacement = 'home_hero' | 'home_featured' | 'search_top' | 'category_top' | 'city_top' | 'map_featured' | 'offers_featured';
export type MenuType = 'a_la_carte' | 'lunch' | 'dinner' | 'all_you_can_eat' | 'takeaway' | 'delivery' | 'drinks' | 'dessert' | 'seasonal' | 'other';
export type OfferType = 'percentage' | 'fixed_amount' | 'special_menu' | 'two_for_one' | 'happy_hour' | 'ayce_promo' | 'free_dish' | 'other';
export type ReservationStatus = 'pending' | 'confirmed' | 'rejected' | 'cancelled' | 'completed' | 'no_show';
export type ReservationSource = 'web' | 'app' | 'admin' | 'restaurant' | 'ai';
export type CouponClaimStatus = 'claimed' | 'redeemed' | 'expired' | 'cancelled';
/** I 14 allergeni del Reg. UE 1169/2011. */
export type AllergenCode =
  | 'gluten' | 'crustaceans' | 'eggs' | 'fish' | 'peanuts' | 'soy' | 'milk'
  | 'nuts' | 'celery' | 'mustard' | 'sesame' | 'sulphites' | 'lupin' | 'molluscs';
export type PlanCode = 'free' | 'business' | 'premium' | 'top';
/** Eventi analytics (Fase 4). Le conversioni (prenotazione, coupon) le registra solo il server. */
export type AnalyticsEventType =
  | 'restaurant_view'
  | 'phone_click'
  | 'whatsapp_click'
  | 'directions_click'
  | 'menu_view'
  | 'reservation_start'
  | 'reservation_completed'
  | 'offer_view'
  | 'coupon_claim'
  | 'coupon_redeem'
  | 'website_click'
  | 'instagram_click'
  | 'social_click'
  | 'map_view'
  | 'map_marker_click'
  | 'sponsored_impression'
  | 'sponsored_click'
  | 'ai_chat_open'
  | 'ai_message_sent'
  | 'ai_result_click'
  | 'ai_map_open'
  | 'ai_reservation_click'
  | 'ai_offer_click'
  | 'ai_no_results'
  // Fase 8: funnel ordini (i passi di pagamento/ordine li registra solo il server)
  | 'menu_item_view'
  | 'add_to_cart'
  | 'remove_from_cart'
  | 'cart_view'
  | 'checkout_started'
  | 'address_added'
  | 'coupon_applied'
  | 'payment_started'
  | 'reorder'
  | 'payment_success'
  | 'payment_failed'
  | 'order_created'
  | 'order_accepted'
  | 'order_completed'
  | 'order_cancelled'
  | 'abandoned_cart';

export interface Region {
  id: UUID;
  name: string;
  slug: string;
  code: string | null;
  country_code: string;
  is_active: boolean;
  sort_order: number;
}

export interface Province {
  id: UUID;
  region_id: UUID;
  name: string;
  slug: string;
  code: string;
  is_active: boolean;
}

export interface City {
  id: UUID;
  province_id: UUID;
  region_id: UUID;
  name: string;
  slug: string;
  istat_code: string | null;
  postal_code: string | null;
  latitude: number | null;
  longitude: number | null;
  population: number | null;
  is_active: boolean;
  is_launch_market: boolean;
}

export interface Category {
  id: UUID;
  name: string;
  slug: string;
  emoji: string | null;
  description: string | null;
  seo_title: string | null;
  seo_description: string | null;
  image_url: string | null;
  sort_order: number;
  is_active: boolean;
}

export interface SubscriptionPlan {
  id: UUID;
  code: PlanCode;
  name: string;
  description: string | null;
  monthly_price: number;
  yearly_price: number | null;
  currency: string;
  features: Record<string, unknown>;
  sort_order: number;
  is_active: boolean;
  // ─── Fase 5: Stripe (ID pubblici di prodotto/prezzo, nessun segreto) ───
  stripe_product_id?: string | null;
  stripe_monthly_price_id?: string | null;
  stripe_yearly_price_id?: string | null;
  trial_enabled?: boolean;
}

export interface Profile {
  id: UUID;
  role: UserRole;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  avatar_url: string | null;
  city_id: UUID | null;
  is_blocked: boolean;
  created_at: ISODate;
  /** Nome mostrato nelle recensioni (facoltativo; altrimenti "Nome I."). */
  display_name?: string | null;
  marketing_opt_in?: boolean;
}

export interface Restaurant {
  id: UUID;
  owner_id: UUID | null;
  name: string;
  slug: string;
  short_description: string | null;
  description: string | null;
  address: string | null;
  city_id: UUID;
  province_id: UUID | null;
  region_id: UUID | null;
  postal_code: string | null;
  latitude: number | null;
  longitude: number | null;
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  website: string | null;
  instagram: string | null;
  facebook: string | null;
  tiktok: string | null;
  logo_url: string | null;
  cover_url: string | null;
  price_range: 1 | 2 | 3 | 4 | null;
  average_price: number | null;
  is_all_you_can_eat: boolean;
  ayce_lunch_price: number | null;
  ayce_dinner_price: number | null;
  ayce_weekend_price: number | null;
  has_delivery: boolean;
  has_takeaway: boolean;
  has_reservation: boolean;
  reservation_url: string | null;
  services: string[];
  timezone: string;
  is_verified: boolean;
  is_active: boolean;
  is_featured: boolean;
  is_sponsored: boolean;
  is_demo: boolean;
  subscription_plan: PlanCode;
  popularity_score: number;
  opened_at: ISODate | null;
  meta_title: string | null;
  meta_description: string | null;
  // ─── Fase 2: provenienza e affidabilità del dato ───
  source_name: string | null;
  source_url: string | null;
  external_id: string | null;
  google_place_id: string | null;
  data_status: DataStatus;
  last_verified_at: ISODate | null;
  claimed_at: ISODate | null;
  claimed_by: UUID | null;
  verification_notes: string | null;
  menu_last_verified_at: ISODate | null;
  opening_hours_last_verified_at: ISODate | null;
  is_temporarily_closed: boolean;
  is_permanently_closed: boolean;
  created_at: ISODate;
  updated_at: ISODate;
  // ─── Fase 5: onboarding ───
  onboarding_completed_at?: ISODate | null;
  publication_requested_at?: ISODate | null;
}

export interface RestaurantCategory {
  restaurant_id: UUID;
  category_id: UUID;
  is_primary: boolean;
}

export interface RestaurantImage {
  id: UUID;
  restaurant_id: UUID;
  url: string;
  storage_path: string | null;
  alt: string | null;
  kind: 'gallery' | 'dish' | 'interior' | 'exterior' | 'menu';
  sort_order: number;
}

export interface RestaurantHour {
  id: UUID;
  restaurant_id: UUID;
  day_of_week: number; // 1 = lunedì … 7 = domenica (ISO)
  opens_at: string | null; // 'HH:MM' o 'HH:MM:SS'
  closes_at: string | null;
  is_closed: boolean;
  label: string | null;
}

export interface Menu {
  id: UUID;
  restaurant_id: UUID;
  name: string;
  description: string | null;
  menu_type: MenuType;
  price: number | null;
  is_active: boolean;
  /** false = nascosto al pubblico (bozza), visibile solo al locale. */
  is_public: boolean;
  valid_from: string | null; // 'YYYY-MM-DD'
  valid_until: string | null;
  sort_order: number;
}

export interface MenuCategory {
  id: UUID;
  menu_id: UUID;
  restaurant_id: UUID;
  name: string;
  description: string | null;
  is_active: boolean;
  sort_order: number;
}

export interface MenuItem {
  id: UUID;
  menu_category_id: UUID;
  restaurant_id: UUID;
  name: string;
  description: string | null;
  price: number | null;
  image_url: string | null;
  pieces: number | null;
  /** Codici allergene (AllergenCode). */
  allergens: string[];
  /** Etichette libere (es. signature). I flag dietetici sono campi dedicati. */
  tags: string[];
  ingredients: string[];
  discount_price: number | null;
  is_available: boolean;
  is_featured: boolean;
  is_spicy: boolean;
  is_vegetarian: boolean;
  is_vegan: boolean;
  is_gluten_free: boolean;
  is_ayce_included: boolean;
  ayce_limit: number | null;
  sort_order: number;
  /** Fase 8: "non disponibile oggi" (torna disponibile a questa data). */
  unavailable_until?: string | null;
}

/** Variante di un piatto (es. 4 / 8 / 12 pezzi, Small / Large). */
export interface MenuItemVariant {
  id: UUID;
  menu_item_id: UUID;
  restaurant_id: UUID;
  name: string;
  price: number | null;
  is_available: boolean;
  display_order: number;
}

/** Extra facoltativo (es. Extra salmone). */
export type MenuItemAddon = MenuItemVariant;

export interface MenuItemFull extends MenuItem {
  variants: MenuItemVariant[];
  addons: MenuItemAddon[];
}

export interface Offer {
  id: UUID;
  restaurant_id: UUID;
  title: string;
  description: string | null;
  offer_type: OfferType;
  discount_type: DiscountType;
  discount_value: number | null;
  minimum_spend: number | null;
  image_url: string | null;
  days_of_week: number[];
  /** Fascia oraria (es. happy hour 18:00–20:00); entrambe null = tutto il giorno. */
  start_time: string | null;
  end_time: string | null;
  starts_at: ISODate;
  ends_at: ISODate | null;
  terms: string | null;
  is_active: boolean;
  is_featured: boolean;
  max_redemptions: number | null;
  redemptions_count: number;
}

export interface Coupon {
  id: UUID;
  restaurant_id: UUID;
  offer_id: UUID | null;
  code: string;
  title: string;
  description: string | null;
  discount_type: DiscountType;
  discount_value: number | null;
  minimum_spend: number | null;
  /** Numero massimo di codici distribuiti (null = illimitato). */
  max_redemptions: number | null;
  max_redemptions_per_user: number;
  claims_count: number;
  redemptions_count: number;
  valid_from: ISODate;
  valid_until: ISODate | null;
  terms: string | null;
  is_active: boolean;
}

/** Coupon ottenuto da un cliente: codice personale da mostrare in cassa. */
export interface CouponClaim {
  id: UUID;
  coupon_id: UUID;
  restaurant_id: UUID;
  user_id: UUID | null;
  email: string | null;
  claim_code: string;
  status: CouponClaimStatus;
  claimed_at: ISODate;
  redeemed_at: ISODate | null;
  /** Origine: sito, app o assistente AI (attribuzione). */
  source?: 'web' | 'app' | 'ai';
}

export interface CouponClaimView extends CouponClaim {
  coupon: Pick<Coupon, 'id' | 'title' | 'description' | 'discount_type' | 'discount_value' | 'minimum_spend' | 'valid_until' | 'terms'> | null;
  restaurant: Pick<Restaurant, 'id' | 'name' | 'slug'> | null;
}

export interface ClaimCouponResult {
  claim_code: string;
  status: CouponClaimStatus;
  already: boolean;
  claimed_at: ISODate;
  valid_until: ISODate | null;
  title: string;
  restaurant_name: string;
  restaurant_slug: string;
}

export interface CouponCheck {
  found: boolean;
  claim_code?: string;
  status?: CouponClaimStatus;
  claimed_at?: ISODate;
  redeemed_at?: ISODate | null;
  title?: string;
  description?: string | null;
  discount_type?: DiscountType;
  discount_value?: number | null;
  minimum_spend?: number | null;
  valid_until?: ISODate | null;
  coupon_active?: boolean;
}

// ─── Prenotazioni ────────────────────────────────────────────
export interface ReservationSettings {
  restaurant_id: UUID;
  reservation_enabled: boolean;
  min_party_size: number;
  max_party_size: number;
  slot_duration_minutes: number;
  booking_notice_minutes: number;
  max_advance_days: number;
  auto_confirm: boolean;
  guest_message: string | null;
}

/** Fascia di servizio: orari ogni `slot_interval_minutes` tra start e end. */
export interface ReservationSlot {
  id: UUID;
  restaurant_id: UUID;
  day_of_week: number; // 1 = lunedì … 7 = domenica
  start_time: string; // 'HH:MM'
  end_time: string;
  slot_interval_minutes: number;
  /** Prenotazioni massime per singolo orario (null = senza limite). */
  max_reservations: number | null;
  /** Coperti massimi per l'intera fascia (null = senza limite). */
  max_guests: number | null;
  is_active: boolean;
  label: string | null;
}

export interface RestaurantClosure {
  id: UUID;
  restaurant_id: UUID;
  date: string; // 'YYYY-MM-DD'
  start_time: string | null;
  end_time: string | null;
  reason: string | null;
}

export interface Reservation {
  id: UUID;
  /** Momento in cui il ristorante ha segnato la visita come completata (Fase 7). */
  completed_at?: ISODate | null;
  restaurant_id: UUID;
  user_id: UUID | null;
  guest_name: string;
  guest_surname: string;
  /** Null solo per prenotazioni inserite a mano dal ristorante. */
  guest_email: string | null;
  guest_phone: string;
  reservation_date: string; // 'YYYY-MM-DD'
  reservation_time: string; // 'HH:MM' o 'HH:MM:SS'
  party_size: number;
  notes: string | null;
  status: ReservationStatus;
  source: ReservationSource;
  confirmation_code: string;
  internal_notes: string | null;
  created_at: ISODate;
  confirmed_at: ISODate | null;
  cancelled_at: ISODate | null;
}

export interface ReservationWithRestaurant extends Reservation {
  restaurant: Pick<Restaurant, 'id' | 'name' | 'slug' | 'phone'> | null;
}

export type SlotStatus = 'available' | 'full' | 'closed' | 'too_soon';
export interface Availability {
  ok: boolean;
  reason: string | null;
  slots: { time: string; status: SlotStatus }[];
  auto_confirm?: boolean;
  guest_message?: string | null;
}

export interface ReservationInput {
  restaurant_id: UUID;
  date: string;
  time: string;
  party_size: number;
  guest_name: string;
  guest_surname: string;
  guest_email: string;
  guest_phone: string;
  notes?: string | null;
  source?: ReservationSource;
}

export interface ReservationResult {
  id: UUID;
  code: string;
  status: ReservationStatus;
  reservation_date: string;
  reservation_time: string;
  party_size: number;
  restaurant_name: string;
  restaurant_slug: string;
  guest_name: string;
}

// ─── Piani, notifiche, analytics ─────────────────────────────
export interface PlanFeature {
  id: UUID;
  plan_code: PlanCode;
  feature_key: string;
  enabled: boolean;
  /** null = illimitato. */
  limit_value: number | null;
}

export interface PlanWithFeatures extends SubscriptionPlan {
  plan_features: PlanFeature[];
}

export interface PlanUpgradeRequest {
  id: UUID;
  restaurant_id: UUID;
  user_id: UUID;
  plan_code: PlanCode;
  billing_interval: 'month' | 'year';
  message: string | null;
  status: 'open' | 'contacted' | 'closed';
  created_at: ISODate;
  restaurant?: Pick<Restaurant, 'id' | 'name' | 'slug' | 'subscription_plan'> | null;
  requester?: Pick<Profile, 'id' | 'full_name' | 'email'> | null;
}

export interface AppNotification {
  id: UUID;
  user_id: UUID;
  restaurant_id: UUID | null;
  type: string;
  title: string;
  body: string | null;
  link: string | null;
  read_at: ISODate | null;
  created_at: ISODate;
  metadata?: Record<string, unknown>;
}

export interface RestaurantAnalytics {
  days: number;
  advanced: boolean;
  events: Partial<Record<AnalyticsEventType, number>>;
  reservations: { total: number; manual: number; pending: number; confirmed: number; completed: number; no_show: number; cancelled: number; covers: number };
  coupons: { claimed: number; redeemed: number };
  daily: { date: string; views: number; contacts: number }[];
  sources: Record<string, number>;
}

export interface RestaurantClaim {
  id: UUID;
  restaurant_id: UUID;
  user_id: UUID;
  status: ClaimStatus;
  first_name: string;
  last_name: string;
  role: string | null;
  business_name: string | null;
  vat_number: string | null;
  tax_code: string | null;
  business_email: string;
  phone: string;
  website: string | null;
  verification_method: VerificationMethod;
  /** Path nel bucket privato "claim-documents" (mai un URL pubblico). */
  verification_document_url: string | null;
  message: string | null;
  admin_notes: string | null;
  submitted_at: ISODate;
  reviewed_at: ISODate | null;
  reviewed_by: UUID | null;
  approved_at: ISODate | null;
  rejected_at: ISODate | null;
  info_requested_at: ISODate | null;
  created_at: ISODate;
}

export interface ClaimMessage {
  id: UUID;
  claim_id: UUID;
  author_id: UUID | null;
  author_role: 'admin' | 'claimant';
  body: string;
  attachment_path: string | null;
  created_at: ISODate;
}

export interface RestaurantMember {
  id: UUID;
  restaurant_id: UUID;
  user_id: UUID;
  role: MemberRole;
  status: MemberStatus;
  created_at: ISODate;
}

export interface RestaurantSource {
  id: UUID;
  restaurant_id: UUID;
  source_type: SourceType;
  source_name: string | null;
  source_url: string | null;
  external_id: string | null;
  is_primary: boolean;
  notes: string | null;
  last_checked_at: ISODate | null;
  import_batch_id: UUID | null;
  created_at: ISODate;
  updated_at: ISODate;
}

export interface RestaurantReport {
  id: UUID;
  restaurant_id: UUID;
  user_id: UUID | null;
  report_type: ReportType;
  description: string;
  email: string | null;
  status: ReportStatus;
  admin_notes: string | null;
  resolved_by: UUID | null;
  resolved_at: ISODate | null;
  created_at: ISODate;
}

export interface ImportBatch {
  id: UUID;
  created_by: UUID | null;
  file_name: string | null;
  format: 'csv' | 'json' | null;
  total_rows: number;
  created_count: number;
  updated_count: number;
  merged_count: number;
  skipped_count: number;
  error_count: number;
  errors: { row: number; name?: string; message: string }[];
  options: Record<string, unknown>;
  created_at: ISODate;
}

// ═══ Fase 5: abbonamenti e fatturazione ═══════════════════════
export type SubscriptionStatus = 'trialing' | 'active' | 'past_due' | 'unpaid' | 'canceled' | 'incomplete' | 'incomplete_expired' | 'paused' | 'free';
export type SubscriptionSource = 'stripe' | 'manual' | 'promo' | 'admin';
export type BillingInterval = 'month' | 'year';

export interface Subscription {
  id: UUID;
  restaurant_id: UUID;
  user_id: UUID | null;
  billing_account_id: UUID | null;
  plan_id: UUID | null;
  plan_code: PlanCode;
  status: SubscriptionStatus;
  source: SubscriptionSource;
  billing_interval: BillingInterval;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  stripe_price_id: string | null;
  stripe_environment: 'test' | 'live' | null;
  trial_start: ISODate | null;
  trial_end: ISODate | null;
  current_period_start: ISODate;
  current_period_end: ISODate | null;
  cancel_at_period_end: boolean;
  cancelled_at: ISODate | null;
  ended_at: ISODate | null;
  expires_at: ISODate | null;
  revoked_at: ISODate | null;
  unit_amount_cents: number | null;
  currency: string | null;
  payment_failed_at: ISODate | null;
  paid_started_at: ISODate | null;
  pm_brand: string | null;
  pm_last4: string | null;
  pm_exp_month: number | null;
  pm_exp_year: number | null;
  latest_invoice_id: string | null;
  latest_invoice_status: string | null;
  scheduled_plan_code: PlanCode | null;
  scheduled_interval: BillingInterval | null;
  scheduled_change_at: ISODate | null;
  stripe_schedule_id: string | null;
  trial_expiring_notified_at: ISODate | null;
  last_synced_at: ISODate | null;
  notes?: string | null;
  created_at: ISODate;
  updated_at: ISODate;
}

/** Dati di fatturazione (privati, mai pubblici). Predisposti per la fatturazione elettronica italiana. */
export interface BillingAccount {
  id: UUID;
  owner_user_id: UUID;
  stripe_customer_id: string | null;
  stripe_environment: 'test' | 'live' | null;
  business_name: string | null;
  vat_number: string | null;
  tax_code: string | null;
  billing_email: string | null;
  pec: string | null;
  recipient_code: string | null;
  address_line: string | null;
  postal_code: string | null;
  city: string | null;
  province: string | null;
  country: string;
  created_at: ISODate;
  updated_at: ISODate;
}

export type BillingAccountInput = Pick<BillingAccount,
  'business_name' | 'vat_number' | 'tax_code' | 'billing_email' | 'pec' | 'recipient_code' | 'address_line' | 'postal_code' | 'city' | 'province' | 'country'>;

export interface BillingInvoice {
  id: UUID;
  stripe_invoice_id: string;
  subscription_id: UUID | null;
  restaurant_id: UUID | null;
  billing_account_id: UUID | null;
  number: string | null;
  status: string;
  amount_due_cents: number;
  amount_paid_cents: number;
  currency: string;
  hosted_invoice_url: string | null;
  invoice_pdf: string | null;
  period_start: ISODate | null;
  period_end: ISODate | null;
  stripe_created_at: ISODate;
  stripe_environment: 'test' | 'live' | null;
}

export type BillingActivityEvent =
  | 'trial_started' | 'trial_expiring' | 'trial_ended' | 'trial_extended'
  | 'subscription_started' | 'subscription_upgraded' | 'subscription_downgraded' | 'interval_changed'
  | 'change_scheduled' | 'change_cancelled' | 'subscription_cancelled' | 'subscription_resumed' | 'subscription_ended'
  | 'payment_succeeded' | 'payment_failed' | 'payment_recovered' | 'payment_action_required'
  | 'plan_granted' | 'plan_revoked' | 'duplicate_subscription' | 'email_error';

export interface BillingActivity {
  event: BillingActivityEvent;
  data: Record<string, unknown>;
  created_at: ISODate;
}

/** Vista "Fatturazione" del locale: letta dal DB sincronizzato, mai da Stripe a ogni render. */
export interface BillingOverview {
  effective_plan: PlanCode;
  effective: Subscription | null;
  stripe: Subscription | null;
  can_manage_billing: boolean;
  trial_eligible: boolean;
  trial_days: number;
  require_payment_method_for_trial: boolean;
  grace_days: number;
  trial_expiring_days: number;
  invoices: BillingInvoice[];
  activity: BillingActivity[];
}

export interface ChangePreview {
  kind: 'upgrade' | 'downgrade' | 'interval_up' | 'interval_down';
  immediate: boolean;
  trialing: boolean;
  amount_due_cents: number;
  currency: string;
  charged_now?: boolean;
  effective_at: ISODate | null;
  target: { plan_code: PlanCode; plan_name: string; interval: BillingInterval; amount: number };
}

export interface CheckoutConfirmation {
  status: 'complete' | 'open' | 'expired' | string;
  payment_status: string;
  restaurant_id: UUID;
  plan_code: PlanCode | null;
  billing_interval: BillingInterval | null;
  subscription_status: SubscriptionStatus | null;
  effective_plan: PlanCode | null;
  /** Solo modalità DEMO: giorni di prova e carta obbligatoria della sessione simulata. */
  trial_days?: number;
  require_payment_method?: boolean;
}

export interface BillingSettings {
  billing_trial_days: number;
  billing_require_payment_method_for_trial: boolean;
  billing_payment_grace_period_days: number;
  billing_trial_expiring_days: number;
  billing_proration_behavior: 'always_invoice' | 'create_prorations' | 'none';
  billing_downgrade_timing: 'period_end' | 'immediate';
  billing_stripe_environment: 'test' | 'live' | null;
}

export interface BillingPromotion {
  id: UUID;
  code: string;
  description: string | null;
  discount_type: 'percent' | 'amount' | 'free_days';
  discount_value: number | null;
  duration: 'once' | 'repeating' | 'forever';
  duration_in_months: number | null;
  free_days: number | null;
  applicable_plans: PlanCode[];
  max_redemptions: number | null;
  redemptions_count: number;
  starts_at: ISODate;
  ends_at: ISODate | null;
  is_active: boolean;
  created_at: ISODate;
}

export interface StripeEventLog {
  id: UUID;
  stripe_event_id: string;
  event_type: string;
  stripe_environment: 'test' | 'live' | null;
  object_id: string | null;
  restaurant_id: UUID | null;
  processing_status: 'processing' | 'processed' | 'failed' | 'ignored';
  error_message: string | null;
  attempts: number;
  created_at: ISODate;
  processed_at: ISODate | null;
}

export interface AdminSubscriptionRow extends Subscription {
  restaurant: { id: UUID; name: string; slug: string; subscription_plan: PlanCode } | null;
  owner: { id: UUID; full_name: string | null; email: string | null } | null;
  last_invoice: Pick<BillingInvoice, 'number' | 'status' | 'amount_paid_cents' | 'amount_due_cents' | 'hosted_invoice_url' | 'stripe_created_at'> | null;
}

export interface RevenueStats {
  environment: 'test' | 'live' | null;
  restaurants_total: number;
  restaurants_claimed: number;
  plans: Record<string, number>;
  paying_customers: number;
  paying_subscriptions: number;
  mrr_cents: number;
  arr_cents: number;
  new_mrr_cents: number;
  churned_mrr_cents: number;
  trials_active: number;
  trials_ended: number;
  trials_converted: number;
  trial_conversion_rate: number | null;
  cancel_scheduled: number;
  cancelled_30d: number;
  past_due: number;
  manual_active: number;
  mrr_series: { month: string; mrr_cents: number }[];
}

export type CompletionKey = 'name' | 'phone' | 'address' | 'logo' | 'cover' | 'hours' | 'categories' | 'menu' | 'photos' | 'offer' | 'reservations';
export interface ProfileCompletion {
  items: { key: CompletionKey; done: boolean; available: boolean; feature?: string }[];
  done: number;
  total: number;
  profile_completion_percentage: number;
  onboarding_completed_at: ISODate | null;
  is_active: boolean;
  publication_requested_at: ISODate | null;
}

// ═══ Fase 5: sponsorizzazioni (AsiaFood Ads) ════════════════════
export type CampaignStatus = 'draft' | 'scheduled' | 'active' | 'paused' | 'ended';
export interface SponsoredCampaign {
  id: UUID;
  restaurant_id: UUID;
  name: string;
  status: CampaignStatus;
  placement: SponsoredPlacement;
  start_date: string; // YYYY-MM-DD
  end_date: string | null;
  daily_budget: number | null;
  total_budget: number | null;
  spend: number;
  priority: number;
  target_cities: UUID[];
  target_categories: UUID[];
  notes: string | null;
  created_at: ISODate;
  updated_at: ISODate;
}

export interface CampaignStats {
  campaign_id: UUID;
  restaurant_id: UUID;
  restaurant_name: string;
  name: string;
  placement: SponsoredPlacement;
  status: CampaignStatus;
  display_status: CampaignStatus;
  start_date: string;
  end_date: string | null;
  priority: number;
  daily_budget: number | null;
  total_budget: number | null;
  spend: number;
  impressions: number;
  clicks: number;
  ctr: number;
}

/** Slot sponsorizzato: separato dai risultati organici, sempre etichettato. */
export interface SponsoredSlot {
  campaign_id: UUID;
  placement: SponsoredPlacement;
  restaurant: RestaurantSummary;
}

// ─── Modelli composti usati dalla UI ─────────────────────────

/** Ristorante "da card": dati base + relazioni leggere. */
export interface RestaurantSummary extends Restaurant {
  city: Pick<City, 'id' | 'name' | 'slug'> | null;
  categories: Pick<Category, 'id' | 'name' | 'slug' | 'emoji'>[];
  hours: RestaurantHour[];
  active_offers_count: number;
  /** true se esiste una campagna sponsorizzata attiva oppure il flag is_sponsored. */
  sponsored_now: boolean;
  distance_km?: number;
}

export interface MenuWithSections extends Menu {
  sections: (MenuCategory & { items: MenuItemFull[] })[];
}

/** Scheda completa del ristorante. */
export interface RestaurantDetail extends RestaurantSummary {
  images: RestaurantImage[];
  menus: MenuWithSections[];
  offers: Offer[];
  coupons: Coupon[];
  province: Pick<Province, 'id' | 'name' | 'code'> | null;
  sources: RestaurantSource[];
  /** Configurazione prenotazioni (null se mai configurate). */
  reservation_settings: ReservationSettings | null;
}

export interface ClaimWithRestaurant extends RestaurantClaim {
  restaurant: (Pick<Restaurant, 'id' | 'name' | 'slug' | 'address' | 'phone' | 'logo_url' | 'owner_id'> & { city_name: string | null }) | null;
  claimant?: Pick<Profile, 'id' | 'full_name' | 'email'> | null;
}

export interface MemberWithProfile extends RestaurantMember {
  profile: Pick<Profile, 'id' | 'full_name' | 'email'> | null;
}

export interface ReportWithRestaurant extends RestaurantReport {
  restaurant: Pick<Restaurant, 'id' | 'name' | 'slug'> | null;
}

export interface OfferWithRestaurant extends Offer {
  restaurant: Pick<Restaurant, 'id' | 'name' | 'slug' | 'cover_url' | 'latitude' | 'longitude' | 'is_all_you_can_eat'> & {
    city_name: string | null;
    city_slug: string | null;
    category_slugs: string[];
  };
  distance_km?: number;
}

/** Correzione di posizione/indirizzo proposta dal ristoratore (approvata dall'Admin). */
export interface ChangeRequest {
  id: UUID;
  restaurant_id: UUID;
  user_id: UUID;
  kind: 'location';
  payload: { address?: string | null; postal_code?: string | null; latitude?: number | null; longitude?: number | null };
  note: string | null;
  status: ChangeRequestStatus;
  admin_notes: string | null;
  reviewed_by: UUID | null;
  reviewed_at: ISODate | null;
  created_at: ISODate;
  restaurant?: Pick<Restaurant, 'id' | 'name' | 'slug' | 'address' | 'latitude' | 'longitude'> | null;
}
