// ─────────────────────────────────────────────────────────────
//  Fase 9 · Logistica AsiaFood (Rider). Stati, dispatch, compensi e
//  privacy sono decisi dal server: qui solo i tipi delle letture.
// ─────────────────────────────────────────────────────────────

export type RiderStatus = 'pending' | 'approved' | 'active' | 'inactive' | 'suspended' | 'rejected';
export type VehicleType = 'bike' | 'e-bike' | 'scooter' | 'motorcycle' | 'car' | 'other';
export type DeliveryJobStatus =
  | 'waiting_assignment' | 'offered' | 'assigned' | 'rider_to_restaurant' | 'arrived_restaurant' | 'picked_up'
  | 'rider_to_customer' | 'arrived_customer' | 'delivered' | 'failed' | 'cancelled';
export type RiderDocumentType = 'identity' | 'driving_license' | 'vehicle_registration' | 'vehicle_insurance' | 'tax' | 'other';
export type OfferRejectReason = 'too_far' | 'end_of_shift' | 'vehicle_problem' | 'not_available' | 'other';
export type RiderJobAction = 'depart' | 'arrived_restaurant' | 'not_ready' | 'picked_up' | 'arrived_customer' | 'customer_unavailable' | 'delivered' | 'fail' | 'cancel' | 'problem';
export type ProofType = 'confirmation' | 'otp' | 'photo';

export const VEHICLE_LABEL: Record<VehicleType, string> = {
  bike: 'Bicicletta', 'e-bike': 'E-bike', scooter: 'Scooter', motorcycle: 'Moto', car: 'Auto', other: 'Altro',
};
export const VEHICLE_EMOJI: Record<VehicleType, string> = { bike: '🚲', 'e-bike': '🚲', scooter: '🛵', motorcycle: '🏍️', car: '🚗', other: '🛵' };
/** Veicoli per cui serve la patente. */
export const LICENSE_VEHICLES: VehicleType[] = ['scooter', 'motorcycle', 'car'];

export const RIDER_STATUS_LABEL: Record<RiderStatus, string> = {
  pending: 'In attesa di approvazione', approved: 'Approvato', active: 'Attivo', inactive: 'Non attivo', suspended: 'Sospeso', rejected: 'Non approvato',
};
export const JOB_STATUS_LABEL: Record<DeliveryJobStatus, string> = {
  waiting_assignment: 'Ricerca Rider in corso', offered: 'Proposta a un Rider', assigned: 'Rider assegnato', rider_to_restaurant: 'Rider in arrivo al ristorante',
  arrived_restaurant: 'Rider al ristorante', picked_up: 'Ordine ritirato', rider_to_customer: 'In consegna', arrived_customer: 'Rider arrivato',
  delivered: 'Consegnato', failed: 'Consegna non riuscita', cancelled: 'Consegna annullata',
};
export const DOCUMENT_TYPE_LABEL: Record<RiderDocumentType, string> = {
  identity: 'Documento d’identità', driving_license: 'Patente', vehicle_registration: 'Libretto del veicolo', vehicle_insurance: 'Assicurazione del veicolo', tax: 'Documentazione fiscale', other: 'Altro',
};
export const OFFER_REJECT_REASONS: { value: OfferRejectReason; label: string }[] = [
  { value: 'too_far', label: 'Troppo lontano' },
  { value: 'end_of_shift', label: 'Fine turno' },
  { value: 'vehicle_problem', label: 'Problema al veicolo' },
  { value: 'not_available', label: 'Non disponibile' },
  { value: 'other', label: 'Altro' },
];
export const RIDER_PROBLEM_TYPES: { value: string; label: string }[] = [
  { value: 'order_problem', label: 'Problema con l’ordine' },
  { value: 'vehicle_problem', label: 'Problema al veicolo' },
  { value: 'accident', label: 'Incidente' },
  { value: 'cannot_complete', label: 'Non posso completare la consegna' },
  { value: 'support', label: 'Contatta il supporto' },
];

export interface RiderApplyInput {
  first_name: string;
  last_name: string;
  phone: string;
  email?: string;
  city_slug?: string | null;
  city?: string | null;
  zone_id?: string | null;
  vehicle_type: VehicleType;
  vehicle_details?: string | null;
  terms_accepted: boolean;
}

export interface RiderDocument {
  id: string;
  type: RiderDocumentType;
  status: 'pending' | 'approved' | 'rejected' | 'expired';
  expires_at: string | null;
  uploaded_at: string;
}

export interface RiderOffer {
  assignment_id: string;
  expires_at: string;
  offered_at: string;
  order_number: string;
  restaurant: { name: string; address: string | null; city: string | null };
  /** Solo CAP e comune: l'indirizzo completo si vede dopo l'accettazione. */
  delivery_area: string;
  distance_to_pickup_km: number | null;
  delivery_distance_km: number | null;
  estimated_minutes: number;
  estimated_earning: number | null;
  ready_at: string | null;
  scheduled_for: string | null;
}

export interface RiderHome {
  rider: null | {
    id: string;
    status: RiderStatus;
    first_name: string;
    last_name: string;
    city: string;
    vehicle_type: VehicleType;
    vehicle_details: string | null;
    suspension_reason: string | null;
    rejected_reason: string | null;
    location_consent: boolean;
    documents: RiderDocument[];
  };
  availability?: { is_online: boolean; accepting_orders: boolean; online_since: string | null; current_capacity: number; max_concurrent_deliveries: number; last_location_at: string | null };
  settings?: { interval_active: number; interval_idle: number; arrival_radius_m: number };
  offer?: RiderOffer | null;
  active?: { id: string; status: DeliveryJobStatus; order_number: string; restaurant: string }[];
  stats?: { completed: number; failed: number; completion_rate: number | null; avg_delivery_minutes: number | null; total_deliveries: number };
}

export interface RiderJob {
  id: string;
  status: DeliveryJobStatus;
  order_number: string;
  order_status: string;
  restaurant: { name: string; address: string | null; city: string | null; phone: string | null; latitude: number | null; longitude: number | null };
  restaurant_notes: string | null;
  ready: boolean;
  estimated_ready_at: string | null;
  items: { name: string; quantity: number; variant: string | null }[];
  customer: null | {
    name: string;
    phone: string | null;
    address: { address_line_1?: string; address_line_2?: string | null; postal_code?: string; city?: string; delivery_notes?: string | null };
    latitude: number | null;
    longitude: number | null;
    notes: string | null;
  };
  pickup_code_required: boolean;
  delivery_code_required: boolean;
  proof_type: ProofType;
  distance_km: number | null;
  eta_pickup_at: string | null;
  eta_delivery_min_at: string | null;
  eta_delivery_max_at: string | null;
  accepted_at: string | null;
  arrived_at_restaurant_at: string | null;
  picked_up_at: string | null;
  arrived_at_customer_at: string | null;
  customer_wait_started_at: string | null;
  delivered_at: string | null;
  customer_wait_minutes: number;
  earning: { total?: number; base_fee?: number; distance_fee?: number; status?: string; final: boolean; available?: boolean };
}

export interface LocationInput {
  latitude: number;
  longitude: number;
  accuracy?: number | null;
  heading?: number | null;
  speed?: number | null;
  recorded_at?: string;
}
export interface LocationResult {
  accepted: boolean;
  reason?: 'OFFLINE' | 'STALE' | 'TOO_FREQUENT' | 'ANOMALY';
  flags?: string[];
  interval_seconds?: number;
  high_accuracy?: boolean;
  tracking: boolean;
  hint?: 'near_restaurant' | 'near_customer' | null;
}

export interface RiderEarningItem {
  id: string;
  total: number;
  base_fee: number;
  distance_fee: number;
  bonus: number;
  adjustment: number;
  status: 'pending' | 'approved' | 'paid' | 'cancelled';
  note: string | null;
  created_at: string;
  paid_at: string | null;
  order_number: string | null;
}
export interface RiderEarningsSummary {
  today: number;
  week: number;
  month: number;
  to_pay: number;
  paid: number;
  items: RiderEarningItem[];
}

export interface OrderDeliveryView {
  provider: string;
  job: null | {
    status: DeliveryJobStatus;
    rider: { name: string; vehicle_type: VehicleType; photo_url: string | null } | null;
    rider_position: { latitude: number; longitude: number; at: string } | null;
    restaurant: { latitude: number | null; longitude: number | null; name: string };
    destination: { latitude: number | null; longitude: number | null };
    eta_min_at: string | null;
    eta_max_at: string | null;
    eta_source: 'estimate' | 'routing';
    eta_updated_at: string | null;
    delivery_code: string | null;
    accepted_at: string | null;
    picked_up_at: string | null;
    arrived_at_customer_at: string | null;
    delivered_at: string | null;
    can_rate: boolean;
    rated: boolean;
  };
}

export interface RestaurantDelivery {
  order_id: string;
  job_id: string;
  status: DeliveryJobStatus;
  pickup_code: string | null;
  rider: { name: string; vehicle_type: VehicleType } | null;
  eta_pickup_at: string | null;
  arrived_at_restaurant_at: string | null;
  picked_up_at: string | null;
  searching_since: string | null;
}

// ─── Admin ───────────────────────────────────────────────────
export interface AdminRiderRow {
  id: string;
  user_id: string;
  name: string;
  city: string;
  vehicle_type: VehicleType;
  status: RiderStatus;
  is_online: boolean;
  busy: boolean;
  total_deliveries: number;
  rating_internal: number | null;
  is_demo: boolean;
  documents: number;
  documents_pending: number;
  last_activity: string | null;
  created_at: string;
}

export interface AdminRiderDetail {
  id: string;
  user_id: string;
  status: RiderStatus;
  first_name: string;
  last_name: string;
  phone: string;
  email: string;
  city: string;
  vehicle_type: VehicleType;
  vehicle_details: string | null;
  admin_notes: string | null;
  suspension_reason: string | null;
  rejected_reason: string | null;
  approved_at: string | null;
  total_deliveries: number;
  rating_internal: number | null;
  created_at: string;
  availability: { is_online: boolean; accepting_orders: boolean; current_capacity: number; max_concurrent_deliveries: number; last_location_at: string | null } | null;
  documents: { id: string; document_type: RiderDocumentType; storage_path: string; status: RiderDocument['status']; expires_at: string | null; uploaded_at: string; review_note: string | null }[];
  recent_jobs: { id: string; status: DeliveryJobStatus; order_number: string; restaurant: string; accepted_at: string | null; delivered_at: string | null }[];
  earnings: { pending: number; paid: number };
  ratings: { count: number; average: number | null };
  flags: { type: string; message: string; created_at: string }[];
}

export interface DispatchJob {
  id: string;
  status: DeliveryJobStatus;
  order_number: string;
  order_status: string;
  restaurant: string;
  restaurant_id: string;
  pickup: { latitude: number | null; longitude: number | null };
  dropoff: { latitude: number | null; longitude: number | null; area: string | null };
  rider: { id: string; name: string } | null;
  distance_km: number | null;
  created_at: string;
  accepted_at: string | null;
  dispatch_attempts: number;
  offer_expires_at: string | null;
  eta_max_at: string | null;
  flags: string[];
  ready: boolean;
  waiting_minutes: number;
}
export interface DispatchRider {
  id: string;
  name: string;
  vehicle_type: VehicleType;
  city: string;
  status: RiderStatus;
  accepting_orders: boolean;
  capacity: number;
  max: number;
  busy: boolean;
  latitude: number | null;
  longitude: number | null;
  location_at: string | null;
  online_since: string | null;
}
export interface LogisticsAlert {
  id: string;
  alert_type: string;
  delivery_job_id: string | null;
  rider_id: string | null;
  message: string;
  status: 'open' | 'acknowledged' | 'resolved';
  created_at: string;
}
export interface DispatchBoard {
  jobs: DispatchJob[];
  riders: DispatchRider[];
  alerts: LogisticsAlert[];
  auto_dispatch: boolean;
  service_enabled: boolean;
}

export interface AdminJobDetail {
  id: string;
  order_id: string;
  order_number: string;
  order_status: string;
  status: DeliveryJobStatus;
  restaurant_id: string;
  pickup_address_snapshot: { name?: string; address?: string | null; city?: string | null } | null;
  delivery_address_snapshot: Record<string, string | null> | null;
  estimated_distance_km: number | null;
  pickup_code: string | null;
  delivery_code_required: boolean;
  proof_type: ProofType;
  proof_photo_path: string | null;
  flags: string[];
  dispatch_attempts: number;
  reassignment_count: number;
  created_at: string;
  accepted_at: string | null;
  picked_up_at: string | null;
  delivered_at: string | null;
  failure_reason: string | null;
  cancel_reason: string | null;
  eta_delivery_min_at: string | null;
  eta_delivery_max_at: string | null;
  rider: { id: string; name: string; phone: string; vehicle_type: VehicleType } | null;
  waiting_minutes: number | null;
  events: { type: string; actor: string; metadata: Record<string, unknown>; created_at: string }[];
  assignments: { id: string; rider: string; status: string; manual: boolean; distance_to_pickup_km: number | null; estimated_earning: number | null; offered_at: string; responded_at: string | null; rejection_reason: string | null }[];
  earnings: { id: string; total: number; status: string; note: string | null; base_fee: number; distance_fee: number; bonus: number; adjustment: number }[];
  issues: { id: string; issue_type: string; description: string; status: string; reported_by_type: string; created_at: string }[];
  rating: { rating: number; comment: string | null } | null;
  location_points: number;
}

export interface LogisticsStats {
  definitions: Record<string, string>;
  active: number;
  waiting_assignment: number;
  jobs_period: number;
  delivered: number;
  failed: number;
  cancelled: number;
  avg_assignment_minutes: number | null;
  avg_pickup_minutes: number | null;
  avg_delivery_minutes: number | null;
  avg_wait_minutes: number | null;
  on_time_rate: number | null;
  riders_online: number;
  riders_busy: number;
  utilization: number | null;
  riders_total: number;
  riders_pending: number;
  offers: { sent: number; accepted: number; rejected: number; expired: number };
  slow_restaurants: { restaurant: string; deliveries: number; avg_wait_minutes: number; not_ready_reports: number }[];
  open_alerts: number;
  earnings: { pending: number; paid_period: number };
}

export interface ServiceZone {
  id: string;
  name: string;
  city_id: string | null;
  center_latitude: number;
  center_longitude: number;
  radius_km: number;
  is_active: boolean;
}

export interface CompensationRule {
  id: string;
  city_id: string | null;
  base_fee: number;
  per_km_fee: number;
  minimum_fee: number;
  max_distance_fee: number | null;
  weather_bonus: number | null;
  peak_bonus: number | null;
  is_active: boolean;
  effective_from: string;
  effective_to: string | null;
  note: string | null;
}

/** Impostazioni /admin/logistics/settings (chiavi di platform_settings senza prefisso "logistics_"). */
export interface LogisticsSettings {
  enabled: boolean;
  auto_dispatch_enabled: boolean;
  initial_search_radius: number;
  max_search_radius: number;
  search_radii: string;
  offer_timeout_seconds: number;
  location_interval_active: number;
  location_interval_idle: number;
  location_retention_hours: number;
  default_rider_capacity: number;
  delivery_code_required: boolean;
  pickup_code_required: boolean;
  proof_of_delivery_type: ProofType;
  dispatch_strategy: 'immediate' | 'before_ready';
  dispatch_before_ready_minutes: number;
  max_dispatch_attempts: number;
  alert_unassigned_minutes: number;
  rider_stale_minutes: number;
  customer_wait_minutes: number;
  document_retention_days: number;
  delivery_data_retention_days: number;
}

export const LOGISTICS_DEFAULTS: LogisticsSettings = {
  enabled: true, auto_dispatch_enabled: true, initial_search_radius: 3, max_search_radius: 10, search_radii: '3,5,8,10', offer_timeout_seconds: 30,
  location_interval_active: 15, location_interval_idle: 60, location_retention_hours: 24, default_rider_capacity: 1, delivery_code_required: false,
  pickup_code_required: true, proof_of_delivery_type: 'confirmation', dispatch_strategy: 'immediate', dispatch_before_ready_minutes: 10,
  max_dispatch_attempts: 20, alert_unassigned_minutes: 10, rider_stale_minutes: 5, customer_wait_minutes: 10, document_retention_days: 730,
  delivery_data_retention_days: 365,
};

export interface LogisticsTickResult {
  expired_offers: number;
  dispatched: number;
  alerts: number;
  locations_purged: number;
  jobs_anonymized?: number;
}
