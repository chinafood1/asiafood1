// ─────────────────────────────────────────────────────────────
//  Fase 12 · Go-to-market: tipi condivisi tra Supabase, DEMO e UI.
//  Specchio delle RPC della migrazione 0024 (launch.sql).
// ─────────────────────────────────────────────────────────────

export type LaunchPhase = 'planned' | 'private_beta' | 'local_beta' | 'public_launch' | 'paused';
export type Segment = 'A' | 'B' | 'C';
export type LeadKind = 'restaurant' | 'creator' | 'partner' | 'press';
export type LeadStatus =
  | 'new' | 'researched' | 'contacted' | 'replied' | 'demo_scheduled' | 'demo_done' | 'claim_sent' | 'claimed'
  | 'trial' | 'activated' | 'paid' | 'in_talks' | 'active' | 'closed' | 'lost' | 'not_interested' | 'do_not_contact';
export type ActivityType =
  | 'research' | 'call' | 'whatsapp' | 'email' | 'instagram_dm' | 'visit' | 'demo' | 'claim_link_sent' | 'follow_up' | 'collaboration' | 'note' | 'status_change';
export type ActivityOutcome = 'no_answer' | 'interested' | 'not_now' | 'not_interested' | 'replied' | 'scheduled' | 'done' | 'other';
export type Channel =
  | 'organic_search' | 'social' | 'qr' | 'direct' | 'referral' | 'restaurant_referral' | 'paid_social' | 'influencer' | 'email' | 'partner' | 'offline' | 'other';
export type QrKind = 'profile' | 'menu' | 'review' | 'booking' | 'offer';
export type ContentStatus = 'idea' | 'draft' | 'approved' | 'scheduled' | 'published';
export type ContentPlatform = 'instagram' | 'facebook' | 'tiktok' | 'email_users' | 'email_restaurants' | 'press' | 'blog' | 'whatsapp' | 'offline';
export type ContentType =
  | 'restaurant_spotlight' | 'dish_of_day' | 'ayce' | 'offers' | 'new_partners' | 'quiz' | 'where_would_you_eat' | 'map' | 'behind_scenes'
  | 'giveaway' | 'local' | 'ugc' | 'launch' | 'newsletter' | 'press_release' | 'tips';
export type FeedbackType = 'user_general' | 'restaurant_dashboard' | 'nps' | 'cancellation' | 'bug' | 'feature_request';
export type IncidentSeverity = 'low' | 'medium' | 'high' | 'critical';
export type GoalMetric =
  | 'restaurants_listed' | 'restaurants_verified' | 'restaurants_claimed' | 'restaurants_partner' | 'restaurants_paying' | 'users_registered'
  | 'users_active_30d' | 'reservations' | 'orders_completed' | 'coupon_claims' | 'referrals_qualified' | 'reviews_published' | 'sponsored_campaigns'
  | 'mrr_cents' | 'qr_scans' | 'food_connections';
export type RestaurantFilter =
  | 'incomplete' | 'no_coords' | 'no_hours' | 'no_phone' | 'no_menu' | 'claimable' | 'stale' | 'closed' | 'duplicates' | 'position'
  | 'segment_a' | 'segment_b' | 'segment_c';
export type LaunchKitStep = 'starter_kit_viewed' | 'qr_kit_downloaded' | 'materials_printed' | 'social_launch' | 'social_launch_undo';

export interface Market { id: string; slug: string; name: string; status: LaunchPhase; launched_at: string | null }
export interface ProgressItem { key: string; label: string; value: number; target: number; pct: number }
export interface LaunchAlert { level: 'low' | 'medium' | 'high'; key: string; text: string; link: string | null }
export interface LocalQuery { query: string; path: string; count: number; ready: boolean }
export interface Goal {
  id: string; metric_key: GoalMetric; target_value: number; period_start: string; period_end: string; actual_value: number | null;
  status: 'not_started' | 'on_track' | 'at_risk' | 'behind' | 'achieved'; refreshed_at: string | null;
}

export interface LaunchOverview {
  market: Market;
  phase: LaunchPhase;
  include_demo: boolean;
  kpis: {
    censused: number; drafts: number; listed: number; verified: number; claimed: number; partner: number; paying: number; premium_top: number;
    founding: number; avg_completion: number | null; demo: number;
    users: number; users_active_30d: number; reservations_30d: number; orders_30d: number; gmv_30d: number; orders_enabled: boolean;
    coupon_claims_30d: number; coupon_redeemed_30d: number; reviews_30d: number; mrr_cents: number; qr_scans_30d: number;
    food_connections_30d: number; visits_30d: number;
    referrals: { invited: number; registered: number; qualified: number; rewarded: number };
    business_referrals: { invited: number; qualified: number; rewarded: number };
    sponsored: { active: number; impressions_30d: number; clicks_30d: number };
    traffic_by_channel: Partial<Record<Channel, number>>;
    seo: { restaurant_pages: number; city_pages: number; local_queries_ready: number; local_queries_total: number };
  };
  progress: ProgressItem[];
  alerts: LaunchAlert[];
  local_queries: LocalQuery[];
  pipeline: Partial<Record<LeadStatus, number>>;
  goals: Goal[];
  north_star: { week: string; value: number }[];
  generated_at: string;
}

export interface CoverageRow {
  city_id: string; city: string; slug: string; priority: number | null; lat: number | null; lng: number | null;
  censused: number; listed: number; verified: number; unclaimed: number; claimed: number; partner: number; premium_top: number; avg_completion: number | null;
}

export interface LaunchRestaurantRow {
  id: string; name: string; slug: string; city_id: string; city_name: string; city_slug: string; city_priority: number | null; is_demo: boolean;
  is_active: boolean; closed: boolean; claimed: boolean; verified: boolean; partner: boolean; paying: boolean; founding: boolean; plan: string;
  completion: number; missing: string[]; has_menu: boolean; no_coords: boolean; no_hours: boolean; no_phone: boolean; stale: boolean;
  duplicate: boolean; position_far: boolean; claimable: boolean; is_ayce: boolean; has_delivery: boolean;
  priority_score: number; segment_suggested: Segment; segment: Segment;
  lead_id: string | null; lead_status: LeadStatus | null; assigned_to: string | null; next_action: string | null; next_action_at: string | null;
  last_contact_at: string | null; potential_plan: string | null; contact_allowed: boolean;
  phone: string | null; whatsapp: string | null; email: string | null; instagram: string | null; website: string | null;
  last_verified_at: string | null; views_30d: number;
  rank?: number; assigned_name?: string | null; claim_status?: string | null;
}

export interface LaunchRestaurantsPage {
  include_demo: boolean;
  counts: Record<'all' | RestaurantFilter, number>;
  total: number;
  rows: LaunchRestaurantRow[];
  open_reports: number;
}

export interface CrmLead {
  id: string; market_id: string; kind: LeadKind; category: string | null; restaurant_id: string | null; name: string; city_id: string | null;
  contact_name: string | null; phone: string | null; email: string | null; instagram: string | null; tiktok: string | null; website: string | null;
  followers: number | null; status: LeadStatus; segment_override: Segment | null; assigned_to: string | null; next_action: string | null;
  next_action_at: string | null; last_contact_at: string | null; potential_plan: string | null; competitor_tools: string[];
  competitor_source: 'public' | 'declared' | null; contact_allowed: boolean; lost_reason: string | null; notes: string | null;
  created_at: string; updated_at: string;
  city_name?: string | null; restaurant_slug?: string | null; assigned_name?: string | null; open_tasks?: number;
}
export interface CrmActivity {
  id: string; lead_id: string; type: ActivityType; outcome: ActivityOutcome | null; notes: string | null; disclosure_required: boolean | null;
  created_by: string | null; created_at: string; by_name?: string | null;
}
export interface CrmTask {
  id: string; lead_id: string | null; restaurant_id: string | null; title: string; reason: string | null; due_at: string | null;
  assigned_to: string | null; status: 'open' | 'done' | 'dismissed'; source: 'manual' | 'at_risk' | 'trial_ending' | 'system'; created_at: string;
  restaurant_name?: string | null; lead_name?: string | null;
}
export interface CrmLeadDetail {
  lead: CrmLead;
  restaurant: null | {
    id: string; name: string; slug: string; phone: string | null; whatsapp: string | null; email: string | null; website: string | null;
    instagram: string | null; facebook: string | null; claimed: boolean; is_active: boolean; plan: string;
    completion: { score: number; missing: string[] }; founding: FoundingRow | null; claim_status: string | null;
  };
  activities: CrmActivity[];
  tasks: CrmTask[];
}
export type CrmLeadPatch = Partial<Omit<CrmLead, 'id' | 'market_id' | 'created_at' | 'updated_at'>> & { id?: string; market?: string };
export interface CrmActivityInput {
  lead_id: string; type: ActivityType; outcome?: ActivityOutcome | null; notes?: string | null;
  next_action?: string | null; next_action_at?: string | null; disclosure_required?: boolean;
}

export interface FoundingRow {
  id: string; restaurant_id: string; number: number; status: 'active' | 'completed' | 'revoked'; benefit_plan: string; benefit_days: number;
  activated_at: string; benefit_ends_at: string | null; revoked_reason: string | null; notes: string | null;
  restaurant_name?: string; restaurant_slug?: string; days_left?: number | null; paying?: boolean;
}
export interface FoundingProgram { enabled: boolean; name: string; limit: number; plan: string; days: number; badge_enabled: boolean; used: number; rows: FoundingRow[] }
export interface FoundingBadge { number: number; label: string; since: string }

export interface DailyBoard {
  day: string;
  targets: Record<'research' | 'contacts' | 'demos' | 'claims' | 'trials', number>;
  actual: Record<'research' | 'contacts' | 'demos' | 'claims' | 'trials', number>;
  due_leads: (Pick<CrmLead, 'id' | 'name' | 'kind' | 'status' | 'next_action' | 'next_action_at' | 'last_contact_at' | 'restaurant_id'> & { city_name: string | null; assigned_name: string | null })[];
  follow_ups: Pick<CrmLead, 'id' | 'name' | 'status' | 'last_contact_at'>[];
  demos: Pick<CrmLead, 'id' | 'name' | 'next_action' | 'next_action_at'>[];
  claims_pending: { id: string; status: string; created_at: string; restaurant_name: string; age_hours: number; overdue: boolean }[];
  trials_expiring: { restaurant_id: string; name: string; plan_code: string; source: string; ends_at: string; founding: boolean }[];
  new_paying: { name: string; plan_code: string; paid_started_at: string }[];
  tasks: CrmTask[];
}

export interface WeeklyRow {
  week: string; contacted: number; replies: number; claims: number; trials: number; paid: number; new_users: number; visits: number;
  reservations: number; orders: number; food_connections: number;
}
export interface TimeToValue {
  claimed: number;
  profile: { n: number; median_hours: number | null }; menu: { n: number; median_hours: number | null }; offer: { n: number; median_hours: number | null };
  reservation: { n: number; median_hours: number | null }; paid: { n: number; median_hours: number | null };
}
export interface WeeklyReview {
  weeks: WeeklyRow[];
  mrr_cents: number;
  feedback_loop: {
    support_by_category: Record<string, number>; incidents: Record<string, number>; feedback_by_type: Record<string, number>;
    cancellation_reasons: Record<string, number>; nps: { responses: number; score: number | null };
    latest_user: { message: string; type: string; created_at: string }[];
    latest_restaurant: { message: string; restaurant: string | null; created_at: string }[];
  };
  user_funnel: Record<'visits' | 'searches' | 'restaurant_views' | 'menu_views' | 'favorites' | 'reservations_orders' | 'reviews' | 'returning_users', number>;
  business_funnel: Record<'discovered' | 'lead' | 'contacted' | 'claimed' | 'trial' | 'activated' | 'paid' | 'retained', number>;
  activation: { users_signed_up_30_60d: number; users_activated_30_60d: number; restaurants_claimed: number; restaurants_activated: number };
  cohorts: {
    users: { week: string; size: number; returned_week2: number; returned_after: number }[];
    restaurants: { week: string; claimed: number; activated: number; paid: number }[];
    trial_conversion: { founding_completed: number; founding_converted: number; stripe_trials_ended: number; stripe_trials_converted: number };
  };
  time_to_value: TimeToValue;
}

export type PartnerFlag = 'trial_ending' | 'no_login' | 'profile_incomplete' | 'zero_activity' | 'reservations_waiting';
export interface PartnerRow {
  restaurant_id: string; name: string; slug: string; city_name: string; plan: string; founding: boolean; paying: boolean; completion: number;
  has_menu: boolean; active_offers: number; last_owner_activity: string | null; pending_reservations_24h: number; customer_actions_30d: number;
  health: number; trial_ends_at: string | null; flags: PartnerFlag[];
  roi: Record<'views' | 'calls' | 'directions' | 'bookings' | 'orders' | 'coupon_uses' | 'qr_scans', number>;
}
export interface PartnersBoard { rows: PartnerRow[]; at_risk: number; founding: FoundingProgram; time_to_value: TimeToValue }

export interface OpsCount { count: number; overdue?: number }
export interface LaunchIncident {
  id: string; title: string; description: string | null; area: string; severity: IncidentSeverity;
  status: 'open' | 'investigating' | 'mitigated' | 'resolved'; created_at: string; resolved_at: string | null;
}
export interface OpsToday {
  sla: { claim_hours: number; support_hours: number; order_issue_hours: number; data_report_hours: number };
  claims_pending: OpsCount; order_issues: OpsCount; restaurant_support: OpsCount; customer_support: OpsCount; rider_issues: OpsCount | null;
  payments_failed_24h: number;
  data_reports: OpsCount & { rows: { id: string; type: string; restaurant: string; slug: string; created_at: string }[] };
  sales_followups: number; incidents: LaunchIncident[]; feedback_new: number;
}

export interface AcquisitionCode { code: string; kind: string; description: string | null; is_active: boolean; uses: number; restaurant_id: string | null; created_at: string }
export interface ExperimentRow {
  id: string; key: string; name: string; hypothesis: string | null; primary_metric: string | null; variants: string[];
  status: 'draft' | 'running' | 'stopped'; started_at: string | null; stopped_at: string | null; created_at: string; exposures?: Record<string, number>;
}
export interface CostRow { id: string; audience: 'restaurants' | 'users'; category: string; channel: string | null; amount_cents: number; spent_on: string; notes: string | null }
export interface GrowthBoard {
  days: number;
  visits_by_channel: Partial<Record<Channel, number>>;
  campaigns: { utm_source: string | null; utm_medium: string | null; utm_campaign: string; visits: number }[];
  signups_by_channel: Partial<Record<Channel, number>>;
  signups_total: number; signups_attributed: number;
  codes: AcquisitionCode[];
  qr_by_kind: Partial<Record<QrKind, number>>;
  referral_funnel: { invited: number; registered: number; qualified: number; rewarded: number };
  restaurant_referral_funnel: { invited: number; qualified: number; rewarded: number };
  ambassadors: { applied: number; approved: number };
  experiments: ExperimentRow[];
  costs: { restaurants_cents: number; users_cents: number; rows: CostRow[] };
  cac: {
    restaurant_cents: number | null; restaurant_reason: 'no_costs' | 'too_few_conversions' | null; restaurant_conversions: number;
    user_cents: number | null; user_reason: 'no_costs' | 'too_few_conversions' | null; user_conversions: number; min_conversions: number;
  };
  revenue_per_restaurant: { id: string; name: string; subscription_cents: number; order_fees_cents: number; ads_cents: number; total_cents: number }[];
}

export interface PlanItem {
  id: string; horizon: '30d' | '90d'; bucket: 'week1' | 'week2' | 'week3' | 'week4' | 'month1' | 'month2' | 'month3'; title: string;
  description: string | null; status: 'todo' | 'doing' | 'done' | 'skipped'; owner_id: string | null; owner_name?: string | null; due_date: string | null; sort: number;
}
export interface ContentItem {
  id: string; platform: ContentPlatform; content_type: ContentType; restaurant_id: string | null; restaurant_name?: string | null; title: string | null;
  caption: string | null; media_url: string | null; status: ContentStatus; scheduled_for: string | null; published_at: string | null;
  is_sponsored: boolean; rights_confirmed: boolean; compliance_checked: boolean; notes: string | null; created_at: string;
}
export interface FeedbackRow {
  id: string; user_id: string | null; restaurant_id: string | null; restaurant_name?: string | null; type: FeedbackType; rating: number | null;
  reason: string | null; message: string | null; page: string | null; status: 'new' | 'reviewed' | 'planned' | 'done' | 'dismissed'; created_at: string;
}
export interface AmbassadorRow {
  id: string; user_id: string; status: 'applied' | 'approved' | 'paused' | 'rejected'; referral_code: string | null; motivation: string | null;
  joined_at: string; approved_at: string | null; notes: string | null; name: string | null; email: string | null; referrals: number; qualified: number;
}
export interface MyAmbassador { enabled: boolean; status: AmbassadorRow['status'] | null; referral_code: string | null; joined_at: string | null; founding_foodie_at: string | null }
export interface ExpansionSignal { province: string; code: string; restaurants: number; claims: number; leads: number; favorites: number; score: number }

export interface MarketLanding {
  market: { slug: string; name: string; status: LaunchPhase };
  min_per_page: number;
  total: number; ayce: number; delivery: number; with_offers: number;
  categories: { slug: string; name: string; emoji: string | null; count: number }[];
  cities: { slug: string; name: string; count: number }[];
  category_city: { category: string; city: string; city_name: string; count: number }[];
}

export interface LaunchKit {
  completion: { score: number; missing: string[]; has_menu: boolean; has_hours: boolean };
  steps: { key: 'profile' | 'menu' | 'hours' | 'photos' | 'qr' | 'first_offer' | 'reservations' | 'notifications' | 'social_launch'; done: boolean }[];
  progress: { starter_kit_viewed_at: string | null; qr_kit_downloaded_at: string | null; materials_printed_at: string | null; social_launch_at: string | null } | null;
  founding: { number: number; status: string; plan: string; benefit_ends_at: string | null; label: string } | null;
  slug: string; name: string;
}

export interface VisitInput {
  channel: Channel; utm_source?: string | null; utm_medium?: string | null; utm_campaign?: string | null; utm_content?: string | null;
  landing_path?: string | null; promo_code?: string | null; market?: string;
  /** Fase 13: tipo di dispositivo (visite) e last touch (attribuzione iscrizione). */
  device_type?: 'mobile' | 'tablet' | 'desktop'; last_channel?: Channel; last_utm_source?: string | null; last_utm_campaign?: string | null;
}
export interface FeedbackInput { type: FeedbackType; rating?: number | null; reason?: string | null; message?: string | null; restaurant_id?: string | null; page?: string | null }

/** API di lancio: stessa firma per Supabase (RPC 0024) e DEMO (motore locale). */
export interface LaunchApi {
  // Pubblico / utente
  marketLanding(market?: string): Promise<MarketLanding | null>;
  foundingBadge(restaurantId: string): Promise<FoundingBadge | null>;
  trackQrScan(slug: string, kind: QrKind): Promise<void>;
  recordVisit(v: VisitInput): Promise<void>;
  attributeSignup(v: VisitInput): Promise<boolean>;
  runningExperiments(): Promise<{ key: string; variants: string[]; weights?: number[]; primary_metric?: string | null }[]>;
  submitFeedback(input: FeedbackInput): Promise<void>;
  npsShouldAsk(): Promise<boolean>;
  ambassadorApply(motivation: string): Promise<{ status: string; referral_code: string }>;
  myAmbassador(): Promise<MyAmbassador>;
  launchKit(restaurantId: string): Promise<LaunchKit>;
  markLaunchKit(restaurantId: string, step: LaunchKitStep): Promise<void>;
  // Admin
  overview(market?: string): Promise<LaunchOverview>;
  coverage(market?: string): Promise<{ include_demo: boolean; rows: CoverageRow[] }>;
  restaurants(market: string, filter: RestaurantFilter | null, search: string | null, limit: number, offset: number): Promise<LaunchRestaurantsPage>;
  firstN(market?: string): Promise<{ n: number; include_demo: boolean; rows: LaunchRestaurantRow[] }>;
  crmLeads(market: string, kind: LeadKind | null, status: string | null, search: string | null, limit: number, offset: number): Promise<{ total: number; rows: CrmLead[] }>;
  crmLead(id: string): Promise<CrmLeadDetail>;
  crmUpsertLead(patch: CrmLeadPatch): Promise<string>;
  crmLogActivity(input: CrmActivityInput): Promise<string>;
  crmSyncRestaurantLeads(market?: string): Promise<number>;
  crmTaskUpsert(input: { id?: string; lead_id?: string | null; restaurant_id?: string | null; title: string; due_at?: string | null; assigned_to?: string | null }): Promise<string>;
  crmTaskSetStatus(id: string, status: CrmTask['status']): Promise<void>;
  foundingActivate(restaurantId: string, note: string | null): Promise<{ number: number; plan: string; days: number }>;
  foundingRevoke(restaurantId: string, reason: string): Promise<void>;
  foundingList(market?: string): Promise<FoundingProgram>;
  daily(market?: string): Promise<DailyBoard>;
  weekly(market?: string, weeks?: number): Promise<WeeklyReview>;
  partners(market?: string): Promise<PartnersBoard>;
  generateFollowups(market?: string): Promise<number>;
  opsToday(): Promise<OpsToday>;
  growth(market?: string, days?: number): Promise<GrowthBoard>;
  setPhase(market: string, phase: LaunchPhase): Promise<void>;
  goalUpsert(g: { id?: string; metric_key?: GoalMetric; target_value?: number; period_start?: string; period_end?: string }): Promise<string>;
  goalDelete(id: string): Promise<void>;
  costAdd(c: Omit<CostRow, 'id'>): Promise<string>;
  costDelete(id: string): Promise<void>;
  experimentUpsert(e: { id?: string; key?: string; name?: string; hypothesis?: string | null; primary_metric?: string | null; variants?: string[] }): Promise<string>;
  experimentSetStatus(id: string, status: ExperimentRow['status']): Promise<void>;
  planItems(market?: string): Promise<PlanItem[]>;
  planItemUpdate(id: string, patch: Partial<Pick<PlanItem, 'status' | 'owner_id' | 'due_date'>>): Promise<void>;
  contentList(market?: string): Promise<ContentItem[]>;
  contentUpsert(c: Partial<ContentItem> & { id?: string }): Promise<string>;
  contentDelete(id: string): Promise<void>;
  seedSocialCalendar(market?: string, start?: string | null): Promise<number>;
  codeUpsert(c: { code: string; kind?: string; description?: string | null; is_active?: boolean; restaurant_id?: string | null }): Promise<string>;
  feedbackList(type: FeedbackType | null, status: string | null, limit: number, offset: number): Promise<{ total: number; rows: FeedbackRow[] }>;
  feedbackUpdate(id: string, status: FeedbackRow['status']): Promise<void>;
  incidentUpsert(i: { id?: string; title?: string; description?: string | null; area?: string; severity?: IncidentSeverity; status?: LaunchIncident['status'] }): Promise<string>;
  ambassadors(market?: string): Promise<AmbassadorRow[]>;
  ambassadorSetStatus(id: string, status: AmbassadorRow['status'], notes?: string | null): Promise<void>;
  expansionSignals(): Promise<ExpansionSignal[]>;
}

// ─── Etichette (UI) ──────────────────────────────────────────
export const LEAD_STATUS_LABELS: Record<LeadStatus, string> = {
  new: 'Nuovo', researched: 'Ricercato', contacted: 'Contattato', replied: 'Ha risposto', demo_scheduled: 'Demo fissata', demo_done: 'Demo fatta',
  claim_sent: 'Link rivendicazione inviato', claimed: 'Rivendicato', trial: 'In prova', activated: 'Attivato', paid: 'Pagante',
  in_talks: 'In trattativa', active: 'Attivo', closed: 'Chiuso', lost: 'Perso', not_interested: 'Non interessato', do_not_contact: 'Non ricontattare',
};
export const RESTAURANT_PIPELINE: LeadStatus[] = ['new', 'researched', 'contacted', 'replied', 'demo_scheduled', 'demo_done', 'claim_sent', 'claimed', 'trial', 'activated', 'paid'];
export const OTHER_PIPELINE: LeadStatus[] = ['new', 'contacted', 'replied', 'in_talks', 'active', 'closed'];
export const CLOSED_STATUSES: LeadStatus[] = ['lost', 'not_interested', 'do_not_contact'];
export const ACTIVITY_LABELS: Record<ActivityType, string> = {
  research: 'Ricerca', call: 'Telefonata', whatsapp: 'WhatsApp', email: 'Email', instagram_dm: 'DM Instagram', visit: 'Visita', demo: 'Demo',
  claim_link_sent: 'Link rivendicazione inviato', follow_up: 'Follow-up', collaboration: 'Collaborazione', note: 'Nota', status_change: 'Cambio stato',
};
export const OUTCOME_LABELS: Record<ActivityOutcome, string> = {
  no_answer: 'Nessuna risposta', interested: 'Interessato', not_now: 'Non ora', not_interested: 'Non interessato', replied: 'Ha risposto',
  scheduled: 'Fissato', done: 'Fatto', other: 'Altro',
};
export const LEAD_KIND_LABELS: Record<LeadKind, string> = { restaurant: 'Ristoranti', creator: 'Creator', partner: 'Partner locali', press: 'Stampa e media' };
export const LEAD_CATEGORY_LABELS: Record<string, string> = {
  hotel: 'Hotel', bnb: 'B&B', university: 'Università', gym: 'Palestra', cinema: 'Cinema', events: 'Eventi', local_business: 'Attività locale',
  newspaper: 'Giornale', blog: 'Blog', radio: 'Radio', tv: 'TV', instagram: 'Instagram', tiktok: 'TikTok', youtube: 'YouTube', multi: 'Più piattaforme',
};
export const KIND_CATEGORIES: Record<LeadKind, string[]> = {
  restaurant: [], creator: ['instagram', 'tiktok', 'youtube', 'multi'], partner: ['hotel', 'bnb', 'university', 'gym', 'cinema', 'events', 'local_business'],
  press: ['newspaper', 'blog', 'radio', 'tv'],
};
export const COMPETITOR_LABELS: Record<string, string> = {
  thefork: 'TheFork', deliveroo: 'Deliveroo', justeat: 'Just Eat', glovo: 'Glovo', ubereats: 'Uber Eats', own_website: 'Sito proprio',
  own_delivery: 'Consegna propria', other: 'Altro',
};
export const CHANNEL_LABELS: Record<Channel, string> = {
  organic_search: 'Ricerca organica', social: 'Social', qr: 'QR', direct: 'Diretto', referral: 'Invito utente', restaurant_referral: 'Invito ristorante',
  paid_social: 'Social a pagamento', influencer: 'Creator/influencer', email: 'Email', partner: 'Partner locali', offline: 'Offline', other: 'Altro',
};
export const PHASE_LABELS: Record<LaunchPhase, string> = {
  planned: 'Pianificato', private_beta: 'Fase A · Beta privata', local_beta: 'Fase B · Beta locale', public_launch: 'Fase C · Lancio pubblico', paused: 'In pausa',
};
export const MISSING_LABELS: Record<string, string> = {
  name: 'Nome', address: 'Indirizzo', coordinates: 'Coordinate', phone: 'Telefono', hours: 'Orari', categories: 'Categorie', logo: 'Logo', cover: 'Copertina',
  menu: 'Menu', social: 'Social/sito', services: 'Servizi', prices: 'Prezzi', ayce: 'Prezzi AYCE', delivery: 'Consegna/asporto', reservations: 'Prenotazioni',
};
export const FILTER_LABELS: Record<RestaurantFilter, string> = {
  incomplete: 'Schede incomplete', no_coords: 'Coordinate mancanti', no_hours: 'Orari mancanti', no_phone: 'Telefono mancante', no_menu: 'Menu mancante',
  claimable: 'Rivendicazione possibile', stale: 'Dati obsoleti', closed: 'Chiusi', duplicates: 'Possibili duplicati', position: 'Posizione anomala',
  segment_a: 'Segmento A', segment_b: 'Segmento B', segment_c: 'Segmento C',
};
export const GOAL_LABELS: Record<GoalMetric, string> = {
  restaurants_listed: 'Ristoranti pubblicati', restaurants_verified: 'Ristoranti verificati', restaurants_claimed: 'Ristoranti rivendicati',
  restaurants_partner: 'Ristoranti partner', restaurants_paying: 'Ristoranti paganti', users_registered: 'Utenti registrati', users_active_30d: 'Utenti attivi (30 gg)',
  reservations: 'Prenotazioni', orders_completed: 'Ordini completati', coupon_claims: 'Coupon salvati', referrals_qualified: 'Inviti qualificati',
  reviews_published: 'Recensioni pubblicate', sponsored_campaigns: 'Campagne sponsorizzate attive', mrr_cents: 'MRR (centesimi)', qr_scans: 'Scansioni QR',
  food_connections: 'Successful Food Connections',
};
export const GOAL_STATUS_LABELS: Record<Goal['status'], string> = {
  not_started: 'Troppo presto per valutare', on_track: 'In linea', at_risk: 'A rischio', behind: 'In ritardo', achieved: 'Raggiunto',
};
export const PARTNER_FLAG_LABELS: Record<PartnerFlag, string> = {
  trial_ending: 'Piano gratuito in scadenza', no_login: 'Nessun accesso recente', profile_incomplete: 'Profilo incompleto', zero_activity: 'Zero azioni clienti',
  reservations_waiting: 'Prenotazioni in attesa',
};
export const CONTENT_TYPE_LABELS: Record<ContentType, string> = {
  restaurant_spotlight: 'Ristorante della settimana', dish_of_day: 'Piatto del giorno', ayce: 'AYCE', offers: 'Offerte', new_partners: 'Nuovi partner',
  quiz: 'Sushi quiz', where_would_you_eat: 'Dove mangeresti?', map: 'Mappa', behind_scenes: 'Dietro le quinte', giveaway: 'Giveaway', local: 'Contenuto locale',
  ugc: 'Contenuto utenti (UGC)', launch: 'Lancio', newsletter: 'Newsletter', press_release: 'Comunicato stampa', tips: 'Consigli d’uso',
};
export const PLATFORM_LABELS: Record<ContentPlatform, string> = {
  instagram: 'Instagram', facebook: 'Facebook', tiktok: 'TikTok', email_users: 'Email utenti (opt-in)', email_restaurants: 'Newsletter ristoranti',
  press: 'Stampa', blog: 'Blog', whatsapp: 'WhatsApp', offline: 'Offline',
};
export const CONTENT_STATUS_LABELS: Record<ContentStatus, string> = { idea: 'Idea', draft: 'Bozza', approved: 'Approvato', scheduled: 'Programmato', published: 'Pubblicato' };
export const FEEDBACK_TYPE_LABELS: Record<FeedbackType, string> = {
  user_general: 'Utente', restaurant_dashboard: 'Ristoratore', nps: 'NPS', cancellation: 'Disdetta', bug: 'Bug', feature_request: 'Richiesta',
};
export const CANCELLATION_REASONS: Record<string, string> = {
  too_expensive: 'Costa troppo', not_enough_results: 'Pochi risultati finora', missing_features: 'Mancano funzioni', no_time: 'Non ho tempo di gestirlo',
  using_other: 'Uso un altro servizio', closing: 'Chiusura/cambio gestione', other: 'Altro',
};
export const QR_KIND_LABELS: Record<QrKind, string> = { profile: 'Profilo', menu: 'Menu', review: 'Recensioni', booking: 'Prenotazione', offer: 'Offerte' };
