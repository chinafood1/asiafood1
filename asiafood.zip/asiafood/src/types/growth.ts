// ─────────────────────────────────────────────────────────────
//  Fase 13 · Tipi della Business Intelligence & Growth Automation.
//  Rispecchiano i payload delle RPC admin_growth_* (migrazioni 0025–0027).
//  Convenzione: null = "dato non disponibile / campione insufficiente" (mai uno zero finto).
// ─────────────────────────────────────────────────────────────
import type { MarketScoreKey, RestaurantPerformance, FunnelStage } from '@shared/growth';

export type { RestaurantPerformance } from '@shared/growth';

export interface DataQualityItem { key: string; severity: 'info' | 'warning' | 'critical'; message: string }

export interface PeriodTotals {
  visits: number; new_users?: number; sessions?: number; searches: number; zero_result_searches: number; ai_queries?: number; restaurant_views: number; menu_views?: number;
  intents: number; reservations: number; reservations_completed: number; orders: number; orders_completed: number; checkouts?: number; payment_failures?: number;
  gmv_cents: number; order_fees_cents?: number; subscription_revenue_cents?: number; platform_revenue_cents?: number; coupon_claims: number; coupon_redemptions: number;
  reviews: number; referrals_qualified?: number; new_paid_restaurants?: number; ai_cost_micros?: number; ai_errors?: number; active_users?: number; conversions?: number;
  days: number; days_computed: number; complete: boolean;
}

export interface GrowthOverview {
  range: { from: string; to: string; days: number; prev_from: string; prev_to: string };
  market: string | null;
  current: PeriodTotals;
  previous: PeriodTotals | null;
  conversion_rate: number | null;
  state: {
    users_total: number; users_today: number; users_7d: number; users_30d: number; new_users_7d: number; restaurants_active: number; restaurants_claimed: number;
    restaurants_paying: number; trials_active: number; trials_expiring_7d: number; mrr_cents: number; retention_d30: number | null;
  };
  series: { date: string; visits: number; active_users: number; new_users: number; searches: number; reservations: number; orders: number; gmv_cents: number; mrr_cents: number }[];
  freshness: { today_at: string | null; batch_at: string | null };
  data_quality: DataQualityItem[];
  min_sample: number;
  demo_included: boolean;
}

export interface Velocity { avg_days: number | null; n: number }
export interface GrowthFunnels {
  consumer: FunnelStage[];
  return: { window_days: number; converted_users: number; returned_users: number; window_open: number };
  b2b: FunnelStage[];
  velocity: { lead_to_contact: Velocity; lead_to_claim: Velocity; claim_to_trial: Velocity; trial_to_paid: Velocity };
  min_sample: number;
  directions_as_conversion: boolean;
  definitions: { unit: string; intent: string; conversion: string; return: string };
}

export interface RetentionPoint { eligible: number; returned: number }
export interface GrowthRetention {
  users: { d1: RetentionPoint; d7: RetentionPoint; d30: RetentionPoint };
  cohorts: { week: string; size: number; weeks: (number | null)[] }[];
  restaurants: { trial_to_paid: { ended: number; converted: number }; paid_m1_m2: { base: number; retained: number }; paid_m2_m3: { base: number; retained: number } };
  min_sample: number;
  definitions: Record<string, string>;
}

export type HealthStatus = 'healthy' | 'needs_attention' | 'at_risk' | 'unknown' | 'not_claimed';
export interface HealthSignal { key: string; label: string }
export interface RestaurantHealth { score: number | null; status: HealthStatus; components: Record<string, number>; signals: HealthSignal[]; last_login?: string | null }

export interface GrowthRestaurantRow {
  id: string; name: string; slug: string; city: string; subscription_plan: string; claimed: boolean;
  impressions: number; views: number; menu_views: number; directions: number; calls: number; whatsapp: number; bookings: number; orders: number;
  coupon_redemptions: number; reviews: number; revenue_cents: number; repeat_customers: number; conversion_actions: number; conversion_rate: number | null;
  health: RestaurantHealth;
}
export interface GrowthRestaurantsPage { total: number; rows: GrowthRestaurantRow[]; definitions: { conversion: string; health: string } }

export interface MrrMovements { new_mrr_cents: number; churned_mrr_cents: number; expansion_mrr_cents: number | null; contraction_mrr_cents: number | null; expansion_available: boolean; note: string | null }
export interface ChurnListRow { restaurant_id: string; name: string; plan?: string; ended_at?: string; until?: string; since?: string | null; trial_end?: string; last_login?: string | null; mrr_cents?: number; health?: RestaurantHealth }
export interface GrowthChurn {
  churn: { base: number; lost: number; rate: number | null };
  mrr: MrrMovements;
  lists: { cancelled: ChurnListRow[]; cancel_scheduled: ChurnListRow[]; past_due: ChurnListRow[]; inactive_trials: ChurnListRow[]; at_risk: ChurnListRow[] };
  reasons: { reason: string; count: number }[];
  definitions: Record<string, string>;
}

export interface GrowthRevenue {
  mrr_cents: number; arr_cents: number; paying_restaurants: number; arpa_cents: number | null; movements: MrrMovements;
  sources: { key: 'subscriptions' | 'orders' | 'ads' | 'other'; label: string; cents: number }[];
  gmv_cents: number; ltv_cents: number | null; ltv_reason: string | null; mrr_series: { date: string; mrr_cents: number }[]; complete: boolean;
  definitions: Record<string, string>;
}

export interface AcquisitionChannelRow {
  channel: string; visits: number; signups: number; activated: number; reservations: number; orders: number; paying_restaurants: number;
  cost_cents: number | null; cac_cents: number | null; cac_reason: string | null;
}
export interface GrowthAcquisition {
  channels: AcquisitionChannelRow[];
  campaigns: { utm_source: string; utm_campaign: string; visits: number; signups: number }[];
  last_touch: { channel: string; signups: number }[];
  coverage: { signups_total: number; signups_attributed: number };
  definitions: Record<string, string>;
}

export interface SearchRow {
  query: string | null; city_slug: string | null; category_slug: string | null; city: string | null; category: string | null;
  searches: number; zero_results: number; sessions: number; ai_searches: number; converted: number | null; with_session: number | null; demand_score: number;
}
export interface SupplyGapRow {
  city_slug: string; city: string | null; category_slug: string | null; category: string | null; term: string | null; searches: number; zero_results: number; ai_searches: number;
  supply: number; zero_pct: number; score: number; breakdown: { demand: number; zero_results: number; low_supply: number };
}
export interface GrowthSearch {
  totals: { searches: number; zero_results: number; ai_searches: number };
  top: SearchRow[]; zero_results: SearchRow[];
  categories: { slug: string; name: string | null; searches: number; zero_results: number }[];
  cities: { slug: string; name: string | null; searches: number; zero_results: number }[];
  conversion: { with_session: number; converted: number };
  supply_gap: SupplyGapRow[];
  min_sample: number;
  definitions: Record<string, string>;
}

export interface GrowthEngagement {
  offers: { views: number; coupons: { id: string; title: string; restaurant: string; discount_type: string; claims: number; redemptions: number; orders: number }[];
    by_type: { discount_type: string; claims: number; redemptions: number }[] };
  menu: { items: { id: string; name: string; restaurant: string; views: number; add_to_cart: number; ordered: number; order_rate: number | null }[];
    searched_terms: { term: string; searches: number; zero_results: number }[] };
  ai: { queries: number; errors: number; intents: { intent: string; count: number }[]; result_clicks: number; map_opens: number; reservation_clicks: number; bookings: number; orders: number;
    no_results: number; no_result_top: { city: string | null; category: string | null; term: string | null; count: number }[]; cost_cents: number; cost_per_assisted_conversion_cents: number | null; note: string };
  referral: { shared: number; registered: number; qualified: number; points_issued: number; point_value_cents: number | null; k_factor: number | null; k_factor_note: string };
  loyalty: { points_issued: number; points_redeemed: number; outstanding: number; reward_claims: number; repeat_users: number };
  reviews: { new: number; verified: number; avg_rating: number | null; responded: number; reviewers_returned: number; reviewers: number; note: string };
  min_sample: number;
}

export type FeedbackCategory = 'bug' | 'feature_request' | 'ux' | 'restaurant_data' | 'pricing' | 'delivery' | 'other' | 'uncategorized';
export interface GrowthVoice {
  feedback: { total: number; by_category: { category: FeedbackCategory; count: number; recent: { id: string; message: string; type: string; page: string | null; created_at: string }[] | null }[];
    nps: { responses: number; promoters: number; detractors: number }; summary_basis: string };
  support: { total: number; open: number; reopened: number; median_resolution_hours: number | null; by_category: { category: string; count: number }[];
    product_insights: { category: string; count: number; message: string }[]; insight_threshold: number };
}

export interface GrowthSegments {
  customers: { key: string; count: number; marketing_consent: number }[];
  restaurants: { key: string; count: number }[];
  definitions: Record<string, string>;
}

export interface ReadinessItem { ok: boolean; detail: string }
export interface MarketReadiness { data: ReadinessItem; sales: ReadinessItem; seo: ReadinessItem; operational: ReadinessItem; launch_ready: ReadinessItem; playbook: Record<string, { done: number; total: number }> }
export interface GrowthMarketRow {
  id: string; slug: string; name: string; status: string; restaurants: number; claimed: number; paying: number; users: number; searches_30d: number; zero_results_30d: number;
  reservations_30d: number; orders_30d: number; gmv_30d_cents: number; mrr_cents: number; supply_gaps: number; visits_30d: number; visits_prev_30d: number;
  traffic_growth_pct: number | null; readiness: MarketReadiness | null;
}
export interface MarketCandidate {
  slug: string; name: string; province_code: string | null; region_name: string | null; status: 'candidate' | 'researching' | 'market_created' | 'rejected';
  market_id: string | null; province_id: string | null; has_province: boolean; research_started_at: string | null;
  inputs: Record<MarketScoreKey, number> & { zero_results: number; supply: number };
  score: number; breakdown: Record<MarketScoreKey, number>; data_points: number; readiness: MarketReadiness | null;
}
export interface GrowthMarkets { markets: GrowthMarketRow[]; candidates: MarketCandidate[]; weights: Record<MarketScoreKey, number> }

export interface PlaybookItem { id: string; market_id: string; stage: 'research' | 'data' | 'sales' | 'seo' | 'partners' | 'beta_users' | 'launch'; sort: number; title: string; hint: string | null; done_at: string | null }
export interface GrowthLearning { id: string; market_id: string | null; market_slug?: string | null; category: string; title: string; description: string; evidence_json: unknown; confidence: 'low' | 'medium' | 'high'; created_at: string }
export interface MarketPlaybook { market_id: string | null; readiness: MarketReadiness | null; items: PlaybookItem[]; learnings: GrowthLearning[] }

export interface MarketReview {
  market: { id: string; slug: string; name: string; status: string };
  goals: { metric_key: string; target: number; actual: number | null; gap: number; pct: number | null; status: string; period_start: string; period_end: string }[];
  correlated: {
    pipeline: Record<string, number>; restaurants_indexed: number; restaurants_claimed: number; restaurants_paying: number;
    trials: { started: number; ended: number; converted: number }; activated: number; users_d30: RetentionPoint; conversions_30d: number;
  };
  note: string;
}

export type AlertSeverity = 'info' | 'warning' | 'critical';
export interface GrowthAlert {
  id: string; key: string; severity: AlertSeverity; category: string; title: string; detail: string | null; link: string | null; metric: Record<string, unknown>;
  status: 'open' | 'acknowledged' | 'resolved'; first_seen_at: string; last_seen_at: string; resolved_at: string | null;
}

export interface AutomationRule {
  id: string; key: string; name: string; description: string; audience: 'consumer' | 'restaurant' | 'sales'; trigger_key: string;
  action: 'create_crm_task' | 'owner_notification' | 'draft_user_message' | 'unavailable'; enabled: boolean; requires_approval: boolean; consent_required: boolean;
  config: Record<string, unknown>; interval_minutes: number; owner_id: string | null; owner_name: string | null; last_run_at: string | null; next_run_at: string | null;
  failure_count: number; last_error: string | null; pending_items: number; created_at: string; updated_at: string;
  last_run: { status: string; records_affected: number; started_at: string; completed_at: string | null; error: string | null } | null;
}
export interface AutomationRun { id: string; rule_id: string; rule_name: string; trigger: 'schedule' | 'manual' | 'dry_run'; status: 'running' | 'success' | 'failed' | 'skipped'; records_affected: number; started_at: string; completed_at: string | null; error: string | null }
export interface AutomationItem {
  id: string; rule_id: string; rule_name: string; status: 'pending_approval' | 'approved' | 'rejected' | 'sent' | 'done' | 'skipped'; title: string; body: string | null; link: string | null;
  restaurant_id: string | null; restaurant_name: string | null; has_recipient: boolean; payload: Record<string, unknown>; created_at: string; decided_at: string | null; sent_at: string | null;
}

export type GuardrailArea = 'none' | 'pricing' | 'consent' | 'security' | 'accessibility';
export interface GrowthExperiment {
  id: string; key: string; name: string; hypothesis: string | null; primary_metric: string | null; secondary_metrics: string[]; variants: string[]; status: 'draft' | 'running' | 'stopped';
  started_at: string | null; stopped_at: string | null; end_at: string | null; guardrail_area: GuardrailArea; review_approved_at: string | null; review_note: string | null;
  created_at: string; allocations: { name: string; allocation: number }[]; assignments: number; same_creator: boolean;
}
export interface ExperimentReport { experiment: GrowthExperiment; variants: { variant: string; allocation: number; users: number; conversions: number }[]; min_sample: number; exposures: number }

export interface GrowthReport { id: string; period_start: string; period_end: string; market_id: string | null; report_type: 'weekly' | 'monthly' | 'custom'; metrics_json: Record<string, unknown>; summary: string; created_at: string }
export interface TodayItem { priority: number; kind: string; title: string; detail: string | null; link: string }
export interface GrowthTask {
  id: string; market_id: string | null; market_slug: string | null; title: string; description: string | null; source: 'manual' | 'insight' | 'alert' | 'expansion' | 'report';
  source_ref: string | null; priority: 'low' | 'normal' | 'high'; status: 'open' | 'done' | 'dismissed'; due_at: string | null; created_at: string; done_at: string | null;
}

export interface CostLine { key: string; label: string; cents: number | null; source: 'computed' | 'real' | 'assumption' | 'manual' }
export interface OperatingCost { id: string; category: string; amount_cents: number; period_start: string; period_end: string; notes: string | null; created_at: string }
export interface GrowthCosts {
  costs: CostLine[];
  unit: { revenue_per_paid_restaurant_cents: number | null; ai_cost_per_active_user_cents: number | null; processing_cost_per_order_cents: number | null; contribution_margin_cents: number; assumptions: (string | null)[] };
  counts: { orders: number; active_users: number; paying_restaurants: number };
  manual: OperatingCost[];
}

export interface LearningEvidence {
  outreach: { channel: string; contacts: number; replied: number; rate: number | null; confidence: 'low' | 'medium' | 'high' }[];
  trial_conversion: { ended: number; converted: number };
  qr: { scans: number; visits: number; signups: number };
  acquisition: { channel: string; signups: number }[];
  note: string;
}

export interface SearchLogInput { query?: string | null; city_slug?: string | null; category_slug?: string | null; result_count: number; result_ids?: string[]; source?: string; session_id?: string | null }

export interface GrowthApi {
  overview(from: string, to: string, market?: string | null): Promise<GrowthOverview>;
  funnels(from: string, to: string, market?: string | null): Promise<GrowthFunnels>;
  retention(weeks?: number): Promise<GrowthRetention>;
  restaurants(p: { from: string; to: string; market?: string | null; status?: string | null; search?: string | null; limit?: number; offset?: number }): Promise<GrowthRestaurantsPage>;
  churn(from: string, to: string): Promise<GrowthChurn>;
  revenue(from: string, to: string): Promise<GrowthRevenue>;
  acquisition(from: string, to: string): Promise<GrowthAcquisition>;
  search(from: string, to: string, market?: string | null): Promise<GrowthSearch>;
  engagement(from: string, to: string): Promise<GrowthEngagement>;
  voice(from: string, to: string): Promise<GrowthVoice>;
  setFeedbackCategory(id: string, category: string | null): Promise<void>;
  segments(): Promise<GrowthSegments>;
  markets(): Promise<GrowthMarkets>;
  startResearch(slug: string): Promise<{ market_id: string; playbook_items: number; tasks: number }>;
  playbook(market: string): Promise<MarketPlaybook>;
  setPlaybookItem(id: string, done: boolean): Promise<void>;
  marketReview(market?: string): Promise<MarketReview>;
  alerts(status?: string | null): Promise<GrowthAlert[]>;
  setAlert(id: string, status: GrowthAlert['status']): Promise<void>;
  refreshAlerts(): Promise<{ active: number; resolved: number }>;
  automationRules(): Promise<{ kill_switch: boolean; rules: AutomationRule[] }>;
  updateAutomationRule(id: string, patch: { enabled?: boolean; interval_minutes?: number; owner_id?: string | null; config?: Record<string, unknown> }): Promise<void>;
  runAutomation(id: string, dryRun?: boolean): Promise<{ run_id: string; status: string; records_affected?: number; error?: string; dry_run?: boolean }>;
  setKillSwitch(on: boolean): Promise<void>;
  automationRuns(ruleId?: string | null): Promise<AutomationRun[]>;
  automationItems(status?: string | null): Promise<AutomationItem[]>;
  decideAutomationItem(id: string, approve: boolean): Promise<string>;
  experiments(): Promise<GrowthExperiment[]>;
  upsertExperiment(p: Omit<Partial<GrowthExperiment>, 'variants'> & { variants?: { name: string; allocation: number }[] | string[] }): Promise<string>;
  setExperimentStatus(id: string, status: GrowthExperiment['status']): Promise<void>;
  reviewExperiment(id: string, note: string): Promise<void>;
  experimentReport(id: string): Promise<ExperimentReport>;
  reports(): Promise<GrowthReport[]>;
  generateReport(type: GrowthReport['report_type'], from: string, to: string, market?: string | null): Promise<string>;
  today(): Promise<TodayItem[]>;
  tasks(status?: string | null): Promise<GrowthTask[]>;
  upsertTask(p: { id?: string; title: string; description?: string | null; source?: GrowthTask['source']; source_ref?: string | null; priority?: GrowthTask['priority']; market?: string | null; due_at?: string | null }): Promise<string>;
  setTaskStatus(id: string, status: GrowthTask['status']): Promise<void>;
  learnings(): Promise<GrowthLearning[]>;
  learningEvidence(market?: string): Promise<LearningEvidence>;
  upsertLearning(p: { id?: string; market?: string | null; category: string; title: string; description: string; evidence?: unknown; confidence: GrowthLearning['confidence'] }): Promise<string>;
  deleteLearning(id: string): Promise<void>;
  costs(from: string, to: string): Promise<GrowthCosts>;
  addCost(p: { category: string; amount_cents: number; period_start: string; period_end: string; notes?: string | null }): Promise<string>;
  deleteCost(id: string): Promise<void>;
  settings(): Promise<Record<string, unknown>>;
  setSetting(key: string, value: unknown): Promise<void>;
  backfill(from: string, to: string): Promise<{ days: number }>;
  // Ristoratore (solo i propri locali)
  performance(restaurantId: string): Promise<RestaurantPerformance>;
  // Pubblico (fire-and-forget, senza dati personali)
  logSearch(p: SearchLogInput): void;
  experimentAssign(key: string, variant: string, anonymousId: string): void;
  experimentGoal(metric: string, anonymousId: string): void;
}

export const SEGMENT_LABELS: Record<string, string> = {
  new: 'Nuovi', active: 'Attivi', returning: 'Di ritorno', dormant: 'Dormienti', sushi_lovers: 'Amanti del sushi', ayce_users: 'All You Can Eat', offer_seekers: 'Cercatori di offerte',
  order_users: 'Ordinano online', booking_users: 'Prenotano', new_lead: 'Nuovi lead', claimed: 'Rivendicati', trial: 'In prova', activated: 'Attivati', paid: 'Paganti',
  high_engagement: 'Alto coinvolgimento', at_risk: 'A rischio', churned: 'Persi',
};
export const HEALTH_LABELS: Record<HealthStatus, string> = { healthy: 'In salute', needs_attention: 'Da seguire', at_risk: 'A rischio', unknown: 'Dati insufficienti', not_claimed: 'Non rivendicato' };
export const FEEDBACK_CATEGORY_LABELS: Record<FeedbackCategory, string> = {
  bug: 'Bug', feature_request: 'Richiesta funzione', ux: 'Esperienza d\'uso', restaurant_data: 'Dati ristorante', pricing: 'Prezzi', delivery: 'Consegna', other: 'Altro', uncategorized: 'Da classificare',
};
export const PLAYBOOK_STAGES: { key: PlaybookItem['stage']; label: string }[] = [
  { key: 'research', label: 'Ricerca' }, { key: 'data', label: 'Dati' }, { key: 'sales', label: 'Vendite' }, { key: 'seo', label: 'SEO' },
  { key: 'partners', label: 'Partner' }, { key: 'beta_users', label: 'Utenti beta' }, { key: 'launch', label: 'Lancio' },
];
export const COST_CATEGORIES = ['ai', 'email', 'push', 'maps', 'payment_processing', 'infrastructure', 'ads', 'other'] as const;
export const COST_CATEGORY_LABELS: Record<(typeof COST_CATEGORIES)[number], string> = {
  ai: 'AI', email: 'Email', push: 'Push', maps: 'Mappe', payment_processing: 'Incasso pagamenti', infrastructure: 'Infrastruttura', ads: 'Pubblicità', other: 'Altro',
};
export const GOAL_METRIC_LABELS: Record<string, string> = {
  restaurants_listed: 'Ristoranti censiti', restaurants_verified: 'Ristoranti verificati', restaurants_claimed: 'Ristoranti rivendicati', restaurants_partner: 'Partner attivi',
  restaurants_paying: 'Ristoranti paganti', users_registered: 'Utenti registrati', users_active_30d: 'Utenti attivi (30 giorni)', reservations: 'Prenotazioni',
  orders_completed: 'Ordini completati', coupon_claims: 'Coupon richiesti', referrals_qualified: 'Inviti qualificati', reviews_published: 'Recensioni pubblicate',
  sponsored_campaigns: 'Campagne sponsorizzate', mrr_cents: 'MRR', qr_scans: 'Scansioni QR', food_connections: 'Connessioni (North Star)',
};
