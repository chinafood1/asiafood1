// Tipi dell'assistente AI lato app. Le forme dei dati arrivano dal modulo condiviso (server + DEMO).
export type {
  AiCoupon,
  AiFilters,
  AiFollowUp,
  AiIntent,
  AiMenuItem,
  AiOffer,
  AiResponse,
  AiRestaurant,
  AiRestaurantDetail,
  OpenStatus,
} from '@shared/ai/types';
import type { AiResponse } from '@shared/ai/types';

export interface AiChatInput {
  /** ID casuale generato nel browser (mai dati personali). */
  session_id: string;
  message: string;
  /** Contesto "Chiedi informazioni su questo ristorante". */
  restaurant_id?: string | null;
  /** Solo per la richiesta corrente: il server la arrotonda e non la salva. */
  location?: { lat: number; lng: number } | null;
  location_denied?: boolean;
}

export interface AiChatReply {
  response: AiResponse;
  remaining?: number;
}

export type AiErrorCode = 'RATE_LIMITED' | 'AI_DISABLED' | 'TOO_LONG' | 'EMPTY' | 'FORBIDDEN' | 'UNAUTHORIZED' | 'OFFLINE' | 'TIMEOUT' | 'NETWORK' | 'AI_ERROR' | 'NOT_CONFIGURED' | string;

export class AiError extends Error {
  constructor(
    readonly code: AiErrorCode,
    message: string,
    readonly status = 0,
  ) {
    super(message);
    this.name = 'AiError';
  }
}

export const DIETARY_OPTIONS = [
  { value: 'vegetarian', label: 'Vegetariano' },
  { value: 'vegan', label: 'Vegano' },
  { value: 'gluten_free', label: 'Senza glutine' },
  { value: 'no_spicy', label: 'Niente piccante' },
] as const;

export interface AiPreferences {
  favorite_categories: string[];
  preferred_price_range: number | null;
  dietary_preferences: string[];
  favorite_cities: string[];
}

export interface AiAdminStats {
  requests_today: number;
  requests_month: number;
  requests_period: number;
  input_tokens: number;
  output_tokens: number;
  estimated_cost: number;
  error_rate: number;
  fallback_rate: number;
  no_results_rate: number;
  rate_limited: number;
  cache_hits: number;
  avg_latency_ms: number;
  intents: { intent: string; count: number }[];
  daily: { day: string; requests: number; errors: number }[];
  conversions: { result_clicks: number; reservations: number; coupon_claims: number; map_opens: number };
  active_sessions: number;
}

export interface RestaurantAiStats {
  profile_views: number;
  result_clicks: number;
  directions_clicks: number;
  phone_clicks: number;
  reservations: number;
  coupon_claims: number;
}

/** Chiavi di configurazione (platform_settings). La chiave API NON è mai qui: resta un secret del server. */
export const AI_SETTING_KEYS = [
  'ai_enabled', 'ai_provider', 'ai_model', 'ai_guest_limit_per_hour', 'ai_user_limit_per_hour', 'ai_premium_limit_per_hour',
  'ai_max_restaurants', 'ai_temperature', 'ai_max_tokens', 'ai_chat_retention_days', 'ai_cache_ttl_seconds',
] as const;
export type AiSettingKey = (typeof AI_SETTING_KEYS)[number];
