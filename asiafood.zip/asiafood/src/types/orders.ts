// ─────────────────────────────────────────────────────────────
//  Fase 8 · Marketplace ordini (takeaway e delivery).
//  Tutti gli importi "che contano" (prezzi, sconti, consegna,
//  commissioni, totale, stato del pagamento) sono calcolati dal
//  server: qui solo i tipi delle letture e degli input.
// ─────────────────────────────────────────────────────────────

export type OrderType = 'takeaway' | 'delivery';
export type OrderStatus =
  | 'pending_payment' | 'payment_authorized' | 'pending_restaurant' | 'accepted' | 'preparing' | 'ready'
  | 'out_for_delivery' | 'completed' | 'rejected' | 'cancelled' | 'refunded' | 'partially_refunded';
export type PaymentStatus = 'unpaid' | 'pending' | 'authorized' | 'paid' | 'failed' | 'refunded' | 'partially_refunded';
export type FulfillmentStatus = 'unfulfilled' | 'preparing' | 'ready' | 'picked_up' | 'out_for_delivery' | 'delivered' | 'cancelled';
export type DeliveryFeeType = 'fixed' | 'distance' | 'zone' | 'free';
export type RejectReason = 'too_busy' | 'item_unavailable' | 'closed' | 'out_of_area' | 'technical' | 'other';
export type IssueType = 'not_arrived' | 'wrong_order' | 'missing_item' | 'late' | 'payment' | 'quality' | 'other';
export type RestaurantOrderTab = 'new' | 'preparing' | 'ready' | 'delivering' | 'completed' | 'cancelled';

export const REJECT_REASONS: { value: RejectReason; label: string }[] = [
  { value: 'too_busy', label: 'Troppi ordini in questo momento' },
  { value: 'item_unavailable', label: 'Prodotto non disponibile' },
  { value: 'closed', label: 'Chiusura imprevista' },
  { value: 'out_of_area', label: 'Indirizzo fuori zona di consegna' },
  { value: 'technical', label: 'Problema tecnico' },
  { value: 'other', label: 'Altro' },
];

export const ISSUE_TYPES: { value: IssueType; label: string }[] = [
  { value: 'not_arrived', label: 'Ordine non arrivato' },
  { value: 'wrong_order', label: 'Ordine sbagliato' },
  { value: 'missing_item', label: 'Prodotto mancante' },
  { value: 'late', label: 'Ritardo' },
  { value: 'payment', label: 'Pagamento' },
  { value: 'quality', label: 'Qualità' },
  { value: 'other', label: 'Altro' },
];

// ─── Menu: scelte strutturate ───────────────────────────────
export interface MenuOption {
  id: string;
  option_group_id: string;
  restaurant_id: string;
  name: string;
  price: number;
  is_available: boolean;
  display_order: number;
}
export interface MenuOptionGroup {
  id: string;
  menu_item_id: string;
  restaurant_id: string;
  name: string;
  min_select: number;
  max_select: number;
  required: boolean;
  display_order: number;
  is_active: boolean;
  options: MenuOption[];
}

// ─── Configurazione del ristorante ──────────────────────────
export interface RestaurantOrderSettings {
  id: string;
  restaurant_id: string;
  orders_enabled: boolean;
  takeaway_enabled: boolean;
  delivery_enabled: boolean;
  minimum_order_amount: number;
  takeaway_minimum_order: number | null;
  delivery_minimum_order: number | null;
  default_preparation_minutes: number;
  busy_extra_minutes: number;
  delivery_estimated_minutes: number;
  slot_interval_minutes: number;
  max_orders_per_slot: number | null;
  accept_orders_automatically: boolean;
  allow_scheduled_orders: boolean;
  max_advance_days: number;
  delivery_radius_km: number | null;
  free_delivery_threshold: number | null;
  delivery_fee_type: DeliveryFeeType;
  delivery_fee: number;
  /** restaurant = consegna del locale; asiafood = Rider AsiaFood (Fase 9); external = provider esterno (predisposto). */
  delivery_provider_type: 'restaurant' | 'asiafood' | 'external' | 'platform_future' | 'external_future';
  /** Abilitazione ai Rider AsiaFood: la concede solo l'Admin. */
  asiafood_delivery_enabled?: boolean;
  service_fee_enabled: boolean;
  orders_paused_until: string | null;
  delivery_paused_until: string | null;
  takeaway_paused_until: string | null;
  pickup_instructions: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface DeliveryZone {
  id: string;
  restaurant_id: string;
  name: string;
  zone_type: 'radius' | 'distance' | 'polygon';
  radius_km: number | null;
  min_distance_km: number | null;
  max_distance_km: number | null;
  polygon?: unknown;
  delivery_fee: number;
  minimum_order: number;
  estimated_delivery_minutes: number;
  is_active: boolean;
}

export interface Slot {
  at: string;
  time: string;
  status: 'available' | 'full';
  date?: string;
}

/** Informazioni pubbliche per la scheda ristorante. */
export interface OrderPublicInfo {
  enabled: boolean;
  payments_ready?: boolean;
  open_now?: boolean;
  open_status?: 'open' | 'closed' | 'unknown';
  temporarily_closed?: boolean;
  paused_until?: string | null;
  preparation_minutes?: number;
  busy?: boolean;
  allow_scheduled?: boolean;
  max_advance_days?: number;
  minimum_order?: number;
  pickup_instructions?: string | null;
  service_fee?: number;
  takeaway?: { enabled: boolean; state: 'ok' | 'paused' | 'disabled'; paused_until: string | null; minimum_order: number; next_slot: Slot | null };
  delivery?: {
    enabled: boolean;
    state: 'ok' | 'paused' | 'disabled';
    paused_until: string | null;
    minimum_order: number;
    fee_type: DeliveryFeeType;
    fee: number;
    radius_km: number | null;
    free_threshold: number | null;
    estimated_minutes: number;
    provider: string;
    zones: { name: string; type: string; min_km: number; max_km: number; fee: number; minimum_order: number; eta_minutes: number }[];
    next_slot: Slot | null;
  };
}

export interface OrderableRestaurant {
  restaurant_id: string;
  takeaway: boolean;
  delivery: boolean;
  order_now: boolean;
  payments_ready: boolean;
  delivery_radius_km: number | null;
}

// ─── Carrello (locale) ──────────────────────────────────────
export interface CartLine {
  /** Chiave locale della riga (stesso piatto con scelte diverse = righe diverse). */
  key: string;
  menu_item_id: string;
  name: string;
  image_url: string | null;
  variant_id: string | null;
  variant_name: string | null;
  addons: { id: string; name: string; price: number; quantity: number }[];
  options: { id: string; group: string; name: string; price: number }[];
  quantity: number;
  notes: string | null;
  /** Prezzo unitario mostrato quando è stato aggiunto (NON autorevole: il server ricalcola). */
  unit_price: number;
}

export interface Cart {
  restaurant_id: string;
  restaurant_name: string;
  restaurant_slug: string;
  lines: CartLine[];
  updated_at: string;
  /** Ultima verifica con il server di prezzi e disponibilità. */
  validated_at: string | null;
}

// ─── Indirizzi ───────────────────────────────────────────────
export interface AddressInput {
  id?: string | null;
  label?: string | null;
  recipient_name: string;
  phone: string;
  address_line_1: string;
  address_line_2?: string | null;
  city: string;
  province?: string | null;
  postal_code: string;
  country?: string;
  latitude: number | null;
  longitude: number | null;
  geocode_source?: 'geocoder' | 'device' | 'demo' | null;
  delivery_notes?: string | null;
}
export interface CustomerAddress extends AddressInput {
  id: string;
  user_id: string;
  is_default: boolean;
  created_at: string;
}

// ─── Preventivo ─────────────────────────────────────────────
export interface QuoteInput {
  restaurant_id: string;
  order_type: OrderType;
  items: { menu_item_id: string; variant_id?: string | null; addons?: { id: string; quantity: number }[]; options?: string[]; quantity: number; notes?: string | null }[];
  address?: AddressInput | null;
  scheduled_for?: string | null;
  coupon_code?: string | null;
  reward_code?: string | null;
  contact?: { name?: string; email?: string; phone?: string };
  notes?: string | null;
  source?: 'web' | 'app' | 'ai' | 'reorder';
}

export interface OrderError {
  code: string;
  message: string;
  index?: number;
  field?: string;
  next_slot?: Slot | null;
  minimum?: number;
  missing?: number;
}

export interface QuoteLine {
  index: number;
  menu_item_id: string;
  name: string | null;
  variant_id: string | null;
  variant_name: string | null;
  base_price: number;
  addons_total: number;
  unit_price: number;
  quantity: number;
  line_total: number;
  options: { kind: 'addon' | 'option'; id: string; group: string; name: string; price: number; quantity: number }[];
  notes: string | null;
  available: boolean;
}

export interface Quote {
  ok: boolean;
  errors: OrderError[];
  restaurant?: { id: string; name: string; slug: string };
  order_type?: OrderType;
  lines?: QuoteLine[];
  subtotal?: number;
  coupon_discount?: number;
  loyalty_discount?: number;
  discount_total?: number;
  delivery_fee?: number;
  service_fee?: number;
  tax_total?: number | null;
  total?: number;
  currency?: string;
  minimum_order?: number;
  codes?: { ok: boolean; code: string; title?: string; discount?: number; is_reward?: boolean; error?: string; message?: string }[];
  delivery?: { distance_km: number | null; zone_id: string | null; zone_name: string | null; eta_minutes: number | null } | null;
  scheduled_for?: string | null;
  estimated_ready_at?: string | null;
  estimated_delivery_at?: string | null;
  preparation_minutes?: number;
  payment_mode?: 'connect' | 'platform_test' | 'demo' | null;
  payments_ready?: boolean;
}

// ─── Checkout ───────────────────────────────────────────────
export interface CheckoutResult {
  ok: boolean;
  errors?: OrderError[];
  order_id?: string;
  order_number?: string;
  access_token?: string;
  /** Stripe PaymentIntent client_secret (solo con Supabase/Stripe). */
  client_secret?: string | null;
  total?: number;
  payment_mode?: 'connect' | 'platform_test' | 'demo';
  /** true = pagamento simulato (modalità DEMO, nessun addebito). */
  simulated?: boolean;
}

// ─── Ordine (vista cliente) ─────────────────────────────────
export interface OrderItemView {
  id: string;
  menu_item_id: string | null;
  name: string;
  variant_id: string | null;
  variant: string | null;
  quantity: number;
  unit_price: number;
  addons_total: number;
  line_total: number;
  notes: string | null;
  options: { kind: string; group: string | null; name: string; price: number; quantity: number }[];
}

export interface OrderView {
  id: string;
  order_number: string;
  order_type: OrderType;
  status: OrderStatus;
  payment_status: PaymentStatus;
  fulfillment_status: FulfillmentStatus;
  restaurant: { id: string; name: string; slug: string; address: string | null; city: string | null; phone: string | null; latitude: number | null; longitude: number | null; pickup_instructions: string | null };
  customer_name: string;
  customer_phone: string;
  customer_email: string;
  delivery_address: (AddressInput & { latitude?: number | null; longitude?: number | null }) | null;
  items: OrderItemView[];
  subtotal: number;
  coupon_discount: number;
  loyalty_discount: number;
  discount_total: number;
  delivery_fee: number;
  service_fee: number;
  tax_total: number | null;
  total: number;
  currency: string;
  coupon_code: string | null;
  amount_paid: number;
  amount_refunded: number;
  scheduled_for: string | null;
  estimated_ready_at: string | null;
  estimated_delivery_at: string | null;
  preparation_minutes: number | null;
  customer_notes: string | null;
  reject_reason: string | null;
  cancel_reason: string | null;
  created_at: string;
  paid_at: string | null;
  accepted_at: string | null;
  rejected_at: string | null;
  preparing_at: string | null;
  ready_at: string | null;
  picked_up_at: string | null;
  out_for_delivery_at: string | null;
  completed_at: string | null;
  cancelled_at: string | null;
  can_cancel: boolean;
  can_pay: boolean;
  refunds: { amount: number; status: string; created_at: string; processed_at: string | null }[];
  issues: { id: string; type: IssueType; status: string; resolution: string | null; created_at: string }[];
  reviewable: boolean;
  is_owner: boolean;
}

export interface MyOrderSummary {
  id: string;
  order_number: string;
  status: OrderStatus;
  payment_status: PaymentStatus;
  order_type: OrderType;
  total: number;
  created_at: string;
  scheduled_for: string | null;
  estimated_ready_at: string | null;
  restaurant: { id: string; name: string; slug: string; logo_url: string | null };
  items_count: number;
  summary: string | null;
}

// ─── Terminale ristorante ───────────────────────────────────
export interface RestaurantOrder {
  id: string;
  order_number: string;
  status: OrderStatus;
  payment_status: PaymentStatus;
  order_type: OrderType;
  created_at: string;
  paid_at: string | null;
  scheduled_for: string | null;
  estimated_ready_at: string | null;
  estimated_delivery_at: string | null;
  accepted_at: string | null;
  ready_at: string | null;
  preparation_minutes: number | null;
  customer_name: string;
  customer_phone: string | null;
  delivery_address: Partial<AddressInput> | null;
  delivery_distance_km: number | null;
  customer_notes: string | null;
  restaurant_notes: string | null;
  subtotal: number;
  discount_total: number;
  delivery_fee: number;
  service_fee: number;
  total: number;
  coupon_code: string | null;
  platform_fee: number;
  restaurant_gross: number;
  restaurant_net_estimated: number;
  amount_paid: number;
  amount_refunded: number;
  reject_reason: string | null;
  cancel_reason: string | null;
  is_repeat_customer: boolean;
  items: { name: string; variant: string | null; quantity: number; line_total: number; notes: string | null; options: { group: string | null; name: string; quantity: number }[] }[];
  refunds: { amount: number; status: string; reason: string; created_at: string }[];
  open_issues: number;
}

export interface RestaurantOrdersPage {
  counts: Record<RestaurantOrderTab, number>;
  can_refund: boolean;
  items: RestaurantOrder[];
}

export interface PayoutAccount {
  stripe_account_id: string;
  stripe_environment: 'test' | 'live';
  onboarding_completed: boolean;
  charges_enabled: boolean;
  payouts_enabled: boolean;
  details_submitted: boolean;
  requirements_due: string[];
  updated_at: string;
}

export interface PayoutStatus {
  configured: boolean;
  environment: 'test' | 'live';
  account: PayoutAccount | null;
  simulated?: boolean;
  platform_collection_test?: boolean;
}

// ─── Admin ───────────────────────────────────────────────────
export interface AdminOrderRow {
  id: string;
  order_number: string;
  restaurant: { id: string; name: string; slug: string };
  city: string | null;
  customer_name: string;
  order_type: OrderType;
  total: number;
  status: OrderStatus;
  payment_status: PaymentStatus;
  platform_fee: number;
  service_fee: number;
  amount_refunded: number;
  risk_flags: string[];
  created_at: string;
  open_issues: number;
}

export interface AdminOrderDetail extends OrderView {
  internal: {
    commission_percent: number;
    commission_fixed: number;
    platform_fee: number;
    restaurant_gross: number;
    restaurant_net_estimated: number;
    payment_processing_fee: number | null;
    payment_mode: string;
    payout_destination: string | null;
    stripe_environment: string | null;
    stripe_payment_intent_id: string | null;
    stripe_charge_id: string | null;
    payment_failures: number;
    risk_flags: string[];
    internal_notes: string | null;
    restaurant_notes: string | null;
    source: string;
    user_id: string | null;
    delivery_distance_km: number | null;
  };
  events: { type: string; actor: string; metadata: Record<string, unknown>; created_at: string }[];
  refunds_admin: { id: string; amount: number; status: string; reason: string; stripe_refund_id: string | null; error: string | null; requested_by_type: string; created_at: string; processed_at: string | null }[];
  issues_admin: { id: string; type: IssueType; description: string; status: string; resolution: string | null; created_at: string }[];
}

export interface AdminOrderFilters {
  q?: string;
  status?: string;
  payment_status?: string;
  order_type?: string;
  restaurant_id?: string;
  city_id?: string;
  from?: string;
  to?: string;
  issues?: boolean;
  limit?: number;
  offset?: number;
}

export interface MarketplaceStats {
  definitions: Record<string, string>;
  orders_today: number;
  orders_month: number;
  orders_period: number;
  valid_orders: number;
  gmv: number;
  gmv_net_of_refunds: number;
  aov: number;
  completed: number;
  cancelled: number;
  unpaid_expired: number;
  refund_rate: number;
  refunded_amount: number;
  takeaway: number;
  delivery: number;
  platform_revenue: number;
  platform_fees_pending: number;
  payments: { failed_attempts: number; awaiting_payment: number; awaiting_restaurant: number; refunds_pending: number; refunds_failed: number; disputes: number; risk_flagged: number; open_issues: number; webhook_failures: number };
  top_categories: { name: string; orders: number; gmv: number }[];
  top_cities: { name: string; orders: number; gmv: number }[];
  daily: { day: string; orders: number; gmv: number }[];
  funnel: { step: string; label: string; events: number; sessions: number | null }[];
  abandoned_carts: number;
}

export interface RestaurantOrderStats {
  orders: number;
  gross: number;
  commission: number;
  net_estimated: number;
  aov: number;
  takeaway: number;
  delivery: number;
  cancel_rate: number;
  repeat_customers: number;
  customers: number;
  coupon_orders: number;
  refunded: number;
  top_items: { name: string; quantity: number; revenue: number }[];
  avg_prep_minutes: number | null;
}

export interface CommissionSettings {
  global_percent: number;
  global_fixed: number;
  service_fee_enabled: boolean;
  service_fee_amount: number;
  overrides: { id: string; restaurant_id: string; restaurant_name: string; percentage_fee: number; fixed_fee: number; effective_from: string; note: string | null }[];
}

export interface OrdersTickResult {
  expired: number;
  accept_timeouts: number;
  reminders: number;
  abandoned_carts: number;
  refunds_processed?: number;
}

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  pending_payment: 'In attesa di pagamento',
  payment_authorized: 'Pagamento autorizzato',
  pending_restaurant: 'In attesa di conferma',
  accepted: 'Accettato',
  preparing: 'In preparazione',
  ready: 'Pronto',
  out_for_delivery: 'In consegna',
  completed: 'Completato',
  rejected: 'Rifiutato',
  cancelled: 'Annullato',
  refunded: 'Rimborsato',
  partially_refunded: 'Rimborsato in parte',
};

export const PAYMENT_STATUS_LABEL: Record<PaymentStatus, string> = {
  unpaid: 'Non pagato',
  pending: 'In corso',
  authorized: 'Autorizzato',
  paid: 'Pagato',
  failed: 'Non riuscito',
  refunded: 'Rimborsato',
  partially_refunded: 'Rimborsato in parte',
};
