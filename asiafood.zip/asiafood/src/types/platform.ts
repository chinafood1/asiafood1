// Tipi della Fase 11 (hardening): configurazione a runtime, privacy/GDPR, supporto, monitoraggio, launch checklist.
export type ConsentType = 'necessary' | 'analytics' | 'marketing' | 'personalization';
export type ConsentChoices = Record<Exclude<ConsentType, 'necessary'>, boolean>;

export interface ConsentState {
  policy_version: string;
  choices: Partial<Record<ConsentType, { granted: boolean; policy_version: string; at: string }>>;
  history?: { type: ConsentType; granted: boolean; policy_version: string; source: string; at: string }[];
}

export type LegalDocumentType = 'privacy' | 'cookie' | 'terms' | 'business_terms' | 'rider_privacy' | 'rider_terms';

export interface RuntimeConfig {
  settings: {
    maintenance_mode?: boolean;
    maintenance_message?: string | null;
    beta_mode?: boolean;
    beta_invite_only?: boolean;
    orders_enabled?: boolean;
    ai_enabled?: boolean;
    reviews_enabled?: boolean;
    loyalty_enabled?: boolean;
    referral_enabled?: boolean;
    push_enabled?: boolean;
    logistics_enabled?: boolean;
    rider_signup_enabled?: boolean;
    crm_agents_enabled?: boolean;
    upload_max_image_mb?: number;
    upload_max_document_mb?: number;
    consent_policy_version?: string;
    account_deletion_grace_days?: number;
    legal_company_name?: string | null;
    legal_vat_number?: string | null;
    legal_address?: string | null;
    legal_email?: string | null;
    legal_pec?: string | null;
    support_email?: string | null;
    [k: string]: unknown;
  };
  legal: Partial<Record<LegalDocumentType, { version: string; url: string; effective_at: string; draft: boolean }>>;
  server_time?: string;
}

export interface DataExportResult {
  request_id: string;
  data: Record<string, unknown>;
}

export type DeletionStatus = 'scheduled' | 'cancelled' | 'blocked' | 'anonymized' | 'completed';
export interface DeletionRequest {
  id: string;
  status: DeletionStatus;
  reason: string | null;
  requested_at: string;
  scheduled_for: string;
  completed_at: string | null;
  cancelled_at: string | null;
  blocked_reason: string | null;
}
export interface PrivacyStatus {
  deletion: DeletionRequest | null;
  exports: { id: string; status: string; requested_at: string; completed_at: string | null; expires_at: string | null }[];
  grace_days: number;
}

export type SupportCategory = 'order' | 'reservation' | 'account' | 'privacy' | 'restaurant' | 'business' | 'billing' | 'rider' | 'bug' | 'other'
  // Fase 12: categorie di lancio (clienti e ristoratori)
  | 'coupon' | 'points' | 'payments' | 'claim' | 'menu' | 'subscription' | 'ads';
export type SupportStatus = 'open' | 'in_progress' | 'waiting_customer' | 'resolved' | 'closed';
export type SupportPriority = 'low' | 'normal' | 'high' | 'urgent';
export interface SupportTicketInput {
  category: SupportCategory;
  subject: string;
  description: string;
  email?: string;
  name?: string;
  order_number?: string;
  order_token?: string;
  restaurant_id?: string;
  turnstile_token?: string | null;
}
export interface SupportTicket {
  id: string;
  reference: string;
  category: SupportCategory;
  subject: string;
  status: SupportStatus;
  resolution?: string | null;
  created_at: string;
  updated_at: string;
}
export interface AdminSupportTicket extends SupportTicket {
  priority: SupportPriority;
  description: string;
  contact_email: string | null;
  contact_name: string | null;
  admin_notes: string | null;
  order_number: string | null;
  restaurant_name: string | null;
  user_id: string | null;
  assigned_to: string | null;
}
export type SupportFilter = 'open' | 'urgent' | 'orders' | 'restaurants' | 'riders' | 'billing' | 'closed' | 'all';

export interface FlagState {
  flag: string;
  key: string;
  kind: 'feature' | 'kill_switch' | 'maintenance';
  label: string;
  value: boolean;
}

export interface SystemStatus {
  generated_at: string;
  alerts: { key: string; level: 'critical' | 'warning' | 'info'; message: string }[];
  flags: FlagState[];
  errors: { last_10min: number; last_24h: number; client_24h: number; recent: { id: number; source: string; code: string | null; message: string; route: string | null; request_id: string | null; created_at: string }[] };
  webhooks: { failed_24h: number; failed_7d: number; stuck: number; processed_24h: number; last_processed_at: string | null; recent_failed: { id: string; event_type: string; error: string | null; attempts: number; at: string }[] };
  jobs: { last_runs: { type: string; status: string; completed_at: string | null; started_at: string | null; error: string | null }[]; failed: { id: string; type: string; attempts: number; max_attempts: number; error: string | null; at: string }[]; running: number; stuck: number };
  email: { pending: number; failed_24h: number; sent_24h: number; oldest_pending_minutes: number | null };
  push: { enabled: boolean; pending: number; failed_24h: number; sent_24h: number; active_devices: number };
  ai: { enabled: boolean; requests_1h: number; errors_1h: number; fallback_1h: number; last_ok_at: string | null };
  payments: { failed_1h: number; succeeded_24h: number; refunds_pending: number };
  dispatch: { failed_1h: number; open_alerts: number; active_jobs: number };
  privacy: { deletions_scheduled: number; deletions_blocked: number; deletions_anonymized: number; exports_7d: number };
  support: { open: number; urgent: number };
  cleanup: { last_retention: { status: string; at: string | null; result: Record<string, number> | null } | null; rider_locations_overdue: number; rate_limit_rows: number; expired_ai_sessions: number };
  security: { rate_limited_24h: number; rate_limited_buckets: Record<string, number>; gps_flood_24h: number; admin_sessions_24h: number };
  web_vitals: Partial<Record<'LCP' | 'INP' | 'CLS' | 'FCP' | 'TTFB', { p75: number; samples: number }>>;
  system_checks: { key: string; status: string; notes: string | null; last_checked_at: string | null }[];
  db: { size_bytes: number | null; tables: { table: string; rows: number; dead: number; seq_scans: number; idx_scans: number }[] };
}

export type CheckStatus = 'pass' | 'fail' | 'warn' | 'pending' | 'na';
export type LaunchStatus = 'BLOCKED' | 'NOT_READY' | 'READY_FOR_BETA' | 'READY_FOR_PRODUCTION';
export interface LaunchCheck {
  key: string;
  section: string;
  title: string;
  crit_beta: boolean;
  crit_prod: boolean;
  kind: 'auto' | 'system' | 'manual';
  status: CheckStatus;
  detail?: string | null;
  last_checked_at?: string | null;
}
export interface CityReadiness {
  province: string;
  generated_at: string;
  restaurants: number;
  score: number;
  ready: boolean;
  critical_failing: number;
  checks: { key: string; label: string; critical: boolean; value: unknown; status: CheckStatus; target: string }[];
}
export interface LaunchChecklist {
  status: LaunchStatus;
  score: number;
  generated_at: string;
  blocking: { key: string; title: string; status: CheckStatus; stage: 'beta' | 'production' }[];
  checks: LaunchCheck[];
  city: CityReadiness;
}

export interface ConsistencyReport {
  generated_at: string;
  total_issues: number;
  checks: { key: string; label: string; severity: 'high' | 'medium' | 'low'; count: number; sample: string[] }[];
}

export interface AuditRow {
  id: number;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  actor: string | null;
  actor_role: string | null;
  metadata: Record<string, unknown>;
  ua: string | null;
  created_at: string;
}

export interface PrivacyRequests {
  deletions: { id: string; user_id: string | null; name: string | null; email_masked: string | null; status: DeletionStatus; requested_at: string; scheduled_for: string; blocked_reason: string | null; completed_at: string | null }[];
  exports: { id: string; user_id: string | null; status: string; requested_at: string; size_bytes: number | null }[];
}

export interface ClientErrorReport {
  message: string;
  code?: string;
  route?: string;
  release?: string;
  environment?: string;
}
export interface WebVitalReport {
  metric: 'LCP' | 'INP' | 'CLS' | 'FCP' | 'TTFB';
  value: number;
  rating?: 'good' | 'needs-improvement' | 'poor';
  route: string;
  device: 'mobile' | 'desktop';
}

export const SUPPORT_CATEGORY_LABEL: Record<SupportCategory, string> = {
  order: 'Ordine', reservation: 'Prenotazione', account: 'Account', privacy: 'Privacy e dati', restaurant: 'Informazioni su un locale',
  business: 'Per ristoratori', billing: 'Fatturazione / abbonamento', rider: 'Rider e consegne', bug: 'Problema tecnico', other: 'Altro',
  coupon: 'Coupon', points: 'AsiaPoints', payments: 'Pagamenti', claim: 'Ristoratori · Rivendicazione', menu: 'Ristoratori · Menu',
  subscription: 'Ristoratori · Abbonamento', ads: 'Ristoratori · Sponsorizzazioni',
};
export const SUPPORT_STATUS_LABEL: Record<SupportStatus, string> = {
  open: 'Aperto', in_progress: 'In lavorazione', waiting_customer: 'In attesa di risposta', resolved: 'Risolto', closed: 'Chiuso',
};
export const LAUNCH_STATUS_LABEL: Record<LaunchStatus, string> = {
  BLOCKED: 'Bloccato', NOT_READY: 'Non pronto', READY_FOR_BETA: 'Pronto per la beta', READY_FOR_PRODUCTION: 'Pronto per la produzione',
};
