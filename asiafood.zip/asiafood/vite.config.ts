import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import path from 'node:path';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const appName = env.VITE_APP_NAME || 'AsiaFood';
  const withSupabase = Boolean(env.VITE_SUPABASE_URL && env.VITE_SUPABASE_ANON_KEY);

  return {
    resolve: {
      alias: [
        // Build con Supabase: il database DEMO (≈ 450 KB di codice e dati di fantasia) resta fuori dal bundle
        ...(withSupabase && env.VITE_DEMO_FALLBACK !== 'true'
          ? [{ find: /^(\.\/|@\/services\/)demoSource$/, replacement: path.resolve(__dirname, 'src/services/demoSourceStub.ts') }]
          : []),
        { find: '@', replacement: path.resolve(__dirname, 'src') },
        { find: '@shared', replacement: path.resolve(__dirname, 'shared') },
      ],
    },
    plugins: [
      react(),
      {
        // Core Web Vitals: preload dei soli font essenziali (sottoinsieme latino) → meno spostamenti di testo (CLS)
        name: 'preload-essential-fonts',
        transformIndexHtml: {
          order: 'post',
          handler: (html, ctx) => {
            if (!ctx.bundle) return html;
            const fonts = Object.keys(ctx.bundle).filter((f) => /(inter-latin-wght-normal|bricolage-grotesque-latin-opsz-normal)-[^/]*\.woff2$/.test(f));
            const tags = fonts.map((f) => `<link rel="preload" href="/${f}" as="font" type="font/woff2" crossorigin>`).join('\n    ');
            return html.replace('</title>', `</title>\n    ${tags}`);
          },
        },
      },
      {
        // Nome brand sostituibile: VITE_APP_NAME (fallback "AsiaFood")
        name: 'inject-app-name',
        transformIndexHtml: (html) => {
          const out = html.replaceAll('__APP_NAME__', appName);
          // Fase 12: verifica Google Search Console (solo il token, caratteri sicuri; nessun segreto)
          const gsc = (env.VITE_GOOGLE_SITE_VERIFICATION ?? '').replace(/[^A-Za-z0-9_-]/g, '');
          return gsc ? out.replace('</head>', `    <meta name="google-site-verification" content="${gsc}" />\n  </head>`) : out;
        },
      },
      VitePWA({
        // Fase 11: aggiornamento su conferma ("È disponibile un aggiornamento" → Aggiorna), registrazione in UpdatePrompt
        registerType: 'prompt',
        injectRegister: null,
        includeAssets: ['favicon.svg', 'apple-touch-icon.png', 'robots.txt'],
        manifest: {
          name: appName,
          short_name: appName,
          description: 'Il meglio della cucina asiatica vicino a te.',
          lang: 'it',
          start_url: '/',
          scope: '/',
          display: 'standalone',
          orientation: 'portrait',
          background_color: '#FAF8F5',
          theme_color: '#16161A',
          categories: ['food', 'lifestyle', 'travel'],
          icons: [
            { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
            { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' },
            { src: '/icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
          ],
        },
        workbox: {
          // Gestori delle notifiche push (Fase 7)
          importScripts: ['/push-sw.js'],
          navigateFallback: '/index.html',
          navigateFallbackDenylist: [/^\/sitemap.*\.xml$/, /^\/robots\.txt$/, /^\/api\//, /^\/_redirects$/],
          cleanupOutdatedCaches: true,
          // Mai in cache: API private, ordini, pagamenti, dati personali (solo asset e immagini pubbliche)
          runtimeCaching: [
            { urlPattern: ({ url }) => url.pathname.startsWith('/api/') || /\/(rest|auth|realtime|functions)\/v1\//.test(url.pathname) || url.pathname.includes('/storage/v1/object/sign/'), handler: 'NetworkOnly' },
            {
              urlPattern: ({ url }) => url.hostname.includes('images.unsplash.com') || url.pathname.includes('/storage/v1/object/public/'),
              handler: 'CacheFirst',
              options: {
                cacheName: 'images',
                expiration: { maxEntries: 200, maxAgeSeconds: 60 * 60 * 24 * 30 },
              },
            },
          ],
        },
      }),
    ],
    build: {
      rollupOptions: {
        output: {
          manualChunks: {
            react: ['react', 'react-dom', 'react-router-dom'],
            supabase: ['@supabase/supabase-js'],
          },
        },
      },
    },
  };
});
