# Changelog

Formato: [Keep a Changelog](https://keepachangelog.com/it/1.1.0/). Versioni: [SemVer](https://semver.org/lang/it/).

## [0.3.0-beta] — Fase 13 · Business Intelligence & Growth Automation (non ancora rilasciata)

### Aggiunto
- **Growth Command Center** `/admin/growth` con periodi (Oggi, Ieri, 7/30/90 giorni, personalizzato), confronto con il periodo precedente solo se valido, freschezza del dato, avvisi di qualità dei dati, brief "Oggi" (max 10 priorità), metriche per board.
- **Tassonomia eventi canonica** (24 eventi) come adattatore sui nomi storici, metadati standard (dispositivo, UTM), nuovi eventi `session_started`, `favorite_added`, `referral_shared`, `conversion` (solo funnel).
- **Ricerche privacy-safe** (`search_events`, `log_search`): zero risultati, demand score, supply gap; filtri strutturati dell'assistente AI.
- **Aggregati giornalieri idempotenti** + backfill, job orario e giornaliero, MRR osservato vs ricostruito.
- Funnel consumer e B2B (velocità), retention D1/D7/D30, coorti, segmenti; ristoranti con **health score interno** e segnali di rischio; churn con motivi standard; ricavi (MRR/ARR/ARPA, LTV solo con storico); acquisizione first/last touch con CAC solo con dati; offerte, menu, AI (costo per conversione assistita, niente ROI), referral (K-factor solo con campione), AsiaPoints, recensioni; feedback e supporto (riaperture tracciate).
- **Mercati**: Market Opportunity Score trasparente con pesi configurabili, readiness, Next City, `/admin/expansion/next-market` con **Start Research** e playbook; Taranto review; knowledge base `growth_learnings`.
- **Alert e anomalie** con soglie minime e chiusura automatica.
- **Automazioni** (`automation_rules`, `automation_runs`, `automation_items`): kill switch, prova a vuoto, approvazione umana obbligatoria per i messaggi, consenso ricontrollato all'invio, auto-disattivazione dopo 5 errori, audit.
- **Esperimenti**: varianti con allocazione, assegnazioni e conversioni (solo con consenso), guardrail con revisione di un secondo Admin, report senza falsi vincitori.
- **Report settimanale** (`growth_reports`), task da insight, costi operativi e unit economics, scenari su ipotesi, **Admin AI Analyst** senza SQL arbitrario, export CSV di aggregati.
- **Ristoratore**: "AsiaFood Performance" (trend 7/30 giorni, insight e raccomandazioni deterministici) e **Business Copilot** limitato al proprio locale.
- Test `npm run test:growth` (191), E2E Fase 13.

### Modificato
- Esplora registra la ricerca strutturata al posto dell'evento generico `search`; `running_experiments` espone pesi e metrica; assegnazione pesata compatibile con la Fase 12; motivi di disdetta standardizzati (codici storici mappati).

## [0.2.0-beta] — Fase 12 · Go-to-market Taranto (non ancora rilasciata)

### Aggiunto
- **Taranto Launch Control** (`/admin/launch/taranto`): panoramica con avanzamento dai dati reali verso i target, avvisi (rivendicazioni in attesa, piani in scadenza, comuni senza verificati, SLA, incidenti, obiettivi), KPI (ristoranti, utenti, prenotazioni, ordini/GMV, coupon, recensioni, referral, MRR, SEO, traffico, sponsorizzate), North Star “Successful Food Connections”.
- **Copertura** per i 19 comuni prioritari con mappa; **qualità dati** (completezza 0–100, coordinate/orari/telefono/menu mancanti, rivendicabili, obsoleti, doppioni, posizioni anomale, chiusi).
- **Segmentazione commerciale** interna A/B/C e lista **First 50**.
- **CRM** leggero: ristoranti, creator, partner locali (hotel, B&B, università…), stampa; attività, esiti, prossime azioni, task, “non ricontattare”, note concorrenti solo verificate; template di outreach (telefono, WhatsApp, email, Instagram, visita) e obiezioni.
- **Partner Fondatore AsiaFood Taranto**: piano gratuito a tempo configurabile (piano, giorni, limite), badge solo per aderenti reali, revoca con audit.
- **Kit QR** (profilo, menu, recensioni, prenotazione, offerte) con PNG/SVG, materiali stampabili (table card A6, counter card A5, sticker) e tracciamento `qr_scan`; **kit di lancio** del ristoratore.
- **Landing `/taranto`** SEO + conversione (solo contenuti dai dati), `/press`, `/app` (installazione PWA), alias `/business`.
- **Attribuzione** (canale, UTM, codici) senza identificativi; iscrizione attribuita solo con consenso; generatore UTM.
- Dashboard **giornaliera** vendite, **operations “Oggi”** con SLA interni, **review settimanale**, funnel, coorti, attivazione, tempo al valore, **health score** partner con follow-up automatici.
- **Feedback** in-app (utenti e ristoratori), **NPS** solo dopo uso significativo, motivo di disdetta facoltativo.
- **Ambassador** (candidatura, nessun compenso automatico), badge **Founding Foodie**.
- **Marketing**: calendario social 30 giorni (bozze), vincoli di trasparenza (#adv, UGC con permesso, giveaway con checklist), template comunicato/email/newsletter.
- **Obiettivi** (target vs actual), **scenario** con ipotesi esplicite, **costi e CAC** (solo con dati affidabili), ricavi per ristorante, **esperimenti A/B** leggeri (max 2), **piano 30 giorni** e **roadmap 90 giorni**, **segnali di espansione**, **incidenti di lancio**, FAQ locali.
- Playbook e piani in `docs/launch/`; test `npm run test:launch` (138).

### Modificato
- Categorie di supporto per clienti e ristoratori; `system-cron` esegue la manutenzione di lancio una volta al giorno; token Search Console via `VITE_GOOGLE_SITE_VERIFICATION`.

## [0.1.0-beta] — 2026-10 (beta privata Taranto, non ancora rilasciata)

### Fase 11 — Hardening e prontezza al lancio
**Sicurezza**
- Revocati i permessi di esecuzione pubblici/anon su tutte le funzioni Admin e di servizio; `assert_service` rifiuta i ruoli client; test di allowlist delle funzioni eseguibili da anonimi.
- Rate limit condiviso nel database (fixed window, IP con hash salato) su API, moduli pubblici, coupon, prenotazioni, segnalazioni, recensioni, rivendicazioni, referral, posizioni Rider (anti-flood).
- Validazione Zod lato server e client; upload con verifica del tipo reale (magic bytes), limiti, nomi casuali, ricompressione WebP senza EXIF.
- Redirect sicuri (`safeNext`, `safeAssign`); allowlist degli endpoint push (anti-SSRF).
- Header di sicurezza: CSP senza `unsafe-eval`, HSTS, COOP, Permissions-Policy, `frame-ancestors 'none'`.
- Errori API standard `{ error: { code, message, requestId } }` senza stack trace; log JSON con redazione dei segreti e dei dati personali.
- Audit log Admin e sicurezza non cancellabili; trigger contro DELETE fisici di ristoranti con storico e profili Admin.

**Privacy / GDPR**
- Banner cookie (Accetta tutti / Rifiuta non necessari / Personalizza), consensi versionati (`user_consents`, `legal_document_versions`).
- Pagine legali in **bozza** (privacy, cookie, termini, termini business, privacy e termini Rider) marcate “Da revisionare con consulente legale”, `noindex` finché bozza.
- `/settings/privacy`: consensi, export dei dati (JSON), cancellazione account con ri-autenticazione e 7 giorni di ripensamento, anonimizzazione.
- Retention configurabile e job automatico; mappa dei dati personali (`docs/PRIVACY_DATA_MAP.md`).

**Affidabilità e operazioni**
- Ambienti `development/staging/production` e validazione delle variabili; `/api/health`, `/api/ready`.
- Cron con lock condiviso e registro job; retry dall’Admin; `system-cron` (controlli, retention, cancellazioni).
- Error tracking interno + Sentry facoltativo con scrubbing PII; Web Vitals con consenso.
- Feature flag e kill switch (ordini, AI, recensioni, campagne, registrazione Rider…), modalità manutenzione, modalità beta e inviti.
- `/admin/system`, `/admin/support`, `/admin/launch-checklist` (readiness Taranto, stati BLOCKED/NOT_READY/READY_FOR_BETA/READY_FOR_PRODUCTION).
- Supporto: `/support` con FAQ e ticket (anche ospiti, con anti-bot).
- Vincoli e indici del database, report di consistenza, importi in centesimi nel client, metriche di business senza dati DEMO.
- Script: `production-check`, `clean-demo-data` (dry-run e doppia conferma), backup/restore staging, EXPLAIN su staging, k6 per staging.
- CI GitHub Actions: lint, typecheck, test, build, production-check, audit.

**Accessibilità**
- Scansione axe-core WCAG 2.1 A/AA su 21 pagine: 0 violazioni dopo la correzione dei contrasti (token `ink-faint`, `coral`, `leaf`), dei piatti non disponibili, della mappa statica dentro i link e dei grafici Admin.

**SEO e prestazioni**
- Storico slug con redirect 301, 404 dedicata, sitemap index, robots per ambiente, soglia minima per pagine categoria×città, `aggregateRating` solo con recensioni reali.
- Bundle di produzione senza database DEMO (681 → 322 KB), font self-hosted, lazy loading di mappa/assistente/QR, correzioni CLS, `srcset` responsive.
- PWA: avviso “È disponibile un aggiornamento.”, avviso offline, nessuna cache di dati privati.

### Fasi precedenti (incluse nella 0.1.0-beta)
- **Fase 9** — Logistica AsiaFood: Rider, dispatch, offerte con timeout, tracking con privacy, compensi.
- **Fase 8** — Ordini online (asporto/consegna), Stripe PaymentIntent + Connect, rimborsi, link ospite firmati.
- **Fase 7** — Recensioni, AsiaPoints, inviti, notifiche in-app/push/email, campagne.
- **Fase 6** — Assistente AI database-first con fallback deterministico.
- **Fase 5** — SaaS B2B con Stripe Billing, piani, prova, sponsorizzazioni.
- **Fase 4** — Menu, prenotazioni, offerte e coupon, statistiche.
- **Fasi 1–3** — Catalogo, ricerca, pagine SEO, mappe, rivendicazione dei locali, import.
