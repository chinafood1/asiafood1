-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0012 · Fase 4: piattaforma commerciale
--   1. Piani e feature flag (plan_features) + helper di entitlement
--   2. Menu digitale completo (varianti, extra, allergeni, visibilità)
--   3. Offerte e coupon (claim con codice univoco, validazione, anti-abuso)
--   4. Prenotazioni (impostazioni, fasce orarie, chiusure, disponibilità)
--   5. Notifiche interne e coda email (provider esterno facoltativo)
--   6. Analytics con i nomi evento della Fase 4 (session_id anonimo)
--   7. Predisposizione Stripe e lista d'attesa upgrade
--  Migrazione additiva: nessun dato esistente viene eliminato.
-- ════════════════════════════════════════════════════════════════════

-- ════════════════════════════════════════════════════════════════════
--  1. PIANI E FEATURE FLAG
-- ════════════════════════════════════════════════════════════════════
alter table public.subscription_plans add column if not exists id uuid not null default gen_random_uuid();
alter table public.subscription_plans add constraint subscription_plans_id_key unique (id);

-- Prezzi iniziali Fase 4 (solo se l'Admin non li ha già cambiati)
update public.subscription_plans set monthly_price = 29.90, yearly_price = 299,
  description = 'Profilo completo, menu digitale, galleria, WhatsApp, offerte e statistiche base.'
  where code = 'business' and monthly_price = 19;
update public.subscription_plans set monthly_price = 59.90, yearly_price = 599,
  description = 'Tutto Business + prenotazioni, coupon, statistiche avanzate, più visibilità e badge Premium.'
  where code = 'premium' and monthly_price = 49;
update public.subscription_plans set monthly_price = 99.90, yearly_price = 999,
  description = 'Tutto Premium + sponsorizzazione prioritaria, campagne promozionali e posizionamento in evidenza.'
  where code = 'top' and monthly_price = 99;
update public.subscription_plans set description = 'Scheda base: telefono, indirizzo, categorie, orari e presenza nella ricerca.'
  where code = 'free' and description = 'Scheda base, contatti e orari.';

-- Feature per piano: configurabili dall'Admin, nessuna regola scritta nel codice.
-- enabled = funzione disponibile; limit_value = limite numerico (null = illimitato).
create table public.plan_features (
  id          uuid primary key default gen_random_uuid(),
  plan_code   text not null references public.subscription_plans(code) on update cascade on delete cascade,
  feature_key text not null check (feature_key ~ '^[a-z][a-z0-9_]{1,48}$'),
  enabled     boolean not null default false,
  limit_value int check (limit_value is null or limit_value >= 0),
  updated_at  timestamptz not null default now(),
  unique (plan_code, feature_key)
);
create trigger plan_features_updated_at before update on public.plan_features
  for each row execute function public.set_updated_at();

insert into public.plan_features (plan_code, feature_key, enabled, limit_value)
select p.code, f.key,
       case p.code when 'free' then f.free when 'business' then f.business when 'premium' then f.premium else f.top end,
       case p.code when 'free' then f.l_free when 'business' then f.l_business when 'premium' then f.l_premium else f.l_top end
from public.subscription_plans p
cross join (values
  -- key                 free   business premium top    limiti: free business premium top
  ('profile_full',       false, true,    true,   true,  null::int, null::int, null::int, null::int),
  ('menu_enabled',       false, true,    true,   true,  null, null, null, null),
  ('max_menu_items',     false, true,    true,   true,  0,    150,  null, null),
  ('max_images',         true,  true,    true,   true,  3,    15,   40,   null),
  ('whatsapp_enabled',   false, true,    true,   true,  null, null, null, null),
  ('analytics_enabled',  false, true,    true,   true,  null, null, null, null),
  ('advanced_analytics', false, false,   true,   true,  null, null, null, null),
  ('offers_enabled',     false, true,    true,   true,  null, null, null, null),
  ('max_active_offers',  false, true,    true,   true,  0,    2,    10,   null),
  ('coupons_enabled',    false, false,   true,   true,  null, null, null, null),
  ('max_active_coupons', false, false,   true,   true,  0,    0,    5,    null),
  ('reservations_enabled', false, false, true,   true,  null, null, null, null),
  ('premium_badge',      false, false,   true,   true,  null, null, null, null),
  ('search_boost',       false, false,   true,   true,  0,    0,    1,    2),
  ('featured_listing',   false, false,   false,  true,  null, null, null, null),
  ('sponsored_ads',      false, false,   false,  true,  null, null, null, null),
  ('marketing_tools',    false, false,   false,  true,  null, null, null, null)
) as f(key, free, business, premium, top, l_free, l_business, l_premium, l_top)
where p.code in ('free', 'business', 'premium', 'top')
on conflict (plan_code, feature_key) do nothing;

-- Copia denormalizzata in subscription_plans.features (jsonb) per compatibilità e lettura rapida
create or replace function public.sync_plan_features_json()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_code text := case when tg_op = 'DELETE' then old.plan_code else new.plan_code end;
begin
  update public.subscription_plans p
     set features = coalesce((
       select jsonb_object_agg(f.feature_key,
         case when not f.enabled then 'false'::jsonb when f.limit_value is not null then to_jsonb(f.limit_value) else 'true'::jsonb end)
       from public.plan_features f where f.plan_code = v_code), '{}'::jsonb)
   where p.code = v_code;
  return null;
end $$;
create trigger plan_features_sync_json after insert or update or delete on public.plan_features
  for each row execute function public.sync_plan_features_json();
update public.plan_features set enabled = enabled; -- allinea subito il jsonb

-- Vista "plans" con i nomi di colonna della specifica (slug = code, display_order = sort_order)
create view public.plans with (security_invoker = true) as
  select id, name, code as slug, description, monthly_price, yearly_price, currency, features, is_active, sort_order as display_order
  from public.subscription_plans;

-- ─── Entitlement: unico punto di verità lato DB ──────────────────────
create or replace function public.restaurant_has_feature(p_restaurant_id uuid, p_key text)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((
    select f.enabled from public.restaurants r
    join public.plan_features f on f.plan_code = r.subscription_plan and f.feature_key = p_key
    where r.id = p_restaurant_id), false);
$$;

-- Limite numerico: null = illimitato, 0 = non disponibile (anche se la riga manca)
create or replace function public.restaurant_feature_limit(p_restaurant_id uuid, p_key text)
returns int language plpgsql stable security definer set search_path = public as $$
declare v_enabled boolean; v_limit int;
begin
  select f.enabled, f.limit_value into v_enabled, v_limit
  from public.restaurants r join public.plan_features f on f.plan_code = r.subscription_plan and f.feature_key = p_key
  where r.id = p_restaurant_id;
  if not found or not v_enabled then return 0; end if;
  return v_limit;
end $$;

-- Le regole di piano valgono per i ristoratori; Admin, service role e script (auth.uid() nullo) sono esenti.
create or replace function public.plan_rules_apply()
returns boolean language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and not public.is_admin();
$$;

create or replace function public.assert_feature(p_restaurant_id uuid, p_key text)
returns void language plpgsql stable security definer set search_path = public as $$
begin
  if public.plan_rules_apply() and not public.restaurant_has_feature(p_restaurant_id, p_key) then
    raise exception 'PLAN_FEATURE:%', p_key using hint = 'upgrade';
  end if;
end $$;

create or replace function public.assert_limit(p_restaurant_id uuid, p_key text, p_current bigint)
returns void language plpgsql stable security definer set search_path = public as $$
declare v_limit int;
begin
  if not public.plan_rules_apply() then return; end if;
  v_limit := public.restaurant_feature_limit(p_restaurant_id, p_key);
  if v_limit is not null and p_current >= v_limit then
    raise exception 'PLAN_LIMIT:%', p_key using hint = 'upgrade';
  end if;
end $$;

-- Codici casuali leggibili (senza 0/O/1/I), generati con pgcrypto
create or replace function public.random_code(p_len int)
returns text language plpgsql volatile set search_path = public, extensions as $$
declare
  chars constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  bytes bytea := gen_random_bytes(p_len);
  out text := '';
  i int;
begin
  for i in 0..p_len - 1 loop
    out := out || substr(chars, 1 + (get_byte(bytes, i) % 32), 1);
  end loop;
  return out;
end $$;

-- Le RPC interne aggiornano i contatori (utilizzi, codici distribuiti): il flag di transazione
-- distingue queste scritture da un UPDATE diretto del ristoratore, che resta bloccato.
create or replace function public.internal_write()
returns boolean language sql stable as $$
  select coalesce(current_setting('asiafood.internal_write', true), '') = 'on';
$$;

-- ════════════════════════════════════════════════════════════════════
--  2. MENU DIGITALE
-- ════════════════════════════════════════════════════════════════════
alter table public.menus
  add column is_public   boolean not null default true,
  add column valid_from  date,
  add column valid_until date,
  add constraint menus_validity check (valid_from is null or valid_until is null or valid_until >= valid_from),
  add constraint menus_name_len check (char_length(name) between 1 and 80);

alter table public.menu_categories
  add column is_active  boolean not null default true,
  add column updated_at timestamptz not null default now();
create trigger menu_categories_updated_at before update on public.menu_categories
  for each row execute function public.set_updated_at();

alter table public.menu_items
  add column discount_price numeric(8,2) check (discount_price is null or discount_price >= 0),
  add column is_featured    boolean not null default false,
  add column is_spicy       boolean not null default false,
  add column is_vegetarian  boolean not null default false,
  add column is_vegan       boolean not null default false,
  add column is_gluten_free boolean not null default false,
  add column ingredients    text[] not null default '{}',
  add constraint menu_items_price_nonneg check (price is null or price >= 0),
  add constraint menu_items_name_len check (char_length(name) between 1 and 120);

-- Da etichette (Fase 1) a flag espliciti
update public.menu_items set
  is_spicy       = 'spicy' = any(tags),
  is_vegan       = 'vegan' = any(tags),
  is_vegetarian  = 'vegetarian' = any(tags) or 'vegan' = any(tags),
  is_gluten_free = 'gluten_free' = any(tags),
  is_featured    = 'signature' = any(tags);

-- Allergeni: i 14 del Reg. UE 1169/2011
create table public.allergens (
  code       text primary key,
  name       text not null,
  eu_number  smallint not null unique check (eu_number between 1 and 14),
  sort_order smallint not null
);
insert into public.allergens (code, name, eu_number, sort_order) values
  ('gluten', 'Glutine', 1, 1), ('crustaceans', 'Crostacei', 2, 2), ('eggs', 'Uova', 3, 3), ('fish', 'Pesce', 4, 4),
  ('peanuts', 'Arachidi', 5, 5), ('soy', 'Soia', 6, 6), ('milk', 'Latte', 7, 7), ('nuts', 'Frutta a guscio', 8, 8),
  ('celery', 'Sedano', 9, 9), ('mustard', 'Senape', 10, 10), ('sesame', 'Sesamo', 11, 11), ('sulphites', 'Solfiti', 12, 12),
  ('lupin', 'Lupini', 13, 13), ('molluscs', 'Molluschi', 14, 14)
on conflict (code) do nothing;

-- Normalizza codici, numeri UE e nomi italiani/inglesi; scarta i valori sconosciuti
create or replace function public.normalize_allergens(p text[])
returns text[] language sql immutable as $$
  select coalesce(array_agg(distinct code), '{}') from (
    select case regexp_replace(lower(trim(x)), '\s+', ' ', 'g')
      when 'gluten' then 'gluten' when 'glutine' then 'gluten' when '1' then 'gluten' when 'cereali' then 'gluten'
      when 'crustaceans' then 'crustaceans' when 'crostacei' then 'crustaceans' when '2' then 'crustaceans'
      when 'eggs' then 'eggs' when 'uova' then 'eggs' when 'uovo' then 'eggs' when '3' then 'eggs'
      when 'fish' then 'fish' when 'pesce' then 'fish' when '4' then 'fish'
      when 'peanuts' then 'peanuts' when 'arachidi' then 'peanuts' when '5' then 'peanuts'
      when 'soy' then 'soy' when 'soia' then 'soy' when '6' then 'soy'
      when 'milk' then 'milk' when 'latte' then 'milk' when 'lattosio' then 'milk' when '7' then 'milk'
      when 'nuts' then 'nuts' when 'frutta a guscio' then 'nuts' when 'frutta secca' then 'nuts' when '8' then 'nuts'
      when 'celery' then 'celery' when 'sedano' then 'celery' when '9' then 'celery'
      when 'mustard' then 'mustard' when 'senape' then 'mustard' when '10' then 'mustard'
      when 'sesame' then 'sesame' when 'sesamo' then 'sesame' when '11' then 'sesame'
      when 'sulphites' then 'sulphites' when 'solfiti' then 'sulphites' when 'anidride solforosa' then 'sulphites' when '12' then 'sulphites'
      when 'lupin' then 'lupin' when 'lupini' then 'lupin' when '13' then 'lupin'
      when 'molluscs' then 'molluscs' when 'molluschi' then 'molluscs' when '14' then 'molluscs'
    end as code
    from unnest(coalesce(p, '{}')) as x
  ) s where code is not null;
$$;

create or replace function public.menu_items_normalize()
returns trigger language plpgsql as $$
begin
  new.allergens := public.normalize_allergens(new.allergens);
  new.ingredients := coalesce((
    select array_agg(left(trim(i), 60)) from unnest(new.ingredients) i where trim(i) <> ''), '{}');
  if array_length(new.ingredients, 1) > 40 then new.ingredients := new.ingredients[1:40]; end if;
  if new.is_vegan then new.is_vegetarian := true; end if;
  return new;
end $$;
create trigger menu_items_normalize before insert or update on public.menu_items
  for each row execute function public.menu_items_normalize();
update public.menu_items set allergens = allergens;

-- Varianti (es. 4 / 8 / 12 pezzi, Small / Large) ed extra (es. Extra salmone)
create table public.menu_item_variants (
  id            uuid primary key default gen_random_uuid(),
  menu_item_id  uuid not null references public.menu_items(id) on delete cascade,
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name          text not null check (char_length(name) between 1 and 60),
  price         numeric(8,2) check (price is null or price >= 0),
  is_available  boolean not null default true,
  display_order int not null default 0,
  created_at    timestamptz not null default now()
);
create index menu_item_variants_item_idx on public.menu_item_variants(menu_item_id, display_order);

create table public.menu_item_addons (
  id            uuid primary key default gen_random_uuid(),
  menu_item_id  uuid not null references public.menu_items(id) on delete cascade,
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name          text not null check (char_length(name) between 1 and 60),
  price         numeric(8,2) check (price is null or price >= 0),
  is_available  boolean not null default true,
  display_order int not null default 0,
  created_at    timestamptz not null default now()
);
create index menu_item_addons_item_idx on public.menu_item_addons(menu_item_id, display_order);

create or replace function public.menu_item_children_fill_restaurant()
returns trigger language plpgsql as $$
begin
  select i.restaurant_id into new.restaurant_id from public.menu_items i where i.id = new.menu_item_id;
  return new;
end $$;
create trigger menu_item_variants_fill_restaurant before insert or update of menu_item_id on public.menu_item_variants
  for each row execute function public.menu_item_children_fill_restaurant();
create trigger menu_item_addons_fill_restaurant before insert or update of menu_item_id on public.menu_item_addons
  for each row execute function public.menu_item_children_fill_restaurant();

-- Visibilità pubblica: menu attivo, pubblico e nel periodo di validità
create or replace function public.menu_is_public(p_menu_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.menus m
    where m.id = p_menu_id and m.is_active and m.is_public
      and (m.valid_from is null or m.valid_from <= current_date)
      and (m.valid_until is null or m.valid_until >= current_date)
      and public.restaurant_is_public(m.restaurant_id)
  );
$$;

create or replace function public.menu_category_is_public(p_category_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.menu_categories c where c.id = p_category_id and c.is_active and public.menu_is_public(c.menu_id)
  );
$$;

drop policy "menus_public_read" on public.menus;
create policy "menus_public_read" on public.menus for select using (
  public.menu_is_public(id) or public.can_manage_restaurant(restaurant_id)
);
drop policy "menu_categories_public_read" on public.menu_categories;
create policy "menu_categories_public_read" on public.menu_categories for select using (
  (is_active and public.menu_is_public(menu_id)) or public.can_manage_restaurant(restaurant_id)
);
drop policy "menu_items_public_read" on public.menu_items;
create policy "menu_items_public_read" on public.menu_items for select using (
  public.menu_category_is_public(menu_category_id) or public.can_manage_restaurant(restaurant_id)
);

-- ─── Regole di piano sul menu ─────────────────────────────────────────
create or replace function public.menu_plan_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_feature(new.restaurant_id, 'menu_enabled');
  if tg_table_name = 'menu_items' and tg_op = 'INSERT' then
    perform public.assert_limit(new.restaurant_id, 'max_menu_items',
      (select count(*) from public.menu_items i where i.restaurant_id = new.restaurant_id));
  end if;
  return new;
end $$;
-- Il nome "…_plan_guard" segue "…_fill_restaurant" in ordine alfabetico: restaurant_id è già valorizzato
create trigger menus_plan_guard before insert or update on public.menus
  for each row execute function public.menu_plan_guard();
create trigger menu_categories_plan_guard before insert or update on public.menu_categories
  for each row execute function public.menu_plan_guard();
create trigger menu_items_plan_guard before insert or update on public.menu_items
  for each row execute function public.menu_plan_guard();
create trigger menu_item_variants_plan_guard before insert or update on public.menu_item_variants
  for each row execute function public.menu_plan_guard();
create trigger menu_item_addons_plan_guard before insert or update on public.menu_item_addons
  for each row execute function public.menu_plan_guard();

create or replace function public.images_plan_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_limit(new.restaurant_id, 'max_images',
    (select count(*) from public.restaurant_images i where i.restaurant_id = new.restaurant_id));
  return new;
end $$;
create trigger restaurant_images_plan_guard before insert on public.restaurant_images
  for each row execute function public.images_plan_guard();

-- ─── RPC menu: duplicazione, riordino, import ─────────────────────────
create or replace function public.duplicate_menu_item(p_item_id uuid, p_target_category uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare it public.menu_items; v_new uuid; v_cat uuid;
begin
  select * into it from public.menu_items where id = p_item_id;
  if not found or not public.can_manage_restaurant(it.restaurant_id) then
    raise exception 'Operazione non consentita.' using errcode = '42501';
  end if;
  v_cat := coalesce(p_target_category, it.menu_category_id);
  if not exists (select 1 from public.menu_categories c where c.id = v_cat and c.restaurant_id = it.restaurant_id) then
    raise exception 'Categoria non valida.';
  end if;
  insert into public.menu_items (menu_category_id, restaurant_id, name, description, price, discount_price, image_url, pieces,
    allergens, tags, ingredients, is_available, is_ayce_included, ayce_limit, is_featured, is_spicy, is_vegetarian, is_vegan,
    is_gluten_free, sort_order)
  values (v_cat, it.restaurant_id, left(it.name || case when p_target_category is null then ' (copia)' else '' end, 120),
    it.description, it.price, it.discount_price, it.image_url, it.pieces, it.allergens, it.tags, it.ingredients,
    it.is_available, it.is_ayce_included, it.ayce_limit, it.is_featured, it.is_spicy, it.is_vegetarian, it.is_vegan,
    it.is_gluten_free, it.sort_order + case when p_target_category is null then 1 else 0 end)
  returning id into v_new;
  insert into public.menu_item_variants (menu_item_id, restaurant_id, name, price, is_available, display_order)
    select v_new, restaurant_id, name, price, is_available, display_order from public.menu_item_variants where menu_item_id = p_item_id;
  insert into public.menu_item_addons (menu_item_id, restaurant_id, name, price, is_available, display_order)
    select v_new, restaurant_id, name, price, is_available, display_order from public.menu_item_addons where menu_item_id = p_item_id;
  return v_new;
end $$;

create or replace function public.duplicate_menu(p_menu_id uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare m public.menus; v_menu uuid; c record; v_cat uuid; i record;
begin
  select * into m from public.menus where id = p_menu_id;
  if not found or not public.can_manage_restaurant(m.restaurant_id) then
    raise exception 'Operazione non consentita.' using errcode = '42501';
  end if;
  insert into public.menus (restaurant_id, name, description, menu_type, price, is_active, is_public, valid_from, valid_until, sort_order)
  values (m.restaurant_id, left(m.name || ' (copia)', 80), m.description, m.menu_type, m.price, m.is_active, false, m.valid_from, m.valid_until,
          (select coalesce(max(sort_order), 0) + 1 from public.menus where restaurant_id = m.restaurant_id))
  returning id into v_menu;
  for c in select * from public.menu_categories where menu_id = p_menu_id order by sort_order loop
    insert into public.menu_categories (menu_id, restaurant_id, name, description, sort_order, is_active)
    values (v_menu, m.restaurant_id, c.name, c.description, c.sort_order, c.is_active) returning id into v_cat;
    for i in select id from public.menu_items where menu_category_id = c.id order by sort_order loop
      perform public.duplicate_menu_item(i.id, v_cat);
    end loop;
  end loop;
  return v_menu;
end $$;

-- Riordino in un'unica chiamata (frecce o drag & drop): la posizione nell'array diventa l'ordine
create or replace function public.reorder_menu_rows(p_table text, p_ids uuid[])
returns void language plpgsql security definer set search_path = public as $$
declare v_col text; v_rest uuid; i int;
begin
  if p_table not in ('menus', 'menu_categories', 'menu_items', 'menu_item_variants', 'menu_item_addons') then
    raise exception 'Tabella non valida.';
  end if;
  if coalesce(array_length(p_ids, 1), 0) = 0 or array_length(p_ids, 1) > 500 then return; end if;
  v_col := case when p_table in ('menu_item_variants', 'menu_item_addons') then 'display_order' else 'sort_order' end;
  execute format('select restaurant_id from public.%I where id = $1', p_table) into v_rest using p_ids[1];
  if v_rest is null or not public.can_manage_restaurant(v_rest) then
    raise exception 'Operazione non consentita.' using errcode = '42501';
  end if;
  for i in 1..array_length(p_ids, 1) loop
    execute format('update public.%I set %I = $1 where id = $2 and restaurant_id = $3', p_table, v_col)
      using i - 1, p_ids[i], v_rest;
  end loop;
end $$;

-- Import menu da CSV/JSON (già convertito in array JSON dal client, validato qui).
-- Ogni elemento: {menu, menu_type?, category, name, description?, price?, discount_price?, allergens?[],
--   ingredients?[], is_vegetarian?, is_vegan?, is_gluten_free?, is_spicy?, is_available?, is_featured?,
--   variants?[{name, price}], addons?[{name, price}]}
create or replace function public.import_menu(p_restaurant_id uuid, p_items jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  e jsonb; v jsonb;
  v_menu uuid; v_cat uuid; v_item uuid;
  n_menus int := 0; n_cats int := 0; n_items int := 0; n_row int := 0;
  v_menu_name text; v_cat_name text; v_name text; v_price numeric; v_type public.menu_type;
begin
  if not public.can_manage_restaurant(p_restaurant_id) then
    raise exception 'Operazione non consentita.' using errcode = '42501';
  end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then raise exception 'Nessuna riga da importare.'; end if;
  if jsonb_array_length(p_items) > 1000 then raise exception 'Massimo 1000 piatti per importazione.'; end if;

  for e in select * from jsonb_array_elements(p_items) loop
    n_row := n_row + 1;
    v_menu_name := left(nullif(trim(coalesce(e->>'menu', 'Menu principale')), ''), 80);
    v_cat_name := left(nullif(trim(coalesce(e->>'category', '')), ''), 80);
    v_name := left(nullif(trim(coalesce(e->>'name', '')), ''), 120);
    if v_name is null then raise exception 'Riga %: il nome del piatto è obbligatorio.', n_row; end if;
    if v_cat_name is null then raise exception 'Riga %: la categoria è obbligatoria.', n_row; end if;
    begin
      v_price := nullif(e->>'price', '')::numeric;
    exception when others then raise exception 'Riga %: prezzo non valido.', n_row;
    end;
    if v_price is not null and (v_price < 0 or v_price > 10000) then raise exception 'Riga %: prezzo non valido.', n_row; end if;

    select id into v_menu from public.menus where restaurant_id = p_restaurant_id and lower(name) = lower(coalesce(v_menu_name, 'Menu principale')) limit 1;
    if v_menu is null then
      begin v_type := coalesce(nullif(e->>'menu_type', ''), 'a_la_carte')::public.menu_type;
      exception when others then v_type := 'a_la_carte'; end;
      insert into public.menus (restaurant_id, name, menu_type, sort_order)
      values (p_restaurant_id, coalesce(v_menu_name, 'Menu principale'), v_type,
              (select coalesce(max(sort_order), -1) + 1 from public.menus where restaurant_id = p_restaurant_id))
      returning id into v_menu;
      n_menus := n_menus + 1;
    end if;

    select id into v_cat from public.menu_categories where menu_id = v_menu and lower(name) = lower(v_cat_name) limit 1;
    if v_cat is null then
      insert into public.menu_categories (menu_id, restaurant_id, name, sort_order)
      values (v_menu, p_restaurant_id, v_cat_name, (select coalesce(max(sort_order), -1) + 1 from public.menu_categories where menu_id = v_menu))
      returning id into v_cat;
      n_cats := n_cats + 1;
    end if;

    insert into public.menu_items (menu_category_id, restaurant_id, name, description, price, discount_price, allergens, ingredients,
      is_vegetarian, is_vegan, is_gluten_free, is_spicy, is_available, is_featured, sort_order)
    values (v_cat, p_restaurant_id, v_name, left(nullif(trim(e->>'description'), ''), 500), v_price,
      case when nullif(e->>'discount_price', '') ~ '^[0-9]+([.][0-9]+)?$' then (e->>'discount_price')::numeric end,
      coalesce((select array_agg(x) from jsonb_array_elements_text(case when jsonb_typeof(e->'allergens') = 'array' then e->'allergens' else '[]' end) x), '{}'),
      coalesce((select array_agg(x) from jsonb_array_elements_text(case when jsonb_typeof(e->'ingredients') = 'array' then e->'ingredients' else '[]' end) x), '{}'),
      coalesce((e->>'is_vegetarian')::boolean, false), coalesce((e->>'is_vegan')::boolean, false),
      coalesce((e->>'is_gluten_free')::boolean, false), coalesce((e->>'is_spicy')::boolean, false),
      coalesce((e->>'is_available')::boolean, true), coalesce((e->>'is_featured')::boolean, false),
      (select coalesce(max(sort_order), -1) + 1 from public.menu_items where menu_category_id = v_cat))
    returning id into v_item;
    n_items := n_items + 1;

    if jsonb_typeof(e->'variants') = 'array' then
      for v in select * from jsonb_array_elements(e->'variants') loop
        if nullif(trim(v->>'name'), '') is not null then
          insert into public.menu_item_variants (menu_item_id, restaurant_id, name, price, display_order)
          values (v_item, p_restaurant_id, left(trim(v->>'name'), 60),
                  case when (v->>'price') ~ '^[0-9]+([.][0-9]+)?$' then (v->>'price')::numeric end,
                  (select count(*) from public.menu_item_variants where menu_item_id = v_item));
        end if;
      end loop;
    end if;
    if jsonb_typeof(e->'addons') = 'array' then
      for v in select * from jsonb_array_elements(e->'addons') loop
        if nullif(trim(v->>'name'), '') is not null then
          insert into public.menu_item_addons (menu_item_id, restaurant_id, name, price, display_order)
          values (v_item, p_restaurant_id, left(trim(v->>'name'), 60),
                  case when (v->>'price') ~ '^[0-9]+([.][0-9]+)?$' then (v->>'price')::numeric end,
                  (select count(*) from public.menu_item_addons where menu_item_id = v_item));
        end if;
      end loop;
    end if;
  end loop;
  update public.restaurants set menu_last_verified_at = now() where id = p_restaurant_id;
  return jsonb_build_object('menus', n_menus, 'categories', n_cats, 'items', n_items);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  3. OFFERTE E COUPON
-- ════════════════════════════════════════════════════════════════════
alter table public.offers
  add column offer_type        public.offer_type not null default 'other',
  add column minimum_spend     numeric(8,2) check (minimum_spend is null or minimum_spend >= 0),
  add column start_time        time,
  add column end_time          time,
  add column is_featured       boolean not null default false,
  add column max_redemptions   int check (max_redemptions is null or max_redemptions > 0),
  add column redemptions_count int not null default 0,
  add constraint offers_time_pair check ((start_time is null) = (end_time is null)),
  add constraint offers_days_valid check (days_of_week <@ array[1,2,3,4,5,6,7]::smallint[]),
  add constraint offers_title_len check (char_length(title) between 1 and 120);

update public.offers set offer_type = case discount_type
  when 'percent' then 'percentage'::public.offer_type
  when 'amount' then 'fixed_amount'::public.offer_type
  when 'fixed_price' then 'special_menu'::public.offer_type
  when 'free_item' then 'free_dish'::public.offer_type
  else 'other'::public.offer_type end;
create index offers_featured_idx on public.offers(is_featured, starts_at desc) where is_active;

alter table public.coupons rename column min_spend to minimum_spend;
alter table public.coupons
  add column max_redemptions_per_user int not null default 1 check (max_redemptions_per_user between 1 and 20),
  add column claims_count int not null default 0,
  add constraint coupons_code_format check (code ~ '^[A-Z0-9][A-Z0-9-]{2,23}$') not valid,
  add constraint coupons_title_len check (char_length(title) between 1 and 120);
alter table public.coupons add constraint coupons_valid_window check (valid_until is null or valid_until > valid_from);

-- Offerte: regole di piano, contatori protetti
create or replace function public.offers_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.plan_rules_apply() then
    perform public.assert_feature(new.restaurant_id, 'offers_enabled');
    if new.is_active and (new.ends_at is null or new.ends_at > now())
       and (tg_op = 'INSERT' or not old.is_active or (old.ends_at is not null and old.ends_at <= now())) then
      perform public.assert_limit(new.restaurant_id, 'max_active_offers', (
        select count(*) from public.offers o
        where o.restaurant_id = new.restaurant_id and o.is_active and (o.ends_at is null or o.ends_at > now()) and o.id <> new.id));
    end if;
    if new.is_featured and not public.restaurant_has_feature(new.restaurant_id, 'featured_listing') then
      new.is_featured := false;
    end if;
    if not public.internal_write() then
      new.redemptions_count := case when tg_op = 'INSERT' then 0 else old.redemptions_count end;
    end if;
  end if;
  return new;
end $$;
create trigger offers_guard before insert or update on public.offers
  for each row execute function public.offers_guard();

create or replace function public.coupons_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.code := upper(regexp_replace(new.code, '\s+', '', 'g'));
  if public.plan_rules_apply() then
    perform public.assert_feature(new.restaurant_id, 'coupons_enabled');
    if new.is_active and (new.valid_until is null or new.valid_until > now())
       and (tg_op = 'INSERT' or not old.is_active or (old.valid_until is not null and old.valid_until <= now())) then
      perform public.assert_limit(new.restaurant_id, 'max_active_coupons', (
        select count(*) from public.coupons c
        where c.restaurant_id = new.restaurant_id and c.is_active and (c.valid_until is null or c.valid_until > now()) and c.id <> new.id));
    end if;
    if not public.internal_write() then
      new.redemptions_count := case when tg_op = 'INSERT' then 0 else old.redemptions_count end;
      new.claims_count := case when tg_op = 'INSERT' then 0 else old.claims_count end;
    end if;
  end if;
  return new;
end $$;
create trigger coupons_guard before insert or update on public.coupons
  for each row execute function public.coupons_guard();

-- Visibili al pubblico solo se il piano del locale li include (un downgrade li nasconde automaticamente)
drop policy "offers_public_read" on public.offers;
create policy "offers_public_read" on public.offers for select using (
  (is_active and starts_at <= now() and (ends_at is null or ends_at > now())
    and public.restaurant_is_public(restaurant_id) and public.restaurant_has_feature(restaurant_id, 'offers_enabled'))
  or public.can_manage_restaurant(restaurant_id)
);
drop policy "coupons_public_read" on public.coupons;
create policy "coupons_public_read" on public.coupons for select using (
  (is_active and valid_from <= now() and (valid_until is null or valid_until > now())
    and public.restaurant_is_public(restaurant_id) and public.restaurant_has_feature(restaurant_id, 'coupons_enabled'))
  or public.can_manage_restaurant(restaurant_id)
);

-- Coupon ottenuti dai clienti (codice personale, es. SUSHI20-X7P4)
create table public.coupon_claims (
  id            uuid primary key default gen_random_uuid(),
  coupon_id     uuid not null references public.coupons(id) on delete cascade,
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id       uuid references public.profiles(id) on delete set null,
  email         text check (email is null or (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' and char_length(email) <= 254)),
  claim_code    text not null unique,
  status        public.coupon_claim_status not null default 'claimed',
  claimed_at    timestamptz not null default now(),
  redeemed_at   timestamptz,
  redeemed_by   uuid references public.profiles(id) on delete set null,
  check (user_id is not null or email is not null)
);
create index coupon_claims_coupon_idx on public.coupon_claims(coupon_id, status);
create index coupon_claims_restaurant_idx on public.coupon_claims(restaurant_id, claimed_at desc);
create index coupon_claims_user_idx on public.coupon_claims(user_id) where user_id is not null;
create index coupon_claims_email_idx on public.coupon_claims(lower(email), claimed_at desc) where email is not null;

-- ════════════════════════════════════════════════════════════════════
--  4. PRENOTAZIONI
-- ════════════════════════════════════════════════════════════════════
create table public.reservation_settings (
  restaurant_id          uuid primary key references public.restaurants(id) on delete cascade,
  reservation_enabled    boolean not null default false,
  min_party_size         smallint not null default 1 check (min_party_size between 1 and 50),
  max_party_size         smallint not null default 8 check (max_party_size between 1 and 100),
  slot_duration_minutes  smallint not null default 90 check (slot_duration_minutes between 15 and 480),
  booking_notice_minutes int not null default 60 check (booking_notice_minutes between 0 and 10080),
  max_advance_days       smallint not null default 30 check (max_advance_days between 1 and 365),
  auto_confirm           boolean not null default false,
  guest_message          text check (char_length(guest_message) <= 300),
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now(),
  check (max_party_size >= min_party_size)
);
create trigger reservation_settings_updated_at before update on public.reservation_settings
  for each row execute function public.set_updated_at();

-- Fasce di servizio: max_reservations = prenotazioni per singolo orario, max_guests = coperti per fascia
create table public.reservation_slots (
  id                    uuid primary key default gen_random_uuid(),
  restaurant_id         uuid not null references public.restaurants(id) on delete cascade,
  day_of_week           smallint not null check (day_of_week between 1 and 7),
  start_time            time not null,
  end_time              time not null,
  slot_interval_minutes smallint not null default 30 check (slot_interval_minutes between 5 and 240),
  max_reservations      int check (max_reservations is null or max_reservations > 0),
  max_guests            int check (max_guests is null or max_guests > 0),
  is_active             boolean not null default true,
  label                 text check (char_length(label) <= 40),
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  check (end_time > start_time)
);
create index reservation_slots_restaurant_idx on public.reservation_slots(restaurant_id, day_of_week) where is_active;
create trigger reservation_slots_updated_at before update on public.reservation_slots
  for each row execute function public.set_updated_at();

create table public.restaurant_closures (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  date          date not null,
  start_time    time,
  end_time      time,
  reason        text check (char_length(reason) <= 200),
  created_at    timestamptz not null default now(),
  check ((start_time is null) = (end_time is null)),
  check (end_time is null or end_time > start_time)
);
create index restaurant_closures_idx on public.restaurant_closures(restaurant_id, date);

create table public.reservations (
  id                uuid primary key default gen_random_uuid(),
  restaurant_id     uuid not null references public.restaurants(id) on delete cascade,
  user_id           uuid references public.profiles(id) on delete set null,
  guest_name        text not null check (char_length(trim(guest_name)) between 1 and 60),
  guest_surname     text not null check (char_length(trim(guest_surname)) between 1 and 60),
  -- Email facoltativa solo per l'inserimento manuale dal gestionale (prenotazione telefonica)
  guest_email       text check (guest_email is null or (guest_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' and char_length(guest_email) <= 254)),
  guest_phone       text not null check (guest_phone ~ '^\+?[0-9 ().-]{6,20}$'),
  reservation_date  date not null,
  reservation_time  time not null,
  party_size        smallint not null check (party_size between 1 and 100),
  notes             text check (char_length(notes) <= 500),
  status            public.reservation_status not null default 'pending',
  source            public.reservation_source not null default 'web',
  confirmation_code text not null unique check (confirmation_code ~ '^ASF-[A-Z0-9]{5}$'),
  internal_notes    text check (char_length(internal_notes) <= 500),
  status_changed_by uuid references public.profiles(id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  confirmed_at      timestamptz,
  cancelled_at      timestamptz,
  check (guest_email is not null or source in ('restaurant', 'admin'))
);
create index reservations_agenda_idx on public.reservations(restaurant_id, reservation_date, reservation_time);
create index reservations_user_idx on public.reservations(user_id) where user_id is not null;
create index reservations_email_idx on public.reservations(lower(guest_email), created_at desc);
create trigger reservations_updated_at before update on public.reservations
  for each row execute function public.set_updated_at();

-- Configurazione prenotazioni: l'attivazione richiede il piano
create or replace function public.reservation_settings_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.reservation_enabled then
    perform public.assert_feature(new.restaurant_id, 'reservations_enabled');
  end if;
  return new;
end $$;
create or replace function public.reservation_slots_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_feature(new.restaurant_id, 'reservations_enabled');
  return new;
end $$;
create trigger reservation_settings_plan_guard before insert or update on public.reservation_settings
  for each row execute function public.reservation_settings_guard();
create trigger reservation_slots_plan_guard before insert or update on public.reservation_slots
  for each row execute function public.reservation_slots_guard();

-- ════════════════════════════════════════════════════════════════════
--  5. NOTIFICHE INTERNE E CODA EMAIL
-- ════════════════════════════════════════════════════════════════════
create table public.notifications (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles(id) on delete cascade,
  restaurant_id uuid references public.restaurants(id) on delete cascade,
  type          text not null check (char_length(type) <= 40),
  title         text not null check (char_length(title) <= 140),
  body          text check (char_length(body) <= 500),
  link          text check (link is null or link ~ '^/'),
  read_at       timestamptz,
  created_at    timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);

-- Coda email transazionali: la elabora una Edge Function con il provider configurato (Resend, Brevo, SendGrid).
-- Senza provider le email restano in coda: nessuna operazione dell'utente viene bloccata.
create table public.email_outbox (
  id             bigint generated always as identity primary key,
  event_type     text not null check (event_type in (
    'reservation_created', 'reservation_confirmed', 'reservation_rejected', 'reservation_cancelled', 'reservation_new_for_restaurant'
  )),
  recipient      text not null check (char_length(recipient) <= 254),
  restaurant_id  uuid references public.restaurants(id) on delete cascade,
  reservation_id uuid references public.reservations(id) on delete set null,
  payload        jsonb not null default '{}'::jsonb,
  status         text not null default 'pending' check (status in ('pending', 'sent', 'failed', 'skipped')),
  attempts       int not null default 0,
  last_error     text,
  created_at     timestamptz not null default now(),
  sent_at        timestamptz
);
create index email_outbox_pending_idx on public.email_outbox(status, created_at) where status = 'pending';

create or replace function public.notify_restaurant(p_restaurant_id uuid, p_type text, p_title text, p_body text, p_link text)
returns void language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, restaurant_id, type, title, body, link)
  select m.user_id, p_restaurant_id, p_type, left(p_title, 140), left(p_body, 500), p_link
  from public.restaurant_members m
  where m.restaurant_id = p_restaurant_id and m.status = 'active' and m.role in ('owner', 'manager');
$$;

create or replace function public.notify_admins(p_type text, p_title text, p_body text, p_link text)
returns void language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, type, title, body, link)
  select p.id, p_type, left(p_title, 140), left(p_body, 500), p_link
  from public.profiles p where p.role = 'admin' and not p.is_blocked;
$$;

create or replace function public.enqueue_email(p_event text, p_recipient text, p_payload jsonb, p_restaurant_id uuid, p_reservation_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if nullif(trim(coalesce(p_recipient, '')), '') is null then return; end if;
  insert into public.email_outbox (event_type, recipient, payload, restaurant_id, reservation_id)
  values (p_event, lower(trim(p_recipient)), coalesce(p_payload, '{}'::jsonb), p_restaurant_id, p_reservation_id);
end $$;

create or replace function public.mark_notifications_read(p_ids uuid[] default null)
returns void language sql security definer set search_path = public as $$
  update public.notifications set read_at = now()
  where user_id = auth.uid() and read_at is null and (p_ids is null or id = any(p_ids));
$$;

-- ════════════════════════════════════════════════════════════════════
--  6. ANALYTICS (nomi Fase 4, nessun dato personale)
-- ════════════════════════════════════════════════════════════════════
alter table public.analytics_events alter column restaurant_id drop not null;

update public.analytics_events set event_type = (case event_type::text
  when 'view' then 'restaurant_view' when 'click_phone' then 'phone_click' when 'click_whatsapp' then 'whatsapp_click'
  when 'click_directions' then 'directions_click' when 'click_menu' then 'menu_view' when 'click_reservation' then 'reservation_start'
  when 'click_website' then 'website_click' when 'click_social' then 'social_click' when 'coupon_reveal' then 'offer_view'
  else event_type::text end)::public.analytics_event_type
where event_type::text in ('view', 'click_phone', 'click_whatsapp', 'click_directions', 'click_menu', 'click_reservation', 'click_website', 'click_social', 'coupon_reveal');

-- Evento server-side (conversioni): non esposto al client
create or replace function public.log_event(p_restaurant_id uuid, p_type text, p_source text, p_metadata jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.analytics_events (restaurant_id, event_type, source, metadata)
  values (p_restaurant_id, p_type::public.analytics_event_type, left(p_source, 40), coalesce(p_metadata, '{}'::jsonb));
end $$;

-- Tracciamento dal client: rimappa i nomi della Fase 1, rifiuta le conversioni (solo server),
-- non salva l'utente (solo session_id anonimo) né coordinate nei metadati.
create or replace function public.track_event(
  p_restaurant_id uuid,
  p_event_type public.analytics_event_type,
  p_session_id text default null,
  p_source text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_type text := case p_event_type::text
    when 'view' then 'restaurant_view' when 'click_phone' then 'phone_click' when 'click_whatsapp' then 'whatsapp_click'
    when 'click_directions' then 'directions_click' when 'click_menu' then 'menu_view' when 'click_reservation' then 'reservation_start'
    when 'click_website' then 'website_click' when 'click_social' then 'social_click' when 'coupon_reveal' then 'offer_view'
    else p_event_type::text end;
  v_meta jsonb := coalesce(p_metadata, '{}'::jsonb);
  k text;
begin
  if v_type in ('reservation_completed', 'coupon_claim', 'coupon_redeem') then return; end if;
  if p_restaurant_id is null then
    if v_type <> 'map_view' then return; end if;
  elsif not exists (select 1 from public.restaurants where id = p_restaurant_id and is_active) then
    return;
  end if;
  if jsonb_typeof(v_meta) <> 'object' then v_meta := '{}'::jsonb; end if;
  for k in select jsonb_object_keys(v_meta) loop
    if k ~* '(lat|lng|lon|coord|position|location|address|email|phone|name)' then v_meta := v_meta - k; end if;
  end loop;
  if pg_column_size(v_meta) > 2000 then v_meta := '{}'::jsonb; end if;
  insert into public.analytics_events (restaurant_id, event_type, user_id, session_id, source, metadata)
  values (p_restaurant_id, v_type::public.analytics_event_type, null, left(p_session_id, 64), left(p_source, 40), v_meta);
end $$;

-- Gli eventi della mappa confluiscono anche negli analytics (map_view, map_marker_click)
create or replace function public.track_app_event(
  p_event_type text,
  p_restaurant_id uuid default null,
  p_session_id text default null,
  p_source text default null,
  p_metadata jsonb default '{}'::jsonb
) returns void language plpgsql security definer set search_path = public as $$
declare
  v_meta jsonb := coalesce(p_metadata, '{}'::jsonb);
  k text;
begin
  if jsonb_typeof(v_meta) <> 'object' then v_meta := '{}'::jsonb; end if;
  for k in select jsonb_object_keys(v_meta) loop
    if k ~* '(lat|lng|lon|coord|position|location|address)' then v_meta := v_meta - k; end if;
  end loop;
  if pg_column_size(v_meta) > 2000 then v_meta := '{}'::jsonb; end if;
  insert into public.app_events (event_type, restaurant_id, session_id, source, metadata)
  values (p_event_type, p_restaurant_id, left(p_session_id, 64), left(p_source, 40), v_meta);
  if p_event_type = 'map_open' then
    insert into public.analytics_events (restaurant_id, event_type, session_id, source) values (null, 'map_view', left(p_session_id, 64), left(p_source, 40));
  elsif p_event_type = 'restaurant_marker_click' and p_restaurant_id is not null then
    insert into public.analytics_events (restaurant_id, event_type, session_id, source) values (p_restaurant_id, 'map_marker_click', left(p_session_id, 64), left(p_source, 40));
  end if;
exception when check_violation or foreign_key_violation then
  return;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  7. PRENOTAZIONI: disponibilità e flusso
-- ════════════════════════════════════════════════════════════════════
-- Disponibilità per data e numero di persone. Nessun dato di altri clienti viene restituito.
create or replace function public.get_reservation_availability(p_restaurant_id uuid, p_date date, p_party_size int)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r public.restaurants;
  st public.reservation_settings;
  v_local timestamp;
  v_today date;
  v_reason text;
  v_slots jsonb;
begin
  select * into r from public.restaurants where id = p_restaurant_id;
  if not found then
    return jsonb_build_object('ok', false, 'reason', 'Ristorante non trovato.', 'slots', '[]'::jsonb);
  end if;
  select * into st from public.reservation_settings where restaurant_id = p_restaurant_id;
  v_local := now() at time zone coalesce(r.timezone, 'Europe/Rome');
  v_today := v_local::date;
  v_reason := case
    when not (public.restaurant_is_public(r.id) or public.can_manage_restaurant(r.id)) then 'Ristorante non trovato.'
    when r.is_permanently_closed or r.is_temporarily_closed then 'Il ristorante non accetta prenotazioni in questo periodo.'
    when not r.has_reservation or st.restaurant_id is null or not st.reservation_enabled
         or not public.restaurant_has_feature(r.id, 'reservations_enabled') then 'Le prenotazioni online non sono attive per questo ristorante.'
    when p_date is null or p_date < v_today then 'Scegli una data a partire da oggi.'
    when p_date > v_today + st.max_advance_days then format('Puoi prenotare al massimo %s giorni prima.', st.max_advance_days)
    when p_party_size is null or p_party_size < st.min_party_size then format('Il numero minimo di persone è %s.', st.min_party_size)
    when p_party_size > st.max_party_size then format('Per gruppi di più di %s persone contatta direttamente il ristorante.', st.max_party_size)
    when exists (select 1 from public.restaurant_closures c where c.restaurant_id = r.id and c.date = p_date and c.start_time is null)
      then 'Il ristorante è chiuso in questa data.'
  end;
  if v_reason is not null then
    return jsonb_build_object('ok', false, 'reason', v_reason, 'slots', '[]'::jsonb);
  end if;

  with times as (
    select s.id as slot_id, s.start_time, s.end_time, s.max_reservations, s.max_guests,
           (s.start_time + (g * s.slot_interval_minutes) * interval '1 minute')::time as t
    from public.reservation_slots s
    cross join lateral generate_series(0, floor(extract(epoch from (s.end_time - s.start_time)) / 60 / s.slot_interval_minutes)::int) as g
    where s.restaurant_id = r.id and s.is_active and s.day_of_week = extract(isodow from p_date)::int
  ), active as (
    select a.reservation_time, a.party_size from public.reservations a
    where a.restaurant_id = r.id and a.reservation_date = p_date and a.status in ('pending', 'confirmed')
  ), calc as (
    select tm.t, tm.slot_id, tm.max_reservations, tm.max_guests,
      (select count(*) from active a where a.reservation_time = tm.t) as n_at_time,
      (select coalesce(sum(a.party_size), 0) from active a where a.reservation_time between tm.start_time and tm.end_time) as guests_window,
      exists (select 1 from public.restaurant_closures c
              where c.restaurant_id = r.id and c.date = p_date and c.start_time is not null and tm.t >= c.start_time and tm.t < c.end_time) as closed,
      (p_date + tm.t) < v_local + make_interval(mins => st.booking_notice_minutes) as too_soon
    from times tm
  ), uniq as (
    select distinct on (t) * from calc order by t, slot_id
  )
  select coalesce(jsonb_agg(jsonb_build_object(
      'time', to_char(t, 'HH24:MI'),
      'status', case
        when closed then 'closed'
        when too_soon then 'too_soon'
        when (max_reservations is not null and n_at_time >= max_reservations)
          or (max_guests is not null and guests_window + p_party_size > max_guests) then 'full'
        else 'available' end
    ) order by t), '[]'::jsonb)
  into v_slots from uniq;

  return jsonb_build_object(
    'ok', true,
    'reason', case when not exists (select 1 from jsonb_array_elements(v_slots) x where x->>'status' = 'available')
                   then 'Nessun orario disponibile in questa data.' end,
    'slots', v_slots,
    'auto_confirm', st.auto_confirm,
    'guest_message', st.guest_message
  );
end $$;

create or replace function public.create_reservation(
  p_restaurant_id uuid,
  p_date date,
  p_time time,
  p_party_size int,
  p_guest_name text,
  p_guest_surname text,
  p_guest_email text,
  p_guest_phone text,
  p_notes text default null,
  p_source public.reservation_source default 'web'
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  r public.restaurants;
  st public.reservation_settings;
  v_manager boolean := false;
  v_av jsonb;
  v_slot text;
  v_email text := nullif(lower(trim(coalesce(p_guest_email, ''))), '');
  v_phone text := trim(coalesce(p_guest_phone, ''));
  v_code text;
  v_status public.reservation_status;
  v_id uuid;
  v_today date;
  i int;
begin
  select * into r from public.restaurants where id = p_restaurant_id;
  if not found then raise exception 'Ristorante non trovato.'; end if;
  select * into st from public.reservation_settings where restaurant_id = p_restaurant_id;
  v_today := (now() at time zone coalesce(r.timezone, 'Europe/Rome'))::date;

  -- Validazione server-side di tutti i campi (mai fidarsi del client)
  if char_length(trim(coalesce(p_guest_name, ''))) not between 1 and 60 then raise exception 'Inserisci il nome.'; end if;
  if char_length(trim(coalesce(p_guest_surname, ''))) not between 1 and 60 then raise exception 'Inserisci il cognome.'; end if;
  if (v_email is null and p_source not in ('restaurant', 'admin'))
     or (v_email is not null and (v_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' or char_length(v_email) > 254)) then
    raise exception 'Inserisci un indirizzo email valido.';
  end if;
  if v_phone !~ '^\+?[0-9 ().-]{6,20}$' then raise exception 'Inserisci un numero di telefono valido.'; end if;
  if char_length(coalesce(p_notes, '')) > 500 then raise exception 'Le note possono contenere al massimo 500 caratteri.'; end if;
  if p_party_size is null or p_party_size not between 1 and 100 then raise exception 'Numero di persone non valido.'; end if;
  if p_date is null or p_time is null then raise exception 'Scegli data e orario.'; end if;

  if p_source in ('restaurant', 'admin') then
    -- Inserimento manuale dal gestionale (telefonata, cliente al banco)
    if not public.can_manage_restaurant(p_restaurant_id) or (p_source = 'admin' and not public.is_admin()) then
      raise exception 'Operazione non consentita.' using errcode = '42501';
    end if;
    perform public.assert_feature(p_restaurant_id, 'reservations_enabled');
    if p_date < v_today then raise exception 'Non puoi inserire prenotazioni nel passato.'; end if;
    v_manager := true;
  else
    -- Anti-abuso: limiti per email e telefono
    if (select count(*) from public.reservations where lower(guest_email) = v_email and created_at > now() - interval '1 hour') >= 5
       or (select count(*) from public.reservations where guest_phone = v_phone and created_at > now() - interval '1 hour') >= 5 then
      raise exception 'Troppe richieste in poco tempo. Riprova più tardi.';
    end if;
    if exists (select 1 from public.reservations where restaurant_id = p_restaurant_id and reservation_date = p_date
               and lower(guest_email) = v_email and status in ('pending', 'confirmed')) then
      raise exception 'Hai già una prenotazione presso questo ristorante per questa data.';
    end if;
  end if;

  -- Serializza le prenotazioni dello stesso locale e giorno: niente overbooking in concorrenza
  perform pg_advisory_xact_lock(hashtextextended(p_restaurant_id::text || ':' || p_date::text, 0));

  if not v_manager then
    v_av := public.get_reservation_availability(p_restaurant_id, p_date, p_party_size);
    if not (v_av->>'ok')::boolean then raise exception '%', v_av->>'reason'; end if;
    select s->>'status' into v_slot from jsonb_array_elements(v_av->'slots') s where s->>'time' = to_char(p_time, 'HH24:MI');
    if v_slot is null then raise exception 'Orario non valido per questa data.'; end if;
    if v_slot <> 'available' then
      raise exception 'Questo orario non è più disponibile. Scegli un altro orario.' using hint = 'slot_unavailable';
    end if;
  end if;

  v_status := case when v_manager or st.auto_confirm then 'confirmed' else 'pending' end;
  for i in 1..8 loop
    v_code := 'ASF-' || public.random_code(5);
    exit when not exists (select 1 from public.reservations where confirmation_code = v_code);
  end loop;

  insert into public.reservations (restaurant_id, user_id, guest_name, guest_surname, guest_email, guest_phone,
    reservation_date, reservation_time, party_size, notes, status, source, confirmation_code, confirmed_at, status_changed_by)
  values (p_restaurant_id, case when v_manager then null else auth.uid() end, trim(p_guest_name), trim(p_guest_surname), v_email, v_phone,
    p_date, p_time, p_party_size, nullif(trim(coalesce(p_notes, '')), ''), v_status, p_source, v_code,
    case when v_status = 'confirmed' then now() end, case when v_manager then auth.uid() end)
  returning id into v_id;

  if not v_manager then
    perform public.log_event(p_restaurant_id, 'reservation_completed', p_source::text, jsonb_build_object('party_size', p_party_size));
    perform public.notify_restaurant(p_restaurant_id, 'reservation_new',
      case when v_status = 'confirmed' then 'Nuova prenotazione confermata' else 'Nuova prenotazione da confermare' end,
      format('%s %s · %s persone · %s alle %s', trim(p_guest_name), left(trim(p_guest_surname), 1) || '.', p_party_size,
             to_char(p_date, 'DD/MM'), to_char(p_time, 'HH24:MI')),
      format('/dashboard/restaurants/%s/reservations', p_restaurant_id));
    perform public.enqueue_email('reservation_new_for_restaurant', r.email,
      jsonb_build_object('restaurant', r.name, 'date', p_date, 'time', to_char(p_time, 'HH24:MI'), 'party_size', p_party_size,
                         'code', v_code, 'status', v_status), p_restaurant_id, v_id);
  end if;
  perform public.enqueue_email(case when v_status = 'confirmed' then 'reservation_confirmed' else 'reservation_created' end, v_email,
    jsonb_build_object('restaurant', r.name, 'restaurant_slug', r.slug, 'guest_name', trim(p_guest_name), 'date', p_date,
                       'time', to_char(p_time, 'HH24:MI'), 'party_size', p_party_size, 'code', v_code, 'status', v_status),
    p_restaurant_id, v_id);

  return jsonb_build_object('id', v_id, 'code', v_code, 'status', v_status, 'reservation_date', p_date,
    'reservation_time', to_char(p_time, 'HH24:MI'), 'party_size', p_party_size,
    'restaurant_name', r.name, 'restaurant_slug', r.slug, 'guest_name', trim(p_guest_name));
end $$;

-- Cambio di stato: gestore (conferma/rifiuta/completata/no show/cancella) o cliente (cancella la propria)
create or replace function public.set_reservation_status(p_id uuid, p_status public.reservation_status, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  x public.reservations;
  r public.restaurants;
  v_manager boolean;
  v_today date;
  v_allowed boolean;
begin
  select * into x from public.reservations where id = p_id for update;
  if not found then raise exception 'Prenotazione non trovata.'; end if;
  select * into r from public.restaurants where id = x.restaurant_id;
  v_manager := public.can_manage_restaurant(x.restaurant_id);
  v_today := (now() at time zone coalesce(r.timezone, 'Europe/Rome'))::date;

  if not v_manager then
    if x.user_id is null or x.user_id <> auth.uid() or p_status <> 'cancelled' then
      raise exception 'Operazione non consentita.' using errcode = '42501';
    end if;
    if x.reservation_date < v_today then raise exception 'Non puoi cancellare una prenotazione passata.'; end if;
  end if;

  v_allowed := case x.status
    when 'pending' then p_status in ('confirmed', 'rejected', 'cancelled')
    when 'confirmed' then p_status in ('completed', 'no_show', 'cancelled')
    else false end;
  if not v_allowed then
    raise exception 'Questa prenotazione è già %.', case x.status
      when 'rejected' then 'stata rifiutata' when 'cancelled' then 'stata cancellata' when 'completed' then 'completata'
      when 'no_show' then 'segnata come no show' when 'confirmed' then 'confermata' else 'in attesa' end;
  end if;
  if p_status in ('completed', 'no_show') and x.reservation_date > v_today then
    raise exception 'Puoi segnarla come completata o no show dal giorno della prenotazione.';
  end if;

  update public.reservations set
    status = p_status,
    confirmed_at = case when p_status = 'confirmed' then now() else confirmed_at end,
    cancelled_at = case when p_status in ('cancelled', 'rejected') then now() else cancelled_at end,
    status_changed_by = auth.uid(),
    internal_notes = case when v_manager and nullif(trim(coalesce(p_note, '')), '') is not null
                          then left(trim(p_note), 500) else internal_notes end
  where id = p_id;

  if p_status in ('confirmed', 'rejected', 'cancelled') then
    perform public.enqueue_email('reservation_' || p_status::text, x.guest_email,
      jsonb_build_object('restaurant', r.name, 'restaurant_slug', r.slug, 'guest_name', x.guest_name, 'date', x.reservation_date,
                         'time', to_char(x.reservation_time, 'HH24:MI'), 'party_size', x.party_size, 'code', x.confirmation_code,
                         'status', p_status, 'by', case when v_manager then 'restaurant' else 'guest' end),
      x.restaurant_id, x.id);
  end if;
  if not v_manager then
    perform public.notify_restaurant(x.restaurant_id, 'reservation_cancelled', 'Prenotazione cancellata dal cliente',
      format('%s · %s persone · %s alle %s', x.confirmation_code, x.party_size, to_char(x.reservation_date, 'DD/MM'), to_char(x.reservation_time, 'HH24:MI')),
      format('/dashboard/restaurants/%s/reservations', x.restaurant_id));
  end if;
end $$;

-- Cancellazione da ospite (senza account): serve il codice e l'email usata
create or replace function public.cancel_reservation_by_code(p_code text, p_email text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare x public.reservations; r public.restaurants;
begin
  select * into x from public.reservations
   where confirmation_code = upper(trim(coalesce(p_code, ''))) and lower(guest_email) = lower(trim(coalesce(p_email, '')))
   for update;
  if not found then raise exception 'Prenotazione non trovata: controlla codice ed email.'; end if;
  select * into r from public.restaurants where id = x.restaurant_id;
  if x.status not in ('pending', 'confirmed') then raise exception 'Questa prenotazione non può più essere cancellata.'; end if;
  if x.reservation_date < (now() at time zone coalesce(r.timezone, 'Europe/Rome'))::date then
    raise exception 'Non puoi cancellare una prenotazione passata.';
  end if;
  update public.reservations set status = 'cancelled', cancelled_at = now() where id = x.id;
  perform public.enqueue_email('reservation_cancelled', x.guest_email,
    jsonb_build_object('restaurant', r.name, 'guest_name', x.guest_name, 'date', x.reservation_date,
                       'time', to_char(x.reservation_time, 'HH24:MI'), 'party_size', x.party_size, 'code', x.confirmation_code, 'by', 'guest'),
    x.restaurant_id, x.id);
  perform public.notify_restaurant(x.restaurant_id, 'reservation_cancelled', 'Prenotazione cancellata dal cliente',
    format('%s · %s persone · %s alle %s', x.confirmation_code, x.party_size, to_char(x.reservation_date, 'DD/MM'), to_char(x.reservation_time, 'HH24:MI')),
    format('/dashboard/restaurants/%s/reservations', x.restaurant_id));
  return jsonb_build_object('code', x.confirmation_code, 'status', 'cancelled', 'restaurant_name', r.name);
end $$;

-- "Prenota per stasera": locali con almeno un orario libero (solo disponibilità reali)
create or replace function public.restaurants_available_on(p_date date default null, p_party_size int default 2, p_from time default '18:00', p_limit int default 12)
returns table (restaurant_id uuid, first_slot text, slots_count int)
language plpgsql stable security definer set search_path = public as $$
declare rec record; v_av jsonb; v_first text; v_n int; v_found int := 0;
begin
  for rec in
    select r.id, coalesce(p_date, (now() at time zone r.timezone)::date) as d
    from public.restaurants r
    join public.reservation_settings s on s.restaurant_id = r.id and s.reservation_enabled
    where r.is_active and r.has_reservation and not r.is_temporarily_closed and not r.is_permanently_closed
      and public.restaurant_is_public(r.id) and public.restaurant_has_feature(r.id, 'reservations_enabled')
    order by r.popularity_score desc
    limit 60
  loop
    v_av := public.get_reservation_availability(rec.id, rec.d, p_party_size);
    if (v_av->>'ok')::boolean then
      select min(x->>'time'), count(*) into v_first, v_n
      from jsonb_array_elements(v_av->'slots') x
      where x->>'status' = 'available' and (x->>'time')::time >= p_from;
      if v_n > 0 then
        restaurant_id := rec.id; first_slot := v_first; slots_count := v_n;
        return next;
        v_found := v_found + 1;
        exit when v_found >= least(greatest(p_limit, 1), 30);
      end if;
    end if;
  end loop;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  8. COUPON: ottenimento e validazione
-- ════════════════════════════════════════════════════════════════════
create or replace function public.claim_coupon(p_coupon_id uuid, p_email text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  c public.coupons;
  r public.restaurants;
  v_uid uuid := auth.uid();
  v_email text := nullif(lower(trim(coalesce(p_email, ''))), '');
  v_existing public.coupon_claims;
  v_mine int;
  v_prefix text;
  v_code text;
  v_claim public.coupon_claims;
  i int;
begin
  select * into c from public.coupons where id = p_coupon_id for update;
  if not found then raise exception 'Coupon non trovato.'; end if;
  select * into r from public.restaurants where id = c.restaurant_id;
  if not public.restaurant_is_public(r.id) or r.is_permanently_closed
     or not public.restaurant_has_feature(r.id, 'coupons_enabled') then
    raise exception 'Coupon non disponibile.';
  end if;
  if not c.is_active or c.valid_from > now() then raise exception 'Questo coupon non è attivo.'; end if;
  if c.valid_until is not null and c.valid_until <= now() then raise exception 'Questo coupon è scaduto.' using hint = 'coupon_expired'; end if;

  if v_uid is null then
    if v_email is null then raise exception 'Inserisci la tua email per ottenere il coupon.'; end if;
    if v_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' or char_length(v_email) > 254 then raise exception 'Inserisci un indirizzo email valido.'; end if;
    if (select count(*) from public.coupon_claims where lower(email) = v_email and claimed_at > now() - interval '24 hours') >= 10 then
      raise exception 'Troppe richieste in poco tempo. Riprova domani.';
    end if;
  else
    v_email := null; -- con account non serve duplicare l'email
  end if;

  -- Limite per persona: con account restituisce il coupon già ottenuto (niente duplicati)
  select count(*) into v_mine from public.coupon_claims
   where coupon_id = c.id and status in ('claimed', 'redeemed')
     and ((v_uid is not null and user_id = v_uid) or (v_uid is null and lower(email) = v_email));
  if v_mine >= c.max_redemptions_per_user then
    if v_uid is not null then
      select * into v_existing from public.coupon_claims
       where coupon_id = c.id and user_id = v_uid and status = 'claimed' order by claimed_at desc limit 1;
      if found then
        return jsonb_build_object('claim_code', v_existing.claim_code, 'status', v_existing.status, 'already', true,
          'claimed_at', v_existing.claimed_at, 'valid_until', c.valid_until, 'title', c.title, 'restaurant_name', r.name, 'restaurant_slug', r.slug);
      end if;
    end if;
    raise exception 'Hai già ottenuto questo coupon.' using hint = 'coupon_already_claimed';
  end if;
  if c.max_redemptions is not null and c.claims_count >= c.max_redemptions then
    raise exception 'Coupon esaurito: sono stati già distribuiti tutti i codici.' using hint = 'coupon_sold_out';
  end if;

  v_prefix := left(regexp_replace(upper(c.code), '[^A-Z0-9]', '', 'g'), 10);
  for i in 1..8 loop
    v_code := v_prefix || '-' || public.random_code(4);
    exit when not exists (select 1 from public.coupon_claims where claim_code = v_code);
  end loop;
  insert into public.coupon_claims (coupon_id, restaurant_id, user_id, email, claim_code)
  values (c.id, c.restaurant_id, v_uid, v_email, v_code)
  returning * into v_claim;
  perform set_config('asiafood.internal_write', 'on', true);
  update public.coupons set claims_count = claims_count + 1 where id = c.id;
  perform set_config('asiafood.internal_write', '', true);
  perform public.log_event(c.restaurant_id, 'coupon_claim', 'web', jsonb_build_object('coupon_id', c.id));

  return jsonb_build_object('claim_code', v_claim.claim_code, 'status', v_claim.status, 'already', false,
    'claimed_at', v_claim.claimed_at, 'valid_until', c.valid_until, 'title', c.title, 'restaurant_name', r.name, 'restaurant_slug', r.slug);
end $$;

-- Verifica un codice senza modificarlo (anteprima in cassa)
create or replace function public.check_coupon_claim(p_restaurant_id uuid, p_code text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare x public.coupon_claims; c public.coupons;
begin
  if not public.can_manage_restaurant(p_restaurant_id) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
  select * into x from public.coupon_claims where claim_code = upper(regexp_replace(coalesce(p_code, ''), '\s+', '', 'g')) and restaurant_id = p_restaurant_id;
  if not found then return jsonb_build_object('found', false); end if;
  select * into c from public.coupons where id = x.coupon_id;
  return jsonb_build_object('found', true, 'claim_code', x.claim_code,
    'status', case when x.status = 'claimed' and c.valid_until is not null and c.valid_until <= now() then 'expired' else x.status::text end,
    'claimed_at', x.claimed_at, 'redeemed_at', x.redeemed_at, 'title', c.title, 'description', c.description,
    'discount_type', c.discount_type, 'discount_value', c.discount_value, 'minimum_spend', c.minimum_spend,
    'valid_until', c.valid_until, 'coupon_active', c.is_active);
end $$;

create or replace function public.redeem_coupon(p_restaurant_id uuid, p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare x public.coupon_claims; c public.coupons;
begin
  if not public.can_manage_restaurant(p_restaurant_id) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
  select * into x from public.coupon_claims
   where claim_code = upper(regexp_replace(coalesce(p_code, ''), '\s+', '', 'g')) and restaurant_id = p_restaurant_id for update;
  if not found then raise exception 'Codice non trovato per questo ristorante.'; end if;
  select * into c from public.coupons where id = x.coupon_id for update;
  if x.status = 'redeemed' then
    raise exception 'Coupon già utilizzato il %.', to_char(x.redeemed_at at time zone 'Europe/Rome', 'DD/MM/YYYY HH24:MI') using hint = 'coupon_redeemed';
  end if;
  if x.status <> 'claimed' then raise exception 'Coupon non valido (%).', x.status; end if;
  -- "Scaduto" è calcolato dalla validità del coupon (check_coupon_claim lo mostra come expired)
  if c.valid_until is not null and c.valid_until <= now() then
    raise exception 'Coupon scaduto.' using hint = 'coupon_expired';
  end if;
  if not c.is_active then raise exception 'Il coupon è stato disattivato.'; end if;
  update public.coupon_claims set status = 'redeemed', redeemed_at = now(), redeemed_by = auth.uid() where id = x.id;
  perform set_config('asiafood.internal_write', 'on', true);
  update public.coupons set redemptions_count = redemptions_count + 1 where id = c.id;
  perform set_config('asiafood.internal_write', '', true);
  perform public.log_event(p_restaurant_id, 'coupon_redeem', 'dashboard', jsonb_build_object('coupon_id', c.id));
  return jsonb_build_object('claim_code', x.claim_code, 'status', 'redeemed', 'title', c.title,
    'discount_type', c.discount_type, 'discount_value', c.discount_value, 'minimum_spend', c.minimum_spend);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  9. STATISTICHE RISTORATORE (conversioni reali, zero = zero)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.restaurant_analytics(p_restaurant_id uuid, p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_days int := least(greatest(coalesce(p_days, 30), 1), 365);
  v_since timestamptz := now() - make_interval(days => v_days);
  v_adv boolean;
  v_events jsonb; v_res jsonb; v_cou jsonb; v_daily jsonb := '[]'::jsonb; v_sources jsonb := '{}'::jsonb;
begin
  if not public.can_manage_restaurant(p_restaurant_id) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  perform public.assert_feature(p_restaurant_id, 'analytics_enabled');
  v_adv := public.is_admin() or public.restaurant_has_feature(p_restaurant_id, 'advanced_analytics');

  select coalesce(jsonb_object_agg(event_type, n), '{}'::jsonb) into v_events from (
    select event_type::text, count(*) n from public.analytics_events
    where restaurant_id = p_restaurant_id and created_at >= v_since group by event_type) e;

  select jsonb_build_object(
    'total', count(*) filter (where source in ('web', 'app')),
    'manual', count(*) filter (where source in ('restaurant', 'admin')),
    'pending', count(*) filter (where status = 'pending'),
    'confirmed', count(*) filter (where status = 'confirmed'),
    'completed', count(*) filter (where status = 'completed'),
    'no_show', count(*) filter (where status = 'no_show'),
    'cancelled', count(*) filter (where status in ('cancelled', 'rejected')),
    'covers', coalesce(sum(party_size) filter (where status in ('confirmed', 'completed')), 0))
  into v_res from public.reservations where restaurant_id = p_restaurant_id and created_at >= v_since;

  select jsonb_build_object(
    'claimed', (select count(*) from public.coupon_claims where restaurant_id = p_restaurant_id and claimed_at >= v_since),
    'redeemed', (select count(*) from public.coupon_claims where restaurant_id = p_restaurant_id and redeemed_at >= v_since))
  into v_cou;

  if v_adv then
    select coalesce(jsonb_agg(jsonb_build_object('date', d::date, 'views', coalesce(v.views, 0), 'contacts', coalesce(v.contacts, 0)) order by d), '[]'::jsonb)
    into v_daily
    from generate_series((now() - make_interval(days => v_days - 1))::date, now()::date, interval '1 day') d
    left join (
      select created_at::date as day,
             count(*) filter (where event_type = 'restaurant_view') as views,
             count(*) filter (where event_type in ('phone_click', 'whatsapp_click', 'directions_click', 'reservation_start')) as contacts
      from public.analytics_events where restaurant_id = p_restaurant_id and created_at >= v_since group by 1
    ) v on v.day = d::date;
    select coalesce(jsonb_object_agg(src, n), '{}'::jsonb) into v_sources from (
      select coalesce(source, 'direct') src, count(*) n from public.analytics_events
      where restaurant_id = p_restaurant_id and created_at >= v_since and event_type = 'restaurant_view' group by 1) s;
  end if;

  return jsonb_build_object('days', v_days, 'advanced', v_adv, 'events', v_events, 'reservations', v_res,
                            'coupons', v_cou, 'daily', v_daily, 'sources', v_sources);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  10. STRIPE (predisposizione) E LISTA D'ATTESA UPGRADE
-- ════════════════════════════════════════════════════════════════════
alter table public.subscriptions add column if not exists stripe_price_id text;
comment on column public.subscriptions.status is 'subscription_status (Stripe): trialing, active, past_due, canceled, incomplete';

create table public.plan_upgrade_requests (
  id               uuid primary key default gen_random_uuid(),
  restaurant_id    uuid not null references public.restaurants(id) on delete cascade,
  user_id          uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  plan_code        text not null references public.subscription_plans(code) on update cascade,
  billing_interval text not null default 'month' check (billing_interval in ('month', 'year')),
  message          text check (char_length(message) <= 500),
  status           text not null default 'open' check (status in ('open', 'contacted', 'closed')),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create unique index plan_upgrade_requests_one_open on public.plan_upgrade_requests(restaurant_id, plan_code) where status = 'open';
create trigger plan_upgrade_requests_updated_at before update on public.plan_upgrade_requests
  for each row execute function public.set_updated_at();

create or replace function public.plan_upgrade_requests_notify()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.notify_admins('plan_upgrade', 'Richiesta di upgrade piano',
    format('%s chiede il piano %s', (select name from public.restaurants where id = new.restaurant_id), upper(new.plan_code)),
    '/admin/plans');
  return null;
end $$;
create trigger plan_upgrade_requests_notify after insert on public.plan_upgrade_requests
  for each row execute function public.plan_upgrade_requests_notify();

-- ════════════════════════════════════════════════════════════════════
--  11. KPI ADMIN
-- ════════════════════════════════════════════════════════════════════
create or replace function public.admin_dashboard_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb;
begin
  if not public.is_admin() then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  select jsonb_build_object(
    'restaurants_total',      (select count(*) from public.restaurants),
    'restaurants_active',     (select count(*) from public.restaurants where is_active),
    'restaurants_draft',      (select count(*) from public.restaurants where not is_active),
    'restaurants_claimed',    (select count(*) from public.restaurants where owner_id is not null),
    'restaurants_demo',       (select count(*) from public.restaurants where is_demo),
    'restaurants_real',       (select count(*) from public.restaurants where not is_demo),
    'restaurants_verified',   (select count(*) from public.restaurants where data_status in ('verified', 'claimed')),
    'restaurants_unverified', (select count(*) from public.restaurants where data_status in ('unverified', 'outdated')),
    'restaurants_no_coords',  (select count(*) from public.restaurants where latitude is null or longitude is null),
    'restaurants_paid',       (select count(*) from public.restaurants where subscription_plan <> 'free'),
    'claims_pending',         (select count(*) from public.restaurant_claims where status in ('pending', 'under_review')),
    'claims_more_info',       (select count(*) from public.restaurant_claims where status = 'more_information_required'),
    'reports_open',           (select count(*) from public.restaurant_reports where status in ('open', 'in_progress')),
    'change_requests_pending',(select count(*) from public.restaurant_change_requests where status = 'pending'),
    'upgrade_requests_open',  (select count(*) from public.plan_upgrade_requests where status = 'open'),
    'users_total',            (select count(*) from public.profiles),
    'owners_total',           (select count(distinct user_id) from public.restaurant_members where status = 'active'),
    'offers_active',          (select count(*) from public.offers where is_active and (ends_at is null or ends_at > now())),
    'coupons_active',         (select count(*) from public.coupons where is_active and (valid_until is null or valid_until > now())),
    'coupons_claimed_30d',    (select count(*) from public.coupon_claims where claimed_at >= now() - interval '30 days'),
    'coupons_redeemed_30d',   (select count(*) from public.coupon_claims where redeemed_at >= now() - interval '30 days'),
    'reservations_30d',       (select count(*) from public.reservations where created_at >= now() - interval '30 days'),
    'reservations_pending',   (select count(*) from public.reservations where status = 'pending'),
    'emails_pending',         (select count(*) from public.email_outbox where status = 'pending'),
    'sponsored_active',       (select count(*) from public.sponsored_restaurants where is_active and (ends_at is null or ends_at > now())),
    'events_30d',             (select count(*) from public.analytics_events where created_at >= now() - interval '30 days'),
    'views_30d',              (select count(*) from public.analytics_events where event_type = 'restaurant_view' and created_at >= now() - interval '30 days'),
    'map_opens_30d',          (select count(*) from public.app_events where event_type = 'map_open' and created_at >= now() - interval '30 days'),
    'near_me_30d',            (select count(*) from public.app_events where event_type = 'near_me_search' and created_at >= now() - interval '30 days'),
    'show_demo_data',         public.demo_data_visible()
  ) into v;
  return v;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  12. RLS
-- ════════════════════════════════════════════════════════════════════
alter table public.plan_features          enable row level security;
alter table public.allergens              enable row level security;
alter table public.menu_item_variants     enable row level security;
alter table public.menu_item_addons       enable row level security;
alter table public.coupon_claims          enable row level security;
alter table public.reservation_settings   enable row level security;
alter table public.reservation_slots      enable row level security;
alter table public.restaurant_closures    enable row level security;
alter table public.reservations           enable row level security;
alter table public.notifications          enable row level security;
alter table public.email_outbox           enable row level security;
alter table public.plan_upgrade_requests  enable row level security;

-- Piani e allergeni: lettura pubblica, scrittura Admin
create policy "plan_features_read" on public.plan_features for select using (true);
create policy "plan_features_admin" on public.plan_features for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy "allergens_read" on public.allergens for select using (true);
create policy "allergens_admin" on public.allergens for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Varianti ed extra: come il menu
do $$
declare t text;
begin
  foreach t in array array['menu_item_variants', 'menu_item_addons'] loop
    execute format($f$create policy "%1$s_public_read" on public.%1$I for select using (
      public.menu_category_is_public((select i.menu_category_id from public.menu_items i where i.id = menu_item_id))
      or public.can_manage_restaurant(restaurant_id))$f$, t);
    execute format($f$create policy "%1$s_manage" on public.%1$I for all to authenticated
      using (public.can_manage_restaurant(restaurant_id)) with check (public.can_manage_restaurant(restaurant_id))$f$, t);
  end loop;
end $$;

-- Coupon ottenuti: il cliente vede i propri, il ristoratore quelli del suo locale. Scrittura solo via RPC.
create policy "coupon_claims_read" on public.coupon_claims for select to authenticated using (
  user_id = (select auth.uid()) or public.can_manage_restaurant(restaurant_id)
);

-- Impostazioni prenotazioni: lette dal pubblico (limiti di persone e messaggio), gestite dal locale
create policy "reservation_settings_read" on public.reservation_settings for select using (
  public.restaurant_is_public(restaurant_id) or public.can_manage_restaurant(restaurant_id)
);
create policy "reservation_settings_manage" on public.reservation_settings for all to authenticated
  using (public.can_manage_restaurant(restaurant_id)) with check (public.can_manage_restaurant(restaurant_id));
create policy "reservation_slots_manage" on public.reservation_slots for all to authenticated
  using (public.can_manage_restaurant(restaurant_id)) with check (public.can_manage_restaurant(restaurant_id));
create policy "restaurant_closures_manage" on public.restaurant_closures for all to authenticated
  using (public.can_manage_restaurant(restaurant_id)) with check (public.can_manage_restaurant(restaurant_id));

-- Prenotazioni: il pubblico non può enumerarle. Cliente = proprie; ristoratore = del proprio locale; Admin = tutte.
-- Nessun INSERT/UPDATE diretto: create_reservation / set_reservation_status validano tutto lato server.
create policy "reservations_read" on public.reservations for select to authenticated using (
  user_id = (select auth.uid()) or public.can_manage_restaurant(restaurant_id)
);
create policy "reservations_admin" on public.reservations for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

create policy "notifications_own" on public.notifications for select to authenticated using (user_id = (select auth.uid()));
create policy "notifications_delete_own" on public.notifications for delete to authenticated using (user_id = (select auth.uid()));

create policy "email_outbox_admin" on public.email_outbox for select to authenticated using (public.is_admin());

create policy "upgrade_requests_insert" on public.plan_upgrade_requests for insert to authenticated with check (
  user_id = (select auth.uid()) and status = 'open' and public.owns_restaurant(restaurant_id)
);
create policy "upgrade_requests_read" on public.plan_upgrade_requests for select to authenticated using (
  user_id = (select auth.uid()) or public.is_admin()
);
create policy "upgrade_requests_admin" on public.plan_upgrade_requests for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy "upgrade_requests_admin_delete" on public.plan_upgrade_requests for delete to authenticated
  using (public.is_admin());

-- ════════════════════════════════════════════════════════════════════
--  13. PRIVILEGI
-- ════════════════════════════════════════════════════════════════════
grant select on public.plan_features, public.allergens, public.plans, public.menu_item_variants, public.menu_item_addons,
  public.reservation_settings to anon, authenticated;
grant insert, update, delete on public.plan_features, public.allergens, public.menu_item_variants, public.menu_item_addons,
  public.reservation_settings, public.reservation_slots, public.restaurant_closures to authenticated;
grant select on public.reservation_slots, public.restaurant_closures, public.coupon_claims, public.reservations,
  public.notifications, public.email_outbox, public.plan_upgrade_requests to authenticated;
grant update, delete on public.reservations to authenticated;          -- solo Admin (RLS)
grant delete on public.notifications to authenticated;
grant insert, update, delete on public.plan_upgrade_requests to authenticated;
revoke insert, update, delete on public.coupon_claims, public.email_outbox from anon, authenticated;
revoke insert on public.reservations, public.notifications from anon, authenticated;

-- Funzioni interne: mai eseguibili dal client
revoke all on function public.notify_restaurant(uuid, text, text, text, text) from public, anon, authenticated;
revoke all on function public.notify_admins(text, text, text, text) from public, anon, authenticated;
revoke all on function public.enqueue_email(text, text, jsonb, uuid, uuid) from public, anon, authenticated;
revoke all on function public.log_event(uuid, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.random_code(int) from public, anon, authenticated;

-- Funzioni pubbliche (controlli interni)
grant execute on function public.restaurant_has_feature(uuid, text), public.restaurant_feature_limit(uuid, text),
  public.menu_is_public(uuid), public.menu_category_is_public(uuid), public.normalize_allergens(text[]),
  public.get_reservation_availability(uuid, date, int),
  public.create_reservation(uuid, date, time, int, text, text, text, text, text, public.reservation_source),
  public.cancel_reservation_by_code(text, text), public.claim_coupon(uuid, text),
  public.restaurants_available_on(date, int, time, int) to anon, authenticated;
revoke all on function public.set_reservation_status(uuid, public.reservation_status, text) from public, anon;
revoke all on function public.check_coupon_claim(uuid, text) from public, anon;
revoke all on function public.redeem_coupon(uuid, text) from public, anon;
revoke all on function public.restaurant_analytics(uuid, int) from public, anon;
revoke all on function public.duplicate_menu(uuid) from public, anon;
revoke all on function public.duplicate_menu_item(uuid, uuid) from public, anon;
revoke all on function public.reorder_menu_rows(text, uuid[]) from public, anon;
revoke all on function public.import_menu(uuid, jsonb) from public, anon;
revoke all on function public.mark_notifications_read(uuid[]) from public, anon;
grant execute on function public.set_reservation_status(uuid, public.reservation_status, text), public.check_coupon_claim(uuid, text),
  public.redeem_coupon(uuid, text), public.restaurant_analytics(uuid, int), public.duplicate_menu(uuid),
  public.duplicate_menu_item(uuid, uuid), public.reorder_menu_rows(text, uuid[]), public.import_menu(uuid, jsonb),
  public.mark_notifications_read(uuid[]) to authenticated;
