-- ════════════════════════════════════════════════════════════════════
--  FASE 13 · BUSINESS INTELLIGENCE & GROWTH AUTOMATION — parte 1 (fondamenta dati)
--
--  Principi (docs/growth/README.md):
--   • Solo dati reali: ogni numero viene da una tabella di dominio o da un evento tracciato.
--     Dove i dati non bastano si restituisce null / "insufficient" — mai una stima travestita da dato.
--   • Additivo: nessun evento o tabella esistente viene rinominato o cancellato.
--     La tassonomia canonica è un ADATTATORE (tabella di mapping + vista) sopra i nomi storici.
--   • Privacy: niente user_id negli eventi, sessione solo con consenso "Statistiche",
--     testo di ricerca normalizzato e filtrato (mai email/telefoni), aggregati giornalieri anonimi.
--   • Prestazioni: le dashboard leggono tabelle aggregate giornaliere (idempotenti, ricalcolabili).
-- ════════════════════════════════════════════════════════════════════

-- ────────────────────────────────────────────────────────────────────
--  1. IMPOSTAZIONI (soglie e pesi trasparenti, modificabili dall'Admin)
-- ────────────────────────────────────────────────────────────────────
insert into public.platform_settings (key, value, description) values
  ('growth_return_window_days',        '30',   'Finestra del "ritorno": un utente è tornato se ha un giorno di attività entro N giorni dalla conversione'),
  ('growth_min_sample',                '30',   'Campione minimo per mostrare tassi, drop-off e confronti (sotto: "Dati insufficienti")'),
  ('growth_experiment_min_sample',     '100',  'Esperimenti: utenti minimi per variante prima di indicare un vincitore'),
  ('growth_directions_as_conversion',  'false','Conta "Indicazioni stradali" e "Chiamata" come conversione qualificata (default: solo intenzione)'),
  ('growth_supply_gap_min_searches',   '5',    'Supply gap: ricerche minime nel periodo per mostrare una combinazione comune/categoria'),
  ('growth_alert_zero_result_min',     '10',   'Alert: ricerche senza risultati (stessa combinazione, 7 giorni) oltre cui segnalare'),
  ('growth_alert_no_login_days',       '21',   'Alert: ristorante pagante/in prova senza accessi da N giorni'),
  ('growth_anomaly_min_baseline',      '10',   'Anomalie: volume minimo medio giornaliero (7 giorni precedenti) per valutare un calo'),
  ('growth_anomaly_drop_pct',          '60',   'Anomalie: calo percentuale di ordini/prenotazioni rispetto alla media dei 7 giorni precedenti'),
  ('growth_checkout_drop_pct',         '25',   'Anomalie: calo della conversione checkout → pagamento (punti percentuali relativi)'),
  ('growth_search_log_days',           '90',   'Ricerche grezze conservate N giorni (gli aggregati giornalieri anonimi restano)'),
  ('growth_market_weights',            '{"search_demand": 30, "supply_gap": 25, "lead_availability": 20, "organic_interest": 15, "commercial_interest": 10}',
                                               'Pesi del Market Opportunity Score (somma libera, normalizzata a 100)'),
  ('growth_forecast',                  'null', 'Ipotesi scenari Conservative/Base/Growth (inserite dall''Admin): input dei calcoli, mai risultati'),
  ('growth_payment_fee_pct',           'null', 'Costo di incasso stimato (%) usato SOLO se l''ordine non riporta la commissione reale; null = non stimare'),
  ('automation_kill_switch',           'false','Interruttore generale: se true nessuna automazione viene eseguita'),
  ('growth_expansion_candidates',      '["bari", "lecce", "brindisi", "matera", "foggia"]', 'Città candidate da ANALIZZARE (nessuna scelta automatica)')
on conflict (key) do nothing;

create or replace function public.growth_setting_json(p_key text, p_default jsonb)
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce((select nullif(value, 'null'::jsonb) from public.platform_settings where key = p_key), p_default);
$$;

-- Ristoranti inclusi nelle metriche: reali; DEMO solo se l'ambiente li mostra (sempre dichiarato in UI)
create or replace function public.growth_in_scope(p_is_demo boolean)
returns boolean language sql stable security definer set search_path = public as $$
  select not coalesce(p_is_demo, false) or public.demo_data_visible();
$$;

create or replace function public.growth_day_bounds(p_day date, out v_from timestamptz, out v_to timestamptz)
language sql immutable as $$
  select (p_day::timestamp at time zone 'Europe/Rome'), ((p_day + 1)::timestamp at time zone 'Europe/Rome');
$$;

-- Mercato di un ristorante (per provincia; un solo mercato per provincia)
create or replace function public.growth_market_of_city(p_city uuid)
returns uuid language sql stable security definer set search_path = public as $$
  select m.id from public.markets m join public.cities c on c.province_id = m.province_id where c.id = p_city limit 1;
$$;

-- ────────────────────────────────────────────────────────────────────
--  2. TASSONOMIA EVENTI CANONICA (adattatore sui nomi storici — nessuna rinomina distruttiva)
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.growth_event_taxonomy (
  canonical     text primary key check (canonical ~ '^[a-z_]{3,40}$'),
  label         text not null,
  stage         text not null check (stage in ('visit', 'search', 'view', 'intent', 'conversion', 'return', 'revenue', 'b2b', 'engagement')),
  source        text not null check (source in ('analytics_events', 'app_events', 'domain', 'search_events')),
  legacy_names  text[] not null default '{}',
  domain_ref    text,               -- tabella di verità per gli eventi "domain"
  description   text not null,
  status        text not null default 'active' check (status in ('active', 'planned')),
  pii           text not null default 'none' check (pii = 'none')
);

insert into public.growth_event_taxonomy (canonical, label, stage, source, legacy_names, domain_ref, description, status) values
  ('session_started',       'Sessione avviata',            'visit',      'app_events',       array['session_started'], null, 'Prima pagina di una sessione di navigazione (una per sessione). Le visite senza consenso sono contate da acquisition_visits.', 'active'),
  ('search_performed',      'Ricerca effettuata',          'search',     'search_events',    array['search', 'near_me_search', 'map_area_search'], 'search_events', 'Ricerca da Esplora/AI (search_events, testo normalizzato) o dalla mappa (app_events).', 'active'),
  ('restaurant_viewed',     'Scheda ristorante vista',     'view',       'analytics_events', array['restaurant_view', 'view'], null, 'Apertura della scheda pubblica del ristorante.', 'active'),
  ('menu_viewed',           'Menu visto',                  'intent',     'analytics_events', array['menu_view', 'click_menu', 'menu_item_view'], null, 'Apertura del menu o di un piatto (menu_item_view = visione approfondita).', 'active'),
  ('favorite_added',        'Aggiunto ai preferiti',       'intent',     'domain',           array['favorite_added'], 'favorites', 'Riga creata in favorites (utente registrato).', 'active'),
  ('map_opened',            'Mappa aperta',                'view',       'app_events',       array['map_open', 'map_view'], null, 'Apertura della mappa.', 'active'),
  ('directions_clicked',    'Indicazioni stradali',        'intent',     'analytics_events', array['directions_click', 'click_directions'], null, 'Tap su "Indicazioni". Conversione qualificata solo se growth_directions_as_conversion = true.', 'active'),
  ('phone_clicked',         'Chiamata',                    'intent',     'analytics_events', array['phone_click', 'click_phone'], null, 'Tap sul numero di telefono.', 'active'),
  ('whatsapp_clicked',      'WhatsApp',                    'intent',     'analytics_events', array['whatsapp_click', 'click_whatsapp'], null, 'Tap su WhatsApp.', 'active'),
  ('offer_viewed',          'Offerta vista',               'intent',     'analytics_events', array['offer_view', 'coupon_reveal'], null, 'Visualizzazione di un''offerta.', 'active'),
  ('coupon_claimed',        'Coupon richiesto',            'intent',     'domain',           array['coupon_claim'], 'coupon_claims', 'Riga in coupon_claims (verità lato server).', 'active'),
  ('coupon_redeemed',       'Coupon utilizzato',           'conversion', 'domain',           array['coupon_redeem'], 'coupon_claims', 'coupon_claims.status = redeemed (validato dal ristorante).', 'active'),
  ('reservation_started',   'Prenotazione iniziata',       'intent',     'analytics_events', array['reservation_start', 'click_reservation'], null, 'Apertura del modulo di prenotazione.', 'active'),
  ('reservation_completed', 'Prenotazione inviata',        'conversion', 'domain',           array['reservation_completed'], 'reservations', 'Richiesta di prenotazione registrata (non rifiutata dal sistema). La visita avvenuta è reservations.status = completed.', 'active'),
  ('cart_created',          'Carrello creato',             'intent',     'domain',           array[]::text[], 'carts', 'Riga in carts.', 'active'),
  ('add_to_cart',           'Aggiunta al carrello',        'intent',     'analytics_events', array['add_to_cart'], null, 'Piatto aggiunto al carrello.', 'active'),
  ('checkout_started',      'Checkout iniziato',           'intent',     'analytics_events', array['checkout_started'], null, 'Apertura del checkout.', 'active'),
  ('payment_completed',     'Pagamento completato',        'revenue',    'domain',           array['payment_success'], 'orders', 'orders.payment_status = paid (confermato dal webhook, mai dal client).', 'active'),
  ('order_completed',       'Ordine completato',           'conversion', 'domain',           array['order_completed'], 'orders', 'orders.status = completed.', 'active'),
  ('review_created',        'Recensione creata',           'engagement', 'domain',           array[]::text[], 'reviews', 'Riga in reviews.', 'active'),
  ('referral_shared',       'Invito condiviso',            'engagement', 'app_events',       array['referral_shared'], null, 'Tap su "Condividi" del codice invito (nessun destinatario salvato).', 'active'),
  ('referral_qualified',    'Invito qualificato',          'engagement', 'domain',           array[]::text[], 'referrals', 'referrals.qualified_at valorizzato (regole AsiaPoints).', 'active'),
  ('subscription_started',  'Abbonamento avviato',         'b2b',        'domain',           array['subscription_started'], 'billing_activity', 'billing_activity.event = subscription_started (Stripe).', 'active'),
  ('subscription_cancelled','Abbonamento disdetto',        'b2b',        'domain',           array['subscription_cancelled'], 'billing_activity', 'billing_activity.event = subscription_cancelled (disdetta a fine periodo) o subscription_ended.', 'active')
on conflict (canonical) do update set label = excluded.label, stage = excluded.stage, source = excluded.source, legacy_names = excluded.legacy_names,
  domain_ref = excluded.domain_ref, description = excluded.description, status = excluded.status;

-- Nuovi eventi app (additivi): sessione, preferito, condivisione invito, conversione per il funnel di sessione
alter table public.app_events drop constraint if exists app_events_event_type_check;
alter table public.app_events add constraint app_events_event_type_check check (event_type in (
  'map_open', 'location_permission_requested', 'location_permission_granted', 'location_permission_denied',
  'restaurant_marker_click', 'directions_click', 'near_me_search', 'map_area_search',
  'search', 'landing_view', 'install_prompt_shown', 'install_accepted', 'experiment_exposure', 'qr_kit_download', 'feedback_opened',
  'session_started', 'favorite_added', 'referral_shared', 'conversion'));
create index if not exists app_events_type_created_idx on public.app_events(event_type, created_at desc);
create index if not exists app_events_session_idx on public.app_events(session_id, created_at) where session_id is not null;
create index if not exists analytics_events_session_idx on public.analytics_events(session_id, created_at) where session_id is not null;
create index if not exists analytics_events_type_created_idx on public.analytics_events(event_type, created_at desc);

-- "conversion" dal client serve SOLO ad attribuire la conversione alla sessione nel funnel;
-- i totali di conversione restano quelli delle tabelle di dominio. Tipi ammessi e nient'altro.
create or replace function public.track_app_event(
  p_event_type text,
  p_restaurant_id uuid default null,
  p_session_id text default null,
  p_source text default null,
  p_metadata jsonb default '{}'::jsonb
) returns void language plpgsql security definer set search_path = public as $$
declare
  v_meta jsonb := coalesce(p_metadata, '{}'::jsonb);
  k text;
begin
  if jsonb_typeof(v_meta) <> 'object' then v_meta := '{}'::jsonb; end if;
  for k in select jsonb_object_keys(v_meta) loop
    if k ~* '(lat|lng|lon|coord|position|location|address|email|phone|name|message|text|query)' then v_meta := v_meta - k; end if;
  end loop;
  if p_event_type = 'conversion' then
    if coalesce(v_meta ->> 'kind', '') not in ('reservation_completed', 'order_completed', 'coupon_claimed') or p_session_id is null then return; end if;
    v_meta := jsonb_build_object('kind', v_meta ->> 'kind');
  end if;
  if pg_column_size(v_meta) > 2000 then v_meta := '{}'::jsonb; end if;
  insert into public.app_events (event_type, restaurant_id, session_id, source, metadata)
  values (p_event_type, p_restaurant_id, left(p_session_id, 64), left(p_source, 40), v_meta);
  if p_event_type = 'map_open' then
    insert into public.analytics_events (restaurant_id, event_type, session_id, source) values (null, 'map_view', left(p_session_id, 64), left(p_source, 40));
  elsif p_event_type = 'restaurant_marker_click' and p_restaurant_id is not null then
    insert into public.analytics_events (restaurant_id, event_type, session_id, source) values (p_restaurant_id, 'map_marker_click', left(p_session_id, 64), left(p_source, 40));
  end if;
exception when check_violation or foreign_key_violation then
  return;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  3. RICERCHE (privacy-safe): testo normalizzato + filtri + numero risultati. Mai utente.
-- ────────────────────────────────────────────────────────────────────
-- Normalizza il testo digitato. Restituisce null se sembra contenere dati personali
-- (email, numeri lunghi) o se è troppo lungo per essere una ricerca di cibo/luogo.
create or replace function public.growth_normalize_query(p text)
returns text language plpgsql immutable as $$
declare v text;
begin
  if p is null then return null; end if;
  if p ~ '@' or p ~ '[0-9][0-9 .-]{4,}[0-9]' or p ~* 'https?://' then return null; end if;
  v := lower(translate(p, 'ÀÁÂÄàáâäÈÉÊËèéêëÌÍÎÏìíîïÒÓÔÖòóôöÙÚÛÜùúûüÇçÑñ', 'AAAAaaaaEEEEeeeeIIIIiiiiOOOOooooUUUUuuuuCcNn'));
  v := regexp_replace(v, '[^a-z0-9'' ]', ' ', 'g');
  v := btrim(regexp_replace(v, '\s+', ' ', 'g'));
  if char_length(v) < 2 or char_length(v) > 60 then return null; end if;
  if array_length(string_to_array(v, ' '), 1) > 6 then return null; end if;
  return v;
end $$;

create table if not exists public.search_events (
  id             bigint generated always as identity primary key,
  source         text not null default 'explore' check (source in ('explore', 'map', 'home', 'city', 'category', 'ai', 'other')),
  query_norm     text check (query_norm is null or char_length(query_norm) between 2 and 60),
  city_slug      text check (city_slug is null or city_slug ~ '^[a-z0-9-]{2,60}$'),
  category_slug  text check (category_slug is null or category_slug ~ '^[a-z0-9-]{2,60}$'),
  market_id      uuid references public.markets(id) on delete set null,
  result_count   int not null default 0 check (result_count >= 0),
  result_ids     uuid[] not null default '{}' check (cardinality(result_ids) <= 20),
  session_id     text check (session_id is null or session_id ~ '^[A-Za-z0-9_-]{8,64}$'),   -- solo con consenso "Statistiche"
  created_at     timestamptz not null default now()
);
create index if not exists search_events_created_idx on public.search_events(created_at desc);
create index if not exists search_events_combo_idx on public.search_events(city_slug, category_slug, created_at desc);
create index if not exists search_events_session_idx on public.search_events(session_id, created_at) where session_id is not null;
comment on table public.search_events is 'Ricerche anonime (nessun utente, IP o posizione). Testo normalizzato e filtrato; conservazione growth_search_log_days.';

create or replace function public.growth_search_insert(p jsonb, p_source text)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_city text := lower(nullif(p ->> 'city_slug', ''));
  v_cat text := lower(nullif(p ->> 'category_slug', ''));
  v_q text := public.growth_normalize_query(p ->> 'query');
  v_ids uuid[];
  v_market uuid;
  v_sess text := nullif(p ->> 'session_id', '');
begin
  if v_city is not null and not exists (select 1 from public.cities where slug = v_city) then v_city := null; end if;
  if v_cat is not null and not exists (select 1 from public.categories where slug = v_cat) then v_cat := null; end if;
  if v_q is null and v_city is null and v_cat is null then return; end if;
  if v_sess is not null and v_sess !~ '^[A-Za-z0-9_-]{8,64}$' then v_sess := null; end if;
  select coalesce(array_agg(r.id), '{}') into v_ids from (
    select x::uuid as id from jsonb_array_elements_text(case when jsonb_typeof(p -> 'result_ids') = 'array' then p -> 'result_ids' else '[]'::jsonb end) x
     where x ~ '^[0-9a-f-]{36}$' limit 20) r
   where exists (select 1 from public.restaurants rr where rr.id = r.id);
  if v_city is not null then v_market := public.growth_market_of_city((select id from public.cities where slug = v_city)); end if;
  insert into public.search_events (source, query_norm, city_slug, category_slug, market_id, result_count, result_ids, session_id)
  values (p_source, v_q, v_city, v_cat, v_market, greatest(0, least(coalesce((p ->> 'result_count')::int, 0), 100000)), v_ids, v_sess);
end $$;

-- Registrazione dal client (Esplora). Rate limit per chiamante; fallimenti silenziosi (l'analytics non blocca la UI).
create or replace function public.log_search(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare v_source text := coalesce(nullif(p ->> 'source', ''), 'explore');
begin
  if jsonb_typeof(p) <> 'object' then return; end if;
  if not public.rate_limit_hit('search_log', public.rate_limit_caller_key(), 60, 60) then return; end if;
  if v_source not in ('explore', 'map', 'home', 'city', 'category', 'other') then v_source := 'other'; end if;
  perform public.growth_search_insert(p, v_source);
exception when others then
  return;
end $$;

-- AI: i filtri strutturati (comune, categoria, piatto) diventano ricerche "ai" — alimentano il Supply Gap.
alter table public.ai_usage add column if not exists search_city text check (search_city is null or search_city ~ '^[a-z0-9-]{2,60}$');
alter table public.ai_usage add column if not exists search_category text check (search_category is null or search_category ~ '^[a-z0-9-]{2,60}$');
alter table public.ai_usage add column if not exists search_term text check (search_term is null or char_length(search_term) <= 60);

create or replace function public.ai_log_usage(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare v_in int := greatest(coalesce((p ->> 'input_tokens')::int, 0), 0); v_out int := greatest(coalesce((p ->> 'output_tokens')::int, 0), 0);
        v_city text := lower(nullif(p ->> 'search_city', '')); v_cat text := lower(nullif(p ->> 'search_category', ''));
        v_term text := public.growth_normalize_query(p ->> 'search_term');
begin
  perform public.assert_service();
  if v_city is not null and not exists (select 1 from public.cities where slug = v_city) then v_city := null; end if;
  if v_cat is not null and not exists (select 1 from public.categories where slug = v_cat) then v_cat := null; end if;
  insert into public.ai_usage (user_id, session_id, ip_hash, provider, model, input_tokens, output_tokens, estimated_cost,
    request_type, intent, status, result_count, no_results, latency_ms, search_city, search_category, search_term)
  values (nullif(p ->> 'user_id', '')::uuid, left(p ->> 'session_id', 64), left(p ->> 'ip_hash', 64), left(p ->> 'provider', 40), left(p ->> 'model', 80),
    v_in, v_out,
    round((v_in * public.ai_setting_num('ai_cost_input_per_mtok', 3) + v_out * public.ai_setting_num('ai_cost_output_per_mtok', 15)) / 1000000.0, 6),
    coalesce(p ->> 'request_type', 'chat'), left(p ->> 'intent', 40), p ->> 'status', coalesce((p ->> 'result_count')::int, 0),
    coalesce((p ->> 'no_results')::boolean, false), (p ->> 'latency_ms')::int, v_city, v_cat, v_term);
  -- Ricerca AI con filtri strutturati → search_events (senza sessione: l'id della chat non è una sessione analytics)
  if p ->> 'status' in ('ok', 'fallback', 'cached') and (v_city is not null or v_cat is not null or v_term is not null) then
    perform public.growth_search_insert(jsonb_build_object('query', v_term, 'city_slug', v_city, 'category_slug', v_cat,
      'result_count', coalesce((p ->> 'result_count')::int, 0)), 'ai');
  end if;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  4. ATTRIBUZIONE: first touch (esistente) + last touch (nuovo), modello semplice e dichiarato
-- ────────────────────────────────────────────────────────────────────
alter table public.user_acquisition add column if not exists last_channel text;
alter table public.user_acquisition add column if not exists last_utm_source text;
alter table public.user_acquisition add column if not exists last_utm_campaign text;
alter table public.acquisition_visits add column if not exists device_type text check (device_type is null or device_type in ('mobile', 'tablet', 'desktop'));

create or replace function public.growth_clean_channel(p text)
returns text language sql immutable as $$
  select case when lower(coalesce(p, '')) in ('organic_search', 'social', 'qr', 'direct', 'referral', 'restaurant_referral', 'paid_social', 'influencer', 'email', 'partner', 'offline', 'other')
              then lower(p) else null end;
$$;
create or replace function public.growth_clean_utm(p text)
returns text language sql immutable as $$
  select nullif(left(regexp_replace(lower(coalesce(p, '')), '[^a-z0-9_.-]', '', 'g'), 60), '');
$$;

-- Canale "di business" (Organic Google, Instagram, QR ristorante…) da canale tecnico + utm_source. Specchio: shared/growth.ts
create or replace function public.growth_channel(p_channel text, p_utm_source text)
returns text language sql immutable as $$
  select case
    when p_channel = 'organic_search' then 'organic_google'
    when p_channel = 'paid_social' then 'paid_social'
    when p_channel = 'qr' or p_channel = 'restaurant_referral' then 'restaurant_qr'
    when p_channel = 'influencer' then 'creator'
    when p_channel in ('referral') then 'referral'
    when p_channel = 'partner' then 'partner'
    when p_channel = 'email' then 'email'
    when p_channel = 'direct' then 'direct'
    when p_channel = 'social' and coalesce(p_utm_source, '') ~ '^(ig|instagram)' then 'instagram'
    when p_channel = 'social' and coalesce(p_utm_source, '') ~ '^(fb|facebook|meta)' then 'facebook'
    when p_channel = 'social' and coalesce(p_utm_source, '') ~ '^(tt|tiktok)' then 'tiktok'
    when p_channel = 'social' then 'other_social'
    else 'other' end;
$$;

create or replace function public.attribute_my_signup(p jsonb)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_channel text := coalesce(public.growth_clean_channel(p ->> 'channel'), 'other');
begin
  if v_uid is null then return false; end if;
  if exists (select 1 from public.user_acquisition where user_id = v_uid) then return false; end if;
  if not exists (select 1 from public.profiles where id = v_uid and created_at > now() - interval '7 days') then return false; end if;
  insert into public.user_acquisition (user_id, market_id, channel, utm_source, utm_medium, utm_campaign, promo_code, last_channel, last_utm_source, last_utm_campaign)
  values (v_uid, (public.launch_market(coalesce(p ->> 'market', 'taranto'))).id, v_channel,
          public.growth_clean_utm(p ->> 'utm_source'), public.growth_clean_utm(p ->> 'utm_medium'), public.growth_clean_utm(p ->> 'utm_campaign'),
          (select code from public.acquisition_codes where code = upper(p ->> 'promo_code') and is_active),
          coalesce(public.growth_clean_channel(p ->> 'last_channel'), v_channel),
          coalesce(public.growth_clean_utm(p ->> 'last_utm_source'), public.growth_clean_utm(p ->> 'utm_source')),
          coalesce(public.growth_clean_utm(p ->> 'last_utm_campaign'), public.growth_clean_utm(p ->> 'utm_campaign')))
  on conflict (user_id) do nothing;
  return true;
end $$;

create or replace function public.record_visit(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_channel text := coalesce(public.growth_clean_channel(p ->> 'channel'), 'other');
  v_code text := upper(nullif(regexp_replace(coalesce(p ->> 'promo_code', ''), '[^A-Za-z0-9]', '', 'g'), ''));
  v_market uuid := (public.launch_market(coalesce(p ->> 'market', 'taranto'))).id;
  v_device text := case when p ->> 'device_type' in ('mobile', 'tablet', 'desktop') then p ->> 'device_type' end;
begin
  if not public.rate_limit_hit('visit', public.rate_limit_caller_key(), 20, 60) then return; end if;
  if v_code is not null and not exists (select 1 from public.acquisition_codes where code = v_code and is_active) then v_code := null; end if;
  insert into public.acquisition_visits (market_id, channel, utm_source, utm_medium, utm_campaign, utm_content, landing_path, promo_code, device_type)
  values (v_market, v_channel, public.growth_clean_utm(p ->> 'utm_source'), public.growth_clean_utm(p ->> 'utm_medium'),
          public.growth_clean_utm(p ->> 'utm_campaign'), public.growth_clean_utm(p ->> 'utm_content'),
          left(regexp_replace(coalesce(p ->> 'landing_path', ''), '[?#].*$', ''), 200), v_code, v_device);
  if v_code is not null then update public.acquisition_codes set uses = uses + 1 where code = v_code; end if;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  5. VISTA EVENTI CANONICI (solo per aggregazioni e audit; mai letta dalle dashboard per grafico)
-- ────────────────────────────────────────────────────────────────────
create or replace view public.growth_events with (security_invoker = true) as
  select e.created_at as occurred_at, t.canonical, e.restaurant_id, r.city_id, e.session_id, e.source,
         e.metadata ->> 'utm_source' as utm_source, e.metadata ->> 'utm_campaign' as utm_campaign, e.metadata ->> 'device_type' as device_type,
         'analytics_events'::text as origin
    from public.analytics_events e
    join public.growth_event_taxonomy t on t.source in ('analytics_events', 'app_events') and e.event_type::text = any(t.legacy_names)
    left join public.restaurants r on r.id = e.restaurant_id
  union all
  select a.created_at, t.canonical, a.restaurant_id, r.city_id, a.session_id, a.source,
         a.metadata ->> 'utm_source', a.metadata ->> 'utm_campaign', a.metadata ->> 'device_type', 'app_events'
    from public.app_events a
    join public.growth_event_taxonomy t on t.source in ('app_events', 'search_events') and a.event_type = any(t.legacy_names)
    left join public.restaurants r on r.id = a.restaurant_id
   where a.event_type not in ('map_open')  -- map_open è già duplicato in analytics_events come map_view
  union all
  select s.created_at, 'search_performed', null, (select id from public.cities where slug = s.city_slug), s.session_id, s.source, null, null, null, 'search_events'
    from public.search_events s;
revoke all on public.growth_events from public, anon, authenticated;
grant select on public.growth_events to service_role;

-- ────────────────────────────────────────────────────────────────────
--  6. AGGREGATI GIORNALIERI (idempotenti: ricalcolo = delete + insert del giorno)
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.daily_platform_metrics (
  date                   date primary key,
  active_users           int not null default 0,   -- utenti registrati con attività nel giorno (user_activity_days)
  new_users              int not null default 0,   -- nuovi profili cliente
  visits                 int not null default 0,   -- visite di atterraggio (acquisition_visits, anche senza consenso)
  sessions               int not null default 0,   -- sessioni con consenso "Statistiche"
  searches               int not null default 0,
  zero_result_searches   int not null default 0,
  ai_queries             int not null default 0,
  restaurant_views       int not null default 0,
  menu_views             int not null default 0,
  intents                int not null default 0,
  reservations           int not null default 0,
  reservations_completed int not null default 0,   -- visite avvenute (status completed, data del giorno)
  orders                 int not null default 0,   -- ordini pagati nel giorno
  orders_completed       int not null default 0,
  checkouts              int not null default 0,
  payment_failures       int not null default 0,
  gmv_cents              bigint not null default 0,
  order_fees_cents       bigint not null default 0,
  subscription_revenue_cents bigint not null default 0,
  platform_revenue_cents bigint not null default 0,
  coupon_claims          int not null default 0,
  coupon_redemptions     int not null default 0,
  reviews                int not null default 0,
  referrals_qualified    int not null default 0,
  new_paid_restaurants   int not null default 0,
  paying_restaurants     int not null default 0,
  trials_active          int not null default 0,
  mrr_cents              bigint not null default 0,
  ai_cost_micros         bigint not null default 0,
  ai_errors              int not null default 0,
  computed_at            timestamptz not null default now()
);

create table if not exists public.daily_market_metrics (
  date                 date not null,
  market_id            uuid not null references public.markets(id) on delete cascade,
  restaurants_active   int not null default 0,
  restaurants_claimed  int not null default 0,
  restaurants_paying   int not null default 0,
  searches             int not null default 0,
  zero_result_searches int not null default 0,
  restaurant_views     int not null default 0,
  reservations         int not null default 0,
  orders               int not null default 0,
  gmv_cents            bigint not null default 0,
  mrr_cents            bigint not null default 0,
  visits               int not null default 0,
  computed_at          timestamptz not null default now(),
  primary key (market_id, date)
);

create table if not exists public.daily_restaurant_metrics (
  restaurant_id      uuid not null references public.restaurants(id) on delete cascade,
  date               date not null,
  impressions        int not null default 0,   -- apparizioni nei risultati di ricerca registrati (search_events.result_ids)
  views              int not null default 0,
  menu_views         int not null default 0,
  item_views         int not null default 0,
  calls              int not null default 0,
  whatsapp           int not null default 0,
  directions         int not null default 0,
  offer_views        int not null default 0,
  add_to_cart        int not null default 0,
  favorites          int not null default 0,
  bookings           int not null default 0,
  bookings_completed int not null default 0,
  orders             int not null default 0,
  orders_completed   int not null default 0,
  orders_rejected    int not null default 0,
  revenue_cents      bigint not null default 0,  -- GMV degli ordini pagati (incasso del ristorante, non di AsiaFood)
  coupon_claims      int not null default 0,
  coupon_redemptions int not null default 0,
  reviews            int not null default 0,
  mrr_cents          bigint not null default 0,
  computed_at        timestamptz not null default now(),
  primary key (restaurant_id, date)
);
create index if not exists daily_restaurant_metrics_date_idx on public.daily_restaurant_metrics(date);

create table if not exists public.daily_acquisition_metrics (
  date          date not null,
  channel       text not null,             -- canale di business (growth_channel)
  utm_source    text not null default '',
  utm_campaign  text not null default '',
  visits        int not null default 0,
  signups       int not null default 0,
  computed_at   timestamptz not null default now(),
  primary key (date, channel, utm_source, utm_campaign)
);

create table if not exists public.daily_search_metrics (
  date           date not null,
  query_norm     text not null default '',
  city_slug      text not null default '',
  category_slug  text not null default '',
  searches       int not null default 0,
  sessions       int not null default 0,
  zero_results   int not null default 0,
  ai_searches    int not null default 0,
  computed_at    timestamptz not null default now(),
  primary key (date, query_norm, city_slug, category_slug)
);

-- Registro dei giorni calcolati: freschezza, copertura del backfill, MRR osservato vs ricostruito
create table if not exists public.growth_computed_days (
  day            date primary key,
  computed_at    timestamptz not null default now(),
  mrr_observed   boolean not null default false,   -- true: MRR fotografato quel giorno; false: ricostruito da date di inizio/fine
  duration_ms    int
);

-- Calcolo di un giorno (Europe/Rome). Idempotente: può essere rieseguito quante volte si vuole.
create or replace function public.growth_compute_day(p_day date)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_from timestamptz; v_to timestamptz;
  v_t0 timestamptz := clock_timestamp();
  v_today date := (now() at time zone 'Europe/Rome')::date;
  v_observed boolean := p_day >= (now() at time zone 'Europe/Rome')::date - 1;
  v_rows int;
begin
  if p_day > v_today then return jsonb_build_object('skipped', 'future'); end if;
  select b.v_from, b.v_to into v_from, v_to from public.growth_day_bounds(p_day) b;

  -- 6.1 Ristoranti (tabella sparsa: solo righe con attività o MRR)
  delete from public.daily_restaurant_metrics where date = p_day;
  with scope as (select id from public.restaurants where public.growth_in_scope(is_demo)),
  ev as (select e.restaurant_id rid,
           count(*) filter (where e.event_type in ('restaurant_view', 'view')) v,
           count(*) filter (where e.event_type in ('menu_view', 'click_menu')) mv,
           count(*) filter (where e.event_type = 'menu_item_view') iv,
           count(*) filter (where e.event_type in ('phone_click', 'click_phone')) ph,
           count(*) filter (where e.event_type in ('whatsapp_click', 'click_whatsapp')) wa,
           count(*) filter (where e.event_type in ('directions_click', 'click_directions')) di,
           count(*) filter (where e.event_type in ('offer_view', 'coupon_reveal')) ov,
           count(*) filter (where e.event_type = 'add_to_cart') ac
         from public.analytics_events e where e.created_at >= v_from and e.created_at < v_to and e.restaurant_id is not null group by 1),
  imp as (select x rid, count(*) c from public.search_events s, unnest(s.result_ids) x where s.created_at >= v_from and s.created_at < v_to group by 1),
  fav as (select restaurant_id rid, count(*) c from public.favorites where created_at >= v_from and created_at < v_to group by 1),
  bk as (select restaurant_id rid, count(*) filter (where created_at >= v_from and created_at < v_to and status::text not in ('rejected')) c,
                count(*) filter (where status::text = 'completed' and reservation_date = p_day) done
           from public.reservations where (created_at >= v_from and created_at < v_to) or reservation_date = p_day group by 1),
  od as (select restaurant_id rid,
                count(*) filter (where paid_at >= v_from and paid_at < v_to and payment_status in ('paid', 'partially_refunded', 'refunded')) paid,
                count(*) filter (where completed_at >= v_from and completed_at < v_to and status = 'completed') done,
                count(*) filter (where rejected_at >= v_from and rejected_at < v_to) rej,
                coalesce(sum(round(total * 100)) filter (where paid_at >= v_from and paid_at < v_to and payment_status in ('paid', 'partially_refunded')
                                                          and status not in ('rejected', 'cancelled', 'refunded')), 0) gmv
           from public.orders where (paid_at >= v_from and paid_at < v_to) or (completed_at >= v_from and completed_at < v_to) or (rejected_at >= v_from and rejected_at < v_to)
          group by 1),
  cc as (select restaurant_id rid, count(*) filter (where claimed_at >= v_from and claimed_at < v_to) cl,
                count(*) filter (where status::text = 'redeemed' and redeemed_at >= v_from and redeemed_at < v_to) rd
           from public.coupon_claims where (claimed_at >= v_from and claimed_at < v_to) or (redeemed_at >= v_from and redeemed_at < v_to) group by 1),
  rv as (select restaurant_id rid, count(*) c from public.reviews where created_at >= v_from and created_at < v_to group by 1),
  mrr as (select s.restaurant_id rid, round(sum(public.subscription_mrr_cents(s))) c from public.subscriptions s
           where public.subscription_in_env(s) and s.paid_started_at is not null and s.paid_started_at < v_to
             and (case when v_observed then s.status in ('active', 'past_due') and public.subscription_grants_access(s)
                       else coalesce(s.ended_at, 'infinity'::timestamptz) >= v_to end)
           group by 1),
  ids as (select rid from ev union select rid from imp union select rid from fav union select rid from bk union select rid from od
          union select rid from cc union select rid from rv union select rid from mrr)
  insert into public.daily_restaurant_metrics (restaurant_id, date, impressions, views, menu_views, item_views, calls, whatsapp, directions, offer_views,
    add_to_cart, favorites, bookings, bookings_completed, orders, orders_completed, orders_rejected, revenue_cents, coupon_claims, coupon_redemptions, reviews, mrr_cents)
  select i.rid, p_day, coalesce(imp.c, 0), coalesce(ev.v, 0), coalesce(ev.mv, 0), coalesce(ev.iv, 0), coalesce(ev.ph, 0), coalesce(ev.wa, 0), coalesce(ev.di, 0),
         coalesce(ev.ov, 0), coalesce(ev.ac, 0), coalesce(fav.c, 0), coalesce(bk.c, 0), coalesce(bk.done, 0), coalesce(od.paid, 0), coalesce(od.done, 0), coalesce(od.rej, 0),
         coalesce(od.gmv, 0), coalesce(cc.cl, 0), coalesce(cc.rd, 0), coalesce(rv.c, 0), coalesce(mrr.c, 0)
    from ids i join scope sc on sc.id = i.rid
    left join ev on ev.rid = i.rid left join imp on imp.rid = i.rid left join fav on fav.rid = i.rid left join bk on bk.rid = i.rid
    left join od on od.rid = i.rid left join cc on cc.rid = i.rid left join rv on rv.rid = i.rid left join mrr on mrr.rid = i.rid;
  get diagnostics v_rows = row_count;

  -- 6.2 Ricerche (anonime)
  delete from public.daily_search_metrics where date = p_day;
  insert into public.daily_search_metrics (date, query_norm, city_slug, category_slug, searches, sessions, zero_results, ai_searches)
  select p_day, coalesce(query_norm, ''), coalesce(city_slug, ''), coalesce(category_slug, ''), count(*), count(distinct session_id),
         count(*) filter (where result_count = 0), count(*) filter (where source = 'ai')
    from public.search_events where created_at >= v_from and created_at < v_to group by 2, 3, 4;

  -- 6.3 Acquisizione (visite anonime + iscrizioni attribuite con consenso)
  delete from public.daily_acquisition_metrics where date = p_day;
  insert into public.daily_acquisition_metrics (date, channel, utm_source, utm_campaign, visits, signups)
  select p_day, ch, us, uc, sum(v), sum(s) from (
    select public.growth_channel(channel, utm_source) ch, coalesce(utm_source, '') us, coalesce(utm_campaign, '') uc, 1 v, 0 s
      from public.acquisition_visits where created_at >= v_from and created_at < v_to
    union all
    select public.growth_channel(ua.channel, ua.utm_source), coalesce(ua.utm_source, ''), coalesce(ua.utm_campaign, ''), 0, 1
      from public.user_acquisition ua join public.profiles p on p.id = ua.user_id where p.created_at >= v_from and p.created_at < v_to) x
   group by 2, 3, 4;

  -- 6.4 Mercati
  delete from public.daily_market_metrics where date = p_day;
  insert into public.daily_market_metrics (date, market_id, restaurants_active, restaurants_claimed, restaurants_paying, searches, zero_result_searches,
    restaurant_views, reservations, orders, gmv_cents, mrr_cents, visits)
  select p_day, m.id,
    (select count(*) from public.restaurants r join public.cities c on c.id = r.city_id where c.province_id = m.province_id and r.is_active and public.growth_in_scope(r.is_demo)),
    (select count(*) from public.restaurants r join public.cities c on c.id = r.city_id where c.province_id = m.province_id and r.owner_id is not null and public.growth_in_scope(r.is_demo)),
    (select count(*) from public.daily_restaurant_metrics d join public.restaurants r on r.id = d.restaurant_id join public.cities c on c.id = r.city_id
      where d.date = p_day and d.mrr_cents > 0 and c.province_id = m.province_id),
    (select count(*) from public.search_events s where s.market_id = m.id and s.created_at >= v_from and s.created_at < v_to),
    (select count(*) from public.search_events s where s.market_id = m.id and s.result_count = 0 and s.created_at >= v_from and s.created_at < v_to),
    coalesce(sum(d.views), 0), coalesce(sum(d.bookings), 0), coalesce(sum(d.orders), 0), coalesce(sum(d.revenue_cents), 0), coalesce(sum(d.mrr_cents), 0),
    (select count(*) from public.acquisition_visits v where v.market_id = m.id and v.created_at >= v_from and v.created_at < v_to)
    from public.markets m
    left join public.daily_restaurant_metrics d on d.date = p_day and d.restaurant_id in (
      select r.id from public.restaurants r join public.cities c on c.id = r.city_id where c.province_id = m.province_id)
   group by m.id, m.province_id;

  -- 6.5 Piattaforma
  delete from public.daily_platform_metrics where date = p_day;
  insert into public.daily_platform_metrics (date, active_users, new_users, visits, sessions, searches, zero_result_searches, ai_queries, restaurant_views, menu_views,
    intents, reservations, reservations_completed, orders, orders_completed, checkouts, payment_failures, gmv_cents, order_fees_cents, subscription_revenue_cents,
    platform_revenue_cents, coupon_claims, coupon_redemptions, reviews, referrals_qualified, new_paid_restaurants, paying_restaurants, trials_active, mrr_cents,
    ai_cost_micros, ai_errors)
  select p_day,
    (select count(*) from public.user_activity_days a join public.profiles p on p.id = a.user_id where a.day = p_day and p.role::text <> 'admin'),
    (select count(*) from public.profiles where created_at >= v_from and created_at < v_to and role::text = 'customer'),
    (select count(*) from public.acquisition_visits where created_at >= v_from and created_at < v_to),
    (select count(distinct sid) from (select session_id sid from public.analytics_events where created_at >= v_from and created_at < v_to and session_id is not null
                                      union all select session_id from public.app_events where created_at >= v_from and created_at < v_to and session_id is not null) s),
    (select count(*) from public.search_events where created_at >= v_from and created_at < v_to and source <> 'ai')
      + (select count(*) from public.app_events where created_at >= v_from and created_at < v_to and event_type in ('search', 'near_me_search', 'map_area_search')),
    (select count(*) from public.search_events where created_at >= v_from and created_at < v_to and result_count = 0),
    (select count(*) from public.ai_usage where created_at >= v_from and created_at < v_to and status in ('ok', 'fallback', 'cached')),
    coalesce((select sum(views) from public.daily_restaurant_metrics where date = p_day), 0),
    coalesce((select sum(menu_views + item_views) from public.daily_restaurant_metrics where date = p_day), 0),
    coalesce((select sum(calls + whatsapp + directions + add_to_cart + favorites + item_views) from public.daily_restaurant_metrics where date = p_day), 0)
      + (select count(*) from public.analytics_events e join public.restaurants r on r.id = e.restaurant_id
          where e.created_at >= v_from and e.created_at < v_to and e.event_type in ('reservation_start', 'click_reservation') and public.growth_in_scope(r.is_demo)),
    coalesce((select sum(bookings) from public.daily_restaurant_metrics where date = p_day), 0),
    coalesce((select sum(bookings_completed) from public.daily_restaurant_metrics where date = p_day), 0),
    coalesce((select sum(orders) from public.daily_restaurant_metrics where date = p_day), 0),
    coalesce((select sum(orders_completed) from public.daily_restaurant_metrics where date = p_day), 0),
    (select count(*) from public.analytics_events where created_at >= v_from and created_at < v_to and event_type = 'checkout_started'),
    (select count(*) from public.analytics_events where created_at >= v_from and created_at < v_to and event_type = 'payment_failed'),
    coalesce((select sum(revenue_cents) from public.daily_restaurant_metrics where date = p_day), 0),
    (select coalesce(round(sum((o.platform_fee + o.service_fee) * 100)), 0) from public.orders o join public.restaurants r on r.id = o.restaurant_id
      where o.paid_at >= v_from and o.paid_at < v_to and o.payment_status in ('paid', 'partially_refunded') and o.status not in ('rejected', 'cancelled', 'refunded')
        and public.growth_in_scope(r.is_demo)),
    (select coalesce(sum(i.amount_paid_cents), 0) from public.billing_invoices i
      where i.status = 'paid' and i.stripe_created_at >= v_from and i.stripe_created_at < v_to
        and (public.billing_setting_text('billing_stripe_environment', null) is null or i.stripe_environment is not distinct from public.billing_setting_text('billing_stripe_environment', null))),
    0,
    coalesce((select sum(coupon_claims) from public.daily_restaurant_metrics where date = p_day), 0),
    coalesce((select sum(coupon_redemptions) from public.daily_restaurant_metrics where date = p_day), 0),
    coalesce((select sum(reviews) from public.daily_restaurant_metrics where date = p_day), 0),
    (select count(*) from public.referrals where qualified_at >= v_from and qualified_at < v_to),
    (select count(distinct s.restaurant_id) from public.subscriptions s where public.subscription_in_env(s) and s.paid_started_at >= v_from and s.paid_started_at < v_to),
    (select count(*) from public.daily_restaurant_metrics where date = p_day and mrr_cents > 0),
    (select count(*) from public.subscriptions s where public.subscription_in_env(s) and coalesce(s.trial_start, s.created_at) < v_to
        and coalesce(s.trial_end, s.created_at) >= v_to and (s.status = 'trialing' or s.trial_end is not null) and coalesce(s.ended_at, 'infinity'::timestamptz) >= v_to),
    coalesce((select sum(mrr_cents) from public.daily_restaurant_metrics where date = p_day), 0),
    (select coalesce(round(sum(estimated_cost) * 1000000), 0) from public.ai_usage where created_at >= v_from and created_at < v_to),
    (select count(*) from public.ai_usage where created_at >= v_from and created_at < v_to and status = 'error');
  update public.daily_platform_metrics set platform_revenue_cents = order_fees_cents + subscription_revenue_cents where date = p_day;

  insert into public.growth_computed_days (day, computed_at, mrr_observed, duration_ms)
  values (p_day, now(), v_observed, extract(milliseconds from clock_timestamp() - v_t0)::int)
  -- Un giorno ricalcolato quando non è più recente ha MRR ricostruito (date di inizio/fine), non osservato
  on conflict (day) do update set computed_at = excluded.computed_at, mrr_observed = excluded.mrr_observed, duration_ms = excluded.duration_ms;
  return jsonb_build_object('day', p_day, 'restaurant_rows', v_rows, 'mrr_observed', v_observed);
end $$;

-- Backfill di un intervallo (max 400 giorni per chiamata). Solo Admin o backend.
create or replace function public.growth_backfill(p_from date, p_to date)
returns jsonb language plpgsql security definer set search_path = public as $$
declare d date; v_n int := 0;
begin
  if not public.is_admin_or_service() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p_from is null or p_to is null or p_to < p_from then raise exception 'Intervallo non valido' using errcode = '22023'; end if;
  if p_to - p_from > 400 then raise exception 'Massimo 400 giorni per esecuzione' using errcode = '22023'; end if;
  d := p_from;
  while d <= least(p_to, (now() at time zone 'Europe/Rome')::date) loop
    perform public.growth_compute_day(d);
    v_n := v_n + 1;
    d := d + 1;
  end loop;
  if public.is_admin() then perform public.audit_admin('growth_backfill', 'growth', null, jsonb_build_object('from', p_from, 'to', p_to, 'days', v_n)); end if;
  return jsonb_build_object('days', v_n, 'from', p_from, 'to', p_to);
end $$;

-- Aggiornamento "quasi realtime" di oggi (usato dalle dashboard se il dato ha più di N minuti)
create or replace function public.growth_refresh_today(p_max_age_minutes int default 5)
returns timestamptz language plpgsql security definer set search_path = public as $$
declare v_today date := (now() at time zone 'Europe/Rome')::date; v_at timestamptz;
begin
  select computed_at into v_at from public.growth_computed_days where day = v_today;
  if v_at is null or v_at < now() - make_interval(mins => greatest(p_max_age_minutes, 0)) then
    perform public.growth_compute_day(v_today);
    v_at := now();
  end if;
  return v_at;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  7. OBLIO: dopo l'anonimizzazione dell'account, le tabelle Growth non conservano legami personali
--     (gli aggregati sono già anonimi; bozze e assegnazioni legate all'utente vengono rimosse/scollegate).
-- ────────────────────────────────────────────────────────────────────
-- (le tabelle con user_id sono definite nella parte 2; il trigger è creato lì)

-- ────────────────────────────────────────────────────────────────────
--  8. RLS: tabelle grezze e aggregate → solo Admin (lettura). Scrittura solo tramite funzioni.
-- ────────────────────────────────────────────────────────────────────
alter table public.growth_event_taxonomy     enable row level security;
alter table public.search_events             enable row level security;
alter table public.daily_platform_metrics    enable row level security;
alter table public.daily_market_metrics      enable row level security;
alter table public.daily_restaurant_metrics  enable row level security;
alter table public.daily_acquisition_metrics enable row level security;
alter table public.daily_search_metrics      enable row level security;
alter table public.growth_computed_days      enable row level security;

create policy "taxonomy_admin_read" on public.growth_event_taxonomy for select to authenticated using (public.is_admin());
create policy "search_events_admin_read" on public.search_events for select to authenticated using (public.is_admin());
create policy "dpm_admin_read" on public.daily_platform_metrics for select to authenticated using (public.is_admin());
create policy "dmm_admin_read" on public.daily_market_metrics for select to authenticated using (public.is_admin());
-- Il ristoratore legge SOLO le righe dei propri locali (dashboard "AsiaFood Performance")
create policy "drm_admin_or_owner_read" on public.daily_restaurant_metrics for select to authenticated using (public.is_admin() or public.can_manage_restaurant(restaurant_id));
create policy "dam_admin_read" on public.daily_acquisition_metrics for select to authenticated using (public.is_admin());
create policy "dsm_admin_read" on public.daily_search_metrics for select to authenticated using (public.is_admin());
create policy "gcd_admin_read" on public.growth_computed_days for select to authenticated using (public.is_admin());

-- Funzioni: log_search pubblica (rate limit), il resto interno/Admin
revoke execute on function public.log_search(jsonb) from public;
grant execute on function public.log_search(jsonb) to anon, authenticated;
revoke execute on function public.growth_search_insert(jsonb, text), public.growth_compute_day(date), public.growth_refresh_today(int) from public, anon, authenticated;
grant execute on function public.growth_search_insert(jsonb, text), public.growth_compute_day(date), public.growth_refresh_today(int) to service_role;
revoke execute on function public.growth_backfill(date, date) from public, anon;
grant execute on function public.growth_backfill(date, date) to authenticated, service_role;
