-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0018 · Fase 8: valori enum per il marketplace ordini
--  (in un file separato: i nuovi valori enum non sono utilizzabili nella
--   stessa transazione in cui vengono aggiunti)
-- ════════════════════════════════════════════════════════════════════

-- Funnel ordini (eventi anonimi, senza dati personali)
alter type public.analytics_event_type add value if not exists 'menu_item_view';
alter type public.analytics_event_type add value if not exists 'add_to_cart';
alter type public.analytics_event_type add value if not exists 'remove_from_cart';
alter type public.analytics_event_type add value if not exists 'cart_view';
alter type public.analytics_event_type add value if not exists 'checkout_started';
alter type public.analytics_event_type add value if not exists 'address_added';
alter type public.analytics_event_type add value if not exists 'coupon_applied';
alter type public.analytics_event_type add value if not exists 'payment_started';
alter type public.analytics_event_type add value if not exists 'reorder';
-- Conversioni registrate SOLO dal server
alter type public.analytics_event_type add value if not exists 'payment_success';
alter type public.analytics_event_type add value if not exists 'payment_failed';
alter type public.analytics_event_type add value if not exists 'order_created';
alter type public.analytics_event_type add value if not exists 'order_accepted';
alter type public.analytics_event_type add value if not exists 'order_completed';
alter type public.analytics_event_type add value if not exists 'order_cancelled';
alter type public.analytics_event_type add value if not exists 'abandoned_cart';
