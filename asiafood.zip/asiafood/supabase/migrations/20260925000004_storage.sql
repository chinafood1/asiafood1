-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0004 · Supabase Storage
--  Bucket pubblico "restaurant-media" con struttura:
--    <restaurant_id>/logo/…   <restaurant_id>/cover/…   <restaurant_id>/gallery/…
--    <restaurant_id>/menu/…
--  Scrittura consentita solo a proprietario del locale e Admin.
-- ════════════════════════════════════════════════════════════════════

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('restaurant-media', 'restaurant-media', true, 5242880,
        array['image/jpeg', 'image/png', 'image/webp', 'image/avif'])
on conflict (id) do nothing;

-- Estrae in modo sicuro l'UUID del ristorante dal primo segmento del path
create or replace function public.storage_restaurant_id(p_name text)
returns uuid language plpgsql immutable as $$
begin
  return (storage.foldername(p_name))[1]::uuid;
exception when others then
  return null;
end $$;

create policy "restaurant_media_public_read" on storage.objects
  for select using (bucket_id = 'restaurant-media');

create policy "restaurant_media_insert" on storage.objects
  for insert to authenticated with check (
    bucket_id = 'restaurant-media'
    and public.can_manage_restaurant(public.storage_restaurant_id(name))
  );

create policy "restaurant_media_update" on storage.objects
  for update to authenticated using (
    bucket_id = 'restaurant-media'
    and public.can_manage_restaurant(public.storage_restaurant_id(name))
  );

create policy "restaurant_media_delete" on storage.objects
  for delete to authenticated using (
    bucket_id = 'restaurant-media'
    and public.can_manage_restaurant(public.storage_restaurant_id(name))
  );
