-- ════════════════════════════════════════════════════════════════════
--  FASE 6 · Enum dell'AI Assistant (file separato: i nuovi valori devono
--  essere committati prima dell'uso nella migrazione 0016)
-- ════════════════════════════════════════════════════════════════════

-- Eventi analytics dell'assistente (conversioni misurabili)
alter type public.analytics_event_type add value if not exists 'ai_chat_open';
alter type public.analytics_event_type add value if not exists 'ai_message_sent';
alter type public.analytics_event_type add value if not exists 'ai_result_click';
alter type public.analytics_event_type add value if not exists 'ai_map_open';
alter type public.analytics_event_type add value if not exists 'ai_reservation_click';
alter type public.analytics_event_type add value if not exists 'ai_offer_click';
alter type public.analytics_event_type add value if not exists 'ai_no_results';

-- Attribuzione: prenotazione nata da un suggerimento dell'assistente
alter type public.reservation_source add value if not exists 'ai';
