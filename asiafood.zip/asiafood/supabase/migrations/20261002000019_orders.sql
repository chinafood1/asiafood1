-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0019 · FASE 8: marketplace ordini (takeaway e delivery)
--
--  Principi:
--   • il browser non è mai autorevole: prezzi, varianti, extra, sconti,
--     coupon, costi di consegna, commissioni, totale e stato del pagamento
--     sono calcolati/confermati SOLO qui (RPC) o dal backend con service_role;
--   • un carrello = un ristorante; un ordine = un ristorante;
--   • pagamento confermato solo dal webhook Stripe (mai dal client);
--   • snapshot di prezzi, nomi e commissioni: lo storico non cambia se il
--     menu o le commissioni cambiano;
--   • dati personali (nome, telefono, indirizzo) visibili al ristorante solo
--     quanto serve per evadere l'ordine; mai negli aggregati;
--   • nessuna cancellazione fisica degli ordini: solo stati.
-- ════════════════════════════════════════════════════════════════════

-- ════════════════════════════════════════════════════════════════════
--  1. IMPOSTAZIONI DI PIATTAFORMA
-- ════════════════════════════════════════════════════════════════════
insert into public.platform_settings (key, value, description) values
  ('orders_enabled', 'true', 'Ordini online (takeaway/delivery) attivi sulla piattaforma'),
  ('platform_commission_percent', '10', 'Commissione AsiaFood sugli ordini (%), salvo override per ristorante'),
  ('platform_commission_fixed', '0', 'Commissione fissa per ordine (€), salvo override per ristorante'),
  ('service_fee_enabled', 'false', 'Costo di servizio a carico del cliente (mostrato sempre prima del pagamento)'),
  ('service_fee_amount', '0.99', 'Importo del costo di servizio cliente (€)'),
  ('allow_coupon_stacking', 'false', 'Consente di cumulare più codici sconto nello stesso ordine'),
  ('marketplace_platform_collection_test', 'false', 'Solo ambiente TEST: incasso sulla piattaforma senza Stripe Connect (liquidazione manuale)'),
  ('order_unpaid_expiry_minutes', '30', 'Minuti dopo i quali un ordine non pagato viene annullato'),
  ('order_accept_timeout_minutes', '20', 'Minuti entro cui il ristorante deve accettare (0 = nessun limite); poi annullamento e rimborso'),
  ('order_auto_refund_on_reject', 'true', 'Rimborso automatico completo se il ristorante rifiuta un ordine pagato'),
  ('order_restaurant_refund_days', '14', 'Giorni entro cui il ristorante può rimborsare un ordine'),
  ('order_max_items', '50', 'Numero massimo di righe per ordine'),
  ('order_abandoned_cart_hours', '2', 'Ore di inattività dopo cui un carrello salvato è considerato abbandonato (solo statistica, nessun reminder)')
on conflict (key) do nothing;

create or replace function public.billing_setting_num(p_key text, p_default numeric)
returns numeric language sql stable security definer set search_path = public as $$
  select coalesce((select case when jsonb_typeof(value) = 'number' then (value #>> '{}')::numeric end
                   from public.platform_settings where key = p_key), p_default);
$$;

-- Punti per ordine completato (regola modificabile dall'Admin, mai conversione in denaro)
insert into public.loyalty_rules (event_key, points, daily_limit, monthly_limit, description) values
  ('order_completed', 50, 3, 20, 'Ordine takeaway o delivery completato')
on conflict (event_key) do nothing;
alter table public.loyalty_transactions drop constraint if exists loyalty_transactions_source_type_check;
alter table public.loyalty_transactions add constraint loyalty_transactions_source_type_check check (source_type in (
  'reservation', 'review', 'coupon', 'referral', 'campaign', 'admin', 'profile', 'reward', 'achievement', 'order', 'other'));

-- Email transazionali degli ordini (coda esistente; l'ordine non fallisce mai se il provider fallisce)
alter table public.email_outbox drop constraint if exists email_outbox_event_type_check;
alter table public.email_outbox add constraint email_outbox_event_type_check check (event_type in (
  'reservation_created', 'reservation_confirmed', 'reservation_rejected', 'reservation_cancelled', 'reservation_new_for_restaurant',
  'billing_welcome', 'billing_trial_started', 'billing_trial_ending', 'billing_subscription_activated',
  'billing_payment_succeeded', 'billing_payment_failed', 'billing_subscription_cancelled',
  'reservation_reminder', 'review_request', 'referral_completed', 'reward_redeemed', 'coupon_expiring', 'marketing_campaign',
  'order_received', 'order_payment_confirmed', 'order_accepted', 'order_rejected', 'order_ready', 'order_cancelled',
  'order_refunded', 'order_new_for_restaurant'
));
alter table public.email_outbox add column if not exists order_id uuid;

-- ════════════════════════════════════════════════════════════════════
--  2. MENU: disponibilità rapida e gruppi di opzioni
-- ════════════════════════════════════════════════════════════════════
-- "Non disponibile oggi": torna disponibile automaticamente alla data indicata
alter table public.menu_items add column if not exists unavailable_until timestamptz;

create or replace function public.menu_item_in_stock(it public.menu_items, p_at timestamptz default now())
returns boolean language sql stable as $$
  select it.is_available and (it.unavailable_until is null or it.unavailable_until <= p_at);
$$;

-- Scelte strutturate (es. "Scegli la base", "Scegli la proteina"): scalabile senza diventare un configuratore
create table public.menu_option_groups (
  id            uuid primary key default gen_random_uuid(),
  menu_item_id  uuid not null references public.menu_items(id) on delete cascade,
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name          text not null check (char_length(name) between 1 and 60),
  min_select    smallint not null default 0 check (min_select between 0 and 20),
  max_select    smallint not null default 1 check (max_select between 1 and 20),
  required      boolean not null default false,
  display_order int not null default 0,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  check (max_select >= min_select)
);
create index menu_option_groups_item_idx on public.menu_option_groups(menu_item_id, display_order);
create trigger menu_option_groups_updated_at before update on public.menu_option_groups for each row execute function public.set_updated_at();
create trigger menu_option_groups_fill_restaurant before insert or update of menu_item_id on public.menu_option_groups
  for each row execute function public.menu_item_children_fill_restaurant();

create table public.menu_options (
  id              uuid primary key default gen_random_uuid(),
  option_group_id uuid not null references public.menu_option_groups(id) on delete cascade,
  restaurant_id   uuid not null references public.restaurants(id) on delete cascade,
  name            text not null check (char_length(name) between 1 and 60),
  price           numeric(8,2) not null default 0 check (price >= 0 and price <= 500),
  is_available    boolean not null default true,
  display_order   int not null default 0,
  created_at      timestamptz not null default now()
);
create index menu_options_group_idx on public.menu_options(option_group_id, display_order);
create or replace function public.menu_options_fill_restaurant()
returns trigger language plpgsql as $$
begin
  select g.restaurant_id into new.restaurant_id from public.menu_option_groups g where g.id = new.option_group_id;
  return new;
end $$;
create trigger menu_options_fill_restaurant before insert or update of option_group_id on public.menu_options
  for each row execute function public.menu_options_fill_restaurant();

-- ════════════════════════════════════════════════════════════════════
--  3. CONFIGURAZIONE ORDINI DEL RISTORANTE
-- ════════════════════════════════════════════════════════════════════
create table public.restaurant_order_settings (
  id                          uuid primary key default gen_random_uuid(),
  restaurant_id               uuid not null unique references public.restaurants(id) on delete cascade,
  orders_enabled              boolean not null default false,
  takeaway_enabled            boolean not null default true,
  delivery_enabled            boolean not null default false,
  minimum_order_amount        numeric(8,2) not null default 0 check (minimum_order_amount >= 0 and minimum_order_amount <= 1000),
  takeaway_minimum_order      numeric(8,2) check (takeaway_minimum_order is null or takeaway_minimum_order between 0 and 1000),
  delivery_minimum_order      numeric(8,2) check (delivery_minimum_order is null or delivery_minimum_order between 0 and 1000),
  default_preparation_minutes smallint not null default 20 check (default_preparation_minutes between 5 and 240),
  busy_extra_minutes          smallint not null default 0 check (busy_extra_minutes between 0 and 180),
  delivery_estimated_minutes  smallint not null default 25 check (delivery_estimated_minutes between 5 and 180),
  slot_interval_minutes       smallint not null default 15 check (slot_interval_minutes in (5, 10, 15, 20, 30, 60)),
  max_orders_per_slot         int check (max_orders_per_slot is null or max_orders_per_slot between 1 and 500),
  accept_orders_automatically boolean not null default false,
  allow_scheduled_orders      boolean not null default true,
  max_advance_days            smallint not null default 2 check (max_advance_days between 0 and 14),
  delivery_radius_km          numeric(5,2) check (delivery_radius_km is null or delivery_radius_km between 0.5 and 50),
  free_delivery_threshold     numeric(8,2) check (free_delivery_threshold is null or free_delivery_threshold between 0 and 1000),
  delivery_fee_type           text not null default 'fixed' check (delivery_fee_type in ('fixed', 'distance', 'zone', 'free')),
  delivery_fee                numeric(8,2) not null default 0 check (delivery_fee between 0 and 100),
  delivery_provider_type      text not null default 'restaurant' check (delivery_provider_type in ('restaurant', 'platform_future', 'external_future')),
  service_fee_enabled         boolean not null default true,
  orders_paused_until         timestamptz,
  delivery_paused_until       timestamptz,
  takeaway_paused_until       timestamptz,
  pickup_instructions         text check (char_length(pickup_instructions) <= 300),
  created_at                  timestamptz not null default now(),
  updated_at                  timestamptz not null default now()
);
create trigger restaurant_order_settings_updated_at before update on public.restaurant_order_settings
  for each row execute function public.set_updated_at();

-- Zone di consegna: raggio (0–R km) o fascia di distanza (min–max km). Poligoni predisposti (non usati nell'MVP).
create table public.delivery_zones (
  id                         uuid primary key default gen_random_uuid(),
  restaurant_id              uuid not null references public.restaurants(id) on delete cascade,
  name                       text not null check (char_length(name) between 1 and 60),
  zone_type                  text not null default 'distance' check (zone_type in ('radius', 'distance', 'polygon')),
  radius_km                  numeric(5,2) check (radius_km is null or radius_km between 0.1 and 50),
  min_distance_km            numeric(5,2) check (min_distance_km is null or min_distance_km between 0 and 50),
  max_distance_km            numeric(5,2) check (max_distance_km is null or max_distance_km between 0.1 and 50),
  polygon                    jsonb,
  delivery_fee               numeric(8,2) not null default 0 check (delivery_fee between 0 and 100),
  minimum_order              numeric(8,2) not null default 0 check (minimum_order between 0 and 1000),
  estimated_delivery_minutes smallint not null default 30 check (estimated_delivery_minutes between 5 and 180),
  is_active                  boolean not null default true,
  created_at                 timestamptz not null default now(),
  updated_at                 timestamptz not null default now(),
  check (zone_type <> 'radius' or radius_km is not null),
  check (zone_type <> 'distance' or (max_distance_km is not null and coalesce(min_distance_km, 0) < max_distance_km)),
  check (zone_type <> 'polygon' or polygon is not null)
);
create index delivery_zones_restaurant_idx on public.delivery_zones(restaurant_id) where is_active;
create trigger delivery_zones_updated_at before update on public.delivery_zones for each row execute function public.set_updated_at();

-- Stripe Connect (Express): i dati bancari li raccoglie Stripe, mai AsiaFood
create table public.restaurant_payout_accounts (
  id                   uuid primary key default gen_random_uuid(),
  restaurant_id        uuid not null references public.restaurants(id) on delete cascade,
  provider             text not null default 'stripe_connect' check (provider in ('stripe_connect')),
  stripe_account_id    text not null unique check (stripe_account_id ~ '^acct_[A-Za-z0-9]+$'),
  stripe_environment   text not null default 'test' check (stripe_environment in ('test', 'live')),
  onboarding_completed boolean not null default false,
  charges_enabled      boolean not null default false,
  payouts_enabled      boolean not null default false,
  details_submitted    boolean not null default false,
  requirements_due     text[] not null default '{}',
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  unique (restaurant_id, stripe_environment)
);
create trigger restaurant_payout_accounts_updated_at before update on public.restaurant_payout_accounts
  for each row execute function public.set_updated_at();

-- Commissioni per ristorante (storico con decorrenza; gli ordini salvano uno snapshot)
create table public.restaurant_commission_settings (
  id             uuid primary key default gen_random_uuid(),
  restaurant_id  uuid not null references public.restaurants(id) on delete cascade,
  percentage_fee numeric(5,2) not null check (percentage_fee between 0 and 50),
  fixed_fee      numeric(8,2) not null default 0 check (fixed_fee between 0 and 20),
  effective_from timestamptz not null default now(),
  note           text check (char_length(note) <= 200),
  created_by     uuid references public.profiles(id) on delete set null,
  created_at     timestamptz not null default now()
);
create index restaurant_commission_settings_idx on public.restaurant_commission_settings(restaurant_id, effective_from desc);

-- ════════════════════════════════════════════════════════════════════
--  4. INDIRIZZI E CARRELLO
-- ════════════════════════════════════════════════════════════════════
create table public.customer_addresses (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references public.profiles(id) on delete cascade,
  label          text check (char_length(label) <= 40),
  recipient_name text not null check (char_length(trim(recipient_name)) between 2 and 80),
  phone          text not null check (phone ~ '^\+?[0-9 ().-]{6,20}$'),
  address_line_1 text not null check (char_length(trim(address_line_1)) between 3 and 120),
  address_line_2 text check (char_length(address_line_2) <= 120),
  city           text not null check (char_length(trim(city)) between 2 and 80),
  province       text check (char_length(province) <= 40),
  postal_code    text not null check (postal_code ~ '^[0-9]{5}$'),
  country        text not null default 'IT' check (country ~ '^[A-Z]{2}$'),
  -- Coordinate SOLO se l'indirizzo è stato validato (geocoding o posizione autorizzata)
  latitude       double precision check (latitude is null or latitude between -90 and 90),
  longitude      double precision check (longitude is null or longitude between -180 and 180),
  geocode_source text check (geocode_source in ('geocoder', 'device', 'demo')),
  delivery_notes text check (char_length(delivery_notes) <= 200),
  is_default     boolean not null default false,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  check ((latitude is null) = (longitude is null))
);
create index customer_addresses_user_idx on public.customer_addresses(user_id);
create unique index customer_addresses_one_default on public.customer_addresses(user_id) where is_default;
create trigger customer_addresses_updated_at before update on public.customer_addresses for each row execute function public.set_updated_at();
create or replace function public.customer_addresses_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' and (select count(*) from public.customer_addresses where user_id = new.user_id) >= 10 then
    raise exception 'Puoi salvare al massimo 10 indirizzi.';
  end if;
  if new.is_default then
    update public.customer_addresses set is_default = false where user_id = new.user_id and id <> new.id and is_default;
  end if;
  return new;
end $$;
create trigger customer_addresses_guard before insert or update on public.customer_addresses
  for each row execute function public.customer_addresses_guard();

-- Carrello salvato (utenti registrati, sincronizzazione tra dispositivi). I prezzi sono solo indicativi:
-- al checkout il server ricalcola tutto.
create table public.carts (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid references public.profiles(id) on delete cascade,
  session_id    text check (char_length(session_id) <= 64),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  status        text not null default 'active' check (status in ('active', 'converted', 'abandoned', 'cleared')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  check (user_id is not null or session_id is not null)
);
create unique index carts_one_active_user on public.carts(user_id) where status = 'active' and user_id is not null;
create trigger carts_updated_at before update on public.carts for each row execute function public.set_updated_at();

create table public.cart_items (
  id                  uuid primary key default gen_random_uuid(),
  cart_id             uuid not null references public.carts(id) on delete cascade,
  menu_item_id        uuid not null references public.menu_items(id) on delete cascade,
  variant_id          uuid references public.menu_item_variants(id) on delete set null,
  option_ids          uuid[] not null default '{}',
  quantity            smallint not null check (quantity between 1 and 20),
  unit_price_snapshot numeric(8,2) check (unit_price_snapshot >= 0),
  notes               text check (char_length(notes) <= 200),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index cart_items_cart_idx on public.cart_items(cart_id);
create trigger cart_items_updated_at before update on public.cart_items for each row execute function public.set_updated_at();

create table public.cart_item_addons (
  id             uuid primary key default gen_random_uuid(),
  cart_item_id   uuid not null references public.cart_items(id) on delete cascade,
  addon_id       uuid not null references public.menu_item_addons(id) on delete cascade,
  quantity       smallint not null default 1 check (quantity between 1 and 5),
  price_snapshot numeric(8,2) check (price_snapshot >= 0)
);
create index cart_item_addons_item_idx on public.cart_item_addons(cart_item_id);

-- ════════════════════════════════════════════════════════════════════
--  5. ORDINI
-- ════════════════════════════════════════════════════════════════════
create table public.orders (
  id                         uuid primary key default gen_random_uuid(),
  order_number               text not null unique check (order_number ~ '^AF-[0-9]{6}-[A-Z0-9]{4}$'),
  restaurant_id              uuid not null references public.restaurants(id) on delete restrict,
  user_id                    uuid references public.profiles(id) on delete set null,
  session_id                 text check (char_length(session_id) <= 64),
  order_type                 text not null check (order_type in ('takeaway', 'delivery')),
  -- Stato del ciclo di vita (separato da pagamento ed evasione)
  status                     text not null default 'pending_payment' check (status in (
    'pending_payment', 'payment_authorized', 'pending_restaurant', 'accepted', 'preparing', 'ready',
    'out_for_delivery', 'completed', 'rejected', 'cancelled', 'refunded', 'partially_refunded')),
  payment_status             text not null default 'unpaid' check (payment_status in (
    'unpaid', 'pending', 'authorized', 'paid', 'failed', 'refunded', 'partially_refunded')),
  fulfillment_status         text not null default 'unfulfilled' check (fulfillment_status in (
    'unfulfilled', 'preparing', 'ready', 'picked_up', 'out_for_delivery', 'delivered', 'cancelled')),
  customer_name              text not null check (char_length(trim(customer_name)) between 2 and 80),
  customer_email             text not null check (customer_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' and char_length(customer_email) <= 254),
  customer_phone             text not null check (customer_phone ~ '^\+?[0-9 ().-]{6,20}$'),
  delivery_address_id        uuid references public.customer_addresses(id) on delete set null,
  delivery_address_snapshot  jsonb,
  delivery_distance_km       numeric(6,2),
  delivery_zone_id           uuid references public.delivery_zones(id) on delete set null,
  delivery_provider_type     text not null default 'restaurant',
  subtotal                   numeric(10,2) not null check (subtotal >= 0),
  discount_total             numeric(10,2) not null default 0 check (discount_total >= 0),
  coupon_discount            numeric(10,2) not null default 0 check (coupon_discount >= 0),
  loyalty_discount           numeric(10,2) not null default 0 check (loyalty_discount >= 0),
  delivery_fee               numeric(10,2) not null default 0 check (delivery_fee >= 0),
  service_fee                numeric(10,2) not null default 0 check (service_fee >= 0),
  tip_amount                 numeric(10,2) not null default 0 check (tip_amount = 0),      -- mance predisposte, non attive
  tax_total                  numeric(10,2),                                                   -- solo con configurazione fiscale affidabile
  total                      numeric(10,2) not null check (total >= 0),
  currency                   char(3) not null default 'EUR',
  coupon_id                  uuid references public.coupons(id) on delete set null,
  coupon_code                text,
  coupon_claim_id            uuid references public.coupon_claims(id) on delete set null,
  reward_redemption_id       uuid references public.reward_redemptions(id) on delete set null,
  -- Commissioni (snapshot al momento dell'ordine: mai ricalcolate con tariffe future)
  commission_percent         numeric(5,2) not null default 0,
  commission_fixed           numeric(8,2) not null default 0,
  platform_fee               numeric(10,2) not null default 0,
  restaurant_gross           numeric(10,2) not null default 0,
  restaurant_net_estimated   numeric(10,2) not null default 0,
  payment_processing_fee     numeric(10,2),
  -- Pagamento
  payment_mode               text not null default 'connect' check (payment_mode in ('connect', 'platform_test', 'demo')),
  payout_destination         text,
  stripe_environment         text check (stripe_environment in ('test', 'live')),
  stripe_payment_intent_id   text unique,
  stripe_charge_id           text,
  amount_paid                numeric(10,2) not null default 0,
  amount_refunded            numeric(10,2) not null default 0,
  payment_failures           smallint not null default 0,
  paid_at                    timestamptz,
  -- Tempi
  scheduled_for              timestamptz,
  slot_at                    timestamptz,
  preparation_minutes        smallint,
  estimated_ready_at         timestamptz,
  estimated_delivery_at      timestamptz,
  customer_notes             text check (char_length(customer_notes) <= 300),
  restaurant_notes           text check (char_length(restaurant_notes) <= 300),
  internal_notes             text check (char_length(internal_notes) <= 1000),
  reject_reason              text,
  cancel_reason              text,
  risk_flags                 text[] not null default '{}',
  source                     text not null default 'web' check (source in ('web', 'app', 'ai', 'reorder')),
  created_at                 timestamptz not null default now(),
  accepted_at                timestamptz,
  rejected_at                timestamptz,
  preparing_at               timestamptz,
  ready_at                   timestamptz,
  picked_up_at               timestamptz,
  out_for_delivery_at        timestamptz,
  completed_at               timestamptz,
  cancelled_at               timestamptz,
  updated_at                 timestamptz not null default now(),
  check (order_type <> 'delivery' or delivery_address_snapshot is not null),
  check (amount_refunded <= amount_paid)
);
create index orders_restaurant_idx on public.orders(restaurant_id, created_at desc);
create index orders_restaurant_status_idx on public.orders(restaurant_id, status);
create index orders_user_idx on public.orders(user_id, created_at desc) where user_id is not null;
create index orders_status_idx on public.orders(status, created_at);
create index orders_slot_idx on public.orders(restaurant_id, slot_at) where slot_at is not null;
create index orders_created_idx on public.orders(created_at desc);
create trigger orders_updated_at before update on public.orders for each row execute function public.set_updated_at();

-- Segreti dell'ordine (nessun accesso dal client): hash del token di accesso ospite e chiave di idempotenza
create table public.order_secrets (
  order_id          uuid primary key references public.orders(id) on delete cascade,
  access_token_hash text not null,
  idempotency_key   text unique check (char_length(idempotency_key) <= 80),
  ip_hash           text check (char_length(ip_hash) <= 80),
  created_at        timestamptz not null default now()
);

create table public.order_items (
  id                      uuid primary key default gen_random_uuid(),
  order_id                uuid not null references public.orders(id) on delete cascade,
  menu_item_id            uuid references public.menu_items(id) on delete set null,
  menu_item_name_snapshot text not null,
  variant_id              uuid,
  variant_name_snapshot   text,
  quantity                smallint not null check (quantity between 1 and 20),
  unit_price              numeric(10,2) not null check (unit_price >= 0),
  addons_total            numeric(10,2) not null default 0 check (addons_total >= 0),
  line_total              numeric(10,2) not null check (line_total >= 0),
  notes                   text check (char_length(notes) <= 200),
  created_at              timestamptz not null default now()
);
create index order_items_order_idx on public.order_items(order_id);
create index order_items_menu_idx on public.order_items(menu_item_id);

create table public.order_item_options (
  id             uuid primary key default gen_random_uuid(),
  order_item_id  uuid not null references public.order_items(id) on delete cascade,
  kind           text not null default 'addon' check (kind in ('addon', 'option')),
  group_name     text,
  name_snapshot  text not null,
  price_snapshot numeric(10,2) not null default 0,
  quantity       smallint not null default 1 check (quantity between 1 and 5)
);
create index order_item_options_item_idx on public.order_item_options(order_item_id);

-- Registro eventi (timeline e audit)
create table public.order_events (
  id         bigint generated always as identity primary key,
  order_id   uuid not null references public.orders(id) on delete cascade,
  event_type text not null check (char_length(event_type) <= 40),
  actor_type text not null check (actor_type in ('customer', 'restaurant', 'admin', 'system', 'stripe')),
  actor_id   uuid,
  metadata   jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index order_events_order_idx on public.order_events(order_id, created_at);

create table public.order_refunds (
  id               uuid primary key default gen_random_uuid(),
  order_id         uuid not null references public.orders(id) on delete restrict,
  amount           numeric(10,2) not null check (amount > 0),
  reason           text not null check (char_length(reason) between 2 and 300),
  status           text not null default 'pending' check (status in ('pending', 'processing', 'succeeded', 'failed', 'cancelled')),
  stripe_refund_id text unique,
  error_message    text check (char_length(error_message) <= 500),
  requested_by     uuid references public.profiles(id) on delete set null,
  requested_by_type text not null default 'system' check (requested_by_type in ('customer', 'restaurant', 'admin', 'system')),
  created_at       timestamptz not null default now(),
  processed_at     timestamptz
);
create index order_refunds_order_idx on public.order_refunds(order_id);
create index order_refunds_pending_idx on public.order_refunds(status, created_at) where status in ('pending', 'processing');

create table public.order_issues (
  id          uuid primary key default gen_random_uuid(),
  order_id    uuid not null references public.orders(id) on delete cascade,
  user_id     uuid references public.profiles(id) on delete set null,
  issue_type  text not null check (issue_type in ('not_arrived', 'wrong_order', 'missing_item', 'late', 'payment', 'quality', 'other')),
  description text not null check (char_length(trim(description)) between 5 and 1000),
  status      text not null default 'open' check (status in ('open', 'in_progress', 'resolved', 'rejected')),
  resolution  text check (char_length(resolution) <= 1000),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index order_issues_order_idx on public.order_issues(order_id);
create index order_issues_open_idx on public.order_issues(status, created_at) where status in ('open', 'in_progress');
create trigger order_issues_updated_at before update on public.order_issues for each row execute function public.set_updated_at();

-- Canale leggero per il tempo reale (nessun dato personale): cliente e ristorante ricevono solo "è cambiato qualcosa"
create table public.order_realtime (
  order_id      uuid primary key references public.orders(id) on delete cascade,
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id       uuid,
  status        text not null,
  updated_at    timestamptz not null default now()
);
create index order_realtime_restaurant_idx on public.order_realtime(restaurant_id);

-- Limiti di frequenza per endpoint ordini (chiavi anonimizzate: hash di utente/sessione/IP)
create table public.order_rate_limits (
  id         bigint generated always as identity primary key,
  key_hash   text not null check (char_length(key_hash) <= 80),
  action     text not null check (char_length(action) <= 40),
  created_at timestamptz not null default now()
);
create index order_rate_limits_idx on public.order_rate_limits(key_hash, action, created_at desc);

-- Tentativi di tracking falliti per numero d'ordine (anti brute-force sul token ospite)
create table public.order_track_failures (
  id           bigint generated always as identity primary key,
  order_number text not null,
  created_at   timestamptz not null default now()
);
create index order_track_failures_idx on public.order_track_failures(order_number, created_at desc);

-- Recensioni verificate anche da ordini completati
alter table public.reviews add column if not exists order_id uuid unique references public.orders(id) on delete set null;
alter table public.reviews drop constraint if exists reviews_verification_source_check;
alter table public.reviews add constraint reviews_verification_source_check check (verification_source in ('reservation', 'coupon', 'order'));

-- ════════════════════════════════════════════════════════════════════
--  6. PERMESSI E UTILITÀ
-- ════════════════════════════════════════════════════════════════════
-- Ruolo nel locale dell'utente corrente (owner/manager/staff) o null
create or replace function public.order_member_role(p_restaurant uuid, p_user uuid default null)
returns text language sql stable security definer set search_path = public as $$
  select m.role::text from public.restaurant_members m
   where m.restaurant_id = p_restaurant and m.user_id = coalesce(p_user, auth.uid()) and m.status = 'active'
   limit 1;
$$;

-- orders.view / orders.manage: owner, manager, staff (+ Admin). refund.request: owner, manager (+ Admin).
create or replace function public.can_view_orders(p_restaurant uuid, p_user uuid default null)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(p_user is null and public.is_admin(), false)
      or exists (select 1 from public.profiles p where p.id = coalesce(p_user, auth.uid()) and p.role = 'admin' and not p.is_blocked)
      or coalesce(public.order_member_role(p_restaurant, p_user) in ('owner', 'manager', 'staff'), false);
$$;
create or replace function public.can_refund_orders(p_restaurant uuid, p_user uuid default null)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = coalesce(p_user, auth.uid()) and p.role = 'admin' and not p.is_blocked)
      or coalesce(public.order_member_role(p_restaurant, p_user) in ('owner', 'manager'), false);
$$;
create or replace function public.is_admin_user(p_user uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = p_user and p.role = 'admin' and not p.is_blocked);
$$;

create or replace function public.order_rate_check(p_key text, p_action text, p_max int, p_window_seconds int)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_n int;
begin
  perform public.assert_service();
  select count(*) into v_n from public.order_rate_limits
   where key_hash = left(p_key, 80) and action = p_action and created_at > now() - make_interval(secs => p_window_seconds);
  if v_n >= p_max then return false; end if;
  insert into public.order_rate_limits (key_hash, action) values (left(p_key, 80), left(p_action, 40));
  if random() < 0.02 then delete from public.order_rate_limits where created_at < now() - interval '1 day'; end if;
  return true;
end $$;

create or replace function public.order_hash_token(p_token text)
returns text language sql immutable as $$
  select encode(sha256(convert_to(coalesce(p_token, ''), 'UTF8')), 'hex');
$$;

create or replace function public.order_log(p_order uuid, p_event text, p_actor_type text, p_actor uuid, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.order_events (order_id, event_type, actor_type, actor_id, metadata)
  values (p_order, left(p_event, 40), p_actor_type, p_actor, coalesce(p_meta, '{}'::jsonb));
end $$;

-- Aggiorna il canale realtime a ogni cambio di stato/pagamento
create or replace function public.orders_realtime_sync()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.order_realtime (order_id, restaurant_id, user_id, status, updated_at)
  values (new.id, new.restaurant_id, new.user_id, new.status || ':' || new.payment_status, now())
  on conflict (order_id) do update set status = excluded.status, updated_at = now(), user_id = excluded.user_id;
  return null;
end $$;
create trigger orders_realtime_sync after insert or update of status, payment_status, estimated_ready_at, fulfillment_status on public.orders
  for each row execute function public.orders_realtime_sync();

-- Commissione applicabile (override del ristorante in vigore, altrimenti globale)
create or replace function public.order_commission_for(p_restaurant uuid, p_at timestamptz default now())
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(
    (select jsonb_build_object('percent', percentage_fee, 'fixed', fixed_fee, 'source', 'restaurant')
       from public.restaurant_commission_settings
      where restaurant_id = p_restaurant and effective_from <= p_at
      order by effective_from desc limit 1),
    jsonb_build_object('percent', public.billing_setting_num('platform_commission_percent', 10),
                       'fixed', public.billing_setting_num('platform_commission_fixed', 0), 'source', 'platform'));
$$;

-- Modalità di incasso: Stripe Connect (destination charge) oppure, SOLO in test, incasso sulla piattaforma
create or replace function public.order_payment_setup(p_restaurant uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_env text := public.billing_setting_text('billing_stripe_environment', 'test'); a public.restaurant_payout_accounts;
begin
  select * into a from public.restaurant_payout_accounts
   where restaurant_id = p_restaurant and stripe_environment = v_env and charges_enabled
   order by updated_at desc limit 1;
  if found then
    return jsonb_build_object('ready', true, 'mode', 'connect', 'destination', a.stripe_account_id, 'environment', v_env);
  end if;
  if v_env = 'test' and public.billing_setting_bool('marketplace_platform_collection_test', false) then
    return jsonb_build_object('ready', true, 'mode', 'platform_test', 'destination', null, 'environment', v_env);
  end if;
  return jsonb_build_object('ready', false, 'mode', null, 'destination', null, 'environment', v_env);
end $$;

-- Minuti di preparazione effettivi (base + modalità occupato)
create or replace function public.order_prep_minutes(s public.restaurant_order_settings)
returns int language sql immutable as $$
  select coalesce(s.default_preparation_minutes, 20) + coalesce(s.busy_extra_minutes, 0);
$$;

-- Inizio della fascia di capacità per un istante
create or replace function public.order_slot_start(p_at timestamptz, p_interval int)
returns timestamptz language sql immutable as $$
  select to_timestamp(floor(extract(epoch from p_at) / (greatest(p_interval, 5) * 60)) * (greatest(p_interval, 5) * 60));
$$;

create or replace function public.order_slot_count(p_restaurant uuid, p_slot timestamptz)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from public.orders o
   where o.restaurant_id = p_restaurant and o.slot_at = p_slot
     and o.status not in ('rejected', 'cancelled')
     and (o.status <> 'pending_payment' or o.created_at > now() - interval '20 minutes');
$$;

-- Stato pausa/tipo disponibile
create or replace function public.order_type_open(s public.restaurant_order_settings, p_type text, p_at timestamptz default now())
returns text language sql stable as $$
  select case
    when s.id is null or not s.orders_enabled then 'disabled'
    when p_type = 'takeaway' and not s.takeaway_enabled then 'disabled'
    when p_type = 'delivery' and not s.delivery_enabled then 'disabled'
    when s.orders_paused_until is not null and s.orders_paused_until > p_at then 'paused'
    when p_type = 'takeaway' and s.takeaway_paused_until is not null and s.takeaway_paused_until > p_at then 'paused'
    when p_type = 'delivery' and s.delivery_paused_until is not null and s.delivery_paused_until > p_at then 'paused'
    else 'ok' end;
$$;

-- Fasce orarie ordinabili per una data (derivate da orari del locale + capacità): mai overbooking
create or replace function public.order_slots(p_restaurant uuid, p_date date, p_type text default 'takeaway')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r public.restaurants; s public.restaurant_order_settings;
  v_tz text; v_prep int; v_int int; v_earliest timestamptz; v_last date;
  t timestamptz; v_out jsonb := '[]'::jsonb; v_n int; v_status text;
begin
  select * into r from public.restaurants where id = p_restaurant;
  select * into s from public.restaurant_order_settings where restaurant_id = p_restaurant;
  if r.id is null or s.id is null or not public.restaurant_is_public(p_restaurant) then return v_out; end if;
  if p_type not in ('takeaway', 'delivery') or public.order_type_open(s, p_type) = 'disabled' then return v_out; end if;
  v_tz := coalesce(r.timezone, 'Europe/Rome');
  v_prep := public.order_prep_minutes(s);
  v_int := s.slot_interval_minutes;
  v_earliest := now() + make_interval(mins => v_prep + case when p_type = 'delivery' then s.delivery_estimated_minutes else 0 end);
  v_last := (now() at time zone v_tz)::date + s.max_advance_days;
  if p_date is null or p_date < (now() at time zone v_tz)::date or p_date > v_last then return v_out; end if;
  for t in select g at time zone v_tz from generate_series(p_date::timestamp, p_date::timestamp + interval '1 day' - make_interval(mins => v_int), make_interval(mins => v_int)) g loop
    if t < v_earliest then continue; end if;
    -- il locale deve essere aperto quando l'ordine viene preparato
    if public.restaurant_open_status(p_restaurant, t - make_interval(mins => case when p_type = 'delivery' then s.delivery_estimated_minutes else 0 end)) <> 'open' then continue; end if;
    if public.order_type_open(s, p_type, t) = 'paused' then continue; end if;
    v_status := 'available';
    if s.max_orders_per_slot is not null then
      v_n := public.order_slot_count(p_restaurant, public.order_slot_start(t, v_int));
      if v_n >= s.max_orders_per_slot then v_status := 'full'; end if;
    end if;
    v_out := v_out || jsonb_build_object('at', t, 'time', to_char(t at time zone v_tz, 'HH24:MI'), 'status', v_status);
  end loop;
  return v_out;
end $$;

-- Primo orario disponibile (oggi o nei giorni consentiti), per "Chiuso · ordina per le 19:15"
create or replace function public.order_next_slot(p_restaurant uuid, p_type text default 'takeaway')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare s public.restaurant_order_settings; r public.restaurants; d date; v_slots jsonb; x jsonb;
begin
  select * into s from public.restaurant_order_settings where restaurant_id = p_restaurant;
  select * into r from public.restaurants where id = p_restaurant;
  if s.id is null or r.id is null then return null; end if;
  for i in 0..least(coalesce(s.max_advance_days, 0), 7) loop
    d := (now() at time zone coalesce(r.timezone, 'Europe/Rome'))::date + i;
    v_slots := public.order_slots(p_restaurant, d, p_type);
    for x in select * from jsonb_array_elements(v_slots) loop
      if x ->> 'status' = 'available' then return x || jsonb_build_object('date', d); end if;
    end loop;
  end loop;
  return null;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  7. PREVENTIVO (unica fonte dei prezzi)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.order_err(p_code text, p_message text, p_extra jsonb default '{}'::jsonb)
returns jsonb language sql immutable as $$
  select jsonb_build_object('code', p_code, 'message', p_message) || coalesce(p_extra, '{}'::jsonb);
$$;

-- Validazione di un codice sconto (coupon pubblico del ristorante o codice personale, anche da premio AsiaPoints)
create or replace function public.order_validate_code(p_restaurant uuid, p_code text, p_user uuid, p_email text, p_subtotal numeric, p_at timestamptz)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_code text := upper(regexp_replace(coalesce(p_code, ''), '\s+', '', 'g'));
  cl public.coupon_claims; c public.coupons; o public.offers; rr public.reward_redemptions;
  v_used int; v_disc numeric; v_local timestamp; v_tz text;
begin
  if v_code = '' then return null; end if;
  if v_code !~ '^[A-Z0-9-]{3,40}$' then
    return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_INVALID', 'message', 'Codice non valido.');
  end if;
  select * into cl from public.coupon_claims where claim_code = v_code and restaurant_id = p_restaurant;
  if cl.id is not null then
    if cl.status <> 'claimed' then
      return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_USED', 'message', 'Questo codice è già stato utilizzato o è scaduto.');
    end if;
    if not ((p_user is not null and cl.user_id = p_user) or (cl.user_id is null and p_email is not null and lower(cl.email) = lower(p_email))) then
      return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_NOT_YOURS', 'message', 'Questo codice personale appartiene a un altro account.');
    end if;
    select * into c from public.coupons where id = cl.coupon_id;
    select * into rr from public.reward_redemptions where coupon_claim_id = cl.id limit 1;
  else
    select * into c from public.coupons where restaurant_id = p_restaurant and code = v_code;
  end if;
  if c.id is null then
    return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_INVALID', 'message', 'Codice sconto non valido per questo ristorante.');
  end if;
  if not c.is_active or c.valid_from > p_at or (c.valid_until is not null and c.valid_until <= p_at)
     or not public.restaurant_has_feature(p_restaurant, 'coupons_enabled') then
    return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_EXPIRED', 'message', 'Il codice sconto non è attivo o è scaduto.');
  end if;
  if c.max_redemptions is not null and c.redemptions_count >= c.max_redemptions then
    return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_EXHAUSTED', 'message', 'Il codice sconto ha raggiunto il numero massimo di utilizzi.');
  end if;
  if cl.id is null then
    -- Limite per cliente (utente o email): ordini pagati e coupon già usati in cassa
    select count(*) into v_used from public.orders x
     where x.coupon_id = c.id and x.payment_status in ('paid', 'partially_refunded', 'refunded') and x.status not in ('rejected', 'cancelled')
       and ((p_user is not null and x.user_id = p_user) or (p_email is not null and lower(x.customer_email) = lower(p_email)));
    v_used := v_used + (select count(*) from public.coupon_claims y where y.coupon_id = c.id and y.status = 'redeemed'
                          and ((p_user is not null and y.user_id = p_user) or (p_email is not null and lower(y.email) = lower(p_email))));
    if v_used >= coalesce(c.max_redemptions_per_user, 1) then
      return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_USED', 'message', 'Hai già utilizzato questo codice sconto.');
    end if;
  end if;
  if c.discount_type::text not in ('percent', 'amount') or c.discount_value is null or c.discount_value <= 0 then
    return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_IN_STORE_ONLY', 'message', 'Questo coupon è valido solo al ristorante, non per gli ordini online.');
  end if;
  if c.minimum_spend is not null and p_subtotal < c.minimum_spend then
    return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_MIN_SPEND',
      'message', format('Il codice è valido con una spesa minima di %s €.', to_char(c.minimum_spend, 'FM999990.00')), 'minimum_spend', c.minimum_spend);
  end if;
  -- Regole dell'offerta collegata (giorni e fascia oraria)
  if c.offer_id is not null then
    select * into o from public.offers where id = c.offer_id;
    select coalesce(timezone, 'Europe/Rome') into v_tz from public.restaurants where id = p_restaurant;
    v_local := p_at at time zone v_tz;
    if o.id is not null and (not o.is_active or o.starts_at > p_at or (o.ends_at is not null and o.ends_at <= p_at)
       or (cardinality(o.days_of_week) > 0 and not (extract(isodow from v_local)::smallint = any(o.days_of_week)))
       or (o.start_time is not null and not (v_local::time >= o.start_time and v_local::time < o.end_time))) then
      return jsonb_build_object('ok', false, 'code', v_code, 'error', 'COUPON_NOT_NOW', 'message', 'Il codice non è valido in questo giorno o orario.');
    end if;
  end if;
  v_disc := case when c.discount_type::text = 'percent' then round(p_subtotal * least(c.discount_value, 100) / 100, 2)
                 else least(c.discount_value, p_subtotal) end;
  return jsonb_build_object('ok', true, 'code', v_code, 'coupon_id', c.id, 'claim_id', cl.id, 'reward_redemption_id', rr.id,
    'is_reward', rr.id is not null, 'title', c.title, 'discount', v_disc, 'discount_type', c.discount_type, 'discount_value', c.discount_value);
end $$;

-- Preventivo completo. p: {restaurant_id, order_type, items:[{menu_item_id, variant_id, addons:[{id, quantity}], options:[id], quantity, notes}],
--   address:{latitude, longitude, ...}, scheduled_for, coupon_code, reward_code}
create or replace function public.order_quote_core(p jsonb, p_user uuid, p_email text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_rest uuid; r public.restaurants; s public.restaurant_order_settings;
  v_type text := p ->> 'order_type';
  v_errors jsonb := '[]'::jsonb;
  v_lines jsonb := '[]'::jsonb;
  e jsonb; a jsonb; v_opt text; idx int := 0;
  it public.menu_items; v public.menu_item_variants; ad public.menu_item_addons; op public.menu_options; g public.menu_option_groups;
  v_menu_ok boolean; v_base numeric; v_unit numeric; v_addons numeric; v_qty int; v_total_qty int := 0;
  v_opts jsonb; v_nvar int; v_line_ok boolean; v_group_counts jsonb;
  v_subtotal numeric := 0; v_delivery numeric := 0; v_service numeric := 0; v_coupon_disc numeric := 0; v_loyalty_disc numeric := 0;
  v_min numeric := 0; v_dist numeric; z public.delivery_zones; v_eta int; v_lat double precision; v_lng double precision;
  v_sched timestamptz; v_prep int; v_ready timestamptz; v_slot timestamptz; v_type_state text;
  v_codes jsonb := '[]'::jsonb; v_code jsonb; v_code_text text; v_max_lines int := public.billing_setting_int('order_max_items', 50);
  v_pay jsonb; v_total numeric; v_disc numeric; v_notes text; v_open text;
begin
  -- Ristorante e configurazione
  if coalesce(p ->> 'restaurant_id', '') !~* '^[0-9a-f-]{36}$' then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('RESTAURANT_NOT_FOUND', 'Ristorante non trovato.')));
  end if;
  v_rest := (p ->> 'restaurant_id')::uuid;
  select * into r from public.restaurants where id = v_rest;
  select * into s from public.restaurant_order_settings where restaurant_id = v_rest;
  if r.id is null or not public.restaurant_is_public(v_rest) then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('RESTAURANT_NOT_FOUND', 'Ristorante non trovato.')));
  end if;
  if not public.billing_setting_bool('orders_enabled', true) or s.id is null or not s.orders_enabled or r.is_permanently_closed then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('ORDERS_DISABLED', 'Questo ristorante non accetta ordini online.')));
  end if;
  if r.is_temporarily_closed then
    v_errors := v_errors || public.order_err('RESTAURANT_CLOSED', 'Il ristorante è chiuso temporaneamente.');
  end if;
  if v_type is null or v_type not in ('takeaway', 'delivery') then
    v_type := case when s.takeaway_enabled then 'takeaway' else 'delivery' end;
  end if;
  v_type_state := public.order_type_open(s, v_type);
  if v_type_state = 'disabled' then
    v_errors := v_errors || public.order_err('TYPE_UNAVAILABLE',
      case when v_type = 'delivery' then 'Questo ristorante non effettua consegne a domicilio.' else 'Questo ristorante non offre il ritiro al locale.' end);
  elsif v_type_state = 'paused' then
    v_errors := v_errors || public.order_err('RESTAURANT_PAUSED',
      case when v_type = 'delivery' then 'Le consegne sono in pausa: riprova tra poco o scegli il ritiro.' else 'Il ristorante ha messo in pausa gli ordini: riprova tra poco.' end);
  end if;

  -- Righe: prezzi SEMPRE dal database
  if jsonb_typeof(p -> 'items') <> 'array' or jsonb_array_length(p -> 'items') = 0 then
    v_errors := v_errors || public.order_err('EMPTY_CART', 'Il carrello è vuoto.');
  elsif jsonb_array_length(p -> 'items') > v_max_lines then
    v_errors := v_errors || public.order_err('TOO_MANY_ITEMS', format('Puoi ordinare al massimo %s prodotti diversi.', v_max_lines));
  else
    for e in select * from jsonb_array_elements(p -> 'items') loop
      v_line_ok := true; v_opts := '[]'::jsonb; v_addons := 0; it := null; v := null;
      v_qty := case when (e ->> 'quantity') ~ '^[0-9]{1,3}$' then (e ->> 'quantity')::int else 0 end;
      v_notes := nullif(left(trim(coalesce(e ->> 'notes', '')), 200), '');
      if coalesce(e ->> 'menu_item_id', '') ~* '^[0-9a-f-]{36}$' then
        select * into it from public.menu_items where id = (e ->> 'menu_item_id')::uuid and restaurant_id = v_rest;
      end if;
      if it.id is null then
        v_errors := v_errors || public.order_err('ITEM_NOT_FOUND', 'Un prodotto nel tuo carrello non esiste più.', jsonb_build_object('index', idx));
        v_lines := v_lines || jsonb_build_object('index', idx, 'menu_item_id', e ->> 'menu_item_id', 'available', false, 'name', null);
        idx := idx + 1; continue;
      end if;
      select exists (select 1 from public.menu_categories c join public.menus m on m.id = c.menu_id
                      where c.id = it.menu_category_id and c.is_active and public.menu_is_public(m.id) and m.menu_type <> 'all_you_can_eat')
        into v_menu_ok;
      if v_qty < 1 or v_qty > 20 then
        v_errors := v_errors || public.order_err('QUANTITY_INVALID', 'Quantità non valida (1–20).', jsonb_build_object('index', idx));
        v_line_ok := false; v_qty := greatest(least(v_qty, 20), 1);
      end if;
      if not v_menu_ok or not public.menu_item_in_stock(it) then
        v_errors := v_errors || public.order_err('ITEM_UNAVAILABLE', 'Un prodotto nel tuo carrello non è più disponibile.', jsonb_build_object('index', idx, 'name', it.name));
        v_line_ok := false;
      end if;
      -- Variante: obbligatoria se il piatto ne ha di disponibili
      select count(*) into v_nvar from public.menu_item_variants where menu_item_id = it.id and is_available;
      if coalesce(e ->> 'variant_id', '') ~* '^[0-9a-f-]{36}$' then
        select * into v from public.menu_item_variants where id = (e ->> 'variant_id')::uuid and menu_item_id = it.id;
        if v.id is null or not v.is_available then
          v_errors := v_errors || public.order_err('OPTION_INVALID', format('La variante scelta per «%s» non è più disponibile.', it.name), jsonb_build_object('index', idx));
          v_line_ok := false;
        end if;
      elsif v_nvar > 0 then
        v_errors := v_errors || public.order_err('OPTIONS_REQUIRED', format('Scegli una variante per «%s».', it.name), jsonb_build_object('index', idx));
        v_line_ok := false;
      end if;
      v_base := coalesce(v.price, case when it.discount_price is not null and it.price is not null and it.discount_price < it.price then it.discount_price else it.price end);
      if v_base is null then
        v_errors := v_errors || public.order_err('PRICE_MISSING', format('«%s» non è ordinabile online.', it.name), jsonb_build_object('index', idx));
        v_line_ok := false; v_base := 0;
      end if;
      -- Extra
      if jsonb_typeof(e -> 'addons') = 'array' then
        if jsonb_array_length(e -> 'addons') > 15 then
          v_errors := v_errors || public.order_err('OPTION_INVALID', 'Troppi extra.', jsonb_build_object('index', idx)); v_line_ok := false;
        else
          for a in select * from jsonb_array_elements(e -> 'addons') loop
            ad := null;
            if coalesce(a ->> 'id', '') ~* '^[0-9a-f-]{36}$' then
              select * into ad from public.menu_item_addons where id = (a ->> 'id')::uuid and menu_item_id = it.id;
            end if;
            if ad.id is null or not ad.is_available then
              v_errors := v_errors || public.order_err('OPTION_INVALID', format('Un extra di «%s» non è più disponibile.', it.name), jsonb_build_object('index', idx));
              v_line_ok := false; continue;
            end if;
            v_addons := v_addons + coalesce(ad.price, 0) * greatest(least(coalesce((a ->> 'quantity')::int, 1), 5), 1);
            v_opts := v_opts || jsonb_build_object('kind', 'addon', 'id', ad.id, 'group', 'Extra', 'name', ad.name,
              'price', coalesce(ad.price, 0), 'quantity', greatest(least(coalesce((a ->> 'quantity')::int, 1), 5), 1));
          end loop;
        end if;
      end if;
      -- Scelte strutturate (gruppi di opzioni)
      v_group_counts := '{}'::jsonb;
      if jsonb_typeof(e -> 'options') = 'array' then
        for v_opt in select * from jsonb_array_elements_text(e -> 'options') loop
          op := null; g := null;
          if v_opt ~* '^[0-9a-f-]{36}$' then
            select o.* into op from public.menu_options o join public.menu_option_groups gg on gg.id = o.option_group_id
             where o.id = v_opt::uuid and gg.menu_item_id = it.id and gg.is_active;
          end if;
          if op.id is null or not op.is_available then
            v_errors := v_errors || public.order_err('OPTION_INVALID', format('Una scelta per «%s» non è più disponibile.', it.name), jsonb_build_object('index', idx));
            v_line_ok := false; continue;
          end if;
          select * into g from public.menu_option_groups where id = op.option_group_id;
          v_group_counts := jsonb_set(v_group_counts, array[g.id::text], to_jsonb(coalesce((v_group_counts ->> g.id::text)::int, 0) + 1));
          v_addons := v_addons + op.price;
          v_opts := v_opts || jsonb_build_object('kind', 'option', 'id', op.id, 'group', g.name, 'name', op.name, 'price', op.price, 'quantity', 1);
        end loop;
      end if;
      for g in select * from public.menu_option_groups where menu_item_id = it.id and is_active loop
        if coalesce((v_group_counts ->> g.id::text)::int, 0) < greatest(g.min_select, case when g.required then 1 else 0 end)
           or coalesce((v_group_counts ->> g.id::text)::int, 0) > g.max_select then
          v_errors := v_errors || public.order_err('OPTIONS_REQUIRED', format('Completa la scelta «%s» per «%s».', g.name, it.name), jsonb_build_object('index', idx));
          v_line_ok := false;
        end if;
      end loop;
      v_unit := round(v_base + v_addons, 2);
      v_total_qty := v_total_qty + v_qty;
      v_subtotal := v_subtotal + round(v_unit * v_qty, 2);
      v_lines := v_lines || jsonb_build_object('index', idx, 'menu_item_id', it.id, 'name', it.name, 'variant_id', v.id, 'variant_name', v.name,
        'base_price', round(v_base, 2), 'addons_total', round(v_addons, 2), 'unit_price', v_unit, 'quantity', v_qty,
        'line_total', round(v_unit * v_qty, 2), 'options', v_opts, 'notes', v_notes, 'available', v_line_ok);
      idx := idx + 1;
    end loop;
    if v_total_qty > 100 then v_errors := v_errors || public.order_err('TOO_MANY_ITEMS', 'Quantità totale troppo alta per un ordine online.'); end if;
  end if;

  -- Orario: il prima possibile oppure programmato
  v_prep := public.order_prep_minutes(s);
  if nullif(p ->> 'scheduled_for', '') is not null then
    begin
      v_sched := (p ->> 'scheduled_for')::timestamptz;
    exception when others then
      v_errors := v_errors || public.order_err('SLOT_INVALID', 'Orario non valido.');
    end;
  end if;
  if v_sched is not null then
    if not s.allow_scheduled_orders then
      v_errors := v_errors || public.order_err('SLOT_INVALID', 'Questo ristorante non accetta ordini programmati.');
    elsif v_sched < now() + make_interval(mins => v_prep + case when v_type = 'delivery' then s.delivery_estimated_minutes else 0 end) - interval '2 minutes' then
      v_errors := v_errors || public.order_err('SLOT_INVALID', 'L''orario scelto è troppo vicino: scegline uno successivo.');
    elsif v_sched > now() + make_interval(days => s.max_advance_days + 1) then
      v_errors := v_errors || public.order_err('SLOT_INVALID', format('Puoi programmare al massimo %s giorni prima.', s.max_advance_days));
    elsif public.restaurant_open_status(v_rest, v_sched - make_interval(mins => case when v_type = 'delivery' then s.delivery_estimated_minutes else 0 end)) <> 'open' then
      v_errors := v_errors || public.order_err('SLOT_INVALID', 'Il ristorante è chiuso all''orario scelto.');
    end if;
    v_ready := v_sched - make_interval(mins => case when v_type = 'delivery' then s.delivery_estimated_minutes else 0 end);
  else
    v_open := public.restaurant_open_status(v_rest, now());
    v_ready := now() + make_interval(mins => v_prep);
    if v_open <> 'open' or public.restaurant_open_status(v_rest, v_ready) <> 'open' then
      v_errors := v_errors || public.order_err('RESTAURANT_CLOSED',
        case when v_open = 'unknown' then 'Orari del ristorante non disponibili: non è possibile ordinare ora.'
             when s.allow_scheduled_orders then 'Il ristorante è chiuso in questo momento: programma l''ordine per più tardi.'
             else 'Il ristorante è chiuso in questo momento.' end,
        jsonb_build_object('next_slot', case when s.allow_scheduled_orders then public.order_next_slot(v_rest, v_type) end));
    end if;
  end if;
  v_slot := public.order_slot_start(coalesce(v_ready, now()), s.slot_interval_minutes);
  if s.max_orders_per_slot is not null and public.order_slot_count(v_rest, v_slot) >= s.max_orders_per_slot then
    v_errors := v_errors || public.order_err('SLOT_FULL', 'La fascia oraria scelta è al completo: scegli un altro orario.',
      jsonb_build_object('next_slot', case when s.allow_scheduled_orders then public.order_next_slot(v_rest, v_type) end));
  end if;

  -- Consegna: distanza calcolata qui (mai dal modello AI né dal browser)
  if v_type = 'delivery' then
    v_eta := s.delivery_estimated_minutes;
    begin
      v_lat := nullif(p #>> '{address,latitude}', '')::double precision;
      v_lng := nullif(p #>> '{address,longitude}', '')::double precision;
    exception when others then v_lat := null; v_lng := null;
    end;
    if v_lat is null or v_lng is null or v_lat not between -90 and 90 or v_lng not between -180 and 180 then
      v_errors := v_errors || public.order_err('ADDRESS_REQUIRED', 'Inserisci un indirizzo di consegna verificato.');
    elsif r.latitude is null or r.longitude is null then
      v_errors := v_errors || public.order_err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.');
    else
      v_dist := round(public.geo_distance_km(r.latitude, r.longitude, v_lat, v_lng)::numeric, 2);
      if s.delivery_radius_km is not null and v_dist > s.delivery_radius_km then
        v_errors := v_errors || public.order_err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.', jsonb_build_object('distance_km', v_dist));
      elsif s.delivery_fee_type in ('distance', 'zone') then
        select * into z from public.delivery_zones
         where restaurant_id = v_rest and is_active and (
           (zone_type = 'radius' and v_dist <= radius_km) or
           (zone_type = 'distance' and v_dist >= coalesce(min_distance_km, 0) and v_dist < max_distance_km))
         order by coalesce(max_distance_km, radius_km) asc limit 1;
        if z.id is null then
          v_errors := v_errors || public.order_err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.', jsonb_build_object('distance_km', v_dist));
        else
          v_delivery := z.delivery_fee; v_eta := z.estimated_delivery_minutes;
          v_min := greatest(v_min, z.minimum_order);
        end if;
      elsif s.delivery_radius_km is null then
        v_errors := v_errors || public.order_err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.');
      else
        v_delivery := case when s.delivery_fee_type = 'free' then 0 else s.delivery_fee end;
      end if;
      if s.free_delivery_threshold is not null and v_subtotal >= s.free_delivery_threshold then v_delivery := 0; end if;
    end if;
    v_min := greatest(v_min, coalesce(s.delivery_minimum_order, s.minimum_order_amount, 0));
  else
    v_min := greatest(v_min, coalesce(s.takeaway_minimum_order, s.minimum_order_amount, 0));
  end if;
  if v_subtotal > 0 and v_subtotal < v_min then
    v_errors := v_errors || public.order_err('MINIMUM_NOT_REACHED',
      format('L''ordine minimo è %s €: aggiungi ancora %s €.', to_char(v_min, 'FM999990.00'), to_char(v_min - v_subtotal, 'FM999990.00')),
      jsonb_build_object('minimum', v_min, 'missing', round(v_min - v_subtotal, 2)));
  end if;

  -- Codici sconto (coupon del ristorante o codice personale da premio AsiaPoints)
  foreach v_code_text in array array[p ->> 'coupon_code', p ->> 'reward_code'] loop
    if nullif(trim(coalesce(v_code_text, '')), '') is not null then
      v_code := public.order_validate_code(v_rest, v_code_text, p_user, p_email, v_subtotal, coalesce(v_sched, now()));
      v_codes := v_codes || v_code;
      if not (v_code ->> 'ok')::boolean then
        v_errors := v_errors || public.order_err(v_code ->> 'error', v_code ->> 'message', jsonb_build_object('field', 'coupon'));
      end if;
    end if;
  end loop;
  if (select count(*) from jsonb_array_elements(v_codes) x where (x ->> 'ok')::boolean) > 1 then
    if not public.billing_setting_bool('allow_coupon_stacking', false) then
      v_errors := v_errors || public.order_err('COUPON_NOT_STACKABLE', 'I codici sconto non sono cumulabili: usane uno solo.', jsonb_build_object('field', 'coupon'));
    elsif (select count(distinct x ->> 'coupon_id') from jsonb_array_elements(v_codes) x where (x ->> 'ok')::boolean) < 2 then
      v_errors := v_errors || public.order_err('COUPON_NOT_STACKABLE', 'Lo stesso coupon non può essere usato due volte.', jsonb_build_object('field', 'coupon'));
    end if;
  end if;
  for v_code in select * from jsonb_array_elements(v_codes) loop
    if (v_code ->> 'ok')::boolean then
      v_disc := least((v_code ->> 'discount')::numeric, v_subtotal - v_coupon_disc - v_loyalty_disc);
      if (v_code ->> 'is_reward')::boolean then v_loyalty_disc := v_loyalty_disc + v_disc; else v_coupon_disc := v_coupon_disc + v_disc; end if;
    end if;
  end loop;

  -- Costo di servizio (piattaforma), sempre mostrato prima del pagamento
  if public.billing_setting_bool('service_fee_enabled', false) and s.service_fee_enabled and v_subtotal > 0 then
    v_service := public.billing_setting_num('service_fee_amount', 0.99);
  end if;

  v_total := round(v_subtotal - v_coupon_disc - v_loyalty_disc + v_delivery + v_service, 2);
  if v_subtotal > 0 and v_total < 0.5 then
    v_errors := v_errors || public.order_err('TOTAL_TOO_LOW', 'L''importo minimo per il pagamento online è 0,50 €.');
  end if;
  v_pay := public.order_payment_setup(v_rest);
  if not (v_pay ->> 'ready')::boolean then
    v_errors := v_errors || public.order_err('PAYMENTS_NOT_READY', 'Questo ristorante non ha ancora attivato i pagamenti online.');
  end if;

  return jsonb_build_object(
    'ok', jsonb_array_length(v_errors) = 0,
    'errors', v_errors,
    'restaurant', jsonb_build_object('id', r.id, 'name', r.name, 'slug', r.slug),
    'order_type', v_type,
    'lines', v_lines,
    'subtotal', round(v_subtotal, 2),
    'coupon_discount', round(v_coupon_disc, 2),
    'loyalty_discount', round(v_loyalty_disc, 2),
    'discount_total', round(v_coupon_disc + v_loyalty_disc, 2),
    'delivery_fee', round(v_delivery, 2),
    'service_fee', round(v_service, 2),
    'tax_total', null,
    'total', greatest(v_total, 0),
    'currency', 'EUR',
    'minimum_order', v_min,
    'codes', v_codes,
    'delivery', case when v_type = 'delivery' then jsonb_build_object('distance_km', v_dist, 'zone_id', z.id, 'zone_name', z.name, 'eta_minutes', v_eta) end,
    'scheduled_for', v_sched,
    'estimated_ready_at', v_ready,
    'estimated_delivery_at', case when v_type = 'delivery' then v_ready + make_interval(mins => coalesce(v_eta, s.delivery_estimated_minutes)) end,
    'slot_at', v_slot,
    'preparation_minutes', v_prep,
    'payment_mode', v_pay ->> 'mode',
    'payments_ready', (v_pay ->> 'ready')::boolean);
end $$;

-- Preventivo dal browser: stessa logica, identità dal JWT (mai passata dal client)
create or replace function public.order_quote(p jsonb)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_email text;
begin
  if pg_column_size(p) > 40000 then raise exception 'Richiesta troppo grande.'; end if;
  if auth.uid() is not null then select email into v_email from public.profiles where id = auth.uid(); end if;
  return public.order_quote_core(p, auth.uid(), coalesce(v_email, nullif(lower(trim(p #>> '{contact,email}')), '')));
end $$;

-- Informazioni pubbliche per la scheda ristorante (nessun dato sensibile)
create or replace function public.order_public_info(p_restaurant uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare r public.restaurants; s public.restaurant_order_settings; v_pay jsonb; v_open text; v_tk text; v_dl text;
begin
  select * into r from public.restaurants where id = p_restaurant;
  select * into s from public.restaurant_order_settings where restaurant_id = p_restaurant;
  if r.id is null or not public.restaurant_is_public(p_restaurant) or s.id is null or not s.orders_enabled
     or not public.billing_setting_bool('orders_enabled', true) or r.is_permanently_closed then
    return jsonb_build_object('enabled', false);
  end if;
  v_pay := public.order_payment_setup(p_restaurant);
  v_open := public.restaurant_open_status(p_restaurant, now());
  v_tk := public.order_type_open(s, 'takeaway'); v_dl := public.order_type_open(s, 'delivery');
  return jsonb_build_object(
    'enabled', true,
    'payments_ready', (v_pay ->> 'ready')::boolean,
    'open_now', v_open = 'open' and not r.is_temporarily_closed,
    'open_status', v_open,
    'temporarily_closed', r.is_temporarily_closed,
    'paused_until', case when s.orders_paused_until > now() then s.orders_paused_until end,
    'preparation_minutes', public.order_prep_minutes(s),
    'busy', s.busy_extra_minutes > 0,
    'allow_scheduled', s.allow_scheduled_orders,
    'max_advance_days', s.max_advance_days,
    'minimum_order', s.minimum_order_amount,
    'pickup_instructions', s.pickup_instructions,
    'takeaway', jsonb_build_object('enabled', v_tk <> 'disabled', 'state', v_tk,
      'paused_until', case when s.takeaway_paused_until > now() then s.takeaway_paused_until end,
      'minimum_order', coalesce(s.takeaway_minimum_order, s.minimum_order_amount),
      'next_slot', case when v_tk = 'ok' then public.order_next_slot(p_restaurant, 'takeaway') end),
    'delivery', jsonb_build_object('enabled', v_dl <> 'disabled', 'state', v_dl,
      'paused_until', case when s.delivery_paused_until > now() then s.delivery_paused_until end,
      'minimum_order', coalesce(s.delivery_minimum_order, s.minimum_order_amount),
      'fee_type', s.delivery_fee_type, 'fee', s.delivery_fee, 'radius_km', s.delivery_radius_km,
      'free_threshold', s.free_delivery_threshold, 'estimated_minutes', s.delivery_estimated_minutes,
      'provider', s.delivery_provider_type,
      'zones', coalesce((select jsonb_agg(jsonb_build_object('name', z.name, 'type', z.zone_type, 'min_km', coalesce(z.min_distance_km, 0),
                           'max_km', coalesce(z.max_distance_km, z.radius_km), 'fee', z.delivery_fee, 'minimum_order', z.minimum_order,
                           'eta_minutes', z.estimated_delivery_minutes) order by coalesce(z.max_distance_km, z.radius_km))
                         from public.delivery_zones z where z.restaurant_id = p_restaurant and z.is_active and z.zone_type <> 'polygon'), '[]'::jsonb),
      'next_slot', case when v_dl = 'ok' then public.order_next_slot(p_restaurant, 'delivery') end),
    'service_fee', case when public.billing_setting_bool('service_fee_enabled', false) and s.service_fee_enabled then public.billing_setting_num('service_fee_amount', 0.99) else 0 end);
end $$;

-- Ristoranti che accettano ordini (per filtri "Delivery", "Takeaway", "Ordina ora", home e mappa)
create or replace function public.orderable_restaurants()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
      'restaurant_id', r.id,
      'takeaway', public.order_type_open(s, 'takeaway') <> 'disabled',
      'delivery', public.order_type_open(s, 'delivery') <> 'disabled',
      'order_now', (v.pay ->> 'ready')::boolean and public.restaurant_open_status(r.id, now()) = 'open' and not r.is_temporarily_closed
                   and (public.order_type_open(s, 'takeaway') = 'ok' or public.order_type_open(s, 'delivery') = 'ok'),
      'payments_ready', (v.pay ->> 'ready')::boolean,
      'delivery_radius_km', coalesce(s.delivery_radius_km, (select max(coalesce(z.max_distance_km, z.radius_km)) from public.delivery_zones z where z.restaurant_id = r.id and z.is_active))
    )), '[]'::jsonb)
  from public.restaurant_order_settings s
  join public.restaurants r on r.id = s.restaurant_id
  cross join lateral (select public.order_payment_setup(r.id) as pay) v
  where s.orders_enabled and public.billing_setting_bool('orders_enabled', true) and not r.is_permanently_closed
    and public.restaurant_is_public(r.id);
$$;

-- "Consegna qui": quali ristoranti consegnano a un punto (posizione autorizzata dall'utente, non salvata)
create or replace function public.restaurants_delivering_to(p_lat double precision, p_lng double precision)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_out jsonb := '[]'::jsonb; x record; v_d numeric; z public.delivery_zones; v_fee numeric;
begin
  if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then return v_out; end if;
  for x in select r.id, r.latitude, r.longitude, s.* from public.restaurant_order_settings s join public.restaurants r on r.id = s.restaurant_id
            where s.orders_enabled and s.delivery_enabled and public.restaurant_is_public(r.id) and r.latitude is not null loop
    v_d := round(public.geo_distance_km(x.latitude, x.longitude, round(p_lat::numeric, 3)::double precision, round(p_lng::numeric, 3)::double precision)::numeric, 1);
    v_fee := null;
    if x.delivery_fee_type in ('distance', 'zone') then
      select * into z from public.delivery_zones where restaurant_id = x.id and is_active and (
        (zone_type = 'radius' and v_d <= radius_km) or (zone_type = 'distance' and v_d >= coalesce(min_distance_km, 0) and v_d < max_distance_km))
        order by coalesce(max_distance_km, radius_km) limit 1;
      if z.id is not null and (x.delivery_radius_km is null or v_d <= x.delivery_radius_km) then v_fee := z.delivery_fee; end if;
    elsif x.delivery_radius_km is not null and v_d <= x.delivery_radius_km then
      v_fee := case when x.delivery_fee_type = 'free' then 0 else x.delivery_fee end;
    end if;
    if v_fee is not null then v_out := v_out || jsonb_build_object('restaurant_id', x.id, 'distance_km', v_d, 'delivery_fee', v_fee); end if;
  end loop;
  return v_out;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  8. CREAZIONE ORDINE (solo backend) E PAGAMENTO
-- ════════════════════════════════════════════════════════════════════
create or replace function public.order_new_number(p_tz text default 'Europe/Rome')
returns text language plpgsql volatile security definer set search_path = public as $$
declare v text;
begin
  loop
    v := 'AF-' || to_char(now() at time zone p_tz, 'YYMMDD') || '-' || public.random_code(4);
    exit when not exists (select 1 from public.orders where order_number = v);
  end loop;
  return v;
end $$;

-- p = input del preventivo + {contact:{name,email,phone}, address:{...}, notes, source}
create or replace function public.order_create(p jsonb, p_user uuid, p_session text, p_idem text, p_token_hash text, p_ip_hash text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  q jsonb; r public.restaurants; o public.orders; v_existing uuid; v_pay jsonb; v_com jsonb;
  v_name text; v_email text; v_phone text; pr public.profiles; ln jsonb; op jsonb; v_item uuid;
  v_gross numeric; v_fee numeric; v_addr jsonb; v_code jsonb; v_coupon uuid; v_claim uuid; v_reward uuid; v_code_txt text;
  v_open int;
begin
  perform public.assert_service();
  if p_token_hash is null or p_token_hash !~ '^[0-9a-f]{64}$' then raise exception 'token hash non valido'; end if;
  -- Idempotenza: lo stesso tentativo di checkout (doppio click, ritentativo) restituisce lo stesso ordine
  if nullif(p_idem, '') is not null then
    select order_id into v_existing from public.order_secrets where idempotency_key = left(p_idem, 80);
    if v_existing is not null then
      select * into o from public.orders where id = v_existing;
      if (o.user_id is not distinct from p_user) then
        return jsonb_build_object('ok', true, 'existing', true, 'order_id', o.id, 'order_number', o.order_number, 'status', o.status,
          'payment_status', o.payment_status, 'total', o.total, 'total_cents', round(o.total * 100)::int, 'currency', o.currency,
          'payment_mode', o.payment_mode, 'destination', o.payout_destination,
          'application_fee_cents', round((o.platform_fee + o.service_fee) * 100)::int, 'payment_intent_id', o.stripe_payment_intent_id,
          'customer_email', o.customer_email, 'restaurant_id', o.restaurant_id);
      end if;
      return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('IDEMPOTENCY_CONFLICT', 'Richiesta duplicata: ricarica la pagina.')));
    end if;
  end if;
  if p_user is not null then
    select * into pr from public.profiles where id = p_user;
    if pr.is_blocked then return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('FORBIDDEN', 'Account non abilitato agli ordini.'))); end if;
  end if;
  -- Contatti (necessari per evadere l'ordine e inviare la ricevuta)
  v_name := left(trim(coalesce(p #>> '{contact,name}', pr.full_name, '')), 80);
  v_email := lower(trim(coalesce(nullif(p #>> '{contact,email}', ''), pr.email, '')));
  v_phone := trim(coalesce(nullif(p #>> '{contact,phone}', ''), pr.phone, ''));
  if char_length(v_name) < 2 then return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('CONTACT_INVALID', 'Inserisci nome e cognome.', '{"field":"name"}'))); end if;
  if v_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' or char_length(v_email) > 254 then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('CONTACT_INVALID', 'Inserisci un indirizzo email valido.', '{"field":"email"}')));
  end if;
  if v_phone !~ '^\+?[0-9 ().-]{6,20}$' then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('CONTACT_INVALID', 'Inserisci un numero di telefono valido.', '{"field":"phone"}')));
  end if;
  -- Anti-abuso: troppi ordini non pagati aperti
  select count(*) into v_open from public.orders
   where status = 'pending_payment' and created_at > now() - interval '30 minutes'
     and ((p_user is not null and user_id = p_user) or (p_session is not null and session_id = p_session) or lower(customer_email) = v_email);
  if v_open >= 5 then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('RATE_LIMITED', 'Hai troppi ordini in attesa di pagamento: completa o attendi qualche minuto.')));
  end if;

  q := public.order_quote_core(p, p_user, v_email);
  if not (q ->> 'ok')::boolean then return jsonb_build_object('ok', false, 'errors', q -> 'errors', 'quote', q); end if;

  select * into r from public.restaurants where id = (q #>> '{restaurant,id}')::uuid;
  v_pay := public.order_payment_setup(r.id);
  v_com := public.order_commission_for(r.id);
  -- Lordo ristorante = cibo scontato + consegna (gestita dal ristorante). Il costo di servizio va alla piattaforma.
  v_gross := round((q ->> 'subtotal')::numeric - (q ->> 'discount_total')::numeric + (q ->> 'delivery_fee')::numeric, 2);
  v_fee := least(round(v_gross * (v_com ->> 'percent')::numeric / 100 + (v_com ->> 'fixed')::numeric, 2), v_gross);
  for v_code in select * from jsonb_array_elements(q -> 'codes') loop
    if (v_code ->> 'ok')::boolean then
      v_coupon := coalesce(v_coupon, (v_code ->> 'coupon_id')::uuid);
      v_code_txt := coalesce(v_code_txt, v_code ->> 'code');
      if nullif(v_code ->> 'claim_id', '') is not null then v_claim := (v_code ->> 'claim_id')::uuid; end if;
      if nullif(v_code ->> 'reward_redemption_id', '') is not null then v_reward := (v_code ->> 'reward_redemption_id')::uuid; end if;
    end if;
  end loop;
  if q ->> 'order_type' = 'delivery' then
    v_addr := jsonb_build_object(
      'recipient_name', left(coalesce(nullif(p #>> '{address,recipient_name}', ''), v_name), 80),
      'phone', left(coalesce(nullif(p #>> '{address,phone}', ''), v_phone), 20),
      'address_line_1', left(trim(coalesce(p #>> '{address,address_line_1}', '')), 120),
      'address_line_2', left(nullif(trim(coalesce(p #>> '{address,address_line_2}', '')), ''), 120),
      'city', left(trim(coalesce(p #>> '{address,city}', '')), 80),
      'province', left(nullif(trim(coalesce(p #>> '{address,province}', '')), ''), 40),
      'postal_code', left(trim(coalesce(p #>> '{address,postal_code}', '')), 5),
      'country', 'IT',
      'latitude', round((p #>> '{address,latitude}')::numeric, 6), 'longitude', round((p #>> '{address,longitude}')::numeric, 6),
      'geocode_source', left(coalesce(p #>> '{address,geocode_source}', 'geocoder'), 20),
      'delivery_notes', left(nullif(trim(coalesce(p #>> '{address,delivery_notes}', '')), ''), 200));
    if char_length(v_addr ->> 'address_line_1') < 3 or char_length(v_addr ->> 'city') < 2 or coalesce(v_addr ->> 'postal_code', '') !~ '^[0-9]{5}$' then
      return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('ADDRESS_REQUIRED', 'Completa l''indirizzo di consegna (via, CAP e città).', '{"field":"address"}')));
    end if;
  end if;

  insert into public.orders (order_number, restaurant_id, user_id, session_id, order_type, status, payment_status,
    customer_name, customer_email, customer_phone, delivery_address_id, delivery_address_snapshot, delivery_distance_km, delivery_zone_id,
    delivery_provider_type, subtotal, discount_total, coupon_discount, loyalty_discount, delivery_fee, service_fee, total, currency,
    coupon_id, coupon_code, coupon_claim_id, reward_redemption_id,
    commission_percent, commission_fixed, platform_fee, restaurant_gross, restaurant_net_estimated,
    payment_mode, payout_destination, stripe_environment, scheduled_for, slot_at, preparation_minutes, estimated_ready_at, estimated_delivery_at,
    customer_notes, source, risk_flags)
  values (public.order_new_number(coalesce(r.timezone, 'Europe/Rome')), r.id, p_user, left(p_session, 64), q ->> 'order_type', 'pending_payment', 'unpaid',
    v_name, v_email, v_phone,
    case when p_user is not null and coalesce(p #>> '{address,id}', '') ~* '^[0-9a-f-]{36}$'
         and exists (select 1 from public.customer_addresses a where a.id = (p #>> '{address,id}')::uuid and a.user_id = p_user)
         then (p #>> '{address,id}')::uuid end,
    v_addr, (q #>> '{delivery,distance_km}')::numeric, nullif(q #>> '{delivery,zone_id}', '')::uuid,
    coalesce((select delivery_provider_type from public.restaurant_order_settings where restaurant_id = r.id), 'restaurant'),
    (q ->> 'subtotal')::numeric, (q ->> 'discount_total')::numeric, (q ->> 'coupon_discount')::numeric, (q ->> 'loyalty_discount')::numeric,
    (q ->> 'delivery_fee')::numeric, (q ->> 'service_fee')::numeric, (q ->> 'total')::numeric, 'EUR',
    v_coupon, v_code_txt, v_claim, v_reward,
    (v_com ->> 'percent')::numeric, (v_com ->> 'fixed')::numeric, v_fee, v_gross, v_gross - v_fee,
    v_pay ->> 'mode', v_pay ->> 'destination', v_pay ->> 'environment',
    nullif(q ->> 'scheduled_for', '')::timestamptz, (q ->> 'slot_at')::timestamptz, (q ->> 'preparation_minutes')::int,
    (q ->> 'estimated_ready_at')::timestamptz, nullif(q ->> 'estimated_delivery_at', '')::timestamptz,
    nullif(left(trim(coalesce(p ->> 'notes', '')), 300), ''),
    case when p ->> 'source' in ('web', 'app', 'ai', 'reorder') then p ->> 'source' else 'web' end,
    case when q ->> 'order_type' = 'delivery' and coalesce(p #>> '{address,geocode_source}', '') = 'device' then array['address_from_device'] else '{}'::text[] end)
  returning * into o;

  insert into public.order_secrets (order_id, access_token_hash, idempotency_key, ip_hash)
  values (o.id, p_token_hash, nullif(left(p_idem, 80), ''), left(p_ip_hash, 80));

  for ln in select * from jsonb_array_elements(q -> 'lines') loop
    insert into public.order_items (order_id, menu_item_id, menu_item_name_snapshot, variant_id, variant_name_snapshot, quantity,
      unit_price, addons_total, line_total, notes)
    values (o.id, (ln ->> 'menu_item_id')::uuid, ln ->> 'name', nullif(ln ->> 'variant_id', '')::uuid, ln ->> 'variant_name',
      (ln ->> 'quantity')::int, (ln ->> 'unit_price')::numeric, (ln ->> 'addons_total')::numeric, (ln ->> 'line_total')::numeric, ln ->> 'notes')
    returning id into v_item;
    for op in select * from jsonb_array_elements(ln -> 'options') loop
      insert into public.order_item_options (order_item_id, kind, group_name, name_snapshot, price_snapshot, quantity)
      values (v_item, op ->> 'kind', op ->> 'group', op ->> 'name', (op ->> 'price')::numeric, (op ->> 'quantity')::int);
    end loop;
  end loop;

  perform public.order_log(o.id, 'created', case when p_user is null then 'customer' else 'customer' end, p_user,
    jsonb_build_object('total', o.total, 'order_type', o.order_type));
  perform public.log_event(r.id, 'order_created', coalesce(nullif(p ->> 'source', ''), 'web'), jsonb_build_object('order_type', o.order_type));
  if p_user is not null then perform public.touch_activity(p_user); end if;
  update public.carts set status = 'converted' where status = 'active' and user_id = p_user and p_user is not null;

  return jsonb_build_object('ok', true, 'existing', false, 'order_id', o.id, 'order_number', o.order_number, 'status', o.status,
    'payment_status', o.payment_status, 'total', o.total, 'total_cents', round(o.total * 100)::int, 'currency', o.currency,
    'payment_mode', o.payment_mode, 'destination', o.payout_destination,
    'application_fee_cents', round((o.platform_fee + o.service_fee) * 100)::int, 'payment_intent_id', null,
    'customer_email', o.customer_email, 'restaurant_id', r.id, 'restaurant_name', r.name);
end $$;

-- Hash del token di accesso (derivato dal server con HMAC sull'ID dell'ordine)
create or replace function public.order_set_token(p_order uuid, p_token_hash text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  if p_token_hash !~ '^[0-9a-f]{64}$' then raise exception 'token hash non valido'; end if;
  update public.order_secrets set access_token_hash = p_token_hash where order_id = p_order;
end $$;

-- Stato di pagamento per il backend (annullamento PaymentIntent, resync)
create or replace function public.order_payment_info(p_order uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select case when o.id is null then jsonb_build_object('ok', false) else
    jsonb_build_object('ok', true, 'order_id', o.id, 'restaurant_id', o.restaurant_id, 'status', o.status, 'payment_status', o.payment_status,
                       'payment_intent_id', o.stripe_payment_intent_id, 'order_number', o.order_number, 'user_id', o.user_id) end
  from (select 1) one left join public.orders o on o.id = p_order;
$$;

create or replace function public.order_attach_payment(p_order uuid, p_payment_intent text, p_env text)
returns void language plpgsql security definer set search_path = public as $$
declare o public.orders;
begin
  perform public.assert_service();
  if p_payment_intent !~ '^pi_[A-Za-z0-9_]+$' then raise exception 'PaymentIntent non valido'; end if;
  select * into o from public.orders where id = p_order for update;
  if not found then raise exception 'Ordine non trovato'; end if;
  if o.stripe_payment_intent_id is not null and o.stripe_payment_intent_id <> p_payment_intent then
    raise exception 'Ordine già collegato a un altro pagamento';
  end if;
  update public.orders set stripe_payment_intent_id = p_payment_intent, stripe_environment = coalesce(p_env, stripe_environment),
         payment_status = case when payment_status = 'unpaid' then 'pending' else payment_status end
   where id = p_order;
  if o.stripe_payment_intent_id is null then
    perform public.order_log(p_order, 'payment_started', 'system', null, '{}'::jsonb);
  end if;
end $$;

-- Notifiche ordine (transazionali: in-app + push per utenti registrati, email anche per ospiti)
create or replace function public.order_notify_customer(o public.orders, p_kind text, p_title text, p_body text, p_email_event text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_link text := '/orders/' || o.order_number; r public.restaurants;
begin
  select * into r from public.restaurants where id = o.restaurant_id;
  if o.user_id is not null then
    perform public.notify_user(o.user_id, 'order', p_title, p_body, v_link, null, 'order:' || p_kind || ':' || o.id,
      jsonb_build_object('order_id', o.id, 'order_number', o.order_number), o.restaurant_id,
      p_email_event, jsonb_build_object('order_number', o.order_number, 'order_id', o.id, 'restaurant', r.name, 'total', o.total));
  elsif p_email_event is not null then
    begin
      insert into public.email_outbox (event_type, recipient, payload, restaurant_id, order_id)
      values (p_email_event, o.customer_email, jsonb_build_object('order_number', o.order_number, 'order_id', o.id, 'restaurant', r.name,
              'total', o.total, 'title', p_title, 'body', p_body, 'link', v_link, 'guest', true), o.restaurant_id, o.id);
    exception when others then null; -- l'email non deve mai bloccare l'ordine
    end;
  end if;
end $$;

-- Membri del locale (anche staff) ricevono gli avvisi dei nuovi ordini
create or replace function public.order_notify_restaurant(o public.orders, p_kind text, p_title text, p_body text)
returns void language plpgsql security definer set search_path = public as $$
declare m record;
begin
  for m in select user_id from public.restaurant_members where restaurant_id = o.restaurant_id and status = 'active' loop
    perform public.notify_user(m.user_id, 'order', p_title, p_body, format('/dashboard/restaurants/%s/orders', o.restaurant_id), null,
      'order_r:' || p_kind || ':' || o.id || ':' || m.user_id, jsonb_build_object('order_id', o.id, 'order_number', o.order_number, 'sound', p_kind = 'new'),
      o.restaurant_id);
  end loop;
end $$;

-- Effetti del pagamento confermato (webhook): coupon/premio consumati, ristorante avvisato, eventuale accettazione automatica
create or replace function public.order_apply_paid(o public.orders)
returns void language plpgsql security definer set search_path = public as $$
declare s public.restaurant_order_settings; v_prev text; r public.restaurants;
begin
  select * into s from public.restaurant_order_settings where restaurant_id = o.restaurant_id;
  select * into r from public.restaurants where id = o.restaurant_id;
  v_prev := public.internal_write_begin();
  if o.coupon_id is not null then
    update public.coupons set redemptions_count = redemptions_count + 1 where id = o.coupon_id;
  end if;
  if o.coupon_claim_id is not null then
    update public.coupon_claims set status = 'redeemed', redeemed_at = now() where id = o.coupon_claim_id and status = 'claimed';
  end if;
  if o.reward_redemption_id is not null then
    update public.reward_redemptions set status = 'used', redeemed_at = now() where id = o.reward_redemption_id and status = 'claimed';
  end if;
  perform public.internal_write_end(v_prev);
  perform public.log_event(o.restaurant_id, 'payment_success', 'server', jsonb_build_object('order_type', o.order_type));
  perform public.order_notify_restaurant(o, 'new', 'Nuovo ordine ' || o.order_number,
    format('%s · %s € · %s', case when o.order_type = 'delivery' then 'Consegna' else 'Ritiro' end, to_char(o.total, 'FM999990.00'),
      case when o.scheduled_for is null then 'il prima possibile' else 'per le ' || to_char(o.scheduled_for at time zone coalesce(r.timezone, 'Europe/Rome'), 'HH24:MI') end));
  perform public.order_notify_customer(o, 'paid', 'Pagamento confermato', format('Ordine %s inviato a %s: ti avvisiamo appena viene accettato.', o.order_number, r.name), 'order_payment_confirmed');
  if s.accept_orders_automatically then
    perform public.order_transition(o.id, 'accept', jsonb_build_object('preparation_minutes', public.order_prep_minutes(s)), 'system', null);
  end if;
end $$;

-- Evento di pagamento dal webhook (o dal "Resync" Admin). Idempotente.
-- p: {type: succeeded|failed|canceled|processing, payment_intent, order_id, amount (centesimi), currency, charge, error_code, source}
create or replace function public.order_payment_event(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare o public.orders; v_amount numeric; v_type text := p ->> 'type'; v_pi text := p ->> 'payment_intent'; v_refund uuid;
begin
  perform public.assert_service();
  select * into o from public.orders where stripe_payment_intent_id = v_pi for update;
  if not found and coalesce(p ->> 'order_id', '') ~* '^[0-9a-f-]{36}$' then
    select * into o from public.orders where id = (p ->> 'order_id')::uuid and stripe_payment_intent_id is null for update;
    if found then update public.orders set stripe_payment_intent_id = v_pi where id = o.id; o.stripe_payment_intent_id := v_pi; end if;
  end if;
  if o.id is null then return jsonb_build_object('ok', false, 'status', 'unknown_order'); end if;

  if v_type = 'succeeded' then
    if o.payment_status in ('paid', 'refunded', 'partially_refunded') then return jsonb_build_object('ok', true, 'status', 'duplicate', 'order_id', o.id); end if;
    v_amount := coalesce((p ->> 'amount')::numeric, 0) / 100;
    update public.orders set payment_status = 'paid', paid_at = now(), amount_paid = v_amount,
           stripe_charge_id = coalesce(nullif(p ->> 'charge', ''), stripe_charge_id),
           risk_flags = case when v_amount <> total or upper(coalesce(p ->> 'currency', 'eur')) <> currency
                             then array_append(risk_flags, 'amount_mismatch') else risk_flags end
     where id = o.id returning * into o;
    perform public.order_log(o.id, 'payment_succeeded', 'stripe', null, jsonb_build_object('amount', v_amount, 'source', coalesce(p ->> 'source', 'webhook')));
    if o.status in ('cancelled', 'rejected') then
      -- Pagato dopo l'annullamento (es. scadenza): rimborso completo automatico
      insert into public.order_refunds (order_id, amount, reason, requested_by_type)
      values (o.id, v_amount, 'Pagamento ricevuto dopo l''annullamento dell''ordine', 'system') returning id into v_refund;
      perform public.order_log(o.id, 'refund_requested', 'system', null, jsonb_build_object('amount', v_amount, 'reason', 'paid_after_cancel'));
      return jsonb_build_object('ok', true, 'status', 'refund_needed', 'order_id', o.id, 'refund_id', v_refund);
    end if;
    if 'amount_mismatch' = any(o.risk_flags) then
      perform public.notify_admins('order_issue', 'Importo pagato diverso dal totale', o.order_number, '/admin/orders?q=' || o.order_number);
    end if;
    update public.orders set status = 'pending_restaurant' where id = o.id and status in ('pending_payment', 'payment_authorized');
    select * into o from public.orders where id = o.id;
    perform public.order_apply_paid(o);
    return jsonb_build_object('ok', true, 'status', 'paid', 'order_id', o.id);
  elsif v_type = 'failed' then
    if o.payment_status in ('paid', 'refunded', 'partially_refunded') then return jsonb_build_object('ok', true, 'status', 'ignored'); end if;
    update public.orders set payment_status = 'failed', payment_failures = payment_failures + 1,
           risk_flags = case when payment_failures + 1 >= 5 and not ('payment_failures' = any(risk_flags)) then array_append(risk_flags, 'payment_failures') else risk_flags end
     where id = o.id returning * into o;
    perform public.order_log(o.id, 'payment_failed', 'stripe', null, jsonb_build_object('code', left(coalesce(p ->> 'error_code', ''), 60)));
    perform public.log_event(o.restaurant_id, 'payment_failed', 'server', '{}'::jsonb);
    return jsonb_build_object('ok', true, 'status', 'failed', 'order_id', o.id, 'failures', o.payment_failures);
  elsif v_type = 'canceled' then
    if o.status = 'pending_payment' then
      update public.orders set status = 'cancelled', cancelled_at = now(), fulfillment_status = 'cancelled',
             payment_status = case when payment_status in ('pending', 'failed') then 'failed' else payment_status end,
             cancel_reason = coalesce(cancel_reason, 'Pagamento annullato') where id = o.id;
      perform public.order_log(o.id, 'cancelled', 'stripe', null, jsonb_build_object('reason', 'payment_canceled'));
    end if;
    return jsonb_build_object('ok', true, 'status', 'canceled', 'order_id', o.id);
  elsif v_type = 'processing' then
    update public.orders set payment_status = 'pending' where id = o.id and payment_status in ('unpaid', 'failed');
    return jsonb_build_object('ok', true, 'status', 'processing', 'order_id', o.id);
  elsif v_type = 'dispute' then
    update public.orders set risk_flags = array_append(risk_flags, 'dispute') where id = o.id and not ('dispute' = any(risk_flags));
    perform public.order_log(o.id, 'dispute_created', 'stripe', null, jsonb_build_object('reason', left(coalesce(p ->> 'reason', ''), 60)));
    perform public.notify_admins('order_issue', 'Contestazione di pagamento', o.order_number, '/admin/orders?q=' || o.order_number);
    return jsonb_build_object('ok', true, 'status', 'dispute', 'order_id', o.id);
  end if;
  return jsonb_build_object('ok', false, 'status', 'ignored');
end $$;

-- Pagamento simulato: SOLO per test automatici/ambienti senza Stripe (mai esposto al browser)
-- (nessuna funzione: i test usano lo Stripe simulato e il webhook firmato)

-- ════════════════════════════════════════════════════════════════════
--  9. CICLO DI VITA (ristorante, cliente, Admin)
-- ════════════════════════════════════════════════════════════════════
-- Motivi di rifiuto
create or replace function public.order_reject_reason_label(p text)
returns text language sql immutable as $$
  select case p when 'too_busy' then 'Troppi ordini in questo momento' when 'item_unavailable' then 'Prodotto non disponibile'
    when 'closed' then 'Chiusura imprevista' when 'out_of_area' then 'Indirizzo fuori zona di consegna'
    when 'technical' then 'Problema tecnico' else 'Altro' end;
$$;

-- Transizione di stato (usata da order_action e dagli automatismi). p_actor_type: restaurant|admin|system
create or replace function public.order_transition(p_order uuid, p_action text, p jsonb, p_actor_type text, p_actor uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  o public.orders; r public.restaurants; v_prep int; v_to text; v_refund uuid; v_reason text; v_label text;
  v_auto_refund boolean := public.billing_setting_bool('order_auto_refund_on_reject', true);
begin
  select * into o from public.orders where id = p_order for update;
  if not found then raise exception 'Ordine non trovato.'; end if;
  select * into r from public.restaurants where id = o.restaurant_id;

  if p_action = 'accept' then
    if o.status <> 'pending_restaurant' then raise exception 'L''ordine non è in attesa di conferma.' using hint = 'INVALID_TRANSITION'; end if;
    v_prep := case when (p ->> 'preparation_minutes') ~ '^[0-9]{1,3}$' then (p ->> 'preparation_minutes')::int else null end;
    if v_prep is null or v_prep not between 5 and 240 then raise exception 'Tempo di preparazione non valido (5–240 minuti).'; end if;
    update public.orders set status = 'accepted', accepted_at = now(), preparation_minutes = v_prep,
           estimated_ready_at = greatest(coalesce(scheduled_for - make_interval(mins => case when order_type = 'delivery' then coalesce(
                                   (select estimated_delivery_minutes from public.delivery_zones where id = delivery_zone_id), 25) else 0 end), now()),
                                   now() + make_interval(mins => v_prep)),
           restaurant_notes = coalesce(nullif(left(trim(coalesce(p ->> 'note', '')), 300), ''), restaurant_notes)
     where id = o.id returning * into o;
    update public.orders set estimated_delivery_at = case when order_type = 'delivery'
             then estimated_ready_at + make_interval(mins => coalesce((select estimated_delivery_minutes from public.delivery_zones where id = delivery_zone_id),
                                                       (select delivery_estimated_minutes from public.restaurant_order_settings where restaurant_id = o.restaurant_id), 25)) end
     where id = o.id returning * into o;
    perform public.order_log(o.id, 'accepted', p_actor_type, p_actor, jsonb_build_object('preparation_minutes', v_prep));
    perform public.log_event(o.restaurant_id, 'order_accepted', 'server', '{}'::jsonb);
    perform public.order_notify_customer(o, 'accepted', 'Ordine accettato',
      format('%s ha accettato l''ordine %s. Pronto verso le %s.', r.name, o.order_number,
             to_char(o.estimated_ready_at at time zone coalesce(r.timezone, 'Europe/Rome'), 'HH24:MI')), 'order_accepted');
    return jsonb_build_object('ok', true, 'status', o.status);

  elsif p_action = 'reject' then
    if o.status not in ('pending_restaurant', 'accepted') then raise exception 'Questo ordine non può più essere rifiutato.' using hint = 'INVALID_TRANSITION'; end if;
    v_reason := coalesce(p ->> 'reason', 'other');
    if v_reason not in ('too_busy', 'item_unavailable', 'closed', 'out_of_area', 'technical', 'other') then raise exception 'Motivo non valido.'; end if;
    v_label := public.order_reject_reason_label(v_reason) || coalesce(': ' || nullif(left(trim(coalesce(p ->> 'note', '')), 200), ''), '');
    update public.orders set status = 'rejected', rejected_at = now(), fulfillment_status = 'cancelled', reject_reason = v_label
     where id = o.id returning * into o;
    perform public.order_log(o.id, 'rejected', p_actor_type, p_actor, jsonb_build_object('reason', v_reason));
    perform public.log_event(o.restaurant_id, 'order_cancelled', 'server', jsonb_build_object('by', 'restaurant'));
    if o.payment_status in ('paid', 'partially_refunded') and v_auto_refund and o.amount_paid - o.amount_refunded > 0 then
      insert into public.order_refunds (order_id, amount, reason, requested_by, requested_by_type)
      values (o.id, o.amount_paid - o.amount_refunded - coalesce((select sum(amount) from public.order_refunds where order_id = o.id and status in ('pending', 'processing')), 0),
              'Ordine rifiutato dal ristorante', p_actor, case when p_actor_type = 'admin' then 'admin' else 'restaurant' end)
      returning id into v_refund;
      perform public.order_log(o.id, 'refund_requested', 'system', null, jsonb_build_object('reason', 'rejected'));
    end if;
    perform public.order_notify_customer(o, 'rejected', 'Ordine non accettato',
      format('%s non può preparare l''ordine %s (%s).%s', r.name, o.order_number, v_label,
             case when v_refund is not null then ' Il rimborso completo è in corso.' else '' end), 'order_rejected');
    return jsonb_build_object('ok', true, 'status', o.status, 'refund_pending', v_refund is not null);

  elsif p_action in ('preparing', 'ready', 'out_for_delivery', 'complete') then
    v_to := case p_action
      when 'preparing' then case when o.status = 'accepted' then 'preparing' end
      when 'ready' then case when o.status in ('accepted', 'preparing') then 'ready' end
      when 'out_for_delivery' then case when o.status in ('ready', 'preparing', 'accepted') and o.order_type = 'delivery' then 'out_for_delivery' end
      when 'complete' then case when (o.order_type = 'takeaway' and o.status in ('ready', 'preparing', 'accepted'))
                                  or (o.order_type = 'delivery' and o.status in ('out_for_delivery', 'ready')) then 'completed' end end;
    if v_to is null then raise exception 'Passaggio di stato non consentito.' using hint = 'INVALID_TRANSITION'; end if;
    update public.orders set status = v_to,
      preparing_at = case when v_to = 'preparing' then now() else preparing_at end,
      ready_at = case when v_to = 'ready' then now() else ready_at end,
      out_for_delivery_at = case when v_to = 'out_for_delivery' then now() else out_for_delivery_at end,
      picked_up_at = case when v_to = 'completed' and order_type = 'takeaway' then now() else picked_up_at end,
      completed_at = case when v_to = 'completed' then now() else completed_at end,
      fulfillment_status = case v_to when 'preparing' then 'preparing' when 'ready' then 'ready' when 'out_for_delivery' then 'out_for_delivery'
                           else case when order_type = 'takeaway' then 'picked_up' else 'delivered' end end
     where id = o.id returning * into o;
    perform public.order_log(o.id, case when v_to = 'completed' then 'completed' else v_to end, p_actor_type, p_actor, '{}'::jsonb);
    if v_to = 'preparing' then
      perform public.order_notify_customer(o, 'preparing', 'Ordine in preparazione', format('%s sta preparando il tuo ordine %s.', r.name, o.order_number), null);
    elsif v_to = 'ready' then
      perform public.order_notify_customer(o, 'ready',
        case when o.order_type = 'takeaway' then 'Ordine pronto per il ritiro' else 'Ordine pronto per la consegna' end,
        case when o.order_type = 'takeaway' then format('Il tuo ordine %s ti aspetta da %s.', o.order_number, r.name)
             else format('Il tuo ordine %s sta per partire.', o.order_number) end, 'order_ready');
    elsif v_to = 'out_for_delivery' then
      perform public.order_notify_customer(o, 'out', 'Il tuo ordine è in consegna', format('%s ha affidato l''ordine %s al fattorino.', r.name, o.order_number), null);
    elsif v_to = 'completed' then
      perform public.log_event(o.restaurant_id, 'order_completed', 'server', jsonb_build_object('order_type', o.order_type));
      perform public.order_notify_customer(o, 'completed', case when o.order_type = 'takeaway' then 'Ordine ritirato' else 'Ordine consegnato' end,
        'Grazie per aver ordinato con AsiaFood! Buon appetito.', null);
      if o.user_id is not null then
        perform public.loyalty_award(o.user_id, 'order_completed', 'order', o.id, 'Ordine completato da ' || r.name);
        perform public.referral_qualify(o.user_id);
        perform public.check_achievements(o.user_id);
        perform public.touch_activity(o.user_id);
      end if;
    end if;
    return jsonb_build_object('ok', true, 'status', o.status);

  elsif p_action = 'cancel' then
    -- Annullamento (Admin, cliente o automatico). Rimborso completo se pagato.
    if o.status in ('completed', 'rejected', 'cancelled', 'refunded') then raise exception 'L''ordine non può essere annullato.' using hint = 'INVALID_TRANSITION'; end if;
    v_label := coalesce(nullif(left(trim(coalesce(p ->> 'reason', '')), 200), ''), 'Annullato');
    update public.orders set status = 'cancelled', cancelled_at = now(), fulfillment_status = 'cancelled', cancel_reason = v_label
     where id = o.id returning * into o;
    perform public.order_log(o.id, 'cancelled', p_actor_type, p_actor, jsonb_build_object('reason', v_label));
    perform public.log_event(o.restaurant_id, 'order_cancelled', 'server', jsonb_build_object('by', p_actor_type));
    if o.payment_status in ('paid', 'partially_refunded') and o.amount_paid - o.amount_refunded > 0 and coalesce((p ->> 'refund')::boolean, true) then
      insert into public.order_refunds (order_id, amount, reason, requested_by, requested_by_type)
      values (o.id, o.amount_paid - o.amount_refunded - coalesce((select sum(amount) from public.order_refunds where order_id = o.id and status in ('pending', 'processing')), 0),
              'Ordine annullato: ' || v_label, p_actor, case when p_actor_type in ('customer', 'restaurant', 'admin') then p_actor_type else 'system' end)
      returning id into v_refund;
      perform public.order_log(o.id, 'refund_requested', 'system', null, jsonb_build_object('reason', 'cancelled'));
    end if;
    if p_actor_type <> 'customer' then
      perform public.order_notify_customer(o, 'cancelled', 'Ordine annullato',
        format('L''ordine %s è stato annullato (%s).%s', o.order_number, v_label, case when v_refund is not null then ' Il rimborso completo è in corso.' else '' end),
        'order_cancelled');
    end if;
    if p_actor_type in ('customer', 'system', 'admin') and o.paid_at is not null then
      perform public.order_notify_restaurant(o, 'cancelled', 'Ordine annullato ' || o.order_number, v_label);
    end if;
    return jsonb_build_object('ok', true, 'status', o.status, 'refund_pending', v_refund is not null);
  end if;
  raise exception 'Azione non valida.';
end $$;

-- Azioni del ristorante (owner/manager/staff) e dell'Admin
create or replace function public.order_action(p_order uuid, p_action text, p jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare o public.orders; v_uid uuid := auth.uid(); v_admin boolean := public.is_admin();
begin
  if v_uid is null then raise exception 'Accedi per continuare.' using errcode = '42501'; end if;
  select * into o from public.orders where id = p_order;
  if not found or not public.can_view_orders(o.restaurant_id) then raise exception 'Ordine non trovato.' using errcode = '42501'; end if;
  if p_action = 'note' then
    update public.orders set restaurant_notes = nullif(left(trim(coalesce(p ->> 'note', '')), 300), '') where id = p_order;
    perform public.order_log(p_order, 'note', case when v_admin then 'admin' else 'restaurant' end, v_uid, '{}'::jsonb);
    return jsonb_build_object('ok', true, 'status', o.status);
  end if;
  if p_action = 'cancel' and not v_admin then raise exception 'Solo lo staff AsiaFood può annullare un ordine accettato.' using errcode = '42501'; end if;
  if p_action not in ('accept', 'reject', 'preparing', 'ready', 'out_for_delivery', 'complete', 'cancel') then raise exception 'Azione non valida.'; end if;
  return public.order_transition(p_order, p_action, coalesce(p, '{}'::jsonb), case when v_admin and public.order_member_role(o.restaurant_id) is null then 'admin' else 'restaurant' end, v_uid);
end $$;

-- Verifica accesso cliente: proprietario autenticato oppure token ospite (hash). Limite ai tentativi falliti.
create or replace function public.order_access(p_number text, p_token text)
returns uuid language plpgsql security definer set search_path = public as $$
declare o public.orders; v_hash text;
begin
  if coalesce(p_number, '') !~ '^AF-[0-9]{6}-[A-Z0-9]{4}$' then return null; end if;
  if (select count(*) from public.order_track_failures where order_number = p_number and created_at > now() - interval '1 hour') >= 20 then
    raise exception 'Troppi tentativi: riprova più tardi.' using hint = 'RATE_LIMITED';
  end if;
  select * into o from public.orders where order_number = p_number;
  if not found then
    insert into public.order_track_failures (order_number) values (p_number);
    return null;
  end if;
  if auth.uid() is not null and o.user_id = auth.uid() then return o.id; end if;
  if auth.uid() is not null and public.is_admin() then return o.id; end if;
  if nullif(p_token, '') is not null then
    select access_token_hash into v_hash from public.order_secrets where order_id = o.id;
    if v_hash = public.order_hash_token(p_token) then return o.id; end if;
  end if;
  insert into public.order_track_failures (order_number) values (p_number);
  return null;
end $$;

-- Vista cliente dell'ordine (tracking): nessun dato interno (commissioni, risk flag, note interne)
create or replace function public.order_view(p_order uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare o public.orders; r public.restaurants; c public.cities;
begin
  select * into o from public.orders where id = p_order;
  select * into r from public.restaurants where id = o.restaurant_id;
  select * into c from public.cities where id = r.city_id;
  return jsonb_build_object(
    'id', o.id, 'order_number', o.order_number, 'order_type', o.order_type, 'status', o.status, 'payment_status', o.payment_status,
    'fulfillment_status', o.fulfillment_status,
    'restaurant', jsonb_build_object('id', r.id, 'name', r.name, 'slug', r.slug, 'address', r.address, 'city', c.name, 'phone', r.phone,
                                     'latitude', r.latitude, 'longitude', r.longitude,
                                     'pickup_instructions', (select pickup_instructions from public.restaurant_order_settings where restaurant_id = r.id)),
    'customer_name', o.customer_name, 'customer_phone', o.customer_phone, 'customer_email', o.customer_email,
    'delivery_address', o.delivery_address_snapshot,
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'menu_item_id', i.menu_item_id, 'name', i.menu_item_name_snapshot,
               'variant_id', i.variant_id, 'variant', i.variant_name_snapshot, 'quantity', i.quantity, 'unit_price', i.unit_price,
               'addons_total', i.addons_total, 'line_total', i.line_total, 'notes', i.notes,
               'options', coalesce((select jsonb_agg(jsonb_build_object('kind', x.kind, 'group', x.group_name, 'name', x.name_snapshot,
                             'price', x.price_snapshot, 'quantity', x.quantity) order by x.id) from public.order_item_options x where x.order_item_id = i.id), '[]'::jsonb))
             order by i.created_at, i.id) from public.order_items i where i.order_id = o.id), '[]'::jsonb),
    'subtotal', o.subtotal, 'coupon_discount', o.coupon_discount, 'loyalty_discount', o.loyalty_discount, 'discount_total', o.discount_total,
    'delivery_fee', o.delivery_fee, 'service_fee', o.service_fee, 'tax_total', o.tax_total, 'total', o.total, 'currency', o.currency,
    'coupon_code', o.coupon_code, 'amount_paid', o.amount_paid, 'amount_refunded', o.amount_refunded,
    'scheduled_for', o.scheduled_for, 'estimated_ready_at', o.estimated_ready_at, 'estimated_delivery_at', o.estimated_delivery_at,
    'preparation_minutes', o.preparation_minutes, 'customer_notes', o.customer_notes, 'reject_reason', o.reject_reason, 'cancel_reason', o.cancel_reason,
    'created_at', o.created_at, 'paid_at', o.paid_at, 'accepted_at', o.accepted_at, 'rejected_at', o.rejected_at, 'preparing_at', o.preparing_at,
    'ready_at', o.ready_at, 'picked_up_at', o.picked_up_at, 'out_for_delivery_at', o.out_for_delivery_at, 'completed_at', o.completed_at,
    'cancelled_at', o.cancelled_at,
    'can_cancel', o.status in ('pending_payment', 'payment_authorized', 'pending_restaurant'),
    'can_pay', o.status = 'pending_payment' and o.payment_status in ('unpaid', 'pending', 'failed'),
    'refunds', coalesce((select jsonb_agg(jsonb_build_object('amount', f.amount, 'status', f.status, 'created_at', f.created_at, 'processed_at', f.processed_at)
                  order by f.created_at) from public.order_refunds f where f.order_id = o.id and f.status <> 'cancelled'), '[]'::jsonb),
    'issues', coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'type', x.issue_type, 'status', x.status, 'resolution', x.resolution, 'created_at', x.created_at)
                  order by x.created_at) from public.order_issues x where x.order_id = o.id), '[]'::jsonb),
    'reviewable', o.status = 'completed' and o.user_id is not null,
    'is_owner', o.user_id is not null and o.user_id = auth.uid());
end $$;

create or replace function public.order_track(p_number text, p_token text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  v_id := public.order_access(p_number, p_token);
  if v_id is null then return null; end if;
  return public.order_view(v_id);
end $$;

-- Annullamento dal cliente: solo prima dell'accettazione (dopo: "Segnala un problema")
create or replace function public.order_customer_cancel(p_number text, p_token text default null, p_reason text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid; o public.orders;
begin
  v_id := public.order_access(p_number, p_token);
  if v_id is null then raise exception 'Ordine non trovato.' using errcode = '42501'; end if;
  select * into o from public.orders where id = v_id;
  if o.status not in ('pending_payment', 'payment_authorized', 'pending_restaurant') then
    raise exception 'Il ristorante ha già accettato l''ordine: per annullarlo usa «Segnala un problema».' using hint = 'INVALID_TRANSITION';
  end if;
  return public.order_transition(v_id, 'cancel', jsonb_build_object('reason', coalesce(nullif(left(trim(coalesce(p_reason, '')), 150), ''), 'Annullato dal cliente')),
                                 'customer', auth.uid()) || jsonb_build_object('order_id', v_id, 'payment_intent_id', o.stripe_payment_intent_id,
                                 'was_unpaid', o.payment_status not in ('paid', 'partially_refunded'));
end $$;

-- Segnala un problema (cliente, anche ospite con token)
create or replace function public.order_issue_create(p_number text, p_token text, p_type text, p_description text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; o public.orders; v_issue uuid;
begin
  v_id := public.order_access(p_number, p_token);
  if v_id is null then raise exception 'Ordine non trovato.' using errcode = '42501'; end if;
  select * into o from public.orders where id = v_id;
  if o.status = 'pending_payment' then raise exception 'L''ordine non è ancora stato pagato.'; end if;
  if (select count(*) from public.order_issues where order_id = v_id and created_at > now() - interval '1 day') >= 3 then
    raise exception 'Hai già inviato diverse segnalazioni per questo ordine: ti risponderemo al più presto.' using hint = 'RATE_LIMITED';
  end if;
  insert into public.order_issues (order_id, user_id, issue_type, description)
  values (v_id, auth.uid(), p_type, left(trim(coalesce(p_description, '')), 1000)) returning id into v_issue;
  perform public.order_log(v_id, 'issue_reported', 'customer', auth.uid(), jsonb_build_object('type', p_type));
  perform public.notify_admins('order_issue', 'Problema segnalato su un ordine', o.order_number, '/admin/orders?q=' || o.order_number);
  perform public.order_notify_restaurant(o, 'issue:' || v_issue, 'Problema segnalato · ' || o.order_number, 'Il cliente ha segnalato un problema: lo staff AsiaFood lo gestirà con te.');
  return v_issue;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  10. RIMBORSI (esecuzione su Stripe SOLO dal backend)
-- ════════════════════════════════════════════════════════════════════
-- Richiesta di rimborso manuale (ristorante owner/manager entro N giorni, Admin sempre). Chiamata dal backend.
create or replace function public.order_refund_request(p_actor uuid, p_order uuid, p_amount numeric, p_reason text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare o public.orders; v_admin boolean; v_avail numeric; v_id uuid; v_amount numeric := round(coalesce(p_amount, 0), 2);
begin
  perform public.assert_service();
  select * into o from public.orders where id = p_order for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'NOT_FOUND'); end if;
  v_admin := public.is_admin_user(p_actor);
  if not public.can_refund_orders(o.restaurant_id, p_actor) then return jsonb_build_object('ok', false, 'error', 'FORBIDDEN'); end if;
  if not v_admin and o.paid_at < now() - make_interval(days => public.billing_setting_int('order_restaurant_refund_days', 14)) then
    return jsonb_build_object('ok', false, 'error', 'REFUND_WINDOW_CLOSED');
  end if;
  if o.payment_status not in ('paid', 'partially_refunded') then return jsonb_build_object('ok', false, 'error', 'NOT_PAID'); end if;
  v_avail := o.amount_paid - o.amount_refunded - coalesce((select sum(amount) from public.order_refunds where order_id = o.id and status in ('pending', 'processing')), 0);
  if v_amount <= 0 or v_amount > v_avail then return jsonb_build_object('ok', false, 'error', 'AMOUNT_INVALID', 'available', v_avail); end if;
  if char_length(trim(coalesce(p_reason, ''))) < 3 then return jsonb_build_object('ok', false, 'error', 'REASON_REQUIRED'); end if;
  insert into public.order_refunds (order_id, amount, reason, requested_by, requested_by_type)
  values (o.id, v_amount, left(trim(p_reason), 300), p_actor, case when v_admin then 'admin' else 'restaurant' end) returning id into v_id;
  perform public.order_log(o.id, 'refund_requested', case when v_admin then 'admin' else 'restaurant' end, p_actor, jsonb_build_object('amount', v_amount));
  if v_admin then
    insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
    values (p_actor, 'order_refund', 'order', o.id::text, jsonb_build_object('amount', v_amount, 'reason', left(p_reason, 300)));
  end if;
  return jsonb_build_object('ok', true, 'refund_id', v_id, 'available_after', v_avail - v_amount);
end $$;

-- Il backend prende in carico i rimborsi in attesa (lock) e li esegue su Stripe
create or replace function public.order_refunds_claim(p_order uuid default null, p_limit int default 20)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v jsonb;
begin
  perform public.assert_service();
  with c as (
    select f.id from public.order_refunds f
     where (f.status = 'pending' or (f.status = 'processing' and f.processed_at is null and f.created_at < now() - interval '10 minutes'))
       and (p_order is null or f.order_id = p_order)
     order by f.created_at limit least(greatest(p_limit, 1), 100) for update skip locked
  ), u as (
    update public.order_refunds f set status = 'processing' from c where f.id = c.id returning f.*
  )
  select coalesce(jsonb_agg(jsonb_build_object('refund_id', u.id, 'order_id', u.order_id, 'amount_cents', round(u.amount * 100)::int,
           'payment_intent_id', o.stripe_payment_intent_id, 'payment_mode', o.payment_mode, 'full', u.amount >= o.amount_paid - o.amount_refunded,
           'order_number', o.order_number)), '[]'::jsonb)
    into v from u join public.orders o on o.id = u.order_id;
  return v;
end $$;

-- Esito del rimborso (dal backend dopo la chiamata Stripe o dal webhook charge.refunded / charge.refund.updated)
create or replace function public.order_refund_result(p_refund uuid, p_stripe_refund text, p_status text, p_error text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare f public.order_refunds; o public.orders; v_status text;
begin
  perform public.assert_service();
  select * into f from public.order_refunds where id = p_refund for update;
  if not found and p_stripe_refund is not null then select * into f from public.order_refunds where stripe_refund_id = p_stripe_refund for update; end if;
  if f.id is null then return jsonb_build_object('ok', false, 'error', 'NOT_FOUND'); end if;
  v_status := case when p_status in ('succeeded') then 'succeeded' when p_status in ('failed', 'canceled', 'cancelled') then 'failed'
                   when p_status in ('pending', 'requires_action', 'processing') then 'processing' else 'processing' end;
  if f.status = 'succeeded' and v_status <> 'failed' then return jsonb_build_object('ok', true, 'status', 'duplicate'); end if;
  update public.order_refunds set status = v_status, stripe_refund_id = coalesce(p_stripe_refund, stripe_refund_id),
         error_message = case when v_status = 'failed' then left(coalesce(p_error, 'Rimborso non riuscito'), 500) end,
         processed_at = case when v_status in ('succeeded', 'failed') then now() else processed_at end
   where id = f.id;
  select * into o from public.orders where id = f.order_id for update;
  if v_status = 'succeeded' and f.status <> 'succeeded' then
    update public.orders set amount_refunded = least(amount_paid, amount_refunded + f.amount) where id = o.id returning * into o;
    update public.orders set
      payment_status = case when o.amount_refunded >= o.amount_paid then 'refunded' else 'partially_refunded' end,
      status = case when status = 'completed' and o.amount_refunded >= o.amount_paid then 'refunded'
                    when status = 'completed' then 'partially_refunded' else status end
     where id = o.id returning * into o;
    perform public.order_log(o.id, 'refunded', 'stripe', null, jsonb_build_object('amount', f.amount));
    perform public.order_notify_customer(o, 'refund:' || f.id, 'Rimborso effettuato',
      format('Abbiamo rimborsato %s € per l''ordine %s. L''accredito sulla carta può richiedere alcuni giorni lavorativi.', to_char(f.amount, 'FM999990.00'), o.order_number),
      'order_refunded');
  elsif v_status = 'failed' and f.status <> 'failed' then
    perform public.order_log(o.id, 'refund_failed', 'stripe', null, jsonb_build_object('amount', f.amount));
    perform public.notify_admins('order_issue', 'Rimborso non riuscito', o.order_number, '/admin/orders?q=' || o.order_number);
  end if;
  return jsonb_build_object('ok', true, 'status', v_status, 'order_id', o.id);
end $$;

-- Rimborsi creati direttamente da Stripe Dashboard: registrati se non esistono
create or replace function public.order_refund_sync(p_payment_intent text, p_refunds jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare o public.orders; x jsonb; f public.order_refunds; n int := 0; v_id uuid;
begin
  perform public.assert_service();
  select * into o from public.orders where stripe_payment_intent_id = p_payment_intent;
  if not found then return jsonb_build_object('ok', false, 'error', 'NOT_FOUND'); end if;
  for x in select * from jsonb_array_elements(coalesce(p_refunds, '[]'::jsonb)) loop
    select * into f from public.order_refunds where stripe_refund_id = x ->> 'id';
    if f.id is null then
      insert into public.order_refunds (order_id, amount, reason, status, stripe_refund_id, requested_by_type)
      values (o.id, (x ->> 'amount')::numeric / 100, 'Rimborso registrato da Stripe', 'processing', x ->> 'id', 'admin') returning id into v_id;
    else
      v_id := f.id;
    end if;
    perform public.order_refund_result(v_id, x ->> 'id', x ->> 'status', x ->> 'failure_reason');
    n := n + 1;
  end loop;
  return jsonb_build_object('ok', true, 'synced', n, 'order_id', o.id);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  11. STRIPE CONNECT (onboarding gestito da Stripe)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.payout_context(p_user uuid, p_restaurant uuid, p_env text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.restaurants; a public.restaurant_payout_accounts; pr public.profiles;
begin
  perform public.assert_service();
  select * into r from public.restaurants where id = p_restaurant;
  if not found then return jsonb_build_object('ok', false, 'error', 'RESTAURANT_NOT_FOUND'); end if;
  if not (public.is_admin_user(p_user) or coalesce(public.order_member_role(p_restaurant, p_user) = 'owner', false)) then
    return jsonb_build_object('ok', false, 'error', 'FORBIDDEN');
  end if;
  select * into pr from public.profiles where id = p_user;
  select * into a from public.restaurant_payout_accounts where restaurant_id = p_restaurant and stripe_environment = p_env;
  return jsonb_build_object('ok', true, 'restaurant', jsonb_build_object('id', r.id, 'name', r.name, 'website', r.website),
    'email', pr.email, 'account', case when a.id is not null then to_jsonb(a) end);
end $$;

create or replace function public.payout_account_upsert(p_restaurant uuid, p_env text, p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.restaurant_payout_accounts; v_was boolean;
begin
  perform public.assert_service();
  select charges_enabled into v_was from public.restaurant_payout_accounts where stripe_account_id = p ->> 'stripe_account_id';
  insert into public.restaurant_payout_accounts (restaurant_id, stripe_account_id, stripe_environment, onboarding_completed, charges_enabled,
    payouts_enabled, details_submitted, requirements_due)
  values (p_restaurant, p ->> 'stripe_account_id', p_env, coalesce((p ->> 'details_submitted')::boolean and (p ->> 'charges_enabled')::boolean, false),
    coalesce((p ->> 'charges_enabled')::boolean, false), coalesce((p ->> 'payouts_enabled')::boolean, false),
    coalesce((p ->> 'details_submitted')::boolean, false),
    coalesce((select array_agg(x) from jsonb_array_elements_text(coalesce(p -> 'requirements_due', '[]'::jsonb)) x), '{}'))
  on conflict (restaurant_id, stripe_environment) do update set
    stripe_account_id = excluded.stripe_account_id, onboarding_completed = excluded.onboarding_completed,
    charges_enabled = excluded.charges_enabled, payouts_enabled = excluded.payouts_enabled,
    details_submitted = excluded.details_submitted, requirements_due = excluded.requirements_due
  returning * into a;
  if a.charges_enabled and not coalesce(v_was, false) then
    perform public.notify_restaurant(p_restaurant, 'payouts', 'Pagamenti online attivi', 'Il tuo account Stripe è verificato: puoi ricevere ordini pagati online.',
      format('/dashboard/restaurants/%s/payouts', p_restaurant));
  end if;
  return to_jsonb(a);
end $$;

-- account.updated (Connect): aggiorna lo stato per stripe_account_id
create or replace function public.payout_account_sync(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.restaurant_payout_accounts;
begin
  perform public.assert_service();
  select * into a from public.restaurant_payout_accounts where stripe_account_id = p ->> 'stripe_account_id';
  if not found then return jsonb_build_object('ok', false, 'error', 'NOT_FOUND'); end if;
  return public.payout_account_upsert(a.restaurant_id, a.stripe_environment, p);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  12. LETTURE: cliente, ristorante, Admin
-- ════════════════════════════════════════════════════════════════════
create or replace function public.my_orders(p_limit int default 20, p_offset int default 0)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'total', (select count(*) from public.orders where user_id = auth.uid() and not (status = 'pending_payment' and created_at < now() - interval '1 day')),
    'items', coalesce((select jsonb_agg(x order by x ->> 'created_at' desc) from (
      select jsonb_build_object('id', o.id, 'order_number', o.order_number, 'status', o.status, 'payment_status', o.payment_status,
               'order_type', o.order_type, 'total', o.total, 'created_at', o.created_at, 'scheduled_for', o.scheduled_for,
               'estimated_ready_at', o.estimated_ready_at,
               'restaurant', jsonb_build_object('id', r.id, 'name', r.name, 'slug', r.slug, 'logo_url', r.logo_url),
               'items_count', (select coalesce(sum(quantity), 0) from public.order_items i where i.order_id = o.id),
               'summary', (select string_agg(i.quantity || '× ' || i.menu_item_name_snapshot, ', ' order by i.created_at) from public.order_items i where i.order_id = o.id)) as x
        from public.orders o join public.restaurants r on r.id = o.restaurant_id
       where o.user_id = auth.uid() and not (o.status = 'pending_payment' and o.created_at < now() - interval '1 day')
       order by o.created_at desc
       limit least(greatest(coalesce(p_limit, 20), 1), 50) offset greatest(coalesce(p_offset, 0), 0)) s), '[]'::jsonb));
$$;

-- Terminale ordini del ristorante: dati personali solo finché servono (poi mascherati)
create or replace function public.restaurant_orders(p_restaurant uuid, p_tab text default 'new', p_limit int default 50)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_statuses text[]; v_tz text;
begin
  if not public.can_view_orders(p_restaurant) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  v_statuses := case p_tab
    when 'new' then array['pending_restaurant']
    when 'preparing' then array['accepted', 'preparing']
    when 'ready' then array['ready']
    when 'delivering' then array['out_for_delivery']
    when 'completed' then array['completed', 'refunded', 'partially_refunded']
    when 'cancelled' then array['rejected', 'cancelled']
    else array['pending_restaurant'] end;
  select coalesce(timezone, 'Europe/Rome') into v_tz from public.restaurants where id = p_restaurant;
  return jsonb_build_object(
    'counts', (select jsonb_build_object(
        'new', count(*) filter (where status = 'pending_restaurant'),
        'preparing', count(*) filter (where status in ('accepted', 'preparing')),
        'ready', count(*) filter (where status = 'ready'),
        'delivering', count(*) filter (where status = 'out_for_delivery'),
        'completed', count(*) filter (where status in ('completed', 'refunded', 'partially_refunded') and completed_at > now() - interval '1 day'),
        'cancelled', count(*) filter (where status in ('rejected', 'cancelled') and paid_at is not null and coalesce(rejected_at, cancelled_at) > now() - interval '1 day'))
      from public.orders where restaurant_id = p_restaurant and status <> 'pending_payment'),
    'can_refund', public.can_refund_orders(p_restaurant),
    'items', coalesce((select jsonb_agg(x) from (
      select jsonb_build_object(
        'id', o.id, 'order_number', o.order_number, 'status', o.status, 'payment_status', o.payment_status, 'order_type', o.order_type,
        'created_at', o.created_at, 'paid_at', o.paid_at, 'scheduled_for', o.scheduled_for, 'estimated_ready_at', o.estimated_ready_at,
        'estimated_delivery_at', o.estimated_delivery_at, 'accepted_at', o.accepted_at, 'ready_at', o.ready_at,
        'preparation_minutes', o.preparation_minutes,
        -- Dati del cliente: completi solo per ordini attivi o chiusi da meno di 24 ore
        'customer_name', case when o.status in ('pending_restaurant', 'accepted', 'preparing', 'ready', 'out_for_delivery')
                                or coalesce(o.completed_at, o.rejected_at, o.cancelled_at, o.created_at) > now() - interval '24 hours'
                              then o.customer_name else split_part(o.customer_name, ' ', 1) end,
        'customer_phone', case when o.status in ('pending_restaurant', 'accepted', 'preparing', 'ready', 'out_for_delivery')
                                or coalesce(o.completed_at, o.rejected_at, o.cancelled_at, o.created_at) > now() - interval '24 hours'
                              then o.customer_phone end,
        'delivery_address', case when o.order_type = 'delivery' and (o.status in ('pending_restaurant', 'accepted', 'preparing', 'ready', 'out_for_delivery')
                                or coalesce(o.completed_at, o.rejected_at, o.cancelled_at, o.created_at) > now() - interval '24 hours')
                              then o.delivery_address_snapshot - 'latitude' - 'longitude' - 'geocode_source' end,
        'delivery_distance_km', o.delivery_distance_km,
        'customer_notes', o.customer_notes, 'restaurant_notes', o.restaurant_notes,
        'subtotal', o.subtotal, 'discount_total', o.discount_total, 'delivery_fee', o.delivery_fee, 'service_fee', o.service_fee, 'total', o.total,
        'coupon_code', o.coupon_code, 'platform_fee', o.platform_fee, 'restaurant_gross', o.restaurant_gross, 'restaurant_net_estimated', o.restaurant_net_estimated,
        'amount_paid', o.amount_paid, 'amount_refunded', o.amount_refunded, 'reject_reason', o.reject_reason, 'cancel_reason', o.cancel_reason,
        'is_repeat_customer', o.user_id is not null and exists (select 1 from public.orders y where y.user_id = o.user_id and y.restaurant_id = o.restaurant_id
                                and y.id <> o.id and y.status = 'completed'),
        'items', coalesce((select jsonb_agg(jsonb_build_object('name', i.menu_item_name_snapshot, 'variant', i.variant_name_snapshot, 'quantity', i.quantity,
                   'line_total', i.line_total, 'notes', i.notes,
                   'options', coalesce((select jsonb_agg(jsonb_build_object('group', y.group_name, 'name', y.name_snapshot, 'quantity', y.quantity) order by y.id)
                                         from public.order_item_options y where y.order_item_id = i.id), '[]'::jsonb)) order by i.created_at, i.id)
                  from public.order_items i where i.order_id = o.id), '[]'::jsonb),
        'refunds', coalesce((select jsonb_agg(jsonb_build_object('amount', f.amount, 'status', f.status, 'reason', f.reason, 'created_at', f.created_at) order by f.created_at)
                  from public.order_refunds f where f.order_id = o.id), '[]'::jsonb),
        'open_issues', (select count(*) from public.order_issues x where x.order_id = o.id and x.status in ('open', 'in_progress'))) as x
      from public.orders o
      where o.restaurant_id = p_restaurant and o.status = any(v_statuses)
        and (p_tab not in ('completed', 'cancelled') or o.created_at > now() - interval '7 days')
        and (p_tab <> 'cancelled' or o.paid_at is not null)
      order by case when p_tab in ('completed', 'cancelled') then extract(epoch from o.created_at) * -1
                    else extract(epoch from coalesce(o.scheduled_for, o.estimated_ready_at, o.created_at)) end
      limit least(greatest(coalesce(p_limit, 50), 1), 200)) s), '[]'::jsonb));
end $$;

create or replace function public.admin_orders(p jsonb default '{}'::jsonb)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_q text := nullif(trim(coalesce(p ->> 'q', '')), ''); v_limit int := least(greatest(coalesce((p ->> 'limit')::int, 50), 1), 200);
        v_offset int := greatest(coalesce((p ->> 'offset')::int, 0), 0);
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  return (with f as (
    select o.*, r.name as restaurant_name, r.slug as restaurant_slug, c.name as city_name
      from public.orders o join public.restaurants r on r.id = o.restaurant_id left join public.cities c on c.id = r.city_id
     where (nullif(p ->> 'status', '') is null or o.status = p ->> 'status')
       and (nullif(p ->> 'payment_status', '') is null or o.payment_status = p ->> 'payment_status')
       and (nullif(p ->> 'order_type', '') is null or o.order_type = p ->> 'order_type')
       and (nullif(p ->> 'restaurant_id', '') is null or o.restaurant_id::text = p ->> 'restaurant_id')
       and (nullif(p ->> 'city_id', '') is null or r.city_id::text = p ->> 'city_id')
       and (nullif(p ->> 'from', '') is null or o.created_at >= (p ->> 'from')::date)
       and (nullif(p ->> 'to', '') is null or o.created_at < (p ->> 'to')::date + 1)
       and (coalesce((p ->> 'issues')::boolean, false) = false or exists (select 1 from public.order_issues x where x.order_id = o.id and x.status in ('open', 'in_progress'))
            or cardinality(o.risk_flags) > 0)
       and (v_q is null or o.order_number ilike '%' || v_q || '%' or r.name ilike '%' || v_q || '%' or o.customer_email ilike '%' || v_q || '%')
  )
  select jsonb_build_object('total', (select count(*) from f),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'order_number', order_number, 'restaurant', jsonb_build_object('id', restaurant_id, 'name', restaurant_name, 'slug', restaurant_slug),
        'city', city_name, 'customer_name', customer_name, 'order_type', order_type, 'total', total, 'status', status, 'payment_status', payment_status,
        'platform_fee', platform_fee, 'service_fee', service_fee, 'amount_refunded', amount_refunded, 'risk_flags', risk_flags, 'created_at', created_at,
        'open_issues', (select count(*) from public.order_issues x where x.order_id = f.id and x.status in ('open', 'in_progress'))) order by created_at desc)
      from (select * from f order by created_at desc limit v_limit offset v_offset) f), '[]'::jsonb)));
end $$;

create or replace function public.admin_order_detail(p_order uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare o public.orders;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into o from public.orders where id = p_order;
  if not found then return null; end if;
  return public.order_view(p_order) || jsonb_build_object(
    'internal', jsonb_build_object('commission_percent', o.commission_percent, 'commission_fixed', o.commission_fixed, 'platform_fee', o.platform_fee,
      'restaurant_gross', o.restaurant_gross, 'restaurant_net_estimated', o.restaurant_net_estimated, 'payment_processing_fee', o.payment_processing_fee,
      'payment_mode', o.payment_mode, 'payout_destination', o.payout_destination, 'stripe_environment', o.stripe_environment,
      'stripe_payment_intent_id', o.stripe_payment_intent_id, 'stripe_charge_id', o.stripe_charge_id, 'payment_failures', o.payment_failures,
      'risk_flags', o.risk_flags, 'internal_notes', o.internal_notes, 'restaurant_notes', o.restaurant_notes, 'source', o.source,
      'user_id', o.user_id, 'delivery_distance_km', o.delivery_distance_km),
    'events', coalesce((select jsonb_agg(jsonb_build_object('type', e.event_type, 'actor', e.actor_type, 'metadata', e.metadata, 'created_at', e.created_at) order by e.created_at, e.id)
                        from public.order_events e where e.order_id = o.id), '[]'::jsonb),
    'refunds_admin', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'amount', f.amount, 'status', f.status, 'reason', f.reason, 'stripe_refund_id', f.stripe_refund_id,
                        'error', f.error_message, 'requested_by_type', f.requested_by_type, 'created_at', f.created_at, 'processed_at', f.processed_at) order by f.created_at)
                        from public.order_refunds f where f.order_id = o.id), '[]'::jsonb),
    'issues_admin', coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'type', x.issue_type, 'description', x.description, 'status', x.status,
                        'resolution', x.resolution, 'created_at', x.created_at) order by x.created_at) from public.order_issues x where x.order_id = o.id), '[]'::jsonb));
end $$;

create or replace function public.admin_order_update(p_order uuid, p jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p ? 'internal_notes' then
    update public.orders set internal_notes = nullif(left(trim(coalesce(p ->> 'internal_notes', '')), 1000), '') where id = p_order;
    perform public.order_log(p_order, 'internal_note', 'admin', auth.uid(), '{}'::jsonb);
  end if;
  if p ? 'issue_id' then
    update public.order_issues set status = coalesce(nullif(p ->> 'issue_status', ''), status),
           resolution = coalesce(nullif(left(trim(coalesce(p ->> 'resolution', '')), 1000), ''), resolution)
     where id = (p ->> 'issue_id')::uuid and order_id = p_order;
    perform public.order_log(p_order, 'issue_updated', 'admin', auth.uid(), jsonb_build_object('status', p ->> 'issue_status'));
  end if;
  perform public.audit_admin('order_update', 'order', p_order::text, p - 'internal_notes');
end $$;

-- ════════════════════════════════════════════════════════════════════
--  13. OPERATIVITÀ RISTORANTE: pausa, occupato, disponibilità piatti
-- ════════════════════════════════════════════════════════════════════
create or replace function public.order_set_pause(p_restaurant uuid, p_kind text, p_minutes int)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_until timestamptz; s public.restaurant_order_settings;
begin
  if not public.can_view_orders(p_restaurant) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p_kind not in ('all', 'delivery', 'takeaway', 'busy') then raise exception 'Tipo non valido.'; end if;
  if p_kind = 'busy' then
    if p_minutes is null or p_minutes not between 0 and 180 then raise exception 'Minuti non validi (0–180).'; end if;
    update public.restaurant_order_settings set busy_extra_minutes = p_minutes where restaurant_id = p_restaurant returning * into s;
  else
    v_until := case when p_minutes is null then 'infinity'::timestamptz when p_minutes <= 0 then null
                    when p_minutes <= 1440 then now() + make_interval(mins => p_minutes) else null end;
    update public.restaurant_order_settings set
      orders_paused_until = case when p_kind = 'all' then v_until else orders_paused_until end,
      delivery_paused_until = case when p_kind = 'delivery' then v_until else delivery_paused_until end,
      takeaway_paused_until = case when p_kind = 'takeaway' then v_until else takeaway_paused_until end
     where restaurant_id = p_restaurant returning * into s;
  end if;
  if s.id is null then raise exception 'Configura prima gli ordini online.'; end if;
  return jsonb_build_object('orders_paused_until', s.orders_paused_until, 'delivery_paused_until', s.delivery_paused_until,
                            'takeaway_paused_until', s.takeaway_paused_until, 'busy_extra_minutes', s.busy_extra_minutes);
end $$;

-- "Non disponibile oggi" (torna disponibile domani) / disattiva / riattiva: anche lo staff
create or replace function public.set_menu_item_availability(p_item uuid, p_mode text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare it public.menu_items; v_tz text; v_prev text;
begin
  select * into it from public.menu_items where id = p_item;
  if not found or not public.can_view_orders(it.restaurant_id) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select coalesce(timezone, 'Europe/Rome') into v_tz from public.restaurants where id = it.restaurant_id;
  if p_mode = 'today' then
    update public.menu_items set unavailable_until = (((now() at time zone v_tz)::date + 1)::timestamp) at time zone v_tz where id = p_item returning * into it;
  elsif p_mode = 'off' then
    update public.menu_items set is_available = false, unavailable_until = null where id = p_item returning * into it;
  elsif p_mode = 'on' then
    update public.menu_items set is_available = true, unavailable_until = null where id = p_item returning * into it;
  else
    raise exception 'Modalità non valida.';
  end if;
  return jsonb_build_object('id', it.id, 'is_available', it.is_available, 'unavailable_until', it.unavailable_until);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  14. CARRELLO SALVATO (utenti registrati)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.cart_save(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_cart uuid; e jsonb; a jsonb; v_item uuid; v_rest uuid;
begin
  if v_uid is null then raise exception 'Accedi per salvare il carrello.' using errcode = '42501'; end if;
  if jsonb_typeof(p -> 'items') <> 'array' or jsonb_array_length(p -> 'items') = 0 or coalesce(p ->> 'restaurant_id', '') !~* '^[0-9a-f-]{36}$' then
    update public.carts set status = 'cleared' where user_id = v_uid and status = 'active';
    return null;
  end if;
  if jsonb_array_length(p -> 'items') > 50 then raise exception 'Carrello troppo grande.'; end if;
  v_rest := (p ->> 'restaurant_id')::uuid;
  select id into v_cart from public.carts where user_id = v_uid and status = 'active';
  if v_cart is not null and (select restaurant_id from public.carts where id = v_cart) <> v_rest then
    update public.carts set status = 'cleared' where id = v_cart; v_cart := null;
  end if;
  if v_cart is null then
    insert into public.carts (user_id, restaurant_id) values (v_uid, v_rest) returning id into v_cart;
  else
    update public.carts set updated_at = now() where id = v_cart;
    delete from public.cart_items where cart_id = v_cart;
  end if;
  for e in select * from jsonb_array_elements(p -> 'items') loop
    if coalesce(e ->> 'menu_item_id', '') !~* '^[0-9a-f-]{36}$'
       or not exists (select 1 from public.menu_items where id = (e ->> 'menu_item_id')::uuid and restaurant_id = v_rest) then continue; end if;
    insert into public.cart_items (cart_id, menu_item_id, variant_id, option_ids, quantity, unit_price_snapshot, notes)
    values (v_cart, (e ->> 'menu_item_id')::uuid,
      case when coalesce(e ->> 'variant_id', '') ~* '^[0-9a-f-]{36}$' and exists (select 1 from public.menu_item_variants where id = (e ->> 'variant_id')::uuid) then (e ->> 'variant_id')::uuid end,
      coalesce((select array_agg(x::uuid) from jsonb_array_elements_text(case when jsonb_typeof(e -> 'options') = 'array' then e -> 'options' else '[]' end) x
                where x ~* '^[0-9a-f-]{36}$' and exists (select 1 from public.menu_options o where o.id = x::uuid)), '{}'),
      greatest(least(coalesce((e ->> 'quantity')::int, 1), 20), 1),
      case when (e ->> 'unit_price') ~ '^[0-9]+(\.[0-9]+)?$' then least((e ->> 'unit_price')::numeric, 9999) end,
      nullif(left(trim(coalesce(e ->> 'notes', '')), 200), ''))
    returning id into v_item;
    for a in select * from jsonb_array_elements(case when jsonb_typeof(e -> 'addons') = 'array' then e -> 'addons' else '[]' end) loop
      if coalesce(a ->> 'id', '') ~* '^[0-9a-f-]{36}$' and exists (select 1 from public.menu_item_addons where id = (a ->> 'id')::uuid) then
        insert into public.cart_item_addons (cart_item_id, addon_id, quantity) values (v_item, (a ->> 'id')::uuid, greatest(least(coalesce((a ->> 'quantity')::int, 1), 5), 1));
      end if;
    end loop;
  end loop;
  return v_cart;
end $$;

create or replace function public.cart_load()
returns jsonb language sql stable security definer set search_path = public as $$
  select case when c.id is null then null else jsonb_build_object('restaurant_id', c.restaurant_id, 'updated_at', c.updated_at,
    'items', coalesce((select jsonb_agg(jsonb_build_object('menu_item_id', i.menu_item_id, 'variant_id', i.variant_id, 'options', to_jsonb(i.option_ids),
      'quantity', i.quantity, 'notes', i.notes, 'unit_price', i.unit_price_snapshot,
      'addons', coalesce((select jsonb_agg(jsonb_build_object('id', a.addon_id, 'quantity', a.quantity)) from public.cart_item_addons a where a.cart_item_id = i.id), '[]'::jsonb))
      order by i.created_at) from public.cart_items i where i.cart_id = c.id), '[]'::jsonb)) end
  from (select * from public.carts where user_id = auth.uid() and status = 'active' limit 1) c
  right join (select 1) one on true;
$$;

-- ════════════════════════════════════════════════════════════════════
--  15. STATISTICHE (solo dati reali, nessun dato personale negli aggregati)
-- ════════════════════════════════════════════════════════════════════
-- Ordine "valido" (GMV): pagamento incassato e ordine non rifiutato/annullato.
-- Esclusi: non pagati, pagamenti falliti, rifiutati, annullati, rimborsati per intero.
create or replace function public.order_is_valid(o public.orders)
returns boolean language sql immutable as $$
  select o.payment_status in ('paid', 'partially_refunded') and o.status not in ('rejected', 'cancelled', 'refunded', 'pending_payment');
$$;

create or replace function public.marketplace_stats(p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_days int := least(greatest(coalesce(p_days, 30), 1), 365);
  v_since timestamptz := now() - make_interval(days => v_days);
  v_today timestamptz := date_trunc('day', now() at time zone 'Europe/Rome') at time zone 'Europe/Rome';
  v_month timestamptz := date_trunc('month', now() at time zone 'Europe/Rome') at time zone 'Europe/Rome';
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  return jsonb_build_object(
    'definitions', jsonb_build_object(
      'gmv', 'Valore lordo degli ordini validi (totale pagato dal cliente, incluse consegna e costo di servizio) prima delle commissioni. Validi = pagamento incassato e ordine non rifiutato, annullato o rimborsato per intero.',
      'revenue', 'Commissioni AsiaFood + costi di servizio maturati sugli ordini completati, al netto della quota rimborsata.',
      'aov', 'GMV diviso numero di ordini validi.',
      'refund_rate', 'Ordini pagati con almeno un rimborso riuscito, sul totale degli ordini pagati.',
      'funnel', 'Passi 1–4: eventi anonimi (una sessione può generarne più di uno). Passi 5–6: ordini reali.'),
    'orders_today', (select count(*) from public.orders o where o.created_at >= v_today and o.paid_at is not null),
    'orders_month', (select count(*) from public.orders o where o.created_at >= v_month and o.paid_at is not null),
    'orders_period', (select count(*) from public.orders o where o.created_at >= v_since and o.paid_at is not null),
    'valid_orders', (select count(*) from public.orders o where o.created_at >= v_since and public.order_is_valid(o)),
    'gmv', (select coalesce(sum(o.total), 0) from public.orders o where o.created_at >= v_since and public.order_is_valid(o)),
    'gmv_net_of_refunds', (select coalesce(sum(o.total - o.amount_refunded), 0) from public.orders o where o.created_at >= v_since and public.order_is_valid(o)),
    'aov', (select coalesce(round(avg(o.total), 2), 0) from public.orders o where o.created_at >= v_since and public.order_is_valid(o)),
    'completed', (select count(*) from public.orders o where o.created_at >= v_since and o.status in ('completed', 'partially_refunded', 'refunded')),
    'cancelled', (select count(*) from public.orders o where o.created_at >= v_since and o.status in ('cancelled', 'rejected') and o.paid_at is not null),
    'unpaid_expired', (select count(*) from public.orders o where o.created_at >= v_since and o.paid_at is null and o.status = 'cancelled'),
    'refund_rate', (select case when count(*) = 0 then 0 else round(count(*) filter (where o.amount_refunded > 0) * 100.0 / count(*), 1) end
                    from public.orders o where o.created_at >= v_since and o.paid_at is not null),
    'refunded_amount', (select coalesce(sum(o.amount_refunded), 0) from public.orders o where o.created_at >= v_since),
    'takeaway', (select count(*) from public.orders o where o.created_at >= v_since and public.order_is_valid(o) and o.order_type = 'takeaway'),
    'delivery', (select count(*) from public.orders o where o.created_at >= v_since and public.order_is_valid(o) and o.order_type = 'delivery'),
    'platform_revenue', (select coalesce(round(sum((o.platform_fee + o.service_fee) * case when o.amount_paid > 0 then 1 - o.amount_refunded / o.amount_paid else 0 end), 2), 0)
                         from public.orders o where o.created_at >= v_since and o.status in ('completed', 'partially_refunded')),
    'platform_fees_pending', (select coalesce(sum(o.platform_fee + o.service_fee), 0) from public.orders o where o.created_at >= v_since and public.order_is_valid(o)
                              and o.status not in ('completed', 'partially_refunded')),
    'payments', jsonb_build_object(
      'failed_attempts', (select coalesce(sum(o.payment_failures), 0) from public.orders o where o.created_at >= v_since),
      'awaiting_payment', (select count(*) from public.orders o where o.status = 'pending_payment' and o.created_at > now() - interval '1 hour'),
      'awaiting_restaurant', (select count(*) from public.orders o where o.status = 'pending_restaurant'),
      'refunds_pending', (select count(*) from public.order_refunds f where f.status in ('pending', 'processing')),
      'refunds_failed', (select count(*) from public.order_refunds f where f.status = 'failed' and f.created_at >= v_since),
      'disputes', (select count(*) from public.orders o where 'dispute' = any(o.risk_flags) and o.created_at >= v_since),
      'risk_flagged', (select count(*) from public.orders o where cardinality(o.risk_flags) > 0 and o.created_at >= v_since),
      'open_issues', (select count(*) from public.order_issues x where x.status in ('open', 'in_progress')),
      'webhook_failures', (select count(*) from public.stripe_events e where e.processing_status = 'failed' and e.created_at >= v_since
                             and (e.event_type like 'payment_intent.%' or e.event_type like 'charge.%'))),
    'top_categories', coalesce((select jsonb_agg(jsonb_build_object('name', name, 'orders', n, 'gmv', g) order by n desc) from (
        select k.name, count(distinct o.id) n, sum(o.total) g from public.orders o
          join public.restaurant_categories rc on rc.restaurant_id = o.restaurant_id and rc.is_primary
          join public.categories k on k.id = rc.category_id
         where o.created_at >= v_since and public.order_is_valid(o) group by k.name order by n desc limit 8) s), '[]'::jsonb),
    'top_cities', coalesce((select jsonb_agg(jsonb_build_object('name', name, 'orders', n, 'gmv', g) order by n desc) from (
        select c.name, count(*) n, sum(o.total) g from public.orders o join public.restaurants r on r.id = o.restaurant_id join public.cities c on c.id = r.city_id
         where o.created_at >= v_since and public.order_is_valid(o) group by c.name order by n desc limit 8) s), '[]'::jsonb),
    'daily', (select jsonb_agg(jsonb_build_object('day', to_char(d, 'YYYY-MM-DD'),
                'orders', (select count(*) from public.orders o where public.order_is_valid(o) and o.created_at >= d at time zone 'Europe/Rome' and o.created_at < (d + interval '1 day') at time zone 'Europe/Rome'),
                'gmv', (select coalesce(sum(o.total), 0) from public.orders o where public.order_is_valid(o) and o.created_at >= d at time zone 'Europe/Rome' and o.created_at < (d + interval '1 day') at time zone 'Europe/Rome'))
              order by d)
              from generate_series(date_trunc('day', now() at time zone 'Europe/Rome') - make_interval(days => least(v_days, 60) - 1),
                                   date_trunc('day', now() at time zone 'Europe/Rome'), interval '1 day') d),
    'funnel', jsonb_build_array(
      jsonb_build_object('step', 'restaurant_view', 'label', 'Visite scheda', 'events', (select count(*) from public.analytics_events where event_type = 'restaurant_view' and created_at >= v_since),
                         'sessions', (select count(distinct session_id) from public.analytics_events where event_type = 'restaurant_view' and created_at >= v_since and session_id is not null)),
      jsonb_build_object('step', 'menu_view', 'label', 'Menu visti', 'events', (select count(*) from public.analytics_events where event_type = 'menu_view' and created_at >= v_since),
                         'sessions', (select count(distinct session_id) from public.analytics_events where event_type = 'menu_view' and created_at >= v_since and session_id is not null)),
      jsonb_build_object('step', 'add_to_cart', 'label', 'Aggiunte al carrello', 'events', (select count(*) from public.analytics_events where event_type = 'add_to_cart' and created_at >= v_since),
                         'sessions', (select count(distinct session_id) from public.analytics_events where event_type = 'add_to_cart' and created_at >= v_since and session_id is not null)),
      jsonb_build_object('step', 'checkout_started', 'label', 'Checkout avviati', 'events', (select count(*) from public.analytics_events where event_type = 'checkout_started' and created_at >= v_since),
                         'sessions', (select count(distinct session_id) from public.analytics_events where event_type = 'checkout_started' and created_at >= v_since and session_id is not null)),
      jsonb_build_object('step', 'paid', 'label', 'Ordini pagati', 'events', (select count(*) from public.orders o where o.created_at >= v_since and o.paid_at is not null), 'sessions', null),
      jsonb_build_object('step', 'completed', 'label', 'Ordini completati', 'events', (select count(*) from public.orders o where o.created_at >= v_since and o.status in ('completed', 'partially_refunded', 'refunded')), 'sessions', null)),
    'abandoned_carts', (select count(*) from public.analytics_events where event_type = 'abandoned_cart' and created_at >= v_since));
end $$;

-- Statistiche ordini del ristoratore (solo il proprio locale, nessun dato personale)
create or replace function public.restaurant_order_stats(p_restaurant uuid, p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_since timestamptz := now() - make_interval(days => least(greatest(coalesce(p_days, 30), 1), 365));
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  return jsonb_build_object(
    'orders', (select count(*) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o)),
    'gross', (select coalesce(sum(o.restaurant_gross), 0) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o)),
    'commission', (select coalesce(sum(o.platform_fee), 0) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o)),
    'net_estimated', (select coalesce(sum(o.restaurant_net_estimated), 0) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o)),
    'aov', (select coalesce(round(avg(o.total), 2), 0) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o)),
    'takeaway', (select count(*) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o) and o.order_type = 'takeaway'),
    'delivery', (select count(*) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o) and o.order_type = 'delivery'),
    'cancel_rate', (select case when count(*) = 0 then 0 else round(count(*) filter (where o.status in ('rejected', 'cancelled')) * 100.0 / count(*), 1) end
                    from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and o.paid_at is not null),
    'repeat_customers', (select count(*) from (select o.user_id from public.orders o where o.restaurant_id = p_restaurant and o.user_id is not null
                          and public.order_is_valid(o) group by o.user_id having count(*) >= 2) x),
    'customers', (select count(distinct o.user_id) from public.orders o where o.restaurant_id = p_restaurant and o.user_id is not null and public.order_is_valid(o)),
    'coupon_orders', (select count(*) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o) and o.coupon_id is not null),
    'refunded', (select coalesce(sum(o.amount_refunded), 0) from public.orders o where o.restaurant_id = p_restaurant and o.created_at >= v_since),
    'top_items', coalesce((select jsonb_agg(jsonb_build_object('name', name, 'quantity', q, 'revenue', rev) order by q desc) from (
        select i.menu_item_name_snapshot as name, sum(i.quantity) q, sum(i.line_total) rev from public.order_items i join public.orders o on o.id = i.order_id
         where o.restaurant_id = p_restaurant and o.created_at >= v_since and public.order_is_valid(o) group by 1 order by 2 desc limit 8) s), '[]'::jsonb),
    'avg_prep_minutes', (select round(avg(extract(epoch from (o.ready_at - o.accepted_at)) / 60)) from public.orders o
                          where o.restaurant_id = p_restaurant and o.created_at >= v_since and o.ready_at is not null and o.accepted_at is not null));
end $$;

-- ════════════════════════════════════════════════════════════════════
--  16. SCHEDULER (ogni 5 minuti dal backend)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.orders_tick(p_now timestamptz default now())
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  x record; ox public.orders; v_expired int := 0; v_timeout int := 0; v_reminded int := 0; v_abandoned int := 0; v_cancel_pi jsonb := '[]'::jsonb;
  v_unpaid int := public.billing_setting_int('order_unpaid_expiry_minutes', 30);
  v_accept int := public.billing_setting_int('order_accept_timeout_minutes', 20);
  v_cart_h int := public.billing_setting_int('order_abandoned_cart_hours', 2);
  v_r jsonb;
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  -- 1) Ordini non pagati scaduti: annullati (il backend annulla anche il PaymentIntent su Stripe)
  for x in select * from public.orders where status = 'pending_payment' and created_at < p_now - make_interval(mins => v_unpaid) for update skip locked loop
    update public.orders set status = 'cancelled', cancelled_at = p_now, fulfillment_status = 'cancelled',
           payment_status = case when payment_status = 'pending' then 'failed' else payment_status end,
           cancel_reason = 'Pagamento non completato in tempo' where id = x.id;
    perform public.order_log(x.id, 'cancelled', 'system', null, jsonb_build_object('reason', 'payment_timeout'));
    if x.stripe_payment_intent_id is not null then v_cancel_pi := v_cancel_pi || to_jsonb(x.stripe_payment_intent_id); end if;
    v_expired := v_expired + 1;
  end loop;
  -- 2) Ordini non accettati in tempo: promemoria a metà tempo, poi annullamento con rimborso
  if v_accept > 0 then
    for ox in select * from public.orders where status = 'pending_restaurant' and paid_at < p_now - make_interval(mins => greatest(v_accept / 2, 1))
               and paid_at >= p_now - make_interval(mins => v_accept) and coalesce(scheduled_for, p_now) <= p_now + interval '2 hours' loop
      perform public.order_notify_restaurant(ox, 'reminder', 'Ordine in attesa ' || ox.order_number, 'Il cliente sta aspettando la conferma.');
      v_reminded := v_reminded + 1;
    end loop;
    for x in select id from public.orders where status = 'pending_restaurant' and paid_at < p_now - make_interval(mins => v_accept)
               and coalesce(scheduled_for, p_now) <= p_now + interval '2 hours' for update skip locked loop
      v_r := public.order_transition(x.id, 'cancel', jsonb_build_object('reason', 'Il ristorante non ha confermato in tempo'), 'system', null);
      v_timeout := v_timeout + 1;
    end loop;
  end if;
  -- 3) Carrelli abbandonati: solo statistica anonima (nessun promemoria marketing senza consenso)
  for x in select * from public.carts where status = 'active' and updated_at < p_now - make_interval(hours => v_cart_h) for update skip locked loop
    update public.carts set status = 'abandoned' where id = x.id;
    perform public.log_event(x.restaurant_id, 'abandoned_cart', 'server', '{}'::jsonb);
    v_abandoned := v_abandoned + 1;
  end loop;
  delete from public.order_track_failures where created_at < p_now - interval '1 day';
  return jsonb_build_object('expired', v_expired, 'accept_timeouts', v_timeout, 'reminders', v_reminded, 'abandoned_carts', v_abandoned,
                            'cancel_payment_intents', v_cancel_pi);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  17. INTEGRAZIONE FIDELIZZAZIONE: recensione verificata e invito dopo ordine completato
-- ════════════════════════════════════════════════════════════════════
create or replace function public.review_verification_for(p_user uuid, p_restaurant uuid, p_reservation uuid default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_days int := public.billing_setting_int('review_verification_window_days', 180); x record;
begin
  select id, reservation_date as d into x from public.reservations r
   where r.user_id = p_user and r.restaurant_id = p_restaurant and r.status = 'completed'
     and (p_reservation is null or r.id = p_reservation)
     and r.reservation_date >= (now() - make_interval(days => v_days))::date
     and not exists (select 1 from public.reviews v where v.reservation_id = r.id)
   order by r.reservation_date desc limit 1;
  if found then return jsonb_build_object('source', 'reservation', 'id', x.id, 'date', x.d); end if;
  if p_reservation is not null then return null; end if;
  select id, (completed_at at time zone 'Europe/Rome')::date as d into x from public.orders o
   where o.user_id = p_user and o.restaurant_id = p_restaurant and o.status in ('completed', 'partially_refunded')
     and o.completed_at >= now() - make_interval(days => v_days)
     and not exists (select 1 from public.reviews v where v.order_id = o.id)
   order by o.completed_at desc limit 1;
  if found then return jsonb_build_object('source', 'order', 'id', x.id, 'date', x.d); end if;
  select id, (redeemed_at at time zone 'Europe/Rome')::date as d into x from public.coupon_claims c
   where c.user_id = p_user and c.restaurant_id = p_restaurant and c.status = 'redeemed'
     and c.redeemed_at >= now() - make_interval(days => v_days)
     and not exists (select 1 from public.reviews v where v.coupon_claim_id = c.id)
   order by c.redeemed_at desc limit 1;
  if found then return jsonb_build_object('source', 'coupon', 'id', x.id, 'date', x.d); end if;
  return null;
end $$;

-- Collega l'ordine alla recensione verificata (stessa logica di submit_review, senza modificarne la firma)
create or replace function public.reviews_link_order()
returns trigger language plpgsql security definer set search_path = public as $$
declare v jsonb;
begin
  if new.is_verified and new.reservation_id is null and new.coupon_claim_id is null and new.order_id is null then
    v := public.review_verification_for(new.user_id, new.restaurant_id);
    if v ->> 'source' = 'order' then new.order_id := (v ->> 'id')::uuid; new.verification_source := 'order'; end if;
  end if;
  return new;
end $$;
create trigger reviews_link_order before insert on public.reviews for each row execute function public.reviews_link_order();

create or replace function public.referral_qualify(p_user uuid, p_force boolean default false)
returns boolean language plpgsql security definer set search_path = public as $$
declare x public.referrals; v_verified boolean; v_action boolean; a int; b int;
begin
  select * into x from public.referrals where referred_user_id = p_user and status = 'registered' for update;
  if not found then return false; end if;
  select coalesce(u.email_confirmed_at is not null, false) into v_verified from auth.users u where u.id = p_user;
  v_action := exists (select 1 from public.reservations where user_id = p_user and status = 'completed')
           or exists (select 1 from public.coupon_claims where user_id = p_user and status = 'redeemed')
           or exists (select 1 from public.orders where user_id = p_user and status in ('completed', 'partially_refunded'));
  if not p_force and not (coalesce(v_verified, false) and v_action) then return false; end if;
  update public.referrals set status = 'qualified', qualified_at = now() where id = x.id;
  a := public.loyalty_award(x.referrer_user_id, 'referral_completed', 'referral', x.id, 'Amico invitato: prima visita completata');
  b := public.loyalty_award(p_user, 'referral_welcome', 'referral', x.id, 'Bonus di benvenuto per l''invito');
  update public.referrals set status = 'rewarded', rewarded_at = now() where id = x.id;
  perform public.notify_user(x.referrer_user_id, 'referral', 'Invito completato',
    case when a > 0 then format('Il tuo amico ha completato la prima visita: +%s punti.', a) else 'Il tuo amico ha completato la prima visita.' end,
    '/profile/referrals', 'referral_updates', 'referral_done:' || x.id, '{}'::jsonb, null,
    'referral_completed', jsonb_build_object('points', a));
  return true;
end $$;

-- Richiesta di recensione dopo l'ordine completato (una sola volta, rispettando le preferenze)
create or replace function public.orders_review_request()
returns trigger language plpgsql security definer set search_path = public as $$
declare r public.restaurants;
begin
  if new.status = 'completed' and old.status is distinct from 'completed' and new.user_id is not null
     and not public.is_restaurant_insider(new.user_id, new.restaurant_id)
     -- al massimo una richiesta ogni 7 giorni per lo stesso ristorante (niente insistenza)
     and not exists (select 1 from public.notifications n where n.user_id = new.user_id and n.restaurant_id = new.restaurant_id
                     and n.type = 'review' and n.created_at > now() - interval '7 days')
     and not exists (select 1 from public.reviews v where v.user_id = new.user_id and v.restaurant_id = new.restaurant_id
                     and v.status in ('published', 'pending', 'flagged') and v.created_at > now() - make_interval(days => public.billing_setting_int('review_cooldown_days', 90))) then
    select * into r from public.restaurants where id = new.restaurant_id;
    perform public.notify_user(new.user_id, 'review', 'Com’è andato il tuo ordine da ' || r.name || '?',
      'Racconta la tua esperienza: la tua recensione aiuta altre persone a scegliere.',
      '/ristorante/' || r.slug || '?review=1#recensioni', 'reservation_updates', 'review_request_order:' || new.id,
      jsonb_build_object('order_id', new.id), r.id, 'review_request', jsonb_build_object('restaurant', r.name, 'restaurant_slug', r.slug));
  end if;
  return null;
end $$;
create trigger orders_review_request after update of status on public.orders for each row execute function public.orders_review_request();

-- ════════════════════════════════════════════════════════════════════
--  18. ANALYTICS: nuovi eventi (le conversioni restano solo lato server)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.track_event(
  p_restaurant_id uuid,
  p_event_type public.analytics_event_type,
  p_session_id text default null,
  p_source text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_type text := case p_event_type::text
    when 'view' then 'restaurant_view' when 'click_phone' then 'phone_click' when 'click_whatsapp' then 'whatsapp_click'
    when 'click_directions' then 'directions_click' when 'click_menu' then 'menu_view' when 'click_reservation' then 'reservation_start'
    when 'click_website' then 'website_click' when 'click_social' then 'social_click' when 'coupon_reveal' then 'offer_view'
    else p_event_type::text end;
  v_meta jsonb := coalesce(p_metadata, '{}'::jsonb);
  k text;
begin
  -- Conversioni, impression sponsorizzate ed eventi di pagamento/ordine: solo lato server
  if v_type in ('reservation_completed', 'coupon_claim', 'coupon_redeem', 'sponsored_impression', 'sponsored_click',
                'payment_success', 'payment_failed', 'order_created', 'order_accepted', 'order_completed', 'order_cancelled', 'abandoned_cart') then return; end if;
  if p_restaurant_id is null then
    if v_type <> 'map_view' and v_type not like 'ai\_%' then return; end if;
  elsif not exists (select 1 from public.restaurants where id = p_restaurant_id and is_active) then
    return;
  end if;
  if jsonb_typeof(v_meta) <> 'object' then v_meta := '{}'::jsonb; end if;
  for k in select jsonb_object_keys(v_meta) loop
    if k ~* '(lat|lng|lon|coord|position|location|address|email|phone|name|message|text|query)' then v_meta := v_meta - k; end if;
  end loop;
  if pg_column_size(v_meta) > 2000 then v_meta := '{}'::jsonb; end if;
  insert into public.analytics_events (restaurant_id, event_type, user_id, session_id, source, metadata)
  values (p_restaurant_id, v_type::public.analytics_event_type, null, left(p_session_id, 64), left(p_source, 40), v_meta);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  19. RLS E PRIVILEGI
-- ════════════════════════════════════════════════════════════════════
alter table public.menu_option_groups            enable row level security;
alter table public.menu_options                  enable row level security;
alter table public.restaurant_order_settings     enable row level security;
alter table public.delivery_zones                enable row level security;
alter table public.restaurant_payout_accounts    enable row level security;
alter table public.restaurant_commission_settings enable row level security;
alter table public.customer_addresses            enable row level security;
alter table public.carts                         enable row level security;
alter table public.cart_items                    enable row level security;
alter table public.cart_item_addons              enable row level security;
alter table public.orders                        enable row level security;
alter table public.order_secrets                 enable row level security;
alter table public.order_items                   enable row level security;
alter table public.order_item_options            enable row level security;
alter table public.order_events                  enable row level security;
alter table public.order_refunds                 enable row level security;
alter table public.order_issues                  enable row level security;
alter table public.order_realtime                enable row level security;
alter table public.order_rate_limits             enable row level security;
alter table public.order_track_failures          enable row level security;

-- Opzioni del menu: come i piatti (pubbliche se il piatto è pubblico), scrittura owner/manager
create policy "menu_option_groups_read" on public.menu_option_groups for select using (
  public.can_manage_restaurant(restaurant_id) or (is_active and exists (select 1 from public.menu_items i where i.id = menu_item_id and public.menu_category_is_public(i.menu_category_id))));
create policy "menu_option_groups_write" on public.menu_option_groups for all to authenticated
  using (public.can_manage_restaurant(restaurant_id)) with check (public.can_manage_restaurant(restaurant_id));
create policy "menu_options_read" on public.menu_options for select using (
  public.can_manage_restaurant(restaurant_id) or exists (select 1 from public.menu_option_groups g join public.menu_items i on i.id = g.menu_item_id
    where g.id = option_group_id and g.is_active and public.menu_category_is_public(i.menu_category_id)));
create policy "menu_options_write" on public.menu_options for all to authenticated
  using (public.can_manage_restaurant(restaurant_id)) with check (public.can_manage_restaurant(restaurant_id));

-- Configurazione ordini e zone: lettura pubblica (nessun dato sensibile), scrittura owner/manager/Admin
create policy "order_settings_read" on public.restaurant_order_settings for select using (public.restaurant_is_public(restaurant_id) or public.can_view_orders(restaurant_id));
create policy "order_settings_write" on public.restaurant_order_settings for all to authenticated
  using (public.can_manage_restaurant(restaurant_id)) with check (public.can_manage_restaurant(restaurant_id));
create policy "delivery_zones_read" on public.delivery_zones for select using (public.restaurant_is_public(restaurant_id) or public.can_view_orders(restaurant_id));
create policy "delivery_zones_write" on public.delivery_zones for all to authenticated
  using (public.can_manage_restaurant(restaurant_id)) with check (public.can_manage_restaurant(restaurant_id));

-- Stripe Connect: il titolare vede lo stato (scritture solo dal backend)
create policy "payout_accounts_read" on public.restaurant_payout_accounts for select to authenticated using (public.can_manage_restaurant(restaurant_id));
-- Commissioni: trasparenza per il titolare, gestione solo Admin
create policy "commission_read" on public.restaurant_commission_settings for select to authenticated using (public.can_manage_restaurant(restaurant_id));
create policy "commission_admin" on public.restaurant_commission_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Indirizzi e carrelli: solo il proprietario
create policy "addresses_own" on public.customer_addresses for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "carts_own" on public.carts for select to authenticated using (user_id = auth.uid());
create policy "cart_items_own" on public.cart_items for select to authenticated using (exists (select 1 from public.carts c where c.id = cart_id and c.user_id = auth.uid()));
create policy "cart_item_addons_own" on public.cart_item_addons for select to authenticated using (exists (
  select 1 from public.cart_items i join public.carts c on c.id = i.cart_id where i.id = cart_item_id and c.user_id = auth.uid()));

-- Ordini: il cliente legge i propri, l'Admin tutti. Il ristorante passa da restaurant_orders() (dati minimizzati).
-- Nessun INSERT/UPDATE/DELETE dal client: solo RPC. Gli ospiti non possono interrogare la tabella (solo order_track con token).
create policy "orders_customer_read" on public.orders for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "order_items_read" on public.order_items for select to authenticated using (
  exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));
create policy "order_item_options_read" on public.order_item_options for select to authenticated using (
  exists (select 1 from public.order_items i join public.orders o on o.id = i.order_id where i.id = order_item_id and (o.user_id = auth.uid() or public.is_admin())));
create policy "order_events_admin" on public.order_events for select to authenticated using (public.is_admin());
create policy "order_refunds_read" on public.order_refunds for select to authenticated using (
  public.is_admin() or exists (select 1 from public.orders o where o.id = order_id and public.can_refund_orders(o.restaurant_id)));
create policy "order_issues_read" on public.order_issues for select to authenticated using (
  user_id = auth.uid() or public.is_admin() or exists (select 1 from public.orders o where o.id = order_id and public.can_view_orders(o.restaurant_id)));
-- Canale realtime: il cliente vede i propri ordini, lo staff quelli del proprio locale (solo id e stato)
create policy "order_realtime_read" on public.order_realtime for select to authenticated using (
  user_id = auth.uid() or public.can_view_orders(restaurant_id));
-- order_secrets, order_rate_limits, order_track_failures: nessuna policy → nessun accesso dal client

grant select on public.menu_option_groups, public.menu_options, public.restaurant_order_settings, public.delivery_zones to anon, authenticated;
grant insert, update, delete on public.menu_option_groups, public.menu_options, public.restaurant_order_settings, public.delivery_zones to authenticated;
grant select on public.restaurant_payout_accounts to authenticated;
grant select, insert on public.restaurant_commission_settings to authenticated;
grant select, insert, update, delete on public.customer_addresses to authenticated;
grant select on public.carts, public.cart_items, public.cart_item_addons to authenticated;
grant select on public.orders, public.order_items, public.order_item_options, public.order_events, public.order_refunds, public.order_issues, public.order_realtime to authenticated;
revoke all on public.order_secrets, public.order_rate_limits, public.order_track_failures from anon, authenticated;
revoke insert, update, delete on public.orders, public.order_items, public.order_item_options, public.order_events, public.order_refunds,
  public.order_issues, public.order_realtime, public.carts, public.cart_items, public.cart_item_addons, public.restaurant_payout_accounts from anon, authenticated;

-- Funzioni solo backend (service_role)
do $$ declare f text;
begin
  foreach f in array array[
    'order_rate_check(text, text, int, int)', 'order_create(jsonb, uuid, text, text, text, text)', 'order_attach_payment(uuid, text, text)',
    'order_payment_event(jsonb)', 'order_refund_request(uuid, uuid, numeric, text)', 'order_refunds_claim(uuid, int)',
    'order_refund_result(uuid, text, text, text)', 'order_refund_sync(text, jsonb)', 'payout_context(uuid, uuid, text)',
    'payout_account_upsert(uuid, text, jsonb)', 'payout_account_sync(jsonb)', 'order_quote_core(jsonb, uuid, text)',
    'order_transition(uuid, text, jsonb, text, uuid)', 'order_apply_paid(public.orders)', 'order_notify_customer(public.orders, text, text, text, text)',
    'order_notify_restaurant(public.orders, text, text, text)', 'order_log(uuid, text, text, uuid, jsonb)', 'order_new_number(text)',
    'order_validate_code(uuid, text, uuid, text, numeric, timestamptz)', 'order_view(uuid)', 'order_access(text, text)', 'is_admin_user(uuid)',
    'order_payment_setup(uuid)', 'order_commission_for(uuid, timestamptz)', 'order_set_token(uuid, text)', 'order_payment_info(uuid)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;
revoke all on function public.orders_tick(timestamptz) from public, anon;
grant execute on function public.orders_tick(timestamptz) to authenticated, service_role;

-- Funzioni pubbliche/utente (controlli interni)
grant execute on function public.order_quote(jsonb), public.order_public_info(uuid), public.orderable_restaurants(),
  public.restaurants_delivering_to(double precision, double precision), public.order_slots(uuid, date, text), public.order_next_slot(uuid, text),
  public.order_track(text, text), public.order_customer_cancel(text, text, text), public.order_issue_create(text, text, text, text)
  to anon, authenticated, service_role;
grant execute on function public.order_action(uuid, text, jsonb), public.my_orders(int, int), public.restaurant_orders(uuid, text, int),
  public.admin_orders(jsonb), public.admin_order_detail(uuid), public.admin_order_update(uuid, jsonb), public.order_set_pause(uuid, text, int),
  public.set_menu_item_availability(uuid, text), public.cart_save(jsonb), public.cart_load(), public.marketplace_stats(int),
  public.restaurant_order_stats(uuid, int), public.can_view_orders(uuid, uuid), public.can_refund_orders(uuid, uuid), public.order_member_role(uuid, uuid)
  to authenticated, service_role;
revoke all on function public.order_action(uuid, text, jsonb), public.my_orders(int, int), public.restaurant_orders(uuid, text, int),
  public.admin_orders(jsonb), public.admin_order_detail(uuid), public.admin_order_update(uuid, jsonb), public.order_set_pause(uuid, text, int),
  public.set_menu_item_availability(uuid, text), public.cart_save(jsonb), public.cart_load(), public.marketplace_stats(int),
  public.restaurant_order_stats(uuid, int) from anon;

-- Tempo reale: canale leggero (nessun dato personale)
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin
      alter publication supabase_realtime add table public.order_realtime;
    exception when duplicate_object then null;
    end;
  end if;
end $$;
