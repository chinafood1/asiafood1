-- ════════════════════════════════════════════════════════════════════
--  FASE 13 · GROWTH OPERATIONS — parte 3
--  Mercati e prossima città (solo ANALISI), alert e anomalie, automazioni controllabili
--  (kill switch, approvazione umana, audit), esperimenti, report, brief giornaliero,
--  task da insight, knowledge base, costi, performance ristoratore, job pianificati, RLS e grant.
--  NESSUNA esecuzione automatica di: contatti commerciali, spesa, prezzi, campagne, lanci di mercato.
-- ════════════════════════════════════════════════════════════════════

-- ────────────────────────────────────────────────────────────────────
--  1. TABELLE
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.growth_alerts (
  id              uuid primary key default gen_random_uuid(),
  key             text not null unique check (char_length(key) <= 160),
  severity        text not null check (severity in ('info', 'warning', 'critical')),
  category        text not null check (category in ('search', 'trial', 'restaurant', 'billing', 'orders', 'reservations', 'checkout', 'ai', 'data', 'automation')),
  title           text not null check (char_length(title) <= 200),
  detail          text check (char_length(detail) <= 600),
  link            text check (link is null or link ~ '^/'),
  metric          jsonb not null default '{}'::jsonb,
  status          text not null default 'open' check (status in ('open', 'acknowledged', 'resolved')),
  first_seen_at   timestamptz not null default now(),
  last_seen_at    timestamptz not null default now(),
  acknowledged_by uuid references public.profiles(id) on delete set null,
  resolved_at     timestamptz
);
create index if not exists growth_alerts_status_idx on public.growth_alerts(status, severity, last_seen_at desc);

create table if not exists public.automation_rules (
  id                uuid primary key default gen_random_uuid(),
  key               text not null unique check (key ~ '^[a-z0-9_]{3,60}$'),
  name              text not null check (char_length(name) between 3 and 120),
  description       text not null check (char_length(description) <= 600),
  audience          text not null check (audience in ('consumer', 'restaurant', 'sales')),
  trigger_key       text not null check (char_length(trigger_key) <= 60),
  action            text not null check (action in ('create_crm_task', 'owner_notification', 'draft_user_message', 'unavailable')),
  enabled           boolean not null default false,
  requires_approval boolean not null default true,
  consent_required  boolean not null default false,
  config            jsonb not null default '{}'::jsonb,
  interval_minutes  int not null default 1440 check (interval_minutes between 15 and 43200),
  owner_id          uuid references public.profiles(id) on delete set null,
  last_run_at       timestamptz,
  next_run_at       timestamptz,
  failure_count     int not null default 0,
  last_error        text check (char_length(last_error) <= 500),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  -- I messaggi commerciali verso gli utenti richiedono SEMPRE approvazione umana e consenso marketing
  check (action <> 'draft_user_message' or (requires_approval and consent_required)),
  check (action <> 'unavailable' or not enabled)
);

create table if not exists public.automation_runs (
  id               uuid primary key default gen_random_uuid(),
  rule_id          uuid not null references public.automation_rules(id) on delete cascade,
  trigger          text not null check (trigger in ('schedule', 'manual', 'dry_run')),
  status           text not null default 'running' check (status in ('running', 'success', 'failed', 'skipped')),
  records_affected int not null default 0,
  started_at       timestamptz not null default now(),
  completed_at     timestamptz,
  error            text check (char_length(error) <= 500)
);
create index if not exists automation_runs_rule_idx on public.automation_runs(rule_id, started_at desc);

-- Coda di output delle automazioni: bozze da approvare, task creati, notifiche. Deduplicata per regola.
create table if not exists public.automation_items (
  id             uuid primary key default gen_random_uuid(),
  rule_id        uuid not null references public.automation_rules(id) on delete cascade,
  dedupe_key     text not null check (char_length(dedupe_key) <= 200),
  status         text not null check (status in ('pending_approval', 'approved', 'rejected', 'sent', 'done', 'skipped')),
  target_user_id uuid references public.profiles(id) on delete cascade,
  restaurant_id  uuid references public.restaurants(id) on delete cascade,
  lead_id        uuid references public.crm_leads(id) on delete cascade,
  title          text not null check (char_length(title) <= 140),
  body           text check (char_length(body) <= 500),
  link           text check (link is null or link ~ '^/'),
  payload        jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  decided_by     uuid references public.profiles(id) on delete set null,
  decided_at     timestamptz,
  sent_at        timestamptz,
  unique (rule_id, dedupe_key)
);
create index if not exists automation_items_status_idx on public.automation_items(status, created_at desc);

-- Esperimenti (estensione additiva della tabella della Fase 12)
alter table public.experiments add column if not exists end_at timestamptz;
alter table public.experiments add column if not exists secondary_metrics text[] not null default '{}';
alter table public.experiments add column if not exists guardrail_area text not null default 'none'
  check (guardrail_area in ('none', 'pricing', 'consent', 'security', 'accessibility'));
alter table public.experiments add column if not exists review_approved_by uuid references public.profiles(id) on delete set null;
alter table public.experiments add column if not exists review_approved_at timestamptz;
alter table public.experiments add column if not exists review_note text check (char_length(review_note) <= 500);
alter table public.experiments add column if not exists created_by uuid references public.profiles(id) on delete set null;

create table if not exists public.experiment_variants (
  id                    uuid primary key default gen_random_uuid(),
  experiment_id         uuid not null references public.experiments(id) on delete cascade,
  name                  text not null check (name ~ '^[a-z0-9_]{2,40}$'),
  allocation_percentage int not null check (allocation_percentage between 1 and 100),
  config_json           jsonb not null default '{}'::jsonb,
  unique (experiment_id, name)
);
insert into public.experiment_variants (experiment_id, name, allocation_percentage)
select e.id, v.name, greatest(1, 100 / cardinality(e.variants)) from public.experiments e cross join lateral unnest(e.variants) v(name)
on conflict do nothing;

create table if not exists public.experiment_assignments (
  id            uuid primary key default gen_random_uuid(),
  experiment_id uuid not null references public.experiments(id) on delete cascade,
  variant_id    uuid not null references public.experiment_variants(id) on delete cascade,
  anonymous_id  text check (anonymous_id is null or anonymous_id ~ '^[A-Za-z0-9_-]{8,64}$'),
  user_id       uuid references public.profiles(id) on delete set null,
  converted_at  timestamptz,
  created_at    timestamptz not null default now(),
  check (anonymous_id is not null or user_id is not null)
);
create unique index if not exists experiment_assignments_anon_uq on public.experiment_assignments(experiment_id, anonymous_id) where anonymous_id is not null;
create index if not exists experiment_assignments_exp_idx on public.experiment_assignments(experiment_id, variant_id);

create table if not exists public.growth_reports (
  id            uuid primary key default gen_random_uuid(),
  period_start  date not null,
  period_end    date not null,
  market_id     uuid references public.markets(id) on delete cascade,
  report_type   text not null check (report_type in ('weekly', 'monthly', 'custom')),
  metrics_json  jsonb not null,
  summary       text not null,
  created_by    uuid references public.profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  check (period_end >= period_start)
);
create unique index if not exists growth_reports_period_uq on public.growth_reports(report_type, period_start, period_end, coalesce(market_id, '00000000-0000-0000-0000-000000000000'::uuid))
  where report_type <> 'custom';

create table if not exists public.growth_tasks (
  id           uuid primary key default gen_random_uuid(),
  market_id    uuid references public.markets(id) on delete cascade,
  title        text not null check (char_length(title) between 3 and 200),
  description  text check (char_length(description) <= 1000),
  source       text not null default 'manual' check (source in ('manual', 'insight', 'alert', 'expansion', 'report')),
  source_ref   text check (char_length(source_ref) <= 200),
  priority     text not null default 'normal' check (priority in ('low', 'normal', 'high')),
  status       text not null default 'open' check (status in ('open', 'done', 'dismissed')),
  due_at       timestamptz,
  assigned_to  uuid references public.profiles(id) on delete set null,
  created_by   uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at   timestamptz not null default now(),
  done_at      timestamptz
);
create unique index if not exists growth_tasks_open_ref_uq on public.growth_tasks(source, source_ref) where status = 'open' and source_ref is not null;

create table if not exists public.growth_learnings (
  id            uuid primary key default gen_random_uuid(),
  market_id     uuid references public.markets(id) on delete cascade,
  category      text not null check (category in ('outreach', 'conversion', 'acquisition', 'qr', 'pricing', 'product', 'operations', 'other')),
  title         text not null check (char_length(title) between 3 and 160),
  description   text not null check (char_length(description) <= 1500),
  evidence_json jsonb not null default '{}'::jsonb,
  confidence    text not null check (confidence in ('low', 'medium', 'high')),
  created_by    uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at    timestamptz not null default now()
);

create table if not exists public.expansion_candidates (
  slug                 text primary key check (slug ~ '^[a-z0-9-]{2,40}$'),
  name                 text not null,
  province_code        text,
  region_name          text,
  status               text not null default 'candidate' check (status in ('candidate', 'researching', 'market_created', 'rejected')),
  market_id            uuid references public.markets(id) on delete set null,
  research_started_at  timestamptz,
  research_started_by  uuid references public.profiles(id) on delete set null,
  notes                text check (char_length(notes) <= 1000),
  created_at           timestamptz not null default now()
);
insert into public.expansion_candidates (slug, name, province_code, region_name) values
  ('bari', 'Bari', 'BA', 'Puglia'), ('lecce', 'Lecce', 'LE', 'Puglia'), ('brindisi', 'Brindisi', 'BR', 'Puglia'),
  ('matera', 'Matera', 'MT', 'Basilicata'), ('foggia', 'Foggia', 'FG', 'Puglia')
on conflict (slug) do nothing;

create table if not exists public.market_playbook_items (
  id          uuid primary key default gen_random_uuid(),
  market_id   uuid not null references public.markets(id) on delete cascade,
  stage       text not null check (stage in ('research', 'data', 'sales', 'seo', 'partners', 'beta_users', 'launch')),
  sort        int not null default 0,
  title       text not null check (char_length(title) between 3 and 200),
  hint        text check (char_length(hint) <= 500),
  done_at     timestamptz,
  done_by     uuid references public.profiles(id) on delete set null,
  unique (market_id, stage, title)
);

create table if not exists public.operating_costs (
  id            uuid primary key default gen_random_uuid(),
  category      text not null check (category in ('ai', 'email', 'push', 'maps', 'payment_processing', 'infrastructure', 'ads', 'other')),
  amount_cents  int not null check (amount_cents > 0),
  period_start  date not null,
  period_end    date not null,
  notes         text check (char_length(notes) <= 500),
  created_by    uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at    timestamptz not null default now(),
  check (period_end >= period_start)
);

-- ────────────────────────────────────────────────────────────────────
--  2. OBLIO (anonimizzazione account): niente legami personali nelle tabelle Growth
-- ────────────────────────────────────────────────────────────────────
create or replace function public.growth_forget_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.is_blocked and new.full_name = 'Utente eliminato' and new.email is null then
    delete from public.automation_items where target_user_id = new.id;
    update public.experiment_assignments set user_id = null, anonymous_id = coalesce(anonymous_id, 'deleted-' || left(md5(id::text), 12)) where user_id = new.id;
  end if;
  return new;
end $$;
drop trigger if exists profiles_growth_forget on public.profiles;
create trigger profiles_growth_forget after update of is_blocked, full_name, email on public.profiles for each row execute function public.growth_forget_user();

-- ────────────────────────────────────────────────────────────────────
--  3. MERCATI: metriche, Market Opportunity Score trasparente, readiness, prossima città (solo analisi)
-- ────────────────────────────────────────────────────────────────────
-- Punteggio: ogni componente normalizzato 0..1 sul massimo tra i candidati, moltiplicato per il peso.
-- Restituisce anche la scomposizione (+32 domanda, +25 supply gap…). Specchio TS: shared/growth.ts → marketScore().
create or replace function public.growth_market_score(p_inputs jsonb, p_max jsonb, p_weights jsonb)
returns jsonb language plpgsql immutable as $$
declare
  k text; v_w numeric; v_tot_w numeric := 0; v_part numeric; v_score numeric := 0; v_break jsonb := '{}'::jsonb;
  keys text[] := array['search_demand', 'supply_gap', 'lead_availability', 'organic_interest', 'commercial_interest'];
begin
  foreach k in array keys loop v_tot_w := v_tot_w + greatest(coalesce((p_weights ->> k)::numeric, 0), 0); end loop;
  if v_tot_w = 0 then return jsonb_build_object('score', 0, 'breakdown', '{}'::jsonb); end if;
  foreach k in array keys loop
    v_w := greatest(coalesce((p_weights ->> k)::numeric, 0), 0) * 100 / v_tot_w;
    v_part := case when coalesce((p_max ->> k)::numeric, 0) > 0 then v_w * greatest(coalesce((p_inputs ->> k)::numeric, 0), 0) / (p_max ->> k)::numeric else 0 end;
    v_break := v_break || jsonb_build_object(k, round(v_part));
    v_score := v_score + v_part;
  end loop;
  return jsonb_build_object('score', round(v_score), 'breakdown', v_break);
end $$;

-- Input grezzi di un'area (provincia): domanda di ricerca, offerta, lead, interesse organico e commerciale (90 giorni)
create or replace function public.growth_area_inputs(p_province uuid, p_name text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_demand bigint; v_zero bigint; v_supply bigint; v_leads bigint; v_organic bigint; v_comm bigint; v_word text := lower(coalesce(p_name, ''));
begin
  select count(*), count(*) filter (where result_count = 0) into v_demand, v_zero from public.search_events s
   where s.created_at > now() - interval '90 days'
     and ((p_province is not null and s.city_slug in (select slug from public.cities where province_id = p_province))
          or (v_word <> '' and s.query_norm ~ ('(^| )' || v_word || '( |$)')));
  select count(*) into v_supply from public.restaurants r join public.cities c on c.id = r.city_id
   where p_province is not null and c.province_id = p_province and r.is_active and not r.is_demo and not r.is_permanently_closed;
  select count(*) into v_leads from public.crm_leads l join public.cities c on c.id = l.city_id where p_province is not null and c.province_id = p_province;
  v_leads := v_leads + v_supply;   -- ristoranti censiti = lead potenziali
  select count(*) into v_organic from public.profiles p join public.cities c on c.id = p.city_id
   where p_province is not null and c.province_id = p_province and p.role::text = 'customer';
  select (select count(*) from public.restaurant_claims cl join public.restaurants r on r.id = cl.restaurant_id join public.cities c on c.id = r.city_id
           where p_province is not null and c.province_id = p_province and not r.is_demo)
       + (select count(*) from public.crm_leads l join public.cities c on c.id = l.city_id
           where p_province is not null and c.province_id = p_province and public.crm_status_rank(l.status) >= public.crm_status_rank('replied'))
    into v_comm;
  return jsonb_build_object('search_demand', v_demand, 'zero_results', v_zero,
    -- Supply gap = domanda non servita: ricerche senza risultati + domanda per ristorante disponibile (quando l'offerta è scarsa)
    'supply_gap', v_zero + case when v_supply < 5 then greatest(v_demand - v_zero, 0) else 0 end,
    'supply', v_supply, 'lead_availability', v_leads, 'organic_interest', v_organic, 'commercial_interest', v_comm);
end $$;

create or replace function public.admin_growth_markets()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_today date := (now() at time zone 'Europe/Rome')::date; v_markets jsonb; v_min int := public.growth_min_sample();
begin
  perform public.growth_assert_admin();
  select coalesce(jsonb_agg(jsonb_build_object(
      'id', m.id, 'slug', m.slug, 'name', m.name, 'status', m.status,
      'restaurants', (select count(*) from public.restaurants r join public.cities c on c.id = r.city_id where c.province_id = m.province_id and r.is_active and public.growth_in_scope(r.is_demo)),
      'claimed', (select count(*) from public.restaurants r join public.cities c on c.id = r.city_id where c.province_id = m.province_id and r.owner_id is not null and public.growth_in_scope(r.is_demo)),
      'paying', (select count(distinct s.restaurant_id) from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id join public.cities c on c.id = r.city_id
                  where c.province_id = m.province_id and public.growth_in_scope(r.is_demo) and public.subscription_in_env(s) and s.paid_started_at is not null
                    and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
      'users', (select count(*) from public.profiles p join public.cities c on c.id = p.city_id where c.province_id = m.province_id and p.role::text = 'customer'),
      'searches_30d', (select coalesce(sum(searches), 0) from public.daily_market_metrics d where d.market_id = m.id and d.date > v_today - 30),
      'zero_results_30d', (select coalesce(sum(zero_result_searches), 0) from public.daily_market_metrics d where d.market_id = m.id and d.date > v_today - 30),
      'reservations_30d', (select coalesce(sum(reservations), 0) from public.daily_market_metrics d where d.market_id = m.id and d.date > v_today - 30),
      'orders_30d', (select coalesce(sum(orders), 0) from public.daily_market_metrics d where d.market_id = m.id and d.date > v_today - 30),
      'gmv_30d_cents', (select coalesce(sum(gmv_cents), 0) from public.daily_market_metrics d where d.market_id = m.id and d.date > v_today - 30),
      'mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id join public.cities c on c.id = r.city_id
                     where c.province_id = m.province_id and public.growth_in_scope(r.is_demo) and public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
      'supply_gaps', jsonb_array_length(public.growth_supply_gap(v_today - 29, v_today, m.slug)),
      'visits_30d', (select coalesce(sum(visits), 0) from public.daily_market_metrics d where d.market_id = m.id and d.date > v_today - 30),
      'visits_prev_30d', (select coalesce(sum(visits), 0) from public.daily_market_metrics d where d.market_id = m.id and d.date between v_today - 59 and v_today - 30),
      'traffic_growth_pct', (select case when prev >= v_min and full_prev then round((cur - prev) * 100.0 / prev, 1) end from (
            select coalesce(sum(visits) filter (where d.date > v_today - 30), 0) cur, coalesce(sum(visits) filter (where d.date between v_today - 59 and v_today - 30), 0) prev,
                   (select count(*) from public.growth_computed_days g where g.day between v_today - 59 and v_today - 30) = 30 full_prev
              from public.daily_market_metrics d where d.market_id = m.id and d.date > v_today - 60) t),
      'readiness', public.growth_market_readiness(m.id)) order by m.created_at), '[]'::jsonb)
    into v_markets from public.markets m;
  return jsonb_build_object('markets', v_markets, 'candidates', public.growth_candidates(), 'weights', public.growth_setting_json('growth_market_weights', '{}'::jsonb));
end $$;

-- Readiness di un mercato: criteri espliciti e verificabili (docs/growth/EXPANSION.md)
create or replace function public.growth_market_readiness(p_market uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets; v_rest int; v_complete int; v_leads int; v_contacted int; v_seo int; v_items jsonb;
begin
  select * into m from public.markets where id = p_market;
  if not found then return null; end if;
  select count(*), count(*) filter (where (public.restaurant_completion(r.id) ->> 'score')::int >= 60) into v_rest, v_complete
    from public.restaurants r join public.cities c on c.id = r.city_id where c.province_id = m.province_id and r.is_active and not r.is_demo;
  select count(*), count(*) filter (where public.crm_status_rank(status) >= public.crm_status_rank('contacted')) into v_leads, v_contacted
    from public.crm_leads where market_id = p_market;
  -- Pagine SEO città/categoria indicizzabili: comuni con almeno 3 ristoranti attivi
  select count(*) into v_seo from (select r.city_id from public.restaurants r join public.cities c on c.id = r.city_id
    where c.province_id = m.province_id and r.is_active and not r.is_demo group by 1 having count(*) >= 3) t;
  select coalesce(jsonb_object_agg(stage, jsonb_build_object('done', d, 'total', n)), '{}'::jsonb) into v_items from (
    select stage, count(*) n, count(*) filter (where done_at is not null) d from public.market_playbook_items where market_id = p_market group by 1) t;
  return jsonb_build_object(
    'data', jsonb_build_object('ok', v_rest >= 20 and v_complete >= v_rest * 0.6, 'detail', format('%s ristoranti, %s con profilo ≥ 60%%', v_rest, v_complete)),
    'sales', jsonb_build_object('ok', v_leads >= 20 and v_contacted >= 10, 'detail', format('%s lead, %s contattati', v_leads, v_contacted)),
    'seo', jsonb_build_object('ok', v_seo >= 1, 'detail', format('%s comuni con ≥ 3 ristoranti (pagine indicizzabili)', v_seo)),
    'operational', jsonb_build_object('ok', coalesce((v_items -> 'partners' ->> 'done')::int, 0) >= 1 and coalesce((v_items -> 'beta_users' ->> 'done')::int, 0) >= 1,
                                      'detail', 'Almeno un''attività completata in Partner e Beta users nel playbook'),
    'launch_ready', jsonb_build_object('ok', v_rest >= 20 and v_complete >= v_rest * 0.6 and v_leads >= 20 and v_contacted >= 10 and v_seo >= 1
                                          and coalesce((v_items -> 'launch' ->> 'total')::int, 0) > 0
                                          and coalesce((v_items -> 'launch' ->> 'done')::int, 0) = coalesce((v_items -> 'launch' ->> 'total')::int, 0),
                                       'detail', 'Tutti i criteri precedenti + checklist "Launch" completa'),
    'playbook', v_items);
end $$;

-- Città candidate: input grezzi, punteggio e scomposizione. Nessuna scelta automatica.
create or replace function public.growth_candidates()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_rows jsonb; v_max jsonb; v_w jsonb := public.growth_setting_json('growth_market_weights', '{"search_demand": 30, "supply_gap": 25, "lead_availability": 20, "organic_interest": 15, "commercial_interest": 10}'::jsonb);
begin
  with c as (
    select ec.*, p.id province_id, public.growth_area_inputs(p.id, ec.name) inputs
      from public.expansion_candidates ec left join public.provinces p on p.code = ec.province_code
     where ec.status <> 'rejected'
       and ec.slug in (select jsonb_array_elements_text(public.growth_setting_json('growth_expansion_candidates', '[]'::jsonb)))
       and not exists (select 1 from public.markets mk where mk.province_id = p.id and mk.status <> 'planned'))
  select coalesce(jsonb_agg(to_jsonb(c.*) - 'inputs' || jsonb_build_object('inputs', c.inputs)), '[]'::jsonb),
         jsonb_build_object('search_demand', max((inputs ->> 'search_demand')::numeric), 'supply_gap', max((inputs ->> 'supply_gap')::numeric),
                            'lead_availability', max((inputs ->> 'lead_availability')::numeric), 'organic_interest', max((inputs ->> 'organic_interest')::numeric),
                            'commercial_interest', max((inputs ->> 'commercial_interest')::numeric))
    into v_rows, v_max from c;
  return coalesce((select jsonb_agg(x || public.growth_market_score(x -> 'inputs', v_max, v_w)
                          || jsonb_build_object('data_points', (select count(*) from jsonb_each_text(x -> 'inputs') e where e.key <> 'supply' and e.value::numeric > 0),
                                                'readiness', case when x ->> 'market_id' is not null then public.growth_market_readiness((x ->> 'market_id')::uuid) end,
                                                'has_province', x ->> 'province_id' is not null)
                          order by (public.growth_market_score(x -> 'inputs', v_max, v_w) ->> 'score')::int desc, x ->> 'name')
                   from jsonb_array_elements(v_rows) x), '[]'::jsonb);
end $$;

-- "Start Research" (MAI "Launch automatically"): crea il mercato in stato "planned", checklist e task di ricerca.
-- Discovery/Research Agent (Fase 10) non sono implementati: i task sono manuali e lo dichiarano.
create or replace function public.admin_expansion_start_research(p_slug text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare ec public.expansion_candidates; v_prov public.provinces; v_market uuid; v_tasks int := 0; v_items int := 0;
begin
  perform public.growth_assert_admin();
  select * into ec from public.expansion_candidates where slug = p_slug for update;
  if not found then raise exception 'Città candidata non trovata' using errcode = 'P0002'; end if;
  select * into v_prov from public.provinces where code = ec.province_code;
  if v_prov.id is null then
    raise exception 'La provincia % non è presente nei dati di riferimento: aggiungila in "Città e territori" prima di avviare la ricerca.', coalesce(ec.province_code, '?') using errcode = 'P0001';
  end if;
  select id into v_market from public.markets where province_id = v_prov.id;
  if v_market is null then
    insert into public.markets (slug, name, province_id, status, notes) values (ec.slug, ec.name, v_prov.id, 'planned', 'Creato da "Start Research" (Growth → Prossimo mercato). Nessun lancio automatico.')
    returning id into v_market;
  end if;
  insert into public.market_playbook_items (market_id, stage, sort, title, hint)
  select v_market, x.st, x.s, x.t, x.h from (values
    ('research', 1, 'Censire i ristoranti asiatici della provincia (fonti pubbliche)', 'Import con fonti verificabili (Importa). Nessun dato inventato.'),
    ('research', 2, 'Analizzare la domanda di ricerca e le ricerche senza risultati', 'Growth → Ricerca, filtro sul mercato.'),
    ('data', 1, 'Coordinate, orari e telefoni verificati per i locali censiti', 'Qualità dati ≥ 60% per almeno il 60% dei locali.'),
    ('data', 2, 'Analisi copertura per comune e categoria', 'Growth → Supply gap.'),
    ('sales', 1, 'Creare i lead CRM dai ristoranti censiti', 'CRM → "Crea lead dai ristoranti".'),
    ('sales', 2, 'Primi 10 contatti con lo script del Sales Playbook', 'Solo contatti consentiti; registrare ogni attività.'),
    ('seo', 1, 'Verificare pagine città/categoria indicizzabili (≥ 3 locali)', 'Sitemap generata solo per pagine con contenuto reale.'),
    ('partners', 1, 'Individuare 3 partner locali (hotel, università, eventi)', 'CRM → Partner.'),
    ('beta_users', 1, 'Invitare i primi utenti beta del territorio', 'beta_invite_only; nessuna campagna automatica.'),
    ('launch', 1, 'Revisione go/no-go con i dati di readiness', 'Decisione umana. Il lancio non è mai automatico.')
  ) x(st, s, t, h)
  on conflict do nothing;
  get diagnostics v_items = row_count;
  insert into public.growth_tasks (market_id, title, description, source, source_ref, priority)
  select v_market, x.t, x.d, 'expansion', 'research:' || ec.slug || ':' || x.k, 'normal' from (values
    ('discovery', format('Discovery: censire i ristoranti asiatici di %s', ec.name), 'Discovery Agent non disponibile (Fase 10 non implementata): attività manuale con fonti pubbliche verificabili.'),
    ('research', format('Research: verificare dati e fonti dei locali di %s', ec.name), 'Research Agent non disponibile: verifica manuale (telefono, sito, social).'),
    ('leads', format('Creare i lead CRM per %s', ec.name), 'Dopo il censimento: CRM → "Crea lead dai ristoranti".'),
    ('coverage', format('Analisi copertura di %s (comuni × categorie)', ec.name), 'Confrontare con la domanda di ricerca reale.'),
    ('seo', format('Preparazione SEO per %s', ec.name), 'Pagine città/categoria solo con contenuto reale; nessuna pagina vuota.')
  ) x(k, t, d)
  on conflict do nothing;
  get diagnostics v_tasks = row_count;
  update public.expansion_candidates set status = case when status = 'candidate' then 'researching' else status end, market_id = v_market,
         research_started_at = coalesce(research_started_at, now()), research_started_by = coalesce(research_started_by, auth.uid())
   where slug = ec.slug;
  perform public.audit_admin('expansion_start_research', 'market', v_market::text, jsonb_build_object('candidate', ec.slug));
  return jsonb_build_object('market_id', v_market, 'playbook_items', v_items, 'tasks', v_tasks);
end $$;

create or replace function public.admin_market_playbook(p_market text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_id uuid;
begin
  perform public.growth_assert_admin();
  select id into v_id from public.markets where slug = p_market;
  return jsonb_build_object('market_id', v_id, 'readiness', public.growth_market_readiness(v_id),
    'items', coalesce((select jsonb_agg(to_jsonb(i) order by array_position(array['research', 'data', 'sales', 'seo', 'partners', 'beta_users', 'launch'], i.stage), i.sort)
                         from public.market_playbook_items i where i.market_id = v_id), '[]'::jsonb),
    -- Knowledge loop: apprendimenti degli ALTRI mercati, da verificare (mai copiati alla cieca)
    'learnings', coalesce((select jsonb_agg(to_jsonb(l) order by l.created_at desc) from public.growth_learnings l where l.market_id is distinct from v_id), '[]'::jsonb));
end $$;

create or replace function public.admin_playbook_item_set(p_id uuid, p_done boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  update public.market_playbook_items set done_at = case when p_done then coalesce(done_at, now()) end, done_by = case when p_done then auth.uid() end where id = p_id;
end $$;

-- Target vs Actual del mercato (Taranto): gap e dati correlati (NON cause)
create or replace function public.admin_growth_market_review(p_market text default 'taranto')
returns jsonb language plpgsql volatile security definer set search_path = public as $$
declare m public.markets; v_goals jsonb;
begin
  perform public.growth_assert_admin();
  select * into m from public.markets where slug = coalesce(nullif(p_market, ''), 'taranto');
  if not found then raise exception 'Mercato non trovato' using errcode = 'P0002'; end if;
  perform public.launch_goals_refresh(m.id);
  select coalesce(jsonb_agg(jsonb_build_object('metric_key', g.metric_key, 'target', g.target_value, 'actual', g.actual_value,
      'gap', greatest(g.target_value - coalesce(g.actual_value, 0), 0),
      'pct', case when g.target_value > 0 then round(coalesce(g.actual_value, 0) * 100 / g.target_value) end,
      'status', g.status, 'period_start', g.period_start, 'period_end', g.period_end) order by g.metric_key), '[]'::jsonb)
    into v_goals from public.growth_goals g where g.market_id = m.id;
  return jsonb_build_object('market', jsonb_build_object('id', m.id, 'slug', m.slug, 'name', m.name, 'status', m.status),
    'goals', v_goals,
    'correlated', jsonb_build_object(
      'pipeline', coalesce((select jsonb_object_agg(status, n) from (select status, count(*) n from public.crm_leads where market_id = m.id and kind = 'restaurant' group by 1) t), '{}'::jsonb),
      'restaurants_indexed', public.launch_metric(m.id, 'restaurants_listed', now() - interval '100 years', now()),
      'restaurants_claimed', public.launch_metric(m.id, 'restaurants_claimed', now() - interval '100 years', now()),
      'restaurants_paying', public.launch_metric(m.id, 'restaurants_paying', now() - interval '100 years', now()),
      'trials', (select jsonb_build_object('started', count(*), 'ended', count(*) filter (where t.ends_at <= now() or t.converted_at is not null), 'converted', count(*) filter (where t.converted_at is not null))
                   from public.billing_trials t join public.launch_market_ids(m.id) mr(id) on mr.id = t.restaurant_id),
      'activated', (select count(*) from public.restaurants r join public.launch_market_ids(m.id) mr(id) on mr.id = r.id where r.owner_id is not null and public.launch_restaurant_activated(r.id)),
      'users_d30', (select jsonb_build_object('eligible', count(*), 'returned', count(*) filter (where exists (select 1 from public.user_activity_days a where a.user_id = p.id
                        and a.day between (p.created_at at time zone 'Europe/Rome')::date + 1 and (p.created_at at time zone 'Europe/Rome')::date + 30)))
                      from public.profiles p join public.cities c on c.id = p.city_id where c.province_id = m.province_id and p.role::text = 'customer' and p.created_at < now() - interval '30 days'),
      'conversions_30d', public.launch_metric(m.id, 'food_connections', now() - interval '30 days', now())),
    'note', 'I dati correlati descrivono la situazione: non indicano la causa di un gap. Le cause vanno verificate (colloqui, feedback, test).');
end $$;

-- ────────────────────────────────────────────────────────────────────
--  4. ALERT E ANOMALIE (semplici, con soglie minime: niente reazioni eccessive, solo segnalazioni)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.growth_alert_upsert(p_key text, p_sev text, p_cat text, p_title text, p_detail text, p_link text, p_metric jsonb, p_seen text[])
returns text[] language plpgsql security definer set search_path = public as $$
begin
  insert into public.growth_alerts (key, severity, category, title, detail, link, metric)
  values (p_key, p_sev, p_cat, left(p_title, 200), left(p_detail, 600), p_link, coalesce(p_metric, '{}'::jsonb))
  on conflict (key) do update set severity = excluded.severity, title = excluded.title, detail = excluded.detail, link = excluded.link, metric = excluded.metric,
    last_seen_at = now(),
    -- Un alert risolto che si ripresenta torna aperto; uno "preso in carico" resta tale
    status = case when public.growth_alerts.status = 'resolved' then 'open' else public.growth_alerts.status end,
    resolved_at = case when public.growth_alerts.status = 'resolved' then null else public.growth_alerts.resolved_at end;
  return p_seen || p_key;
end $$;

create or replace function public.growth_alerts_refresh()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_seen text[] := '{}'; r record; v_today date := (now() at time zone 'Europe/Rome')::date;
  v_zero_min int := public.billing_setting_int('growth_alert_zero_result_min', 10);
  v_no_login int := public.billing_setting_int('growth_alert_no_login_days', 21);
  v_base_min int := public.billing_setting_int('growth_anomaly_min_baseline', 10);
  v_drop int := public.billing_setting_int('growth_anomaly_drop_pct', 60);
  v_chk_drop int := public.billing_setting_int('growth_checkout_drop_pct', 25);
  v_min int := public.growth_min_sample();
  v_y date := v_today - 1; v_avg numeric; v_val numeric; v_a numeric; v_b numeric; v_c numeric; v_d numeric; v_resolved int;
begin
  if not public.is_admin_or_service() then raise exception 'Non autorizzato' using errcode = '42501'; end if;

  -- Ricerche senza risultati ricorrenti (7 giorni)
  for r in select coalesce(nullif(query_norm, ''), '') q, city_slug, category_slug, sum(zero_results) z
             from public.daily_search_metrics where date > v_today - 7 group by 1, 2, 3 having sum(zero_results) >= v_zero_min order by 4 desc limit 10 loop
    v_seen := public.growth_alert_upsert('zero:' || r.q || ':' || r.city_slug || ':' || r.category_slug, 'warning', 'search',
      format('«%s»: %s ricerche senza risultati in 7 giorni', trim(concat_ws(' · ', nullif(coalesce((select name from public.categories where slug = r.category_slug), r.q), ''),
             (select name from public.cities where slug = r.city_slug))), r.z),
      'Domanda non servita: valutare censimento di nuovi locali o contatto con ristoranti della zona.', '/admin/growth/search',
      jsonb_build_object('zero_results', r.z, 'city', nullif(r.city_slug, ''), 'category', nullif(r.category_slug, ''), 'query', nullif(r.q, '')), v_seen);
  end loop;

  -- Prove in scadenza entro 3 giorni
  for r in select rs.id, rs.name, s.trial_end from public.subscriptions s join public.restaurants rs on rs.id = s.restaurant_id
            where public.subscription_in_env(s) and s.status = 'trialing' and s.trial_end between now() and now() + interval '3 days' and public.growth_in_scope(rs.is_demo) loop
    v_seen := public.growth_alert_upsert('trial:' || r.id, 'warning', 'trial', format('Prova di «%s» in scadenza il %s', r.name, to_char(r.trial_end at time zone 'Europe/Rome', 'DD/MM')),
      'Follow-up commerciale consigliato (nessun addebito o rinnovo automatico viene attivato da AsiaFood).', '/admin/growth/restaurants', jsonb_build_object('restaurant_id', r.id), v_seen);
  end loop;

  -- Pagamenti non riusciti
  for r in select rs.id, rs.name from public.subscriptions s join public.restaurants rs on rs.id = s.restaurant_id
            where public.subscription_in_env(s) and s.status in ('past_due', 'unpaid') and public.growth_in_scope(rs.is_demo) loop
    v_seen := public.growth_alert_upsert('payfail:' || r.id, 'critical', 'billing', format('Pagamento non riuscito: «%s»', r.name),
      'Stripe riprova automaticamente; verificare se serve supporto al ristoratore.', '/admin/growth/churn', jsonb_build_object('restaurant_id', r.id), v_seen);
  end loop;

  -- Ristoranti paganti o in prova senza accessi da N giorni
  for r in select rs.id, rs.name, (select max(day) from public.user_activity_days a where a.user_id = rs.owner_id) last_day
             from public.restaurants rs where rs.owner_id is not null and public.growth_in_scope(rs.is_demo)
              and exists (select 1 from public.subscriptions s where s.restaurant_id = rs.id and public.subscription_in_env(s) and s.status in ('active', 'trialing', 'past_due')) loop
    if r.last_day is null or r.last_day <= v_today - v_no_login then
      v_seen := public.growth_alert_upsert('nologin:' || r.id, 'warning', 'restaurant',
        case when r.last_day is null then format('«%s» non ha mai effettuato l''accesso', r.name) else format('«%s» non accede da %s giorni', r.name, v_today - r.last_day) end,
        'Rischio di abbandono: contatto di supporto consigliato.', '/admin/growth/restaurants', jsonb_build_object('restaurant_id', r.id, 'last_login', r.last_day), v_seen);
    end if;
  end loop;

  -- Calo ordini/prenotazioni di ieri rispetto alla media dei 7 giorni precedenti (solo con volume minimo)
  select avg(orders), (select orders from public.daily_platform_metrics where date = v_y) into v_avg, v_val from public.daily_platform_metrics where date between v_y - 7 and v_y - 1;
  if v_avg >= v_base_min and v_val is not null and v_val <= v_avg * (100 - v_drop) / 100.0 then
    v_seen := public.growth_alert_upsert('anomaly:orders:' || v_y, 'critical', 'orders', format('Ordini di ieri −%s%% rispetto alla media 7 giorni', round((1 - v_val / v_avg) * 100)),
      format('Ieri %s ordini, media %s. Verificare pagamenti, disponibilità dei ristoranti e funzionamento del checkout.', v_val, round(v_avg, 1)), '/admin/growth', jsonb_build_object('yesterday', v_val, 'avg7', round(v_avg, 1)), v_seen);
  end if;
  select avg(reservations), (select reservations from public.daily_platform_metrics where date = v_y) into v_avg, v_val from public.daily_platform_metrics where date between v_y - 7 and v_y - 1;
  if v_avg >= v_base_min and v_val is not null and v_val <= v_avg * (100 - v_drop) / 100.0 then
    v_seen := public.growth_alert_upsert('anomaly:reservations:' || v_y, 'warning', 'reservations', format('Prenotazioni di ieri −%s%% rispetto alla media 7 giorni', round((1 - v_val / v_avg) * 100)),
      format('Ieri %s prenotazioni, media %s.', v_val, round(v_avg, 1)), '/admin/growth', jsonb_build_object('yesterday', v_val, 'avg7', round(v_avg, 1)), v_seen);
  end if;

  -- Conversione checkout → pagamento: ultimi 7 giorni vs 7 precedenti (campione minimo su entrambi)
  select coalesce(sum(checkouts) filter (where date > v_today - 7), 0), coalesce(sum(orders) filter (where date > v_today - 7), 0),
         coalesce(sum(checkouts) filter (where date between v_today - 13 and v_today - 7), 0), coalesce(sum(orders) filter (where date between v_today - 13 and v_today - 7), 0)
    into v_a, v_b, v_c, v_d from public.daily_platform_metrics where date > v_today - 14;
  if v_a >= v_min and v_c >= v_min and v_d > 0 and (v_b / v_a) <= (v_d / v_c) * (100 - v_chk_drop) / 100.0 then
    v_seen := public.growth_alert_upsert('anomaly:checkout:' || v_today, 'warning', 'checkout',
      format('Conversione checkout −%s%% (7 giorni)', round((1 - (v_b / v_a) / (v_d / v_c)) * 100)),
      format('Checkout → pagamento: %s%% contro %s%% della settimana precedente.', round(v_b * 100 / v_a), round(v_d * 100 / v_c)), '/admin/growth', jsonb_build_object('rate', round(v_b * 100 / v_a, 1), 'prev_rate', round(v_d * 100 / v_c, 1)), v_seen);
  end if;

  -- Picco di pagamenti falliti e di ricerche (ieri ≥ 3× media, con minimo)
  select avg(payment_failures), (select payment_failures from public.daily_platform_metrics where date = v_y) into v_avg, v_val from public.daily_platform_metrics where date between v_y - 7 and v_y - 1;
  if v_val >= 5 and v_val >= 3 * greatest(coalesce(v_avg, 0), 1) then
    v_seen := public.growth_alert_upsert('anomaly:payfail:' || v_y, 'critical', 'billing', format('Picco di pagamenti falliti: %s ieri', v_val),
      'Verificare Stripe (stato servizio, webhook) e i log di sistema.', '/admin/system', jsonb_build_object('yesterday', v_val, 'avg7', round(coalesce(v_avg, 0), 1)), v_seen);
  end if;
  select avg(searches), (select searches from public.daily_platform_metrics where date = v_y) into v_avg, v_val from public.daily_platform_metrics where date between v_y - 7 and v_y - 1;
  if v_avg >= v_base_min and v_val >= 3 * v_avg then
    v_seen := public.growth_alert_upsert('anomaly:search:' || v_y, 'info', 'search', format('Picco di ricerche: %s ieri (media %s)', v_val, round(v_avg)),
      'Possibile effetto di una campagna o di traffico anomalo: verificare le sorgenti.', '/admin/growth/search', jsonb_build_object('yesterday', v_val, 'avg7', round(v_avg, 1)), v_seen);
  end if;

  -- Errori AI (24 ore)
  select count(*) filter (where status = 'error'), count(*) into v_a, v_b from public.ai_usage where created_at > now() - interval '24 hours';
  if v_a >= 10 and v_a >= v_b * 0.2 then
    v_seen := public.growth_alert_upsert('anomaly:ai:' || v_today, 'warning', 'ai', format('Errori dell''assistente AI: %s nelle ultime 24 ore', v_a),
      format('%s%% delle richieste. Verificare provider e chiave (lato server).', round(v_a * 100 / v_b)), '/admin/ai', jsonb_build_object('errors', v_a, 'requests', v_b), v_seen);
  end if;

  -- Prenotazioni senza risposta (fallimenti del flusso prenotazione)
  select count(*) into v_a from public.reservations x join public.restaurants rs on rs.id = x.restaurant_id
   where x.status::text = 'pending' and x.reservation_date < v_today and x.reservation_date >= v_today - 7 and public.growth_in_scope(rs.is_demo);
  if v_a >= 3 then
    v_seen := public.growth_alert_upsert('reservations:unanswered:' || v_today, 'warning', 'reservations', format('%s prenotazioni rimaste senza risposta (7 giorni)', v_a),
      'Clienti senza conferma: verificare con i ristoranti la gestione delle richieste.', '/admin/growth/restaurants', jsonb_build_object('count', v_a), v_seen);
  end if;

  -- Aggregati non aggiornati
  if coalesce((select max(computed_at) from public.growth_computed_days where day < v_today), '-infinity') < now() - interval '36 hours'
     and exists (select 1 from public.growth_computed_days) then
    v_seen := public.growth_alert_upsert('data:stale', 'warning', 'data', 'Aggregazione giornaliera ferma da oltre 36 ore', 'Verificare il job pianificato (system-cron).', '/admin/growth/data', '{}'::jsonb, v_seen);
  end if;

  -- Automazioni che falliscono
  for r in select id, name, failure_count from public.automation_rules where failure_count >= 3 loop
    v_seen := public.growth_alert_upsert('automation:' || r.id, 'warning', 'automation', format('Automazione «%s»: %s errori consecutivi', r.name, r.failure_count),
      'Controllare lo storico esecuzioni. Dopo 5 errori la regola viene disattivata automaticamente.', '/admin/growth/automations', jsonb_build_object('rule_id', r.id), v_seen);
  end loop;

  -- Chiusura automatica degli alert non più veri (non quelli presi in carico manualmente)
  update public.growth_alerts set status = 'resolved', resolved_at = now() where status = 'open' and not (key = any(v_seen));
  get diagnostics v_resolved = row_count;
  return jsonb_build_object('active', cardinality(v_seen), 'resolved', v_resolved);
end $$;

create or replace function public.admin_growth_alerts(p_status text default 'open')
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(a) order by array_position(array['critical', 'warning', 'info'], a.severity), a.last_seen_at desc)
                     from public.growth_alerts a where p_status is null or p_status = '' or a.status = p_status), '[]'::jsonb);
end $$;

create or replace function public.admin_growth_alert_set(p_id uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  if p_status not in ('open', 'acknowledged', 'resolved') then raise exception 'Stato non valido' using errcode = '22023'; end if;
  update public.growth_alerts set status = p_status, acknowledged_by = case when p_status = 'acknowledged' then auth.uid() else acknowledged_by end,
         resolved_at = case when p_status = 'resolved' then now() end where id = p_id;
end $$;

create or replace function public.admin_growth_alerts_refresh()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  perform public.growth_refresh_today(0);
  return public.growth_alerts_refresh();
end $$;

-- ────────────────────────────────────────────────────────────────────
--  5. AUTOMAZIONI: regole predefinite (tutte disattivabili; messaggi agli utenti SOLO bozze da approvare)
-- ────────────────────────────────────────────────────────────────────
insert into public.automation_rules (key, name, description, audience, trigger_key, action, enabled, requires_approval, consent_required, config, interval_minutes) values
  ('consumer_category_affinity', 'Affinità categoria → offerte (es. Sushi)',
   'Utenti con almeno N preferiti nella categoria e consenso marketing: bozza di suggerimento verso offerte attive della categoria. Nessun invio senza approvazione.',
   'consumer', 'favorites_category_affinity', 'draft_user_message', false, true, true, '{"category": "sushi", "min_favorites": 3}', 1440),
  ('consumer_abandoned_cart', 'Carrello abbandonato',
   'Carrelli con prodotti fermi da 2–48 ore senza ordine, solo utenti con consenso marketing: bozza di promemoria da approvare.',
   'consumer', 'abandoned_cart', 'draft_user_message', false, true, true, '{"min_hours": 2, "max_hours": 48}', 120),
  ('consumer_abandoned_reservation', 'Prenotazione abbandonata',
   'NON DISPONIBILE: l''avvio della prenotazione è tracciato in forma anonima (senza utente), quindi non è possibile sapere chi l''ha abbandonata senza raccogliere dati aggiuntivi.',
   'consumer', 'abandoned_reservation', 'unavailable', false, true, true, '{}', 1440),
  ('consumer_dormant_reactivation', 'Riattivazione utenti dormienti',
   'Utenti senza attività da 30–90 giorni, con consenso marketing, e nuovi ristoranti pubblicati nel loro comune negli ultimi 30 giorni: bozza "Nuovi ristoranti sono arrivati su AsiaFood".',
   'consumer', 'dormant_new_restaurants', 'draft_user_message', false, true, true, '{"min_days": 30, "max_days": 90}', 1440),
  ('restaurant_incomplete_profile', 'Profilo ristorante incompleto',
   'Ristoranti rivendicati con completezza < 60%: task CRM interno "Aiutare a completare il profilo".',
   'restaurant', 'profile_incomplete', 'create_crm_task', true, false, false, '{"threshold": 60}', 1440),
  ('restaurant_trial_ending', 'Prova in scadenza (3 giorni)',
   'Prove che terminano entro 3 giorni: task di follow-up commerciale. Notifica in-app al titolare solo se abilitata e se il sistema di fatturazione non l''ha già inviata.',
   'restaurant', 'trial_ending', 'create_crm_task', true, false, false, '{"days": 3, "notify_owner": false}', 720),
  ('restaurant_payment_failed', 'Pagamento non riuscito',
   'Abbonamenti in past_due/unpaid: task di supporto (Stripe invia già le comunicazioni di fatturazione).',
   'restaurant', 'payment_failed', 'create_crm_task', true, false, false, '{}', 720),
  ('sales_no_reply', 'Lead senza risposta (4 giorni)',
   'Lead contattati senza risposta da 4 giorni: task con bozza di follow-up (il messaggio NON viene inviato).',
   'sales', 'lead_no_reply', 'create_crm_task', true, false, false, '{"days": 4}', 1440),
  ('sales_demo_done', 'Demo completata → prossimo passo',
   'Demo registrata negli ultimi 7 giorni senza attività successive: task "Inviare link di rivendicazione / proporre la prova".',
   'sales', 'demo_completed', 'create_crm_task', true, false, false, '{}', 1440),
  ('sales_trial_mid', 'Metà prova → follow-up',
   'Prove oltre la metà della durata, non convertite: task di follow-up con i dati di performance del locale (senza promettere risultati).',
   'sales', 'trial_midpoint', 'create_crm_task', true, false, false, '{}', 1440),
  ('restaurant_winback', 'Win-back ristoranti',
   'Abbonamenti terminati negli ultimi 90 giorni: task per chiedere feedback. Mai riattivare un abbonamento senza consenso esplicito del ristoratore.',
   'restaurant', 'subscription_ended', 'create_crm_task', true, false, false, '{"days": 90}', 1440)
on conflict (key) do nothing;

-- Crea un task CRM interno (deduplicato dall'indice crm_tasks_auto_uq) e registra l'item
create or replace function public.automation_task(p_rule public.automation_rules, p_dedupe text, p_restaurant uuid, p_lead uuid, p_title text, p_reason text, p_payload jsonb)
returns int language plpgsql security definer set search_path = public as $$
declare v_market uuid;
begin
  if exists (select 1 from public.automation_items where rule_id = p_rule.id and dedupe_key = p_dedupe) then return 0; end if;
  v_market := coalesce((select market_id from public.crm_leads where id = p_lead),
                       (select public.growth_market_of_city(city_id) from public.restaurants where id = p_restaurant));
  begin
    insert into public.crm_tasks (market_id, lead_id, restaurant_id, title, reason, due_at, source, created_by, assigned_to)
    values (v_market, p_lead, p_restaurant, left(p_title, 200), left(p_reason, 60), now() + interval '1 day', 'system', null, p_rule.owner_id);
  exception when unique_violation then null;   -- task equivalente già aperto
  end;
  insert into public.automation_items (rule_id, dedupe_key, status, restaurant_id, lead_id, title, payload)
  values (p_rule.id, p_dedupe, 'done', p_restaurant, p_lead, left(p_title, 140), coalesce(p_payload, '{}'::jsonb))
  on conflict do nothing;
  return 1;
end $$;

-- Bozza di messaggio per un utente: SOLO con consenso marketing attuale; resta in attesa di approvazione.
create or replace function public.automation_draft(p_rule public.automation_rules, p_dedupe text, p_user uuid, p_title text, p_body text, p_link text, p_payload jsonb)
returns int language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.notification_preferences np join public.profiles p on p.id = np.user_id
                  where np.user_id = p_user and np.marketing and not p.is_blocked) then return 0; end if;
  insert into public.automation_items (rule_id, dedupe_key, status, target_user_id, title, body, link, payload)
  values (p_rule.id, p_dedupe, 'pending_approval', p_user, left(p_title, 140), left(p_body, 500), p_link, coalesce(p_payload, '{}'::jsonb))
  on conflict do nothing;
  return case when found then 1 else 0 end;
end $$;

-- Valuta i trigger di una regola. p_dry = true: conta i candidati senza scrivere nulla.
create or replace function public.automation_evaluate(p_rule public.automation_rules, p_dry boolean)
returns int language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; v_today date := (now() at time zone 'Europe/Rome')::date; v_cfg jsonb := p_rule.config;
begin
  case p_rule.trigger_key
  when 'favorites_category_affinity' then
    for r in select f.user_id, count(*) c from public.favorites f join public.restaurant_categories rc on rc.restaurant_id = f.restaurant_id
               join public.categories cat on cat.id = rc.category_id
              where cat.slug = coalesce(v_cfg ->> 'category', 'sushi') group by 1 having count(*) >= coalesce((v_cfg ->> 'min_favorites')::int, 3) loop
      -- Solo se esistono davvero offerte attive nella categoria (mai offerte inventate)
      continue when not exists (select 1 from public.offers o join public.restaurant_categories rc on rc.restaurant_id = o.restaurant_id join public.categories cat on cat.id = rc.category_id
                                 where cat.slug = coalesce(v_cfg ->> 'category', 'sushi') and o.is_active and (o.ends_at is null or o.ends_at > now()) and public.restaurant_is_public(o.restaurant_id));
      if p_dry then n := n + 1; else
        n := n + public.automation_draft(p_rule, r.user_id || ':' || to_char(now(), 'YYYY-MM'), r.user_id,
          format('Offerte %s attive su AsiaFood', coalesce((select name from public.categories where slug = v_cfg ->> 'category'), 'sushi')),
          'Ci sono offerte attive nei locali della categoria che segui. Scoprile nella sezione Offerte.', '/offerte', jsonb_build_object('category', v_cfg ->> 'category'));
      end if;
    end loop;
  when 'abandoned_cart' then
    for r in select c.id, c.user_id, rs.name from public.carts c join public.restaurants rs on rs.id = c.restaurant_id
              where c.status = 'active' and c.user_id is not null
                and c.updated_at between now() - make_interval(hours => coalesce((v_cfg ->> 'max_hours')::int, 48)) and now() - make_interval(hours => coalesce((v_cfg ->> 'min_hours')::int, 2))
                and exists (select 1 from public.cart_items ci where ci.cart_id = c.id)
                and not exists (select 1 from public.orders o where o.user_id = c.user_id and o.created_at > c.updated_at) loop
      if p_dry then n := n + 1; else
        n := n + public.automation_draft(p_rule, 'cart:' || r.id, r.user_id, 'Il tuo carrello ti aspetta',
          format('Hai lasciato dei piatti nel carrello di %s.', r.name), '/carrello', jsonb_build_object('cart_id', r.id));
      end if;
    end loop;
  when 'dormant_new_restaurants' then
    for r in select p.id user_id, p.city_id, (select count(*) from public.restaurants x join public.cities cx on cx.id = x.city_id join public.cities cp on cp.id = p.city_id
                                                where cx.province_id = cp.province_id and x.is_active and not x.is_demo and x.created_at > now() - interval '30 days') newr
               from public.profiles p
              where p.role::text = 'customer' and p.city_id is not null and not p.is_blocked
                and (select max(day) from public.user_activity_days a where a.user_id = p.id)
                    between v_today - coalesce((v_cfg ->> 'max_days')::int, 90) and v_today - coalesce((v_cfg ->> 'min_days')::int, 30) loop
      continue when r.newr = 0;
      if p_dry then n := n + 1; else
        n := n + public.automation_draft(p_rule, 'dormant:' || r.user_id || ':' || to_char(now(), 'YYYY-MM'), r.user_id, 'Nuovi ristoranti sono arrivati su AsiaFood',
          format('%s nuovi locali nella tua zona da scoprire.', r.newr), '/esplora', jsonb_build_object('new_restaurants', r.newr));
      end if;
    end loop;
  when 'profile_incomplete' then
    for r in select rs.id, rs.name, (public.restaurant_completion(rs.id) ->> 'score')::int score from public.restaurants rs
              where rs.owner_id is not null and rs.is_active and not rs.is_demo loop
      continue when r.score >= coalesce((v_cfg ->> 'threshold')::int, 60);
      if p_dry then n := n + 1; else
        n := n + public.automation_task(p_rule, 'incomplete:' || r.id, r.id, (select id from public.crm_leads where restaurant_id = r.id limit 1),
          format('Aiutare «%s» a completare il profilo (%s%%)', r.name, r.score), 'growth_incomplete', jsonb_build_object('score', r.score));
      end if;
    end loop;
  when 'trial_ending' then
    for r in select rs.id, rs.name, rs.owner_id, s.trial_end, s.trial_expiring_notified_at from public.subscriptions s join public.restaurants rs on rs.id = s.restaurant_id
              where public.subscription_in_env(s) and s.status = 'trialing' and s.trial_end between now() and now() + make_interval(days => coalesce((v_cfg ->> 'days')::int, 3))
                and not rs.is_demo loop
      if p_dry then n := n + 1; else
        n := n + public.automation_task(p_rule, 'trial:' || r.id || ':' || to_char(r.trial_end, 'YYYYMMDD'), r.id, (select id from public.crm_leads where restaurant_id = r.id limit 1),
          format('Prova di «%s» in scadenza il %s: follow-up', r.name, to_char(r.trial_end at time zone 'Europe/Rome', 'DD/MM')), 'trial_ending', '{}'::jsonb);
        -- Notifica al titolare (transazionale sul proprio account): solo se abilitata e non già inviata dalla fatturazione
        if coalesce((v_cfg ->> 'notify_owner')::boolean, false) and r.trial_expiring_notified_at is null and r.owner_id is not null
           and not exists (select 1 from public.automation_items where rule_id = p_rule.id and dedupe_key = 'notify:' || r.id || ':' || to_char(r.trial_end, 'YYYYMMDD')) then
          insert into public.notifications (user_id, restaurant_id, type, title, body, link)
          values (r.owner_id, r.id, 'billing_trial_expiring', 'La prova gratuita sta per terminare',
                  format('La prova di %s termina il %s. Puoi scegliere un piano quando vuoi: nessun addebito automatico da AsiaFood.', r.name, to_char(r.trial_end at time zone 'Europe/Rome', 'DD/MM/YYYY')),
                  '/dashboard/restaurants/' || r.id || '/billing');
          insert into public.automation_items (rule_id, dedupe_key, status, restaurant_id, title, sent_at)
          values (p_rule.id, 'notify:' || r.id || ':' || to_char(r.trial_end, 'YYYYMMDD'), 'sent', r.id, 'Notifica prova in scadenza', now()) on conflict do nothing;
        end if;
      end if;
    end loop;
  when 'payment_failed' then
    for r in select rs.id, rs.name, s.id sid from public.subscriptions s join public.restaurants rs on rs.id = s.restaurant_id
              where public.subscription_in_env(s) and s.status in ('past_due', 'unpaid') and not rs.is_demo loop
      if p_dry then n := n + 1; else
        n := n + public.automation_task(p_rule, 'payfail:' || r.sid || ':' || to_char(now(), 'YYYYMM'), r.id, (select id from public.crm_leads where restaurant_id = r.id limit 1),
          format('Pagamento non riuscito per «%s»: offrire supporto', r.name), 'payment_failed', '{}'::jsonb);
      end if;
    end loop;
  when 'lead_no_reply' then
    for r in select l.id, l.name, l.restaurant_id, max(a.created_at) last_contact from public.crm_leads l join public.crm_activities a on a.lead_id = l.id
              where l.status = 'contacted' and l.kind = 'restaurant' and a.type in ('call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'follow_up')
              group by l.id, l.name, l.restaurant_id having max(a.created_at) < now() - make_interval(days => coalesce((v_cfg ->> 'days')::int, 4))
                 and not bool_or(a.outcome = 'replied') loop
      if p_dry then n := n + 1; else
        n := n + public.automation_task(p_rule, 'noreply:' || r.id || ':' || to_char(r.last_contact, 'YYYYMMDD'), r.restaurant_id, r.id,
          format('Follow-up «%s»: nessuna risposta da %s giorni', r.name, extract(day from now() - r.last_contact)::int), 'followup_no_reply',
          jsonb_build_object('draft_template', 'followup_no_reply', 'note', 'Bozza nel Sales Playbook: verificare il consenso al contatto prima di inviarla.'));
      end if;
    end loop;
  when 'demo_completed' then
    for r in select l.id, l.name, l.restaurant_id, a.created_at from public.crm_activities a join public.crm_leads l on l.id = a.lead_id
              where a.type = 'demo' and a.created_at > now() - interval '7 days' and coalesce(a.outcome, 'done') in ('done', 'interested')
                and not exists (select 1 from public.crm_activities b where b.lead_id = l.id and b.created_at > a.created_at) loop
      if p_dry then n := n + 1; else
        n := n + public.automation_task(p_rule, 'demo:' || r.id || ':' || to_char(r.created_at, 'YYYYMMDD'), r.restaurant_id, r.id,
          format('Dopo la demo con «%s»: link di rivendicazione o prova', r.name), 'demo_next_step', '{}'::jsonb);
      end if;
    end loop;
  when 'trial_midpoint' then
    for r in select rs.id, rs.name, t.started_at, t.ends_at from public.billing_trials t join public.restaurants rs on rs.id = t.restaurant_id
              where t.converted_at is null and t.ends_at > now() and not rs.is_demo and now() >= t.started_at + (t.ends_at - t.started_at) / 2 loop
      if p_dry then n := n + 1; else
        n := n + public.automation_task(p_rule, 'midtrial:' || r.id || ':' || to_char(r.started_at, 'YYYYMMDD'), r.id, (select id from public.crm_leads where restaurant_id = r.id limit 1),
          format('Metà prova per «%s»: condividere i dati di performance', r.name), 'trial_midpoint', '{}'::jsonb);
      end if;
    end loop;
  when 'subscription_ended' then
    for r in select rs.id, rs.name, s.id sid from public.subscriptions s join public.restaurants rs on rs.id = s.restaurant_id
              where public.subscription_in_env(s) and s.paid_started_at is not null and s.ended_at > now() - make_interval(days => coalesce((v_cfg ->> 'days')::int, 90))
                and not rs.is_demo
                and not exists (select 1 from public.subscriptions s2 where s2.restaurant_id = rs.id and s2.status in ('active', 'trialing') and public.subscription_in_env(s2)) loop
      if p_dry then n := n + 1; else
        n := n + public.automation_task(p_rule, 'winback:' || r.sid, r.id, (select id from public.crm_leads where restaurant_id = r.id limit 1),
          format('Win-back «%s»: chiedere feedback (nessuna riattivazione senza consenso)', r.name), 'winback', '{}'::jsonb);
      end if;
    end loop;
  else
    return -1;   -- trigger non disponibile
  end case;
  return n;
end $$;

-- Esecuzione di una regola: kill switch, abilitazione, registro, errori (auto-disattivazione dopo 5 errori consecutivi)
create or replace function public.automation_run(p_rule_id uuid, p_trigger text default 'schedule')
returns jsonb language plpgsql security definer set search_path = public as $$
declare ru public.automation_rules; v_run uuid; v_n int; v_err text;
begin
  select * into ru from public.automation_rules where id = p_rule_id;
  if not found then raise exception 'Regola non trovata' using errcode = 'P0002'; end if;
  if p_trigger <> 'dry_run' and (public.billing_setting_bool('automation_kill_switch', false) or not ru.enabled or ru.action = 'unavailable') then
    insert into public.automation_runs (rule_id, trigger, status, completed_at, error)
    values (ru.id, p_trigger, 'skipped', now(), case when ru.action = 'unavailable' then 'Automazione non disponibile' when not ru.enabled then 'Regola disattivata' else 'Kill switch attivo' end)
    returning id into v_run;
    return jsonb_build_object('run_id', v_run, 'status', 'skipped');
  end if;
  insert into public.automation_runs (rule_id, trigger) values (ru.id, p_trigger) returning id into v_run;
  begin
    v_n := public.automation_evaluate(ru, p_trigger = 'dry_run');
    if v_n < 0 then
      update public.automation_runs set status = 'skipped', completed_at = now(), error = 'Trigger non disponibile' where id = v_run;
      return jsonb_build_object('run_id', v_run, 'status', 'skipped');
    end if;
    update public.automation_runs set status = 'success', records_affected = v_n, completed_at = now() where id = v_run;
    if p_trigger <> 'dry_run' then
      update public.automation_rules set last_run_at = now(), next_run_at = now() + make_interval(mins => interval_minutes), failure_count = 0, last_error = null where id = ru.id;
    end if;
    return jsonb_build_object('run_id', v_run, 'status', 'success', 'records_affected', v_n, 'dry_run', p_trigger = 'dry_run');
  exception when others then
    v_err := left(sqlerrm, 480);
    update public.automation_runs set status = 'failed', completed_at = now(), error = v_err where id = v_run;
    update public.automation_rules set failure_count = failure_count + 1, last_error = v_err, last_run_at = now(),
           next_run_at = now() + make_interval(mins => interval_minutes),
           enabled = case when failure_count + 1 >= 5 then false else enabled end where id = ru.id;
    return jsonb_build_object('run_id', v_run, 'status', 'failed', 'error', v_err);
  end;
end $$;

create or replace function public.automation_run_due()
returns jsonb language plpgsql security definer set search_path = public as $$
declare ru record; v_out jsonb := '[]'::jsonb;
begin
  perform public.assert_service();
  if public.billing_setting_bool('automation_kill_switch', false) then return jsonb_build_object('kill_switch', true); end if;
  for ru in select id, key from public.automation_rules where enabled and action <> 'unavailable' and (next_run_at is null or next_run_at <= now()) order by key loop
    v_out := v_out || jsonb_build_object(ru.key, public.automation_run(ru.id, 'schedule'));
  end loop;
  return jsonb_build_object('runs', v_out);
end $$;

create or replace function public.admin_automation_rules()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return jsonb_build_object('kill_switch', public.billing_setting_bool('automation_kill_switch', false),
    'rules', coalesce((select jsonb_agg(to_jsonb(r) || jsonb_build_object(
        'owner_name', (select coalesce(display_name, full_name) from public.profiles where id = r.owner_id),
        'pending_items', (select count(*) from public.automation_items i where i.rule_id = r.id and i.status = 'pending_approval'),
        'last_run', (select to_jsonb(x) from (select status, records_affected, started_at, completed_at, error from public.automation_runs where rule_id = r.id order by started_at desc limit 1) x))
      order by array_position(array['consumer', 'restaurant', 'sales'], r.audience), r.key) from public.automation_rules r), '[]'::jsonb));
end $$;

create or replace function public.admin_automation_rule_update(p_id uuid, p jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare ru public.automation_rules;
begin
  perform public.growth_assert_admin();
  select * into ru from public.automation_rules where id = p_id for update;
  if not found then raise exception 'Regola non trovata' using errcode = 'P0002'; end if;
  if (p ->> 'enabled')::boolean and ru.action = 'unavailable' then raise exception 'Automazione non disponibile: non può essere attivata' using errcode = 'P0001'; end if;
  update public.automation_rules set
    enabled = coalesce((p ->> 'enabled')::boolean, enabled),
    interval_minutes = coalesce((p ->> 'interval_minutes')::int, interval_minutes),
    owner_id = case when p ? 'owner_id' then case when public.is_admin_user(nullif(p ->> 'owner_id', '')::uuid) then nullif(p ->> 'owner_id', '')::uuid end else owner_id end,
    -- config: solo chiavi già previste dalla regola (nessuna logica arbitraria)
    config = case when jsonb_typeof(p -> 'config') = 'object' then config || (select coalesce(jsonb_object_agg(k, v), '{}'::jsonb) from jsonb_each(p -> 'config') e(k, v) where config ? k) else config end,
    failure_count = case when (p ->> 'enabled')::boolean then 0 else failure_count end,
    next_run_at = case when (p ->> 'enabled')::boolean and not enabled then now() else next_run_at end,
    updated_at = now()
   where id = p_id;
  perform public.audit_admin('automation_rule_update', 'automation_rule', p_id::text, p - 'config' || jsonb_build_object('config_keys', (select jsonb_agg(k) from jsonb_object_keys(coalesce(p -> 'config', '{}'::jsonb)) k)));
end $$;

create or replace function public.admin_automation_run_now(p_id uuid, p_dry_run boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  perform public.audit_admin(case when p_dry_run then 'automation_dry_run' else 'automation_run_manual' end, 'automation_rule', p_id::text, '{}'::jsonb);
  return public.automation_run(p_id, case when p_dry_run then 'dry_run' else 'manual' end);
end $$;

create or replace function public.admin_automation_kill_switch(p_on boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  insert into public.platform_settings (key, value, description) values ('automation_kill_switch', to_jsonb(coalesce(p_on, true)), 'Interruttore generale automazioni')
  on conflict (key) do update set value = excluded.value;
  perform public.audit_admin('automation_kill_switch', 'platform_settings', 'automation_kill_switch', jsonb_build_object('on', p_on));
end $$;

create or replace function public.admin_automation_runs(p_rule uuid default null, p_limit int default 50)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(x) order by x.started_at desc) from (
    select ar.*, r.name rule_name from public.automation_runs ar join public.automation_rules r on r.id = ar.rule_id
     where p_rule is null or ar.rule_id = p_rule order by ar.started_at desc limit least(coalesce(p_limit, 50), 200)) x), '[]'::jsonb);
end $$;

-- Bozze in attesa: l'Admin vede solo titolo/testo e il fatto che il destinatario ha consenso (mai email/telefono)
create or replace function public.admin_automation_items(p_status text default 'pending_approval', p_limit int default 100)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'rule_id', i.rule_id, 'rule_name', r.name, 'status', i.status, 'title', i.title, 'body', i.body, 'link', i.link,
      'restaurant_id', i.restaurant_id, 'restaurant_name', (select name from public.restaurants where id = i.restaurant_id), 'has_recipient', i.target_user_id is not null,
      'payload', i.payload, 'created_at', i.created_at, 'decided_at', i.decided_at, 'sent_at', i.sent_at) order by i.created_at desc)
    from (select * from public.automation_items where p_status is null or p_status = '' or status = p_status order by created_at desc limit least(coalesce(p_limit, 100), 500)) i
    join public.automation_rules r on r.id = i.rule_id), '[]'::jsonb);
end $$;

-- Approvazione umana: invio in-app SOLO se il consenso marketing è ancora valido al momento dell'approvazione
create or replace function public.admin_automation_decide(p_id uuid, p_approve boolean)
returns text language plpgsql security definer set search_path = public as $$
declare i public.automation_items;
begin
  perform public.growth_assert_admin();
  select * into i from public.automation_items where id = p_id for update;
  if not found or i.status <> 'pending_approval' then raise exception 'Elemento non in attesa di approvazione' using errcode = 'P0001'; end if;
  if not p_approve then
    update public.automation_items set status = 'rejected', decided_by = auth.uid(), decided_at = now() where id = p_id;
    perform public.audit_admin('automation_item_rejected', 'automation_item', p_id::text, '{}'::jsonb);
    return 'rejected';
  end if;
  if i.target_user_id is null or not exists (select 1 from public.notification_preferences where user_id = i.target_user_id and marketing) then
    update public.automation_items set status = 'skipped', decided_by = auth.uid(), decided_at = now() where id = p_id;
    return 'skipped_no_consent';
  end if;
  insert into public.notifications (user_id, type, title, body, link) values (i.target_user_id, 'marketing_campaign', i.title, i.body, i.link);
  update public.automation_items set status = 'sent', decided_by = auth.uid(), decided_at = now(), sent_at = now() where id = p_id;
  perform public.audit_admin('automation_item_sent', 'automation_item', p_id::text, jsonb_build_object('rule_id', i.rule_id));
  return 'sent';
end $$;

-- ────────────────────────────────────────────────────────────────────
--  6. ESPERIMENTI: varianti con allocazione, assegnazioni, conversioni, report senza falsi vincitori
-- ────────────────────────────────────────────────────────────────────
create or replace function public.running_experiments()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('key', e.key, 'variants', e.variants,
    'weights', coalesce((select jsonb_agg(v.allocation_percentage order by array_position(e.variants, v.name)) from public.experiment_variants v where v.experiment_id = e.id), '[]'::jsonb),
    'primary_metric', e.primary_metric)), '[]'::jsonb)
  from public.experiments e where e.status = 'running' and (e.end_at is null or e.end_at > now());
$$;

-- Assegnazione (il client la invia SOLO con consenso "Statistiche"): idempotente per browser
create or replace function public.experiment_assign(p_key text, p_variant text, p_anon text)
returns void language plpgsql security definer set search_path = public as $$
declare e public.experiments; v uuid;
begin
  if p_anon is null or p_anon !~ '^[A-Za-z0-9_-]{8,64}$' then return; end if;
  if not public.rate_limit_hit('exp_assign', public.rate_limit_caller_key(), 30, 60) then return; end if;
  select * into e from public.experiments where key = p_key and status = 'running';
  if not found then return; end if;
  select id into v from public.experiment_variants where experiment_id = e.id and name = p_variant;
  if v is null then return; end if;
  insert into public.experiment_assignments (experiment_id, variant_id, anonymous_id, user_id) values (e.id, v, p_anon, auth.uid())
  on conflict (experiment_id, anonymous_id) where anonymous_id is not null do update set user_id = coalesce(public.experiment_assignments.user_id, excluded.user_id);
end $$;

-- Conversione sulla metrica primaria (reservation_completed, order_completed, coupon_claimed, signup)
create or replace function public.experiment_goal(p_metric text, p_anon text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_anon is null or p_anon !~ '^[A-Za-z0-9_-]{8,64}$' or p_metric not in ('reservation_completed', 'order_completed', 'coupon_claimed', 'signup') then return; end if;
  if not public.rate_limit_hit('exp_goal', public.rate_limit_caller_key(), 30, 60) then return; end if;
  update public.experiment_assignments a set converted_at = now()
    from public.experiments e
   where e.id = a.experiment_id and e.status = 'running' and e.primary_metric = p_metric and a.anonymous_id = p_anon and a.converted_at is null;
end $$;

create or replace function public.admin_experiment_report(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare e public.experiments; v_min int := public.billing_setting_int('growth_experiment_min_sample', 100); v_rows jsonb;
begin
  perform public.growth_assert_admin();
  select * into e from public.experiments where id = p_id;
  if not found then raise exception 'Esperimento non trovato' using errcode = 'P0002'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('variant', v.name, 'allocation', v.allocation_percentage,
      'users', (select count(*) from public.experiment_assignments a where a.variant_id = v.id),
      'conversions', (select count(*) from public.experiment_assignments a where a.variant_id = v.id and a.converted_at is not null)) order by array_position(e.variants, v.name)), '[]'::jsonb)
    into v_rows from public.experiment_variants v where v.experiment_id = e.id;
  -- Il vincitore (test z su due proporzioni) è calcolato lato client con shared/growth.ts → experimentVerdict(), stessi numeri
  return jsonb_build_object('experiment', to_jsonb(e), 'variants', v_rows, 'min_sample', v_min,
    'exposures', (select count(*) from public.app_events where event_type = 'experiment_exposure' and metadata ->> 'experiment' = e.key));
end $$;

create or replace function public.admin_experiment_upsert(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p ->> 'id', '')::uuid; v_vars text[]; v_alloc int[]; e public.experiments; i int;
begin
  perform public.growth_assert_admin();
  if p ? 'variants' then
    select array_agg(lower(regexp_replace(coalesce(x ->> 'name', x #>> '{}'), '[^A-Za-z0-9_]', '', 'g')) order by o),
           array_agg(coalesce((x ->> 'allocation')::int, 0) order by o)
      into v_vars, v_alloc from jsonb_array_elements(p -> 'variants') with ordinality t(x, o);
    if cardinality(v_vars) not between 2 and 3 then raise exception 'Servono 2 o 3 varianti' using errcode = '22023'; end if;
    if (select sum(a) from unnest(v_alloc) a) = 0 then v_alloc := array_fill(100 / cardinality(v_vars), array[cardinality(v_vars)]); end if;
    if (select sum(a) from unnest(v_alloc) a) <> 100 and (select sum(a) from unnest(v_alloc) a) <> (100 / cardinality(v_vars)) * cardinality(v_vars) then
      raise exception 'Le allocazioni devono sommare a 100' using errcode = '22023';
    end if;
  end if;
  if coalesce(p ->> 'guardrail_area', 'none') not in ('none', 'pricing', 'consent', 'security', 'accessibility') then raise exception 'Area non valida' using errcode = '22023'; end if;
  if v_id is null then
    insert into public.experiments (key, name, hypothesis, primary_metric, variants, secondary_metrics, guardrail_area, end_at, created_by)
    values (lower(p ->> 'key'), p ->> 'name', nullif(p ->> 'hypothesis', ''), nullif(p ->> 'primary_metric', ''), coalesce(v_vars, array['control', 'variant_b']),
            coalesce((select array_agg(x) from jsonb_array_elements_text(p -> 'secondary_metrics') x), '{}'), coalesce(p ->> 'guardrail_area', 'none'),
            nullif(p ->> 'end_at', '')::timestamptz, auth.uid())
    returning id into v_id;
  else
    select * into e from public.experiments where id = v_id for update;
    update public.experiments set name = coalesce(p ->> 'name', name), hypothesis = coalesce(p ->> 'hypothesis', hypothesis),
      primary_metric = case when status = 'draft' then coalesce(p ->> 'primary_metric', primary_metric) else primary_metric end,
      variants = case when status = 'draft' then coalesce(v_vars, variants) else variants end,
      secondary_metrics = coalesce((select array_agg(x) from jsonb_array_elements_text(p -> 'secondary_metrics') x), secondary_metrics),
      guardrail_area = case when status = 'draft' then coalesce(p ->> 'guardrail_area', guardrail_area) else guardrail_area end,
      -- Cambiare l'area sensibile invalida la revisione precedente
      review_approved_at = case when status = 'draft' and coalesce(p ->> 'guardrail_area', guardrail_area) <> guardrail_area then null else review_approved_at end,
      end_at = case when p ? 'end_at' then nullif(p ->> 'end_at', '')::timestamptz else end_at end
     where id = v_id;
    if e.status <> 'draft' then v_vars := null; end if;
  end if;
  if v_vars is not null then
    delete from public.experiment_variants where experiment_id = v_id and not (name = any(v_vars));
    for i in 1 .. cardinality(v_vars) loop
      insert into public.experiment_variants (experiment_id, name, allocation_percentage) values (v_id, v_vars[i], greatest(1, v_alloc[i]))
      on conflict (experiment_id, name) do update set allocation_percentage = excluded.allocation_percentage;
    end loop;
  elsif not exists (select 1 from public.experiment_variants where experiment_id = v_id) then
    insert into public.experiment_variants (experiment_id, name, allocation_percentage)
    select v_id, x, 100 / cardinality(e2.variants) from public.experiments e2, unnest(e2.variants) x where e2.id = v_id on conflict do nothing;
  end if;
  return v_id;
end $$;

-- Revisione obbligatoria per esperimenti su prezzi, consenso privacy, sicurezza o accessibilità critica
create or replace function public.admin_experiment_review(p_id uuid, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare e public.experiments;
begin
  perform public.growth_assert_admin();
  select * into e from public.experiments where id = p_id for update;
  if not found then raise exception 'Esperimento non trovato' using errcode = 'P0002'; end if;
  if e.guardrail_area = 'none' then raise exception 'Nessuna revisione necessaria' using errcode = 'P0001'; end if;
  if coalesce(char_length(trim(p_note)), 0) < 10 then raise exception 'Motiva la revisione (almeno 10 caratteri)' using errcode = '22023'; end if;
  -- Chi crea non si auto-approva: serve un secondo Admin
  if e.created_by = auth.uid() then raise exception 'La revisione deve essere fatta da un Admin diverso da chi ha creato l''esperimento' using errcode = 'P0001'; end if;
  update public.experiments set review_approved_by = auth.uid(), review_approved_at = now(), review_note = left(p_note, 500) where id = p_id;
  perform public.audit_admin('experiment_reviewed', 'experiment', p_id::text, jsonb_build_object('area', e.guardrail_area));
end $$;

create or replace function public.admin_experiment_set_status(p_id uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
declare e public.experiments;
begin
  perform public.launch_assert_admin();
  if p_status not in ('draft', 'running', 'stopped') then raise exception 'Stato non valido'; end if;
  select * into e from public.experiments where id = p_id;
  if p_status = 'running' and e.guardrail_area <> 'none' and e.review_approved_at is null then
    raise exception 'Esperimento su area sensibile (%): serve la revisione di un secondo Admin prima dell''avvio', e.guardrail_area using errcode = 'P0001';
  end if;
  if p_status = 'running' and (select count(*) from public.experiments where status = 'running' and id <> p_id) >= public.billing_setting_int('experiments_max_running', 2) then
    raise exception 'Troppi esperimenti attivi: fermane uno prima di avviarne un altro' using errcode = 'P0001';
  end if;
  if p_status = 'running' and not exists (select 1 from public.experiment_variants where experiment_id = p_id) then
    insert into public.experiment_variants (experiment_id, name, allocation_percentage) select p_id, x, 100 / cardinality(e.variants) from unnest(e.variants) x on conflict do nothing;
  end if;
  update public.experiments set status = p_status,
    started_at = case when p_status = 'running' then coalesce(started_at, now()) else started_at end,
    stopped_at = case when p_status = 'stopped' then now() else null end where id = p_id;
  perform public.audit_admin('experiment_' || p_status, 'experiment', p_id::text, '{}'::jsonb);
end $$;

create or replace function public.admin_experiments()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(e) || jsonb_build_object(
      'allocations', (select coalesce(jsonb_agg(jsonb_build_object('name', v.name, 'allocation', v.allocation_percentage) order by array_position(e.variants, v.name)), '[]'::jsonb)
                        from public.experiment_variants v where v.experiment_id = e.id),
      'assignments', (select count(*) from public.experiment_assignments a where a.experiment_id = e.id),
      'same_creator', e.created_by = auth.uid()) order by e.created_at desc) from public.experiments e), '[]'::jsonb);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  7. REPORT SETTIMANALE (zero resta zero; nessuna narrativa inventata) E BRIEF GIORNALIERO
-- ────────────────────────────────────────────────────────────────────
create or replace function public.growth_generate_report(p_type text, p_from date, p_to date, p_market uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_cur jsonb; v_prev jsonb; v_days int := p_to - p_from + 1; v_m jsonb; v_sum text; v_id uuid; v_slug text; v_churn jsonb; v_rev jsonb; v_gaps jsonb; v_ret jsonb;
  fmt_delta text;
begin
  if not public.is_admin_or_service() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p_type not in ('weekly', 'monthly', 'custom') or p_to < p_from or v_days > 400 then raise exception 'Parametri non validi' using errcode = '22023'; end if;
  select slug into v_slug from public.markets where id = p_market;
  v_cur := public.growth_period_totals(p_from, p_to, v_slug);
  v_prev := public.growth_period_totals(p_from - v_days, p_from - 1, v_slug);
  v_gaps := public.growth_supply_gap(p_from, p_to, v_slug);
  v_m := jsonb_build_object(
    'period', jsonb_build_object('from', p_from, 'to', p_to, 'market', v_slug),
    'current', v_cur, 'previous', case when (v_prev ->> 'complete')::boolean then v_prev end,
    'restaurants', jsonb_build_object(
      'active', (select count(*) from public.restaurants r where r.id in (select public.growth_market_restaurants(v_slug)) and r.is_active),
      'claimed_in_period', (select count(*) from public.restaurants r where r.id in (select public.growth_market_restaurants(v_slug)) and r.claimed_at::date between p_from and p_to),
      'paying', (select count(distinct s.restaurant_id) from public.subscriptions s where s.restaurant_id in (select public.growth_market_restaurants(v_slug))
                   and public.subscription_in_env(s) and s.paid_started_at is not null and s.status in ('active', 'past_due') and public.subscription_grants_access(s))),
    'sales', jsonb_build_object(
      'activities', (select count(*) from public.crm_activities a join public.crm_leads l on l.id = a.lead_id where a.created_at::date between p_from and p_to
                       and (p_market is null or l.market_id = p_market)),
      'trials_started', (select count(*) from public.billing_trials t where t.started_at::date between p_from and p_to and t.restaurant_id in (select public.growth_market_restaurants(v_slug)))),
    'revenue', jsonb_build_object('mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                   where s.restaurant_id in (select public.growth_market_restaurants(v_slug)) and public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
                 'movements', public.growth_mrr_movements(p_from, p_to)),
    'retention_d7', (select jsonb_build_object('eligible', count(*), 'returned', count(*) filter (where exists (select 1 from public.user_activity_days a where a.user_id = p.id
                        and a.day between (p.created_at at time zone 'Europe/Rome')::date + 1 and (p.created_at at time zone 'Europe/Rome')::date + 7)))
                      from public.profiles p where p.role::text = 'customer' and (p.created_at at time zone 'Europe/Rome')::date between p_from - 7 and p_to - 7),
    'top_searches', coalesce((select jsonb_agg(jsonb_build_object('query', nullif(query_norm, ''), 'city', nullif(city_slug, ''), 'category', nullif(category_slug, ''), 'searches', n, 'zero_results', z) order by n desc)
                                from (select query_norm, city_slug, category_slug, sum(searches) n, sum(zero_results) z from public.daily_search_metrics
                                       where date between p_from and p_to group by 1, 2, 3 order by 4 desc limit 10) t), '[]'::jsonb),
    'supply_gaps', (select coalesce(jsonb_agg(x), '[]'::jsonb) from (select x from jsonb_array_elements(v_gaps) x limit 10) t),
    'churn_risks', coalesce((select jsonb_agg(jsonb_build_object('title', title, 'severity', severity)) from public.growth_alerts
                               where status <> 'resolved' and category in ('trial', 'billing', 'restaurant')), '[]'::jsonb),
    'next_actions', coalesce((select jsonb_agg(jsonb_build_object('title', title, 'source', source)) from (
                               select title, source from public.growth_tasks where status = 'open' and (p_market is null or market_id = p_market or market_id is null)
                                order by priority = 'high' desc, created_at limit 10) t), '[]'::jsonb));
  -- Sintesi: solo frasi costruite dai numeri (lo zero resta zero); confronto solo se il periodo precedente è completo
  fmt_delta := case when (v_prev ->> 'complete')::boolean and coalesce((v_prev ->> 'visits')::numeric, 0) > 0
                    then format(' (%s%s%% sul periodo precedente)', case when (v_cur ->> 'visits')::numeric >= (v_prev ->> 'visits')::numeric then '+' else '' end,
                                round(((v_cur ->> 'visits')::numeric - (v_prev ->> 'visits')::numeric) * 100 / (v_prev ->> 'visits')::numeric)) else '' end;
  v_sum := concat_ws(E'\n',
    format('Periodo %s – %s%s.', to_char(p_from, 'DD/MM/YYYY'), to_char(p_to, 'DD/MM/YYYY'), case when v_slug is not null then ' · mercato ' || v_slug else '' end),
    format('Visite: %s%s. Nuovi utenti: %s. Utenti attivi: %s.', v_cur ->> 'visits', fmt_delta, coalesce(v_cur ->> 'new_users', 'n/d'), coalesce(v_cur ->> 'active_users', 'n/d')),
    format('Ricerche: %s, di cui senza risultati: %s.', v_cur ->> 'searches', v_cur ->> 'zero_result_searches'),
    format('Prenotazioni: %s. Ordini pagati: %s. Coupon utilizzati: %s.', v_cur ->> 'reservations', v_cur ->> 'orders', v_cur ->> 'coupon_redemptions'),
    format('Ristoranti paganti: %s. MRR: € %s.', v_m -> 'restaurants' ->> 'paying', to_char(((v_m -> 'revenue' ->> 'mrr_cents')::numeric) / 100, 'FM999G999G990D00')),
    case when not (v_cur ->> 'complete')::boolean then 'Attenzione: alcuni giorni del periodo non sono aggregati; i totali possono essere incompleti.' end,
    case when public.demo_data_visible() then 'I numeri includono i locali DEMO (ambiente non di produzione).' end);
  if p_type = 'custom' then
    insert into public.growth_reports (period_start, period_end, market_id, report_type, metrics_json, summary, created_by)
    values (p_from, p_to, p_market, p_type, v_m, v_sum, auth.uid()) returning id into v_id;
  else
    insert into public.growth_reports (period_start, period_end, market_id, report_type, metrics_json, summary, created_by)
    values (p_from, p_to, p_market, p_type, v_m, v_sum, auth.uid())
    on conflict (report_type, period_start, period_end, coalesce(market_id, '00000000-0000-0000-0000-000000000000'::uuid)) where report_type <> 'custom'
    do update set metrics_json = excluded.metrics_json, summary = excluded.summary, created_at = now()
    returning id into v_id;
  end if;
  return v_id;
end $$;

create or replace function public.admin_growth_reports(p_limit int default 20)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(r) order by r.period_end desc, r.created_at desc) from (
    select * from public.growth_reports order by period_end desc, created_at desc limit least(coalesce(p_limit, 20), 100)) r), '[]'::jsonb);
end $$;

create or replace function public.admin_growth_generate_report(p_type text, p_from date, p_to date, p_market text default null)
returns uuid language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return public.growth_generate_report(p_type, p_from, p_to, (select id from public.markets where slug = nullif(p_market, '')));
end $$;

-- "Today": massimo 10 priorità operative, ordinate per gravità
create or replace function public.admin_growth_today()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb := '[]'::jsonb; r record; v_n int;
begin
  perform public.growth_assert_admin();
  for r in select title, detail, link, severity from public.growth_alerts where status = 'open' and severity = 'critical' order by last_seen_at desc limit 4 loop
    v := v || jsonb_build_object('priority', 1, 'kind', 'alert', 'title', r.title, 'detail', r.detail, 'link', coalesce(r.link, '/admin/growth/alerts'));
  end loop;
  select count(*) into v_n from public.automation_items where status = 'pending_approval';
  if v_n > 0 then v := v || jsonb_build_object('priority', 2, 'kind', 'approval', 'title', format('%s messaggi in attesa di approvazione', v_n),
                                                'detail', 'Nessun messaggio parte senza approvazione.', 'link', '/admin/growth/automations'); end if;
  select count(*) into v_n from public.subscriptions s join public.restaurants rs on rs.id = s.restaurant_id where public.subscription_in_env(s) and s.status = 'trialing'
     and s.trial_end between now() and now() + interval '3 days' and public.growth_in_scope(rs.is_demo);
  if v_n > 0 then v := v || jsonb_build_object('priority', 2, 'kind', 'trial', 'title', format('%s prove in scadenza entro 3 giorni', v_n), 'detail', 'Follow-up commerciale.', 'link', '/admin/growth/churn'); end if;
  select count(*) into v_n from public.crm_tasks where status = 'open' and due_at < now() + interval '1 day';
  if v_n > 0 then v := v || jsonb_build_object('priority', 3, 'kind', 'crm', 'title', format('%s task CRM in scadenza o scaduti', v_n), 'detail', null, 'link', '/admin/launch/taranto/sales'); end if;
  select count(*) into v_n from public.growth_tasks where status = 'open' and (due_at is null or due_at < now() + interval '1 day') and priority = 'high';
  if v_n > 0 then v := v || jsonb_build_object('priority', 3, 'kind', 'growth_task', 'title', format('%s task growth ad alta priorità', v_n), 'detail', null, 'link', '/admin/growth/tasks'); end if;
  for r in select title, detail, link from public.growth_alerts where status = 'open' and severity = 'warning' order by last_seen_at desc limit 4 loop
    v := v || jsonb_build_object('priority', 4, 'kind', 'alert', 'title', r.title, 'detail', r.detail, 'link', coalesce(r.link, '/admin/growth/alerts'));
  end loop;
  select count(*) into v_n from public.product_feedback where status = 'new';
  if v_n > 0 then v := v || jsonb_build_object('priority', 5, 'kind', 'feedback', 'title', format('%s feedback da leggere', v_n), 'detail', null, 'link', '/admin/launch/taranto/quality'); end if;
  select count(*) into v_n from public.support_tickets where status = 'open';
  if v_n > 0 then v := v || jsonb_build_object('priority', 5, 'kind', 'support', 'title', format('%s ticket di supporto aperti', v_n), 'detail', null, 'link', '/admin/support'); end if;
  return coalesce((select jsonb_agg(x order by (x ->> 'priority')::int) from (select x from jsonb_array_elements(v) x order by (x ->> 'priority')::int limit 10) t), '[]'::jsonb);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  8. TASK DA INSIGHT (nessuna esecuzione automatica), KNOWLEDGE BASE
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_tasks(p_status text default 'open')
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(t) || jsonb_build_object('market_slug', (select slug from public.markets where id = t.market_id))
                     order by t.priority = 'high' desc, t.due_at nulls last, t.created_at desc)
                     from public.growth_tasks t where p_status is null or p_status = '' or t.status = p_status), '[]'::jsonb);
end $$;

create or replace function public.admin_growth_task_upsert(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  perform public.growth_assert_admin();
  if v_id is null then
    insert into public.growth_tasks (market_id, title, description, source, source_ref, priority, due_at)
    values ((select id from public.markets where slug = nullif(p ->> 'market', '')), p ->> 'title', nullif(p ->> 'description', ''),
            coalesce(nullif(p ->> 'source', ''), 'manual'), nullif(p ->> 'source_ref', ''), coalesce(nullif(p ->> 'priority', ''), 'normal'), nullif(p ->> 'due_at', '')::timestamptz)
    on conflict (source, source_ref) where status = 'open' and source_ref is not null do update set title = excluded.title
    returning id into v_id;
  else
    update public.growth_tasks set title = coalesce(p ->> 'title', title), description = coalesce(p ->> 'description', description),
      priority = coalesce(p ->> 'priority', priority), due_at = case when p ? 'due_at' then nullif(p ->> 'due_at', '')::timestamptz else due_at end where id = v_id;
  end if;
  return v_id;
end $$;

create or replace function public.admin_growth_task_set_status(p_id uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  if p_status not in ('open', 'done', 'dismissed') then raise exception 'Stato non valido' using errcode = '22023'; end if;
  update public.growth_tasks set status = p_status, done_at = case when p_status = 'done' then now() end where id = p_id;
end $$;

-- Evidenze suggerite (calcolate, NON salvate): l'Admin decide se registrarle come apprendimento
create or replace function public.admin_growth_learning_evidence(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_m uuid := (select id from public.markets where slug = p_market);
begin
  perform public.growth_assert_admin();
  return jsonb_build_object(
    'outreach', coalesce((select jsonb_agg(jsonb_build_object('channel', type, 'contacts', n, 'replied', r, 'rate', case when n > 0 then round(r * 100.0 / n) end,
                           'confidence', case when n >= 30 then 'high' when n >= 10 then 'medium' else 'low' end) order by case when n > 0 then r::numeric / n end desc nulls last)
                          from (select a.type, count(*) n, count(*) filter (where a.outcome in ('replied', 'interested', 'scheduled')) r
                                  from public.crm_activities a join public.crm_leads l on l.id = a.lead_id
                                 where l.market_id = v_m and a.type in ('call', 'whatsapp', 'email', 'instagram_dm', 'visit') group by 1) t), '[]'::jsonb),
    'trial_conversion', (select jsonb_build_object('ended', count(*) filter (where t.ends_at <= now() or t.converted_at is not null), 'converted', count(*) filter (where t.converted_at is not null))
                           from public.billing_trials t join public.launch_market_ids(v_m) mr(id) on mr.id = t.restaurant_id),
    'qr', jsonb_build_object('scans', (select count(*) from public.analytics_events e join public.launch_market_ids(v_m) mr(id) on mr.id = e.restaurant_id where e.event_type = 'qr_scan'),
                             'visits', (select count(*) from public.acquisition_visits where market_id = v_m and channel = 'qr'),
                             'signups', (select count(*) from public.user_acquisition where market_id = v_m and channel = 'qr')),
    'acquisition', coalesce((select jsonb_agg(jsonb_build_object('channel', ch, 'signups', n) order by n desc) from (
                       select public.growth_channel(channel, utm_source) ch, count(*) n from public.user_acquisition where market_id = v_m group by 1) t), '[]'::jsonb),
    'note', 'Evidenze osservate in questo mercato. Prima di applicarle a un altro mercato vanno verificate: contesti diversi, risultati diversi.');
end $$;

create or replace function public.admin_growth_learnings()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(l) || jsonb_build_object('market_slug', (select slug from public.markets where id = l.market_id)) order by l.created_at desc)
                     from public.growth_learnings l), '[]'::jsonb);
end $$;

create or replace function public.admin_growth_learning_upsert(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  perform public.growth_assert_admin();
  if v_id is null then
    insert into public.growth_learnings (market_id, category, title, description, evidence_json, confidence)
    values ((select id from public.markets where slug = nullif(p ->> 'market', '')), p ->> 'category', p ->> 'title', p ->> 'description',
            coalesce(p -> 'evidence', '{}'::jsonb), coalesce(nullif(p ->> 'confidence', ''), 'low'))
    returning id into v_id;
  else
    update public.growth_learnings set category = coalesce(p ->> 'category', category), title = coalesce(p ->> 'title', title),
      description = coalesce(p ->> 'description', description), evidence_json = coalesce(p -> 'evidence', evidence_json), confidence = coalesce(p ->> 'confidence', confidence)
     where id = v_id;
  end if;
  return v_id;
end $$;

create or replace function public.admin_growth_learning_delete(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  delete from public.growth_learnings where id = p_id;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  9. COSTI E UNIT ECONOMICS (solo costi reali o configurati; ipotesi sempre etichettate)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_costs(p_from date, p_to date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_from timestamptz := p_from::timestamp at time zone 'Europe/Rome'; v_to timestamptz := (p_to + 1)::timestamp at time zone 'Europe/Rome';
  v_ai numeric; v_proc numeric; v_proc_missing int; v_orders int; v_fee_pct numeric := public.setting_num('growth_payment_fee_pct', null);
  v_manual jsonb; v_mkt numeric; v_tot jsonb; v_active int; v_paying int; v_proc_est numeric; v_var numeric;
begin
  perform public.growth_assert_admin();
  select coalesce(sum(estimated_cost), 0) * 100 into v_ai from public.ai_usage where created_at >= v_from and created_at < v_to;
  select coalesce(sum(payment_processing_fee) * 100, 0), count(*) filter (where payment_processing_fee is null), count(*)
    into v_proc, v_proc_missing, v_orders
    from public.orders o join public.restaurants r on r.id = o.restaurant_id
   where o.paid_at >= v_from and o.paid_at < v_to and o.payment_status in ('paid', 'partially_refunded') and public.growth_in_scope(r.is_demo);
  if v_fee_pct is not null and v_proc_missing > 0 then
    select round(sum(o.total) * v_fee_pct) into v_proc_est from public.orders o
     where o.paid_at >= v_from and o.paid_at < v_to and o.payment_status in ('paid', 'partially_refunded') and o.payment_processing_fee is null;
  end if;
  -- Costi manuali ripartiti in proporzione ai giorni di sovrapposizione con il periodo
  select coalesce(jsonb_object_agg(category, cents), '{}'::jsonb) into v_manual from (
    select category, round(sum(amount_cents * (least(period_end, p_to) - greatest(period_start, p_from) + 1)::numeric / (period_end - period_start + 1))) cents
      from public.operating_costs where period_start <= p_to and period_end >= p_from group by 1) t;
  select coalesce(sum(amount_cents), 0) into v_mkt from public.acquisition_costs where spent_on between p_from and p_to;
  v_tot := public.growth_period_totals(p_from, p_to, null);
  select count(distinct user_id) into v_active from public.user_activity_days where day between p_from and p_to;
  select count(distinct s.restaurant_id) into v_paying from public.subscriptions s where public.subscription_in_env(s) and s.paid_started_at is not null
     and s.paid_started_at < v_to and coalesce(s.ended_at, 'infinity') >= v_from;
  v_var := v_ai + v_proc + coalesce(v_proc_est, 0) + coalesce((v_manual ->> 'ai')::numeric, 0) + coalesce((v_manual ->> 'email')::numeric, 0)
         + coalesce((v_manual ->> 'push')::numeric, 0) + coalesce((v_manual ->> 'maps')::numeric, 0) + coalesce((v_manual ->> 'payment_processing')::numeric, 0);
  return jsonb_build_object(
    'costs', jsonb_build_array(
      jsonb_build_object('key', 'ai', 'label', 'AI (consumo token × tariffe configurate)', 'cents', round(v_ai + coalesce((v_manual ->> 'ai')::numeric, 0)), 'source', 'computed'),
      jsonb_build_object('key', 'payment_processing', 'label', 'Incasso pagamenti (commissioni reali degli ordini)', 'cents', round(v_proc + coalesce((v_manual ->> 'payment_processing')::numeric, 0)), 'source', 'real'),
      jsonb_build_object('key', 'payment_processing_estimate', 'label', format('Incasso stimato per %s ordini senza commissione registrata (ipotesi %s)', v_proc_missing, coalesce(v_fee_pct * 100 || '%', 'non configurata')),
                         'cents', v_proc_est, 'source', 'assumption'),
      jsonb_build_object('key', 'email', 'label', 'Email', 'cents', (v_manual ->> 'email')::numeric, 'source', 'manual'),
      jsonb_build_object('key', 'push', 'label', 'Push', 'cents', (v_manual ->> 'push')::numeric, 'source', 'manual'),
      jsonb_build_object('key', 'maps', 'label', 'Mappe', 'cents', (v_manual ->> 'maps')::numeric, 'source', 'manual'),
      jsonb_build_object('key', 'infrastructure', 'label', 'Infrastruttura', 'cents', (v_manual ->> 'infrastructure')::numeric, 'source', 'manual'),
      jsonb_build_object('key', 'ads', 'label', 'Pubblicità e marketing (costi di acquisizione registrati + manuali)', 'cents', v_mkt + coalesce((v_manual ->> 'ads')::numeric, 0), 'source', 'manual'),
      jsonb_build_object('key', 'other', 'label', 'Altro', 'cents', (v_manual ->> 'other')::numeric, 'source', 'manual')),
    'unit', jsonb_build_object(
      'revenue_per_paid_restaurant_cents', case when v_paying > 0 then round((v_tot ->> 'subscription_revenue_cents')::numeric / v_paying) end,
      'ai_cost_per_active_user_cents', case when v_active > 0 then round(v_ai / v_active, 2) end,
      'processing_cost_per_order_cents', case when v_orders > 0 and v_proc_missing = 0 then round(v_proc / v_orders, 2) end,
      'contribution_margin_cents', round((v_tot ->> 'platform_revenue_cents')::numeric - v_var),
      'assumptions', jsonb_build_array(
        'Margine di contribuzione APPROSSIMATO = ricavi piattaforma (fatture abbonamenti + commissioni ordini) − costi variabili (AI, incasso, email, push, mappe).',
        'I costi manuali sono ripartiti in proporzione ai giorni del periodo.',
        'Il costo AI è stimato da token × tariffe impostate (ai_cost_*_per_mtok), non dalla fattura del provider.',
        case when v_proc_missing > 0 then format('%s ordini non riportano la commissione di incasso reale: costo per ordine non calcolato.', v_proc_missing) end)),
    'counts', jsonb_build_object('orders', v_orders, 'active_users', v_active, 'paying_restaurants', v_paying),
    'manual', coalesce((select jsonb_agg(to_jsonb(c) order by c.period_start desc) from public.operating_costs c where c.period_start <= p_to and c.period_end >= p_from), '[]'::jsonb));
end $$;

create or replace function public.admin_operating_cost_add(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  perform public.growth_assert_admin();
  insert into public.operating_costs (category, amount_cents, period_start, period_end, notes)
  values (p ->> 'category', (p ->> 'amount_cents')::int, (p ->> 'period_start')::date, (p ->> 'period_end')::date, nullif(p ->> 'notes', ''))
  returning id into v_id;
  perform public.audit_admin('operating_cost_add', 'operating_costs', v_id::text, p - 'notes');
  return v_id;
end $$;

create or replace function public.admin_operating_cost_delete(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  delete from public.operating_costs where id = p_id;
  perform public.audit_admin('operating_cost_delete', 'operating_costs', p_id::text, '{}'::jsonb);
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 10. PERFORMANCE DEL RISTORANTE ("AsiaFood Performance") — SOLO i dati del proprio locale
--     Base anche del Copilot: il Copilot risponde esclusivamente da questo payload (niente concorrenti).
-- ────────────────────────────────────────────────────────────────────
create or replace function public.restaurant_performance(p_restaurant uuid)
returns jsonb language plpgsql volatile security definer set search_path = public as $$
declare
  r public.restaurants; v_today date := (now() at time zone 'Europe/Rome')::date; v_comp jsonb; v_items jsonb; v_period jsonb := '{}'::jsonb; k int;
begin
  if auth.uid() is null or not (public.is_admin() or public.can_manage_restaurant(p_restaurant)) then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  select * into r from public.restaurants where id = p_restaurant;
  if not found then raise exception 'Ristorante non trovato' using errcode = 'P0002'; end if;
  perform public.growth_refresh_today(15);
  v_comp := public.restaurant_completion(p_restaurant);
  foreach k in array array[7, 30] loop
    v_period := v_period || jsonb_build_object(k::text, (
      select jsonb_build_object(
        'current', (select jsonb_build_object('impressions', coalesce(sum(impressions), 0), 'views', coalesce(sum(views), 0), 'menu_views', coalesce(sum(menu_views + item_views), 0),
                      'calls', coalesce(sum(calls), 0), 'whatsapp', coalesce(sum(whatsapp), 0), 'directions', coalesce(sum(directions), 0), 'bookings', coalesce(sum(bookings), 0),
                      'orders', coalesce(sum(orders), 0), 'coupon_redemptions', coalesce(sum(coupon_redemptions), 0), 'revenue_cents', coalesce(sum(revenue_cents), 0),
                      'reviews', coalesce(sum(reviews), 0), 'favorites', coalesce(sum(favorites), 0))
                    from public.daily_restaurant_metrics where restaurant_id = p_restaurant and date between v_today - k + 1 and v_today),
        'previous', (select jsonb_build_object('impressions', coalesce(sum(impressions), 0), 'views', coalesce(sum(views), 0), 'menu_views', coalesce(sum(menu_views + item_views), 0),
                      'calls', coalesce(sum(calls), 0), 'whatsapp', coalesce(sum(whatsapp), 0), 'directions', coalesce(sum(directions), 0), 'bookings', coalesce(sum(bookings), 0),
                      'orders', coalesce(sum(orders), 0), 'coupon_redemptions', coalesce(sum(coupon_redemptions), 0), 'revenue_cents', coalesce(sum(revenue_cents), 0),
                      'reviews', coalesce(sum(reviews), 0), 'favorites', coalesce(sum(favorites), 0))
                     from public.daily_restaurant_metrics where restaurant_id = p_restaurant and date between v_today - 2 * k + 1 and v_today - k),
        'previous_complete', (select count(*) from public.growth_computed_days where day between v_today - 2 * k + 1 and v_today - k) = k)));
  end loop;
  select coalesce(jsonb_agg(to_jsonb(t) order by t.views desc, t.name), '[]'::jsonb) into v_items from (
    select mi.id, mi.name, mi.image_url is not null has_image,
           (select count(*) from public.analytics_events e where e.restaurant_id = p_restaurant and e.event_type = 'menu_item_view' and e.metadata ->> 'item' = mi.id::text
               and e.created_at > now() - interval '30 days') views,
           (select count(*) from public.analytics_events e where e.restaurant_id = p_restaurant and e.event_type = 'add_to_cart' and e.metadata ->> 'item' = mi.id::text
               and e.created_at > now() - interval '30 days') add_to_cart,
           (select coalesce(sum(oi.quantity), 0) from public.order_items oi join public.orders o on o.id = oi.order_id where oi.menu_item_id = mi.id
               and o.paid_at > now() - interval '30 days' and o.payment_status in ('paid', 'partially_refunded')) ordered
      from public.menu_items mi where mi.restaurant_id = p_restaurant order by 4 desc, mi.sort_order limit 15) t;
  return jsonb_build_object(
    'restaurant', jsonb_build_object('id', r.id, 'name', r.name, 'slug', r.slug, 'plan', r.subscription_plan, 'has_cover', r.cover_url is not null or exists (select 1 from public.restaurant_images where restaurant_id = r.id),
                                     'has_reservation', exists (select 1 from public.reservation_settings where restaurant_id = r.id and reservation_enabled),
                                     'accepts_orders', exists (select 1 from public.restaurant_order_settings where restaurant_id = r.id)),
    'completion', v_comp,
    'periods', v_period,
    'menu', jsonb_build_object('items', (select count(*) from public.menu_items where restaurant_id = p_restaurant),
                               'with_image', (select count(*) from public.menu_items where restaurant_id = p_restaurant and image_url is not null),
                               'top', v_items),
    'offers_active', (select count(*) from public.offers where restaurant_id = p_restaurant and is_active and (ends_at is null or ends_at > now()))
                   + (select count(*) from public.coupons where restaurant_id = p_restaurant and is_active and (valid_until is null or valid_until > now())),
    'best_offer', (select jsonb_build_object('title', c.title, 'redemptions', count(cc.id) filter (where cc.status::text = 'redeemed'), 'claims', count(cc.id))
                     from public.coupons c join public.coupon_claims cc on cc.coupon_id = c.id where c.restaurant_id = p_restaurant and cc.claimed_at > now() - interval '90 days'
                    group by c.id, c.title order by count(cc.id) filter (where cc.status::text = 'redeemed') desc, count(cc.id) desc limit 1),
    'repeat_customers_90d', (select count(*) from (select user_id from (
        select user_id from public.reservations where restaurant_id = p_restaurant and user_id is not null and status::text not in ('rejected', 'cancelled') and created_at > now() - interval '90 days'
        union all select user_id from public.orders where restaurant_id = p_restaurant and user_id is not null and payment_status in ('paid', 'partially_refunded') and paid_at > now() - interval '90 days') x
        group by 1 having count(*) >= 2) y),
    'reviews', (select jsonb_build_object('count', count(*), 'avg', round(avg(rating_overall), 1)) from public.reviews where restaurant_id = p_restaurant and status = 'published'),
    'freshness', (select computed_at from public.growth_computed_days where day = v_today),
    'definitions', jsonb_build_object('impressions', 'Volte in cui il locale è comparso nei risultati di una ricerca registrata.',
                                      'revenue', 'Totale degli ordini online pagati (incasso del locale).'));
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 11. IMPOSTAZIONI GROWTH (chiavi ammesse, validate)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_settings()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  return coalesce((select jsonb_object_agg(key, value) from public.platform_settings where key like 'growth\_%' or key = 'automation_kill_switch' or key = 'cac_min_conversions'), '{}'::jsonb);
end $$;

create or replace function public.admin_growth_setting_set(p_key text, p_value jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare k text;
begin
  perform public.growth_assert_admin();
  if p_key in ('growth_return_window_days', 'growth_min_sample', 'growth_experiment_min_sample', 'growth_supply_gap_min_searches', 'growth_alert_zero_result_min',
               'growth_alert_no_login_days', 'growth_anomaly_min_baseline', 'growth_anomaly_drop_pct', 'growth_checkout_drop_pct', 'growth_search_log_days', 'cac_min_conversions') then
    if jsonb_typeof(p_value) <> 'number' or (p_value #>> '{}')::numeric < 1 or (p_value #>> '{}')::numeric > 1000 then raise exception 'Valore non valido' using errcode = '22023'; end if;
  elsif p_key = 'growth_directions_as_conversion' then
    if jsonb_typeof(p_value) <> 'boolean' then raise exception 'Valore non valido' using errcode = '22023'; end if;
  elsif p_key = 'growth_payment_fee_pct' then
    if not (p_value = 'null'::jsonb or (jsonb_typeof(p_value) = 'number' and (p_value #>> '{}')::numeric between 0 and 0.2)) then raise exception 'Valore non valido (0–0,2)' using errcode = '22023'; end if;
  elsif p_key = 'growth_market_weights' then
    if jsonb_typeof(p_value) <> 'object' then raise exception 'Valore non valido' using errcode = '22023'; end if;
    for k in select jsonb_object_keys(p_value) loop
      if k not in ('search_demand', 'supply_gap', 'lead_availability', 'organic_interest', 'commercial_interest')
         or jsonb_typeof(p_value -> k) <> 'number' or (p_value ->> k)::numeric < 0 or (p_value ->> k)::numeric > 100 then
        raise exception 'Peso non valido: %', k using errcode = '22023';
      end if;
    end loop;
  elsif p_key = 'growth_forecast' then
    if not (p_value = 'null'::jsonb or jsonb_typeof(p_value) = 'object') or pg_column_size(p_value) > 4000 then raise exception 'Valore non valido' using errcode = '22023'; end if;
  elsif p_key = 'growth_expansion_candidates' then
    if jsonb_typeof(p_value) <> 'array' or jsonb_array_length(p_value) > 20 then raise exception 'Valore non valido' using errcode = '22023'; end if;
  else
    raise exception 'Impostazione non modificabile da qui' using errcode = '42501';
  end if;
  insert into public.platform_settings (key, value, description) values (p_key, p_value, 'Fase 13 · Growth')
  on conflict (key) do update set value = excluded.value;
  perform public.audit_admin('growth_setting_set', 'platform_settings', p_key, jsonb_build_object('value', p_value));
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 12. JOB PIANIFICATI (backend, system-cron): idempotenti
--     orario: oggi quasi-realtime + alert + automazioni dovute · giornaliero: ieri definitivo, pulizia, report settimanale
-- ────────────────────────────────────────────────────────────────────
create or replace function public.growth_hourly()
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_alerts jsonb; v_auto jsonb;
begin
  perform public.assert_service();
  perform public.growth_compute_day((now() at time zone 'Europe/Rome')::date);
  v_alerts := public.growth_alerts_refresh();
  v_auto := public.automation_run_due();
  return jsonb_build_object('alerts', v_alerts, 'automations', v_auto);
end $$;

create or replace function public.growth_daily()
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_today date := (now() at time zone 'Europe/Rome')::date; v_purged int; v_report uuid; v_week date;
begin
  perform public.assert_service();
  perform public.growth_compute_day(v_today - 1);
  perform public.growth_compute_day(v_today);
  -- Giorni mancanti degli ultimi 7 (es. job saltato)
  perform public.growth_compute_day(d::date) from generate_series(v_today - 7, v_today - 2, interval '1 day') d
   where not exists (select 1 from public.growth_computed_days g where g.day = d::date);
  delete from public.search_events where created_at < now() - make_interval(days => public.billing_setting_int('growth_search_log_days', 90));
  get diagnostics v_purged = row_count;
  -- Report settimanale della settimana precedente (lunedì–domenica), idempotente
  v_week := date_trunc('week', v_today::timestamp)::date - 7;
  v_report := public.growth_generate_report('weekly', v_week, v_week + 6, null);
  return jsonb_build_object('purged_searches', v_purged, 'weekly_report', v_report);
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 13. RLS: tutte le tabelle Growth → solo Admin (lettura); scrittura solo tramite RPC
-- ────────────────────────────────────────────────────────────────────
alter table public.growth_alerts          enable row level security;
alter table public.automation_rules       enable row level security;
alter table public.automation_runs        enable row level security;
alter table public.automation_items       enable row level security;
alter table public.experiment_variants    enable row level security;
alter table public.experiment_assignments enable row level security;
alter table public.growth_reports         enable row level security;
alter table public.growth_tasks           enable row level security;
alter table public.growth_learnings       enable row level security;
alter table public.expansion_candidates   enable row level security;
alter table public.market_playbook_items  enable row level security;
alter table public.operating_costs        enable row level security;

create policy "growth_alerts_admin" on public.growth_alerts for select to authenticated using (public.is_admin());
create policy "automation_rules_admin" on public.automation_rules for select to authenticated using (public.is_admin());
create policy "automation_runs_admin" on public.automation_runs for select to authenticated using (public.is_admin());
create policy "automation_items_admin" on public.automation_items for select to authenticated using (public.is_admin());
create policy "experiment_variants_admin" on public.experiment_variants for select to authenticated using (public.is_admin());
create policy "experiment_assignments_admin" on public.experiment_assignments for select to authenticated using (public.is_admin());
create policy "growth_reports_admin" on public.growth_reports for select to authenticated using (public.is_admin());
create policy "growth_tasks_admin" on public.growth_tasks for select to authenticated using (public.is_admin());
create policy "growth_learnings_admin" on public.growth_learnings for select to authenticated using (public.is_admin());
create policy "expansion_candidates_admin" on public.expansion_candidates for select to authenticated using (public.is_admin());
create policy "market_playbook_admin" on public.market_playbook_items for select to authenticated using (public.is_admin());
create policy "operating_costs_admin" on public.operating_costs for select to authenticated using (public.is_admin());

-- ────────────────────────────────────────────────────────────────────
-- 14. GRANT MINIMI: admin_* → authenticated (controllo interno); growth_*/automation_* interne → solo service_role
-- ────────────────────────────────────────────────────────────────────
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig, p.proname, p.prosrc from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prokind = 'f' and p.prorettype <> 'trigger'::regtype
       and (p.proname like 'admin\_growth%' or p.proname like 'admin\_automation%' or p.proname like 'admin\_experiment%' or p.proname like 'admin\_expansion%'
            or p.proname like 'admin\_market\_playbook%' or p.proname like 'admin\_playbook%' or p.proname like 'admin\_operating\_cost%' or p.proname = 'admin_feedback_set_category'
            or p.proname like 'growth\_%' or p.proname like 'automation\_%')
  loop
    execute format('revoke execute on function %s from public, anon', f.sig);
    if f.proname like 'admin\_%' then
      execute format('grant execute on function %s to authenticated, service_role', f.sig);
    else
      execute format('revoke execute on function %s from authenticated', f.sig);
      execute format('grant execute on function %s to service_role', f.sig);
    end if;
  end loop;
end $$;
-- Lettura (filtrata dalle RLS: Admin; il ristoratore solo le proprie metriche giornaliere). Nessuna scrittura diretta.
grant select on public.growth_event_taxonomy, public.search_events, public.daily_platform_metrics, public.daily_market_metrics, public.daily_restaurant_metrics,
  public.daily_acquisition_metrics, public.daily_search_metrics, public.growth_computed_days, public.growth_alerts, public.automation_rules, public.automation_runs,
  public.automation_items, public.experiment_variants, public.experiment_assignments, public.growth_reports, public.growth_tasks, public.growth_learnings,
  public.expansion_candidates, public.market_playbook_items, public.operating_costs to authenticated;
revoke insert, update, delete on public.growth_event_taxonomy, public.search_events, public.daily_platform_metrics, public.daily_market_metrics, public.daily_restaurant_metrics,
  public.daily_acquisition_metrics, public.daily_search_metrics, public.growth_computed_days, public.growth_alerts, public.automation_rules, public.automation_runs,
  public.automation_items, public.experiment_variants, public.experiment_assignments, public.growth_reports, public.growth_tasks, public.growth_learnings,
  public.expansion_candidates, public.market_playbook_items, public.operating_costs from anon, authenticated;
-- Backfill: Admin (controllo interno is_admin_or_service)
grant execute on function public.growth_backfill(date, date) to authenticated;
-- Pubbliche/ristoratore
revoke execute on function public.restaurant_performance(uuid) from public, anon;
grant execute on function public.restaurant_performance(uuid) to authenticated;
revoke execute on function public.experiment_assign(text, text, text), public.experiment_goal(text, text) from public;
grant execute on function public.experiment_assign(text, text, text), public.experiment_goal(text, text) to anon, authenticated;
grant execute on function public.running_experiments() to anon, authenticated;
