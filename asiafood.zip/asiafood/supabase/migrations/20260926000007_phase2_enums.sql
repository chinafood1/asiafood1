-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0007 · Fase 2: nuovi enum
--  In un file separato: i valori aggiunti a un enum esistente non
--  possono essere usati nella stessa transazione in cui vengono creati.
-- ════════════════════════════════════════════════════════════════════

-- Stati aggiuntivi del workflow di rivendicazione
alter type public.claim_status add value if not exists 'under_review';
alter type public.claim_status add value if not exists 'more_information_required';

-- Affidabilità del dato pubblicato
create type public.data_status as enum ('verified', 'partially_verified', 'unverified', 'claimed', 'outdated');

-- Metodo con cui il richiedente chiede di essere verificato
create type public.verification_method as enum ('email', 'phone', 'document', 'manual');

-- Team del ristorante (più persone sullo stesso locale)
create type public.member_role as enum ('owner', 'manager', 'staff');
create type public.member_status as enum ('active', 'invited', 'revoked');

-- Provenienza dei dati
create type public.source_type as enum (
  'google_business', 'official_website', 'facebook', 'instagram', 'directory', 'owner', 'admin', 'import', 'other'
);

-- Segnalazioni "informazioni errate"
create type public.report_type as enum (
  'wrong_address', 'wrong_phone', 'wrong_hours', 'closed', 'wrong_menu', 'wrong_price', 'other'
);
create type public.report_status as enum ('open', 'in_progress', 'resolved', 'dismissed');
