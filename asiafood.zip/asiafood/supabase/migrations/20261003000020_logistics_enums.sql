-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0020 · Fase 9: valori enum per la logistica (Rider)
--  (in un file separato: i nuovi valori enum non sono utilizzabili nella
--   stessa transazione in cui vengono aggiunti)
-- ════════════════════════════════════════════════════════════════════

-- Ruolo Rider: assegnato SOLO dall'Admin all'approvazione della candidatura
alter type public.user_role add value if not exists 'rider';

-- Eventi logistici (scritti solo dal server, mai dal client)
alter type public.analytics_event_type add value if not exists 'rider_online';
alter type public.analytics_event_type add value if not exists 'rider_offline';
alter type public.analytics_event_type add value if not exists 'delivery_offer_sent';
alter type public.analytics_event_type add value if not exists 'delivery_offer_accepted';
alter type public.analytics_event_type add value if not exists 'delivery_offer_rejected';
alter type public.analytics_event_type add value if not exists 'delivery_assignment_failed';
alter type public.analytics_event_type add value if not exists 'rider_arrived_restaurant';
alter type public.analytics_event_type add value if not exists 'order_picked_up';
alter type public.analytics_event_type add value if not exists 'rider_arrived_customer';
alter type public.analytics_event_type add value if not exists 'delivery_completed';
alter type public.analytics_event_type add value if not exists 'delivery_failed';
