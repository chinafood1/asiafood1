-- ════════════════════════════════════════════════════════════════════
--  FASE 11 · HARDENING & PRODUCTION READINESS
--  - impostazioni: feature flag / kill switch / manutenzione / beta / retention (lettura pubblica solo allowlist)
--  - rate limit condiviso nel database (trigger + RPC per il backend)
--  - GDPR: consensi versionati, export dati, cancellazione account con periodo di sicurezza e anonimizzazione
--  - audit centralizzato (admin + sicurezza) con trigger sugli eventi sensibili
--  - job in background, lock anti doppia esecuzione, log errori, Web Vitals
--  - supporto (ticket), inviti beta, storico slug (redirect 301), launch checklist e readiness Taranto
--  - vincoli, indici, protezione delle cancellazioni fisiche, grant minimi sulle funzioni
-- ════════════════════════════════════════════════════════════════════

-- ────────────────────────────────────────────────────────────────────
--  1. IMPOSTAZIONI (platform_settings) + lettura pubblica solo per chiavi non sensibili
-- ────────────────────────────────────────────────────────────────────
insert into public.platform_settings (key, value, description) values
  ('maintenance_mode',                 'false',        'Manutenzione: il pubblico vede "Stiamo effettuando un aggiornamento", l''Admin entra comunque'),
  ('maintenance_message',              'null',         'Messaggio facoltativo mostrato nella pagina di manutenzione'),
  ('beta_mode',                        'true',         'Beta: badge "Beta" visibile'),
  ('beta_invite_only',                 'false',        'Beta privata: registrazione solo con invito'),
  ('reviews_enabled',                  'true',         'Feature flag: nuove recensioni'),
  ('campaigns_enabled',                'true',         'Kill switch: invio campagne push/in-app programmate'),
  ('crm_agents_enabled',               'false',        'Feature flag: CRM / Sales Agent (modulo non presente in questa versione)'),
  ('rider_signup_enabled',             'true',         'Feature flag: nuove candidature Rider'),
  ('consent_policy_version',           '"2026-10-01"', 'Versione corrente dell''informativa usata per i consensi'),
  ('account_deletion_grace_days',      '7',            'Giorni prima dell''esecuzione della cancellazione account (annullabile)'),
  ('data_export_max_per_day',          '3',            'Export dati per utente al giorno'),
  ('data_export_link_days',            '7',            'Validità della richiesta di export'),
  ('upload_max_image_mb',              '5',            'Dimensione massima immagini pubbliche (MB)'),
  ('upload_max_document_mb',           '10',           'Dimensione massima documenti privati (MB)'),
  ('retention_ai_chat_days',           '7',            'Retention conversazioni AI (giorni) — allineata a ai_chat_retention_days'),
  ('retention_app_logs_days',          '90',           'Retention log applicativi (errori client/server, eventi app)'),
  ('retention_security_logs_days',     '365',          'Retention log di sicurezza'),
  ('retention_analytics_days',         '395',          'Retention eventi analytics (13 mesi)'),
  ('retention_abandoned_cart_days',    '30',           'Retention carrelli abbandonati'),
  ('retention_push_inactive_days',     '180',          'Endpoint push disattivati da oltre N giorni: eliminati'),
  ('retention_expired_invites_days',   '30',           'Inviti beta scaduti/usati: eliminati dopo N giorni'),
  ('retention_failed_payment_days',    '90',           'Ordini mai pagati (scaduti/falliti): dati personali rimossi dopo N giorni'),
  ('retention_rate_limit_hours',       '48',           'Contatori rate limit'),
  ('retention_support_closed_days',    '730',          'Ticket di supporto chiusi: anonimizzati dopo N giorni'),
  ('retention_web_vitals_days',        '90',           'Misure Web Vitals'),
  ('seo_min_restaurants_category_city','2',            'Pagine categoria×città indicizzabili solo con almeno N locali'),
  ('legal_company_name',               'null',         'Ragione sociale (footer) — da compilare'),
  ('legal_vat_number',                 'null',         'Partita IVA (footer) — da compilare'),
  ('legal_address',                    'null',         'Sede legale (footer) — da compilare'),
  ('legal_email',                      'null',         'Email di contatto legale/privacy — da compilare'),
  ('legal_pec',                        'null',         'PEC (se applicabile)'),
  ('support_email',                    'null',         'Email supporto clienti/ristoranti/Rider'),
  ('alert_error_rate_per_10min',       '25',           'Soglia errori server in 10 minuti per avviso'),
  ('alert_webhook_failures_per_hour',  '3',            'Soglia webhook falliti in 1 ora'),
  ('alert_payment_failures_per_hour',  '10',           'Soglia pagamenti falliti in 1 ora'),
  ('alert_ai_error_percent',           '30',           'Soglia percentuale errori AI (ultima ora, min 10 richieste)'),
  ('alert_dispatch_failures_per_hour', '5',            'Soglia dispatch falliti in 1 ora')
on conflict (key) do nothing;

alter table public.platform_settings add column if not exists is_public boolean not null default false;
update public.platform_settings set is_public = true where key in (
  'billing_trial_days', 'show_demo_data', 'loyalty_enabled', 'loyalty_program_name', 'referral_enabled', 'orders_enabled',
  'service_fee_enabled', 'service_fee_amount', 'platform_commission_percent', 'platform_commission_fixed', 'push_enabled',
  'ai_enabled', 'logistics_enabled', 'review_min_length', 'maintenance_mode', 'maintenance_message', 'beta_mode', 'beta_invite_only',
  'reviews_enabled', 'crm_agents_enabled', 'rider_signup_enabled', 'upload_max_image_mb', 'upload_max_document_mb',
  'consent_policy_version', 'account_deletion_grace_days', 'legal_company_name', 'legal_vat_number', 'legal_address', 'legal_email',
  'legal_pec', 'support_email', 'seo_min_restaurants_category_city');

-- Prima: lettura pubblica di TUTTE le impostazioni (soglie anti-abuso, parametri interni). Ora solo l'allowlist.
drop policy if exists "platform_settings_read" on public.platform_settings;
create policy "platform_settings_read" on public.platform_settings for select using (is_public);

create or replace function public.setting_num(p_key text, p_default numeric)
returns numeric language sql stable security definer set search_path = public as $$
  select coalesce((select case when jsonb_typeof(value) = 'number' then (value #>> '{}')::numeric end
                   from public.platform_settings where key = p_key), p_default);
$$;

-- ────────────────────────────────────────────────────────────────────
--  2. SEGRETI INTERNI (mai esposti via API) e hash dell'indirizzo di rete
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.system_secrets (
  key   text primary key,
  value text not null
);
alter table public.system_secrets enable row level security;
revoke all on public.system_secrets from anon, authenticated;
insert into public.system_secrets (key, value)
select 'ip_salt', encode(gen_random_bytes(32), 'hex')
where not exists (select 1 from public.system_secrets where key = 'ip_salt');

/** Header della richiesta PostgREST (null se chiamata interna). */
create or replace function public.sys_request_header(p_name text)
returns text language plpgsql stable security definer set search_path = public as $$
declare h jsonb;
begin
  begin
    h := nullif(current_setting('request.headers', true), '')::jsonb;
  exception when others then
    h := null;
  end;
  return nullif(trim(h ->> lower(p_name)), '');
end $$;

/** SHA-256 salato dell'IP del chiamante (mai l'IP in chiaro). */
create or replace function public.sys_ip_hash(p_ip text default null)
returns text language plpgsql stable security definer set search_path = public as $$
declare v_ip text := coalesce(p_ip, public.sys_request_header('cf-connecting-ip'),
                               nullif(split_part(coalesce(public.sys_request_header('x-forwarded-for'), ''), ',', 1), ''),
                               public.sys_request_header('x-real-ip'));
begin
  if v_ip is null or v_ip = '' then return null; end if;
  return left(encode(sha256(convert_to(trim(v_ip) || (select value from public.system_secrets where key = 'ip_salt'), 'UTF8')), 'hex'), 32);
end $$;

/** User agent ridotto a "browser/os" (niente stringa completa: dato non necessario). */
create or replace function public.sys_ua_summary(p_ua text default null)
returns text language sql stable security definer set search_path = public as $$
  select case when u is null then null else
    (case when u ~* 'edg/' then 'Edge' when u ~* 'chrome|crios' then 'Chrome' when u ~* 'firefox|fxios' then 'Firefox'
          when u ~* 'safari' then 'Safari' else 'Altro' end) || '/' ||
    (case when u ~* 'iphone|ipad|ios' then 'iOS' when u ~* 'android' then 'Android' when u ~* 'windows' then 'Windows'
          when u ~* 'mac os' then 'macOS' when u ~* 'linux' then 'Linux' else 'Altro' end) end
  from (select coalesce(p_ua, public.sys_request_header('user-agent')) u) s;
$$;

create or replace function public.sys_is_service()
returns boolean language sql stable security definer set search_path = public as $$
  select auth.uid() is null and coalesce(auth.role(), 'service_role') = 'service_role';
$$;

-- ────────────────────────────────────────────────────────────────────
--  3. RATE LIMIT (storage condiviso, finestra fissa)
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.rate_limits (
  bucket       text not null check (char_length(bucket) <= 40),
  key_hash     text not null check (char_length(key_hash) <= 80),
  window_start timestamptz not null,
  hits         int not null default 0,
  limit_value  int,
  primary key (bucket, key_hash, window_start)
);
create index if not exists rate_limits_window_idx on public.rate_limits(window_start);
alter table public.rate_limits enable row level security;
revoke all on public.rate_limits from anon, authenticated;

/** true = consentito. Conta anche i tentativi oltre soglia (nessun reset "gratis"). */
create or replace function public.rate_limit_hit(p_bucket text, p_key text, p_limit int, p_window_seconds int)
returns boolean language plpgsql security definer set search_path = public as $$
declare
  v_start timestamptz := to_timestamp(floor(extract(epoch from now()) / greatest(p_window_seconds, 1)) * greatest(p_window_seconds, 1));
  v_hits int;
begin
  insert into public.rate_limits (bucket, key_hash, window_start, hits, limit_value)
  values (left(p_bucket, 40), left(coalesce(p_key, 'unknown'), 80), v_start, 1, p_limit)
  on conflict (bucket, key_hash, window_start) do update set hits = public.rate_limits.hits + 1
  returning hits into v_hits;
  return v_hits <= p_limit;
end $$;

/** Chiave del chiamante: utente autenticato, altrimenti hash IP, altrimenti bucket anonimo globale. */
create or replace function public.rate_limit_caller_key()
returns text language sql stable security definer set search_path = public as $$
  select coalesce('u:' || auth.uid()::text, 'ip:' || public.sys_ip_hash(), 'anon');
$$;

/** Solleva RATE_LIMITED (per le RPC chiamate dal browser). Il backend (service role) non è limitato qui. */
create or replace function public.rate_limit_assert(p_bucket text, p_limit int, p_window_seconds int)
returns void language plpgsql security definer set search_path = public as $$
declare v_key text := public.rate_limit_caller_key();
begin
  if public.sys_is_service() then return; end if;
  -- Senza identità (niente utente né IP) il limite vale per tutti gli anonimi insieme: soglia più ampia
  -- Il raggiungimento della soglia resta nel contatore (hits >= limit_value): un log scritto qui verrebbe annullato dal rollback
  if not public.rate_limit_hit(p_bucket, v_key, case when v_key = 'anon' then p_limit * 20 else p_limit end, p_window_seconds) then
    raise exception 'RATE_LIMITED: Troppe richieste in poco tempo. Riprova tra qualche minuto.' using errcode = 'P0001';
  end if;
end $$;

/** Per il backend: stesso contatore, chiave già hashata dal server (IP/utente). */
create or replace function public.rate_limit_check(p_bucket text, p_key text, p_limit int, p_window_seconds int)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  return public.rate_limit_hit(p_bucket, p_key, p_limit, p_window_seconds);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  4. AUDIT CENTRALIZZATO
-- ────────────────────────────────────────────────────────────────────
alter table public.admin_audit_logs add column if not exists actor_role text check (char_length(actor_role) <= 30);
alter table public.admin_audit_logs add column if not exists ip_hash text check (char_length(ip_hash) <= 64);
alter table public.admin_audit_logs add column if not exists user_agent_summary text check (char_length(user_agent_summary) <= 40);
create index if not exists admin_audit_logs_admin_idx on public.admin_audit_logs(admin_id);
create index if not exists admin_audit_logs_entity_idx on public.admin_audit_logs(entity_type, entity_id);

create table if not exists public.security_audit_logs (
  id                 bigint generated always as identity primary key,
  actor_user_id      uuid references public.profiles(id) on delete set null,
  actor_role         text check (char_length(actor_role) <= 30),
  action             text not null check (char_length(action) <= 60),
  entity_type        text check (char_length(entity_type) <= 40),
  entity_id          text check (char_length(entity_id) <= 80),
  metadata           jsonb not null default '{}'::jsonb check (pg_column_size(metadata) <= 4000),
  ip_hash            text check (char_length(ip_hash) <= 64),
  user_agent_summary text check (char_length(user_agent_summary) <= 40),
  created_at         timestamptz not null default now()
);
create index if not exists security_audit_logs_created_idx on public.security_audit_logs(created_at desc);
create index if not exists security_audit_logs_actor_idx on public.security_audit_logs(actor_user_id);
create index if not exists security_audit_logs_action_idx on public.security_audit_logs(action, created_at desc);
alter table public.security_audit_logs enable row level security;
create policy "security_audit_admin_read" on public.security_audit_logs for select to authenticated using (public.is_admin());
revoke insert, update, delete on public.security_audit_logs from anon, authenticated;

-- audit_admin ora registra anche ruolo, hash IP e user agent sintetico (stessa firma: nessun chiamante da cambiare)
create or replace function public.audit_admin(p_action text, p_entity text, p_id text, p_details jsonb default '{}'::jsonb)
returns void language sql security definer set search_path = public as $$
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details, actor_role, ip_hash, user_agent_summary)
  values (auth.uid(), left(p_action, 60), left(p_entity, 40), p_id, coalesce(p_details, '{}'::jsonb),
          coalesce(public.current_user_role()::text, case when auth.uid() is null then 'service' end), public.sys_ip_hash(), public.sys_ua_summary());
$$;

create or replace function public.audit_security(p_action text, p_entity text, p_id text, p_meta jsonb default '{}'::jsonb, p_user uuid default null)
returns void language sql security definer set search_path = public as $$
  insert into public.security_audit_logs (actor_user_id, actor_role, action, entity_type, entity_id, metadata, ip_hash, user_agent_summary)
  values (coalesce(p_user, auth.uid()), coalesce(public.current_user_role()::text, case when auth.uid() is null then 'service' end),
          left(p_action, 60), left(p_entity, 40), left(p_id, 80), coalesce(p_meta, '{}'::jsonb), public.sys_ip_hash(), public.sys_ua_summary());
$$;

/**
 * Trigger di audit per gli eventi sensibili (cambio ruolo, trasferimento proprietà, claim, rimborsi,
 * abbonamenti manuali, sospensione Rider, moderazione recensioni, sponsorizzazioni, impostazioni).
 * TG_ARGV[0] = azione, TG_ARGV[1] = colonne da confrontare (separate da virgola; vuoto = sempre).
 */
create or replace function public.audit_row_trigger()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_action text := tg_argv[0];
  v_cols text[] := case when coalesce(tg_argv[1], '') = '' then '{}'::text[] else string_to_array(tg_argv[1], ',') end;
  v_old jsonb := case when tg_op in ('UPDATE', 'DELETE') then to_jsonb(old) else '{}'::jsonb end;
  v_new jsonb := case when tg_op in ('INSERT', 'UPDATE') then to_jsonb(new) else '{}'::jsonb end;
  v_diff jsonb := '{}'::jsonb;
  c text;
  v_id text;
begin
  if tg_op = 'UPDATE' and array_length(v_cols, 1) > 0 then
    foreach c in array v_cols loop
      if (v_old -> c) is distinct from (v_new -> c) then
        v_diff := v_diff || jsonb_build_object(c, jsonb_build_object('from', v_old -> c, 'to', v_new -> c));
      end if;
    end loop;
    if v_diff = '{}'::jsonb then return null; end if;
  end if;
  v_id := coalesce(v_new ->> 'id', v_old ->> 'id', v_new ->> 'key', v_old ->> 'key');
  if public.is_admin() then
    perform public.audit_admin(v_action, tg_table_name, v_id, jsonb_build_object('op', lower(tg_op), 'changes', v_diff));
  else
    perform public.audit_security(v_action, tg_table_name, v_id, jsonb_build_object('op', lower(tg_op), 'changes', v_diff));
  end if;
  return null;
end $$;

drop trigger if exists audit_profiles_role on public.profiles;
create trigger audit_profiles_role after update of role, is_blocked on public.profiles
  for each row execute function public.audit_row_trigger('role_change', 'role,is_blocked');
drop trigger if exists audit_restaurants_owner on public.restaurants;
create trigger audit_restaurants_owner after update of owner_id, slug, is_active, is_sponsored, is_featured, subscription_plan on public.restaurants
  for each row execute function public.audit_row_trigger('restaurant_admin_change', 'owner_id,slug,is_active,is_sponsored,is_featured,subscription_plan');
drop trigger if exists audit_claims_status on public.restaurant_claims;
create trigger audit_claims_status after update of status on public.restaurant_claims
  for each row execute function public.audit_row_trigger('claim_status_change', 'status');
drop trigger if exists audit_order_refunds on public.order_refunds;
create trigger audit_order_refunds after insert on public.order_refunds
  for each row execute function public.audit_row_trigger('refund_requested', '');
drop trigger if exists audit_subscriptions_manual on public.subscriptions;
create trigger audit_subscriptions_manual after insert or update of plan_code, status, expires_at, revoked_at on public.subscriptions
  for each row when (new.source <> 'stripe') execute function public.audit_row_trigger('subscription_manual_change', 'plan_code,status,expires_at,revoked_at');
drop trigger if exists audit_rider_status on public.rider_profiles;
create trigger audit_rider_status after update of status on public.rider_profiles
  for each row execute function public.audit_row_trigger('rider_status_change', 'status');
drop trigger if exists audit_reviews_moderation on public.reviews;
create trigger audit_reviews_moderation after update of status on public.reviews
  for each row when (new.moderated_by is not null) execute function public.audit_row_trigger('review_moderation', 'status');
drop trigger if exists audit_sponsored on public.sponsored_campaigns;
create trigger audit_sponsored after insert or update or delete on public.sponsored_campaigns
  for each row execute function public.audit_row_trigger('sponsorship_change', '');
drop trigger if exists audit_members on public.restaurant_members;
create trigger audit_members after insert or update of role, status or delete on public.restaurant_members
  for each row execute function public.audit_row_trigger('member_change', 'role,status');
drop trigger if exists audit_settings on public.platform_settings;
create trigger audit_settings after update of value on public.platform_settings
  for each row execute function public.audit_row_trigger('setting_change', 'value');

-- Log di audit, eventi Stripe, timeline ordini/consegne: MAI cancellabili via API (solo retention di sistema)
create or replace function public.prevent_audit_delete()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if coalesce(current_setting('asiafood.retention', true), '') = 'on' then return old; end if;
  raise exception 'I log di audit non possono essere cancellati' using errcode = '42501';
end $$;
do $$
declare t text;
begin
  foreach t in array array['admin_audit_logs', 'security_audit_logs', 'stripe_events', 'order_events', 'delivery_events', 'billing_activity'] loop
    execute format('drop trigger if exists %I on public.%I', t || '_no_delete', t);
    execute format('create trigger %I before delete on public.%I for each row execute function public.prevent_audit_delete()', t || '_no_delete', t);
  end loop;
end $$;

-- Ristoranti con storico (ordini, abbonamenti, prenotazioni, recensioni, fatture): niente DELETE fisico, si disattivano
create or replace function public.restaurants_prevent_hard_delete()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.sys_is_service() and coalesce(current_setting('asiafood.allow_hard_delete', true), '') = 'on' then return old; end if;
  if exists (select 1 from public.orders where restaurant_id = old.id)
     or exists (select 1 from public.subscriptions where restaurant_id = old.id and source = 'stripe')
     or exists (select 1 from public.billing_invoices where restaurant_id = old.id)
     or exists (select 1 from public.reservations where restaurant_id = old.id)
     or exists (select 1 from public.reviews where restaurant_id = old.id) then
    raise exception 'Il locale ha ordini, prenotazioni, recensioni o fatture: disattivalo invece di eliminarlo.' using errcode = '42501';
  end if;
  return old;
end $$;
drop trigger if exists restaurants_no_hard_delete on public.restaurants;
create trigger restaurants_no_hard_delete before delete on public.restaurants
  for each row execute function public.restaurants_prevent_hard_delete();

-- Profili: la cancellazione passa dal workflow GDPR (account_deletion_requests), non da un DELETE dell'Admin
create or replace function public.profiles_prevent_admin_delete()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null then
    raise exception 'Usa la procedura di cancellazione account (anonimizzazione + periodo di sicurezza).' using errcode = '42501';
  end if;
  return old;
end $$;
drop trigger if exists profiles_no_admin_delete on public.profiles;
create trigger profiles_no_admin_delete before delete on public.profiles
  for each row execute function public.profiles_prevent_admin_delete();

/** Sessione Admin (chiamata dall'area /admin una volta per sessione): audit "admin login sensibile". */
create or replace function public.record_admin_session()
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then return; end if;
  if exists (select 1 from public.security_audit_logs where actor_user_id = auth.uid() and action = 'admin_session'
               and created_at > now() - interval '1 hour') then return; end if;
  perform public.audit_security('admin_session', 'profile', auth.uid()::text, '{}'::jsonb);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  5. CONSENSI E VERSIONI DEI DOCUMENTI LEGALI
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.legal_document_versions (
  id            uuid primary key default gen_random_uuid(),
  document_type text not null check (document_type in ('privacy', 'cookie', 'terms', 'business_terms', 'rider_privacy', 'rider_terms')),
  version       text not null check (char_length(version) between 1 and 40),
  effective_at  timestamptz not null default now(),
  url           text not null check (url ~ '^/[a-z0-9/_-]*$' or url ~ '^https://'),
  is_current    boolean not null default false,
  is_draft      boolean not null default true,
  created_at    timestamptz not null default now(),
  unique (document_type, version)
);
create unique index if not exists legal_document_versions_current_idx on public.legal_document_versions(document_type) where is_current;
alter table public.legal_document_versions enable row level security;
create policy "legal_versions_read" on public.legal_document_versions for select using (true);
create policy "legal_versions_admin" on public.legal_document_versions for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.legal_document_versions (document_type, version, url, is_current, is_draft) values
  ('privacy', '2026-10-01-bozza', '/privacy', true, true),
  ('cookie', '2026-10-01-bozza', '/cookie-policy', true, true),
  ('terms', '2026-10-01-bozza', '/terms', true, true),
  ('business_terms', '2026-10-01-bozza', '/business-terms', true, true),
  ('rider_privacy', '2026-10-01-bozza', '/rider-privacy', true, true),
  ('rider_terms', '2026-10-01-bozza', '/rider-terms', true, true)
on conflict (document_type, version) do nothing;

create table if not exists public.user_consents (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid references public.profiles(id) on delete set null,
  anonymous_id   text check (anonymous_id ~ '^[A-Za-z0-9_-]{8,64}$'),
  consent_type   text not null check (consent_type in ('necessary', 'analytics', 'marketing', 'personalization')),
  granted        boolean not null,
  policy_version text not null check (char_length(policy_version) <= 40),
  source         text not null default 'banner' check (source in ('banner', 'settings', 'signup', 'import')),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  check (user_id is not null or anonymous_id is not null)
);
create index if not exists user_consents_user_idx on public.user_consents(user_id, consent_type, created_at desc);
create index if not exists user_consents_anon_idx on public.user_consents(anonymous_id, consent_type, created_at desc);
alter table public.user_consents enable row level security;
create policy "consents_own_read" on public.user_consents for select to authenticated using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.user_consents from anon, authenticated;

/**
 * Registra le scelte del banner/impostazioni (storico append-only: ogni modifica è una riga, prova del consenso).
 * "necessary" è sempre true (cookie tecnici). Nessun dato personale oltre a utente o ID anonimo casuale.
 */
create or replace function public.consent_record(p_choices jsonb, p_anonymous_id text default null, p_policy_version text default null, p_source text default 'banner')
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_ver text := coalesce(nullif(left(p_policy_version, 40), ''), public.billing_setting_text('consent_policy_version', 'n/d'));
  v_type text;
  v_val boolean;
  v_src text := case when p_source in ('banner', 'settings', 'signup') then p_source else 'banner' end;
begin
  if v_uid is null and (p_anonymous_id is null or p_anonymous_id !~ '^[A-Za-z0-9_-]{8,64}$') then
    raise exception 'Identificativo di consenso non valido' using errcode = '22023';
  end if;
  if jsonb_typeof(p_choices) <> 'object' then raise exception 'Scelte non valide' using errcode = '22023'; end if;
  perform public.rate_limit_assert('consent', 30, 3600);
  foreach v_type in array array['necessary', 'analytics', 'marketing', 'personalization'] loop
    v_val := case when v_type = 'necessary' then true else coalesce((p_choices ->> v_type)::boolean, false) end;
    -- Nessuna riga duplicata se la scelta non cambia
    if not exists (
      select 1 from (
        select granted, policy_version from public.user_consents
         where consent_type = v_type and ((v_uid is not null and user_id = v_uid) or (v_uid is null and anonymous_id = p_anonymous_id))
         order by created_at desc limit 1) last
      where last.granted = v_val and last.policy_version = v_ver) then
      insert into public.user_consents (user_id, anonymous_id, consent_type, granted, policy_version, source)
      values (v_uid, case when v_uid is null then p_anonymous_id end, v_type, v_val, v_ver, v_src);
    end if;
  end loop;
  -- Allineamento con le preferenze di notifica: il consenso marketing governa le comunicazioni promozionali
  if v_uid is not null then
    update public.profiles set marketing_opt_in = coalesce((p_choices ->> 'marketing')::boolean, false) where id = v_uid;
    update public.notification_preferences set marketing = coalesce((p_choices ->> 'marketing')::boolean, false) where user_id = v_uid;
  end if;
  return public.my_consents_for(v_uid, p_anonymous_id);
end $$;

create or replace function public.my_consents_for(p_user uuid, p_anon text)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'policy_version', public.billing_setting_text('consent_policy_version', 'n/d'),
    'choices', coalesce((select jsonb_object_agg(consent_type, jsonb_build_object('granted', granted, 'policy_version', policy_version, 'at', created_at))
      from (select distinct on (consent_type) consent_type, granted, policy_version, created_at from public.user_consents
             where (p_user is not null and user_id = p_user) or (p_user is null and p_anon is not null and anonymous_id = p_anon)
             order by consent_type, created_at desc) x), '{}'::jsonb));
$$;

create or replace function public.my_consents()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Accedi per continuare' using errcode = '42501'; end if;
  return public.my_consents_for(auth.uid(), null) || jsonb_build_object('history',
    coalesce((select jsonb_agg(jsonb_build_object('type', consent_type, 'granted', granted, 'policy_version', policy_version, 'source', source, 'at', created_at) order by created_at desc)
      from (select * from public.user_consents where user_id = auth.uid() order by created_at desc limit 50) h), '[]'::jsonb));
end $$;

create or replace function public.admin_legal_version_create(p_type text, p_version text, p_url text, p_effective_at timestamptz default now(), p_is_draft boolean default true)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  update public.legal_document_versions set is_current = false where document_type = p_type and is_current;
  insert into public.legal_document_versions (document_type, version, url, effective_at, is_current, is_draft)
  values (p_type, p_version, p_url, coalesce(p_effective_at, now()), true, coalesce(p_is_draft, true)) returning id into v_id;
  if p_type in ('privacy', 'cookie') then
    update public.platform_settings set value = to_jsonb(p_version) where key = 'consent_policy_version';
  end if;
  perform public.audit_admin('legal_version_created', 'legal_document', v_id::text, jsonb_build_object('type', p_type, 'version', p_version));
  return v_id;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  6. CONFIGURAZIONE PUBBLICA A RUNTIME (una sola chiamata all'avvio dell'app)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.public_runtime_config()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'settings', coalesce((select jsonb_object_agg(key, value) from public.platform_settings where is_public), '{}'::jsonb),
    'legal', coalesce((select jsonb_object_agg(document_type, jsonb_build_object('version', version, 'url', url, 'effective_at', effective_at, 'draft', is_draft))
                         from public.legal_document_versions where is_current), '{}'::jsonb),
    'server_time', now());
$$;

-- Tabella ticket (usata anche da export e anonimizzazione; RPC nella sezione 11)
create table if not exists public.support_tickets (
  id            uuid primary key default gen_random_uuid(),
  reference     text not null unique default ('T-' || public.random_code(6)),
  user_id       uuid references public.profiles(id) on delete set null,
  restaurant_id uuid references public.restaurants(id) on delete set null,
  order_id      uuid references public.orders(id) on delete set null,
  category      text not null check (category in ('order', 'reservation', 'account', 'privacy', 'restaurant', 'business', 'billing', 'rider', 'bug', 'other')),
  priority      text not null default 'normal' check (priority in ('low', 'normal', 'high', 'urgent')),
  subject       text not null check (char_length(subject) between 3 and 140),
  description   text not null check (char_length(description) between 10 and 4000),
  contact_email text check (contact_email is null or (char_length(contact_email) <= 254 and contact_email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$')),
  contact_name  text check (char_length(contact_name) <= 80),
  status        text not null default 'open' check (status in ('open', 'in_progress', 'waiting_customer', 'resolved', 'closed')),
  assigned_to   uuid references public.profiles(id) on delete set null,
  admin_notes   text check (char_length(admin_notes) <= 4000),
  resolution    text check (char_length(resolution) <= 2000),
  source        text not null default 'web' check (source in ('web', 'app', 'admin')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  resolved_at   timestamptz
);
create index if not exists support_tickets_status_idx on public.support_tickets(status, priority, created_at desc);
create index if not exists support_tickets_user_idx on public.support_tickets(user_id);
create index if not exists support_tickets_order_idx on public.support_tickets(order_id);
create index if not exists support_tickets_restaurant_idx on public.support_tickets(restaurant_id);
create index if not exists support_tickets_assigned_idx on public.support_tickets(assigned_to);
alter table public.support_tickets enable row level security;
create policy "tickets_own_read" on public.support_tickets for select to authenticated using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.support_tickets from anon, authenticated;
drop trigger if exists support_tickets_updated_at on public.support_tickets;
create trigger support_tickets_updated_at before update on public.support_tickets for each row execute function public.set_updated_at();

-- ────────────────────────────────────────────────────────────────────
--  7. EXPORT DATI (diritto di accesso / portabilità)
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.data_export_requests (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid references public.profiles(id) on delete cascade,
  status       text not null default 'requested' check (status in ('requested', 'processing', 'completed', 'failed', 'expired')),
  requested_at timestamptz not null default now(),
  completed_at timestamptz,
  expires_at   timestamptz,
  file_path    text check (file_path is null or file_path ~ '^[a-f0-9-]{36}/[A-Za-z0-9._-]{1,80}$'),
  size_bytes   int,
  error        text check (char_length(error) <= 300)
);
create index if not exists data_export_requests_user_idx on public.data_export_requests(user_id, requested_at desc);
alter table public.data_export_requests enable row level security;
create policy "exports_own_read" on public.data_export_requests for select to authenticated using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.data_export_requests from anon, authenticated;

/**
 * Raccolta dei dati dell'utente (profilo, preferiti, recensioni, prenotazioni, ordini, loyalty, referral,
 * preferenze di notifica, consensi, indirizzi, preferenze AI, Rider). Nessun segreto (token, hash, codici
 * di pagamento, chiavi push). Il file viene generato dal browser dell'utente e non resta sul server.
 */
create or replace function public.privacy_export_data(p_user uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'generated_at', now(),
    'format_version', 1,
    'profile', (select jsonb_build_object('id', id, 'full_name', full_name, 'display_name', display_name, 'email', email, 'phone', phone,
                  'role', role, 'marketing_opt_in', marketing_opt_in, 'created_at', created_at) from public.profiles where id = p_user),
    'favorites', coalesce((select jsonb_agg(jsonb_build_object('restaurant', r.name, 'slug', r.slug, 'since', f.created_at, 'notifications', f.notifications_enabled) order by f.created_at)
                    from public.favorites f join public.restaurants r on r.id = f.restaurant_id where f.user_id = p_user), '[]'::jsonb),
    'reviews', coalesce((select jsonb_agg(jsonb_build_object('restaurant', r.name, 'rating', v.rating_overall, 'title', v.title, 'content', v.content,
                    'status', v.status, 'verified', v.is_verified, 'created_at', v.created_at) order by v.created_at)
                    from public.reviews v join public.restaurants r on r.id = v.restaurant_id where v.user_id = p_user), '[]'::jsonb),
    'reservations', coalesce((select jsonb_agg(jsonb_build_object('restaurant', r.name, 'date', x.reservation_date, 'time', x.reservation_time,
                    'party_size', x.party_size, 'status', x.status, 'name', x.guest_name || ' ' || x.guest_surname, 'phone', x.guest_phone,
                    'email', x.guest_email, 'notes', x.notes, 'created_at', x.created_at) order by x.created_at)
                    from public.reservations x join public.restaurants r on r.id = x.restaurant_id where x.user_id = p_user), '[]'::jsonb),
    'orders', coalesce((select jsonb_agg(jsonb_build_object('order_number', o.order_number, 'restaurant', r.name, 'type', o.order_type, 'status', o.status,
                    'payment_status', o.payment_status, 'total', o.total, 'currency', o.currency, 'created_at', o.created_at,
                    'customer', jsonb_build_object('name', o.customer_name, 'email', o.customer_email, 'phone', o.customer_phone),
                    'delivery_address', o.delivery_address_snapshot, 'notes', o.customer_notes,
                    'items', (select coalesce(jsonb_agg(jsonb_build_object('name', i.menu_item_name_snapshot, 'variant', i.variant_name_snapshot, 'quantity', i.quantity, 'line_total', i.line_total)), '[]'::jsonb)
                                from public.order_items i where i.order_id = o.id)) order by o.created_at)
                    from public.orders o join public.restaurants r on r.id = o.restaurant_id where o.user_id = p_user), '[]'::jsonb),
    'addresses', coalesce((select jsonb_agg(jsonb_build_object('label', label, 'recipient', recipient_name, 'phone', phone, 'address', address_line_1,
                    'address_2', address_line_2, 'city', city, 'postal_code', postal_code, 'notes', delivery_notes)) from public.customer_addresses where user_id = p_user), '[]'::jsonb),
    'loyalty', jsonb_build_object(
       'account', (select jsonb_build_object('points_balance', points_balance, 'lifetime_points', lifetime_points, 'level', level) from public.loyalty_accounts where user_id = p_user),
       'transactions', coalesce((select jsonb_agg(jsonb_build_object('type', type, 'points', points, 'description', description, 'status', status, 'at', created_at) order by created_at)
                         from public.loyalty_transactions where user_id = p_user), '[]'::jsonb),
       'rewards', coalesce((select jsonb_agg(jsonb_build_object('points_spent', points_spent, 'status', status, 'at', created_at)) from public.reward_redemptions where user_id = p_user), '[]'::jsonb)),
    'referrals', jsonb_build_object(
       'code', (select code from public.referral_codes where user_id = p_user),
       'invited', coalesce((select jsonb_agg(jsonb_build_object('status', status, 'registered_at', registered_at, 'qualified_at', qualified_at)) from public.referrals where referrer_user_id = p_user), '[]'::jsonb),
       'invited_by', (select jsonb_build_object('status', status, 'at', created_at) from public.referrals where referred_user_id = p_user limit 1)),
    'coupons', coalesce((select jsonb_agg(jsonb_build_object('restaurant', r.name, 'status', c.status, 'claimed_at', c.claimed_at, 'redeemed_at', c.redeemed_at))
                    from public.coupon_claims c join public.restaurants r on r.id = c.restaurant_id where c.user_id = p_user), '[]'::jsonb),
    'notification_preferences', (select to_jsonb(n) - 'user_id' from public.notification_preferences n where user_id = p_user),
    'push_devices', (select count(*) from public.push_subscriptions where user_id = p_user and is_active),
    'consents', coalesce((select jsonb_agg(jsonb_build_object('type', consent_type, 'granted', granted, 'policy_version', policy_version, 'source', source, 'at', created_at) order by created_at)
                    from public.user_consents where user_id = p_user), '[]'::jsonb),
    'ai_preferences', (select to_jsonb(a) - 'user_id' from public.ai_user_preferences a where user_id = p_user),
    'rider', (select jsonb_build_object('status', status, 'first_name', first_name, 'last_name', last_name, 'phone', phone, 'email', email, 'city', city,
                'vehicle_type', vehicle_type, 'created_at', created_at, 'total_deliveries', total_deliveries,
                'documents', (select coalesce(jsonb_agg(jsonb_build_object('type', document_type, 'status', status, 'uploaded_at', uploaded_at)), '[]'::jsonb)
                                from public.rider_documents d where d.rider_id = rp.id),
                'earnings', (select coalesce(jsonb_agg(jsonb_build_object('total', total, 'status', status, 'at', created_at)), '[]'::jsonb)
                                from public.rider_earnings e where e.rider_id = rp.id))
              from public.rider_profiles rp where user_id = p_user),
    'support_tickets', coalesce((select jsonb_agg(jsonb_build_object('reference', reference, 'category', category, 'subject', subject, 'status', status, 'created_at', created_at))
                    from public.support_tickets where user_id = p_user), '[]'::jsonb),
    'restaurant_roles', coalesce((select jsonb_agg(jsonb_build_object('restaurant', r.name, 'role', m.role, 'status', m.status))
                    from public.restaurant_members m join public.restaurants r on r.id = m.restaurant_id where m.user_id = p_user), '[]'::jsonb)
  );
$$;

create or replace function public.privacy_export()
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_id uuid; v_data jsonb;
begin
  if v_uid is null then raise exception 'Accedi per scaricare i tuoi dati' using errcode = '42501'; end if;
  if (select count(*) from public.data_export_requests where user_id = v_uid and requested_at > now() - interval '1 day')
     >= public.billing_setting_int('data_export_max_per_day', 3) then
    raise exception 'RATE_LIMITED: Hai già scaricato i tuoi dati più volte oggi. Riprova domani.' using errcode = 'P0001';
  end if;
  insert into public.data_export_requests (user_id, status) values (v_uid, 'processing') returning id into v_id;
  v_data := public.privacy_export_data(v_uid);
  update public.data_export_requests set status = 'completed', completed_at = now(),
         expires_at = now() + make_interval(days => public.billing_setting_int('data_export_link_days', 7)),
         size_bytes = octet_length(v_data::text) where id = v_id;
  perform public.audit_security('data_export', 'profile', v_uid::text, jsonb_build_object('request_id', v_id));
  return jsonb_build_object('request_id', v_id, 'data', v_data);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  8. CANCELLAZIONE ACCOUNT (ri-autenticazione, periodo di sicurezza, anonimizzazione, poi eliminazione)
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.account_deletion_requests (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid references public.profiles(id) on delete set null,
  status        text not null default 'scheduled' check (status in ('scheduled', 'cancelled', 'blocked', 'anonymized', 'completed')),
  reason        text check (char_length(reason) <= 500),
  requested_at  timestamptz not null default now(),
  scheduled_for timestamptz not null,
  completed_at  timestamptz,
  cancelled_at  timestamptz,
  blocked_reason text check (char_length(blocked_reason) <= 200),
  attempts      int not null default 0
);
create unique index if not exists account_deletion_one_open_idx on public.account_deletion_requests(user_id) where status in ('scheduled', 'blocked');
create index if not exists account_deletion_due_idx on public.account_deletion_requests(scheduled_for) where status = 'scheduled';
alter table public.account_deletion_requests enable row level security;
create policy "deletion_own_read" on public.account_deletion_requests for select to authenticated using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.account_deletion_requests from anon, authenticated;

/** Autenticazione recente: timestamp "amr" del JWT Supabase (login con password/OTP negli ultimi N minuti). */
create or replace function public.auth_recent(p_minutes int default 10)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare v_claims jsonb; v_ts bigint;
begin
  begin
    v_claims := nullif(current_setting('request.jwt.claims', true), '')::jsonb;
  exception when others then v_claims := null; end;
  if v_claims is null then return false; end if;
  select max((a ->> 'timestamp')::bigint) into v_ts from jsonb_array_elements(coalesce(v_claims -> 'amr', '[]'::jsonb)) a;
  return v_ts is not null and to_timestamp(v_ts) > now() - make_interval(mins => p_minutes);
end $$;

create or replace function public.request_account_deletion(p_reason text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_row public.account_deletion_requests;
begin
  if v_uid is null then raise exception 'Accedi per continuare' using errcode = '42501'; end if;
  if not public.auth_recent(10) then
    raise exception 'REAUTH_REQUIRED: Per sicurezza inserisci di nuovo la password prima di eliminare l''account.' using errcode = '42501';
  end if;
  perform public.rate_limit_assert('account_deletion', 5, 86400);
  select * into v_row from public.account_deletion_requests where user_id = v_uid and status in ('scheduled', 'blocked');
  if found then return to_jsonb(v_row); end if;
  insert into public.account_deletion_requests (user_id, reason, scheduled_for)
  values (v_uid, left(p_reason, 500), now() + make_interval(days => greatest(public.billing_setting_int('account_deletion_grace_days', 7), 0)))
  returning * into v_row;
  perform public.audit_security('account_deletion_requested', 'profile', v_uid::text, jsonb_build_object('scheduled_for', v_row.scheduled_for));
  perform public.notify_user(v_uid, 'account', 'Richiesta di eliminazione ricevuta',
    format('Il tuo account verrà eliminato il %s. Puoi annullare da Impostazioni → Privacy fino a quel momento.', to_char(v_row.scheduled_for at time zone 'Europe/Rome', 'DD/MM/YYYY')),
    '/settings/privacy');
  return to_jsonb(v_row);
end $$;

create or replace function public.cancel_account_deletion()
returns boolean language plpgsql security definer set search_path = public as $$
declare v_n int;
begin
  if auth.uid() is null then raise exception 'Accedi per continuare' using errcode = '42501'; end if;
  update public.account_deletion_requests set status = 'cancelled', cancelled_at = now()
   where user_id = auth.uid() and status = 'scheduled' and scheduled_for > now();
  get diagnostics v_n = row_count;
  if v_n > 0 then perform public.audit_security('account_deletion_cancelled', 'profile', auth.uid()::text, '{}'::jsonb); end if;
  return v_n > 0;
end $$;

create or replace function public.my_privacy_status()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Accedi per continuare' using errcode = '42501'; end if;
  return jsonb_build_object(
    'deletion', (select to_jsonb(d) - 'user_id' from public.account_deletion_requests d where user_id = auth.uid() order by requested_at desc limit 1),
    'exports', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'status', status, 'requested_at', requested_at, 'completed_at', completed_at, 'expires_at', expires_at) order by requested_at desc)
                  from (select * from public.data_export_requests where user_id = auth.uid() order by requested_at desc limit 5) e), '[]'::jsonb),
    'grace_days', public.billing_setting_int('account_deletion_grace_days', 7));
end $$;

/**
 * Anonimizzazione (account_deleted): dati personali rimossi dove la conservazione serve per obblighi contabili
 * o integrità statistica (ordini, prenotazioni storiche), cancellazione del resto. L'utente Auth viene poi
 * eliminato dal backend (hard_deleted) con l'Admin API di Supabase.
 * Ritorna: 'anonymized' | 'blocked:<motivo>' | 'postponed'.
 */
create or replace function public.account_anonymize(p_user uuid)
returns text language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  -- Titolari/manager di un locale attivo: serve prima il trasferimento (intervento Admin)
  if exists (select 1 from public.restaurant_members m join public.restaurants r on r.id = m.restaurant_id
              where m.user_id = p_user and m.status = 'active' and m.role in ('owner', 'manager') and r.is_active)
     or exists (select 1 from public.restaurants where owner_id = p_user and is_active) then
    return 'blocked:owns_restaurant';
  end if;
  -- Rider: documenti con obblighi di conservazione → revisione Admin
  if exists (select 1 from public.rider_profiles where user_id = p_user and status <> 'rejected') then
    return 'blocked:rider_profile';
  end if;
  -- Ordini in corso: si rimanda
  if exists (select 1 from public.orders where user_id = p_user
              and status not in ('completed', 'cancelled', 'rejected', 'refunded', 'partially_refunded', 'pending_payment')) then
    return 'postponed';
  end if;

  set local asiafood.lg_sync = 'on';
  update public.orders set customer_name = 'Cliente eliminato', customer_email = 'eliminato+' || left(id::text, 8) || '@invalid.local',
         customer_phone = '000000', customer_notes = null, session_id = null,
         delivery_address_snapshot = case when delivery_address_snapshot is null then null
           else jsonb_build_object('city', delivery_address_snapshot ->> 'city', 'postal_code', delivery_address_snapshot ->> 'postal_code') end,
         user_id = null
   where user_id = p_user;
  update public.reservations set guest_name = 'Cliente', guest_surname = 'eliminato', guest_email = null, guest_phone = '000000', notes = null, user_id = null
   where user_id = p_user;
  update public.coupon_claims set user_id = null, email = null where user_id = p_user;
  update public.analytics_events set user_id = null where user_id = p_user;
  update public.ai_usage set user_id = null where user_id = p_user;
  update public.order_issues set user_id = null where user_id = p_user;
  update public.restaurant_reports set user_id = null where user_id = p_user;
  update public.support_tickets set user_id = null, contact_email = null, contact_name = null where user_id = p_user;
  update public.user_consents set user_id = null, anonymous_id = coalesce(anonymous_id, 'deleted-' || left(md5(p_user::text), 12)) where user_id = p_user;
  delete from public.ai_chat_sessions where user_id = p_user;
  delete from public.push_subscriptions where user_id = p_user;
  delete from public.customer_addresses where user_id = p_user;
  delete from public.carts where user_id = p_user;
  delete from public.favorites where user_id = p_user;
  delete from public.notifications where user_id = p_user;
  update public.profiles set full_name = 'Utente eliminato', display_name = null, email = null, phone = null, avatar_url = null,
         marketing_opt_in = false, is_blocked = true, city_id = null
   where id = p_user;
  perform public.audit_security('account_anonymized', 'profile', p_user::text, '{}'::jsonb, null);
  return 'anonymized';
end $$;

/** Esegue le richieste scadute (cron). Ritorna gli utenti Auth da eliminare con l'Admin API. */
create or replace function public.process_account_deletions(p_limit int default 20)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.account_deletion_requests; v_res text; v_ready uuid[] := '{}'; v_blocked int := 0; v_post int := 0;
begin
  perform public.assert_service();
  for r in select * from public.account_deletion_requests where status = 'scheduled' and scheduled_for <= now()
            order by scheduled_for limit p_limit for update skip locked loop
    if r.user_id is null then
      update public.account_deletion_requests set status = 'completed', completed_at = now() where id = r.id;
      continue;
    end if;
    v_res := public.account_anonymize(r.user_id);
    if v_res = 'anonymized' then
      update public.account_deletion_requests set status = 'anonymized', attempts = attempts + 1 where id = r.id;
      v_ready := v_ready || r.user_id;
    elsif v_res = 'postponed' then
      update public.account_deletion_requests set scheduled_for = now() + interval '1 day', attempts = attempts + 1 where id = r.id;
      v_post := v_post + 1;
    else
      update public.account_deletion_requests set status = 'blocked', blocked_reason = split_part(v_res, ':', 2), attempts = attempts + 1 where id = r.id;
      v_blocked := v_blocked + 1;
    end if;
  end loop;
  -- Anonimizzati ma non ancora eliminati da Auth (es. errore temporaneo): si riprovano
  select coalesce(array_agg(distinct x), '{}') into v_ready from (
    select unnest(v_ready) x union select user_id from public.account_deletion_requests where status = 'anonymized' and user_id is not null) s;
  return jsonb_build_object('hard_delete', to_jsonb(v_ready), 'blocked', v_blocked, 'postponed', v_post);
end $$;

create or replace function public.account_deletion_mark_hard_deleted(p_user uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  update public.account_deletion_requests set status = 'completed', completed_at = now() where user_id = p_user and status = 'anonymized';
  perform public.audit_security('account_hard_deleted', 'profile', p_user::text, '{}'::jsonb, null);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  9. JOB IN BACKGROUND, LOCK E LOG ERRORI
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.background_jobs (
  id           uuid primary key default gen_random_uuid(),
  job_type     text not null check (char_length(job_type) <= 60),
  status       text not null default 'queued' check (status in ('queued', 'running', 'completed', 'failed', 'skipped')),
  payload_safe jsonb not null default '{}'::jsonb check (pg_column_size(payload_safe) <= 4000),
  result       jsonb check (pg_column_size(result) <= 8000),
  attempts     int not null default 0,
  max_attempts int not null default 3,
  last_error   text check (char_length(last_error) <= 500),
  scheduled_at timestamptz not null default now(),
  started_at   timestamptz,
  completed_at timestamptz,
  created_at   timestamptz not null default now()
);
create index if not exists background_jobs_type_idx on public.background_jobs(job_type, created_at desc);
create index if not exists background_jobs_status_idx on public.background_jobs(status, scheduled_at) where status in ('queued', 'failed', 'running');
alter table public.background_jobs enable row level security;
create policy "jobs_admin_read" on public.background_jobs for select to authenticated using (public.is_admin());
revoke insert, update, delete on public.background_jobs from anon, authenticated;

create table if not exists public.job_locks (
  name         text primary key check (char_length(name) <= 60),
  holder       text not null,
  locked_until timestamptz not null,
  acquired_at  timestamptz not null default now()
);
alter table public.job_locks enable row level security;
revoke all on public.job_locks from anon, authenticated;

/** Lock con scadenza (un'esecuzione bloccata non blocca per sempre). true = acquisito. */
create or replace function public.job_lock_acquire(p_name text, p_holder text, p_ttl_seconds int default 300)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_ok boolean;
begin
  perform public.assert_service();
  insert into public.job_locks (name, holder, locked_until) values (p_name, p_holder, now() + make_interval(secs => p_ttl_seconds))
  on conflict (name) do update set holder = excluded.holder, locked_until = excluded.locked_until, acquired_at = now()
    where public.job_locks.locked_until < now()
  returning true into v_ok;
  return coalesce(v_ok, false);
end $$;

create or replace function public.job_lock_release(p_name text, p_holder text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  delete from public.job_locks where name = p_name and holder = p_holder;
end $$;

create or replace function public.background_job_start(p_type text, p_payload jsonb default '{}'::jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  perform public.assert_service();
  insert into public.background_jobs (job_type, status, payload_safe, attempts, started_at)
  values (left(p_type, 60), 'running', coalesce(p_payload, '{}'::jsonb), 1, now()) returning id into v_id;
  return v_id;
end $$;

create or replace function public.background_job_finish(p_id uuid, p_status text, p_error text default null, p_result jsonb default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  update public.background_jobs set status = case when p_status in ('completed', 'failed', 'skipped') then p_status else 'failed' end,
         last_error = left(p_error, 500), result = p_result, completed_at = now()
   where id = p_id;
end $$;

/** Retry controllato: rimette in coda un job fallito (il cron lo riesegue se il tipo è rieseguibile). */
create or replace function public.admin_retry_job(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare j public.background_jobs;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into j from public.background_jobs where id = p_id for update;
  if not found or j.status <> 'failed' then raise exception 'Solo i job falliti possono essere ripetuti'; end if;
  if j.attempts >= j.max_attempts then raise exception 'Numero massimo di tentativi raggiunto: serve un intervento manuale'; end if;
  update public.background_jobs set status = 'queued', scheduled_at = now() where id = p_id;
  perform public.audit_admin('job_retry', 'background_job', p_id::text, jsonb_build_object('type', j.job_type));
end $$;

create or replace function public.background_jobs_claim(p_types text[], p_limit int default 5)
returns setof public.background_jobs language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  return query
  update public.background_jobs b set status = 'running', attempts = b.attempts + 1, started_at = now()
   where b.id in (select id from public.background_jobs where status = 'queued' and job_type = any(p_types) and scheduled_at <= now()
                   order by scheduled_at limit p_limit for update skip locked)
  returning b.*;
end $$;

create table if not exists public.system_error_log (
  id         bigint generated always as identity primary key,
  source     text not null check (source in ('client', 'server', 'cron', 'webhook')),
  code       text check (char_length(code) <= 60),
  message    text not null check (char_length(message) <= 400),
  route      text check (char_length(route) <= 120),
  request_id text check (char_length(request_id) <= 64),
  release    text check (char_length(release) <= 40),
  environment text check (char_length(environment) <= 20),
  ip_hash    text check (char_length(ip_hash) <= 64),
  created_at timestamptz not null default now()
);
create index if not exists system_error_log_created_idx on public.system_error_log(created_at desc);
alter table public.system_error_log enable row level security;
create policy "errors_admin_read" on public.system_error_log for select to authenticated using (public.is_admin());
revoke insert, update, delete on public.system_error_log from anon, authenticated;

/** Rimozione di dati personali prima di salvare un messaggio d'errore (email, telefoni, numeri lunghi, token, URL firmati). */
create or replace function public.scrub_pii(p_text text)
returns text language sql immutable as $$
  select left(regexp_replace(regexp_replace(regexp_replace(regexp_replace(regexp_replace(coalesce(p_text, ''),
    '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', '[email]', 'g'),
    '(token|key|secret|signature|sig|apikey|authorization|bearer)([=: ]+)[^ &"'']+', '\1\2[redacted]', 'gi'),
    '(eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+)', '[jwt]', 'g'),
    '(sk|rk|pk|whsec)_(live|test)?_?[A-Za-z0-9]{8,}', '[stripe-key]', 'g'),
    '\+?[0-9][0-9 .-]{7,}[0-9]', '[number]', 'g'), 400);
$$;

create or replace function public.client_error_record(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.rate_limit_hit('client_error', public.rate_limit_caller_key(), 20, 600) then return; end if;
  insert into public.system_error_log (source, code, message, route, release, environment, ip_hash)
  values ('client', left(public.scrub_pii(p ->> 'code'), 60), coalesce(nullif(public.scrub_pii(p ->> 'message'), ''), 'Errore sconosciuto'),
          left(regexp_replace(coalesce(p ->> 'route', ''), '[?#].*$', ''), 120), left(p ->> 'release', 40), left(p ->> 'environment', 20), public.sys_ip_hash());
end $$;

create or replace function public.system_log_error(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  insert into public.system_error_log (source, code, message, route, request_id, release, environment)
  values (case when p ->> 'source' in ('server', 'cron', 'webhook') then p ->> 'source' else 'server' end,
          left(p ->> 'code', 60), coalesce(nullif(public.scrub_pii(p ->> 'message'), ''), 'Errore'), left(p ->> 'route', 120),
          left(p ->> 'request_id', 64), left(p ->> 'release', 40), left(p ->> 'environment', 20));
end $$;

create or replace function public.system_ping()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object('ok', true, 'db_time', now());
$$;

-- Web Vitals (solo con consenso analytics, lato client): nessun identificativo, solo pagina "modello" e tipo di dispositivo
create table if not exists public.web_vitals (
  id         bigint generated always as identity primary key,
  metric     text not null check (metric in ('LCP', 'INP', 'CLS', 'FCP', 'TTFB')),
  value      numeric not null check (value >= 0 and value < 600000),
  rating     text check (rating in ('good', 'needs-improvement', 'poor')),
  route      text check (char_length(route) <= 80),
  device     text check (device in ('mobile', 'desktop')),
  created_at timestamptz not null default now()
);
create index if not exists web_vitals_created_idx on public.web_vitals(metric, created_at desc);
alter table public.web_vitals enable row level security;
create policy "vitals_admin_read" on public.web_vitals for select to authenticated using (public.is_admin());
revoke insert, update, delete on public.web_vitals from anon, authenticated;

create or replace function public.web_vital_record(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.rate_limit_hit('web_vitals', public.rate_limit_caller_key(), 60, 600) then return; end if;
  if (p ->> 'metric') not in ('LCP', 'INP', 'CLS', 'FCP', 'TTFB') then return; end if;
  insert into public.web_vitals (metric, value, rating, route, device)
  values (p ->> 'metric', greatest(least((p ->> 'value')::numeric, 599999), 0),
          case when p ->> 'rating' in ('good', 'needs-improvement', 'poor') then p ->> 'rating' end,
          left(regexp_replace(coalesce(p ->> 'route', ''), '[?#].*$', ''), 80),
          case when p ->> 'device' in ('mobile', 'desktop') then p ->> 'device' end);
exception when others then
  return; -- misura non valida: ignorata
end $$;

-- ────────────────────────────────────────────────────────────────────
--  10. STORICO SLUG (redirect 301 old → current)
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.restaurant_slug_history (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  old_slug      text not null unique check (old_slug ~ '^[a-z0-9-]{1,120}$'),
  created_at    timestamptz not null default now()
);
create index if not exists restaurant_slug_history_restaurant_idx on public.restaurant_slug_history(restaurant_id);
alter table public.restaurant_slug_history enable row level security;
create policy "slug_history_read" on public.restaurant_slug_history for select using (public.restaurant_is_public(restaurant_id) or public.is_admin());

create or replace function public.restaurants_track_slug()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.slug is distinct from old.slug and old.slug is not null then
    delete from public.restaurant_slug_history where old_slug = new.slug; -- lo slug torna attivo: niente loop
    insert into public.restaurant_slug_history (restaurant_id, old_slug) values (new.id, old.slug)
    on conflict (old_slug) do update set restaurant_id = excluded.restaurant_id, created_at = now();
  end if;
  return new;
end $$;
drop trigger if exists restaurants_slug_history on public.restaurants;
create trigger restaurants_slug_history after update of slug on public.restaurants
  for each row execute function public.restaurants_track_slug();

create or replace function public.restaurant_slug_redirect(p_slug text)
returns text language sql stable security definer set search_path = public as $$
  select r.slug from public.restaurant_slug_history h join public.restaurants r on r.id = h.restaurant_id
   where h.old_slug = lower(p_slug) and public.restaurant_is_public(r.id) limit 1;
$$;

create or replace function public.restaurant_slug_redirects()
returns table (old_slug text, new_slug text) language sql stable security definer set search_path = public as $$
  select h.old_slug, r.slug from public.restaurant_slug_history h join public.restaurants r on r.id = h.restaurant_id
   where public.restaurant_is_public(r.id) and h.old_slug <> r.slug order by h.created_at limit 5000;
$$;

-- ────────────────────────────────────────────────────────────────────
--  11. SUPPORTO (ticket)
-- ────────────────────────────────────────────────────────────────────

/**
 * Nuovo ticket. Da utente autenticato (RPC diretta) o dal backend /api/support per gli ospiti (Turnstile verificato dal server).
 * Ordine collegato solo se è dell'utente o se l'ospite conosce numero + token di tracciamento.
 */
create or replace function public.support_ticket_create(p jsonb, p_ip_hash text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_order uuid;
  v_rest uuid;
  v_cat text := coalesce(p ->> 'category', 'other');
  v_prio text := 'normal';
  v_row public.support_tickets;
  v_email text := nullif(lower(trim(p ->> 'email')), '');
begin
  if v_uid is null and not public.sys_is_service() then raise exception 'Accedi o usa il modulo di contatto' using errcode = '42501'; end if;
  if v_uid is null then
    if not public.rate_limit_hit('support_guest', coalesce(p_ip_hash, 'anon'), 5, 3600) then
      raise exception 'RATE_LIMITED: Troppe richieste in poco tempo. Riprova tra qualche minuto.' using errcode = 'P0001';
    end if;
    if v_email is null then raise exception 'Indica un''email per ricevere la risposta' using errcode = '22023'; end if;
  else
    perform public.rate_limit_assert('support', 8, 3600);
  end if;
  if coalesce(p ->> 'order_number', '') <> '' then
    select o.id, o.restaurant_id into v_order, v_rest from public.orders o where o.order_number = upper(p ->> 'order_number')
      and ((v_uid is not null and o.user_id = v_uid)
        or public.order_access(p ->> 'order_number', p ->> 'order_token') is not null
        or (v_uid is not null and public.can_view_orders(o.restaurant_id)));
    if v_order is null then raise exception 'Ordine non trovato o non accessibile' using errcode = '22023'; end if;
  end if;
  if v_rest is null and coalesce(p ->> 'restaurant_id', '') ~ '^[0-9a-f-]{36}$' then
    select id into v_rest from public.restaurants where id = (p ->> 'restaurant_id')::uuid and (public.restaurant_is_public(id) or public.can_manage_restaurant(id));
  end if;
  if v_cat in ('order', 'rider', 'billing') and v_order is not null then v_prio := 'high'; end if;
  if v_cat = 'privacy' then v_prio := 'high'; end if;
  insert into public.support_tickets (user_id, restaurant_id, order_id, category, priority, subject, description, contact_email, contact_name, source)
  values (v_uid, v_rest, v_order, v_cat, v_prio, left(trim(p ->> 'subject'), 140), left(trim(p ->> 'description'), 4000),
          coalesce(v_email, (select email from public.profiles where id = v_uid)), left(trim(p ->> 'name'), 80),
          case when p ->> 'source' = 'app' then 'app' else 'web' end)
  returning * into v_row;
  return jsonb_build_object('id', v_row.id, 'reference', v_row.reference, 'status', v_row.status);
end $$;

create or replace function public.my_support_tickets()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'reference', reference, 'category', category, 'subject', subject, 'status', status,
         'resolution', resolution, 'created_at', created_at, 'updated_at', updated_at) order by created_at desc), '[]'::jsonb)
    from (select * from public.support_tickets where user_id = auth.uid() order by created_at desc limit 50) t;
$$;

create or replace function public.admin_support_tickets(p_filter text default 'open', p_limit int default 50, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_rows jsonb; v_total int;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  with f as (
    select t.* from public.support_tickets t
     where case p_filter
       when 'open' then t.status in ('open', 'in_progress', 'waiting_customer')
       when 'urgent' then t.priority in ('urgent', 'high') and t.status in ('open', 'in_progress', 'waiting_customer')
       when 'orders' then t.category in ('order', 'reservation')
       when 'restaurants' then t.category in ('restaurant', 'business')
       when 'riders' then t.category = 'rider'
       when 'billing' then t.category = 'billing'
       when 'closed' then t.status in ('resolved', 'closed')
       else true end)
  select count(*)::int, coalesce(jsonb_agg(x order by x.pr, x.created_at desc), '[]'::jsonb) into v_total, v_rows
    from (select f.*, case f.priority when 'urgent' then 0 when 'high' then 1 when 'normal' then 2 else 3 end pr,
                 (select order_number from public.orders o where o.id = f.order_id) order_number,
                 (select name from public.restaurants r where r.id = f.restaurant_id) restaurant_name
            from f order by pr, created_at desc limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)) x;
  return jsonb_build_object('total', (select count(*) from public.support_tickets t where case p_filter
       when 'open' then t.status in ('open', 'in_progress', 'waiting_customer')
       when 'urgent' then t.priority in ('urgent', 'high') and t.status in ('open', 'in_progress', 'waiting_customer')
       when 'orders' then t.category in ('order', 'reservation')
       when 'restaurants' then t.category in ('restaurant', 'business')
       when 'riders' then t.category = 'rider'
       when 'billing' then t.category = 'billing'
       when 'closed' then t.status in ('resolved', 'closed')
       else true end), 'rows', v_rows);
end $$;

create or replace function public.admin_support_update(p_id uuid, p jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  update public.support_tickets set
    status = case when p ? 'status' and p ->> 'status' in ('open', 'in_progress', 'waiting_customer', 'resolved', 'closed') then p ->> 'status' else status end,
    priority = case when p ? 'priority' and p ->> 'priority' in ('low', 'normal', 'high', 'urgent') then p ->> 'priority' else priority end,
    assigned_to = case when p ? 'assigned_to' then nullif(p ->> 'assigned_to', '')::uuid else assigned_to end,
    admin_notes = case when p ? 'admin_notes' then left(p ->> 'admin_notes', 4000) else admin_notes end,
    resolution = case when p ? 'resolution' then left(p ->> 'resolution', 2000) else resolution end,
    resolved_at = case when p ->> 'status' in ('resolved', 'closed') then coalesce(resolved_at, now()) else resolved_at end
   where id = p_id;
  if not found then raise exception 'Ticket non trovato'; end if;
  perform public.audit_admin('support_ticket_update', 'support_ticket', p_id::text, p - 'admin_notes');
  if p ->> 'status' in ('resolved', 'closed') then
    perform public.notify_user(t.user_id, 'support', 'Richiesta di supporto aggiornata', format('La richiesta %s è stata chiusa.', t.reference), '/support')
      from public.support_tickets t where t.id = p_id and t.user_id is not null;
  end if;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  12. INVITI BETA
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.beta_invites (
  id         uuid primary key default gen_random_uuid(),
  email      text check (email is null or email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  token_hash text not null unique,
  role       text not null default 'customer' check (role in ('customer', 'restaurant_owner', 'rider', 'tester')),
  created_by uuid references public.profiles(id) on delete set null,
  used_by    uuid references public.profiles(id) on delete set null,
  expires_at timestamptz not null,
  used_at    timestamptz,
  created_at timestamptz not null default now()
);
alter table public.beta_invites enable row level security;
create policy "beta_invites_admin" on public.beta_invites for select to authenticated using (public.is_admin());
revoke insert, update, delete on public.beta_invites from anon, authenticated;
alter table public.profiles add column if not exists beta_access_at timestamptz;

create or replace function public.admin_beta_invite_create(p_email text default null, p_role text default 'customer', p_days int default 14)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v_token text := encode(gen_random_bytes(18), 'hex'); v_id uuid;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  insert into public.beta_invites (email, token_hash, role, created_by, expires_at)
  values (nullif(lower(trim(p_email)), ''), public.order_hash_token(v_token), coalesce(p_role, 'customer'), auth.uid(), now() + make_interval(days => least(greatest(p_days, 1), 90)))
  returning id into v_id;
  perform public.audit_admin('beta_invite_created', 'beta_invite', v_id::text, jsonb_build_object('role', p_role));
  -- Il token è mostrato UNA volta: nel database resta solo l'hash
  return jsonb_build_object('id', v_id, 'token', v_token);
end $$;

create or replace function public.beta_invite_redeem(p_token text)
returns boolean language plpgsql security definer set search_path = public as $$
declare v public.beta_invites;
begin
  if auth.uid() is null then raise exception 'Accedi per usare l''invito' using errcode = '42501'; end if;
  perform public.rate_limit_assert('beta_invite', 10, 3600);
  select * into v from public.beta_invites where token_hash = public.order_hash_token(p_token) for update;
  if not found or v.used_at is not null or v.expires_at < now() then return false; end if;
  update public.beta_invites set used_at = now(), used_by = auth.uid() where id = v.id;
  update public.profiles set beta_access_at = now() where id = auth.uid();
  return true;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  13. FEATURE FLAG / KILL SWITCH (Admin, con audit)
-- ────────────────────────────────────────────────────────────────────
/** Registro unico: flag → chiave platform_settings (niente duplicati con le chiavi esistenti). */
create or replace function public.feature_flag_keys()
returns table (flag text, setting_key text, kind text, label text) language sql immutable as $$
  values ('ai', 'ai_enabled', 'feature', 'Assistente AI (chiamate al modello)'),
         ('orders', 'orders_enabled', 'kill_switch', 'Nuovi ordini online'),
         ('delivery', 'logistics_enabled', 'feature', 'Consegne con Rider AsiaFood'),
         ('rider_dispatch', 'logistics_auto_dispatch_enabled', 'kill_switch', 'Dispatch automatico Rider'),
         ('riders', 'rider_signup_enabled', 'feature', 'Candidature Rider'),
         ('crm_agents', 'crm_agents_enabled', 'kill_switch', 'CRM / Sales Agent (modulo non presente)'),
         ('push', 'push_enabled', 'feature', 'Notifiche push'),
         ('push_campaigns', 'campaigns_enabled', 'kill_switch', 'Campagne push/in-app programmate'),
         ('reviews', 'reviews_enabled', 'feature', 'Nuove recensioni'),
         ('loyalty', 'loyalty_enabled', 'feature', 'AsiaPoints (loyalty)'),
         ('referral', 'referral_enabled', 'feature', 'Invita un amico'),
         ('maintenance', 'maintenance_mode', 'maintenance', 'Modalità manutenzione'),
         ('beta', 'beta_mode', 'feature', 'Badge Beta'),
         ('beta_invite_only', 'beta_invite_only', 'feature', 'Beta solo su invito');
$$;

create or replace function public.admin_set_flag(p_flag text, p_value boolean)
returns void language plpgsql security definer set search_path = public as $$
declare v_key text;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select setting_key into v_key from public.feature_flag_keys() where flag = p_flag;
  if v_key is null then raise exception 'Flag sconosciuto' using errcode = '22023'; end if;
  insert into public.platform_settings (key, value, updated_by) values (v_key, to_jsonb(p_value), auth.uid())
  on conflict (key) do update set value = to_jsonb(p_value), updated_by = auth.uid();
  perform public.audit_admin('flag_change', 'feature_flag', p_flag, jsonb_build_object('value', p_value));
end $$;

-- Recensioni disattivabili (feature flag) + limite di frequenza per utente
create or replace function public.reviews_guard_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.sys_is_service() then return new; end if;
  if not public.billing_setting_bool('reviews_enabled', true) then
    raise exception 'Le recensioni sono temporaneamente disattivate.' using errcode = 'P0001';
  end if;
  perform public.rate_limit_assert('review_submit', 6, 3600);
  return new;
end $$;
drop trigger if exists reviews_guard_insert on public.reviews;
create trigger reviews_guard_insert before insert on public.reviews for each row execute function public.reviews_guard_insert();

-- Candidature Rider disattivabili
create or replace function public.rider_signup_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.sys_is_service() or public.is_admin() then return new; end if;
  if not public.billing_setting_bool('rider_signup_enabled', true) then
    raise exception 'Le candidature Rider sono momentaneamente chiuse.' using errcode = 'P0001';
  end if;
  perform public.rate_limit_assert('rider_apply', 5, 86400);
  return new;
end $$;
drop trigger if exists rider_signup_guard on public.rider_profiles;
create trigger rider_signup_guard before insert on public.rider_profiles for each row execute function public.rider_signup_guard();

-- ────────────────────────────────────────────────────────────────────
--  14. RATE LIMIT SUI FLUSSI AD ALTO ABUSO (trigger: valgono per qualsiasi RPC che scrive)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.rate_limit_trigger()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.rate_limit_assert(tg_argv[0], tg_argv[1]::int, tg_argv[2]::int);
  return new;
end $$;

do $$
declare x record;
begin
  for x in select * from (values
      ('coupon_claims', 'coupon_claim', 20, 3600),
      ('reservations', 'reservation_create', 10, 3600),
      ('review_reports', 'review_report', 20, 3600),
      ('review_votes', 'review_vote', 120, 3600),
      ('restaurant_reports', 'restaurant_report', 10, 3600),
      ('restaurant_claims', 'claim_submit', 5, 86400),
      ('restaurant_claim_messages', 'claim_message', 30, 3600),
      ('restaurant_change_requests', 'change_request', 30, 3600),
      ('plan_upgrade_requests', 'upgrade_request', 10, 86400),
      ('order_issues', 'order_issue', 10, 3600),
      ('referrals', 'referral_invite', 30, 86400)
    ) as v(tbl, bucket, lim, win) loop
    execute format('drop trigger if exists %I on public.%I', x.tbl || '_rate_limit', x.tbl);
    execute format('create trigger %I before insert on public.%I for each row execute function public.rate_limit_trigger(%L, %L, %L)',
                   x.tbl || '_rate_limit', x.tbl, x.bucket, x.lim, x.win);
  end loop;
end $$;

-- GPS Rider: traffico anomalo (oltre 40 posizioni al minuto) scartato senza errore, con traccia di sicurezza
create or replace function public.rider_locations_flood_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.sys_is_service() then return new; end if;
  if not public.rate_limit_hit('rider_gps', 'r:' || new.rider_id::text, 40, 60) then
    if not exists (select 1 from public.security_audit_logs where action = 'rider_gps_flood' and entity_id = new.rider_id::text and created_at > now() - interval '10 minutes') then
      perform public.audit_security('rider_gps_flood', 'rider', new.rider_id::text, '{}'::jsonb);
    end if;
    return null;
  end if;
  return new;
end $$;
drop trigger if exists rider_locations_flood_guard on public.rider_locations;
create trigger rider_locations_flood_guard before insert on public.rider_locations for each row execute function public.rider_locations_flood_guard();

-- Push: solo endpoint di servizi push noti (niente richieste del server verso host arbitrari = SSRF)
create or replace function public.push_endpoint_allowed(p_endpoint text)
returns boolean language sql immutable as $$
  select p_endpoint ~ '^https://(fcm\.googleapis\.com|android\.googleapis\.com|updates\.push\.services\.mozilla\.com|[a-z0-9-]+\.push\.services\.mozilla\.com|web\.push\.apple\.com|[a-z0-9.-]+\.push\.apple\.com|[a-z0-9.-]+\.notify\.windows\.com)/';
$$;
create or replace function public.push_subscriptions_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.push_endpoint_allowed(new.endpoint) then
    raise exception 'Servizio di notifica non supportato' using errcode = '22023';
  end if;
  return new;
end $$;
drop trigger if exists push_subscriptions_guard on public.push_subscriptions;
create trigger push_subscriptions_guard before insert or update of endpoint on public.push_subscriptions
  for each row execute function public.push_subscriptions_guard();
update public.push_subscriptions set is_active = false where is_active and not public.push_endpoint_allowed(endpoint);

-- ────────────────────────────────────────────────────────────────────
--  15. RETENTION (job pianificato; nessuna cancellazione di dati con obbligo legale senza policy)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.retention_cleanup()
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  n jsonb := '{}'::jsonb;
  c int;
begin
  perform public.assert_service();
  set local asiafood.retention = 'on';
  set local asiafood.lg_sync = 'on';
  -- Chat AI (anche ai_purge esistente, qui per coerenza della policy)
  delete from public.ai_chat_sessions where expires_at < now() or updated_at < now() - make_interval(days => public.billing_setting_int('retention_ai_chat_days', 7));
  get diagnostics c = row_count; n := n || jsonb_build_object('ai_chat_sessions', c);
  -- GPS Rider: posizioni precise oltre la finestra configurata
  delete from public.rider_locations where recorded_at < now() - make_interval(hours => public.billing_setting_int('logistics_location_retention_hours', 24));
  get diagnostics c = row_count; n := n || jsonb_build_object('rider_locations', c);
  -- Log applicativi
  delete from public.system_error_log where created_at < now() - make_interval(days => public.billing_setting_int('retention_app_logs_days', 90));
  get diagnostics c = row_count; n := n || jsonb_build_object('system_error_log', c);
  delete from public.app_events where created_at < now() - make_interval(days => public.billing_setting_int('retention_app_logs_days', 90));
  get diagnostics c = row_count; n := n || jsonb_build_object('app_events', c);
  delete from public.background_jobs where created_at < now() - make_interval(days => public.billing_setting_int('retention_app_logs_days', 90))
     and status in ('completed', 'skipped', 'failed');
  get diagnostics c = row_count; n := n || jsonb_build_object('background_jobs', c);
  delete from public.security_audit_logs where created_at < now() - make_interval(days => public.billing_setting_int('retention_security_logs_days', 365));
  get diagnostics c = row_count; n := n || jsonb_build_object('security_audit_logs', c);
  -- Analytics (13 mesi)
  delete from public.analytics_events where created_at < now() - make_interval(days => public.billing_setting_int('retention_analytics_days', 395));
  get diagnostics c = row_count; n := n || jsonb_build_object('analytics_events', c);
  delete from public.web_vitals where created_at < now() - make_interval(days => public.billing_setting_int('retention_web_vitals_days', 90));
  get diagnostics c = row_count; n := n || jsonb_build_object('web_vitals', c);
  -- Carrelli abbandonati
  delete from public.carts where status <> 'active' and updated_at < now() - make_interval(days => public.billing_setting_int('retention_abandoned_cart_days', 30));
  get diagnostics c = row_count; n := n || jsonb_build_object('carts', c);
  delete from public.carts where user_id is null and updated_at < now() - make_interval(days => public.billing_setting_int('retention_abandoned_cart_days', 30));
  get diagnostics c = row_count; n := n || jsonb_build_object('guest_carts', c);
  -- Endpoint push disattivati
  delete from public.push_subscriptions where not is_active and updated_at < now() - make_interval(days => public.billing_setting_int('retention_push_inactive_days', 180));
  get diagnostics c = row_count; n := n || jsonb_build_object('push_subscriptions', c);
  -- Inviti scaduti o usati
  delete from public.beta_invites where (expires_at < now() or used_at is not null)
     and coalesce(used_at, expires_at) < now() - make_interval(days => public.billing_setting_int('retention_expired_invites_days', 30));
  get diagnostics c = row_count; n := n || jsonb_build_object('beta_invites', c);
  -- Pagamenti mai completati: dati personali rimossi (l'ordine resta come riga statistica)
  update public.orders set customer_name = 'Cliente', customer_email = 'rimosso+' || left(id::text, 8) || '@invalid.local', customer_phone = '000000',
         customer_notes = null, delivery_address_snapshot = null
   where status in ('cancelled', 'pending_payment') and payment_status in ('unpaid', 'failed')
     and created_at < now() - make_interval(days => public.billing_setting_int('retention_failed_payment_days', 90))
     and customer_phone <> '000000';
  get diagnostics c = row_count; n := n || jsonb_build_object('failed_payment_orders', c);
  -- Rate limit e lock scaduti
  delete from public.rate_limits where window_start < now() - make_interval(hours => public.billing_setting_int('retention_rate_limit_hours', 48));
  get diagnostics c = row_count; n := n || jsonb_build_object('rate_limits', c);
  delete from public.order_rate_limits where created_at < now() - make_interval(hours => public.billing_setting_int('retention_rate_limit_hours', 48));
  get diagnostics c = row_count; n := n || jsonb_build_object('order_rate_limits', c);
  delete from public.job_locks where locked_until < now() - interval '1 day';
  -- Export scaduti
  update public.data_export_requests set status = 'expired' where status = 'completed' and expires_at < now();
  -- Ticket chiusi molto vecchi: contatti rimossi
  update public.support_tickets set contact_email = null, contact_name = null
   where status in ('resolved', 'closed') and updated_at < now() - make_interval(days => public.billing_setting_int('retention_support_closed_days', 730))
     and (contact_email is not null or contact_name is not null);
  get diagnostics c = row_count; n := n || jsonb_build_object('support_tickets_anonymized', c);
  -- Notifiche scadute
  delete from public.notifications where expires_at is not null and expires_at < now() - interval '30 days';
  get diagnostics c = row_count; n := n || jsonb_build_object('notifications', c);
  return n;
end $$;

-- Kill switch campagne: campaign_dispatch non invia nulla se campaigns_enabled = false (la campagna resta programmata)
-- (corpo originale della Fase 7 + controllo iniziale)
create or replace function public.campaign_dispatch(p_id uuid)
returns int language plpgsql security definer set search_path = public as $$
declare
  c public.campaigns;
  u record;
  v_n int := 0;
  v_cap int := public.billing_setting_int('campaign_max_per_user_week', 3);
  v_max int := public.billing_setting_int('campaign_max_recipients', 5000);
  v_notif uuid;
  v_del uuid;
  v_link text;
  pr public.notification_preferences;
  ch text;
  r public.restaurants;
begin
  -- Fase 11 · kill switch: con campagne disattivate non si invia nulla (resta "programmata")
  if not public.billing_setting_bool('campaigns_enabled', true) then return 0; end if;
  select * into c from public.campaigns where id = p_id for update skip locked;
  if not found or c.status <> 'scheduled' or c.send_at > now() then return 0; end if;
  update public.campaigns set status = 'sending' where id = p_id;
  if c.scope = 'restaurant' then
    select * into r from public.restaurants where id = c.restaurant_id;
    if not public.restaurant_has_feature(c.restaurant_id, 'push_campaigns_enabled') then
      update public.campaigns set status = 'failed', error = 'Funzione non inclusa nel piano attuale' where id = p_id;
      return 0;
    end if;
  end if;
  for u in select a.user_id from public.campaign_audience(c.scope, c.restaurant_id, c.target, c.targeting) a limit v_max loop
    -- Tetto promozionale settimanale per persona (tutte le campagne)
    if (select count(distinct d.campaign_id) from public.campaign_deliveries d
        where d.user_id = u.user_id and d.status in ('sent', 'delivered', 'queued') and d.sent_at > now() - interval '7 days') >= v_cap then
      insert into public.campaign_deliveries (campaign_id, user_id, channel, status, error)
      values (p_id, u.user_id, c.channels[1], 'skipped', 'frequency_cap') on conflict do nothing;
      continue;
    end if;
    pr := public.user_prefs(u.user_id);
    foreach ch in array c.channels loop
      insert into public.campaign_deliveries (campaign_id, user_id, channel, status, sent_at)
      values (p_id, u.user_id, ch, 'queued', now()) on conflict do nothing returning id into v_del;
      continue when v_del is null;
      v_link := coalesce(c.action_url, '/') || case when coalesce(c.action_url, '/') ~ '\?' then '&' else '?' end || 'cd=' || v_del;
      if ch = 'in_app' then
        insert into public.notifications (user_id, restaurant_id, type, title, body, link, metadata)
        values (u.user_id, c.restaurant_id, 'promotion', c.title, c.message, v_link, jsonb_build_object('campaign_id', c.id, 'delivery_id', v_del))
        returning id into v_notif;
        update public.campaign_deliveries set status = 'delivered', notification_id = v_notif, delivered_at = now() where id = v_del;
      elsif ch = 'push' then
        if pr.push_enabled and exists (select 1 from public.push_subscriptions s where s.user_id = u.user_id and s.is_active) then
          insert into public.push_outbox (user_id, campaign_delivery_id, title, body, url, tag)
          values (u.user_id, v_del, c.title, c.message, v_link, 'campaign-' || left(c.id::text, 8));
        else
          update public.campaign_deliveries set status = 'skipped', error = 'no_push_subscription' where id = v_del;
        end if;
      elsif ch = 'email' then
        if pr.email_enabled then
          perform public.enqueue_email('marketing_campaign', (select email from public.profiles where id = u.user_id),
            jsonb_build_object('title', c.title, 'body', c.message, 'link', v_link), c.restaurant_id, null);
          update public.campaign_deliveries set status = 'sent' where id = v_del;
        else
          update public.campaign_deliveries set status = 'skipped', error = 'email_disabled' where id = v_del;
        end if;
      end if;
    end loop;
    v_n := v_n + 1;
  end loop;
  update public.campaigns set status = 'sent', sent_at = now(), recipients_count = v_n where id = p_id;
  return v_n;
exception when others then
  update public.campaigns set status = 'failed', error = left(sqlerrm, 200) where id = p_id;
  return 0;
end $$;

-- assert_service più rigoroso: prima bastava non avere un utente (anche la chiave anon passava);
-- ora rifiuta esplicitamente i ruoli anon/authenticated (difesa in profondità oltre ai GRANT).
create or replace function public.assert_service()
returns void language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is not null or coalesce(auth.role(), '') in ('anon', 'authenticated') then
    raise exception 'Solo backend' using errcode = '42501';
  end if;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  16. REPORT DI CONSISTENZA DEL DATABASE
-- ────────────────────────────────────────────────────────────────────
create or replace function public.db_consistency_report()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb := '[]'::jsonb;
begin
  if not (public.is_admin() or public.sys_is_service()) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  with checks(key, label, severity, ids) as (
    select 'orders_stuck_inactive_restaurant', 'Ordini aperti su locali disattivati', 'high',
           array(select o.id::text from public.orders o join public.restaurants r on r.id = o.restaurant_id
                  where not r.is_active and o.status in ('pending_restaurant', 'accepted', 'preparing', 'ready', 'out_for_delivery') limit 20)
    union all select 'delivery_jobs_without_active_order', 'Consegne attive con ordine già chiuso', 'high',
           array(select j.id::text from public.delivery_jobs j join public.orders o on o.id = j.order_id
                  where j.status not in ('delivered', 'failed', 'cancelled') and o.status in ('completed', 'cancelled', 'rejected', 'refunded') limit 20)
    union all select 'menu_items_category_mismatch', 'Piatti con categoria di un altro locale', 'medium',
           array(select i.id::text from public.menu_items i join public.menu_categories c on c.id = i.menu_category_id where c.restaurant_id <> i.restaurant_id limit 20)
    union all select 'menu_categories_menu_mismatch', 'Categorie menu collegate al menu di un altro locale', 'medium',
           array(select c.id::text from public.menu_categories c join public.menus m on m.id = c.menu_id where m.restaurant_id <> c.restaurant_id limit 20)
    union all select 'reviews_published_inactive_restaurant', 'Recensioni pubblicate su locali non attivi', 'low',
           array(select v.id::text from public.reviews v join public.restaurants r on r.id = v.restaurant_id where v.status = 'published' and not r.is_active limit 20)
    union all select 'reviews_empty_content', 'Recensioni pubblicate senza testo', 'low',
           array(select id::text from public.reviews where status = 'published' and char_length(trim(content)) = 0 limit 20)
    union all select 'subscriptions_multiple_active', 'Locali con più abbonamenti attivi', 'high',
           array(select restaurant_id::text from public.subscriptions where status in ('active', 'trialing', 'past_due')
                  group by restaurant_id having count(*) > 1 limit 20)
    union all select 'subscriptions_stale_period', 'Abbonamenti Stripe attivi con periodo scaduto da oltre 7 giorni', 'medium',
           array(select id::text from public.subscriptions where source = 'stripe' and status in ('active', 'trialing')
                  and current_period_end < now() - interval '7 days' limit 20)
    union all select 'members_blocked_active', 'Membri attivi con profilo bloccato', 'medium',
           array(select m.id::text from public.restaurant_members m join public.profiles p on p.id = m.user_id where m.status = 'active' and p.is_blocked limit 20)
    union all select 'owner_without_membership', 'Titolari senza membership attiva', 'medium',
           array(select r.id::text from public.restaurants r where r.owner_id is not null and not exists (
                  select 1 from public.restaurant_members m where m.restaurant_id = r.id and m.user_id = r.owner_id and m.status = 'active') limit 20)
    union all select 'duplicate_restaurant_slugs', 'Slug ristorante duplicati (maiuscole/minuscole)', 'high',
           array(select lower(slug) from public.restaurants group by lower(slug) having count(*) > 1 limit 20)
    union all select 'duplicate_city_slugs', 'Slug città duplicati', 'high',
           array(select lower(slug) from public.cities group by lower(slug) having count(*) > 1 limit 20)
    union all select 'active_restaurants_without_coordinates', 'Locali attivi senza coordinate', 'low',
           array(select id::text from public.restaurants where is_active and not is_demo and (latitude is null or longitude is null) limit 20)
    union all select 'loyalty_balance_mismatch', 'Saldo punti diverso dalla somma dei movimenti', 'medium',
           array(select a.user_id::text from public.loyalty_accounts a
                  where a.points_balance <> coalesce((select sum(t.points) from public.loyalty_transactions t where t.user_id = a.user_id and t.status <> 'pending'), 0)
                  limit 20)
    union all select 'rider_capacity_negative', 'Rider con capacità negativa', 'medium',
           array(select rider_id::text from public.rider_availability where current_capacity < 0 limit 20)
  )
  select coalesce(jsonb_agg(jsonb_build_object('key', key, 'label', label, 'severity', severity, 'count', coalesce(array_length(ids, 1), 0), 'sample', to_jsonb(ids[1:5]))), '[]'::jsonb)
    into v from checks;
  return jsonb_build_object('generated_at', now(), 'total_issues', (select coalesce(sum((x ->> 'count')::int), 0) from jsonb_array_elements(v) x), 'checks', v);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  17. STATO DI SISTEMA (/admin/system) — nessun segreto, solo conteggi e stati
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.launch_checks (
  key             text primary key check (key ~ '^[a-z0-9_]{3,60}$'),
  status          text not null default 'pending' check (status in ('pass', 'fail', 'warn', 'pending', 'na')),
  notes           text check (char_length(notes) <= 1000),
  source          text not null default 'manual' check (source in ('manual', 'system')),
  checked_by      uuid references public.profiles(id) on delete set null,
  last_checked_at timestamptz
);
alter table public.launch_checks enable row level security;
create policy "launch_checks_admin_read" on public.launch_checks for select to authenticated using (public.is_admin());
revoke insert, update, delete on public.launch_checks from anon, authenticated;

/** Risultati dei controlli di sistema (variabili d'ambiente, health, sitemap, HTTPS) registrati dal cron del backend. */
create or replace function public.system_record_check(p_key text, p_status text, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  insert into public.launch_checks (key, status, notes, source, last_checked_at)
  values (p_key, p_status, left(p_notes, 1000), 'system', now())
  on conflict (key) do update set status = excluded.status, notes = excluded.notes, source = 'system', last_checked_at = now();
end $$;

create or replace function public.admin_set_launch_check(p_key text, p_status text, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if exists (select 1 from public.launch_checks where key = p_key and source = 'system') then
    raise exception 'Controllo automatico: non modificabile a mano' using errcode = '22023';
  end if;
  if p_status not in ('pass', 'fail', 'warn', 'pending', 'na') then raise exception 'Stato non valido' using errcode = '22023'; end if;
  insert into public.launch_checks (key, status, notes, source, checked_by, last_checked_at)
  values (p_key, p_status, left(p_notes, 1000), 'manual', auth.uid(), now())
  on conflict (key) do update set status = excluded.status, notes = excluded.notes, checked_by = auth.uid(), last_checked_at = now();
  perform public.audit_admin('launch_check', 'launch_check', p_key, jsonb_build_object('status', p_status));
end $$;

create or replace function public.admin_system_status()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_ai_total int; v_ai_err int;
  v_db jsonb;
  v_alerts jsonb := '[]'::jsonb;
  v_err10 int; v_wh1 int; v_pay1 int; v_disp1 int;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select count(*), count(*) filter (where status = 'error') into v_ai_total, v_ai_err from public.ai_usage where created_at > now() - interval '1 hour';
  select count(*) into v_err10 from public.system_error_log where source <> 'client' and created_at > now() - interval '10 minutes';
  select count(*) into v_wh1 from public.stripe_events where processing_status = 'failed' and last_attempt_at > now() - interval '1 hour';
  select count(*) into v_pay1 from public.analytics_events where event_type = 'payment_failed' and created_at > now() - interval '1 hour';
  select count(*) into v_disp1 from public.logistics_alerts where alert_type in ('dispatch_exhausted', 'no_rider') and created_at > now() - interval '1 hour';
  if v_err10 >= public.billing_setting_int('alert_error_rate_per_10min', 25) then
    v_alerts := v_alerts || jsonb_build_object('key', 'error_rate', 'level', 'critical', 'message', format('%s errori server negli ultimi 10 minuti', v_err10)); end if;
  if v_wh1 >= public.billing_setting_int('alert_webhook_failures_per_hour', 3) then
    v_alerts := v_alerts || jsonb_build_object('key', 'webhooks', 'level', 'critical', 'message', format('%s webhook Stripe falliti nell''ultima ora', v_wh1)); end if;
  if v_pay1 >= public.billing_setting_int('alert_payment_failures_per_hour', 10) then
    v_alerts := v_alerts || jsonb_build_object('key', 'payments', 'level', 'warning', 'message', format('%s pagamenti falliti nell''ultima ora', v_pay1)); end if;
  if v_ai_total >= 10 and v_ai_err * 100 / v_ai_total >= public.billing_setting_int('alert_ai_error_percent', 30) then
    v_alerts := v_alerts || jsonb_build_object('key', 'ai', 'level', 'warning', 'message', format('Errori AI al %s%% nell''ultima ora', v_ai_err * 100 / v_ai_total)); end if;
  if v_disp1 >= public.billing_setting_int('alert_dispatch_failures_per_hour', 5) then
    v_alerts := v_alerts || jsonb_build_object('key', 'dispatch', 'level', 'warning', 'message', format('%s consegne senza Rider nell''ultima ora', v_disp1)); end if;
  if public.billing_setting_bool('maintenance_mode', false) then
    v_alerts := v_alerts || jsonb_build_object('key', 'maintenance', 'level', 'info', 'message', 'Modalità manutenzione attiva'); end if;

  begin
    v_db := jsonb_build_object(
      'size_bytes', pg_database_size(current_database()),
      'tables', (select coalesce(jsonb_agg(jsonb_build_object('table', relname, 'rows', n_live_tup, 'dead', n_dead_tup, 'seq_scans', seq_scan, 'idx_scans', idx_scan) order by n_live_tup desc), '[]'::jsonb)
                   from (select * from pg_stat_user_tables where schemaname = 'public' order by n_live_tup desc limit 12) t));
  exception when others then
    v_db := jsonb_build_object('size_bytes', null, 'tables', '[]'::jsonb);
  end;

  return jsonb_build_object(
    'generated_at', now(),
    'alerts', v_alerts,
    'flags', (select jsonb_agg(jsonb_build_object('flag', f.flag, 'key', f.setting_key, 'kind', f.kind, 'label', f.label,
                'value', coalesce((select (value #>> '{}')::boolean from public.platform_settings s where s.key = f.setting_key and jsonb_typeof(value) = 'boolean'), false)))
              from public.feature_flag_keys() f),
    'errors', jsonb_build_object(
      'last_10min', v_err10,
      'last_24h', (select count(*) from public.system_error_log where created_at > now() - interval '24 hours'),
      'client_24h', (select count(*) from public.system_error_log where source = 'client' and created_at > now() - interval '24 hours'),
      'recent', (select coalesce(jsonb_agg(to_jsonb(e) - 'ip_hash' order by e.created_at desc), '[]'::jsonb)
                   from (select * from public.system_error_log order by created_at desc limit 30) e)),
    'webhooks', jsonb_build_object(
      'failed_24h', (select count(*) from public.stripe_events where processing_status = 'failed' and last_attempt_at > now() - interval '24 hours'),
      'failed_7d', (select count(*) from public.stripe_events where processing_status = 'failed' and last_attempt_at > now() - interval '7 days'),
      'stuck', (select count(*) from public.stripe_events where processing_status = 'processing' and last_attempt_at < now() - interval '15 minutes'),
      'processed_24h', (select count(*) from public.stripe_events where processing_status = 'processed' and created_at > now() - interval '24 hours'),
      'last_processed_at', (select max(processed_at) from public.stripe_events where processing_status = 'processed'),
      'recent_failed', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'event_type', event_type, 'error', error_message, 'attempts', attempts, 'at', last_attempt_at) order by last_attempt_at desc), '[]'::jsonb)
                          from (select * from public.stripe_events where processing_status in ('failed', 'processing') order by last_attempt_at desc limit 20) w)),
    'jobs', jsonb_build_object(
      'last_runs', (select coalesce(jsonb_agg(jsonb_build_object('type', job_type, 'status', status, 'completed_at', completed_at, 'started_at', started_at, 'error', last_error) order by job_type), '[]'::jsonb)
                      from (select distinct on (job_type) * from public.background_jobs order by job_type, created_at desc) j),
      'failed', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'type', job_type, 'attempts', attempts, 'max_attempts', max_attempts, 'error', last_error, 'at', coalesce(completed_at, created_at)) order by created_at desc), '[]'::jsonb)
                   from (select * from public.background_jobs where status = 'failed' order by created_at desc limit 20) f),
      'running', (select count(*) from public.background_jobs where status = 'running'),
      'stuck', (select count(*) from public.background_jobs where status = 'running' and started_at < now() - interval '30 minutes')),
    'email', jsonb_build_object(
      'pending', (select count(*) from public.email_outbox where status = 'pending'),
      'failed_24h', (select count(*) from public.email_outbox where status = 'failed' and created_at > now() - interval '24 hours'),
      'sent_24h', (select count(*) from public.email_outbox where status = 'sent' and sent_at > now() - interval '24 hours'),
      'oldest_pending_minutes', (select extract(epoch from now() - min(created_at))::int / 60 from public.email_outbox where status = 'pending')),
    'push', jsonb_build_object(
      'enabled', public.billing_setting_bool('push_enabled', true),
      'pending', (select count(*) from public.push_outbox where status in ('pending', 'sending')),
      'failed_24h', (select count(*) from public.push_outbox where status = 'failed' and created_at > now() - interval '24 hours'),
      'sent_24h', (select count(*) from public.push_outbox where status = 'sent' and created_at > now() - interval '24 hours'),
      'active_devices', (select count(*) from public.push_subscriptions where is_active)),
    'ai', jsonb_build_object(
      'enabled', public.billing_setting_bool('ai_enabled', true),
      'requests_1h', v_ai_total, 'errors_1h', v_ai_err,
      'fallback_1h', (select count(*) from public.ai_usage where status = 'fallback' and created_at > now() - interval '1 hour'),
      'last_ok_at', (select max(created_at) from public.ai_usage where status = 'ok')),
    'payments', jsonb_build_object(
      'failed_1h', v_pay1,
      'succeeded_24h', (select count(*) from public.orders where paid_at > now() - interval '24 hours'),
      'refunds_pending', (select count(*) from public.order_refunds where status in ('pending', 'processing'))),
    'dispatch', jsonb_build_object(
      'failed_1h', v_disp1,
      'open_alerts', (select count(*) from public.logistics_alerts where status = 'open'),
      'active_jobs', (select count(*) from public.delivery_jobs where status not in ('delivered', 'failed', 'cancelled'))),
    'privacy', jsonb_build_object(
      'deletions_scheduled', (select count(*) from public.account_deletion_requests where status = 'scheduled'),
      'deletions_blocked', (select count(*) from public.account_deletion_requests where status = 'blocked'),
      'deletions_anonymized', (select count(*) from public.account_deletion_requests where status = 'anonymized'),
      'exports_7d', (select count(*) from public.data_export_requests where requested_at > now() - interval '7 days')),
    'support', jsonb_build_object(
      'open', (select count(*) from public.support_tickets where status in ('open', 'in_progress', 'waiting_customer')),
      'urgent', (select count(*) from public.support_tickets where priority in ('urgent', 'high') and status in ('open', 'in_progress'))),
    'cleanup', jsonb_build_object(
      'last_retention', (select jsonb_build_object('status', status, 'at', completed_at, 'result', result) from public.background_jobs where job_type = 'retention_cleanup' order by created_at desc limit 1),
      'rider_locations_overdue', (select count(*) from public.rider_locations where recorded_at < now() - make_interval(hours => public.billing_setting_int('logistics_location_retention_hours', 24))),
      'rate_limit_rows', (select count(*) from public.rate_limits),
      'expired_ai_sessions', (select count(*) from public.ai_chat_sessions where expires_at < now())),
    'security', jsonb_build_object(
      'rate_limited_24h', (select count(*) from public.rate_limits where hits >= limit_value and window_start > now() - interval '24 hours'),
      'rate_limited_buckets', (select coalesce(jsonb_object_agg(bucket, n), '{}'::jsonb) from (select bucket, count(*) n from public.rate_limits
                                 where hits >= limit_value and window_start > now() - interval '24 hours' group by bucket) b),
      'gps_flood_24h', (select count(*) from public.security_audit_logs where action = 'rider_gps_flood' and created_at > now() - interval '24 hours'),
      'admin_sessions_24h', (select count(*) from public.security_audit_logs where action = 'admin_session' and created_at > now() - interval '24 hours')),
    'web_vitals', (select coalesce(jsonb_object_agg(metric, jsonb_build_object('p75', p75, 'samples', n)), '{}'::jsonb)
                     from (select metric, percentile_cont(0.75) within group (order by value) p75, count(*) n
                             from public.web_vitals where created_at > now() - interval '7 days' group by metric) w),
    'system_checks', (select coalesce(jsonb_agg(to_jsonb(c) order by key), '[]'::jsonb) from public.launch_checks c where source = 'system'),
    'db', v_db);
end $$;

create or replace function public.admin_audit_list(p_kind text default 'admin', p_limit int default 50, p_offset int default 0, p_action text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p_kind = 'security' then
    return jsonb_build_object(
      'total', (select count(*) from public.security_audit_logs where p_action is null or action = p_action),
      'rows', (select coalesce(jsonb_agg(jsonb_build_object('id', l.id, 'action', l.action, 'entity_type', l.entity_type, 'entity_id', l.entity_id,
                 'actor', coalesce(p.display_name, p.full_name, left(l.actor_user_id::text, 8)), 'actor_role', l.actor_role, 'metadata', l.metadata,
                 'ua', l.user_agent_summary, 'created_at', l.created_at) order by l.created_at desc), '[]'::jsonb)
               from (select * from public.security_audit_logs where p_action is null or action = p_action order by created_at desc
                      limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)) l left join public.profiles p on p.id = l.actor_user_id));
  end if;
  return jsonb_build_object(
    'total', (select count(*) from public.admin_audit_logs where p_action is null or action = p_action),
    'rows', (select coalesce(jsonb_agg(jsonb_build_object('id', l.id, 'action', l.action, 'entity_type', l.entity_type, 'entity_id', l.entity_id,
               'actor', coalesce(p.display_name, p.full_name, left(l.admin_id::text, 8)), 'actor_role', l.actor_role, 'metadata', l.details,
               'ua', l.user_agent_summary, 'created_at', l.created_at) order by l.created_at desc), '[]'::jsonb)
             from (select * from public.admin_audit_logs where p_action is null or action = p_action order by created_at desc
                    limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)) l left join public.profiles p on p.id = l.admin_id));
end $$;

create or replace function public.admin_privacy_requests()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  return jsonb_build_object(
    'deletions', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'user_id', d.user_id, 'name', coalesce(p.display_name, p.full_name),
                    'email_masked', case when p.email is null then null else left(p.email, 2) || '•••@' || split_part(p.email, '@', 2) end,
                    'status', d.status, 'requested_at', d.requested_at, 'scheduled_for', d.scheduled_for, 'blocked_reason', d.blocked_reason, 'completed_at', d.completed_at)
                    order by d.requested_at desc), '[]'::jsonb)
                  from (select * from public.account_deletion_requests order by requested_at desc limit 100) d left join public.profiles p on p.id = d.user_id),
    'exports', (select coalesce(jsonb_agg(jsonb_build_object('id', e.id, 'user_id', e.user_id, 'status', e.status, 'requested_at', e.requested_at, 'size_bytes', e.size_bytes)
                    order by e.requested_at desc), '[]'::jsonb)
                  from (select * from public.data_export_requests order by requested_at desc limit 100) e));
end $$;

/** Sblocco di una cancellazione bloccata (dopo trasferimento del locale o revisione Rider): torna in coda. */
create or replace function public.admin_deletion_action(p_id uuid, p_action text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p_action = 'retry' then
    update public.account_deletion_requests set status = 'scheduled', scheduled_for = now(), blocked_reason = null where id = p_id and status = 'blocked';
  elsif p_action = 'cancel' then
    update public.account_deletion_requests set status = 'cancelled', cancelled_at = now() where id = p_id and status in ('scheduled', 'blocked');
  else
    raise exception 'Azione non valida' using errcode = '22023';
  end if;
  perform public.audit_admin('deletion_' || p_action, 'account_deletion', p_id::text, '{}'::jsonb);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  18. LAUNCH CHECKLIST + READINESS TARANTO
-- ────────────────────────────────────────────────────────────────────
/** Readiness di un mercato (default provincia di Taranto): qualità dati reale, niente locali demo. */
create or replace function public.admin_city_readiness(p_province_code text default 'TA')
returns jsonb language plpgsql volatile security definer set search_path = public as $$
declare
  v_total int; v_coords int; v_hours int; v_cats int; v_contact int; v_source int; v_verified int; v_claimed int; v_menu int; v_cities int;
  v_seo int; v_city_pages int; v_min int := public.billing_setting_int('seo_min_restaurants_category_city', 2);
  v_checks jsonb := '[]'::jsonb; v_crit_fail int; v_pass int; v_n int; v_score int;
  pct numeric;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  create temporary table if not exists _rr (id uuid primary key, city_id uuid) on commit drop;
  truncate _rr;
  insert into _rr select r.id, r.city_id from public.restaurants r join public.provinces p on p.id = r.province_id
   where p.code = upper(p_province_code) and r.is_active and not r.is_demo and not r.is_permanently_closed;
  select count(*) into v_total from _rr;
  select count(*) into v_coords from _rr x join public.restaurants r on r.id = x.id where r.latitude is not null and r.longitude is not null;
  select count(*) into v_hours from _rr x where exists (select 1 from public.restaurant_hours h where h.restaurant_id = x.id);
  select count(*) into v_cats from _rr x where exists (select 1 from public.restaurant_categories c where c.restaurant_id = x.id);
  select count(*) into v_contact from _rr x join public.restaurants r on r.id = x.id where coalesce(r.phone, r.whatsapp, r.website, r.email) is not null;
  select count(*) into v_source from _rr x join public.restaurants r on r.id = x.id
   where r.source_name is not null or exists (select 1 from public.restaurant_sources s where s.restaurant_id = x.id);
  select count(*) into v_verified from _rr x join public.restaurants r on r.id = x.id where r.data_status in ('verified', 'claimed', 'partially_verified') or r.is_verified;
  select count(*) into v_claimed from _rr x join public.restaurants r on r.id = x.id where r.owner_id is not null;
  select count(*) into v_menu from _rr x where exists (select 1 from public.menus m where m.restaurant_id = x.id and m.is_active);
  select count(distinct city_id) into v_cities from _rr;
  select count(*) into v_city_pages from (select city_id from _rr group by city_id) c;
  select count(*) into v_seo from (select rc.category_id, x.city_id from _rr x join public.restaurant_categories rc on rc.restaurant_id = x.id
                                    group by 1, 2 having count(*) >= v_min) s;

  pct := case when v_total > 0 then 100.0 / v_total else 0 end;
  v_checks := jsonb_build_array(
    jsonb_build_object('key', 'database', 'label', 'Database popolato (locali reali attivi)', 'critical', true, 'value', v_total,
      'status', case when v_total >= 20 then 'pass' when v_total >= 5 then 'warn' else 'fail' end, 'target', '≥ 20 locali reali'),
    jsonb_build_object('key', 'coordinates', 'label', 'Coordinate (copertura mappa)', 'critical', true, 'value', round(v_coords * pct),
      'status', case when v_total = 0 then 'fail' when v_coords * pct >= 95 then 'pass' when v_coords * pct >= 80 then 'warn' else 'fail' end, 'target', '≥ 95%'),
    jsonb_build_object('key', 'hours', 'label', 'Orari di apertura', 'critical', false, 'value', round(v_hours * pct),
      'status', case when v_total = 0 then 'fail' when v_hours * pct >= 80 then 'pass' when v_hours * pct >= 50 then 'warn' else 'fail' end, 'target', '≥ 80%'),
    jsonb_build_object('key', 'categories', 'label', 'Categorie assegnate', 'critical', true, 'value', round(v_cats * pct),
      'status', case when v_total = 0 then 'fail' when v_cats * pct >= 95 then 'pass' when v_cats * pct >= 80 then 'warn' else 'fail' end, 'target', '≥ 95%'),
    jsonb_build_object('key', 'contacts', 'label', 'Contatti (telefono/sito/WhatsApp)', 'critical', false, 'value', round(v_contact * pct),
      'status', case when v_total = 0 then 'fail' when v_contact * pct >= 80 then 'pass' when v_contact * pct >= 50 then 'warn' else 'fail' end, 'target', '≥ 80%'),
    jsonb_build_object('key', 'sources', 'label', 'Fonti dei dati tracciate', 'critical', true, 'value', round(v_source * pct),
      'status', case when v_total = 0 then 'fail' when v_source * pct >= 90 then 'pass' when v_source * pct >= 70 then 'warn' else 'fail' end, 'target', '≥ 90%'),
    jsonb_build_object('key', 'verified', 'label', 'Dati verificati o rivendicati', 'critical', false, 'value', round(v_verified * pct),
      'status', case when v_total = 0 then 'fail' when v_verified * pct >= 50 then 'pass' when v_verified * pct >= 20 then 'warn' else 'fail' end, 'target', '≥ 50%'),
    jsonb_build_object('key', 'menus', 'label', 'Locali con menu', 'critical', false, 'value', round(v_menu * pct),
      'status', case when v_total = 0 then 'fail' when v_menu * pct >= 40 then 'pass' when v_menu * pct >= 15 then 'warn' else 'fail' end, 'target', '≥ 40%'),
    jsonb_build_object('key', 'seo_pages', 'label', format('Pagine SEO categoria×comune (≥ %s locali)', v_min), 'critical', false, 'value', v_seo,
      'status', case when v_seo >= 10 then 'pass' when v_seo >= 3 then 'warn' else 'fail' end, 'target', '≥ 10 pagine'),
    jsonb_build_object('key', 'city_pages', 'label', 'Comuni coperti', 'critical', false, 'value', v_cities,
      'status', case when v_cities >= 5 then 'pass' when v_cities >= 1 then 'warn' else 'fail' end, 'target', '≥ 5 comuni'),
    jsonb_build_object('key', 'claim_flow', 'label', 'Flusso rivendicazione e piani business', 'critical', true,
      'value', (select count(*) from public.subscription_plans where is_active),
      'status', case when (select count(*) from public.subscription_plans where is_active) >= 2 then 'pass' else 'fail' end, 'target', 'piani attivi'),
    jsonb_build_object('key', 'business_pricing', 'label', 'Prezzi business collegati a Stripe', 'critical', false,
      'value', (select count(*) from public.subscription_plans where is_active and monthly_price > 0 and stripe_monthly_price_id is not null),
      'status', case when exists (select 1 from public.subscription_plans where is_active and monthly_price > 0 and stripe_monthly_price_id is not null) then 'pass' else 'warn' end, 'target', 'price ID Stripe'),
    jsonb_build_object('key', 'support', 'label', 'Supporto (email e pagina /support)', 'critical', true, 'value', public.billing_setting_text('support_email', null),
      'status', case when public.billing_setting_text('support_email', null) is not null then 'pass' else 'fail' end, 'target', 'email impostata'),
    jsonb_build_object('key', 'legal', 'label', 'Privacy, cookie e termini (revisione legale)', 'critical', true,
      'value', (select count(*) from public.legal_document_versions where is_current and not is_draft),
      'status', case when (select count(*) from public.legal_document_versions where is_current and not is_draft and document_type in ('privacy', 'cookie', 'terms')) = 3 then 'pass'
                     when (select count(*) from public.legal_document_versions where is_current and document_type in ('privacy', 'cookie', 'terms')) = 3 then 'warn' else 'fail' end,
      'target', 'documenti non in bozza'),
    jsonb_build_object('key', 'analytics', 'label', 'Analytics (eventi ultimi 7 giorni)', 'critical', false,
      'value', (select count(*) from public.analytics_events where created_at > now() - interval '7 days'),
      'status', case when exists (select 1 from public.analytics_events where created_at > now() - interval '7 days') then 'pass' else 'warn' end, 'target', 'eventi ricevuti'),
    jsonb_build_object('key', 'monitoring', 'label', 'Monitoring (health check recente)', 'critical', true,
      'value', (select last_checked_at from public.launch_checks where key = 'mon_health'),
      'status', case when exists (select 1 from public.launch_checks where key = 'mon_health' and status = 'pass' and last_checked_at > now() - interval '2 hours') then 'pass' else 'fail' end,
      'target', 'cron di sistema attivo'),
    jsonb_build_object('key', 'backup', 'label', 'Backup verificato', 'critical', true, 'value', (select notes from public.launch_checks where key = 'backup_enabled'),
      'status', coalesce((select case status when 'pass' then 'pass' when 'fail' then 'fail' else 'pending' end from public.launch_checks where key = 'backup_enabled'), 'pending'),
      'target', 'conferma manuale')
  );
  select count(*) filter (where (c ->> 'critical')::boolean and c ->> 'status' <> 'pass'), count(*) filter (where c ->> 'status' = 'pass'), count(*)
    into v_crit_fail, v_pass, v_n from jsonb_array_elements(v_checks) c;
  v_score := round(100.0 * v_pass / greatest(v_n, 1));
  if v_crit_fail > 0 then v_score := least(v_score, 99); end if;
  return jsonb_build_object('province', upper(p_province_code), 'generated_at', now(), 'restaurants', v_total, 'score', v_score,
    'ready', v_crit_fail = 0, 'critical_failing', v_crit_fail, 'checks', v_checks);
end $$;

/**
 * Launch checklist: controlli automatici (database), di sistema (registrati dal backend: env, health, HTTPS…) e manuali (Admin).
 * Stato suggerito: BLOCKED (un controllo critico fallito) · NOT_READY · READY_FOR_BETA · READY_FOR_PRODUCTION.
 * Nessuna configurazione viene modificata automaticamente.
 */
create or replace function public.admin_launch_checklist()
returns jsonb language plpgsql volatile security definer set search_path = public as $$
declare
  v jsonb := '[]'::jsonb;
  v_rls_off int; v_anon_admin int; v_demo_visible boolean; v_demo_rest int; v_cons jsonb; v_city jsonb;
  v_status text; v_score int; v_beta_block int; v_beta_open int; v_prod_open int; v_pass int; v_total int;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select count(*) into v_rls_off from pg_class c join pg_namespace n on n.oid = c.relnamespace
   where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity;
  select count(*) into v_anon_admin from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public' and p.prosecdef and (p.proname like 'admin\_%' or p.proname in ('marketplace_stats', 'ai_admin_stats', 'retention_cleanup', 'process_account_deletions'))
     and has_function_privilege('anon', p.oid, 'execute');
  v_demo_visible := public.billing_setting_bool('show_demo_data', true);
  select count(*) into v_demo_rest from public.restaurants where is_demo and is_active;
  v_cons := public.db_consistency_report();
  v_city := public.admin_city_readiness('TA');

  -- Helper locale: (key, sezione, titolo, critico beta, critico produzione, tipo, stato, dettaglio)
  v := jsonb_build_array(
    -- SECURITY
    jsonb_build_object('key', 'sec_rls', 'section', 'SECURITY', 'title', 'RLS attiva su tutte le tabelle', 'crit_beta', true, 'crit_prod', true, 'kind', 'auto',
      'status', case when v_rls_off = 0 then 'pass' else 'fail' end, 'detail', format('%s tabelle senza RLS', v_rls_off)),
    jsonb_build_object('key', 'sec_admin_rpc', 'section', 'SECURITY', 'title', 'Funzioni Admin non eseguibili da anonimi', 'crit_beta', true, 'crit_prod', true, 'kind', 'auto',
      'status', case when v_anon_admin = 0 then 'pass' else 'fail' end, 'detail', format('%s funzioni esposte', v_anon_admin)),
    jsonb_build_object('key', 'env_secrets', 'section', 'SECURITY', 'title', 'Secret server configurati (nessun valore mostrato)', 'crit_beta', true, 'crit_prod', true, 'kind', 'system'),
    jsonb_build_object('key', 'env_app_env', 'section', 'SECURITY', 'title', 'APP_ENV=production e chiavi coerenti con l''ambiente', 'crit_beta', false, 'crit_prod', true, 'kind', 'system'),
    jsonb_build_object('key', 'sec_headers', 'section', 'SECURITY', 'title', 'Security headers e CSP verificati sul dominio (securityheaders.com)', 'crit_beta', false, 'crit_prod', true, 'kind', 'manual'),
    jsonb_build_object('key', 'sec_auth_captcha', 'section', 'SECURITY', 'title', 'Supabase Auth: rate limit, conferma email, Turnstile/CAPTCHA attivi', 'crit_beta', false, 'crit_prod', true, 'kind', 'manual'),
    -- PRIVACY
    jsonb_build_object('key', 'priv_documents', 'section', 'PRIVACY', 'title', 'Informativa privacy e cookie pubblicate', 'crit_beta', true, 'crit_prod', true, 'kind', 'auto',
      'status', case when (select count(*) from public.legal_document_versions where is_current and document_type in ('privacy', 'cookie')) = 2 then 'pass' else 'fail' end,
      'detail', 'Template presenti: vanno completati con il consulente'),
    jsonb_build_object('key', 'priv_retention_job', 'section', 'PRIVACY', 'title', 'Job di retention eseguito nelle ultime 48 ore', 'crit_beta', false, 'crit_prod', true, 'kind', 'auto',
      'status', case when exists (select 1 from public.background_jobs where job_type = 'retention_cleanup' and status = 'completed' and completed_at > now() - interval '48 hours') then 'pass' else 'pending' end),
    jsonb_build_object('key', 'priv_dpa', 'section', 'PRIVACY', 'title', 'Nomine responsabili (DPA) con Supabase, Netlify, Stripe, provider AI/email; registro trattamenti', 'crit_beta', false, 'crit_prod', true, 'kind', 'manual'),
    -- LEGAL
    jsonb_build_object('key', 'legal_review', 'section', 'LEGAL', 'title', 'Testi legali revisionati da un consulente (non più bozza)', 'crit_beta', false, 'crit_prod', true, 'kind', 'auto',
      'status', case when not exists (select 1 from public.legal_document_versions where is_current and is_draft and document_type in ('privacy', 'cookie', 'terms', 'business_terms')) then 'pass' else 'pending' end,
      'detail', format('%s documenti ancora in bozza', (select count(*) from public.legal_document_versions where is_current and is_draft))),
    jsonb_build_object('key', 'legal_company', 'section', 'LEGAL', 'title', 'Ragione sociale, P.IVA, sede e contatti nel footer', 'crit_beta', false, 'crit_prod', true, 'kind', 'auto',
      'status', case when public.billing_setting_text('legal_company_name', null) is not null and public.billing_setting_text('legal_vat_number', null) is not null
                          and public.billing_setting_text('legal_address', null) is not null then 'pass' else 'pending' end),
    -- DATA
    jsonb_build_object('key', 'data_demo_hidden', 'section', 'DATA', 'title', 'Dati DEMO nascosti/eliminati', 'crit_beta', false, 'crit_prod', true, 'kind', 'auto',
      'status', case when not v_demo_visible or v_demo_rest = 0 then 'pass' else 'fail' end,
      'detail', format('show_demo_data=%s, locali demo attivi=%s', v_demo_visible, v_demo_rest)),
    jsonb_build_object('key', 'data_consistency', 'section', 'DATA', 'title', 'Report di consistenza senza anomalie gravi', 'crit_beta', false, 'crit_prod', false, 'kind', 'auto',
      'status', case when (v_cons ->> 'total_issues')::int = 0 then 'pass' else 'warn' end, 'detail', format('%s anomalie', v_cons ->> 'total_issues')),
    jsonb_build_object('key', 'data_taranto', 'section', 'DATA', 'title', 'Taranto Launch Readiness', 'crit_beta', false, 'crit_prod', true, 'kind', 'auto',
      'status', case when (v_city ->> 'ready')::boolean then 'pass' else 'pending' end, 'detail', format('score %s%%, %s locali reali', v_city ->> 'score', v_city ->> 'restaurants')),
    -- SEO
    jsonb_build_object('key', 'env_sitemap', 'section', 'SEO', 'title', 'sitemap.xml e robots.txt raggiungibili sul dominio', 'crit_beta', false, 'crit_prod', true, 'kind', 'system'),
    jsonb_build_object('key', 'seo_search_console', 'section', 'SEO', 'title', 'Dominio verificato in Google Search Console e sitemap inviata', 'crit_beta', false, 'crit_prod', false, 'kind', 'manual'),
    -- PERFORMANCE
    jsonb_build_object('key', 'perf_web_vitals', 'section', 'PERFORMANCE', 'title', 'Core Web Vitals p75 nei target (LCP < 2,5 s, INP < 200 ms, CLS < 0,1)', 'crit_beta', false, 'crit_prod', false, 'kind', 'auto',
      'status', case
        when (select count(*) from public.web_vitals where created_at > now() - interval '7 days') < 50 then 'pending'
        when coalesce((select percentile_cont(0.75) within group (order by value) from public.web_vitals where metric = 'LCP' and created_at > now() - interval '7 days'), 0) < 2500
         and coalesce((select percentile_cont(0.75) within group (order by value) from public.web_vitals where metric = 'CLS' and created_at > now() - interval '7 days'), 0) < 0.1
         and coalesce((select percentile_cont(0.75) within group (order by value) from public.web_vitals where metric = 'INP' and created_at > now() - interval '7 days'), 0) < 200 then 'pass'
        else 'warn' end, 'detail', 'Misure reali degli utenti che hanno accettato i cookie analytics'),
    -- PAYMENTS
    jsonb_build_object('key', 'env_stripe', 'section', 'PAYMENTS', 'title', 'Stripe configurato (chiave, webhook secret, modalità coerente)', 'crit_beta', false, 'crit_prod', true, 'kind', 'system'),
    jsonb_build_object('key', 'pay_webhook', 'section', 'PAYMENTS', 'title', 'Webhook Stripe senza errori nelle ultime 24 ore', 'crit_beta', true, 'crit_prod', true, 'kind', 'auto',
      'status', case when exists (select 1 from public.stripe_events where processing_status = 'failed' and last_attempt_at > now() - interval '24 hours') then 'fail'
                     when exists (select 1 from public.stripe_events where processing_status = 'processed') then 'pass' else 'pending' end,
      'detail', 'Serve almeno un evento elaborato (es. pagamento di prova)'),
    jsonb_build_object('key', 'pay_live_test', 'section', 'PAYMENTS', 'title', 'Pagamento reale di prova + rimborso eseguiti in LIVE', 'crit_beta', false, 'crit_prod', true, 'kind', 'manual'),
    -- ORDERS / DELIVERY / RIDER
    jsonb_build_object('key', 'orders_cron', 'section', 'ORDERS', 'title', 'Cron ordini attivo (ultima ora)', 'crit_beta', false, 'crit_prod', true, 'kind', 'auto',
      'status', case when not public.billing_setting_bool('orders_enabled', true) then 'na'
                     when exists (select 1 from public.background_jobs where job_type = 'orders-cron' and status = 'completed' and completed_at > now() - interval '1 hour') then 'pass' else 'pending' end),
    jsonb_build_object('key', 'delivery_zones', 'section', 'DELIVERY', 'title', 'Zone servite configurate', 'crit_beta', false, 'crit_prod', false, 'kind', 'auto',
      'status', case when not public.billing_setting_bool('logistics_enabled', true) then 'na'
                     when exists (select 1 from public.delivery_service_zones where is_active) then 'pass' else 'warn' end),
    jsonb_build_object('key', 'rider_real', 'section', 'RIDER', 'title', 'Almeno un Rider reale approvato (se consegne AsiaFood attive)', 'crit_beta', false, 'crit_prod', false, 'kind', 'auto',
      'status', case when not exists (select 1 from public.restaurant_order_settings where asiafood_delivery_enabled) then 'na'
                     when exists (select 1 from public.rider_profiles where status in ('approved', 'active') and not is_demo) then 'pass' else 'warn' end),
    -- AI / CRM
    jsonb_build_object('key', 'env_ai', 'section', 'AI', 'title', 'Provider AI configurato o disattivato esplicitamente', 'crit_beta', false, 'crit_prod', false, 'kind', 'system'),
    jsonb_build_object('key', 'crm_module', 'section', 'CRM', 'title', 'CRM / Sales Agent', 'crit_beta', false, 'crit_prod', false, 'kind', 'auto',
      'status', 'na', 'detail', 'Modulo non presente in questa versione: nessuna superficie da proteggere'),
    -- EMAIL / PUSH
    jsonb_build_object('key', 'email_dns', 'section', 'EMAIL', 'title', 'Provider email + SPF, DKIM, DMARC sul dominio mittente', 'crit_beta', false, 'crit_prod', true, 'kind', 'manual'),
    jsonb_build_object('key', 'email_outbox', 'section', 'EMAIL', 'title', 'Nessuna email fallita nelle ultime 24 ore', 'crit_beta', false, 'crit_prod', false, 'kind', 'auto',
      'status', case when exists (select 1 from public.email_outbox where status = 'failed' and created_at > now() - interval '24 hours') then 'warn' else 'pass' end),
    jsonb_build_object('key', 'env_push', 'section', 'PUSH', 'title', 'Chiavi VAPID configurate', 'crit_beta', false, 'crit_prod', false, 'kind', 'system'),
    -- ANALYTICS
    jsonb_build_object('key', 'analytics_consent', 'section', 'ANALYTICS', 'title', 'Banner cookie con consensi registrati', 'crit_beta', true, 'crit_prod', true, 'kind', 'auto',
      'status', case when exists (select 1 from public.user_consents) then 'pass' else 'pending' end, 'detail', 'Almeno una scelta registrata dal banner'),
    -- BACKUP
    jsonb_build_object('key', 'backup_enabled', 'section', 'BACKUP', 'title', 'Backup giornalieri Supabase attivi (piano Pro o superiore / PITR)', 'crit_beta', true, 'crit_prod', true, 'kind', 'manual'),
    jsonb_build_object('key', 'backup_restore_test', 'section', 'BACKUP', 'title', 'Restore testato su staging (data e durata annotate)', 'crit_beta', false, 'crit_prod', true, 'kind', 'manual'),
    -- MONITORING
    jsonb_build_object('key', 'mon_health', 'section', 'MONITORING', 'title', 'Health check del backend OK (ultime 2 ore)', 'crit_beta', true, 'crit_prod', true, 'kind', 'system'),
    jsonb_build_object('key', 'mon_uptime', 'section', 'MONITORING', 'title', 'Uptime monitor esterno su home, /api/health e checkout', 'crit_beta', false, 'crit_prod', true, 'kind', 'manual'),
    jsonb_build_object('key', 'env_error_tracking', 'section', 'MONITORING', 'title', 'Error tracking (Sentry o log errori interno)', 'crit_beta', false, 'crit_prod', false, 'kind', 'system'),
    jsonb_build_object('key', 'env_domain', 'section', 'MONITORING', 'title', 'Dominio personalizzato in HTTPS', 'crit_beta', false, 'crit_prod', true, 'kind', 'system'),
    -- SUPPORT
    jsonb_build_object('key', 'support_contact', 'section', 'SUPPORT', 'title', 'Email di supporto impostata', 'crit_beta', true, 'crit_prod', true, 'kind', 'auto',
      'status', case when public.billing_setting_text('support_email', null) is not null then 'pass' else 'fail' end),
    jsonb_build_object('key', 'support_backlog', 'section', 'SUPPORT', 'title', 'Nessun ticket urgente aperto da oltre 24 ore', 'crit_beta', false, 'crit_prod', false, 'kind', 'auto',
      'status', case when exists (select 1 from public.support_tickets where priority = 'urgent' and status in ('open', 'in_progress') and created_at < now() - interval '24 hours') then 'warn' else 'pass' end)
  );

  -- Stato di sistema/manuale dalla tabella launch_checks (i dati di sistema scadono dopo 2 ore)
  select jsonb_agg(case when e ->> 'kind' in ('system', 'manual') then
      e || jsonb_build_object(
        'status', coalesce((select case when c.source = 'system' and c.last_checked_at < now() - interval '2 hours' then 'pending' else c.status end
                              from public.launch_checks c where c.key = e ->> 'key'), 'pending'),
        'detail', coalesce((select c.notes from public.launch_checks c where c.key = e ->> 'key'), e ->> 'detail',
                           case when e ->> 'kind' = 'manual' then 'Da confermare manualmente' else 'In attesa del controllo automatico (cron di sistema)' end),
        'last_checked_at', (select c.last_checked_at from public.launch_checks c where c.key = e ->> 'key'))
    else e || jsonb_build_object('last_checked_at', now()) end)
    into v from jsonb_array_elements(v) e;

  select count(*) filter (where (x2 ->> 'crit_beta')::boolean and x2 ->> 'status' = 'fail'),
         count(*) filter (where (x2 ->> 'crit_beta')::boolean and x2 ->> 'status' not in ('pass', 'na')),
         count(*) filter (where ((x2 ->> 'crit_beta')::boolean or (x2 ->> 'crit_prod')::boolean) and x2 ->> 'status' not in ('pass', 'na')),
         count(*) filter (where x2 ->> 'status' = 'pass'),
         count(*) filter (where x2 ->> 'status' <> 'na')
    into v_beta_block, v_beta_open, v_prod_open, v_pass, v_total from jsonb_array_elements(v) x2;
  v_status := case when v_beta_block > 0 then 'BLOCKED' when v_beta_open > 0 then 'NOT_READY' when v_prod_open > 0 then 'READY_FOR_BETA' else 'READY_FOR_PRODUCTION' end;
  v_score := round(100.0 * v_pass / greatest(v_total, 1));
  if v_prod_open > 0 then v_score := least(v_score, 99); end if;
  return jsonb_build_object('status', v_status, 'score', v_score, 'generated_at', now(),
    'blocking', (select coalesce(jsonb_agg(jsonb_build_object('key', x3 ->> 'key', 'title', x3 ->> 'title', 'status', x3 ->> 'status', 'stage',
                   case when (x3 ->> 'crit_beta')::boolean then 'beta' else 'production' end)), '[]'::jsonb)
                   from jsonb_array_elements(v) x3 where ((x3 ->> 'crit_beta')::boolean or (x3 ->> 'crit_prod')::boolean) and x3 ->> 'status' not in ('pass', 'na')),
    'checks', v, 'city', v_city);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  19. VINCOLI (NOT VALID + validazione: i dati esistenti non bloccano il deploy, i nuovi sono controllati)
-- ────────────────────────────────────────────────────────────────────
alter table public.order_refunds add column if not exists currency char(3) not null default 'EUR';
alter table public.rider_earnings add column if not exists currency char(3) not null default 'EUR';

do $$
declare x record;
begin
  for x in select * from (values
      ('cities', 'cities_lat_lng_valid', 'check ((latitude is null or latitude between -90 and 90) and (longitude is null or longitude between -180 and 180))'),
      ('delivery_jobs', 'delivery_jobs_coords_valid', 'check ((pickup_latitude is null or pickup_latitude between -90 and 90) and (pickup_longitude is null or pickup_longitude between -180 and 180) and (delivery_latitude is null or delivery_latitude between -90 and 90) and (delivery_longitude is null or delivery_longitude between -180 and 180))'),
      ('rider_availability', 'rider_availability_coords_valid', 'check ((last_latitude is null or last_latitude between -90 and 90) and (last_longitude is null or last_longitude between -180 and 180))'),
      ('orders', 'orders_money_valid', 'check (commission_percent between 0 and 100 and commission_fixed >= 0 and platform_fee >= 0 and coalesce(payment_processing_fee, 0) >= 0 and coalesce(tax_total, 0) >= 0)'),
      ('orders', 'orders_currency_valid', 'check (currency ~ ''^[A-Z]{3}$'')'),
      ('order_refunds', 'order_refunds_currency_valid', 'check (currency ~ ''^[A-Z]{3}$'')'),
      ('rider_earnings', 'rider_earnings_money_valid', 'check (base_fee >= 0 and distance_fee >= 0 and bonus >= 0 and total >= 0 and currency ~ ''^[A-Z]{3}$'')'),
      ('billing_invoices', 'billing_invoices_amounts_valid', 'check (coalesce(amount_due_cents, 0) >= 0 and coalesce(amount_paid_cents, 0) >= 0)'),
      ('menus', 'menus_price_valid', 'check (price is null or price >= 0)'),
      ('order_item_options', 'order_item_options_price_valid', 'check (price_snapshot >= 0)'),
      ('restaurants', 'restaurants_prices_valid', 'check ((average_price is null or average_price >= 0) and (ayce_lunch_price is null or ayce_lunch_price >= 0) and (ayce_dinner_price is null or ayce_dinner_price >= 0) and (ayce_weekend_price is null or ayce_weekend_price >= 0))'),
      ('rider_profiles', 'rider_profiles_stats_valid', 'check ((rating_internal is null or rating_internal between 0 and 5) and total_deliveries >= 0)'),
      ('review_versions', 'review_versions_rating_valid', 'check (previous_rating is null or previous_rating between 1 and 5)'),
      ('subscriptions', 'subscriptions_currency_valid', 'check (currency is null or currency ~ ''^[A-Z]{3}$'')'),
      ('restaurant_order_settings', 'order_settings_delivery_fee_valid', 'check (delivery_fee >= 0 and minimum_order_amount >= 0)')
    ) as v(tbl, name, def) loop
    if not exists (select 1 from pg_constraint where conname = x.name) then
      execute format('alter table public.%I add constraint %I %s not valid', x.tbl, x.name, x.def);
      begin
        execute format('alter table public.%I validate constraint %I', x.tbl, x.name);
      exception when others then
        raise notice 'Vincolo % non validato sui dati esistenti (resta attivo sulle nuove scritture): %', x.name, sqlerrm;
      end;
    end if;
  end loop;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  20. INDICI (FK usate da cancellazioni/filtri, query critiche)
-- ────────────────────────────────────────────────────────────────────
create index if not exists menu_categories_restaurant_idx on public.menu_categories(restaurant_id, sort_order);
create index if not exists menu_item_variants_restaurant_idx on public.menu_item_variants(restaurant_id);
create index if not exists menu_item_addons_restaurant_idx on public.menu_item_addons(restaurant_id);
create index if not exists menu_option_groups_restaurant_idx on public.menu_option_groups(restaurant_id);
create index if not exists menu_options_restaurant_idx on public.menu_options(restaurant_id);
create index if not exists review_responses_restaurant_idx on public.review_responses(restaurant_id);
create index if not exists rewards_restaurant_idx on public.rewards(restaurant_id);
create index if not exists notifications_restaurant_idx on public.notifications(restaurant_id) where restaurant_id is not null;
create index if not exists analytics_events_user_idx on public.analytics_events(user_id) where user_id is not null;
create index if not exists push_outbox_user_idx on public.push_outbox(user_id);
create index if not exists order_issues_user_idx on public.order_issues(user_id) where user_id is not null;
create index if not exists delivery_ratings_user_idx on public.delivery_ratings(user_id);
create index if not exists plan_upgrade_requests_user_idx on public.plan_upgrade_requests(user_id);
create index if not exists restaurant_change_requests_user_idx on public.restaurant_change_requests(user_id);
create index if not exists review_reports_reporter_idx on public.review_reports(reporter_user_id);
create index if not exists subscriptions_user_idx on public.subscriptions(user_id) where user_id is not null;
create index if not exists coupon_redemptions_user_idx on public.coupon_redemptions(user_id) where user_id is not null;
create index if not exists logistics_alerts_job_idx on public.logistics_alerts(delivery_job_id) where delivery_job_id is not null;
create index if not exists carts_restaurant_idx on public.carts(restaurant_id);
create index if not exists restaurant_reports_user_idx on public.restaurant_reports(user_id) where user_id is not null;
create index if not exists restaurant_claim_messages_author_idx on public.restaurant_claim_messages(author_id);
create index if not exists reward_redemptions_reward_idx on public.reward_redemptions(reward_id);
create index if not exists campaign_deliveries_notification_idx on public.campaign_deliveries(notification_id) where notification_id is not null;
create index if not exists orders_restaurant_created_idx on public.orders(restaurant_id, created_at desc);
create index if not exists orders_user_created_idx on public.orders(user_id, created_at desc) where user_id is not null;
create index if not exists reviews_restaurant_published_idx on public.reviews(restaurant_id, published_at desc) where status = 'published';
create index if not exists restaurants_slug_lower_idx on public.restaurants(lower(slug));
create index if not exists stripe_events_status_idx on public.stripe_events(processing_status, last_attempt_at desc) where processing_status in ('failed', 'processing');
create index if not exists ai_usage_created_status_idx on public.ai_usage(created_at desc, status);

-- ────────────────────────────────────────────────────────────────────
--  21. GRANT MINIMI SULLE FUNZIONI
--  Postgres concede EXECUTE a PUBLIC per default (e Supabase anche ad anon): "revoke from anon" non basta.
--  - funzioni "solo backend" (assert_service) → solo service_role
--  - funzioni Admin / "Admin o backend" → authenticated (+ controllo is_admin interno) e service_role, mai anon
-- ────────────────────────────────────────────────────────────────────
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig, p.proname, p.prosrc
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prorettype <> 'trigger'::regtype and p.prokind = 'f'
  loop
    if f.prosrc like '%perform public.assert_service()%' then
      execute format('revoke execute on function %s from public, anon, authenticated', f.sig);
      execute format('grant execute on function %s to service_role', f.sig);
    elsif f.proname like 'admin\_%' or f.prosrc ~ 'auth\.uid\(\) is not null and not public\.is_admin\(\)'
          or f.proname in ('db_consistency_report', 'marketplace_stats', 'ai_admin_stats', 'campaign_stats', 'push_campaign_stats', 'logistics_stats') then
      execute format('revoke execute on function %s from public, anon', f.sig);
      execute format('grant execute on function %s to authenticated, service_role', f.sig);
    end if;
  end loop;
end $$;

-- Funzioni interne senza chiamate dirette dal client
revoke execute on function public.account_anonymize(uuid), public.privacy_export_data(uuid), public.my_consents_for(uuid, text),
  public.rate_limit_hit(text, text, int, int), public.audit_security(text, text, text, jsonb, uuid), public.sys_ip_hash(text),
  public.sys_request_header(text), public.sys_ua_summary(text) from public, anon, authenticated;
grant execute on function public.account_anonymize(uuid), public.privacy_export_data(uuid), public.rate_limit_hit(text, text, int, int)
  to service_role;
revoke execute on function public.audit_admin(text, text, text, jsonb) from public, anon, authenticated;
-- Utente autenticato
revoke execute on function public.privacy_export(), public.request_account_deletion(text), public.cancel_account_deletion(),
  public.my_privacy_status(), public.my_consents(), public.my_support_tickets(), public.beta_invite_redeem(text), public.record_admin_session() from public, anon;
grant execute on function public.privacy_export(), public.request_account_deletion(text), public.cancel_account_deletion(),
  public.my_privacy_status(), public.my_consents(), public.my_support_tickets(), public.beta_invite_redeem(text), public.record_admin_session() to authenticated;
-- Ticket: utente autenticato direttamente; ospiti solo tramite /api/support (Turnstile) con service role
revoke execute on function public.support_ticket_create(jsonb, text) from public, anon;
grant execute on function public.support_ticket_create(jsonb, text) to authenticated, service_role;
-- Pubbliche (con rate limit interno)
grant execute on function public.consent_record(jsonb, text, text, text), public.public_runtime_config(), public.restaurant_slug_redirect(text),
  public.restaurant_slug_redirects(), public.client_error_record(jsonb), public.web_vital_record(jsonb), public.system_ping(),
  public.scrub_pii(text), public.push_endpoint_allowed(text), public.feature_flag_keys() to anon, authenticated;
grant execute on function public.auth_recent(int) to authenticated;

-- Lettura diretta delle impostazioni: prima chiunque poteva leggere QUALSIASI chiave con billing_setting('…')
-- aggirando l'allowlist. Le usano solo funzioni SECURITY DEFINER (eseguite come proprietario): niente grant ai client.
revoke execute on function public.billing_setting(text), public.billing_setting_int(text, int), public.billing_setting_bool(text, boolean),
  public.billing_setting_text(text, text), public.billing_setting_num(text, numeric), public.ai_setting_num(text, numeric),
  public.setting_num(text, numeric) from public, anon, authenticated;
grant execute on function public.billing_setting(text), public.billing_setting_int(text, int), public.billing_setting_bool(text, boolean),
  public.billing_setting_text(text, text), public.billing_setting_num(text, numeric), public.ai_setting_num(text, numeric),
  public.setting_num(text, numeric) to service_role;

-- Funzioni del ristoratore: mai eseguibili senza login (controllo di ownership interno invariato)
do $$
declare f record;
begin
  for f in select p.oid::regprocedure sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.proname in ('complete_onboarding', 'get_billing_overview', 'order_action', 'order_set_pause', 'request_publication',
              'restaurant_ai_stats', 'restaurant_order_stats', 'restaurant_orders', 'restaurant_profile_completion', 'set_menu_item_availability', 'my_orders',
              'rate_limit_assert', 'rate_limit_caller_key', 'assert_service', 'is_admin_or_service', 'sys_is_service')
  loop
    execute format('revoke execute on function %s from public, anon', f.sig);
    execute format('grant execute on function %s to authenticated, service_role', f.sig);
  end loop;
end $$;

-- Privilegi espliciti sulle nuove tabelle (le RLS restano la vera barriera; scritture solo via RPC)
grant select on public.legal_document_versions, public.restaurant_slug_history to anon, authenticated;
grant select on public.user_consents, public.data_export_requests, public.account_deletion_requests, public.support_tickets,
  public.security_audit_logs, public.background_jobs, public.system_error_log, public.web_vitals, public.launch_checks, public.beta_invites
  to authenticated;
revoke all on public.rate_limits, public.job_locks, public.system_secrets from anon, authenticated;
revoke insert, update, delete on public.legal_document_versions, public.restaurant_slug_history from anon;

-- ────────────────────────────────────────────────────────────────────
--  22. PULIZIA DATI DEMO (solo backend, con conferma esplicita; dry-run di default)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.clean_demo_data(p_confirm text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_dry boolean := coalesce(p_confirm, '') <> 'DELETE-DEMO-DATA';
  v_rest int; v_keep int; v_riders int;
begin
  perform public.assert_service();
  select count(*) into v_rest from public.restaurants r where r.is_demo
     and not exists (select 1 from public.orders o where o.restaurant_id = r.id)
     and not exists (select 1 from public.reservations x where x.restaurant_id = r.id and x.user_id is not null)
     and not exists (select 1 from public.reviews v where v.restaurant_id = r.id and not exists (select 1 from public.profiles p where p.id = v.user_id and p.email like '%@demo.local'));
  select count(*) into v_keep from public.restaurants where is_demo and is_active;
  select count(*) into v_riders from public.rider_profiles where is_demo;
  if v_dry then
    return jsonb_build_object('dry_run', true, 'restaurants_deletable', v_rest, 'demo_restaurants_active', v_keep, 'demo_riders', v_riders,
      'hint', 'Per eseguire: p_confirm = DELETE-DEMO-DATA');
  end if;
  set local asiafood.allow_hard_delete = 'on';
  -- 1) mai più visibili
  update public.platform_settings set value = 'false' where key = 'show_demo_data';
  -- 2) locali demo senza storico reale: eliminati; gli altri disattivati (lo storico resta integro)
  delete from public.restaurants r where r.is_demo
     and not exists (select 1 from public.orders o where o.restaurant_id = r.id)
     and not exists (select 1 from public.reservations x where x.restaurant_id = r.id and x.user_id is not null);
  get diagnostics v_rest = row_count;
  update public.restaurants set is_active = false where is_demo and is_active;
  get diagnostics v_keep = row_count;
  -- 3) Rider demo
  delete from public.rider_profiles where is_demo;
  get diagnostics v_riders = row_count;
  perform public.audit_security('demo_data_cleaned', 'platform', null, jsonb_build_object('restaurants_deleted', v_rest, 'restaurants_deactivated', v_keep, 'riders_deleted', v_riders));
  return jsonb_build_object('dry_run', false, 'restaurants_deleted', v_rest, 'restaurants_deactivated', v_keep, 'riders_deleted', v_riders, 'show_demo_data', false);
end $$;
revoke execute on function public.clean_demo_data(text) from public, anon, authenticated;
grant execute on function public.clean_demo_data(text) to service_role;

-- ────────────────────────────────────────────────────────────────────
--  23. METRICHE BUSINESS: locali DEMO esclusi dai conteggi (corpo della Fase 5 + filtro is_demo)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_revenue_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_month_start timestamptz := date_trunc('month', now() at time zone 'Europe/Rome') at time zone 'Europe/Rome';
  v jsonb;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select jsonb_build_object(
    'environment', public.billing_setting_text('billing_stripe_environment', null),
    -- Fase 11: metriche business senza locali DEMO (definizioni in docs/ANALYTICS_EVENTS.md)
    'restaurants_total', (select count(*) from public.restaurants where not is_demo),
    'restaurants_active', (select count(*) from public.restaurants where not is_demo and is_active and not is_permanently_closed),
    'restaurants_claimed', (select count(*) from public.restaurants where not is_demo and owner_id is not null),
    'plans', (select jsonb_object_agg(p.code, (select count(*) from public.restaurants r where r.subscription_plan = p.code and not r.is_demo))
              from public.subscription_plans p),
    'paying_customers', (select count(distinct coalesce(s.billing_account_id::text, s.restaurant_id::text)) from public.subscriptions s
                         where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
    'paying_subscriptions', (select count(*) from public.subscriptions s
                             where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
    'mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                  where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
    'arr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s)) * 12), 0) from public.subscriptions s
                  where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
    'new_mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                      where public.subscription_in_env(s) and s.paid_started_at >= v_month_start),
    'churned_mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                          where public.subscription_in_env(s) and s.ended_at >= v_month_start and s.paid_started_at is not null),
    'trials_active', (select count(*) from public.subscriptions s
                      where public.subscription_in_env(s) and s.status = 'trialing' and public.subscription_grants_access(s)),
    'trials_ended', (select count(*) from public.billing_trials where ends_at is not null and ends_at <= now()),
    'trials_converted', (select count(*) from public.billing_trials where converted_at is not null),
    'trial_conversion_rate', (select case when count(*) filter (where ends_at <= now() or converted_at is not null) = 0 then null
                                     else round(count(*) filter (where converted_at is not null) * 100.0
                                                / count(*) filter (where ends_at <= now() or converted_at is not null), 1) end
                              from public.billing_trials),
    'cancel_scheduled', (select count(*) from public.subscriptions s
                         where public.subscription_in_env(s) and s.cancel_at_period_end and s.status in ('active', 'trialing', 'past_due')),
    'cancelled_30d', (select count(*) from public.subscriptions s
                      where public.subscription_in_env(s) and s.status = 'canceled' and coalesce(s.ended_at, s.cancelled_at) >= now() - interval '30 days'),
    'past_due', (select count(*) from public.subscriptions s where public.subscription_in_env(s) and s.status in ('past_due', 'unpaid')),
    'manual_active', (select count(*) from public.subscriptions s where s.source <> 'stripe' and public.subscription_grants_access(s)),
    'mrr_series', (select jsonb_agg(jsonb_build_object('month', to_char(mo.m, 'YYYY-MM'), 'mrr_cents',
                     (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                       where public.subscription_in_env(s) and s.paid_started_at is not null
                         and s.paid_started_at < mo.m + interval '1 month'
                         and (case when mo.m + interval '1 month' > now()
                                   then s.status in ('active', 'past_due') and public.subscription_grants_access(s)
                                   else coalesce(s.ended_at, 'infinity'::timestamptz) >= mo.m + interval '1 month' end)))
                   order by mo.m)
                   from generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') as mo(m))
  ) into v;
  return v;
end $$;
revoke execute on function public.admin_revenue_stats() from public, anon;
grant execute on function public.admin_revenue_stats() to authenticated, service_role;
