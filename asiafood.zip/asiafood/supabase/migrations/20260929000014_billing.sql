-- ════════════════════════════════════════════════════════════════════
--  FASE 5 · SaaS B2B: Stripe Billing, abbonamenti, prove gratuite,
--  fatturazione, promozioni B2B, onboarding, sponsorizzazioni, ricavi.
--
--  Principi:
--  • Stripe è la fonte autorevole per gli abbonamenti a pagamento: le righe
--    source='stripe' le scrive SOLO il backend (Netlify Functions con
--    service role) dopo aver letto l'oggetto da Stripe (webhook o sync).
--  • Il piano "realmente attivo" è calcolato qui (restaurant_effective_plan):
--    trial/active → piano; past_due → periodo di tolleranza; canceled → fino
--    a fine periodo; altrimenti Free. restaurants.subscription_plan ne è la
--    copia (cache) aggiornata da trigger e dal cron orario.
--  • Nessun ID Stripe arriva dal browser: le RPC server-side ricevono
--    l'utente verificato e leggono prezzi, clienti e abbonamenti dal DB.
-- ════════════════════════════════════════════════════════════════════

-- ════════════════════════════════════════════════════════════════════
--  1. IMPOSTAZIONI BILLING (modificabili dall'Admin)
-- ════════════════════════════════════════════════════════════════════
insert into public.platform_settings (key, value, description) values
  ('billing_trial_days', '30', 'Durata della prova gratuita (giorni). 0 = nessuna prova'),
  ('billing_require_payment_method_for_trial', 'false', 'true = carta richiesta per iniziare la prova; false = prova senza carta'),
  ('billing_payment_grace_period_days', '3', 'Giorni di tolleranza dopo un pagamento fallito prima di tornare al piano Free'),
  ('billing_trial_expiring_days', '3', 'Avviso di fine prova: giorni prima della scadenza'),
  ('billing_proration_behavior', '"always_invoice"', 'Upgrade: always_invoice (addebito subito della differenza), create_prorations (in fattura successiva), none'),
  ('billing_downgrade_timing', '"period_end"', 'Downgrade: period_end (a fine ciclo) oppure immediate'),
  ('billing_max_trial_extension_days', '60', 'Estensione massima di una prova concessa dall''Admin'),
  ('billing_stripe_environment', 'null', 'test | live — impostato automaticamente dal backend in base alla chiave Stripe')
on conflict (key) do nothing;

create or replace function public.billing_setting(p_key text)
returns jsonb language sql stable security definer set search_path = public as $$
  select value from public.platform_settings where key = p_key;
$$;
create or replace function public.billing_setting_int(p_key text, p_default int)
returns int language sql stable security definer set search_path = public as $$
  select coalesce((select case when jsonb_typeof(value) = 'number' then (value #>> '{}')::int end
                   from public.platform_settings where key = p_key), p_default);
$$;
create or replace function public.billing_setting_bool(p_key text, p_default boolean)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select case when jsonb_typeof(value) = 'boolean' then (value #>> '{}')::boolean end
                   from public.platform_settings where key = p_key), p_default);
$$;
create or replace function public.billing_setting_text(p_key text, p_default text)
returns text language sql stable security definer set search_path = public as $$
  select coalesce((select case when jsonb_typeof(value) = 'string' then value #>> '{}' end
                   from public.platform_settings where key = p_key), p_default);
$$;

-- Salva/ripristina il flag di scrittura interna (le funzioni possono annidarsi)
create or replace function public.internal_write_begin()
returns text language plpgsql volatile as $$
declare v text := coalesce(current_setting('asiafood.internal_write', true), '');
begin
  perform set_config('asiafood.internal_write', 'on', true);
  return v;
end $$;
create or replace function public.internal_write_end(p_prev text)
returns void language sql volatile as $$
  select set_config('asiafood.internal_write', coalesce(p_prev, ''), true);
$$;

-- ════════════════════════════════════════════════════════════════════
--  2. PIANI ↔ STRIPE
-- ════════════════════════════════════════════════════════════════════
alter table public.subscription_plans rename column stripe_price_monthly_id to stripe_monthly_price_id;
alter table public.subscription_plans rename column stripe_price_yearly_id to stripe_yearly_price_id;
alter table public.subscription_plans
  add column if not exists stripe_product_id text,
  add column if not exists trial_enabled boolean not null default false,
  add column if not exists slug text generated always as (code) stored,
  add column if not exists display_order int generated always as (sort_order) stored;
alter table public.subscription_plans
  add constraint subscription_plans_stripe_ids_format check (
    (stripe_product_id is null or stripe_product_id ~ '^prod_[A-Za-z0-9]+$')
    and (stripe_monthly_price_id is null or stripe_monthly_price_id ~ '^price_[A-Za-z0-9]+$')
    and (stripe_yearly_price_id is null or stripe_yearly_price_id ~ '^price_[A-Za-z0-9]+$'));
create unique index subscription_plans_monthly_price_key on public.subscription_plans(stripe_monthly_price_id) where stripe_monthly_price_id is not null;
create unique index subscription_plans_yearly_price_key on public.subscription_plans(stripe_yearly_price_id) where stripe_yearly_price_id is not null;

update public.subscription_plans set trial_enabled = true where code in ('business', 'premium', 'top');
-- Prezzi annuali della specifica, solo se ancora ai valori iniziali
update public.subscription_plans set yearly_price = 299 where code = 'business' and yearly_price is null;
update public.subscription_plans set yearly_price = 599 where code = 'premium' and yearly_price is null;
update public.subscription_plans set yearly_price = 999 where code = 'top' and yearly_price is null;

-- Nuove funzioni per il confronto piani (Premium: supporto prioritario; Top: promozioni avanzate)
insert into public.plan_features (plan_code, feature_key, enabled, limit_value)
select p.code, f.key,
       case p.code when 'free' then f.free when 'business' then f.business when 'premium' then f.premium else f.top end, null
from public.subscription_plans p
cross join (values
  ('priority_support',    false, false, true, true),
  ('advanced_promotions', false, false, false, true)
) as f(key, free, business, premium, top)
where p.code in ('free', 'business', 'premium', 'top')
on conflict (plan_code, feature_key) do nothing;

drop view if exists public.plans;
create view public.plans with (security_invoker = true) as
  select id, name, slug, description, monthly_price, yearly_price, currency, features,
         stripe_product_id, stripe_monthly_price_id, stripe_yearly_price_id, trial_enabled,
         is_active, display_order, created_at, updated_at
  from public.subscription_plans;

-- ════════════════════════════════════════════════════════════════════
--  3. ACCOUNT DI FATTURAZIONE (multi-locale: un cliente Stripe per account,
--     più abbonamenti — uno per ristorante — sullo stesso account)
-- ════════════════════════════════════════════════════════════════════
create table public.billing_accounts (
  id                 uuid primary key default gen_random_uuid(),
  owner_user_id      uuid not null unique references public.profiles(id) on delete cascade,
  stripe_customer_id text unique check (stripe_customer_id is null or stripe_customer_id ~ '^cus_[A-Za-z0-9]+$'),
  stripe_environment text check (stripe_environment in ('test', 'live')),
  business_name      text check (char_length(business_name) <= 160),
  vat_number         text check (vat_number is null or vat_number ~ '^[A-Z]{0,2}[0-9A-Z]{8,14}$'),
  tax_code           text check (tax_code is null or tax_code ~ '^[0-9A-Z]{11,16}$'),
  billing_email      text check (billing_email is null or billing_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  pec                text check (pec is null or pec ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  recipient_code     text check (recipient_code is null or recipient_code ~ '^[0-9A-Z]{6,7}$'),
  address_line       text check (char_length(address_line) <= 200),
  postal_code        text check (postal_code is null or postal_code ~ '^[0-9A-Za-z -]{3,10}$'),
  city               text check (char_length(city) <= 100),
  province           text check (province is null or char_length(province) <= 40),
  country            char(2) not null default 'IT' check (country ~ '^[A-Z]{2}$'),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create trigger billing_accounts_updated_at before update on public.billing_accounts
  for each row execute function public.set_updated_at();

-- I collegamenti a Stripe li scrive solo il backend
create or replace function public.billing_accounts_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.internal_write() then
    if tg_op = 'INSERT' then
      new.stripe_customer_id := null;
      new.stripe_environment := null;
      if not public.is_admin() then new.owner_user_id := auth.uid(); end if;
    else
      new.stripe_customer_id := old.stripe_customer_id;
      new.stripe_environment := old.stripe_environment;
      new.owner_user_id := old.owner_user_id;
    end if;
  end if;
  new.vat_number     := nullif(upper(regexp_replace(coalesce(new.vat_number, ''), '\s', '', 'g')), '');
  new.tax_code       := nullif(upper(regexp_replace(coalesce(new.tax_code, ''), '\s', '', 'g')), '');
  new.recipient_code := nullif(upper(trim(coalesce(new.recipient_code, ''))), '');
  new.billing_email  := nullif(lower(trim(coalesce(new.billing_email, ''))), '');
  new.pec            := nullif(lower(trim(coalesce(new.pec, ''))), '');
  new.country        := upper(coalesce(nullif(trim(new.country), ''), 'IT'));
  return new;
end $$;
create trigger billing_accounts_guard before insert or update on public.billing_accounts
  for each row execute function public.billing_accounts_guard();

-- ════════════════════════════════════════════════════════════════════
--  4. ABBONAMENTI
-- ════════════════════════════════════════════════════════════════════
alter table public.subscriptions
  add column if not exists user_id                  uuid references public.profiles(id) on delete set null,
  add column if not exists billing_account_id       uuid references public.billing_accounts(id) on delete set null,
  add column if not exists plan_id                  uuid references public.subscription_plans(id) on delete set null,
  add column if not exists source                   public.subscription_source not null default 'manual',
  add column if not exists stripe_environment       text check (stripe_environment in ('test', 'live')),
  add column if not exists trial_start              timestamptz,
  add column if not exists trial_end                timestamptz,
  add column if not exists cancelled_at             timestamptz,
  add column if not exists ended_at                 timestamptz,
  add column if not exists expires_at               timestamptz,          -- piani manuali/promo
  add column if not exists revoked_at               timestamptz,
  add column if not exists granted_by               uuid references public.profiles(id) on delete set null,
  add column if not exists unit_amount_cents        int check (unit_amount_cents is null or unit_amount_cents >= 0),
  add column if not exists currency                 char(3) default 'EUR',
  add column if not exists payment_failed_at        timestamptz,
  add column if not exists paid_started_at          timestamptz,          -- primo pagamento > 0
  add column if not exists pm_brand                 text,                 -- dati "safe" del metodo di pagamento
  add column if not exists pm_last4                 text check (pm_last4 is null or pm_last4 ~ '^[0-9]{4}$'),
  add column if not exists pm_exp_month             smallint,
  add column if not exists pm_exp_year              smallint,
  add column if not exists latest_invoice_id        text,
  add column if not exists latest_invoice_status    text,
  add column if not exists scheduled_plan_code      text references public.subscription_plans(code) on update cascade,
  add column if not exists scheduled_interval       text check (scheduled_interval in ('month', 'year')),
  add column if not exists scheduled_change_at      timestamptz,
  add column if not exists stripe_schedule_id       text,
  add column if not exists trial_expiring_notified_at timestamptz,
  add column if not exists last_synced_at           timestamptz;
alter table public.subscriptions alter column source set default 'stripe';
alter table public.subscriptions add constraint subscriptions_stripe_fields check (
  source <> 'stripe' or (stripe_subscription_id is not null and stripe_subscription_id ~ '^sub_[A-Za-z0-9]+$'));
create index subscriptions_customer_idx on public.subscriptions(stripe_customer_id);
create index subscriptions_account_idx on public.subscriptions(billing_account_id);
create index subscriptions_source_status_idx on public.subscriptions(source, status);
comment on column public.subscriptions.status is 'Stato Stripe: trialing, active, past_due, unpaid, canceled, incomplete, incomplete_expired, paused (free = nessun piano a pagamento)';

create or replace function public.subscriptions_fill()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.plan_id := (select id from public.subscription_plans where code = new.plan_code);
  new.updated_at := now();
  return new;
end $$;
create trigger subscriptions_fill before insert or update on public.subscriptions
  for each row execute function public.subscriptions_fill();

-- ─── Piano realmente attivo ──────────────────────────────────────────
create or replace function public.subscription_grants_access(s public.subscriptions)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare v_env text := public.billing_setting_text('billing_stripe_environment', null);
begin
  if s.source <> 'stripe' then
    return s.status in ('active', 'trialing') and s.revoked_at is null and (s.expires_at is null or s.expires_at > now());
  end if;
  -- Non mescolare test e live: vale solo l'ambiente Stripe in uso
  if v_env is not null and s.stripe_environment is distinct from v_env then return false; end if;
  return case s.status
    when 'active'   then true
    when 'trialing' then coalesce(s.trial_end, now()) > now() - interval '1 day'
    when 'past_due' then now() < coalesce(s.payment_failed_at, s.current_period_end, now())
                                 + make_interval(days => public.billing_setting_int('billing_payment_grace_period_days', 3))
    -- Cancellato su richiesta: accesso fino a fine periodo già pagato (non se insoluto)
    when 'canceled' then s.payment_failed_at is null and s.current_period_end is not null and s.current_period_end > now()
    else false
  end;
end $$;

create or replace function public.restaurant_effective_subscription(p_restaurant_id uuid)
returns public.subscriptions language sql stable security definer set search_path = public as $$
  select s.* from public.subscriptions s
  join public.subscription_plans p on p.code = s.plan_code
  where s.restaurant_id = p_restaurant_id and public.subscription_grants_access(s)
  order by p.sort_order desc, (s.source = 'stripe') desc, s.created_at desc
  limit 1;
$$;

create or replace function public.restaurant_effective_plan(p_restaurant_id uuid)
returns text language sql stable security definer set search_path = public as $$
  select coalesce((public.restaurant_effective_subscription(p_restaurant_id)).plan_code, 'free');
$$;

-- Le regole di piano leggono il piano realmente attivo (non la cache)
create or replace function public.restaurant_has_feature(p_restaurant_id uuid, p_key text)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((
    select f.enabled from public.plan_features f
    where f.plan_code = public.restaurant_effective_plan(p_restaurant_id) and f.feature_key = p_key), false);
$$;

create or replace function public.restaurant_feature_limit(p_restaurant_id uuid, p_key text)
returns int language plpgsql stable security definer set search_path = public as $$
declare v_enabled boolean; v_limit int;
begin
  select f.enabled, f.limit_value into v_enabled, v_limit
  from public.plan_features f
  where f.plan_code = public.restaurant_effective_plan(p_restaurant_id) and f.feature_key = p_key;
  if not found or not v_enabled then return 0; end if;
  return v_limit;
end $$;

-- ─── Cache restaurants.subscription_plan ─────────────────────────────
create or replace function public.refresh_restaurant_plan(p_restaurant_id uuid)
returns text language plpgsql security definer set search_path = public as $$
declare v_plan text := public.restaurant_effective_plan(p_restaurant_id); v_prev text;
begin
  v_prev := public.internal_write_begin();
  update public.restaurants set subscription_plan = v_plan
   where id = p_restaurant_id and subscription_plan is distinct from v_plan;
  perform public.internal_write_end(v_prev);
  return v_plan;
end $$;

create or replace function public.subscriptions_refresh_plan()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op in ('UPDATE', 'DELETE') then perform public.refresh_restaurant_plan(old.restaurant_id); end if;
  if tg_op in ('INSERT', 'UPDATE') and (tg_op = 'INSERT' or new.restaurant_id <> old.restaurant_id) then
    perform public.refresh_restaurant_plan(new.restaurant_id);
  end if;
  return null;
end $$;
create trigger subscriptions_refresh_plan after insert or update or delete on public.subscriptions
  for each row execute function public.subscriptions_refresh_plan();

-- Scadenze a tempo (fine tolleranza, fine periodo, piani manuali): cron orario
create or replace function public.billing_refresh_plans()
returns int language plpgsql security definer set search_path = public as $$
declare v_count int := 0; r record;
begin
  if auth.uid() is not null and not public.is_admin() then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  for r in
    select id, subscription_plan from public.restaurants
    where subscription_plan <> 'free' or exists (select 1 from public.subscriptions s where s.restaurant_id = restaurants.id)
  loop
    if public.refresh_restaurant_plan(r.id) is distinct from r.subscription_plan then v_count := v_count + 1; end if;
  end loop;
  return v_count;
end $$;

-- Il piano del locale non si imposta a mano: deriva dagli abbonamenti (Stripe o concessioni Admin)
create or replace function public.protect_restaurant_admin_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.internal_write() and tg_op = 'UPDATE' then
    new.subscription_plan := old.subscription_plan;
  end if;
  if auth.uid() is not null and not public.is_admin() then
    new.owner_id              := old.owner_id;
    new.is_verified           := old.is_verified;
    new.is_active             := old.is_active;
    new.is_featured           := old.is_featured;
    new.is_sponsored          := old.is_sponsored;
    new.is_demo               := old.is_demo;
    new.popularity_score      := old.popularity_score;
    new.slug                  := old.slug;
    new.city_id               := old.city_id;
    new.data_status           := old.data_status;
    new.source_name           := old.source_name;
    new.source_url            := old.source_url;
    new.external_id           := old.external_id;
    new.google_place_id       := old.google_place_id;
    new.last_verified_at      := old.last_verified_at;
    new.claimed_at            := old.claimed_at;
    new.claimed_by            := old.claimed_by;
    new.verification_notes    := old.verification_notes;
    new.is_permanently_closed := old.is_permanently_closed;
    new.address               := old.address;
    new.postal_code           := old.postal_code;
    if new.latitude is distinct from old.latitude or new.longitude is distinct from old.longitude then
      if old.latitude is null or new.latitude is null or new.longitude is null
         or public.geo_distance_km(old.latitude, old.longitude, new.latitude, new.longitude) > 0.3 then
        new.latitude  := old.latitude;
        new.longitude := old.longitude;
      end if;
    end if;
  end if;
  return new;
end $$;

-- Nuovi locali: il piano parte da Free (le concessioni passano da admin_grant_plan)
create or replace function public.restaurants_plan_on_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.internal_write() then new.subscription_plan := 'free'; end if;
  return new;
end $$;
create trigger restaurants_plan_on_insert before insert on public.restaurants
  for each row execute function public.restaurants_plan_on_insert();

-- Migrazione dati: i piani assegnati a mano nelle fasi precedenti diventano concessioni Admin
insert into public.subscriptions (restaurant_id, plan_code, status, source, billing_interval, current_period_start, notes)
select r.id, r.subscription_plan, 'active', 'admin', 'month', now(), 'Piano assegnato prima della Fase 5'
from public.restaurants r
where r.subscription_plan <> 'free'
  and not exists (select 1 from public.subscriptions s where s.restaurant_id = r.id);
update public.subscriptions set source = 'stripe' where stripe_subscription_id is not null and source <> 'stripe';

-- ════════════════════════════════════════════════════════════════════
--  5. FATTURE, EVENTI STRIPE, PROVE, PROMOZIONI, ATTIVITÀ
-- ════════════════════════════════════════════════════════════════════
create table public.billing_invoices (
  id                  uuid primary key default gen_random_uuid(),
  stripe_invoice_id   text not null unique check (stripe_invoice_id ~ '^in_[A-Za-z0-9]+$'),
  subscription_id     uuid references public.subscriptions(id) on delete set null,
  restaurant_id       uuid references public.restaurants(id) on delete set null,
  billing_account_id  uuid references public.billing_accounts(id) on delete set null,
  stripe_customer_id  text,
  number              text,
  status              text not null,             -- draft, open, paid, uncollectible, void
  amount_due_cents    int not null default 0,
  amount_paid_cents   int not null default 0,
  currency            char(3) not null default 'EUR',
  hosted_invoice_url  text check (hosted_invoice_url is null or hosted_invoice_url ~ '^https://'),
  invoice_pdf         text check (invoice_pdf is null or invoice_pdf ~ '^https://'),   -- link Stripe, il PDF non è salvato
  period_start        timestamptz,
  period_end          timestamptz,
  stripe_created_at   timestamptz not null default now(),
  stripe_environment  text check (stripe_environment in ('test', 'live')),
  updated_at          timestamptz not null default now()
);
create index billing_invoices_restaurant_idx on public.billing_invoices(restaurant_id, stripe_created_at desc);
create index billing_invoices_account_idx on public.billing_invoices(billing_account_id, stripe_created_at desc);

-- Idempotenza webhook: un evento Stripe viene elaborato una sola volta
create table public.stripe_events (
  id                uuid primary key default gen_random_uuid(),
  stripe_event_id   text not null unique check (stripe_event_id ~ '^evt_[A-Za-z0-9]+$'),
  event_type        text not null check (char_length(event_type) <= 80),
  stripe_environment text check (stripe_environment in ('test', 'live')),
  object_id         text check (char_length(object_id) <= 80),
  restaurant_id     uuid references public.restaurants(id) on delete set null,
  processing_status text not null default 'processing' check (processing_status in ('processing', 'processed', 'failed', 'ignored')),
  error_message     text check (char_length(error_message) <= 500),
  attempts          int not null default 1,
  last_attempt_at   timestamptz not null default now(),
  created_at        timestamptz not null default now(),
  processed_at      timestamptz
);
create index stripe_events_created_idx on public.stripe_events(created_at desc);

-- Registro delle prove gratuite: una sola per locale e per utente (anche se l'abbonamento viene cancellato)
create table public.billing_trials (
  id                     uuid primary key default gen_random_uuid(),
  restaurant_id          uuid not null unique references public.restaurants(id) on delete cascade,
  user_id                uuid references public.profiles(id) on delete set null,
  billing_account_id     uuid references public.billing_accounts(id) on delete set null,
  vat_number             text,
  plan_code              text not null references public.subscription_plans(code) on update cascade,
  subscription_id        uuid references public.subscriptions(id) on delete set null,
  started_at             timestamptz not null default now(),
  ends_at                timestamptz,
  converted_at           timestamptz,
  created_at             timestamptz not null default now()
);
create index billing_trials_user_idx on public.billing_trials(user_id);
create index billing_trials_vat_idx on public.billing_trials(vat_number) where vat_number is not null;

-- Promozioni commerciali B2B (diverse dai coupon clienti dei ristoranti)
create table public.billing_promotions (
  id                  uuid primary key default gen_random_uuid(),
  code                text not null unique check (code ~ '^[A-Z0-9][A-Z0-9_-]{2,29}$'),
  description         text check (char_length(description) <= 300),
  discount_type       text not null check (discount_type in ('percent', 'amount', 'free_days')),
  discount_value      numeric(10,2) check (discount_value is null or discount_value > 0),
  duration            text not null default 'once' check (duration in ('once', 'repeating', 'forever')),
  duration_in_months  int check (duration_in_months is null or duration_in_months between 1 and 36),
  free_days           int check (free_days is null or free_days between 1 and 365),
  applicable_plans    text[] not null default '{}',           -- vuoto = tutti i piani a pagamento
  max_redemptions     int check (max_redemptions is null or max_redemptions > 0),
  redemptions_count   int not null default 0,
  starts_at           timestamptz not null default now(),
  ends_at             timestamptz,
  is_active           boolean not null default true,
  stripe_coupon_ids   jsonb not null default '{}'::jsonb,     -- {"test": "...", "live": "..."} creati dal backend
  created_by          uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  check (discount_type <> 'percent' or (discount_value is not null and discount_value <= 100)),
  check (discount_type <> 'amount' or discount_value is not null),
  check (discount_type <> 'free_days' or free_days is not null),
  check (duration <> 'repeating' or duration_in_months is not null),
  check (ends_at is null or ends_at > starts_at)
);
create trigger billing_promotions_updated_at before update on public.billing_promotions
  for each row execute function public.set_updated_at();
create or replace function public.billing_promotions_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.code := upper(trim(new.code));
  if tg_op = 'UPDATE' and not public.internal_write() then
    new.redemptions_count := old.redemptions_count;
    new.stripe_coupon_ids := old.stripe_coupon_ids;
  elsif tg_op = 'INSERT' and not public.internal_write() then
    new.redemptions_count := 0;
    new.stripe_coupon_ids := '{}'::jsonb;
  end if;
  return new;
end $$;
create trigger billing_promotions_guard before insert or update on public.billing_promotions
  for each row execute function public.billing_promotions_guard();

create table public.billing_promotion_redemptions (
  id                     uuid primary key default gen_random_uuid(),
  promotion_id           uuid not null references public.billing_promotions(id) on delete cascade,
  restaurant_id          uuid not null references public.restaurants(id) on delete cascade,
  user_id                uuid references public.profiles(id) on delete set null,
  stripe_subscription_id text,
  created_at             timestamptz not null default now(),
  unique (promotion_id, restaurant_id)
);

-- Eventi interni del ciclo di vita (log + base per email/notifiche)
create table public.billing_activity (
  id              bigint generated always as identity primary key,
  restaurant_id   uuid references public.restaurants(id) on delete cascade,
  subscription_id uuid references public.subscriptions(id) on delete set null,
  event           text not null check (event in (
    'trial_started', 'trial_expiring', 'trial_ended', 'trial_extended',
    'subscription_started', 'subscription_upgraded', 'subscription_downgraded', 'interval_changed',
    'change_scheduled', 'change_cancelled', 'subscription_cancelled', 'subscription_resumed', 'subscription_ended',
    'payment_succeeded', 'payment_failed', 'payment_recovered', 'payment_action_required',
    'plan_granted', 'plan_revoked', 'duplicate_subscription', 'email_error'
  )),
  data            jsonb not null default '{}'::jsonb,
  created_at      timestamptz not null default now()
);
create index billing_activity_restaurant_idx on public.billing_activity(restaurant_id, created_at desc);

-- Rate limit delle azioni di fatturazione (checkout, portale, cambi piano)
create table public.billing_requests (
  id         bigint generated always as identity primary key,
  user_id    uuid not null,
  action     text not null,
  created_at timestamptz not null default now()
);
create index billing_requests_user_idx on public.billing_requests(user_id, action, created_at desc);

-- ─── Email di fatturazione: coda esistente, mai bloccanti ────────────
alter table public.email_outbox drop constraint if exists email_outbox_event_type_check;
alter table public.email_outbox add constraint email_outbox_event_type_check check (event_type in (
  'reservation_created', 'reservation_confirmed', 'reservation_rejected', 'reservation_cancelled', 'reservation_new_for_restaurant',
  'billing_welcome', 'billing_trial_started', 'billing_trial_ending', 'billing_subscription_activated',
  'billing_payment_succeeded', 'billing_payment_failed', 'billing_subscription_cancelled'
));

create or replace function public.billing_log(p_restaurant uuid, p_sub uuid, p_event text, p_data jsonb default '{}'::jsonb)
returns void language sql security definer set search_path = public as $$
  insert into public.billing_activity (restaurant_id, subscription_id, event, data)
  values (p_restaurant, p_sub, p_event, coalesce(p_data, '{}'::jsonb));
$$;

-- Notifica in-app ai titolari + email all'indirizzo di fatturazione. Un errore qui
-- non interrompe mai il webhook: viene registrato come 'email_error'.
create or replace function public.billing_notify(p_restaurant uuid, p_sub uuid, p_email_event text, p_title text, p_body text, p_payload jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare v_email text; v_name text;
begin
  begin
    select name into v_name from public.restaurants where id = p_restaurant;
    perform public.notify_restaurant(p_restaurant, 'billing', p_title, p_body, format('/dashboard/restaurants/%s/billing', p_restaurant));
    if p_email_event is not null then
      select coalesce(ba.billing_email, p.email) into v_email
      from public.subscriptions s
      left join public.billing_accounts ba on ba.id = s.billing_account_id
      left join public.profiles p on p.id = coalesce(ba.owner_user_id, s.user_id)
      where s.id = p_sub;
      if v_email is null then
        select p.email into v_email from public.restaurant_members m join public.profiles p on p.id = m.user_id
        where m.restaurant_id = p_restaurant and m.status = 'active' and m.role = 'owner' limit 1;
      end if;
      perform public.enqueue_email(p_email_event, v_email,
        coalesce(p_payload, '{}'::jsonb) || jsonb_build_object('restaurant_name', v_name, 'restaurant_id', p_restaurant, 'title', p_title, 'body', p_body),
        p_restaurant, null);
    end if;
  exception when others then
    insert into public.billing_activity (restaurant_id, subscription_id, event, data)
    values (p_restaurant, p_sub, 'email_error', jsonb_build_object('email_event', p_email_event, 'error', left(sqlerrm, 300)));
  end;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  6. RPC SERVER-SIDE (solo service_role: le chiamano le Netlify Functions
--     dopo aver verificato il JWT dell'utente)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.assert_service()
returns void language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is not null then raise exception 'Solo backend' using errcode = '42501'; end if;
end $$;

create or replace function public.user_can_bill(p_user uuid, p_restaurant uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p where p.id = p_user and not p.is_blocked and (
      p.role = 'admin' or exists (
        select 1 from public.restaurant_members m
        where m.restaurant_id = p_restaurant and m.user_id = p_user and m.status = 'active' and m.role = 'owner')));
$$;

create or replace function public.billing_rate_check(p_user uuid, p_action text, p_max int, p_window_seconds int)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_n int;
begin
  perform public.assert_service();
  select count(*) into v_n from public.billing_requests
  where user_id = p_user and action = p_action and created_at > now() - make_interval(secs => p_window_seconds);
  if v_n >= p_max then return false; end if;
  insert into public.billing_requests (user_id, action) values (p_user, p_action);
  delete from public.billing_requests where created_at < now() - interval '1 day';
  return true;
end $$;

-- Il backend comunica l'ambiente Stripe in uso (dedotto dalla chiave: sk_test / sk_live)
create or replace function public.billing_set_environment(p_env text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  if p_env not in ('test', 'live') then raise exception 'Ambiente non valido'; end if;
  if public.billing_setting_text('billing_stripe_environment', null) is distinct from p_env then
    update public.platform_settings set value = to_jsonb(p_env) where key = 'billing_stripe_environment';
    perform public.billing_refresh_plans();
  end if;
end $$;

create or replace function public.billing_trial_eligible(p_restaurant uuid, p_user uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select not exists (select 1 from public.billing_trials t where t.restaurant_id = p_restaurant or (p_user is not null and t.user_id = p_user))
     and not exists (select 1 from public.subscriptions s where s.restaurant_id = p_restaurant and s.source = 'stripe' and s.trial_start is not null)
     and not exists (
       select 1 from public.billing_accounts ba join public.billing_trials t on t.vat_number = ba.vat_number
       where ba.owner_user_id = p_user and ba.vat_number is not null);
$$;

-- Account di fatturazione dell'utente (creato al primo checkout)
create or replace function public.billing_ensure_account(p_user uuid)
returns public.billing_accounts language plpgsql security definer set search_path = public as $$
declare v public.billing_accounts;
begin
  select * into v from public.billing_accounts where owner_user_id = p_user;
  if not found then
    insert into public.billing_accounts (owner_user_id, billing_email, country)
    select p.id, p.email, 'IT' from public.profiles p where p.id = p_user
    returning * into v;
  end if;
  return v;
end $$;

-- Promozione B2B valida per piano/locale?
create or replace function public.billing_find_promotion(p_code text, p_plan text, p_restaurant uuid)
returns public.billing_promotions language plpgsql stable security definer set search_path = public as $$
declare v public.billing_promotions;
begin
  if nullif(trim(coalesce(p_code, '')), '') is null then return null; end if;
  select * into v from public.billing_promotions where code = upper(trim(p_code));
  if not found or not v.is_active or v.starts_at > now() or (v.ends_at is not null and v.ends_at <= now())
     or (v.max_redemptions is not null and v.redemptions_count >= v.max_redemptions)
     or (cardinality(v.applicable_plans) > 0 and not p_plan = any(v.applicable_plans))
     or exists (select 1 from public.billing_promotion_redemptions r where r.promotion_id = v.id and r.restaurant_id = p_restaurant) then
    raise exception 'PROMO_INVALID';
  end if;
  return v;
end $$;

-- Contesto del checkout: tutte le verifiche prima di contattare Stripe.
-- Il Price ID viene SEMPRE dal database, mai dal browser.
create or replace function public.billing_checkout_context(
  p_user uuid, p_restaurant uuid, p_plan text, p_interval text, p_env text, p_promo text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_rest record; v_plan public.subscription_plans; v_price text; v_acc public.billing_accounts;
  v_trial int; v_promo public.billing_promotions; v_existing record;
begin
  perform public.assert_service();
  if p_interval not in ('month', 'year') then return jsonb_build_object('ok', false, 'error', 'INVALID_INTERVAL'); end if;
  select id, name, slug, is_active into v_rest from public.restaurants where id = p_restaurant;
  if not found then return jsonb_build_object('ok', false, 'error', 'RESTAURANT_NOT_FOUND'); end if;
  if not public.user_can_bill(p_user, p_restaurant) then return jsonb_build_object('ok', false, 'error', 'FORBIDDEN'); end if;
  select * into v_plan from public.subscription_plans
   where (code = p_plan or id::text = p_plan) and is_active;
  if not found or v_plan.code = 'free' or coalesce(v_plan.monthly_price, 0) <= 0 then
    return jsonb_build_object('ok', false, 'error', 'INVALID_PLAN');
  end if;
  v_price := case p_interval when 'year' then v_plan.stripe_yearly_price_id else v_plan.stripe_monthly_price_id end;
  if v_price is null then return jsonb_build_object('ok', false, 'error', 'PRICE_NOT_CONFIGURED'); end if;

  select s.id, s.plan_code, s.status into v_existing from public.subscriptions s
   where s.restaurant_id = p_restaurant and s.source = 'stripe' and s.stripe_environment is not distinct from p_env
     and s.status in ('trialing', 'active', 'past_due', 'unpaid', 'paused')
   limit 1;
  if found then return jsonb_build_object('ok', false, 'error', 'ALREADY_SUBSCRIBED', 'plan', v_existing.plan_code); end if;

  begin
    v_promo := public.billing_find_promotion(p_promo, v_plan.code, p_restaurant);
  exception when others then
    return jsonb_build_object('ok', false, 'error', 'PROMO_INVALID');
  end;

  v_acc := public.billing_ensure_account(p_user);
  v_trial := case when v_plan.trial_enabled and public.billing_trial_eligible(p_restaurant, p_user)
                  then greatest(public.billing_setting_int('billing_trial_days', 30), 0) else 0 end;
  if v_promo.id is not null and v_promo.discount_type = 'free_days' then
    v_trial := least(greatest(v_trial, v_promo.free_days), 365);
  end if;

  return jsonb_build_object(
    'ok', true,
    'restaurant', jsonb_build_object('id', v_rest.id, 'name', v_rest.name, 'slug', v_rest.slug),
    'plan', jsonb_build_object('code', v_plan.code, 'name', v_plan.name, 'price_id', v_price, 'interval', p_interval,
                               'amount', case p_interval when 'year' then v_plan.yearly_price else v_plan.monthly_price end),
    'trial_days', v_trial,
    'require_payment_method', public.billing_setting_bool('billing_require_payment_method_for_trial', false),
    'account', jsonb_build_object(
      'id', v_acc.id,
      'stripe_customer_id', case when v_acc.stripe_environment is not distinct from p_env then v_acc.stripe_customer_id end,
      'email', v_acc.billing_email, 'business_name', v_acc.business_name, 'vat_number', v_acc.vat_number,
      'tax_code', v_acc.tax_code, 'pec', v_acc.pec, 'recipient_code', v_acc.recipient_code,
      'address_line', v_acc.address_line, 'postal_code', v_acc.postal_code, 'city', v_acc.city,
      'province', v_acc.province, 'country', v_acc.country),
    'promotion', case when v_promo.id is null then null else jsonb_build_object(
      'id', v_promo.id, 'code', v_promo.code, 'discount_type', v_promo.discount_type, 'discount_value', v_promo.discount_value,
      'duration', v_promo.duration, 'duration_in_months', v_promo.duration_in_months, 'free_days', v_promo.free_days,
      'stripe_coupon_id', v_promo.stripe_coupon_ids ->> p_env) end
  );
end $$;

-- Dopo la creazione del cliente Stripe (un cliente per account e per ambiente)
create or replace function public.billing_set_customer(p_account uuid, p_customer text, p_env text)
returns void language plpgsql security definer set search_path = public as $$
declare v_prev text;
begin
  perform public.assert_service();
  v_prev := public.internal_write_begin();
  update public.billing_accounts set stripe_customer_id = p_customer, stripe_environment = p_env where id = p_account;
  perform public.internal_write_end(v_prev);
end $$;

create or replace function public.billing_set_promotion_coupon(p_promotion uuid, p_env text, p_coupon text)
returns void language plpgsql security definer set search_path = public as $$
declare v_prev text;
begin
  perform public.assert_service();
  v_prev := public.internal_write_begin();
  update public.billing_promotions set stripe_coupon_ids = stripe_coupon_ids || jsonb_build_object(p_env, p_coupon) where id = p_promotion;
  perform public.internal_write_end(v_prev);
end $$;

-- Contesto per portale e azioni sull'abbonamento esistente
create or replace function public.billing_manage_context(p_user uuid, p_restaurant uuid, p_env text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_acc public.billing_accounts; v_sub public.subscriptions; v_plan public.subscription_plans;
begin
  perform public.assert_service();
  if not exists (select 1 from public.restaurants where id = p_restaurant) then
    return jsonb_build_object('ok', false, 'error', 'RESTAURANT_NOT_FOUND');
  end if;
  if not public.user_can_bill(p_user, p_restaurant) then return jsonb_build_object('ok', false, 'error', 'FORBIDDEN'); end if;
  select * into v_sub from public.subscriptions s
   where s.restaurant_id = p_restaurant and s.source = 'stripe' and s.stripe_environment is not distinct from p_env
   order by (s.status in ('trialing', 'active', 'past_due', 'unpaid', 'paused')) desc, s.created_at desc limit 1;
  select a.* into v_acc from public.billing_accounts a
   where a.id = coalesce(v_sub.billing_account_id, (select id from public.billing_accounts where owner_user_id = p_user));
  select * into v_plan from public.subscription_plans where code = v_sub.plan_code;
  return jsonb_build_object(
    'ok', true,
    'customer_id', case when v_acc.stripe_environment is not distinct from p_env then v_acc.stripe_customer_id end,
    'account_id', v_acc.id,
    'subscription', case when v_sub.id is null then null else jsonb_build_object(
      'id', v_sub.id, 'stripe_subscription_id', v_sub.stripe_subscription_id, 'stripe_schedule_id', v_sub.stripe_schedule_id,
      'status', v_sub.status, 'plan_code', v_sub.plan_code, 'plan_order', v_plan.sort_order, 'billing_interval', v_sub.billing_interval,
      'stripe_price_id', v_sub.stripe_price_id, 'current_period_end', v_sub.current_period_end,
      'cancel_at_period_end', v_sub.cancel_at_period_end, 'trial_end', v_sub.trial_end,
      'scheduled_plan_code', v_sub.scheduled_plan_code, 'scheduled_interval', v_sub.scheduled_interval) end
  );
end $$;

-- Cambio piano/intervallo: prezzo di destinazione dal DB e tipo di cambio
create or replace function public.billing_change_context(p_user uuid, p_restaurant uuid, p_plan text, p_interval text, p_env text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_ctx jsonb; v_cur public.subscription_plans; v_new public.subscription_plans; v_price text; v_kind text; v_sub jsonb;
begin
  v_ctx := public.billing_manage_context(p_user, p_restaurant, p_env);
  if not (v_ctx ->> 'ok')::boolean then return v_ctx; end if;
  v_sub := v_ctx -> 'subscription';
  if v_sub is null or (v_sub ->> 'status') not in ('trialing', 'active', 'past_due') then
    return jsonb_build_object('ok', false, 'error', 'SUBSCRIPTION_NOT_FOUND');
  end if;
  if p_interval not in ('month', 'year') then return jsonb_build_object('ok', false, 'error', 'INVALID_INTERVAL'); end if;
  select * into v_new from public.subscription_plans where (code = p_plan or id::text = p_plan) and is_active and code <> 'free';
  if not found then return jsonb_build_object('ok', false, 'error', 'INVALID_PLAN'); end if;
  v_price := case p_interval when 'year' then v_new.stripe_yearly_price_id else v_new.stripe_monthly_price_id end;
  if v_price is null then return jsonb_build_object('ok', false, 'error', 'PRICE_NOT_CONFIGURED'); end if;
  select * into v_cur from public.subscription_plans where code = v_sub ->> 'plan_code';
  if v_price = v_sub ->> 'stripe_price_id' then return jsonb_build_object('ok', false, 'error', 'SAME_PLAN'); end if;
  v_kind := case
    when v_new.sort_order > v_cur.sort_order then 'upgrade'
    when v_new.sort_order < v_cur.sort_order then 'downgrade'
    when p_interval = 'year' then 'interval_up'
    else 'interval_down' end;
  return v_ctx || jsonb_build_object(
    'kind', v_kind,
    'immediate', v_kind in ('upgrade', 'interval_up') or public.billing_setting_text('billing_downgrade_timing', 'period_end') = 'immediate'
                 or (v_sub ->> 'status') = 'trialing',
    'proration_behavior', public.billing_setting_text('billing_proration_behavior', 'always_invoice'),
    'target', jsonb_build_object('plan_code', v_new.code, 'plan_name', v_new.name, 'interval', p_interval, 'price_id', v_price,
                                 'amount', case p_interval when 'year' then v_new.yearly_price else v_new.monthly_price end));
end $$;

-- Evento webhook: 'process' se va elaborato, 'duplicate' se già fatto,
-- 'in_progress' se un'altra consegna dello stesso evento è in corso (Stripe ritenterà)
create or replace function public.billing_event_begin(p_event_id text, p_type text, p_env text, p_object_id text)
returns text language plpgsql security definer set search_path = public as $$
declare v public.stripe_events;
begin
  perform public.assert_service();
  insert into public.stripe_events (stripe_event_id, event_type, stripe_environment, object_id)
  values (p_event_id, left(p_type, 80), p_env, left(p_object_id, 80))
  on conflict (stripe_event_id) do nothing
  returning * into v;
  if found then return 'process'; end if;
  select * into v from public.stripe_events where stripe_event_id = p_event_id for update;
  if v.processing_status in ('processed', 'ignored') then return 'duplicate'; end if;
  if v.processing_status = 'processing' and v.last_attempt_at > now() - interval '2 minutes' then return 'in_progress'; end if;
  update public.stripe_events set attempts = attempts + 1, processing_status = 'processing', error_message = null, last_attempt_at = now()
   where id = v.id;
  return 'process';
end $$;

create or replace function public.billing_event_finish(p_event_id text, p_status text, p_error text default null, p_restaurant uuid default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  update public.stripe_events
     set processing_status = p_status, error_message = left(p_error, 500), processed_at = now(),
         restaurant_id = coalesce(p_restaurant, restaurant_id)
   where stripe_event_id = p_event_id;
end $$;

-- Sincronizzazione di un abbonamento letto da Stripe (webhook, sync, ritorno dal checkout).
-- Idempotente: riapplicare lo stesso stato non genera eventi duplicati.
create or replace function public.billing_upsert_subscription(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_old public.subscriptions; v_new public.subscriptions; v_plan public.subscription_plans; v_old_plan public.subscription_plans;
  v_rest uuid := nullif(p ->> 'restaurant_id', '')::uuid;
  v_price text := p ->> 'price_id';
  v_interval text := coalesce(p ->> 'interval', 'month');
  v_status public.subscription_status := (p ->> 'status')::public.subscription_status;
  v_acc uuid; v_user uuid; v_ts timestamptz := now(); v_is_new boolean;
begin
  perform public.assert_service();
  if coalesce(p ->> 'stripe_subscription_id', '') !~ '^sub_[A-Za-z0-9]+$' then raise exception 'SUBSCRIPTION_ID_INVALID'; end if;
  select * into v_old from public.subscriptions where stripe_subscription_id = p ->> 'stripe_subscription_id' for update;
  v_is_new := not found;
  v_rest := coalesce(v_old.restaurant_id, v_rest);
  if v_rest is null or not exists (select 1 from public.restaurants where id = v_rest) then
    return jsonb_build_object('ok', false, 'error', 'RESTAURANT_UNKNOWN');
  end if;
  -- Piano dal Price ID (fonte autorevole); in mancanza dal metadata, poi dallo stato precedente
  select * into v_plan from public.subscription_plans where stripe_monthly_price_id = v_price or stripe_yearly_price_id = v_price limit 1;
  if found then
    v_interval := case when v_plan.stripe_yearly_price_id = v_price then 'year' else 'month' end;
  else
    select * into v_plan from public.subscription_plans where code = coalesce(v_old.plan_code, p ->> 'plan_code');
    if not found then return jsonb_build_object('ok', false, 'error', 'PLAN_UNKNOWN'); end if;
  end if;
  select id, owner_user_id into v_acc, v_user from public.billing_accounts
   where stripe_customer_id = p ->> 'customer_id' or id = nullif(p ->> 'billing_account_id', '')::uuid
   order by (stripe_customer_id = p ->> 'customer_id') desc nulls last limit 1;
  -- Intestatario per il registro anti-abuso delle prove: metadata → account → titolare del locale
  v_user := coalesce(nullif(p ->> 'user_id', '')::uuid, v_user,
    (select m.user_id from public.restaurant_members m where m.restaurant_id = v_rest and m.role = 'owner' and m.status = 'active'
      order by m.created_at limit 1));

  if v_is_new then
    insert into public.subscriptions (
      restaurant_id, user_id, billing_account_id, plan_code, status, source, billing_interval,
      stripe_customer_id, stripe_subscription_id, stripe_price_id, stripe_environment,
      trial_start, trial_end, current_period_start, current_period_end, cancel_at_period_end, cancelled_at, ended_at,
      unit_amount_cents, currency, pm_brand, pm_last4, pm_exp_month, pm_exp_year, latest_invoice_id, latest_invoice_status,
      stripe_schedule_id, last_synced_at)
    values (
      v_rest, v_user, v_acc, v_plan.code, v_status, 'stripe', v_interval,
      p ->> 'customer_id', p ->> 'stripe_subscription_id', v_price, p ->> 'environment',
      (p ->> 'trial_start')::timestamptz, (p ->> 'trial_end')::timestamptz,
      coalesce((p ->> 'current_period_start')::timestamptz, v_ts), (p ->> 'current_period_end')::timestamptz,
      coalesce((p ->> 'cancel_at_period_end')::boolean, false), (p ->> 'canceled_at')::timestamptz, (p ->> 'ended_at')::timestamptz,
      (p ->> 'unit_amount')::int, upper(coalesce(p ->> 'currency', 'EUR')), p ->> 'pm_brand', p ->> 'pm_last4',
      (p ->> 'pm_exp_month')::smallint, (p ->> 'pm_exp_year')::smallint, p ->> 'latest_invoice_id', p ->> 'latest_invoice_status',
      p ->> 'schedule_id', now())
    returning * into v_new;
  else
    update public.subscriptions set
      plan_code = v_plan.code, status = v_status, billing_interval = v_interval,
      billing_account_id = coalesce(v_acc, billing_account_id),
      stripe_customer_id = coalesce(p ->> 'customer_id', stripe_customer_id), stripe_price_id = coalesce(v_price, stripe_price_id),
      stripe_environment = coalesce(p ->> 'environment', stripe_environment),
      trial_start = (p ->> 'trial_start')::timestamptz, trial_end = (p ->> 'trial_end')::timestamptz,
      current_period_start = coalesce((p ->> 'current_period_start')::timestamptz, current_period_start),
      current_period_end = coalesce((p ->> 'current_period_end')::timestamptz, current_period_end),
      cancel_at_period_end = coalesce((p ->> 'cancel_at_period_end')::boolean, false),
      cancelled_at = (p ->> 'canceled_at')::timestamptz, ended_at = (p ->> 'ended_at')::timestamptz,
      unit_amount_cents = coalesce((p ->> 'unit_amount')::int, unit_amount_cents),
      currency = upper(coalesce(p ->> 'currency', currency)),
      pm_brand = coalesce(p ->> 'pm_brand', pm_brand), pm_last4 = coalesce(p ->> 'pm_last4', pm_last4),
      pm_exp_month = coalesce((p ->> 'pm_exp_month')::smallint, pm_exp_month), pm_exp_year = coalesce((p ->> 'pm_exp_year')::smallint, pm_exp_year),
      latest_invoice_id = coalesce(p ->> 'latest_invoice_id', latest_invoice_id),
      latest_invoice_status = coalesce(p ->> 'latest_invoice_status', latest_invoice_status),
      stripe_schedule_id = p ->> 'schedule_id',
      scheduled_plan_code = case when p ->> 'schedule_id' is null then null else scheduled_plan_code end,
      scheduled_interval = case when p ->> 'schedule_id' is null then null else scheduled_interval end,
      scheduled_change_at = case when p ->> 'schedule_id' is null then null else scheduled_change_at end,
      last_synced_at = now()
    where id = v_old.id
    returning * into v_new;
  end if;

  -- Registro prove: fine prova aggiornata (estensioni Admin, conversione o cancellazione)
  if v_status = 'trialing' then
    update public.billing_trials set ends_at = v_new.trial_end where restaurant_id = v_rest and subscription_id = v_new.id;
  elsif not v_is_new and v_old.status = 'trialing' then
    update public.billing_trials set ends_at = least(coalesce(ends_at, now()), now()) where restaurant_id = v_rest and subscription_id = v_new.id;
  end if;

  -- ─── Transizioni → eventi interni, notifiche, email (solo quando cambia qualcosa) ───
  if v_is_new then
    if v_status = 'trialing' then
      insert into public.billing_trials (restaurant_id, user_id, billing_account_id, vat_number, plan_code, subscription_id, started_at, ends_at)
      select v_rest, v_new.user_id, v_acc, (select vat_number from public.billing_accounts where id = v_acc), v_plan.code, v_new.id,
             coalesce(v_new.trial_start, now()), v_new.trial_end
      on conflict (restaurant_id) do nothing;
      perform public.billing_log(v_rest, v_new.id, 'trial_started', jsonb_build_object('plan', v_plan.code, 'trial_end', v_new.trial_end));
      perform public.billing_notify(v_rest, v_new.id, 'billing_trial_started', format('Prova %s attivata', v_plan.name),
        format('La prova gratuita del piano %s è attiva fino al %s.', v_plan.name, to_char(v_new.trial_end at time zone 'Europe/Rome', 'DD/MM/YYYY')),
        jsonb_build_object('plan', v_plan.name, 'trial_end', v_new.trial_end));
    elsif v_status = 'active' then
      perform public.billing_log(v_rest, v_new.id, 'subscription_started', jsonb_build_object('plan', v_plan.code, 'interval', v_interval));
      perform public.billing_notify(v_rest, v_new.id, 'billing_subscription_activated', format('Abbonamento %s attivato', v_plan.name),
        format('Il piano %s è attivo. Benvenuto in %s Business!', v_plan.name, 'AsiaFood'),
        jsonb_build_object('plan', v_plan.name, 'interval', v_interval));
    end if;
  else
    select * into v_old_plan from public.subscription_plans where code = v_old.plan_code;
    if v_old.status = 'trialing' and v_status = 'active' then
      update public.billing_trials set converted_at = coalesce(converted_at, now()) where restaurant_id = v_rest;
      perform public.billing_log(v_rest, v_new.id, 'trial_ended', jsonb_build_object('converted', true));
      perform public.billing_log(v_rest, v_new.id, 'subscription_started', jsonb_build_object('plan', v_plan.code, 'interval', v_interval));
      perform public.billing_notify(v_rest, v_new.id, 'billing_subscription_activated', format('Abbonamento %s attivato', v_plan.name),
        format('La prova è terminata e il piano %s è ora attivo.', v_plan.name), jsonb_build_object('plan', v_plan.name));
    elsif v_old.status = 'trialing' and v_status in ('canceled', 'incomplete_expired', 'paused', 'unpaid') then
      perform public.billing_log(v_rest, v_new.id, 'trial_ended', jsonb_build_object('converted', false, 'status', v_status));
      perform public.billing_notify(v_rest, v_new.id, null, 'Prova gratuita terminata',
        'La prova è terminata: il locale è tornato al piano Free. Puoi attivare un piano in qualsiasi momento.');
    elsif v_old.status in ('incomplete') and v_status = 'active' then
      perform public.billing_log(v_rest, v_new.id, 'subscription_started', jsonb_build_object('plan', v_plan.code, 'interval', v_interval));
      perform public.billing_notify(v_rest, v_new.id, 'billing_subscription_activated', format('Abbonamento %s attivato', v_plan.name),
        format('Il piano %s è attivo.', v_plan.name), jsonb_build_object('plan', v_plan.name));
    end if;
    if v_old_plan.code is distinct from v_plan.code then
      perform public.billing_log(v_rest, v_new.id,
        case when v_plan.sort_order > v_old_plan.sort_order then 'subscription_upgraded' else 'subscription_downgraded' end,
        jsonb_build_object('from', v_old_plan.code, 'to', v_plan.code));
      perform public.billing_notify(v_rest, v_new.id, null, format('Piano aggiornato: %s', v_plan.name),
        format('Il locale è passato dal piano %s al piano %s.', v_old_plan.name, v_plan.name));
    elsif v_old.billing_interval is distinct from v_interval then
      perform public.billing_log(v_rest, v_new.id, 'interval_changed', jsonb_build_object('from', v_old.billing_interval, 'to', v_interval));
    end if;
    if not v_old.cancel_at_period_end and v_new.cancel_at_period_end and v_status <> 'canceled' then
      perform public.billing_log(v_rest, v_new.id, 'subscription_cancelled', jsonb_build_object('until', v_new.current_period_end));
      perform public.billing_notify(v_rest, v_new.id, 'billing_subscription_cancelled', 'Abbonamento cancellato',
        format('Potrai continuare a usare %s fino al %s.', v_plan.name, to_char(v_new.current_period_end at time zone 'Europe/Rome', 'DD/MM/YYYY')),
        jsonb_build_object('plan', v_plan.name, 'until', v_new.current_period_end));
    elsif v_old.cancel_at_period_end and not v_new.cancel_at_period_end and v_status in ('active', 'trialing') then
      perform public.billing_log(v_rest, v_new.id, 'subscription_resumed', '{}'::jsonb);
      perform public.billing_notify(v_rest, v_new.id, null, 'Abbonamento riattivato', format('Il piano %s si rinnoverà regolarmente.', v_plan.name));
    end if;
    if v_old.status <> 'canceled' and v_status = 'canceled' then
      perform public.billing_log(v_rest, v_new.id, 'subscription_ended', jsonb_build_object('plan', v_plan.code));
      if not v_old.cancel_at_period_end and v_old.status <> 'trialing' then
        perform public.billing_notify(v_rest, v_new.id, 'billing_subscription_cancelled', 'Abbonamento terminato',
          format('L''abbonamento %s è terminato.', v_plan.name), jsonb_build_object('plan', v_plan.name));
      end if;
    end if;
  end if;

  -- Più abbonamenti Stripe attivi sullo stesso locale: segnalato all'Admin (nessun rimborso automatico)
  if v_status in ('trialing', 'active') and exists (
    select 1 from public.subscriptions s where s.restaurant_id = v_rest and s.source = 'stripe' and s.id <> v_new.id
      and s.status in ('trialing', 'active', 'past_due') and s.stripe_environment is not distinct from v_new.stripe_environment) then
    if not exists (select 1 from public.billing_activity where subscription_id = v_new.id and event = 'duplicate_subscription') then
      perform public.billing_log(v_rest, v_new.id, 'duplicate_subscription', jsonb_build_object('stripe_subscription_id', v_new.stripe_subscription_id));
      perform public.notify_admins('billing', 'Abbonamento duplicato', 'Un locale ha più abbonamenti Stripe attivi: verifica in Admin → Abbonamenti.', '/admin/subscriptions');
    end if;
  end if;

  return jsonb_build_object('ok', true, 'id', v_new.id, 'restaurant_id', v_rest, 'plan_code', v_plan.code, 'status', v_status,
                            'created', v_is_new, 'effective_plan', public.restaurant_effective_plan(v_rest));
end $$;

-- Downgrade/cambio a fine periodo pianificato su Stripe (Subscription Schedule).
-- Il piano di destinazione si ricava dal Price ID (vale anche per cambi fatti dal Customer Portal).
create or replace function public.billing_set_scheduled_change(p_stripe_sub text, p_schedule text, p_price text, p_at timestamptz)
returns void language plpgsql security definer set search_path = public as $$
declare v public.subscriptions; v_plan public.subscription_plans; v_interval text;
begin
  perform public.assert_service();
  if p_price is not null then
    select * into v_plan from public.subscription_plans where stripe_monthly_price_id = p_price or stripe_yearly_price_id = p_price;
    v_interval := case when v_plan.stripe_yearly_price_id = p_price then 'year' when v_plan.code is not null then 'month' end;
  end if;
  select * into v from public.subscriptions where stripe_subscription_id = p_stripe_sub;
  if not found then return; end if;
  if v.scheduled_plan_code is not distinct from v_plan.code and v.scheduled_interval is not distinct from v_interval
     and v.stripe_schedule_id is not distinct from p_schedule then
    return;  -- nessun cambiamento (idempotente)
  end if;
  update public.subscriptions
     set stripe_schedule_id = p_schedule, scheduled_plan_code = v_plan.code, scheduled_interval = v_interval,
         scheduled_change_at = case when v_plan.code is null then null else p_at end
   where id = v.id;
  perform public.billing_log(v.restaurant_id, v.id, case when v_plan.code is null then 'change_cancelled' else 'change_scheduled' end,
    jsonb_build_object('plan', v_plan.code, 'interval', v_interval, 'at', p_at));
end $$;

-- Piani da creare/aggiornare su Stripe (azione Admin "Crea prezzi su Stripe")
create or replace function public.billing_plans_for_provisioning()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('code', code, 'name', name, 'description', description,
    'monthly_price', monthly_price, 'yearly_price', yearly_price, 'currency', currency,
    'stripe_product_id', stripe_product_id, 'stripe_monthly_price_id', stripe_monthly_price_id,
    'stripe_yearly_price_id', stripe_yearly_price_id) order by sort_order), '[]'::jsonb)
  from public.subscription_plans where code <> 'free' and is_active and monthly_price > 0;
$$;

-- Fatture (lette da Stripe): pagamento riuscito/fallito, tolleranza, recupero
create or replace function public.billing_record_invoice(p jsonb, p_event text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_sub public.subscriptions; v_inv public.billing_invoices; v_was_failed boolean; v_plan text;
begin
  perform public.assert_service();
  if coalesce(p ->> 'id', '') !~ '^in_[A-Za-z0-9]+$' then raise exception 'INVOICE_ID_INVALID'; end if;
  select * into v_sub from public.subscriptions where stripe_subscription_id = p ->> 'subscription_id';
  insert into public.billing_invoices (stripe_invoice_id, subscription_id, restaurant_id, billing_account_id, stripe_customer_id, number, status,
    amount_due_cents, amount_paid_cents, currency, hosted_invoice_url, invoice_pdf, period_start, period_end, stripe_created_at, stripe_environment)
  values (p ->> 'id', v_sub.id, coalesce(v_sub.restaurant_id, nullif(p ->> 'restaurant_id', '')::uuid), v_sub.billing_account_id,
    p ->> 'customer_id', p ->> 'number', coalesce(p ->> 'status', 'open'),
    coalesce((p ->> 'amount_due')::int, 0), coalesce((p ->> 'amount_paid')::int, 0), upper(coalesce(p ->> 'currency', 'EUR')),
    p ->> 'hosted_invoice_url', p ->> 'invoice_pdf', (p ->> 'period_start')::timestamptz, (p ->> 'period_end')::timestamptz,
    coalesce((p ->> 'created')::timestamptz, now()), p ->> 'environment')
  on conflict (stripe_invoice_id) do update set
    status = excluded.status, number = coalesce(excluded.number, billing_invoices.number),
    amount_due_cents = excluded.amount_due_cents, amount_paid_cents = excluded.amount_paid_cents,
    hosted_invoice_url = coalesce(excluded.hosted_invoice_url, billing_invoices.hosted_invoice_url),
    invoice_pdf = coalesce(excluded.invoice_pdf, billing_invoices.invoice_pdf),
    subscription_id = coalesce(billing_invoices.subscription_id, excluded.subscription_id),
    restaurant_id = coalesce(billing_invoices.restaurant_id, excluded.restaurant_id),
    updated_at = now()
  returning * into v_inv;

  if v_sub.id is null then return jsonb_build_object('ok', true, 'invoice_id', v_inv.id, 'subscription', null); end if;
  v_plan := (select name from public.subscription_plans where code = v_sub.plan_code);
  v_was_failed := v_sub.payment_failed_at is not null;

  if p_event = 'invoice.paid' then
    update public.subscriptions set payment_failed_at = null, latest_invoice_id = v_inv.stripe_invoice_id, latest_invoice_status = 'paid',
           paid_started_at = case when paid_started_at is null and v_inv.amount_paid_cents > 0 then now() else paid_started_at end
     where id = v_sub.id;
    if v_inv.amount_paid_cents > 0 and not exists (
      select 1 from public.billing_activity where subscription_id = v_sub.id and event in ('payment_succeeded', 'payment_recovered') and data ->> 'invoice' = v_inv.stripe_invoice_id) then
      if v_was_failed then
        perform public.billing_log(v_sub.restaurant_id, v_sub.id, 'payment_recovered', jsonb_build_object('invoice', v_inv.stripe_invoice_id));
        perform public.billing_notify(v_sub.restaurant_id, v_sub.id, 'billing_payment_succeeded', 'Pagamento ricevuto',
          format('Il pagamento del piano %s è andato a buon fine. Grazie!', v_plan),
          jsonb_build_object('amount_cents', v_inv.amount_paid_cents, 'invoice_url', v_inv.hosted_invoice_url));
      else
        perform public.billing_log(v_sub.restaurant_id, v_sub.id, 'payment_succeeded', jsonb_build_object('invoice', v_inv.stripe_invoice_id, 'amount_cents', v_inv.amount_paid_cents));
        perform public.billing_notify(v_sub.restaurant_id, v_sub.id, 'billing_payment_succeeded', 'Pagamento ricevuto',
          format('Abbiamo ricevuto il pagamento del piano %s.', v_plan),
          jsonb_build_object('amount_cents', v_inv.amount_paid_cents, 'invoice_url', v_inv.hosted_invoice_url));
      end if;
    end if;
  elsif p_event = 'invoice.payment_failed' then
    update public.subscriptions set payment_failed_at = coalesce(payment_failed_at, now()), latest_invoice_id = v_inv.stripe_invoice_id,
           latest_invoice_status = v_inv.status
     where id = v_sub.id;
    if not exists (select 1 from public.billing_activity where subscription_id = v_sub.id and event = 'payment_failed' and data ->> 'invoice' = v_inv.stripe_invoice_id) then
      perform public.billing_log(v_sub.restaurant_id, v_sub.id, 'payment_failed', jsonb_build_object('invoice', v_inv.stripe_invoice_id));
      perform public.billing_notify(v_sub.restaurant_id, v_sub.id, 'billing_payment_failed', 'Problema con il pagamento del tuo abbonamento',
        format('Non siamo riusciti ad addebitare il piano %s. Aggiorna il metodo di pagamento: le funzioni restano attive per %s giorni.',
               v_plan, public.billing_setting_int('billing_payment_grace_period_days', 3)),
        jsonb_build_object('invoice_url', v_inv.hosted_invoice_url));
    end if;
  elsif p_event = 'invoice.payment_action_required' then
    if not exists (select 1 from public.billing_activity where subscription_id = v_sub.id and event = 'payment_action_required' and data ->> 'invoice' = v_inv.stripe_invoice_id) then
      perform public.billing_log(v_sub.restaurant_id, v_sub.id, 'payment_action_required', jsonb_build_object('invoice', v_inv.stripe_invoice_id));
      perform public.billing_notify(v_sub.restaurant_id, v_sub.id, null, 'Conferma il pagamento',
        'La tua banca richiede una conferma (3D Secure) per completare il pagamento. Apri la fattura per confermare.');
    end if;
  end if;
  perform public.refresh_restaurant_plan(v_sub.restaurant_id);
  return jsonb_build_object('ok', true, 'invoice_id', v_inv.id, 'restaurant_id', v_sub.restaurant_id);
end $$;

-- Promozione usata (al completamento del checkout)
create or replace function public.billing_redeem_promotion(p_promotion uuid, p_restaurant uuid, p_user uuid, p_stripe_sub text)
returns void language plpgsql security definer set search_path = public as $$
declare v_prev text;
begin
  perform public.assert_service();
  insert into public.billing_promotion_redemptions (promotion_id, restaurant_id, user_id, stripe_subscription_id)
  values (p_promotion, p_restaurant, p_user, p_stripe_sub)
  on conflict (promotion_id, restaurant_id) do nothing;
  if found then
    v_prev := public.internal_write_begin();
    update public.billing_promotions set redemptions_count = redemptions_count + 1 where id = p_promotion;
    perform public.internal_write_end(v_prev);
  end if;
end $$;

-- Avviso fine prova (cron orario + evento Stripe trial_will_end), una sola volta per abbonamento
create or replace function public.billing_trial_expiring(p_stripe_sub text default null)
returns int language plpgsql security definer set search_path = public as $$
declare r record; v_n int := 0; v_days int := public.billing_setting_int('billing_trial_expiring_days', 3);
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  for r in
    select s.*, p.name as plan_name from public.subscriptions s join public.subscription_plans p on p.code = s.plan_code
    where s.status = 'trialing' and s.trial_expiring_notified_at is null and s.trial_end is not null
      and s.trial_end > now() and s.trial_end <= now() + make_interval(days => v_days)
      and (p_stripe_sub is null or s.stripe_subscription_id = p_stripe_sub)
  loop
    update public.subscriptions set trial_expiring_notified_at = now() where id = r.id;
    perform public.billing_log(r.restaurant_id, r.id, 'trial_expiring', jsonb_build_object('trial_end', r.trial_end));
    perform public.billing_notify(r.restaurant_id, r.id, 'billing_trial_ending',
      format('La prova %s sta per terminare', r.plan_name),
      format('Mancano %s giorni alla fine della prova %s.', greatest(1, ceil(extract(epoch from r.trial_end - now()) / 86400)::int), r.plan_name),
      jsonb_build_object('plan', r.plan_name, 'trial_end', r.trial_end, 'has_payment_method', r.pm_last4 is not null));
    v_n := v_n + 1;
  end loop;
  return v_n;
end $$;

-- Prezzi creati dal backend su Stripe ("Crea prezzi su Stripe" in Admin → Piani)
create or replace function public.billing_set_plan_stripe_ids(p_plan text, p_product text, p_monthly text, p_yearly text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  update public.subscription_plans
     set stripe_product_id = coalesce(p_product, stripe_product_id),
         stripe_monthly_price_id = coalesce(p_monthly, stripe_monthly_price_id),
         stripe_yearly_price_id = coalesce(p_yearly, stripe_yearly_price_id)
   where code = p_plan;
end $$;

-- Operazioni Admin che passano da Stripe (sync, estensione prova): contesto verificato
create or replace function public.billing_admin_context(p_user uuid, p_subscription uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v public.subscriptions;
begin
  perform public.assert_service();
  if not exists (select 1 from public.profiles where id = p_user and role = 'admin' and not is_blocked) then
    return jsonb_build_object('ok', false, 'error', 'FORBIDDEN');
  end if;
  if p_subscription is null then return jsonb_build_object('ok', true); end if;
  select * into v from public.subscriptions where id = p_subscription;
  if not found then return jsonb_build_object('ok', false, 'error', 'SUBSCRIPTION_NOT_FOUND'); end if;
  return jsonb_build_object('ok', true, 'id', v.id, 'restaurant_id', v.restaurant_id, 'source', v.source,
    'stripe_subscription_id', v.stripe_subscription_id, 'stripe_environment', v.stripe_environment, 'status', v.status,
    'trial_end', v.trial_end);
end $$;

create or replace function public.billing_stripe_subscription_ids(p_env text)
returns setof text language sql stable security definer set search_path = public as $$
  select stripe_subscription_id from public.subscriptions
  where source = 'stripe' and stripe_environment is not distinct from p_env
    and status not in ('canceled', 'incomplete_expired') and coalesce(auth.uid()::text, '') = '';
$$;

-- ════════════════════════════════════════════════════════════════════
--  7. RPC ADMIN (piani manuali, nessuna finta subscription Stripe)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.admin_grant_plan(
  p_restaurant uuid, p_plan text, p_expires_at timestamptz default null, p_source text default 'manual', p_note text default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p_source not in ('manual', 'admin', 'promo') then raise exception 'Origine non valida'; end if;
  if not exists (select 1 from public.subscription_plans where code = p_plan) then raise exception 'Piano non valido'; end if;
  if p_expires_at is not null and p_expires_at <= now() then raise exception 'La scadenza deve essere futura'; end if;
  -- Una sola concessione attiva per locale: la precedente viene revocata
  update public.subscriptions set revoked_at = now(), status = 'canceled', ended_at = now()
   where restaurant_id = p_restaurant and source <> 'stripe' and revoked_at is null;
  if p_plan = 'free' then
    perform public.billing_log(p_restaurant, null, 'plan_revoked', jsonb_build_object('by', auth.uid()));
    return null;
  end if;
  insert into public.subscriptions (restaurant_id, plan_code, status, source, billing_interval, current_period_start,
    current_period_end, expires_at, granted_by, notes, user_id)
  values (p_restaurant, p_plan, 'active', p_source::public.subscription_source, 'month', now(), p_expires_at, p_expires_at, auth.uid(),
    left(p_note, 500), (select user_id from public.restaurant_members where restaurant_id = p_restaurant and role = 'owner' and status = 'active' limit 1))
  returning id into v_id;
  perform public.billing_log(p_restaurant, v_id, 'plan_granted',
    jsonb_build_object('plan', p_plan, 'source', p_source, 'expires_at', p_expires_at, 'by', auth.uid()));
  perform public.billing_notify(p_restaurant, v_id, null, format('Piano %s attivato', initcap(p_plan)),
    case when p_expires_at is null then 'Il piano è stato attivato dallo staff.'
         else format('Il piano è stato attivato dallo staff fino al %s.', to_char(p_expires_at at time zone 'Europe/Rome', 'DD/MM/YYYY')) end);
  return v_id;
end $$;

create or replace function public.admin_revoke_plan(p_subscription uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v public.subscriptions;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into v from public.subscriptions where id = p_subscription;
  if not found then raise exception 'Abbonamento non trovato'; end if;
  if v.source = 'stripe' then raise exception 'Gli abbonamenti Stripe si cancellano da Stripe'; end if;
  update public.subscriptions set revoked_at = now(), status = 'canceled', ended_at = now() where id = p_subscription;
  perform public.billing_log(v.restaurant_id, v.id, 'plan_revoked', jsonb_build_object('plan', v.plan_code, 'by', auth.uid()));
end $$;

create or replace function public.admin_extend_manual_plan(p_subscription uuid, p_expires_at timestamptz)
returns void language plpgsql security definer set search_path = public as $$
declare v public.subscriptions;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into v from public.subscriptions where id = p_subscription;
  if not found or v.source = 'stripe' then raise exception 'Solo piani manuali o promozionali'; end if;
  if p_expires_at is not null and p_expires_at <= now() then raise exception 'La scadenza deve essere futura'; end if;
  update public.subscriptions set expires_at = p_expires_at, current_period_end = p_expires_at, status = 'active', revoked_at = null, ended_at = null
   where id = p_subscription;
  perform public.billing_log(v.restaurant_id, v.id, 'trial_extended', jsonb_build_object('expires_at', p_expires_at, 'by', auth.uid()));
end $$;

-- ════════════════════════════════════════════════════════════════════
--  8. VISTA FATTURAZIONE DEL RISTORATORE (lettura primaria: nessuna chiamata a Stripe)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.get_billing_overview(p_restaurant uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_eff public.subscriptions; v_stripe public.subscriptions; v_plan text; v_can boolean; v_env text;
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  v_plan := public.refresh_restaurant_plan(p_restaurant);  -- aggiornamento pigro della cache
  v_env := public.billing_setting_text('billing_stripe_environment', null);
  v_eff := public.restaurant_effective_subscription(p_restaurant);
  select * into v_stripe from public.subscriptions s
   where s.restaurant_id = p_restaurant and s.source = 'stripe' and (v_env is null or s.stripe_environment is not distinct from v_env)
   order by (s.status in ('trialing', 'active', 'past_due', 'unpaid', 'paused')) desc, s.created_at desc limit 1;
  v_can := public.is_admin() or exists (select 1 from public.restaurant_members m where m.restaurant_id = p_restaurant
            and m.user_id = auth.uid() and m.status = 'active' and m.role = 'owner');
  return jsonb_build_object(
    'effective_plan', v_plan,
    'effective', case when v_eff.id is null then null else to_jsonb(v_eff) - 'notes' - 'granted_by' end,
    'stripe', case when v_stripe.id is null then null else to_jsonb(v_stripe) - 'notes' - 'granted_by' end,
    'can_manage_billing', v_can,
    'trial_eligible', public.billing_trial_eligible(p_restaurant, auth.uid()),
    'trial_days', public.billing_setting_int('billing_trial_days', 30),
    'require_payment_method_for_trial', public.billing_setting_bool('billing_require_payment_method_for_trial', false),
    'grace_days', public.billing_setting_int('billing_payment_grace_period_days', 3),
    'trial_expiring_days', public.billing_setting_int('billing_trial_expiring_days', 3),
    'invoices', coalesce((select jsonb_agg(to_jsonb(i) - 'stripe_customer_id' order by i.stripe_created_at desc)
                          from (select * from public.billing_invoices where restaurant_id = p_restaurant
                                order by stripe_created_at desc limit 24) i), '[]'::jsonb),
    'activity', coalesce((select jsonb_agg(jsonb_build_object('event', a.event, 'data', a.data - 'by', 'created_at', a.created_at) order by a.created_at desc)
                          from (select * from public.billing_activity where restaurant_id = p_restaurant and event <> 'email_error'
                                order by created_at desc limit 20) a), '[]'::jsonb)
  );
end $$;

-- ════════════════════════════════════════════════════════════════════
--  9. ONBOARDING E COMPLETAMENTO PROFILO (calcolato, mai manuale)
-- ════════════════════════════════════════════════════════════════════
alter table public.restaurants add column if not exists onboarding_completed_at timestamptz;
alter table public.restaurants add column if not exists publication_requested_at timestamptz;

create or replace function public.restaurant_profile_completion(p_restaurant uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare r public.restaurants; v_items jsonb; v_done int; v_total int;
begin
  select * into r from public.restaurants where id = p_restaurant;
  if not found then return null; end if;
  if not (public.can_manage_restaurant(p_restaurant) or auth.uid() is null) then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  v_items := jsonb_build_array(
    jsonb_build_object('key', 'name', 'done', nullif(trim(r.name), '') is not null, 'available', true),
    jsonb_build_object('key', 'phone', 'done', nullif(trim(coalesce(r.phone, '')), '') is not null, 'available', true),
    jsonb_build_object('key', 'address', 'done', nullif(trim(coalesce(r.address, '')), '') is not null, 'available', true),
    jsonb_build_object('key', 'logo', 'done', r.logo_url is not null, 'available', true),
    jsonb_build_object('key', 'cover', 'done', r.cover_url is not null, 'available', true),
    jsonb_build_object('key', 'hours', 'done', exists (select 1 from public.restaurant_hours h where h.restaurant_id = r.id), 'available', true),
    jsonb_build_object('key', 'categories', 'done', exists (select 1 from public.restaurant_categories c where c.restaurant_id = r.id), 'available', true),
    jsonb_build_object('key', 'menu', 'done', exists (select 1 from public.menu_items i where i.restaurant_id = r.id),
                       'available', public.restaurant_has_feature(r.id, 'menu_enabled'), 'feature', 'menu_enabled'),
    jsonb_build_object('key', 'photos', 'done', exists (select 1 from public.restaurant_images i where i.restaurant_id = r.id), 'available', true),
    jsonb_build_object('key', 'offer', 'done', exists (select 1 from public.offers o where o.restaurant_id = r.id and o.is_active),
                       'available', public.restaurant_has_feature(r.id, 'offers_enabled'), 'feature', 'offers_enabled'),
    jsonb_build_object('key', 'reservations', 'done', exists (select 1 from public.reservation_settings s where s.restaurant_id = r.id and s.reservation_enabled),
                       'available', public.restaurant_has_feature(r.id, 'reservations_enabled'), 'feature', 'reservations_enabled')
  );
  select count(*) filter (where (x ->> 'done')::boolean and (x ->> 'available')::boolean),
         count(*) filter (where (x ->> 'available')::boolean)
    into v_done, v_total from jsonb_array_elements(v_items) x;
  return jsonb_build_object('items', v_items, 'done', v_done, 'total', v_total,
    'profile_completion_percentage', case when v_total = 0 then 0 else round(v_done * 100.0 / v_total)::int end,
    'onboarding_completed_at', r.onboarding_completed_at, 'is_active', r.is_active,
    'publication_requested_at', r.publication_requested_at);
end $$;

create or replace function public.complete_onboarding(p_restaurant uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  update public.restaurants set onboarding_completed_at = coalesce(onboarding_completed_at, now()) where id = p_restaurant;
end $$;

-- Pubblicazione: il titolare la richiede, l'Admin approva (is_active resta un campo riservato)
create or replace function public.request_publication(p_restaurant uuid)
returns text language plpgsql security definer set search_path = public as $$
declare r public.restaurants;
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into r from public.restaurants where id = p_restaurant;
  if r.is_active then return 'already_public'; end if;
  if r.publication_requested_at is not null and r.publication_requested_at > now() - interval '1 day' then return 'already_requested'; end if;
  if nullif(trim(coalesce(r.phone, '')), '') is null or nullif(trim(coalesce(r.address, '')), '') is null then
    raise exception 'Completa telefono e indirizzo prima di pubblicare';
  end if;
  update public.restaurants set publication_requested_at = now() where id = p_restaurant;
  perform public.notify_admins('publication', 'Richiesta di pubblicazione', format('%s chiede di essere pubblicato', r.name),
    format('/admin/restaurants/%s', p_restaurant));
  return 'requested';
end $$;

-- ════════════════════════════════════════════════════════════════════
--  10. SPONSORIZZAZIONI (AsiaFood Ads, gestite dall'Admin)
-- ════════════════════════════════════════════════════════════════════
create table public.sponsored_campaigns (
  id                uuid primary key default gen_random_uuid(),
  restaurant_id     uuid not null references public.restaurants(id) on delete cascade,
  name              text not null check (char_length(name) between 2 and 120),
  status            public.campaign_status not null default 'draft',
  placement         public.sponsored_placement not null default 'home_featured',
  start_date        date not null default current_date,
  end_date          date,
  daily_budget      numeric(10,2) check (daily_budget is null or daily_budget >= 0),
  total_budget      numeric(10,2) check (total_budget is null or total_budget >= 0),
  spend             numeric(10,2) not null default 0 check (spend >= 0),   -- aggiornata a mano (fatturazione Ads manuale)
  priority          int not null default 0 check (priority between 0 and 100),
  target_cities     uuid[] not null default '{}',                           -- vuoto = tutti i comuni
  target_categories uuid[] not null default '{}',                           -- vuoto = tutte le categorie
  notes             text check (char_length(notes) <= 500),
  created_by        uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  check (end_date is null or end_date >= start_date)
);
create index sponsored_campaigns_live_idx on public.sponsored_campaigns(placement, status, priority desc);
create index sponsored_campaigns_restaurant_idx on public.sponsored_campaigns(restaurant_id);
create trigger sponsored_campaigns_updated_at before update on public.sponsored_campaigns
  for each row execute function public.set_updated_at();

-- Migrazione dalle sponsorizzazioni Fase 1
insert into public.sponsored_campaigns (id, restaurant_id, name, status, placement, start_date, end_date, total_budget, priority, target_cities, target_categories)
select s.id, s.restaurant_id, coalesce(nullif(s.campaign_name, ''), 'Campagna ' || to_char(s.starts_at, 'DD/MM/YYYY')),
       case when not s.is_active then 'paused'::public.campaign_status
            when s.ends_at is not null and s.ends_at < now() then 'ended'::public.campaign_status
            else 'active'::public.campaign_status end,
       s.placement, (s.starts_at at time zone 'Europe/Rome')::date, (s.ends_at at time zone 'Europe/Rome')::date,
       s.budget, least(greatest(s.priority, 0), 100),
       array_remove(array[s.city_id], null), array_remove(array[s.category_id], null)
from public.sponsored_restaurants s;
drop table public.sponsored_restaurants;

create or replace function public.campaign_is_live(c public.sponsored_campaigns)
returns boolean language sql stable set search_path = public as $$
  select c.status in ('active', 'scheduled')
     and c.start_date <= (now() at time zone 'Europe/Rome')::date
     and (c.end_date is null or c.end_date >= (now() at time zone 'Europe/Rome')::date)
     and (c.total_budget is null or c.spend < c.total_budget);
$$;

-- Stato mostrato: "scheduled" se attiva ma non ancora iniziata, "ended" oltre la data di fine
create or replace function public.campaign_display_status(c public.sponsored_campaigns)
returns text language sql stable set search_path = public as $$
  select case
    when c.status in ('active', 'scheduled') and c.end_date is not null and c.end_date < (now() at time zone 'Europe/Rome')::date then 'ended'
    when c.status in ('active', 'scheduled') and c.start_date > (now() at time zone 'Europe/Rome')::date then 'scheduled'
    when c.status = 'scheduled' then 'active'
    else c.status::text end;
$$;

-- Slot sponsorizzati per un placement: separati dai risultati organici, pochi, a rotazione giornaliera
create or replace function public.sponsored_slots(p_placement text, p_city_slug text default null, p_category_slug text default null, p_limit int default 2)
returns table (campaign_id uuid, restaurant_id uuid, placement text, priority int)
language sql stable security definer set search_path = public as $$
  with ctx as (
    select (select id from public.cities where slug = p_city_slug) as city_id,
           (select id from public.categories where slug = p_category_slug) as category_id
  ), ranked as (
    select c.id, c.restaurant_id, c.placement::text as placement, c.priority,
           row_number() over (partition by c.restaurant_id order by c.priority desc, c.id) as rn
    from public.sponsored_campaigns c, ctx
    where c.placement::text = p_placement and public.campaign_is_live(c)
      and public.restaurant_is_public(c.restaurant_id)
      and (p_city_slug is null or cardinality(c.target_cities) = 0 or ctx.city_id = any(c.target_cities))
      and (p_category_slug is null or cardinality(c.target_categories) = 0 or ctx.category_id = any(c.target_categories))
      and (p_city_slug is null or exists (select 1 from public.restaurants r where r.id = c.restaurant_id and r.city_id = ctx.city_id))
      and (p_category_slug is null or exists (select 1 from public.restaurant_categories rc where rc.restaurant_id = c.restaurant_id and rc.category_id = ctx.category_id))
  )
  select id, restaurant_id, placement, priority from ranked
  where rn = 1
  order by priority desc, md5(id::text || current_date::text)
  limit least(greatest(coalesce(p_limit, 2), 1), 6);
$$;

-- Campo calcolato per PostgREST (select=*,sponsored_now): etichetta "Sponsorizzato" senza esporre budget/spesa
create or replace function public.sponsored_now(r public.restaurants)
returns boolean language sql stable security definer set search_path = public as $$
  select r.is_sponsored or exists (select 1 from public.sponsored_campaigns c where c.restaurant_id = r.id and public.campaign_is_live(c));
$$;

-- Tracciamento con deduplica per sessione (nessun fingerprint): impression 1 ogni 30 min, click 1 ogni 10 s
alter table public.analytics_events add column if not exists campaign_id uuid references public.sponsored_campaigns(id) on delete set null;
create index analytics_events_campaign_idx on public.analytics_events(campaign_id, event_type, created_at desc) where campaign_id is not null;

create or replace function public.track_sponsored_event(p_campaign_id uuid, p_type text, p_placement text, p_session_id text)
returns boolean language plpgsql security definer set search_path = public as $$
declare c public.sponsored_campaigns; v_session text := left(nullif(trim(coalesce(p_session_id, '')), ''), 64);
begin
  if p_type not in ('sponsored_impression', 'sponsored_click') then return false; end if;
  if v_session is null or v_session !~ '^[A-Za-z0-9_-]{8,64}$' then return false; end if;
  select * into c from public.sponsored_campaigns where id = p_campaign_id;
  if not found or not public.campaign_is_live(c) or c.placement::text is distinct from p_placement then return false; end if;
  if exists (select 1 from public.analytics_events e
             where e.campaign_id = p_campaign_id and e.session_id = v_session and e.event_type::text = p_type
               and e.created_at > now() - case when p_type = 'sponsored_impression' then interval '30 minutes' else interval '10 seconds' end) then
    return false;
  end if;
  -- Anti-flood per sessione
  if (select count(*) from public.analytics_events e where e.session_id = v_session and e.campaign_id is not null
      and e.created_at > now() - interval '1 hour') >= 300 then
    return false;
  end if;
  insert into public.analytics_events (restaurant_id, event_type, session_id, source, metadata, campaign_id)
  values (c.restaurant_id, p_type::public.analytics_event_type, v_session, left(p_placement, 40), jsonb_build_object('placement', p_placement), c.id);
  return true;
end $$;

-- Statistiche campagne (dati reali da analytics_events)
create or replace function public.campaign_stats(p_restaurant uuid default null, p_days int default 30)
returns table (campaign_id uuid, restaurant_id uuid, restaurant_name text, name text, placement text, status text, display_status text,
               start_date date, end_date date, priority int, daily_budget numeric, total_budget numeric, spend numeric,
               impressions bigint, clicks bigint, ctr numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  if p_restaurant is null then
    if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  elsif not public.can_manage_restaurant(p_restaurant) then
    raise exception 'Non autorizzato' using errcode = '42501';
  elsif not public.is_admin() and not public.restaurant_has_feature(p_restaurant, 'sponsored_ads') then
    raise exception 'PLAN_FEATURE:sponsored_ads' using hint = 'upgrade';
  end if;
  return query
  select c.id, c.restaurant_id, r.name, c.name, c.placement::text, c.status::text, public.campaign_display_status(c),
         c.start_date, c.end_date, c.priority, c.daily_budget, c.total_budget, c.spend,
         coalesce(e.imp, 0), coalesce(e.clk, 0),
         case when coalesce(e.imp, 0) = 0 then 0 else round(coalesce(e.clk, 0) * 100.0 / e.imp, 2) end
  from public.sponsored_campaigns c
  join public.restaurants r on r.id = c.restaurant_id
  left join lateral (
    select count(*) filter (where ev.event_type = 'sponsored_impression') as imp,
           count(*) filter (where ev.event_type = 'sponsored_click') as clk
    from public.analytics_events ev
    where ev.campaign_id = c.id and ev.created_at >= now() - make_interval(days => least(greatest(p_days, 1), 365))
  ) e on true
  where p_restaurant is null or c.restaurant_id = p_restaurant
  order by (c.status in ('active', 'scheduled')) desc, c.start_date desc;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  11. RICAVI (solo abbonamenti Stripe reali; annuali normalizzati /12)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.subscription_mrr_cents(s public.subscriptions)
returns numeric language sql immutable as $$
  select case when s.billing_interval = 'year' then coalesce(s.unit_amount_cents, 0) / 12.0 else coalesce(s.unit_amount_cents, 0)::numeric end;
$$;

create or replace function public.subscription_in_env(s public.subscriptions)
returns boolean language sql stable security definer set search_path = public as $$
  select s.source = 'stripe' and (public.billing_setting_text('billing_stripe_environment', null) is null
         or s.stripe_environment is not distinct from public.billing_setting_text('billing_stripe_environment', null));
$$;

create or replace function public.admin_revenue_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_month_start timestamptz := date_trunc('month', now() at time zone 'Europe/Rome') at time zone 'Europe/Rome';
  v jsonb;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select jsonb_build_object(
    'environment', public.billing_setting_text('billing_stripe_environment', null),
    'restaurants_total', (select count(*) from public.restaurants),
    'restaurants_claimed', (select count(*) from public.restaurants where owner_id is not null),
    'plans', (select jsonb_object_agg(p.code, (select count(*) from public.restaurants r where r.subscription_plan = p.code))
              from public.subscription_plans p),
    'paying_customers', (select count(distinct coalesce(s.billing_account_id::text, s.restaurant_id::text)) from public.subscriptions s
                         where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
    'paying_subscriptions', (select count(*) from public.subscriptions s
                             where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
    'mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                  where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
    'arr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s)) * 12), 0) from public.subscriptions s
                  where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
    'new_mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                      where public.subscription_in_env(s) and s.paid_started_at >= v_month_start),
    'churned_mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                          where public.subscription_in_env(s) and s.ended_at >= v_month_start and s.paid_started_at is not null),
    'trials_active', (select count(*) from public.subscriptions s
                      where public.subscription_in_env(s) and s.status = 'trialing' and public.subscription_grants_access(s)),
    'trials_ended', (select count(*) from public.billing_trials where ends_at is not null and ends_at <= now()),
    'trials_converted', (select count(*) from public.billing_trials where converted_at is not null),
    'trial_conversion_rate', (select case when count(*) filter (where ends_at <= now() or converted_at is not null) = 0 then null
                                     else round(count(*) filter (where converted_at is not null) * 100.0
                                                / count(*) filter (where ends_at <= now() or converted_at is not null), 1) end
                              from public.billing_trials),
    'cancel_scheduled', (select count(*) from public.subscriptions s
                         where public.subscription_in_env(s) and s.cancel_at_period_end and s.status in ('active', 'trialing', 'past_due')),
    'cancelled_30d', (select count(*) from public.subscriptions s
                      where public.subscription_in_env(s) and s.status = 'canceled' and coalesce(s.ended_at, s.cancelled_at) >= now() - interval '30 days'),
    'past_due', (select count(*) from public.subscriptions s where public.subscription_in_env(s) and s.status in ('past_due', 'unpaid')),
    'manual_active', (select count(*) from public.subscriptions s where s.source <> 'stripe' and public.subscription_grants_access(s)),
    'mrr_series', (select jsonb_agg(jsonb_build_object('month', to_char(mo.m, 'YYYY-MM'), 'mrr_cents',
                     (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s
                       where public.subscription_in_env(s) and s.paid_started_at is not null
                         and s.paid_started_at < mo.m + interval '1 month'
                         and (case when mo.m + interval '1 month' > now()
                                   then s.status in ('active', 'past_due') and public.subscription_grants_access(s)
                                   else coalesce(s.ended_at, 'infinity'::timestamptz) >= mo.m + interval '1 month' end)))
                   order by mo.m)
                   from generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') as mo(m))
  ) into v;
  return v;
end $$;

-- KPI Admin: sponsorizzazioni dalla nuova tabella + indicatori abbonamenti
create or replace function public.admin_dashboard_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb;
begin
  if not public.is_admin() then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  select jsonb_build_object(
    'restaurants_total',      (select count(*) from public.restaurants),
    'restaurants_active',     (select count(*) from public.restaurants where is_active),
    'restaurants_draft',      (select count(*) from public.restaurants where not is_active),
    'restaurants_claimed',    (select count(*) from public.restaurants where owner_id is not null),
    'restaurants_demo',       (select count(*) from public.restaurants where is_demo),
    'restaurants_real',       (select count(*) from public.restaurants where not is_demo),
    'restaurants_verified',   (select count(*) from public.restaurants where data_status in ('verified', 'claimed')),
    'restaurants_unverified', (select count(*) from public.restaurants where data_status in ('unverified', 'outdated')),
    'restaurants_no_coords',  (select count(*) from public.restaurants where latitude is null or longitude is null),
    'restaurants_paid',       (select count(*) from public.restaurants where subscription_plan <> 'free'),
    'claims_pending',         (select count(*) from public.restaurant_claims where status in ('pending', 'under_review')),
    'claims_more_info',       (select count(*) from public.restaurant_claims where status = 'more_information_required'),
    'reports_open',           (select count(*) from public.restaurant_reports where status in ('open', 'in_progress')),
    'change_requests_pending',(select count(*) from public.restaurant_change_requests where status = 'pending'),
    'upgrade_requests_open',  (select count(*) from public.plan_upgrade_requests where status = 'open'),
    'publication_requests',   (select count(*) from public.restaurants where not is_active and publication_requested_at is not null),
    'users_total',            (select count(*) from public.profiles),
    'owners_total',           (select count(distinct user_id) from public.restaurant_members where status = 'active'),
    'offers_active',          (select count(*) from public.offers where is_active and (ends_at is null or ends_at > now())),
    'coupons_active',         (select count(*) from public.coupons where is_active and (valid_until is null or valid_until > now())),
    'coupons_claimed_30d',    (select count(*) from public.coupon_claims where claimed_at >= now() - interval '30 days'),
    'coupons_redeemed_30d',   (select count(*) from public.coupon_claims where redeemed_at >= now() - interval '30 days'),
    'reservations_30d',       (select count(*) from public.reservations where created_at >= now() - interval '30 days'),
    'reservations_pending',   (select count(*) from public.reservations where status = 'pending'),
    'emails_pending',         (select count(*) from public.email_outbox where status = 'pending'),
    'sponsored_active',       (select count(*) from public.sponsored_campaigns c where public.campaign_is_live(c)),
    'webhook_failed_7d',      (select count(*) from public.stripe_events where processing_status = 'failed' and created_at >= now() - interval '7 days'),
    'events_30d',             (select count(*) from public.analytics_events where created_at >= now() - interval '30 days'),
    'views_30d',              (select count(*) from public.analytics_events where event_type = 'restaurant_view' and created_at >= now() - interval '30 days'),
    'map_opens_30d',          (select count(*) from public.app_events where event_type = 'map_open' and created_at >= now() - interval '30 days'),
    'near_me_30d',            (select count(*) from public.app_events where event_type = 'near_me_search' and created_at >= now() - interval '30 days'),
    'show_demo_data',         public.demo_data_visible()
  ) into v;
  return v;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  12. RLS
-- ════════════════════════════════════════════════════════════════════
alter table public.billing_accounts               enable row level security;
alter table public.billing_invoices               enable row level security;
alter table public.stripe_events                  enable row level security;
alter table public.billing_trials                 enable row level security;
alter table public.billing_promotions             enable row level security;
alter table public.billing_promotion_redemptions  enable row level security;
alter table public.billing_activity               enable row level security;
alter table public.billing_requests               enable row level security;
alter table public.sponsored_campaigns            enable row level security;

-- Piani: il pubblico legge solo i piani attivi (prima: tutti)
drop policy if exists "subscription_plans_public_read" on public.subscription_plans;
do $$ declare p record;
begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'subscription_plans' and cmd = 'SELECT' loop
    execute format('drop policy %I on public.subscription_plans', p.policyname);
  end loop;
end $$;
create policy "subscription_plans_read_active" on public.subscription_plans
  for select using (is_active or public.is_admin());

-- Abbonamenti: lettura per chi gestisce il locale o per l'intestatario; scrittura solo backend/RPC Admin
drop policy if exists "subscriptions_read" on public.subscriptions;
drop policy if exists "subscriptions_admin" on public.subscriptions;
create policy "subscriptions_read" on public.subscriptions
  for select to authenticated using (public.can_manage_restaurant(restaurant_id) or user_id = auth.uid());
create policy "subscriptions_admin_read" on public.subscriptions
  for select to authenticated using (public.is_admin());

-- Account di fatturazione: dati privati del titolare
create policy "billing_accounts_own" on public.billing_accounts
  for select to authenticated using (owner_user_id = auth.uid() or public.is_admin());
create policy "billing_accounts_insert_own" on public.billing_accounts
  for insert to authenticated with check (owner_user_id = auth.uid() or public.is_admin());
create policy "billing_accounts_update_own" on public.billing_accounts
  for update to authenticated using (owner_user_id = auth.uid() or public.is_admin())
  with check (owner_user_id = auth.uid() or public.is_admin());

create policy "billing_invoices_read" on public.billing_invoices
  for select to authenticated using (
    public.is_admin()
    or (restaurant_id is not null and public.can_manage_restaurant(restaurant_id))
    or billing_account_id in (select id from public.billing_accounts where owner_user_id = auth.uid()));

create policy "stripe_events_admin" on public.stripe_events for select to authenticated using (public.is_admin());
create policy "billing_trials_admin" on public.billing_trials for select to authenticated using (public.is_admin());
create policy "billing_promotions_admin" on public.billing_promotions
  for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "billing_promotion_redemptions_admin" on public.billing_promotion_redemptions
  for select to authenticated using (public.is_admin());
create policy "billing_activity_read" on public.billing_activity
  for select to authenticated using (public.is_admin() or (restaurant_id is not null and public.can_manage_restaurant(restaurant_id) and event <> 'email_error'));

-- Campagne: Admin gestisce; il ristoratore vede le proprie; il pubblico usa sponsored_slots (senza budget)
create policy "sponsored_campaigns_admin" on public.sponsored_campaigns
  for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "sponsored_campaigns_owner_read" on public.sponsored_campaigns
  for select to authenticated using (public.can_manage_restaurant(restaurant_id));

-- ════════════════════════════════════════════════════════════════════
--  13. PRIVILEGI
-- ════════════════════════════════════════════════════════════════════
grant select on public.plans to anon, authenticated;
grant select, insert on public.billing_accounts to authenticated;
grant update (business_name, vat_number, tax_code, billing_email, pec, recipient_code, address_line, postal_code, city, province, country)
  on public.billing_accounts to authenticated;
grant select on public.billing_invoices, public.billing_activity, public.sponsored_campaigns to authenticated;
grant select, insert, update, delete on public.billing_promotions to authenticated;
grant insert, update, delete on public.sponsored_campaigns to authenticated;
grant select on public.stripe_events, public.billing_trials, public.billing_promotion_redemptions to authenticated;
revoke insert, update, delete on public.subscriptions from anon, authenticated;
revoke all on public.billing_requests from anon, authenticated;
revoke insert, update, delete on public.stripe_events, public.billing_invoices, public.billing_trials,
  public.billing_activity, public.billing_promotion_redemptions from anon, authenticated;

-- Funzioni solo backend (service_role)
do $$ declare f text;
begin
  foreach f in array array[
    'billing_rate_check(uuid, text, int, int)', 'billing_set_environment(text)', 'billing_ensure_account(uuid)',
    'billing_checkout_context(uuid, uuid, text, text, text, text)', 'billing_set_customer(uuid, text, text)',
    'billing_set_promotion_coupon(uuid, text, text)', 'billing_manage_context(uuid, uuid, text)',
    'billing_change_context(uuid, uuid, text, text, text)', 'billing_event_begin(text, text, text, text)',
    'billing_event_finish(text, text, text, uuid)', 'billing_upsert_subscription(jsonb)',
    'billing_set_scheduled_change(text, text, text, timestamptz)', 'billing_plans_for_provisioning()', 'billing_record_invoice(jsonb, text)',
    'billing_redeem_promotion(uuid, uuid, uuid, text)', 'billing_set_plan_stripe_ids(text, text, text, text)',
    'billing_admin_context(uuid, uuid)', 'billing_stripe_subscription_ids(text)', 'billing_find_promotion(text, text, uuid)',
    'user_can_bill(uuid, uuid)', 'billing_trial_eligible(uuid, uuid)', 'billing_log(uuid, uuid, text, jsonb)',
    'billing_notify(uuid, uuid, text, text, text, jsonb)', 'refresh_restaurant_plan(uuid)', 'internal_write_begin()', 'internal_write_end(text)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;

grant execute on function public.billing_refresh_plans(), public.billing_trial_expiring(text) to authenticated, service_role;
grant execute on function public.admin_grant_plan(uuid, text, timestamptz, text, text), public.admin_revoke_plan(uuid),
  public.admin_extend_manual_plan(uuid, timestamptz), public.admin_revenue_stats(), public.get_billing_overview(uuid),
  public.restaurant_profile_completion(uuid), public.complete_onboarding(uuid), public.request_publication(uuid),
  public.campaign_stats(uuid, int) to authenticated;
grant execute on function public.sponsored_now(public.restaurants), public.sponsored_slots(text, text, text, int), public.track_sponsored_event(uuid, text, text, text),
  public.restaurant_effective_plan(uuid) to anon, authenticated;
revoke all on function public.billing_refresh_plans(), public.billing_trial_expiring(text) from anon;
revoke all on function public.admin_grant_plan(uuid, text, timestamptz, text, text), public.admin_revoke_plan(uuid),
  public.admin_extend_manual_plan(uuid, timestamptz), public.admin_revenue_stats(), public.get_billing_overview(uuid),
  public.restaurant_profile_completion(uuid), public.complete_onboarding(uuid), public.request_publication(uuid),
  public.campaign_stats(uuid, int) from anon;
