-- ════════════════════════════════════════════════════════════════════
--  FASE 5 · Enum (file separato: i nuovi valori devono essere
--  committati prima di essere usati dalla migrazione 0014)
-- ════════════════════════════════════════════════════════════════════

-- Stati Stripe completi + "free" (nessun abbonamento a pagamento)
alter type public.subscription_status add value if not exists 'unpaid';
alter type public.subscription_status add value if not exists 'incomplete_expired';
alter type public.subscription_status add value if not exists 'paused';
alter type public.subscription_status add value if not exists 'free';

-- Origine dell'abbonamento: solo "stripe" è fatturato da Stripe
create type public.subscription_source as enum ('stripe', 'manual', 'promo', 'admin');

-- Sponsorizzazioni (AsiaFood Ads)
create type public.campaign_status as enum ('draft', 'scheduled', 'active', 'paused', 'ended');
alter type public.sponsored_placement add value if not exists 'map_featured';
alter type public.sponsored_placement add value if not exists 'offers_featured';

-- Eventi analytics delle sponsorizzazioni
alter type public.analytics_event_type add value if not exists 'sponsored_impression';
alter type public.analytics_event_type add value if not exists 'sponsored_click';
