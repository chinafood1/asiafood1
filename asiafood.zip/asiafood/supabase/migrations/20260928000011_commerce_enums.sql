-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0011 · Fase 4: enum (file separato: i nuovi valori di un
--  enum esistente non si possono usare nella stessa transazione).
-- ════════════════════════════════════════════════════════════════════

-- Eventi analytics con i nomi della Fase 4 (i vecchi restano validi e vengono rimappati)
alter type public.analytics_event_type add value if not exists 'restaurant_view';
alter type public.analytics_event_type add value if not exists 'phone_click';
alter type public.analytics_event_type add value if not exists 'whatsapp_click';
alter type public.analytics_event_type add value if not exists 'directions_click';
alter type public.analytics_event_type add value if not exists 'menu_view';
alter type public.analytics_event_type add value if not exists 'reservation_start';
alter type public.analytics_event_type add value if not exists 'reservation_completed';
alter type public.analytics_event_type add value if not exists 'offer_view';
alter type public.analytics_event_type add value if not exists 'coupon_claim';
alter type public.analytics_event_type add value if not exists 'website_click';
alter type public.analytics_event_type add value if not exists 'instagram_click';
alter type public.analytics_event_type add value if not exists 'social_click';
alter type public.analytics_event_type add value if not exists 'map_view';
alter type public.analytics_event_type add value if not exists 'map_marker_click';

-- Tipi di menu aggiuntivi (principale = a_la_carte)
alter type public.menu_type add value if not exists 'dinner';
alter type public.menu_type add value if not exists 'delivery';
alter type public.menu_type add value if not exists 'dessert';
alter type public.menu_type add value if not exists 'seasonal';

-- Nuovi enum
create type public.offer_type as enum (
  'percentage', 'fixed_amount', 'special_menu', 'two_for_one', 'happy_hour', 'ayce_promo', 'free_dish', 'other'
);
create type public.reservation_status as enum ('pending', 'confirmed', 'rejected', 'cancelled', 'completed', 'no_show');
create type public.reservation_source as enum ('web', 'app', 'admin', 'restaurant');
create type public.coupon_claim_status as enum ('claimed', 'redeemed', 'expired', 'cancelled');
