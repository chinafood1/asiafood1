-- ════════════════════════════════════════════════════════════════════
--  FASE 12 · GO-TO-MARKET TARANTO E PROVINCIA
--  Strumenti per il lancio reale (nessuna nuova funzione commerciale per i clienti finali):
--  - mercati e comuni prioritari (base del futuro Expansion Engine)
--  - completezza dati, qualità, segmentazione commerciale interna, First 50
--  - CRM leggero (ristoranti, creator, partner locali, stampa) con attività e task
--  - programma "Partner Fondatore" configurabile, badge solo per aderenti reali
--  - QR tracking, attribuzione acquisizione (UTM, codici), feedback/NPS, ambassador,
--    contenuti marketing, incidenti di lancio, obiettivi (target vs actual), costi (CAC),
--    esperimenti leggeri, piano 30/90 giorni, dashboard (overview, daily, weekly, operations)
--  Regole: numeri solo da dati reali; DEMO inclusi solo se show_demo_data = true (e dichiarato);
--  nessun invio automatico di messaggi/campagne; nessun dato personale nei QR o negli eventi.
-- ════════════════════════════════════════════════════════════════════

-- ────────────────────────────────────────────────────────────────────
--  1. IMPOSTAZIONI (tutte modificabili dall'Admin; nessuna promessa pubblica)
-- ────────────────────────────────────────────────────────────────────
insert into public.platform_settings (key, value, description) values
  ('launch_phase',                     '"private_beta"', 'Fase di lancio del mercato principale: private_beta | local_beta | public_launch'),
  ('founding_program_enabled',         'true',   'Programma "Partner Fondatore": attivabile dall''Admin per ristoranti rivendicati'),
  ('founding_program_name',            '"Partner Fondatore AsiaFood Taranto"', 'Nome del programma e del badge'),
  ('founding_limit',                   '30',     'Numero massimo di Partner Fondatori per mercato'),
  ('founding_plan',                    '"premium"', 'Piano concesso ai Partner Fondatori (free|business|premium|top)'),
  ('founding_days',                    '30',     'Giorni di piano gratuito per i Partner Fondatori (poi il piano scade: nessun addebito automatico)'),
  ('founding_badge_enabled',           'true',   'Mostra il badge "Partner Fondatore" sulle schede degli aderenti'),
  ('founding_foodie_open',             'false',  'Assegna il badge "Founding Foodie" ai nuovi iscritti (solo fase iniziale)'),
  ('founding_foodie_limit',            '500',    'Numero massimo di badge "Founding Foodie"'),
  ('launch_first_n',                   '50',     'Dimensione della lista "First N" per l''outreach'),
  ('launch_daily_target_research',     '10',     'Obiettivo operativo giornaliero: nuovi lead ricercati (non una promessa)'),
  ('launch_daily_target_contacts',     '10',     'Obiettivo operativo giornaliero: contatti'),
  ('launch_daily_target_demos',        '3',      'Obiettivo operativo giornaliero: demo'),
  ('launch_daily_target_claims',       '2',      'Obiettivo operativo giornaliero: rivendicazioni'),
  ('launch_daily_target_trials',       '1',      'Obiettivo operativo giornaliero: prove attivate'),
  ('sla_claim_review_hours',           '48',     'SLA interno: revisione rivendicazioni (ore) — non mostrato al pubblico'),
  ('sla_support_first_response_hours', '24',     'SLA interno: prima risposta al supporto (ore)'),
  ('sla_order_issue_hours',            '2',      'SLA interno: problemi sugli ordini (ore)'),
  ('sla_data_report_hours',            '72',     'SLA interno: segnalazioni di dati errati (ore)'),
  ('data_stale_days',                  '180',    'Dati considerati obsoleti dopo N giorni senza verifica'),
  ('partner_no_login_days',            '14',     'Partner a rischio: nessun accesso da N giorni'),
  ('partner_zero_activity_days',       '30',     'Partner a rischio: nessuna azione dei clienti da N giorni'),
  ('nps_enabled',                      'false',  'Chiedi l''NPS dopo un uso significativo (mai più di una volta ogni nps_interval_days)'),
  ('nps_min_actions',                  '3',      'Azioni concluse (prenotazioni/ordini/coupon) prima di chiedere l''NPS'),
  ('nps_interval_days',                '90',     'Intervallo minimo tra due richieste NPS allo stesso utente'),
  ('ambassador_program_enabled',       'false',  'Programma AsiaFood Ambassador: candidature aperte (nessun compenso automatico)'),
  ('experiments_max_running',          '2',      'Esperimenti A/B attivi contemporaneamente (massimo)'),
  ('cac_min_conversions',              '5',      'CAC calcolato solo con almeno N conversioni nel periodo'),
  ('crm_lost_retention_days',          '730',    'Lead persi/non interessati: dati di contatto anonimizzati dopo N giorni'),
  ('launch_forecast',                  'null',   'Ipotesi di scenario (Conservative/Base/Growth) inserite dall''Admin: mai calcolate automaticamente'),
  ('google_site_verification',         'null',   'Riferimento: il token Search Console si imposta con VITE_GOOGLE_SITE_VERIFICATION (build)')
on conflict (key) do nothing;

update public.platform_settings set is_public = true
 where key in ('launch_phase', 'founding_program_name', 'founding_badge_enabled', 'ambassador_program_enabled', 'nps_enabled');

-- ────────────────────────────────────────────────────────────────────
--  2. MERCATI E COMUNI PRIORITARI
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.markets (
  id           uuid primary key default gen_random_uuid(),
  slug         text not null unique check (slug ~ '^[a-z0-9-]{2,40}$'),
  name         text not null check (char_length(name) between 2 and 80),
  province_id  uuid references public.provinces(id) on delete restrict,
  status       text not null default 'planned' check (status in ('planned', 'private_beta', 'local_beta', 'public_launch', 'paused')),
  launched_at  timestamptz,
  notes        text check (char_length(notes) <= 1000),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists public.market_cities (
  market_id           uuid not null references public.markets(id) on delete cascade,
  city_id             uuid not null references public.cities(id) on delete cascade,
  priority            int not null default 100 check (priority between 1 and 1000),
  target_restaurants  int check (target_restaurants is null or target_restaurants >= 0),
  primary key (market_id, city_id)
);

insert into public.markets (slug, name, province_id, status)
select 'taranto', 'Taranto e provincia', p.id, 'private_beta' from public.provinces p where p.code = 'TA'
on conflict (slug) do nothing;

-- Comuni iniziali prioritari (ordine = priorità di outreach)
insert into public.market_cities (market_id, city_id, priority)
select m.id, c.id, x.prio
  from public.markets m
  join (values ('taranto', 1), ('massafra', 2), ('martina-franca', 3), ('grottaglie', 4), ('manduria', 5), ('castellaneta', 6),
               ('ginosa', 7), ('laterza', 8), ('palagiano', 9), ('mottola', 10), ('pulsano', 11), ('leporano', 12),
               ('san-giorgio-ionico', 13), ('statte', 14), ('crispiano', 15), ('sava', 16), ('lizzano', 17), ('maruggio', 18), ('avetrana', 19))
       as x(slug, prio) on true
  join public.cities c on c.slug = x.slug and c.province_id = m.province_id
 where m.slug = 'taranto'
on conflict do nothing;

create or replace function public.launch_market(p_slug text)
returns public.markets language sql stable security definer set search_path = public as $$
  select * from public.markets where slug = coalesce(nullif(p_slug, ''), 'taranto');
$$;

-- Locali considerati nelle metriche di lancio: reali; i DEMO solo se visibili al pubblico (staging/demo) e sempre dichiarati
create or replace function public.launch_include_demo()
returns boolean language sql stable security definer set search_path = public as $$
  select public.demo_data_visible();
$$;

create or replace function public.launch_market_restaurant(p_market uuid, r public.restaurants)
returns boolean language sql stable security definer set search_path = public as $$
  select (select province_id from public.markets where id = p_market) = coalesce(r.province_id, (select province_id from public.cities where id = r.city_id))
     and (not r.is_demo or public.launch_include_demo());
$$;

-- ────────────────────────────────────────────────────────────────────
--  3. COMPLETEZZA DATI (data_completion_score, 0–100) — criteri documentati in docs/launch/METRICS.md
-- ────────────────────────────────────────────────────────────────────
create or replace function public.restaurant_completion(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r public.restaurants;
  v_hours boolean; v_cats boolean; v_menu boolean; v_imgs boolean; v_resv boolean;
  v_score int := 0; v_missing text[] := '{}';
  v_known boolean;
begin
  select * into r from public.restaurants where id = p_id;
  if not found then return null; end if;
  v_hours := exists (select 1 from public.restaurant_hours where restaurant_id = p_id);
  v_cats  := exists (select 1 from public.restaurant_categories where restaurant_id = p_id);
  v_menu  := exists (select 1 from public.menus where restaurant_id = p_id and is_active)
             or exists (select 1 from public.menu_items where restaurant_id = p_id);
  v_imgs  := exists (select 1 from public.restaurant_images where restaurant_id = p_id);
  v_resv  := exists (select 1 from public.reservation_settings where restaurant_id = p_id and reservation_enabled);
  -- Servizi (consegna/prenotazione) "noti": locale verificato/rivendicato oppure almeno un servizio dichiarato
  v_known := r.is_verified or r.data_status in ('verified', 'claimed') or r.has_delivery or r.has_takeaway or r.has_reservation;

  if coalesce(trim(r.name), '') <> '' then v_score := v_score + 5; else v_missing := array_append(v_missing, 'name'); end if;
  if coalesce(trim(r.address), '') <> '' then v_score := v_score + 8; else v_missing := array_append(v_missing, 'address'); end if;
  if r.latitude is not null and r.longitude is not null then v_score := v_score + 10; else v_missing := array_append(v_missing, 'coordinates'); end if;
  if coalesce(r.phone, r.whatsapp) is not null then v_score := v_score + 8; else v_missing := array_append(v_missing, 'phone'); end if;
  if v_hours then v_score := v_score + 10; else v_missing := array_append(v_missing, 'hours'); end if;
  if v_cats then v_score := v_score + 8; else v_missing := array_append(v_missing, 'categories'); end if;
  if r.logo_url is not null then v_score := v_score + 5; else v_missing := array_append(v_missing, 'logo'); end if;
  if r.cover_url is not null or v_imgs then v_score := v_score + 8; else v_missing := array_append(v_missing, 'cover'); end if;
  if v_menu then v_score := v_score + 10; else v_missing := array_append(v_missing, 'menu'); end if;
  if coalesce(r.instagram, r.facebook, r.tiktok, r.website) is not null then v_score := v_score + 6; else v_missing := array_append(v_missing, 'social'); end if;
  if cardinality(r.services) > 0 then v_score := v_score + 5; else v_missing := array_append(v_missing, 'services'); end if;
  if r.price_range is not null or r.average_price is not null then v_score := v_score + 6; else v_missing := array_append(v_missing, 'prices'); end if;
  if not r.is_all_you_can_eat or coalesce(r.ayce_lunch_price, r.ayce_dinner_price, r.ayce_weekend_price) is not null then v_score := v_score + 4;
  else v_missing := array_append(v_missing, 'ayce'); end if;
  if v_known then v_score := v_score + 3; else v_missing := array_append(v_missing, 'delivery'); end if;
  if (r.has_reservation and (r.reservation_url is not null or v_resv)) or v_resv or (v_known and not r.has_reservation) then v_score := v_score + 4;
  else v_missing := array_append(v_missing, 'reservations'); end if;

  return jsonb_build_object('score', v_score, 'missing', to_jsonb(v_missing), 'has_menu', v_menu, 'has_hours', v_hours);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  4. CRM LEGGERO (solo Admin): ristoranti, creator, partner locali, stampa
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.crm_leads (
  id                uuid primary key default gen_random_uuid(),
  market_id         uuid not null references public.markets(id) on delete restrict,
  kind              text not null default 'restaurant' check (kind in ('restaurant', 'creator', 'partner', 'press')),
  category          text check (category in (
                      'hotel', 'bnb', 'university', 'gym', 'cinema', 'events', 'local_business',  -- partner
                      'newspaper', 'blog', 'radio', 'tv',                                         -- stampa
                      'instagram', 'tiktok', 'youtube', 'multi')),                                -- creator
  restaurant_id     uuid references public.restaurants(id) on delete set null,
  name              text not null check (char_length(name) between 2 and 160),
  city_id           uuid references public.cities(id) on delete set null,
  contact_name      text check (char_length(contact_name) <= 120),
  phone             text check (char_length(phone) <= 40),
  email             text check (email is null or (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' and char_length(email) <= 254)),
  instagram         text check (char_length(instagram) <= 120),
  tiktok            text check (char_length(tiktok) <= 120),
  website           text check (website is null or website ~* '^https?://'),
  followers         int check (followers is null or followers >= 0),
  status            text not null default 'new' check (status in (
                      'new', 'researched', 'contacted', 'replied', 'demo_scheduled', 'demo_done', 'claim_sent', 'claimed',
                      'trial', 'activated', 'paid', 'in_talks', 'active', 'closed', 'lost', 'not_interested', 'do_not_contact')),
  segment_override  text check (segment_override in ('A', 'B', 'C')),
  assigned_to       uuid references public.profiles(id) on delete set null,
  next_action       text check (char_length(next_action) <= 200),
  next_action_at    timestamptz,
  last_contact_at   timestamptz,
  potential_plan    text references public.subscription_plans(code) on update cascade,
  -- Strumenti usati: SOLO se pubblicamente comunicati o dichiarati dal lead (mai ipotesi)
  competitor_tools  text[] not null default '{}' check (competitor_tools <@ array['thefork', 'deliveroo', 'justeat', 'glovo', 'ubereats', 'own_website', 'own_delivery', 'other']::text[]),
  competitor_source text check (competitor_source in ('public', 'declared')),
  contact_allowed   boolean not null default true,      -- false = non ricontattare (anche win-back)
  lost_reason       text check (char_length(lost_reason) <= 300),
  notes             text check (char_length(notes) <= 4000),
  created_by        uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  check (cardinality(competitor_tools) = 0 or competitor_source is not null),
  check (kind = 'restaurant' or restaurant_id is null),
  check (status <> 'do_not_contact' or not contact_allowed)
);
create unique index if not exists crm_leads_restaurant_uq on public.crm_leads(restaurant_id) where restaurant_id is not null;
create index if not exists crm_leads_market_kind_idx on public.crm_leads(market_id, kind, status);
create index if not exists crm_leads_next_action_idx on public.crm_leads(next_action_at) where next_action_at is not null;
create index if not exists crm_leads_assigned_idx on public.crm_leads(assigned_to) where assigned_to is not null;

create table if not exists public.crm_activities (
  id              uuid primary key default gen_random_uuid(),
  lead_id         uuid not null references public.crm_leads(id) on delete cascade,
  type            text not null check (type in ('research', 'call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'demo', 'claim_link_sent',
                                                'follow_up', 'collaboration', 'note', 'status_change')),
  outcome         text check (outcome in ('no_answer', 'interested', 'not_now', 'not_interested', 'replied', 'scheduled', 'done', 'other')),
  notes           text check (char_length(notes) <= 2000),
  -- Collaborazioni con creator/partner: sempre tracciate e con obbligo di trasparenza (#adv) se c'è un corrispettivo
  disclosure_required boolean,
  created_by      uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at      timestamptz not null default now()
);
create index if not exists crm_activities_lead_idx on public.crm_activities(lead_id, created_at desc);
create index if not exists crm_activities_created_idx on public.crm_activities(created_at desc, type);

create table if not exists public.crm_tasks (
  id             uuid primary key default gen_random_uuid(),
  market_id      uuid references public.markets(id) on delete cascade,
  lead_id        uuid references public.crm_leads(id) on delete cascade,
  restaurant_id  uuid references public.restaurants(id) on delete cascade,
  title          text not null check (char_length(title) between 3 and 200),
  reason         text check (char_length(reason) <= 60),
  due_at         timestamptz,
  assigned_to    uuid references public.profiles(id) on delete set null,
  status         text not null default 'open' check (status in ('open', 'done', 'dismissed')),
  source         text not null default 'manual' check (source in ('manual', 'at_risk', 'trial_ending', 'system')),
  created_by     uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at     timestamptz not null default now(),
  done_at        timestamptz
);
-- Un solo task automatico aperto per locale e motivo (idempotenza della generazione)
create unique index if not exists crm_tasks_auto_uq on public.crm_tasks(restaurant_id, reason) where status = 'open' and source <> 'manual';
create index if not exists crm_tasks_open_idx on public.crm_tasks(status, due_at);

create or replace function public.crm_status_rank(p_status text)
returns int language sql immutable as $$
  select case p_status when 'new' then 0 when 'researched' then 1 when 'contacted' then 2 when 'replied' then 3
    when 'demo_scheduled' then 4 when 'demo_done' then 5 when 'claim_sent' then 6 when 'claimed' then 7 when 'trial' then 8
    when 'activated' then 9 when 'paid' then 10 else -1 end;
$$;

-- Avanza lo stato del lead di un locale solo "in avanti" e mai per lead chiusi/da non contattare
create or replace function public.crm_advance_restaurant_lead(p_restaurant uuid, p_status text, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare v public.crm_leads;
begin
  select * into v from public.crm_leads where restaurant_id = p_restaurant;
  if not found then return; end if;
  if v.status in ('lost', 'not_interested', 'do_not_contact') then return; end if;
  if public.crm_status_rank(v.status) >= public.crm_status_rank(p_status) then return; end if;
  update public.crm_leads set status = p_status, updated_at = now() where id = v.id;
  insert into public.crm_activities (lead_id, type, notes, created_by) values (v.id, 'status_change', left(p_note, 200), null);
end $$;

create or replace function public.crm_leads_touch()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  if new.status = 'do_not_contact' then new.contact_allowed := false; new.next_action := null; new.next_action_at := null; end if;
  return new;
end $$;
drop trigger if exists crm_leads_touch on public.crm_leads;
create trigger crm_leads_touch before update on public.crm_leads for each row execute function public.crm_leads_touch();

-- Un'attività di contatto aggiorna "ultimo contatto" e porta un lead nuovo in "contattato"
create or replace function public.crm_activity_after()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.type in ('call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'demo', 'claim_link_sent', 'follow_up', 'collaboration') then
    update public.crm_leads
       set last_contact_at = new.created_at,
           status = case
             when new.type = 'claim_link_sent' and public.crm_status_rank(status) between 0 and 5 then 'claim_sent'
             when new.type = 'demo' and new.outcome = 'done' and public.crm_status_rank(status) between 0 and 4 then 'demo_done'
             when new.type = 'demo' and new.outcome = 'scheduled' and public.crm_status_rank(status) between 0 and 3 then 'demo_scheduled'
             when new.outcome in ('replied', 'interested') and public.crm_status_rank(status) between 0 and 2 then 'replied'
             when status in ('new', 'researched') then 'contacted'
             else status end
     where id = new.lead_id;
  elsif new.type = 'research' then
    update public.crm_leads set status = 'researched' where id = new.lead_id and status = 'new';
  end if;
  return new;
end $$;
drop trigger if exists crm_activity_after on public.crm_activities;
create trigger crm_activity_after after insert on public.crm_activities for each row execute function public.crm_activity_after();

-- Rivendicazione approvata → lead "claimed"
create or replace function public.crm_claim_sync()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'approved' and (old.status is distinct from 'approved') then
    perform public.crm_advance_restaurant_lead(new.restaurant_id, 'claimed', 'Rivendicazione approvata');
  end if;
  return new;
end $$;
drop trigger if exists crm_claim_sync on public.restaurant_claims;
create trigger crm_claim_sync after update of status on public.restaurant_claims for each row execute function public.crm_claim_sync();

-- Primo abbonamento Stripe pagato → lead "paid"
create or replace function public.crm_subscription_sync()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.source = 'stripe' and new.paid_started_at is not null and (tg_op = 'INSERT' or old.paid_started_at is null) then
    perform public.crm_advance_restaurant_lead(new.restaurant_id, 'paid', 'Primo pagamento abbonamento');
  elsif new.source = 'stripe' and new.status = 'trialing' and (tg_op = 'INSERT' or old.status is distinct from 'trialing') then
    perform public.crm_advance_restaurant_lead(new.restaurant_id, 'trial', 'Prova Stripe avviata');
  end if;
  return new;
end $$;
drop trigger if exists crm_subscription_sync on public.subscriptions;
create trigger crm_subscription_sync after insert or update of paid_started_at, status on public.subscriptions
  for each row execute function public.crm_subscription_sync();

-- ────────────────────────────────────────────────────────────────────
--  5. PROGRAMMA PARTNER FONDATORE
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.founding_partners (
  id               uuid primary key default gen_random_uuid(),
  market_id        uuid not null references public.markets(id) on delete restrict,
  restaurant_id    uuid not null unique references public.restaurants(id) on delete cascade,
  number           int not null check (number > 0),
  status           text not null default 'active' check (status in ('active', 'completed', 'revoked')),
  benefit_plan     text not null references public.subscription_plans(code) on update cascade,
  benefit_days     int not null check (benefit_days between 0 and 365),
  subscription_id  uuid references public.subscriptions(id) on delete set null,
  badge_visible    boolean not null default true,
  activated_at     timestamptz not null default now(),
  benefit_ends_at  timestamptz,
  revoked_at       timestamptz,
  revoked_reason   text check (char_length(revoked_reason) <= 300),
  notes            text check (char_length(notes) <= 1000),
  activated_by     uuid references public.profiles(id) on delete set null default auth.uid(),
  unique (market_id, number)
);

-- ────────────────────────────────────────────────────────────────────
--  6. ATTRIBUZIONE ACQUISIZIONE (senza identificativi) + CODICI
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.acquisition_codes (
  code           text primary key check (code ~ '^[A-Z0-9]{3,20}$'),
  market_id      uuid references public.markets(id) on delete cascade,
  kind           text not null default 'campaign' check (kind in ('campaign', 'restaurant', 'partner', 'creator', 'event')),
  restaurant_id  uuid references public.restaurants(id) on delete set null,
  lead_id        uuid references public.crm_leads(id) on delete set null,
  description    text check (char_length(description) <= 300),
  is_active      boolean not null default true,
  uses           int not null default 0,
  created_at     timestamptz not null default now()
);

-- Visite di atterraggio: SOLO canale e parametri di campagna. Nessun utente, sessione, IP o user agent.
create table if not exists public.acquisition_visits (
  id            bigint generated always as identity primary key,
  market_id     uuid references public.markets(id) on delete set null,
  channel       text not null check (channel in ('organic_search', 'social', 'qr', 'direct', 'referral', 'restaurant_referral',
                                                  'paid_social', 'influencer', 'email', 'partner', 'offline', 'other')),
  utm_source    text check (utm_source ~ '^[a-z0-9_.-]{1,60}$'),
  utm_medium    text check (utm_medium ~ '^[a-z0-9_.-]{1,60}$'),
  utm_campaign  text check (utm_campaign ~ '^[a-z0-9_.-]{1,60}$'),
  utm_content   text check (utm_content ~ '^[a-z0-9_.-]{1,60}$'),
  landing_path  text check (char_length(landing_path) <= 200),
  promo_code    text,
  created_at    timestamptz not null default now()
);
create index if not exists acquisition_visits_created_idx on public.acquisition_visits(created_at desc, channel);

-- Attribuzione dell'iscrizione: solo con consenso "Statistiche" (il client non la invia senza), una volta per utente
create table if not exists public.user_acquisition (
  user_id       uuid primary key references public.profiles(id) on delete cascade,
  market_id     uuid references public.markets(id) on delete set null,
  channel       text not null,
  utm_source    text, utm_medium text, utm_campaign text,
  promo_code    text,
  created_at    timestamptz not null default now()
);

-- ────────────────────────────────────────────────────────────────────
--  7. CONTENUTI MARKETING (calendario social, newsletter, stampa) — nessuna pubblicazione automatica
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.marketing_content (
  id                 uuid primary key default gen_random_uuid(),
  market_id          uuid not null references public.markets(id) on delete cascade,
  restaurant_id      uuid references public.restaurants(id) on delete set null,
  platform           text not null check (platform in ('instagram', 'facebook', 'tiktok', 'email_users', 'email_restaurants', 'press', 'blog', 'whatsapp', 'offline')),
  content_type       text not null check (content_type in ('restaurant_spotlight', 'dish_of_day', 'ayce', 'offers', 'new_partners', 'quiz', 'where_would_you_eat',
                                                           'map', 'behind_scenes', 'giveaway', 'local', 'ugc', 'launch', 'newsletter', 'press_release', 'tips')),
  title              text check (char_length(title) <= 160),
  caption            text check (char_length(caption) <= 5000),
  media_url          text check (media_url is null or media_url ~* '^https?://'),
  status             text not null default 'idea' check (status in ('idea', 'draft', 'approved', 'scheduled', 'published')),
  scheduled_for      timestamptz,
  published_at       timestamptz,
  is_sponsored       boolean not null default false,       -- contenuto pagato/sponsorizzato → etichetta obbligatoria
  rights_confirmed   boolean not null default false,       -- UGC: permesso dell'autore per il riutilizzo
  compliance_checked boolean not null default false,       -- giveaway: checklist legale completata
  notes              text check (char_length(notes) <= 2000),
  created_by         uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  -- Sponsorizzato: la didascalia deve dichiararlo (trasparenza pubblicitaria)
  check (not is_sponsored or status in ('idea', 'draft') or caption ~* '(#adv|#ad\M|sponsorizzat|pubblicit|in collaborazione con)'),
  -- UGC: niente foto/contenuti di utenti senza permesso
  check (content_type <> 'ugc' or status in ('idea', 'draft') or rights_confirmed),
  -- Giveaway / concorsi: mai oltre la bozza senza verifica di conformità
  check (content_type <> 'giveaway' or status in ('idea', 'draft') or compliance_checked),
  check (status <> 'scheduled' or scheduled_for is not null)
);
create index if not exists marketing_content_calendar_idx on public.marketing_content(market_id, coalesce(scheduled_for, created_at));

-- ────────────────────────────────────────────────────────────────────
--  8. AMBASSADOR, FEEDBACK/NPS, INCIDENTI, OBIETTIVI, COSTI, ESPERIMENTI, PIANO, KIT DI LANCIO
-- ────────────────────────────────────────────────────────────────────
create table if not exists public.ambassadors (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null unique references public.profiles(id) on delete cascade,
  market_id      uuid not null references public.markets(id) on delete cascade,
  status         text not null default 'applied' check (status in ('applied', 'approved', 'paused', 'rejected')),
  referral_code  text,
  motivation     text check (char_length(motivation) <= 1000),
  joined_at      timestamptz not null default now(),
  approved_at    timestamptz,
  notes          text check (char_length(notes) <= 1000)
);

create table if not exists public.product_feedback (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid references public.profiles(id) on delete set null,
  restaurant_id  uuid references public.restaurants(id) on delete set null,
  type           text not null check (type in ('user_general', 'restaurant_dashboard', 'nps', 'cancellation', 'bug', 'feature_request')),
  rating         int check (rating is null or rating between 0 and 10),
  reason         text check (reason is null or reason ~ '^[a-z_]{2,40}$'),
  message        text check (char_length(message) <= 2000),
  page           text check (char_length(page) <= 120),
  status         text not null default 'new' check (status in ('new', 'reviewed', 'planned', 'done', 'dismissed')),
  created_at     timestamptz not null default now(),
  check (type <> 'nps' or rating is not null),
  check (type = 'nps' or type = 'cancellation' or coalesce(char_length(trim(message)), 0) >= 3)
);
create index if not exists product_feedback_created_idx on public.product_feedback(created_at desc, type);
create index if not exists product_feedback_user_nps_idx on public.product_feedback(user_id, created_at desc) where type = 'nps';

create table if not exists public.launch_incidents (
  id           uuid primary key default gen_random_uuid(),
  market_id    uuid references public.markets(id) on delete set null,
  title        text not null check (char_length(title) between 3 and 160),
  description  text check (char_length(description) <= 4000),
  area         text not null default 'other' check (area in ('data', 'payments', 'orders', 'delivery', 'auth', 'performance', 'seo', 'support', 'restaurant', 'other')),
  severity     text not null check (severity in ('low', 'medium', 'high', 'critical')),
  status       text not null default 'open' check (status in ('open', 'investigating', 'mitigated', 'resolved')),
  created_by   uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at   timestamptz not null default now(),
  resolved_at  timestamptz
);

create table if not exists public.growth_goals (
  id            uuid primary key default gen_random_uuid(),
  market_id     uuid not null references public.markets(id) on delete cascade,
  metric_key    text not null check (metric_key in ('restaurants_listed', 'restaurants_verified', 'restaurants_claimed', 'restaurants_partner',
                  'restaurants_paying', 'users_registered', 'users_active_30d', 'reservations', 'orders_completed', 'coupon_claims',
                  'referrals_qualified', 'reviews_published', 'sponsored_campaigns', 'mrr_cents', 'qr_scans', 'food_connections')),
  target_value  numeric not null check (target_value > 0),
  period_start  date not null,
  period_end    date not null,
  actual_value  numeric,
  status        text not null default 'not_started' check (status in ('not_started', 'on_track', 'at_risk', 'behind', 'achieved')),
  refreshed_at  timestamptz,
  created_at    timestamptz not null default now(),
  check (period_end > period_start),
  unique (market_id, metric_key, period_start)
);

create table if not exists public.acquisition_costs (
  id            uuid primary key default gen_random_uuid(),
  market_id     uuid not null references public.markets(id) on delete cascade,
  audience      text not null check (audience in ('restaurants', 'users')),
  category      text not null check (category in ('sales', 'marketing', 'promo', 'print', 'events', 'tools', 'other')),
  channel       text,
  amount_cents  int not null check (amount_cents > 0),
  spent_on      date not null,
  notes         text check (char_length(notes) <= 500),
  created_by    uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at    timestamptz not null default now()
);

create table if not exists public.experiments (
  id             uuid primary key default gen_random_uuid(),
  key            text not null unique check (key ~ '^[a-z0-9_]{3,40}$'),
  name           text not null check (char_length(name) between 3 and 120),
  hypothesis     text check (char_length(hypothesis) <= 500),
  primary_metric text check (char_length(primary_metric) <= 80),
  variants       text[] not null default array['control', 'variant_b'] check (cardinality(variants) between 2 and 3),
  status         text not null default 'draft' check (status in ('draft', 'running', 'stopped')),
  started_at     timestamptz,
  stopped_at     timestamptz,
  created_at     timestamptz not null default now()
);

create table if not exists public.launch_plan_items (
  id           uuid primary key default gen_random_uuid(),
  market_id    uuid not null references public.markets(id) on delete cascade,
  horizon      text not null check (horizon in ('30d', '90d')),
  bucket       text not null check (bucket in ('week1', 'week2', 'week3', 'week4', 'month1', 'month2', 'month3')),
  title        text not null check (char_length(title) between 3 and 200),
  description  text check (char_length(description) <= 1000),
  status       text not null default 'todo' check (status in ('todo', 'doing', 'done', 'skipped')),
  owner_id     uuid references public.profiles(id) on delete set null,
  due_date     date,
  sort         int not null default 0,
  done_at      timestamptz,
  unique (market_id, horizon, title)
);

create table if not exists public.restaurant_launch_progress (
  restaurant_id         uuid primary key references public.restaurants(id) on delete cascade,
  starter_kit_viewed_at timestamptz,
  qr_kit_downloaded_at  timestamptz,
  materials_printed_at  timestamptz,
  social_launch_at      timestamptz,
  updated_at            timestamptz not null default now()
);

-- Founding Foodie: solo utenti della prima fase, nessun valore economico
alter table public.profiles add column if not exists founding_foodie_at timestamptz;

create or replace function public.founding_foodie_assign()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if public.billing_setting_bool('founding_foodie_open', false)
     and new.role = 'customer'
     and (select count(*) from public.profiles where founding_foodie_at is not null) < public.billing_setting_int('founding_foodie_limit', 500) then
    new.founding_foodie_at := now();
  end if;
  return new;
end $$;
drop trigger if exists founding_foodie_assign on public.profiles;
create trigger founding_foodie_assign before insert on public.profiles for each row execute function public.founding_foodie_assign();

-- Il badge non si modifica dal client (anti-escalation: come ruolo/blocco)
create or replace function public.profiles_protect_founding()
returns trigger language plpgsql as $$
begin
  if new.founding_foodie_at is distinct from old.founding_foodie_at and not public.is_admin() and auth.uid() is not null then
    new.founding_foodie_at := old.founding_foodie_at;
  end if;
  return new;
end $$;
drop trigger if exists profiles_protect_founding on public.profiles;
create trigger profiles_protect_founding before update on public.profiles for each row execute function public.profiles_protect_founding();

-- ────────────────────────────────────────────────────────────────────
--  9. EVENTI APP E SUPPORTO: nuove categorie (additive)
-- ────────────────────────────────────────────────────────────────────
alter table public.app_events drop constraint if exists app_events_event_type_check;
alter table public.app_events add constraint app_events_event_type_check check (event_type in (
  'map_open', 'location_permission_requested', 'location_permission_granted', 'location_permission_denied',
  'restaurant_marker_click', 'directions_click', 'near_me_search', 'map_area_search',
  'search', 'landing_view', 'install_prompt_shown', 'install_accepted', 'experiment_exposure', 'qr_kit_download', 'feedback_opened'));

alter table public.support_tickets drop constraint if exists support_tickets_category_check;
alter table public.support_tickets add constraint support_tickets_category_check check (category in (
  'order', 'reservation', 'account', 'privacy', 'restaurant', 'business', 'billing', 'rider', 'bug', 'other',
  'coupon', 'points', 'payments', 'claim', 'menu', 'subscription', 'ads'));

-- ────────────────────────────────────────────────────────────────────
-- 10. RLS (tutte le tabelle nuove): CRM, costi, incidenti, contenuti, obiettivi, piano → solo Admin.
--     Pubblico: solo tramite RPC che restituiscono aggregati o dati già pubblici.
-- ────────────────────────────────────────────────────────────────────
alter table public.markets                    enable row level security;
alter table public.market_cities              enable row level security;
alter table public.crm_leads                  enable row level security;
alter table public.crm_activities             enable row level security;
alter table public.crm_tasks                  enable row level security;
alter table public.founding_partners          enable row level security;
alter table public.acquisition_codes          enable row level security;
alter table public.acquisition_visits         enable row level security;
alter table public.user_acquisition           enable row level security;
alter table public.marketing_content          enable row level security;
alter table public.ambassadors                enable row level security;
alter table public.product_feedback           enable row level security;
alter table public.launch_incidents           enable row level security;
alter table public.growth_goals               enable row level security;
alter table public.acquisition_costs          enable row level security;
alter table public.experiments                enable row level security;
alter table public.launch_plan_items          enable row level security;
alter table public.restaurant_launch_progress enable row level security;

create policy "markets_read" on public.markets for select using (true);
create policy "markets_admin" on public.markets for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "market_cities_read" on public.market_cities for select using (true);
create policy "market_cities_admin" on public.market_cities for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "crm_leads_admin" on public.crm_leads for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "crm_activities_admin" on public.crm_activities for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "crm_tasks_admin" on public.crm_tasks for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "founding_admin" on public.founding_partners for select to authenticated using (public.is_admin() or public.can_manage_restaurant(restaurant_id));
create policy "acq_codes_admin" on public.acquisition_codes for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "acq_visits_admin" on public.acquisition_visits for select to authenticated using (public.is_admin());
create policy "user_acq_admin" on public.user_acquisition for select to authenticated using (public.is_admin() or user_id = (select auth.uid()));
create policy "content_admin" on public.marketing_content for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "ambassadors_own_or_admin" on public.ambassadors for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
create policy "feedback_own_or_admin" on public.product_feedback for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
create policy "incidents_admin" on public.launch_incidents for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "goals_admin" on public.growth_goals for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "costs_admin" on public.acquisition_costs for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "experiments_admin" on public.experiments for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "plan_admin" on public.launch_plan_items for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "launch_progress_owner" on public.restaurant_launch_progress for select to authenticated using (public.can_manage_restaurant(restaurant_id));

grant select on public.markets, public.market_cities to anon, authenticated;
grant select, insert, update, delete on public.crm_leads, public.crm_activities, public.crm_tasks, public.acquisition_codes, public.marketing_content,
  public.launch_incidents, public.growth_goals, public.acquisition_costs, public.experiments, public.launch_plan_items, public.markets, public.market_cities to authenticated;
grant select on public.founding_partners, public.acquisition_visits, public.user_acquisition, public.ambassadors, public.product_feedback,
  public.restaurant_launch_progress to authenticated;
-- Scritture su feedback/ambassador/attribuzione/visite/progressi: solo tramite RPC con validazione e rate limit
revoke insert, update, delete on public.founding_partners, public.acquisition_visits, public.user_acquisition, public.ambassadors,
  public.product_feedback, public.restaurant_launch_progress from anon, authenticated;

-- Log di audit sulle azioni commerciali sensibili (programma Fondatori, fasi di lancio)
drop trigger if exists audit_founding on public.founding_partners;
create trigger audit_founding after insert or update of status on public.founding_partners
  for each row execute function public.audit_row_trigger('founding_status_change', 'status');
drop trigger if exists audit_markets on public.markets;
create trigger audit_markets after update of status on public.markets
  for each row execute function public.audit_row_trigger('market_status_change', 'status');

-- ────────────────────────────────────────────────────────────────────
-- 11. RIGHE DI LANCIO PER RISTORANTE (base di copertura, qualità, segmenti, First 50)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.launch_restaurant_rows(p_market uuid)
returns table (
  id uuid, name text, slug text, city_id uuid, city_name text, city_slug text, city_priority int, is_demo boolean, is_active boolean,
  closed boolean, claimed boolean, verified boolean, partner boolean, paying boolean, founding boolean, plan text,
  completion int, missing jsonb, has_menu boolean, no_coords boolean, no_hours boolean, no_phone boolean, stale boolean,
  duplicate boolean, position_far boolean, claimable boolean, is_ayce boolean, has_delivery boolean,
  priority_score int, segment_suggested text, segment text,
  lead_id uuid, lead_status text, assigned_to uuid, next_action text, next_action_at timestamptz, last_contact_at timestamptz,
  potential_plan text, contact_allowed boolean, phone text, whatsapp text, email text, instagram text, website text,
  last_verified_at timestamptz, views_30d int
) language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare
  v_prov uuid := (select province_id from public.markets where id = p_market);
  v_demo boolean := public.launch_include_demo();
  v_stale int := public.billing_setting_int('data_stale_days', 180);
begin
  return query
  with base as (
    select r.*, c.name as c_name, c.slug as c_slug, c.latitude as c_lat, c.longitude as c_lng, mc.priority as c_prio,
           public.restaurant_completion(r.id) as comp,
           lower(regexp_replace(r.name, '[^A-Za-z0-9]', '', 'g')) as norm_name,
           nullif(regexp_replace(coalesce(r.phone, ''), '[^0-9]', '', 'g'), '') as norm_phone
      from public.restaurants r
      join public.cities c on c.id = r.city_id
      left join public.market_cities mc on mc.market_id = p_market and mc.city_id = r.city_id
     where coalesce(r.province_id, c.province_id) = v_prov and (not r.is_demo or v_demo)
  ), flags as (
    select b.*,
      (b.is_permanently_closed or b.is_temporarily_closed) as f_closed,
      (b.owner_id is not null) as f_claimed,
      (b.is_verified or b.data_status = 'verified') as f_verified,
      exists (select 1 from public.founding_partners fp where fp.restaurant_id = b.id and fp.status in ('active', 'completed')) as f_founding,
      exists (select 1 from public.subscriptions s where s.restaurant_id = b.id and s.source = 'stripe' and s.paid_started_at is not null
                 and public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)) as f_paying,
      exists (select 1 from public.subscriptions s where s.restaurant_id = b.id and s.plan_code <> 'free' and public.subscription_grants_access(s)) as f_plan,
      exists (select 1 from base o where o.id <> b.id and ((o.norm_name = b.norm_name and o.city_id = b.city_id and length(b.norm_name) > 2)
                                                          or (o.norm_phone is not null and o.norm_phone = b.norm_phone))) as f_dup,
      exists (select 1 from base o where o.id <> b.id and o.norm_name = b.norm_name and length(b.norm_name) > 3) as f_multi,
      (b.latitude is not null and b.c_lat is not null and public.geo_distance_km(b.latitude, b.longitude, b.c_lat, b.c_lng) > 25) as f_far,
      coalesce((select count(*) from public.analytics_events e where e.restaurant_id = b.id and e.event_type = 'restaurant_view'
                  and e.created_at > now() - interval '30 days'), 0)::int as f_views
      from base b
  ), scored as (
    select f.*,
      (case when f.is_all_you_can_eat then 20 else 0 end
       + case when f.has_delivery or f.has_takeaway then 10 else 0 end
       + case when (f.comp ->> 'has_menu')::boolean then 10 else 0 end
       + case when coalesce(f.instagram, f.facebook, f.tiktok) is not null then 10 else 0 end
       + case when f.f_multi then 15 else 0 end
       + case when f.c_prio = 1 then 15 when f.c_prio between 2 and 4 then 10 when f.c_prio between 5 and 10 then 5 else 0 end
       + case when f.has_reservation then 5 else 0 end
       + ((f.comp ->> 'score')::int / 10)
       + least(10, f.f_views / 20))::int as p_score
      from flags f
  )
  select s.id, s.name, s.slug, s.city_id, s.c_name, s.c_slug, s.c_prio, s.is_demo, s.is_active,
         s.f_closed, s.f_claimed, s.f_verified, (s.f_claimed and (s.f_founding or s.f_plan)), s.f_paying, s.f_founding, s.subscription_plan,
         (s.comp ->> 'score')::int, s.comp -> 'missing', (s.comp ->> 'has_menu')::boolean,
         s.latitude is null, not (s.comp ->> 'has_hours')::boolean, coalesce(s.phone, s.whatsapp) is null,
         (s.last_verified_at is null or s.last_verified_at < now() - make_interval(days => v_stale)) and s.owner_id is null,
         s.f_dup, s.f_far,
         (s.owner_id is null and not s.f_closed and coalesce(s.phone, s.whatsapp, s.email, s.instagram, s.website) is not null),
         s.is_all_you_can_eat, (s.has_delivery or s.has_takeaway),
         s.p_score,
         case when s.p_score >= 50 then 'A' when s.p_score >= 30 then 'B' else 'C' end,
         coalesce(l.segment_override, case when s.p_score >= 50 then 'A' when s.p_score >= 30 then 'B' else 'C' end),
         l.id, l.status, l.assigned_to, l.next_action, l.next_action_at, l.last_contact_at, l.potential_plan, coalesce(l.contact_allowed, true),
         s.phone, s.whatsapp, s.email, s.instagram, s.website, s.last_verified_at, s.f_views
    from scored s
    left join public.crm_leads l on l.restaurant_id = s.id;
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 12. METRICHE (definizioni in docs/launch/METRICS.md)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.launch_market_ids(p_market uuid)
returns setof uuid language sql stable security definer set search_path = public as $$
  select r.id from public.restaurants r join public.cities c on c.id = r.city_id
   where coalesce(r.province_id, c.province_id) = (select province_id from public.markets where id = p_market)
     and (not r.is_demo or public.launch_include_demo());
$$;

create or replace function public.launch_metric(p_market uuid, p_key text, p_from timestamptz, p_to timestamptz)
returns numeric language plpgsql stable security definer set search_path = public as $$
begin
  return case p_key
    when 'restaurants_listed' then (select count(*) from public.restaurants r join public.launch_market_ids(p_market) mr(id) on mr.id = r.id where r.is_active and not r.is_permanently_closed)
    when 'restaurants_verified' then (select count(*) from public.restaurants r join public.launch_market_ids(p_market) mr(id) on mr.id = r.id where r.is_active and (r.is_verified or r.data_status = 'verified'))
    when 'restaurants_claimed' then (select count(*) from public.restaurants r join public.launch_market_ids(p_market) mr(id) on mr.id = r.id where r.owner_id is not null)
    when 'restaurants_partner' then (select count(*) from public.restaurants r join public.launch_market_ids(p_market) mr(id) on mr.id = r.id where r.owner_id is not null and (
        exists (select 1 from public.founding_partners fp where fp.restaurant_id = r.id and fp.status in ('active', 'completed'))
        or exists (select 1 from public.subscriptions s where s.restaurant_id = r.id and s.plan_code <> 'free' and public.subscription_grants_access(s))))
    when 'restaurants_paying' then (select count(distinct s.restaurant_id) from public.subscriptions s join public.launch_market_ids(p_market) mr(id) on mr.id = s.restaurant_id
        where s.source = 'stripe' and s.paid_started_at is not null and public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s))
    when 'mrr_cents' then (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s join public.launch_market_ids(p_market) mr(id) on mr.id = s.restaurant_id
        where public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s))
    when 'users_registered' then (select count(*) from public.profiles where role = 'customer' and created_at < p_to)
    when 'users_active_30d' then (select count(distinct user_id) from public.user_activity_days where day > (p_to at time zone 'Europe/Rome')::date - 30 and day <= (p_to at time zone 'Europe/Rome')::date)
    when 'reservations' then (select count(*) from public.reservations x join public.launch_market_ids(p_market) mr(id) on mr.id = x.restaurant_id
        where x.created_at >= p_from and x.created_at < p_to and x.status not in ('rejected', 'cancelled'))
    when 'orders_completed' then (select count(*) from public.orders o join public.launch_market_ids(p_market) mr(id) on mr.id = o.restaurant_id where o.status = 'completed' and o.completed_at >= p_from and o.completed_at < p_to)
    when 'gmv' then (select coalesce(sum(o.total), 0) from public.orders o join public.launch_market_ids(p_market) mr(id) on mr.id = o.restaurant_id
        where o.payment_status in ('paid', 'partially_refunded') and o.status not in ('rejected', 'cancelled', 'refunded') and o.paid_at >= p_from and o.paid_at < p_to)
    when 'coupon_claims' then (select count(*) from public.coupon_claims x join public.launch_market_ids(p_market) mr(id) on mr.id = x.restaurant_id where x.claimed_at >= p_from and x.claimed_at < p_to)
    when 'coupon_redeemed' then (select count(*) from public.coupon_claims x join public.launch_market_ids(p_market) mr(id) on mr.id = x.restaurant_id where x.status = 'redeemed' and x.redeemed_at >= p_from and x.redeemed_at < p_to)
    when 'reviews_published' then (select count(*) from public.reviews x join public.launch_market_ids(p_market) mr(id) on mr.id = x.restaurant_id where x.status = 'published' and coalesce(x.published_at, x.created_at) >= p_from and coalesce(x.published_at, x.created_at) < p_to)
    when 'referrals_qualified' then (select count(*) from public.referrals where qualified_at >= p_from and qualified_at < p_to)
    when 'sponsored_campaigns' then (select count(*) from public.sponsored_campaigns x join public.launch_market_ids(p_market) mr(id) on mr.id = x.restaurant_id where x.status = 'active')
    when 'qr_scans' then (select count(*) from public.analytics_events e join public.launch_market_ids(p_market) mr(id) on mr.id = e.restaurant_id where e.event_type = 'qr_scan' and e.created_at >= p_from and e.created_at < p_to)
    when 'food_connections' then
      (select count(*) from public.reservations x join public.launch_market_ids(p_market) mr(id) on mr.id = x.restaurant_id where x.status = 'completed'
          and x.reservation_date >= (p_from at time zone 'Europe/Rome')::date and x.reservation_date < (p_to at time zone 'Europe/Rome')::date)
      + (select count(*) from public.orders o join public.launch_market_ids(p_market) mr(id) on mr.id = o.restaurant_id where o.status = 'completed' and o.completed_at >= p_from and o.completed_at < p_to)
      + (select count(*) from public.coupon_claims x join public.launch_market_ids(p_market) mr(id) on mr.id = x.restaurant_id where x.status = 'redeemed' and x.redeemed_at >= p_from and x.redeemed_at < p_to)
      + (select count(*) from (select distinct e.restaurant_id, (e.created_at at time zone 'Europe/Rome')::date, coalesce(e.session_id, e.id::text)
                                 from public.analytics_events e join public.launch_market_ids(p_market) mr(id) on mr.id = e.restaurant_id
                                where e.event_type = 'directions_click' and e.created_at >= p_from and e.created_at < p_to) d)
    when 'visits' then (select count(*) from public.acquisition_visits where (market_id = p_market or market_id is null) and created_at >= p_from and created_at < p_to)
    else null end;
end $$;

-- Obiettivi: valore reale e stato (target operativi, non garanzie)
create or replace function public.launch_goals_refresh(p_market uuid)
returns void language plpgsql security definer set search_path = public as $$
declare g public.growth_goals; v numeric; v_elapsed numeric; v_ratio numeric; v_state_metric boolean;
begin
  for g in select * from public.growth_goals where market_id = p_market loop
    v_state_metric := g.metric_key in ('restaurants_listed', 'restaurants_verified', 'restaurants_claimed', 'restaurants_partner', 'restaurants_paying',
                                       'users_registered', 'users_active_30d', 'sponsored_campaigns', 'mrr_cents');
    v := public.launch_metric(p_market, g.metric_key,
           (g.period_start::timestamp at time zone 'Europe/Rome'),
           least(now(), ((g.period_end + 1)::timestamp at time zone 'Europe/Rome')));
    v_elapsed := greatest(0, least(1, (extract(epoch from now()) - extract(epoch from g.period_start::timestamp at time zone 'Europe/Rome'))
                       / nullif(extract(epoch from (g.period_end + 1)::timestamp at time zone 'Europe/Rome') - extract(epoch from g.period_start::timestamp at time zone 'Europe/Rome'), 0)));
    v_ratio := coalesce(v, 0) / g.target_value;
    update public.growth_goals set actual_value = v, refreshed_at = now(),
      status = case when v_ratio >= 1 then 'achieved'
                    -- Primo 10% del periodo: troppo presto per giudicare (non "in ritardo" al giorno 1)
                    when now() < g.period_start::timestamp at time zone 'Europe/Rome' or v_elapsed < 0.1 then 'not_started'
                    when v_ratio >= v_elapsed * 0.9 then 'on_track'
                    when v_ratio >= v_elapsed * 0.6 then 'at_risk'
                    else 'behind' end
     where id = g.id;
  end loop;
end $$;

-- Obiettivi iniziali suggeriti per Taranto (90 giorni dalla migrazione; modificabili). Prenotazioni: da misurare, nessun target.
insert into public.growth_goals (market_id, metric_key, target_value, period_start, period_end)
select m.id, x.k, x.t, current_date, current_date + 90
  from public.markets m
  cross join (values ('restaurants_listed', 100), ('restaurants_claimed', 30), ('restaurants_partner', 20), ('restaurants_paying', 10),
                     ('users_registered', 1000), ('users_active_30d', 500)) as x(k, t)
 where m.slug = 'taranto'
on conflict do nothing;

-- ────────────────────────────────────────────────────────────────────
-- 13. RPC PUBBLICHE (aggregati o dati già pubblici; rate limit; nessun dato personale)
-- ────────────────────────────────────────────────────────────────────
-- Scansione QR del kit: registra solo il tipo di QR sul locale (mai utente, IP o posizione)
create or replace function public.track_qr_scan(p_slug text, p_kind text)
returns void language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if p_kind not in ('profile', 'menu', 'review', 'booking', 'offer') then return; end if;
  select id into v_id from public.restaurants where slug = lower(left(p_slug, 120)) and public.restaurant_is_public(id);
  if v_id is null then return; end if;
  if not public.rate_limit_hit('qr_scan', public.rate_limit_caller_key(), 30, 60) then return; end if;
  insert into public.analytics_events (restaurant_id, event_type, source, metadata)
  values (v_id, 'qr_scan', 'qr', jsonb_build_object('kind', p_kind));
end $$;

-- Visita di atterraggio: canale + UTM (normalizzati). Nessun identificativo. Codici promo: solo conteggio.
create or replace function public.record_visit(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_channel text := lower(coalesce(p ->> 'channel', 'direct'));
  v_code text := upper(nullif(regexp_replace(coalesce(p ->> 'promo_code', ''), '[^A-Za-z0-9]', '', 'g'), ''));
  v_market uuid := (public.launch_market(coalesce(p ->> 'market', 'taranto'))).id;
  f text; v jsonb := '{}'::jsonb;
begin
  if not public.rate_limit_hit('visit', public.rate_limit_caller_key(), 20, 60) then return; end if;
  if v_channel not in ('organic_search', 'social', 'qr', 'direct', 'referral', 'restaurant_referral', 'paid_social', 'influencer', 'email', 'partner', 'offline', 'other') then
    v_channel := 'other';
  end if;
  foreach f in array array['utm_source', 'utm_medium', 'utm_campaign', 'utm_content'] loop
    v := v || jsonb_build_object(f, nullif(left(regexp_replace(lower(coalesce(p ->> f, '')), '[^a-z0-9_.-]', '', 'g'), 60), ''));
  end loop;
  if v_code is not null and not exists (select 1 from public.acquisition_codes where code = v_code and is_active) then v_code := null; end if;
  insert into public.acquisition_visits (market_id, channel, utm_source, utm_medium, utm_campaign, utm_content, landing_path, promo_code)
  values (v_market, v_channel, v ->> 'utm_source', v ->> 'utm_medium', v ->> 'utm_campaign', v ->> 'utm_content',
          left(regexp_replace(coalesce(p ->> 'landing_path', ''), '[?#].*$', ''), 200), v_code);
  if v_code is not null then update public.acquisition_codes set uses = uses + 1 where code = v_code; end if;
end $$;

-- Attribuzione dell'iscrizione (una sola volta, entro 7 giorni dalla registrazione). Il client la invia solo con consenso "Statistiche".
create or replace function public.attribute_my_signup(p jsonb)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_channel text := lower(coalesce(p ->> 'channel', 'direct'));
begin
  if v_uid is null then return false; end if;
  if exists (select 1 from public.user_acquisition where user_id = v_uid) then return false; end if;
  if not exists (select 1 from public.profiles where id = v_uid and created_at > now() - interval '7 days') then return false; end if;
  if v_channel not in ('organic_search', 'social', 'qr', 'direct', 'referral', 'restaurant_referral', 'paid_social', 'influencer', 'email', 'partner', 'offline', 'other') then
    v_channel := 'other';
  end if;
  insert into public.user_acquisition (user_id, market_id, channel, utm_source, utm_medium, utm_campaign, promo_code)
  values (v_uid, (public.launch_market(coalesce(p ->> 'market', 'taranto'))).id, v_channel,
          nullif(left(regexp_replace(lower(coalesce(p ->> 'utm_source', '')), '[^a-z0-9_.-]', '', 'g'), 60), ''),
          nullif(left(regexp_replace(lower(coalesce(p ->> 'utm_medium', '')), '[^a-z0-9_.-]', '', 'g'), 60), ''),
          nullif(left(regexp_replace(lower(coalesce(p ->> 'utm_campaign', '')), '[^a-z0-9_.-]', '', 'g'), 60), ''),
          (select code from public.acquisition_codes where code = upper(p ->> 'promo_code') and is_active))
  on conflict (user_id) do nothing;
  return true;
end $$;

-- Badge "Partner Fondatore": solo per aderenti reali (attivi o con beneficio concluso), mai per i revocati
create or replace function public.founding_badge(p_restaurant uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select case when public.billing_setting_bool('founding_badge_enabled', true) and public.restaurant_is_public(p_restaurant) then
    (select jsonb_build_object('number', fp.number, 'label', public.billing_setting_text('founding_program_name', 'Partner Fondatore'),
                               'since', fp.activated_at)
       from public.founding_partners fp where fp.restaurant_id = p_restaurant and fp.status in ('active', 'completed') and fp.badge_visible) end;
$$;

-- Landing di mercato (/taranto): solo numeri aggregati di locali pubblici. Nessuna pagina "vuota": il client decide cosa mostrare.
create or replace function public.market_landing(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets; v_min int := public.billing_setting_int('seo_min_restaurants_category_city', 2);
begin
  m := public.launch_market(p_market);
  if m.id is null then return null; end if;
  return (
    with pub as (
      select r.* from public.restaurants r join public.cities c on c.id = r.city_id
       where coalesce(r.province_id, c.province_id) = m.province_id and public.restaurant_is_public(r.id) and not r.is_permanently_closed
    )
    select jsonb_build_object(
      'market', jsonb_build_object('slug', m.slug, 'name', m.name, 'status', m.status),
      'min_per_page', v_min,
      'total', (select count(*) from pub),
      'ayce', (select count(*) from pub where is_all_you_can_eat),
      'delivery', (select count(*) from pub where has_delivery),
      'with_offers', (select count(distinct o.restaurant_id) from public.offers o join pub on pub.id = o.restaurant_id
                       where o.is_active and o.starts_at <= now() and (o.ends_at is null or o.ends_at > now())),
      'categories', coalesce((select jsonb_agg(jsonb_build_object('slug', k.slug, 'name', k.name, 'emoji', k.emoji, 'count', k.n) order by k.n desc, k.name)
                               from (select cat.slug, cat.name, cat.emoji, count(*) n from pub join public.restaurant_categories rc on rc.restaurant_id = pub.id
                                       join public.categories cat on cat.id = rc.category_id group by cat.slug, cat.name, cat.emoji) k), '[]'::jsonb),
      'cities', coalesce((select jsonb_agg(jsonb_build_object('slug', k.slug, 'name', k.name, 'count', k.n) order by k.n desc, k.name)
                           from (select c.slug, c.name, count(*) n from pub join public.cities c on c.id = pub.city_id group by c.slug, c.name) k), '[]'::jsonb),
      'category_city', coalesce((select jsonb_agg(jsonb_build_object('category', k.cat, 'city', k.city, 'city_name', k.city_name, 'count', k.n))
                                  from (select cat.slug cat, c.slug city, c.name city_name, count(*) n from pub join public.restaurant_categories rc on rc.restaurant_id = pub.id
                                          join public.categories cat on cat.id = rc.category_id join public.cities c on c.id = pub.city_id
                                         group by cat.slug, c.slug, c.name having count(*) >= v_min) k), '[]'::jsonb)
    ));
end $$;

create or replace function public.running_experiments()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('key', key, 'variants', variants)), '[]'::jsonb) from public.experiments where status = 'running';
$$;

-- Feedback in-app (utenti, ristoratori, NPS, motivo di disdetta). Mai obbligatorio, mai blocca un'azione.
create or replace function public.submit_feedback(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_type text := coalesce(p ->> 'type', 'user_general');
  v_rest uuid;
  v_id uuid;
begin
  if v_type not in ('user_general', 'restaurant_dashboard', 'nps', 'cancellation', 'bug', 'feature_request') then raise exception 'Tipo non valido' using errcode = '22023'; end if;
  if v_uid is null and v_type <> 'user_general' then raise exception 'Accedi per inviare questo feedback' using errcode = '42501'; end if;
  perform public.rate_limit_assert('feedback', 6, 3600);
  if coalesce(p ->> 'restaurant_id', '') ~ '^[0-9a-f-]{36}$' then
    v_rest := (p ->> 'restaurant_id')::uuid;
    if not public.can_manage_restaurant(v_rest) then raise exception 'Operazione non consentita' using errcode = '42501'; end if;
  end if;
  if v_type in ('restaurant_dashboard', 'cancellation') and v_rest is null then raise exception 'Seleziona il locale' using errcode = '22023'; end if;
  insert into public.product_feedback (user_id, restaurant_id, type, rating, reason, message, page)
  values (v_uid, v_rest, v_type, nullif(p ->> 'rating', '')::int,
          nullif(regexp_replace(lower(coalesce(p ->> 'reason', '')), '[^a-z_]', '', 'g'), ''),
          nullif(left(trim(coalesce(p ->> 'message', '')), 2000), ''), left(p ->> 'page', 120))
  returning id into v_id;
  return jsonb_build_object('id', v_id);
end $$;

-- NPS: solo dopo uso significativo e al massimo una volta ogni N giorni (mai "bombardare")
create or replace function public.nps_should_ask()
returns boolean language plpgsql stable security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_actions int;
begin
  if v_uid is null or not public.billing_setting_bool('nps_enabled', false) then return false; end if;
  if exists (select 1 from public.profiles where id = v_uid and (role <> 'customer' or created_at > now() - interval '7 days')) then return false; end if;
  if exists (select 1 from public.product_feedback where user_id = v_uid and type = 'nps'
               and created_at > now() - make_interval(days => public.billing_setting_int('nps_interval_days', 90))) then return false; end if;
  select (select count(*) from public.reservations where user_id = v_uid and status = 'completed')
       + (select count(*) from public.orders where user_id = v_uid and status = 'completed')
       + (select count(*) from public.coupon_claims where user_id = v_uid and status = 'redeemed') into v_actions;
  return v_actions >= public.billing_setting_int('nps_min_actions', 3);
end $$;

-- Ambassador: candidatura volontaria; nessun compenso automatico (regole e compliance da definire)
create or replace function public.ambassador_apply(p_motivation text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v public.ambassadors;
begin
  if v_uid is null then raise exception 'Accedi per candidarti' using errcode = '42501'; end if;
  if not public.billing_setting_bool('ambassador_program_enabled', false) then raise exception 'Il programma Ambassador non è ancora aperto' using errcode = 'P0001'; end if;
  perform public.rate_limit_assert('ambassador_apply', 3, 86400);
  insert into public.ambassadors (user_id, market_id, referral_code, motivation)
  values (v_uid, (public.launch_market('taranto')).id, public.ensure_referral_code(v_uid), nullif(left(trim(p_motivation), 1000), ''))
  on conflict (user_id) do update set motivation = coalesce(excluded.motivation, public.ambassadors.motivation)
  returning * into v;
  return jsonb_build_object('status', v.status, 'referral_code', v.referral_code);
end $$;

create or replace function public.my_ambassador()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object('enabled', public.billing_setting_bool('ambassador_program_enabled', false),
    'status', a.status, 'referral_code', a.referral_code, 'joined_at', a.joined_at,
    'founding_foodie_at', (select founding_foodie_at from public.profiles where id = auth.uid()))
    from (select 1) x left join public.ambassadors a on a.user_id = auth.uid();
$$;

-- Kit di lancio del ristoratore: checklist calcolata dai dati reali + passi manuali
create or replace function public.launch_kit_status(p_restaurant uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare r public.restaurants; c jsonb; pr public.restaurant_launch_progress; fp public.founding_partners;
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Operazione non consentita' using errcode = '42501'; end if;
  select * into r from public.restaurants where id = p_restaurant;
  c := public.restaurant_completion(p_restaurant);
  select * into pr from public.restaurant_launch_progress where restaurant_id = p_restaurant;
  select * into fp from public.founding_partners where restaurant_id = p_restaurant;
  return jsonb_build_object(
    'completion', c,
    'steps', jsonb_build_array(
      jsonb_build_object('key', 'profile', 'done', (c ->> 'score')::int >= 80),
      jsonb_build_object('key', 'menu', 'done', (c ->> 'has_menu')::boolean),
      jsonb_build_object('key', 'hours', 'done', (c ->> 'has_hours')::boolean),
      jsonb_build_object('key', 'photos', 'done', r.cover_url is not null or r.logo_url is not null or exists (select 1 from public.restaurant_images where restaurant_id = p_restaurant)),
      jsonb_build_object('key', 'qr', 'done', pr.qr_kit_downloaded_at is not null),
      jsonb_build_object('key', 'first_offer', 'done', exists (select 1 from public.offers where restaurant_id = p_restaurant)),
      jsonb_build_object('key', 'reservations', 'done', exists (select 1 from public.reservation_settings where restaurant_id = p_restaurant and reservation_enabled) or r.reservation_url is not null),
      jsonb_build_object('key', 'notifications', 'done', exists (select 1 from public.restaurant_members m join public.push_subscriptions ps on ps.user_id = m.user_id
                                                                 where m.restaurant_id = p_restaurant and m.status = 'active')
                                                        or exists (select 1 from public.restaurant_members m join public.notification_preferences np on np.user_id = m.user_id
                                                                 where m.restaurant_id = p_restaurant and m.status = 'active')),
      jsonb_build_object('key', 'social_launch', 'done', pr.social_launch_at is not null)),
    'progress', to_jsonb(pr),
    'founding', case when fp.id is not null and fp.status <> 'revoked' then jsonb_build_object('number', fp.number, 'status', fp.status,
      'plan', fp.benefit_plan, 'benefit_ends_at', fp.benefit_ends_at, 'label', public.billing_setting_text('founding_program_name', 'Partner Fondatore')) end,
    'slug', r.slug, 'name', r.name);
end $$;

create or replace function public.launch_kit_mark(p_restaurant uuid, p_step text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Operazione non consentita' using errcode = '42501'; end if;
  if p_step not in ('starter_kit_viewed', 'qr_kit_downloaded', 'materials_printed', 'social_launch', 'social_launch_undo') then raise exception 'Passo non valido'; end if;
  insert into public.restaurant_launch_progress (restaurant_id) values (p_restaurant) on conflict do nothing;
  update public.restaurant_launch_progress set
    starter_kit_viewed_at = case when p_step = 'starter_kit_viewed' then coalesce(starter_kit_viewed_at, now()) else starter_kit_viewed_at end,
    qr_kit_downloaded_at = case when p_step = 'qr_kit_downloaded' then coalesce(qr_kit_downloaded_at, now()) else qr_kit_downloaded_at end,
    materials_printed_at = case when p_step = 'materials_printed' then coalesce(materials_printed_at, now()) else materials_printed_at end,
    social_launch_at = case when p_step = 'social_launch' then coalesce(social_launch_at, now()) when p_step = 'social_launch_undo' then null else social_launch_at end,
    updated_at = now()
   where restaurant_id = p_restaurant;
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 14. CRM — RPC ADMIN
-- ────────────────────────────────────────────────────────────────────
create or replace function public.launch_assert_admin()
returns void language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
end $$;

create or replace function public.admin_crm_leads(p_market text, p_kind text default 'restaurant', p_status text default null,
  p_search text default null, p_limit int default 50, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets; v_rows jsonb; v_total int; v_q text := nullif(lower(trim(coalesce(p_search, ''))), '');
begin
  perform public.launch_assert_admin();
  m := public.launch_market(p_market);
  with f as (
    select l.* from public.crm_leads l
     where l.market_id = m.id and (p_kind is null or l.kind = p_kind)
       and (p_status is null or l.status = p_status
            or (p_status = 'open' and l.status not in ('lost', 'not_interested', 'do_not_contact', 'paid', 'closed'))
            or (p_status = 'due' and l.next_action_at < (current_date + 1)::timestamp at time zone 'Europe/Rome'))
       and (v_q is null or lower(l.name) like '%' || v_q || '%' or lower(coalesce(l.contact_name, '')) like '%' || v_q || '%')
  )
  select (select count(*) from f)::int,
         coalesce(jsonb_agg(to_jsonb(x) order by x.next_action_at nulls last, x.updated_at desc), '[]'::jsonb) into v_total, v_rows
    from (select f.*, c.name as city_name, r.slug as restaurant_slug,
                 (select coalesce(p.display_name, p.full_name, p.email) from public.profiles p where p.id = f.assigned_to) as assigned_name,
                 (select count(*) from public.crm_tasks t where t.lead_id = f.id and t.status = 'open')::int as open_tasks
            from f left join public.cities c on c.id = f.city_id left join public.restaurants r on r.id = f.restaurant_id
           order by f.next_action_at nulls last, f.updated_at desc
           limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)) x;
  return jsonb_build_object('total', v_total, 'rows', v_rows);
end $$;

create or replace function public.admin_crm_lead(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare l public.crm_leads;
begin
  perform public.launch_assert_admin();
  select * into l from public.crm_leads where id = p_id;
  if not found then raise exception 'Lead non trovato' using errcode = 'P0002'; end if;
  return jsonb_build_object(
    'lead', to_jsonb(l) || jsonb_build_object('city_name', (select name from public.cities where id = l.city_id)),
    'restaurant', (select jsonb_build_object('id', r.id, 'name', r.name, 'slug', r.slug, 'phone', r.phone, 'whatsapp', r.whatsapp, 'email', r.email,
                     'website', r.website, 'instagram', r.instagram, 'facebook', r.facebook, 'claimed', r.owner_id is not null, 'is_active', r.is_active,
                     'plan', r.subscription_plan, 'completion', public.restaurant_completion(r.id),
                     'founding', (select to_jsonb(fp) from public.founding_partners fp where fp.restaurant_id = r.id),
                     'claim_status', (select c.status from public.restaurant_claims c where c.restaurant_id = r.id order by c.created_at desc limit 1))
                   from public.restaurants r where r.id = l.restaurant_id),
    'activities', coalesce((select jsonb_agg(to_jsonb(a) || jsonb_build_object('by_name', (select coalesce(p.display_name, p.full_name) from public.profiles p where p.id = a.created_by))
                             order by a.created_at desc) from public.crm_activities a where a.lead_id = p_id), '[]'::jsonb),
    'tasks', coalesce((select jsonb_agg(to_jsonb(t) order by t.status, t.due_at nulls last) from public.crm_tasks t where t.lead_id = p_id or (l.restaurant_id is not null and t.restaurant_id = l.restaurant_id)), '[]'::jsonb));
end $$;

create or replace function public.admin_crm_upsert_lead(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_id uuid := nullif(p ->> 'id', '')::uuid;
  l public.crm_leads;
  m public.markets := public.launch_market(coalesce(p ->> 'market', 'taranto'));
  v_rest uuid := nullif(p ->> 'restaurant_id', '')::uuid;
  v_tools text[];
begin
  perform public.launch_assert_admin();
  if p ? 'competitor_tools' then
    select coalesce(array_agg(x), '{}') into v_tools from jsonb_array_elements_text(p -> 'competitor_tools') x;
  end if;
  if v_id is null then
    if v_rest is not null and exists (select 1 from public.crm_leads where restaurant_id = v_rest) then
      select id into v_id from public.crm_leads where restaurant_id = v_rest;
    else
      insert into public.crm_leads (market_id, kind, category, restaurant_id, name, city_id)
      values (m.id, coalesce(p ->> 'kind', 'restaurant'), nullif(p ->> 'category', ''), v_rest,
              coalesce(nullif(trim(p ->> 'name'), ''), (select name from public.restaurants where id = v_rest)),
              coalesce(nullif(p ->> 'city_id', '')::uuid, (select city_id from public.restaurants where id = v_rest)))
      returning id into v_id;
    end if;
  end if;
  select * into l from public.crm_leads where id = v_id for update;
  if not found then raise exception 'Lead non trovato' using errcode = 'P0002'; end if;
  update public.crm_leads set
    name              = case when p ? 'name' and coalesce(trim(p ->> 'name'), '') <> '' then trim(p ->> 'name') else l.name end,
    category          = case when p ? 'category' then nullif(p ->> 'category', '') else l.category end,
    city_id           = case when p ? 'city_id' then nullif(p ->> 'city_id', '')::uuid else l.city_id end,
    contact_name      = case when p ? 'contact_name' then nullif(trim(p ->> 'contact_name'), '') else l.contact_name end,
    phone             = case when p ? 'phone' then nullif(trim(p ->> 'phone'), '') else l.phone end,
    email             = case when p ? 'email' then nullif(lower(trim(p ->> 'email')), '') else l.email end,
    instagram         = case when p ? 'instagram' then nullif(trim(p ->> 'instagram'), '') else l.instagram end,
    tiktok            = case when p ? 'tiktok' then nullif(trim(p ->> 'tiktok'), '') else l.tiktok end,
    website           = case when p ? 'website' then nullif(trim(p ->> 'website'), '') else l.website end,
    followers         = case when p ? 'followers' then nullif(p ->> 'followers', '')::int else l.followers end,
    status            = case when p ? 'status' then p ->> 'status' else l.status end,
    segment_override  = case when p ? 'segment_override' then nullif(p ->> 'segment_override', '') else l.segment_override end,
    assigned_to       = case when p ? 'assigned_to' then nullif(p ->> 'assigned_to', '')::uuid else l.assigned_to end,
    next_action       = case when p ? 'next_action' then nullif(trim(p ->> 'next_action'), '') else l.next_action end,
    next_action_at    = case when p ? 'next_action_at' then nullif(p ->> 'next_action_at', '')::timestamptz else l.next_action_at end,
    potential_plan    = case when p ? 'potential_plan' then nullif(p ->> 'potential_plan', '') else l.potential_plan end,
    competitor_tools  = case when p ? 'competitor_tools' then v_tools else l.competitor_tools end,
    competitor_source = case when p ? 'competitor_source' then nullif(p ->> 'competitor_source', '') else l.competitor_source end,
    contact_allowed   = case when p ? 'contact_allowed' then (p ->> 'contact_allowed')::boolean else l.contact_allowed end,
    lost_reason       = case when p ? 'lost_reason' then nullif(trim(p ->> 'lost_reason'), '') else l.lost_reason end,
    notes             = case when p ? 'notes' then nullif(p ->> 'notes', '') else l.notes end
   where id = v_id;
  if p ? 'assigned_to' and nullif(p ->> 'assigned_to', '') is not null
     and not exists (select 1 from public.profiles where id = (p ->> 'assigned_to')::uuid and role = 'admin') then
    raise exception 'Il lead si assegna solo a un membro dello staff' using errcode = '22023';
  end if;
  if p ? 'status' and (p ->> 'status') is distinct from l.status then
    insert into public.crm_activities (lead_id, type, notes) values (v_id, 'status_change', l.status || ' → ' || (p ->> 'status'));
  end if;
  return v_id;
end $$;

create or replace function public.admin_crm_log_activity(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare l public.crm_leads; v_id uuid; v_type text := p ->> 'type';
begin
  perform public.launch_assert_admin();
  select * into l from public.crm_leads where id = (p ->> 'lead_id')::uuid;
  if not found then raise exception 'Lead non trovato' using errcode = 'P0002'; end if;
  if not l.contact_allowed and v_type in ('call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'claim_link_sent', 'follow_up') then
    raise exception 'Questo contatto ha chiesto di non essere ricontattato' using errcode = 'P0001';
  end if;
  insert into public.crm_activities (lead_id, type, outcome, notes, disclosure_required)
  values (l.id, v_type, nullif(p ->> 'outcome', ''), nullif(left(trim(coalesce(p ->> 'notes', '')), 2000), ''),
          case when v_type = 'collaboration' then coalesce((p ->> 'disclosure_required')::boolean, true) end)
  returning id into v_id;
  if p ? 'next_action' or p ? 'next_action_at' then
    update public.crm_leads set next_action = nullif(trim(coalesce(p ->> 'next_action', '')), ''),
                                next_action_at = nullif(p ->> 'next_action_at', '')::timestamptz
     where id = l.id;
  end if;
  if (p ->> 'outcome') = 'not_interested' then
    update public.crm_leads set status = 'not_interested', next_action = null, next_action_at = null where id = l.id and status not in ('claimed', 'trial', 'activated', 'paid');
  end if;
  return v_id;
end $$;

-- Crea un lead per ogni locale del mercato che non ne ha uno (idempotente). Nessun dato di contatto duplicato: resta sulla scheda.
create or replace function public.admin_crm_sync_restaurant_leads(p_market text default 'taranto')
returns int language plpgsql security definer set search_path = public as $$
declare m public.markets; n int;
begin
  perform public.launch_assert_admin();
  m := public.launch_market(p_market);
  insert into public.crm_leads (market_id, kind, restaurant_id, name, city_id, status)
  select m.id, 'restaurant', x.id, x.name, x.city_id,
         case when x.paying then 'paid' when x.claimed then 'claimed' else 'new' end
    from public.launch_restaurant_rows(m.id) x
   where not x.closed and x.lead_id is null
  on conflict do nothing;
  get diagnostics n = row_count;
  perform public.audit_admin('crm_leads_synced', 'market', m.id::text, jsonb_build_object('created', n));
  return n;
end $$;

create or replace function public.admin_crm_task_upsert(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  perform public.launch_assert_admin();
  if v_id is null then
    insert into public.crm_tasks (market_id, lead_id, restaurant_id, title, due_at, assigned_to, source)
    values ((public.launch_market(coalesce(p ->> 'market', 'taranto'))).id, nullif(p ->> 'lead_id', '')::uuid, nullif(p ->> 'restaurant_id', '')::uuid,
            trim(p ->> 'title'), nullif(p ->> 'due_at', '')::timestamptz, nullif(p ->> 'assigned_to', '')::uuid, 'manual')
    returning id into v_id;
  else
    update public.crm_tasks set title = coalesce(nullif(trim(p ->> 'title'), ''), title),
      due_at = case when p ? 'due_at' then nullif(p ->> 'due_at', '')::timestamptz else due_at end,
      assigned_to = case when p ? 'assigned_to' then nullif(p ->> 'assigned_to', '')::uuid else assigned_to end
     where id = v_id;
  end if;
  return v_id;
end $$;

create or replace function public.admin_crm_task_set_status(p_id uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  if p_status not in ('open', 'done', 'dismissed') then raise exception 'Stato non valido'; end if;
  update public.crm_tasks set status = p_status, done_at = case when p_status = 'open' then null else now() end where id = p_id;
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 15. PARTNER FONDATORI — attivazione manuale dell'Admin (mai automatica), limite configurabile
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_founding_activate(p_restaurant uuid, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  r public.restaurants; m public.markets; v_n int; v_plan text; v_days int; v_sub uuid; v_existing public.founding_partners; v_paying boolean;
begin
  perform public.launch_assert_admin();
  if not public.billing_setting_bool('founding_program_enabled', true) then raise exception 'Il programma Partner Fondatori è disattivato' using errcode = 'P0001'; end if;
  select * into r from public.restaurants where id = p_restaurant for update;
  if not found then raise exception 'Locale non trovato' using errcode = 'P0002'; end if;
  select * into m from public.markets where province_id = coalesce(r.province_id, (select province_id from public.cities where id = r.city_id)) limit 1;
  if m.id is null then raise exception 'Il locale non appartiene a un mercato attivo' using errcode = 'P0001'; end if;
  -- Solo ristoranti realmente aderenti: rivendicati con un titolare attivo
  if r.owner_id is null or not exists (select 1 from public.restaurant_members where restaurant_id = r.id and role = 'owner' and status = 'active') then
    raise exception 'Il locale deve essere rivendicato da un titolare prima di aderire' using errcode = 'P0001';
  end if;
  select * into v_existing from public.founding_partners where restaurant_id = r.id;
  if v_existing.id is not null and v_existing.status <> 'revoked' then raise exception 'Il locale è già Partner Fondatore' using errcode = 'P0001'; end if;
  if (select count(*) from public.founding_partners where market_id = m.id and status in ('active', 'completed'))
     >= public.billing_setting_int('founding_limit', 30) then
    raise exception 'Posti da Partner Fondatore esauriti per questo mercato' using errcode = 'P0001';
  end if;
  v_plan := coalesce(public.billing_setting_text('founding_plan', 'premium'), 'premium');
  v_days := greatest(public.billing_setting_int('founding_days', 30), 0);
  v_paying := exists (select 1 from public.subscriptions s where s.restaurant_id = r.id and s.source = 'stripe' and public.subscription_grants_access(s));
  -- Beneficio: piano gratuito a tempo (nessun addebito automatico alla scadenza). Chi paga già su Stripe non riceve un secondo piano.
  if v_days > 0 and v_plan <> 'free' and not v_paying then
    v_sub := public.admin_grant_plan(r.id, v_plan, now() + make_interval(days => v_days), 'promo',
                                     left('Partner Fondatore — ' || coalesce(p_note, ''), 500));
  end if;
  v_n := coalesce(v_existing.number, (select coalesce(max(number), 0) + 1 from public.founding_partners where market_id = m.id));
  if v_existing.id is not null then
    update public.founding_partners set status = 'active', benefit_plan = v_plan, benefit_days = case when v_sub is null then 0 else v_days end,
      subscription_id = v_sub, activated_at = now(), benefit_ends_at = case when v_sub is null then null else now() + make_interval(days => v_days) end,
      revoked_at = null, revoked_reason = null, badge_visible = true, notes = left(p_note, 1000), activated_by = auth.uid()
     where id = v_existing.id;
  else
    insert into public.founding_partners (market_id, restaurant_id, number, benefit_plan, benefit_days, subscription_id, benefit_ends_at, notes)
    values (m.id, r.id, v_n, v_plan, case when v_sub is null then 0 else v_days end, v_sub,
            case when v_sub is null then null else now() + make_interval(days => v_days) end, left(p_note, 1000));
  end if;
  perform public.crm_advance_restaurant_lead(r.id, 'trial', 'Partner Fondatore attivato');
  perform public.audit_admin('founding_activated', 'restaurant', r.id::text, jsonb_build_object('number', v_n, 'plan', v_plan, 'days', v_days, 'paying', v_paying));
  return jsonb_build_object('number', v_n, 'plan', v_plan, 'days', case when v_sub is null then 0 else v_days end, 'subscription_id', v_sub);
end $$;

create or replace function public.admin_founding_revoke(p_restaurant uuid, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare fp public.founding_partners;
begin
  perform public.launch_assert_admin();
  if coalesce(trim(p_reason), '') = '' then raise exception 'Indica il motivo' using errcode = '22023'; end if;
  select * into fp from public.founding_partners where restaurant_id = p_restaurant and status <> 'revoked';
  if not found then raise exception 'Nessuna adesione attiva' using errcode = 'P0002'; end if;
  update public.founding_partners set status = 'revoked', revoked_at = now(), revoked_reason = left(p_reason, 300), badge_visible = false where id = fp.id;
  if fp.subscription_id is not null and exists (select 1 from public.subscriptions where id = fp.subscription_id and revoked_at is null and source <> 'stripe') then
    perform public.admin_revoke_plan(fp.subscription_id);
  end if;
  perform public.audit_admin('founding_revoked', 'restaurant', p_restaurant::text, jsonb_build_object('reason', left(p_reason, 300)));
end $$;

create or replace function public.admin_founding_list(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets := public.launch_market(p_market);
begin
  perform public.launch_assert_admin();
  return jsonb_build_object(
    'enabled', public.billing_setting_bool('founding_program_enabled', true),
    'name', public.billing_setting_text('founding_program_name', 'Partner Fondatore'),
    'limit', public.billing_setting_int('founding_limit', 30),
    'plan', public.billing_setting_text('founding_plan', 'premium'),
    'days', public.billing_setting_int('founding_days', 30),
    'badge_enabled', public.billing_setting_bool('founding_badge_enabled', true),
    'used', (select count(*) from public.founding_partners where market_id = m.id and status in ('active', 'completed')),
    'rows', coalesce((select jsonb_agg(to_jsonb(fp) || jsonb_build_object('restaurant_name', r.name, 'restaurant_slug', r.slug,
                        'days_left', case when fp.benefit_ends_at is not null then greatest(0, ceil(extract(epoch from fp.benefit_ends_at - now()) / 86400))::int end,
                        'paying', exists (select 1 from public.subscriptions s where s.restaurant_id = r.id and s.source = 'stripe' and s.paid_started_at is not null
                                           and public.subscription_grants_access(s)))
                        order by fp.number)
                      from public.founding_partners fp join public.restaurants r on r.id = fp.restaurant_id where fp.market_id = m.id), '[]'::jsonb));
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 16. DASHBOARD DI LANCIO
-- ────────────────────────────────────────────────────────────────────
-- Query locali prioritarie (PARTE 12): pronte quando la pagina categoria×città ha abbastanza locali pubblici
create or replace function public.launch_local_queries(p_market uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  with q(label, cat, city) as (values
    ('sushi Taranto', 'sushi', 'taranto'), ('all you can eat Taranto', 'all-you-can-eat', 'taranto'),
    ('ristorante giapponese Taranto', 'giapponese', 'taranto'), ('ristorante cinese Taranto', 'cinese', 'taranto'),
    ('poke Taranto', 'poke', 'taranto'), ('ramen Taranto', 'ramen', 'taranto'), ('sushi Massafra', 'sushi', 'massafra'),
    ('sushi Martina Franca', 'sushi', 'martina-franca'), ('sushi Grottaglie', 'sushi', 'grottaglie'))
  select coalesce(jsonb_agg(jsonb_build_object('query', q.label, 'path', '/' || q.cat || '/' || q.city, 'count', n.c,
                    'ready', n.c >= public.billing_setting_int('seo_min_restaurants_category_city', 2))), '[]'::jsonb)
    from q cross join lateral (
      select count(*)::int c from public.restaurants r join public.cities ci on ci.id = r.city_id and ci.slug = q.city
        join public.restaurant_categories rc on rc.restaurant_id = r.id join public.categories k on k.id = rc.category_id and k.slug = q.cat
       where public.restaurant_is_public(r.id) and not r.is_permanently_closed
         and r.id in (select public.launch_market_ids(p_market))) n;
$$;

create or replace function public.admin_launch_overview(p_market text default 'taranto')
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  m public.markets; v_now timestamptz := now(); v_30 timestamptz := now() - interval '30 days';
  v_k jsonb; v_prog jsonb; v_alerts jsonb := '[]'::jsonb; v_lq jsonb; v_rows int; v_cnt int; v_names text;
  g record;
begin
  perform public.launch_assert_admin();
  m := public.launch_market(p_market);
  if m.id is null then raise exception 'Mercato non trovato' using errcode = 'P0002'; end if;
  perform public.launch_goals_refresh(m.id);
  v_lq := public.launch_local_queries(m.id);

  select jsonb_build_object(
    'censused', count(*) filter (where not x.closed or x.is_active),
    'drafts', count(*) filter (where not x.is_active),
    'listed', count(*) filter (where x.is_active and not x.closed),
    'verified', count(*) filter (where x.verified and x.is_active),
    'claimed', count(*) filter (where x.claimed),
    'partner', count(*) filter (where x.partner),
    'paying', count(*) filter (where x.paying),
    'premium_top', count(*) filter (where x.plan in ('premium', 'top')),
    'founding', count(*) filter (where x.founding),
    'avg_completion', round(avg(x.completion)),
    'demo', count(*) filter (where x.is_demo))
    into v_k from public.launch_restaurant_rows(m.id) x;
  select count(*) into v_rows from public.launch_restaurant_rows(m.id);

  v_k := v_k || jsonb_build_object(
    'users', public.launch_metric(m.id, 'users_registered', v_30, v_now),
    'users_active_30d', public.launch_metric(m.id, 'users_active_30d', v_30, v_now),
    'reservations_30d', public.launch_metric(m.id, 'reservations', v_30, v_now),
    'orders_30d', public.launch_metric(m.id, 'orders_completed', v_30, v_now),
    'gmv_30d', public.launch_metric(m.id, 'gmv', v_30, v_now),
    'orders_enabled', public.billing_setting_bool('orders_enabled', true),
    'coupon_claims_30d', public.launch_metric(m.id, 'coupon_claims', v_30, v_now),
    'coupon_redeemed_30d', public.launch_metric(m.id, 'coupon_redeemed', v_30, v_now),
    'reviews_30d', public.launch_metric(m.id, 'reviews_published', v_30, v_now),
    'mrr_cents', public.launch_metric(m.id, 'mrr_cents', v_30, v_now),
    'qr_scans_30d', public.launch_metric(m.id, 'qr_scans', v_30, v_now),
    'food_connections_30d', public.launch_metric(m.id, 'food_connections', v_30, v_now),
    'visits_30d', public.launch_metric(m.id, 'visits', v_30, v_now),
    'referrals', (select jsonb_build_object('invited', count(*), 'registered', count(*) filter (where registered_at is not null),
                    'qualified', count(*) filter (where qualified_at is not null), 'rewarded', count(*) filter (where rewarded_at is not null)) from public.referrals),
    'business_referrals', (select jsonb_build_object('invited', count(*), 'qualified', count(*) filter (where status in ('qualified', 'approved', 'rewarded')),
                             'rewarded', count(*) filter (where status = 'rewarded')) from public.business_referrals),
    'sponsored', jsonb_build_object('active', public.launch_metric(m.id, 'sponsored_campaigns', v_30, v_now),
                   'impressions_30d', (select count(*) from public.analytics_events e join public.launch_market_ids(m.id) mr(id) on mr.id = e.restaurant_id
                                        where e.event_type = 'sponsored_impression' and e.created_at > v_30),
                   'clicks_30d', (select count(*) from public.analytics_events e join public.launch_market_ids(m.id) mr(id) on mr.id = e.restaurant_id
                                   where e.event_type = 'sponsored_click' and e.created_at > v_30)),
    'traffic_by_channel', coalesce((select jsonb_object_agg(channel, n) from (select channel, count(*) n from public.acquisition_visits
                             where created_at > v_30 and (market_id = m.id or market_id is null) group by channel) t), '{}'::jsonb),
    'seo', jsonb_build_object(
      'restaurant_pages', (select count(*) from public.restaurants r where public.restaurant_is_public(r.id) and r.id in (select public.launch_market_ids(m.id))),
      'city_pages', (select count(distinct r.city_id) from public.restaurants r where public.restaurant_is_public(r.id) and r.id in (select public.launch_market_ids(m.id))),
      'local_queries_ready', (select count(*) from jsonb_array_elements(v_lq) e where (e ->> 'ready')::boolean),
      'local_queries_total', jsonb_array_length(v_lq)));

  -- Progressi calcolati dai dati reali verso i target operativi (growth_goals; se assenti, i valori suggeriti dichiarati)
  v_prog := jsonb_build_array(
    public.launch_progress_item('database', 'Database locale', (v_k ->> 'listed')::numeric,
      coalesce((select target_value from public.growth_goals where market_id = m.id and metric_key = 'restaurants_listed' order by period_start desc limit 1), 100)),
    public.launch_progress_item('claims', 'Rivendicazioni', (v_k ->> 'claimed')::numeric,
      coalesce((select target_value from public.growth_goals where market_id = m.id and metric_key = 'restaurants_claimed' order by period_start desc limit 1), 30)),
    public.launch_progress_item('partners', 'Onboarding partner', (v_k ->> 'partner')::numeric,
      coalesce((select target_value from public.growth_goals where market_id = m.id and metric_key = 'restaurants_partner' order by period_start desc limit 1), 20)),
    public.launch_progress_item('paying', 'Ristoranti paganti', (v_k ->> 'paying')::numeric,
      coalesce((select target_value from public.growth_goals where market_id = m.id and metric_key = 'restaurants_paying' order by period_start desc limit 1), 10)),
    public.launch_progress_item('seo', 'SEO locale (query prioritarie pronte)', (v_k -> 'seo' ->> 'local_queries_ready')::numeric, (v_k -> 'seo' ->> 'local_queries_total')::numeric),
    public.launch_progress_item('consumers', 'Acquisizione utenti', (v_k ->> 'users')::numeric,
      coalesce((select target_value from public.growth_goals where market_id = m.id and metric_key = 'users_registered' order by period_start desc limit 1), 1000)));

  -- Avvisi operativi
  select count(*) into v_cnt from public.restaurant_claims c where c.status in ('pending', 'under_review', 'more_information_required');
  if v_cnt > 0 then
    v_alerts := v_alerts || jsonb_build_object('level',
      case when exists (select 1 from public.restaurant_claims c where c.status in ('pending', 'under_review')
                          and c.created_at < now() - make_interval(hours => public.billing_setting_int('sla_claim_review_hours', 48))) then 'high' else 'medium' end,
      'key', 'claims_pending', 'text', format('%s %s aspetta%s revisione.', v_cnt, case when v_cnt = 1 then 'rivendicazione' else 'rivendicazioni' end,
                                               case when v_cnt = 1 then '' else 'no' end), 'link', '/admin/claims');
  end if;
  for g in
    select r.name, ceil(extract(epoch from coalesce(s.expires_at, s.trial_end) - now()) / 86400)::int as d, initcap(s.plan_code) as plan
      from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
     where r.id in (select public.launch_market_ids(m.id)) and public.subscription_grants_access(s)
       and ((s.source <> 'stripe' and s.expires_at between now() and now() + interval '3 days')
            or (s.source = 'stripe' and s.status = 'trialing' and s.trial_end between now() and now() + interval '3 days'))
     order by 2 limit 10
  loop
    v_alerts := v_alerts || jsonb_build_object('level', 'medium', 'key', 'trial_ending',
      'text', format('Il piano %s di %s termina tra %s %s.', g.plan, g.name, g.d, case when g.d = 1 then 'giorno' else 'giorni' end), 'link', '/admin/launch/taranto/partners');
  end loop;
  select string_agg(ci.name, ', ' order by mc.priority), count(*) into v_names, v_cnt
    from public.market_cities mc join public.cities ci on ci.id = mc.city_id
   where mc.market_id = m.id and mc.priority <= 10
     and not exists (select 1 from public.restaurants r where r.city_id = mc.city_id and r.is_active and (r.is_verified or r.data_status = 'verified' or r.owner_id is not null)
                       and (not r.is_demo or public.launch_include_demo()));
  if v_cnt > 0 then
    v_alerts := v_alerts || jsonb_build_object('level', 'low', 'key', 'city_no_verified',
      'text', format('%s %s con 0 ristoranti verificati: %s.', v_cnt, case when v_cnt = 1 then 'comune prioritario' else 'comuni prioritari' end, v_names),
      'link', '/admin/launch/taranto/coverage');
  end if;
  select count(*) into v_cnt from public.restaurant_reports where status in ('open', 'in_progress')
     and created_at < now() - make_interval(hours => public.billing_setting_int('sla_data_report_hours', 72));
  if v_cnt > 0 then
    v_alerts := v_alerts || jsonb_build_object('level', 'medium', 'key', 'reports_overdue', 'text', format('%s segnalazioni di dati errati oltre lo SLA interno.', v_cnt), 'link', '/admin/reports');
  end if;
  select count(*) into v_cnt from public.launch_incidents where status <> 'resolved' and severity in ('high', 'critical');
  if v_cnt > 0 then
    v_alerts := v_alerts || jsonb_build_object('level', 'high', 'key', 'incidents', 'text', format('%s incidenti di lancio gravi aperti.', v_cnt), 'link', '/admin/launch/taranto/today');
  end if;
  select count(*) into v_cnt from public.crm_tasks where status = 'open' and due_at < now();
  if v_cnt > 0 then
    v_alerts := v_alerts || jsonb_build_object('level', 'low', 'key', 'tasks_overdue', 'text', format('%s attività commerciali scadute.', v_cnt), 'link', '/admin/launch/taranto/daily');
  end if;
  select count(*) into v_cnt from public.growth_goals where market_id = m.id and status = 'behind';
  if v_cnt > 0 then
    v_alerts := v_alerts || jsonb_build_object('level', 'low', 'key', 'goals_behind', 'text', format('%s obiettivi in ritardo rispetto al periodo trascorso.', v_cnt), 'link', '/admin/launch/taranto/plan');
  end if;

  return jsonb_build_object(
    'market', to_jsonb(m), 'phase', public.billing_setting_text('launch_phase', 'private_beta'),
    'include_demo', public.launch_include_demo(), 'restaurants_rows', v_rows,
    'kpis', v_k, 'progress', v_prog, 'alerts', v_alerts, 'local_queries', v_lq,
    'pipeline', coalesce((select jsonb_object_agg(status, n) from (select status, count(*) n from public.crm_leads where market_id = m.id and kind = 'restaurant' group by status) t), '{}'::jsonb),
    'goals', coalesce((select jsonb_agg(to_jsonb(g2) order by g2.metric_key) from public.growth_goals g2 where g2.market_id = m.id), '[]'::jsonb),
    'north_star', (select jsonb_agg(jsonb_build_object('week', to_char(w, 'YYYY-MM-DD'),
                      'value', public.launch_metric(m.id, 'food_connections', w::date::timestamp at time zone 'Europe/Rome', (w::date + 7)::timestamp at time zone 'Europe/Rome')) order by w)
                   from generate_series(date_trunc('week', now() at time zone 'Europe/Rome')::date - 49, date_trunc('week', now() at time zone 'Europe/Rome')::date, interval '7 days') w),
    'generated_at', now());
end $$;

create or replace function public.launch_progress_item(p_key text, p_label text, p_value numeric, p_target numeric)
returns jsonb language sql immutable as $$
  select jsonb_build_object('key', p_key, 'label', p_label, 'value', coalesce(p_value, 0), 'target', p_target,
    'pct', case when coalesce(p_target, 0) <= 0 then 0 else least(100, round(coalesce(p_value, 0) * 100 / p_target))::int end);
$$;

create or replace function public.admin_launch_coverage(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets := public.launch_market(p_market);
begin
  perform public.launch_assert_admin();
  return (
    with x as (select * from public.launch_restaurant_rows(m.id)),
    cities as (
      select ci.id, ci.name, ci.slug, ci.latitude, ci.longitude, mc.priority
        from public.cities ci left join public.market_cities mc on mc.market_id = m.id and mc.city_id = ci.id
       where ci.province_id = m.province_id and (mc.city_id is not null or exists (select 1 from x where x.city_id = ci.id))
    )
    select jsonb_build_object('include_demo', public.launch_include_demo(), 'rows', coalesce(jsonb_agg(jsonb_build_object(
      'city_id', c.id, 'city', c.name, 'slug', c.slug, 'priority', c.priority, 'lat', c.latitude, 'lng', c.longitude,
      'censused', (select count(*) from x where x.city_id = c.id and (x.is_active or not x.closed)),
      'listed', (select count(*) from x where x.city_id = c.id and x.is_active and not x.closed),
      'verified', (select count(*) from x where x.city_id = c.id and x.verified and x.is_active),
      'unclaimed', (select count(*) from x where x.city_id = c.id and not x.claimed and not x.closed),
      'claimed', (select count(*) from x where x.city_id = c.id and x.claimed),
      'partner', (select count(*) from x where x.city_id = c.id and x.partner),
      'premium_top', (select count(*) from x where x.city_id = c.id and x.plan in ('premium', 'top')),
      'avg_completion', (select round(avg(x.completion)) from x where x.city_id = c.id))
      order by c.priority nulls last, c.name), '[]'::jsonb))
    from cities c);
end $$;

-- Elenco locali con completezza, problemi di qualità e segmento commerciale (interno)
create or replace function public.admin_launch_restaurants(p_market text default 'taranto', p_filter text default null, p_search text default null,
  p_limit int default 50, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets := public.launch_market(p_market); v_q text := nullif(lower(trim(coalesce(p_search, ''))), '');
begin
  perform public.launch_assert_admin();
  return (
    with x as (select * from public.launch_restaurant_rows(m.id)),
    f as (
      select * from x where (v_q is null or lower(x.name) like '%' || v_q || '%') and case p_filter
        when 'incomplete' then x.completion < 60 and not x.closed
        when 'no_coords' then x.no_coords and not x.closed
        when 'no_hours' then x.no_hours and not x.closed
        when 'no_phone' then x.no_phone and not x.closed
        when 'no_menu' then not x.has_menu and not x.closed
        when 'claimable' then x.claimable
        when 'stale' then x.stale and not x.closed
        when 'closed' then x.closed
        when 'duplicates' then x.duplicate
        when 'position' then x.position_far
        when 'segment_a' then x.segment = 'A' and not x.closed
        when 'segment_b' then x.segment = 'B' and not x.closed
        when 'segment_c' then x.segment = 'C' and not x.closed
        else true end)
    select jsonb_build_object(
      'include_demo', public.launch_include_demo(),
      'counts', (select jsonb_build_object(
          'all', count(*), 'incomplete', count(*) filter (where completion < 60 and not closed), 'no_coords', count(*) filter (where no_coords and not closed),
          'no_hours', count(*) filter (where no_hours and not closed), 'no_phone', count(*) filter (where no_phone and not closed),
          'no_menu', count(*) filter (where not has_menu and not closed), 'claimable', count(*) filter (where claimable),
          'stale', count(*) filter (where stale and not closed), 'closed', count(*) filter (where closed), 'duplicates', count(*) filter (where duplicate),
          'position', count(*) filter (where position_far), 'segment_a', count(*) filter (where segment = 'A' and not closed),
          'segment_b', count(*) filter (where segment = 'B' and not closed), 'segment_c', count(*) filter (where segment = 'C' and not closed)) from x),
      'total', (select count(*) from f),
      'rows', coalesce((select jsonb_agg(to_jsonb(y) order by y.priority_score desc, y.name)
                          from (select * from f order by f.priority_score desc, f.name limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)) y), '[]'::jsonb),
      'open_reports', (select count(*) from public.restaurant_reports rr where rr.status in ('open', 'in_progress') and rr.restaurant_id in (select id from x))));
end $$;

-- First N (50): priorità per l'outreach (segmento, punteggio, completezza). Esclusi chiusi, paganti, persi, da non contattare.
create or replace function public.admin_launch_first_n(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets := public.launch_market(p_market); n int := public.billing_setting_int('launch_first_n', 50);
begin
  perform public.launch_assert_admin();
  return jsonb_build_object('n', n, 'include_demo', public.launch_include_demo(), 'rows', coalesce((
    select jsonb_agg(to_jsonb(y) || jsonb_build_object('rank', y.rk,
             'assigned_name', (select coalesce(p.display_name, p.full_name, p.email) from public.profiles p where p.id = y.assigned_to),
             'claim_status', (select c.status from public.restaurant_claims c where c.restaurant_id = y.id order by c.created_at desc limit 1)) order by y.rk)
      from (select x.*, row_number() over (order by x.segment, x.priority_score desc, x.completion desc, x.name) rk
              from public.launch_restaurant_rows(m.id) x
             where not x.closed and not x.paying and x.contact_allowed
               and coalesce(x.lead_status, 'new') not in ('lost', 'not_interested', 'do_not_contact', 'paid')
             order by x.segment, x.priority_score desc, x.completion desc, x.name limit n) y), '[]'::jsonb));
end $$;

-- Dashboard commerciale giornaliera (target operativi: non promesse)
create or replace function public.admin_launch_daily(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  m public.markets := public.launch_market(p_market);
  v_today date := (now() at time zone 'Europe/Rome')::date;
  v_start timestamptz := v_today::timestamp at time zone 'Europe/Rome';
  v_end timestamptz := (v_today + 1)::timestamp at time zone 'Europe/Rome';
begin
  perform public.launch_assert_admin();
  return jsonb_build_object(
    'day', v_today,
    'targets', jsonb_build_object('research', public.billing_setting_int('launch_daily_target_research', 10),
      'contacts', public.billing_setting_int('launch_daily_target_contacts', 10), 'demos', public.billing_setting_int('launch_daily_target_demos', 3),
      'claims', public.billing_setting_int('launch_daily_target_claims', 2), 'trials', public.billing_setting_int('launch_daily_target_trials', 1)),
    'actual', jsonb_build_object(
      'research', (select count(*) from public.crm_activities a join public.crm_leads l on l.id = a.lead_id where l.market_id = m.id and a.type = 'research' and a.created_at >= v_start)
                  + (select count(*) from public.crm_leads where market_id = m.id and created_at >= v_start and created_by is not null),
      'contacts', (select count(distinct a.lead_id) from public.crm_activities a join public.crm_leads l on l.id = a.lead_id
                    where l.market_id = m.id and a.type in ('call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'follow_up', 'claim_link_sent') and a.created_at >= v_start),
      'demos', (select count(*) from public.crm_activities a join public.crm_leads l on l.id = a.lead_id where l.market_id = m.id and a.type = 'demo' and a.outcome = 'done' and a.created_at >= v_start),
      'claims', (select count(*) from public.restaurant_claims c where c.status = 'approved' and coalesce(c.approved_at, c.updated_at) >= v_start
                   and c.restaurant_id in (select public.launch_market_ids(m.id))),
      'trials', (select count(*) from public.founding_partners where market_id = m.id and activated_at >= v_start)
                + (select count(*) from public.subscriptions s where s.source = 'stripe' and s.trial_start >= v_start and s.restaurant_id in (select public.launch_market_ids(m.id)))),
    'due_leads', coalesce((select jsonb_agg(to_jsonb(y) order by y.next_action_at) from (
        select l.id, l.name, l.kind, l.status, l.next_action, l.next_action_at, l.last_contact_at, l.restaurant_id, c.name as city_name,
               (select coalesce(p.display_name, p.full_name) from public.profiles p where p.id = l.assigned_to) as assigned_name
          from public.crm_leads l left join public.cities c on c.id = l.city_id
         where l.market_id = m.id and l.next_action_at < v_end and l.status not in ('lost', 'not_interested', 'do_not_contact', 'closed')
         order by l.next_action_at limit 50) y), '[]'::jsonb),
    'follow_ups', coalesce((select jsonb_agg(to_jsonb(y)) from (
        select l.id, l.name, l.status, l.last_contact_at from public.crm_leads l
         where l.market_id = m.id and l.status in ('contacted', 'replied', 'demo_done', 'claim_sent') and l.next_action_at is null
           and l.last_contact_at < now() - interval '3 days' order by l.last_contact_at limit 30) y), '[]'::jsonb),
    'demos', coalesce((select jsonb_agg(to_jsonb(y) order by y.next_action_at nulls last) from (
        select l.id, l.name, l.next_action, l.next_action_at from public.crm_leads l where l.market_id = m.id and l.status = 'demo_scheduled' limit 30) y), '[]'::jsonb),
    'claims_pending', coalesce((select jsonb_agg(to_jsonb(y) order by y.created_at) from (
        select c.id, c.status, c.created_at, r.name as restaurant_name,
               round(extract(epoch from now() - c.created_at) / 3600)::int as age_hours,
               c.created_at < now() - make_interval(hours => public.billing_setting_int('sla_claim_review_hours', 48)) as overdue
          from public.restaurant_claims c join public.restaurants r on r.id = c.restaurant_id
         where c.status in ('pending', 'under_review', 'more_information_required') order by c.created_at limit 50) y), '[]'::jsonb),
    'trials_expiring', coalesce((select jsonb_agg(to_jsonb(y) order by y.ends_at) from (
        select r.id as restaurant_id, r.name, s.plan_code, s.source, coalesce(s.expires_at, s.trial_end) as ends_at,
               exists (select 1 from public.founding_partners fp where fp.restaurant_id = r.id and fp.status = 'active') as founding
          from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
         where r.id in (select public.launch_market_ids(m.id)) and public.subscription_grants_access(s)
           and ((s.source <> 'stripe' and s.expires_at between now() and now() + interval '7 days')
                or (s.source = 'stripe' and s.status = 'trialing' and s.trial_end between now() and now() + interval '7 days'))) y), '[]'::jsonb),
    'new_paying', coalesce((select jsonb_agg(to_jsonb(y)) from (
        select r.name, s.plan_code, s.paid_started_at from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
         where s.source = 'stripe' and s.paid_started_at > now() - interval '7 days' and r.id in (select public.launch_market_ids(m.id))
         order by s.paid_started_at desc) y), '[]'::jsonb),
    'tasks', coalesce((select jsonb_agg(to_jsonb(t) || jsonb_build_object('restaurant_name', (select name from public.restaurants where id = t.restaurant_id),
                          'lead_name', (select name from public.crm_leads where id = t.lead_id)) order by t.due_at nulls last)
                        from public.crm_tasks t where t.status = 'open' and (t.market_id = m.id or t.market_id is null) and (t.due_at is null or t.due_at < v_end)), '[]'::jsonb));
end $$;

-- Tempo al valore: mediane in ore dalla rivendicazione (approvata) ai passi successivi
create or replace function public.launch_time_to_value(p_market uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  with c as (
    select r.id, coalesce(r.claimed_at, (select max(approved_at) from public.restaurant_claims x where x.restaurant_id = r.id and x.status = 'approved')) as t0,
           r.onboarding_completed_at as profile_at,
           (select min(created_at) from public.menus where restaurant_id = r.id) as menu_at,
           (select min(created_at) from public.offers where restaurant_id = r.id) as offer_at,
           (select min(created_at) from public.reservations where restaurant_id = r.id and status not in ('rejected', 'cancelled')) as reservation_at,
           (select min(paid_started_at) from public.subscriptions where restaurant_id = r.id and source = 'stripe') as paid_at
      from public.restaurants r where r.owner_id is not null and r.id in (select public.launch_market_ids(p_market))
  )
  select jsonb_build_object(
    'claimed', (select count(*) from c where t0 is not null),
    'profile', jsonb_build_object('n', count(*) filter (where profile_at >= t0), 'median_hours', round((percentile_cont(0.5) within group (order by extract(epoch from profile_at - t0) / 3600) filter (where profile_at >= t0))::numeric, 1)),
    'menu', jsonb_build_object('n', count(*) filter (where menu_at >= t0), 'median_hours', round((percentile_cont(0.5) within group (order by extract(epoch from menu_at - t0) / 3600) filter (where menu_at >= t0))::numeric, 1)),
    'offer', jsonb_build_object('n', count(*) filter (where offer_at >= t0), 'median_hours', round((percentile_cont(0.5) within group (order by extract(epoch from offer_at - t0) / 3600) filter (where offer_at >= t0))::numeric, 1)),
    'reservation', jsonb_build_object('n', count(*) filter (where reservation_at >= t0), 'median_hours', round((percentile_cont(0.5) within group (order by extract(epoch from reservation_at - t0) / 3600) filter (where reservation_at >= t0))::numeric, 1)),
    'paid', jsonb_build_object('n', count(*) filter (where paid_at >= t0), 'median_hours', round((percentile_cont(0.5) within group (order by extract(epoch from paid_at - t0) / 3600) filter (where paid_at >= t0))::numeric, 1)))
  from c where t0 is not null;
$$;

-- Attivazione ristorante (definizione): profilo ≥ 70% + (menu o offerta) + almeno una azione misurabile di un cliente
create or replace function public.launch_restaurant_activated(p_restaurant uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(((public.restaurant_completion(p_restaurant) ->> 'score')::int >= 70)
     and ((public.restaurant_completion(p_restaurant) ->> 'has_menu')::boolean or exists (select 1 from public.offers where restaurant_id = p_restaurant))
     and (exists (select 1 from public.reservations where restaurant_id = p_restaurant and status not in ('rejected', 'cancelled'))
          or exists (select 1 from public.orders where restaurant_id = p_restaurant and status = 'completed')
          or exists (select 1 from public.coupon_claims where restaurant_id = p_restaurant)
          or exists (select 1 from public.analytics_events where restaurant_id = p_restaurant
                       and event_type in ('phone_click', 'whatsapp_click', 'directions_click', 'reservation_start', 'website_click'))), false);
$$;

create or replace function public.admin_launch_weekly(p_market text default 'taranto', p_weeks int default 8)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets := public.launch_market(p_market); v_weeks int := least(greatest(p_weeks, 1), 26);
begin
  perform public.launch_assert_admin();
  return jsonb_build_object(
    'weeks', (select jsonb_agg(jsonb_build_object(
        'week', to_char(w.d, 'YYYY-MM-DD'),
        'contacted', (select count(distinct a.lead_id) from public.crm_activities a join public.crm_leads l on l.id = a.lead_id
                       where l.market_id = m.id and a.type in ('call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'follow_up', 'claim_link_sent')
                         and a.created_at >= w.s and a.created_at < w.e),
        'replies', (select count(*) from public.crm_activities a join public.crm_leads l on l.id = a.lead_id
                     where l.market_id = m.id and a.outcome in ('replied', 'interested', 'scheduled') and a.created_at >= w.s and a.created_at < w.e),
        'claims', (select count(*) from public.restaurant_claims c where c.status = 'approved' and coalesce(c.approved_at, c.updated_at) >= w.s
                     and coalesce(c.approved_at, c.updated_at) < w.e and c.restaurant_id in (select public.launch_market_ids(m.id))),
        'trials', (select count(*) from public.founding_partners where market_id = m.id and activated_at >= w.s and activated_at < w.e)
                  + (select count(*) from public.subscriptions s where s.source = 'stripe' and s.trial_start >= w.s and s.trial_start < w.e
                       and s.restaurant_id in (select public.launch_market_ids(m.id))),
        'paid', (select count(*) from public.subscriptions s where s.source = 'stripe' and s.paid_started_at >= w.s and s.paid_started_at < w.e
                   and s.restaurant_id in (select public.launch_market_ids(m.id))),
        'new_users', (select count(*) from public.profiles where role = 'customer' and created_at >= w.s and created_at < w.e),
        'visits', public.launch_metric(m.id, 'visits', w.s, w.e),
        'reservations', public.launch_metric(m.id, 'reservations', w.s, w.e),
        'orders', public.launch_metric(m.id, 'orders_completed', w.s, w.e),
        'food_connections', public.launch_metric(m.id, 'food_connections', w.s, w.e)) order by w.d)
      from (select d, d::timestamp at time zone 'Europe/Rome' s, (d + 7)::timestamp at time zone 'Europe/Rome' e
              from generate_series(date_trunc('week', now() at time zone 'Europe/Rome')::date - (v_weeks - 1) * 7,
                                   date_trunc('week', now() at time zone 'Europe/Rome')::date, interval '7 days') g(d0),
                   lateral (select g.d0::date d) dd) w),
    'mrr_cents', public.launch_metric(m.id, 'mrr_cents', now(), now()),
    'feedback_loop', jsonb_build_object(
      'support_by_category', coalesce((select jsonb_object_agg(category, n) from (select category, count(*) n from public.support_tickets
                                  where created_at > now() - interval '7 days' group by category order by 2 desc) t), '{}'::jsonb),
      'incidents', coalesce((select jsonb_object_agg(severity, n) from (select severity, count(*) n from public.launch_incidents
                                  where created_at > now() - interval '7 days' group by severity) t), '{}'::jsonb),
      'feedback_by_type', coalesce((select jsonb_object_agg(type, n) from (select type, count(*) n from public.product_feedback
                                  where created_at > now() - interval '7 days' group by type) t), '{}'::jsonb),
      'cancellation_reasons', coalesce((select jsonb_object_agg(coalesce(reason, 'non_indicato'), n) from (select reason, count(*) n from public.product_feedback
                                  where type = 'cancellation' and created_at > now() - interval '90 days' group by reason) t), '{}'::jsonb),
      'nps', (select jsonb_build_object('responses', count(*), 'score', case when count(*) = 0 then null else
                  round((count(*) filter (where rating >= 9) - count(*) filter (where rating <= 6)) * 100.0 / count(*)) end)
                from public.product_feedback where type = 'nps' and created_at > now() - interval '90 days'),
      'latest_user', coalesce((select jsonb_agg(jsonb_build_object('message', message, 'type', type, 'created_at', created_at) order by created_at desc)
                                 from (select * from public.product_feedback where type in ('user_general', 'bug', 'feature_request') and message is not null
                                        order by created_at desc limit 8) f), '[]'::jsonb),
      'latest_restaurant', coalesce((select jsonb_agg(jsonb_build_object('message', message, 'restaurant', (select name from public.restaurants where id = f.restaurant_id), 'created_at', created_at) order by created_at desc)
                                 from (select * from public.product_feedback where type = 'restaurant_dashboard' order by created_at desc limit 8) f), '[]'::jsonb)),
    -- Funnel utente (ultimi 30 giorni): conteggi per fase, non percorso sequenziale dello stesso utente
    'user_funnel', jsonb_build_object(
      'visits', public.launch_metric(m.id, 'visits', now() - interval '30 days', now()),
      'searches', (select count(*) from public.app_events where event_type in ('search', 'near_me_search', 'map_area_search') and created_at > now() - interval '30 days'),
      'restaurant_views', (select count(*) from public.analytics_events e join public.launch_market_ids(m.id) mr(id) on mr.id = e.restaurant_id
                             where e.event_type = 'restaurant_view' and e.created_at > now() - interval '30 days'),
      'menu_views', (select count(*) from public.analytics_events e join public.launch_market_ids(m.id) mr(id) on mr.id = e.restaurant_id
                       where e.event_type = 'menu_view' and e.created_at > now() - interval '30 days'),
      'favorites', (select count(*) from public.favorites f join public.launch_market_ids(m.id) mr(id) on mr.id = f.restaurant_id where f.created_at > now() - interval '30 days'),
      'reservations_orders', public.launch_metric(m.id, 'reservations', now() - interval '30 days', now()) + public.launch_metric(m.id, 'orders_completed', now() - interval '30 days', now()),
      'reviews', public.launch_metric(m.id, 'reviews_published', now() - interval '30 days', now()),
      'returning_users', (select count(*) from (select user_id from public.user_activity_days where day > current_date - 30 group by user_id having count(*) >= 2) t)),
    'business_funnel', (select jsonb_build_object(
      'discovered', count(*) filter (where not x.closed),
      'lead', count(*) filter (where x.lead_id is not null),
      'contacted', count(*) filter (where x.last_contact_at is not null or public.crm_status_rank(x.lead_status) >= 2),
      'claimed', count(*) filter (where x.claimed),
      'trial', count(*) filter (where x.founding or public.crm_status_rank(x.lead_status) >= 8),
      'activated', count(*) filter (where x.claimed and public.launch_restaurant_activated(x.id)),
      'paid', count(*) filter (where x.paying),
      'retained', count(*) filter (where x.paying and exists (select 1 from public.subscriptions s where s.restaurant_id = x.id and s.source = 'stripe'
                                                                and s.paid_started_at < now() - interval '60 days')))
      from public.launch_restaurant_rows(m.id) x),
    'activation', jsonb_build_object(
      -- Utente attivato: almeno un preferito, coupon, prenotazione o ordine entro 30 giorni dall'iscrizione
      'users_signed_up_30_60d', (select count(*) from public.profiles where role = 'customer' and created_at between now() - interval '60 days' and now() - interval '30 days'),
      'users_activated_30_60d', (select count(*) from public.profiles p where p.role = 'customer' and p.created_at between now() - interval '60 days' and now() - interval '30 days'
                                   and (exists (select 1 from public.favorites f where f.user_id = p.id and f.created_at < p.created_at + interval '30 days')
                                     or exists (select 1 from public.coupon_claims c where c.user_id = p.id and c.claimed_at < p.created_at + interval '30 days')
                                     or exists (select 1 from public.reservations r where r.user_id = p.id and r.created_at < p.created_at + interval '30 days')
                                     or exists (select 1 from public.orders o where o.user_id = p.id and o.created_at < p.created_at + interval '30 days' and o.payment_status = 'paid'))),
      'restaurants_claimed', (select count(*) from public.launch_restaurant_rows(m.id) x where x.claimed),
      'restaurants_activated', (select count(*) from public.launch_restaurant_rows(m.id) x where x.claimed and public.launch_restaurant_activated(x.id))),
    'cohorts', jsonb_build_object(
      'users', (select coalesce(jsonb_agg(jsonb_build_object('week', to_char(w, 'YYYY-MM-DD'), 'size', t.size, 'returned_week2', t.w2, 'returned_after', t.later) order by w), '[]'::jsonb)
                  from generate_series(date_trunc('week', now() at time zone 'Europe/Rome')::date - 7 * 7, date_trunc('week', now() at time zone 'Europe/Rome')::date, interval '7 days') w,
                  lateral (select count(*) size,
                                  count(*) filter (where exists (select 1 from public.user_activity_days a where a.user_id = p.id and a.day between (p.created_at at time zone 'Europe/Rome')::date + 7 and (p.created_at at time zone 'Europe/Rome')::date + 13)) w2,
                                  count(*) filter (where exists (select 1 from public.user_activity_days a where a.user_id = p.id and a.day >= (p.created_at at time zone 'Europe/Rome')::date + 7)) later
                             from public.profiles p where p.role = 'customer' and p.created_at >= w::timestamp at time zone 'Europe/Rome' and p.created_at < (w + interval '7 days')::timestamp at time zone 'Europe/Rome') t),
      'restaurants', (select coalesce(jsonb_agg(jsonb_build_object('week', to_char(w, 'YYYY-MM-DD'), 'claimed', t.n, 'activated', t.act, 'paid', t.paid) order by w), '[]'::jsonb)
                  from generate_series(date_trunc('week', now() at time zone 'Europe/Rome')::date - 7 * 7, date_trunc('week', now() at time zone 'Europe/Rome')::date, interval '7 days') w,
                  lateral (select count(*) n, count(*) filter (where public.launch_restaurant_activated(r.id)) act,
                                  count(*) filter (where exists (select 1 from public.subscriptions s where s.restaurant_id = r.id and s.source = 'stripe' and s.paid_started_at is not null)) paid
                             from public.restaurants r where r.owner_id is not null and r.claimed_at >= w::timestamp at time zone 'Europe/Rome'
                              and r.claimed_at < (w + interval '7 days')::timestamp at time zone 'Europe/Rome' and r.id in (select public.launch_market_ids(m.id))) t),
      'trial_conversion', (select jsonb_build_object('founding_completed', count(*) filter (where fp.status = 'completed'),
                             'founding_converted', count(*) filter (where fp.status = 'completed' and exists (select 1 from public.subscriptions s where s.restaurant_id = fp.restaurant_id
                                                                     and s.source = 'stripe' and s.paid_started_at is not null)),
                             'stripe_trials_ended', (select count(*) from public.billing_trials where ends_at <= now() or converted_at is not null),
                             'stripe_trials_converted', (select count(*) from public.billing_trials where converted_at is not null))
                           from public.founding_partners fp where fp.market_id = m.id)),
    'time_to_value', public.launch_time_to_value(m.id));
end $$;

-- Partner success: health score di UTILIZZO della piattaforma (non qualità del ristorante) + segnali di rischio + ROI misurato
create or replace function public.launch_partner_rows(p_market uuid)
returns table (restaurant_id uuid, name text, slug text, city_name text, plan text, founding boolean, paying boolean, completion int,
  has_menu boolean, active_offers int, last_owner_activity date, pending_reservations_24h int, customer_actions_30d int,
  health int, trial_ends_at timestamptz, flags text[], roi jsonb)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare v_nologin int := public.billing_setting_int('partner_no_login_days', 14); v_zero int := public.billing_setting_int('partner_zero_activity_days', 30);
begin
  return query
  with p as (
    select x.id, x.name, x.slug, x.city_name, x.plan, x.founding, x.paying, x.completion, x.has_menu,
      (select count(*) from public.offers o where o.restaurant_id = x.id and o.is_active and (o.ends_at is null or o.ends_at > now()))::int as offers,
      (select max(a.day) from public.user_activity_days a join public.restaurant_members rm on rm.user_id = a.user_id
        where rm.restaurant_id = x.id and rm.status = 'active') as last_act,
      (select count(*) from public.reservations rv where rv.restaurant_id = x.id and rv.status = 'pending' and rv.created_at < now() - interval '24 hours')::int as pend,
      (select count(*) from public.analytics_events e where e.restaurant_id = x.id and e.created_at > now() - make_interval(days => v_zero)
          and e.event_type in ('phone_click', 'whatsapp_click', 'directions_click', 'reservation_start', 'website_click', 'coupon_claim', 'reservation_completed', 'order_completed'))::int
        + (select count(*) from public.reservations rv where rv.restaurant_id = x.id and rv.created_at > now() - make_interval(days => v_zero))::int as acts,
      (select min(coalesce(s.expires_at, s.trial_end)) from public.subscriptions s where s.restaurant_id = x.id and public.subscription_grants_access(s)
          and ((s.source <> 'stripe' and s.expires_at is not null) or (s.source = 'stripe' and s.status = 'trialing'))) as tends,
      jsonb_build_object(
        'views', (select count(*) from public.analytics_events e where e.restaurant_id = x.id and e.event_type = 'restaurant_view' and e.created_at > now() - interval '30 days'),
        'calls', (select count(*) from public.analytics_events e where e.restaurant_id = x.id and e.event_type in ('phone_click', 'whatsapp_click') and e.created_at > now() - interval '30 days'),
        'directions', (select count(*) from public.analytics_events e where e.restaurant_id = x.id and e.event_type = 'directions_click' and e.created_at > now() - interval '30 days'),
        'bookings', (select count(*) from public.reservations rv where rv.restaurant_id = x.id and rv.status not in ('rejected', 'cancelled') and rv.created_at > now() - interval '30 days'),
        'orders', (select count(*) from public.orders o where o.restaurant_id = x.id and o.status = 'completed' and o.completed_at > now() - interval '30 days'),
        'coupon_uses', (select count(*) from public.coupon_claims c where c.restaurant_id = x.id and c.status = 'redeemed' and c.redeemed_at > now() - interval '30 days'),
        'qr_scans', (select count(*) from public.analytics_events e where e.restaurant_id = x.id and e.event_type = 'qr_scan' and e.created_at > now() - interval '30 days')) as roi
      from public.launch_restaurant_rows(p_market) x where x.claimed
  )
  select p.id, p.name, p.slug, p.city_name, p.plan, p.founding, p.paying, p.completion, p.has_menu, p.offers, p.last_act, p.pend, p.acts,
    (round(p.completion * 0.3)
      + case when p.has_menu then 15 else 0 end
      + case when p.last_act >= current_date - 7 then 20 when p.last_act >= current_date - v_nologin then 10 else 0 end
      + case when p.offers > 0 then 15 else 0 end
      + case when p.pend = 0 then 10 else 0 end
      + case when p.acts > 0 then 10 else 0 end)::int,
    p.tends,
    array_remove(array[
      case when p.tends is not null and p.tends < now() + interval '7 days' then 'trial_ending' end,
      case when p.last_act is null or p.last_act < current_date - v_nologin then 'no_login' end,
      case when p.completion < 60 then 'profile_incomplete' end,
      case when p.acts = 0 then 'zero_activity' end,
      case when p.pend > 0 then 'reservations_waiting' end], null),
    p.roi
  from p;
end $$;

create or replace function public.admin_launch_partners(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m public.markets := public.launch_market(p_market);
begin
  perform public.launch_assert_admin();
  return jsonb_build_object(
    'rows', coalesce((select jsonb_agg(to_jsonb(p) order by cardinality(p.flags) desc, p.health) from public.launch_partner_rows(m.id) p), '[]'::jsonb),
    'at_risk', (select count(*) from public.launch_partner_rows(m.id) p where p.flags && array['trial_ending', 'no_login', 'profile_incomplete', 'zero_activity']),
    'founding', public.admin_founding_list(p_market),
    'time_to_value', public.launch_time_to_value(m.id));
end $$;

-- Task di follow-up per i partner a rischio (idempotente: uno aperto per locale e motivo)
create or replace function public.launch_generate_followups(p_market uuid)
returns int language plpgsql security definer set search_path = public as $$
declare n int := 0; k int; p record; f text;
begin
  for p in select * from public.launch_partner_rows(p_market) where cardinality(flags) > 0 loop
    foreach f in array p.flags loop
      continue when f = 'reservations_waiting';
      insert into public.crm_tasks (market_id, restaurant_id, lead_id, title, reason, due_at, source, created_by)
      values (p_market, p.restaurant_id, (select id from public.crm_leads where restaurant_id = p.restaurant_id),
              case f when 'trial_ending' then 'Il piano gratuito di ' || p.name || ' sta per terminare: proporre la continuazione'
                     when 'no_login' then 'Nessun accesso recente di ' || p.name || ': chiamare e offrire aiuto'
                     when 'profile_incomplete' then 'Aiutare ' || p.name || ' a completare il profilo'
                     else 'Nessuna azione dei clienti per ' || p.name || ': verificare visibilità, QR e prima offerta' end,
              f, now() + interval '1 day', case when f = 'trial_ending' then 'trial_ending' else 'at_risk' end, null)
      on conflict (restaurant_id, reason) where status = 'open' and source <> 'manual' do nothing;
      get diagnostics k = row_count; n := n + k;
    end loop;
  end loop;
  return n;
end $$;

create or replace function public.admin_launch_generate_followups(p_market text default 'taranto')
returns int language plpgsql security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  return public.launch_generate_followups((public.launch_market(p_market)).id);
end $$;

-- Operations board "Oggi": una schermata per ciò che richiede azione (SLA interni, non pubblici)
create or replace function public.admin_ops_today()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_logistics boolean := public.billing_setting_bool('logistics_enabled', true);
begin
  perform public.launch_assert_admin();
  return jsonb_build_object(
    'sla', jsonb_build_object('claim_hours', public.billing_setting_int('sla_claim_review_hours', 48),
      'support_hours', public.billing_setting_int('sla_support_first_response_hours', 24), 'order_issue_hours', public.billing_setting_int('sla_order_issue_hours', 2),
      'data_report_hours', public.billing_setting_int('sla_data_report_hours', 72)),
    'claims_pending', (select jsonb_build_object('count', count(*), 'overdue', count(*) filter (where created_at < now() - make_interval(hours => public.billing_setting_int('sla_claim_review_hours', 48))))
                        from public.restaurant_claims where status in ('pending', 'under_review', 'more_information_required')),
    'order_issues', (select jsonb_build_object('count', count(*), 'overdue', count(*) filter (where created_at < now() - make_interval(hours => public.billing_setting_int('sla_order_issue_hours', 2))))
                      from public.order_issues where status in ('open', 'in_progress')),
    'restaurant_support', (select jsonb_build_object('count', count(*), 'overdue', count(*) filter (where status = 'open' and created_at < now() - make_interval(hours => public.billing_setting_int('sla_support_first_response_hours', 24))))
                      from public.support_tickets where status in ('open', 'in_progress', 'waiting_customer') and category in ('restaurant', 'business', 'claim', 'menu', 'subscription', 'ads', 'billing')),
    'customer_support', (select jsonb_build_object('count', count(*), 'overdue', count(*) filter (where status = 'open' and created_at < now() - make_interval(hours => public.billing_setting_int('sla_support_first_response_hours', 24))))
                      from public.support_tickets where status in ('open', 'in_progress', 'waiting_customer') and category not in ('restaurant', 'business', 'claim', 'menu', 'subscription', 'ads', 'billing')),
    'rider_issues', case when v_logistics then (select jsonb_build_object('count', count(*)) from public.delivery_issues where status in ('open', 'in_review')) end,
    'payments_failed_24h', (select count(*) from public.orders where payment_status = 'failed' and updated_at > now() - interval '24 hours'),
    'data_reports', (select jsonb_build_object('count', count(*), 'overdue', count(*) filter (where rr.created_at < now() - make_interval(hours => public.billing_setting_int('sla_data_report_hours', 72))),
                       'rows', coalesce(jsonb_agg(jsonb_build_object('id', rr.id, 'type', rr.report_type, 'restaurant', r.name, 'slug', r.slug, 'created_at', rr.created_at) order by rr.created_at) filter (where rr.id is not null), '[]'::jsonb))
                      from public.restaurant_reports rr join public.restaurants r on r.id = rr.restaurant_id where rr.status in ('open', 'in_progress')),
    'sales_followups', (select count(*) from public.crm_leads where next_action_at < now() + interval '1 day' and status not in ('lost', 'not_interested', 'do_not_contact', 'closed'))
                       + (select count(*) from public.crm_tasks where status = 'open' and (due_at is null or due_at < now() + interval '1 day')),
    'incidents', coalesce((select jsonb_agg(to_jsonb(i) order by case i.severity when 'critical' then 0 when 'high' then 1 when 'medium' then 2 else 3 end, i.created_at)
                            from public.launch_incidents i where i.status <> 'resolved'), '[]'::jsonb),
    'feedback_new', (select count(*) from public.product_feedback where status = 'new'));
end $$;

-- Crescita: acquisizione (canali/UTM/codici), referral, esperimenti, costi e CAC (solo con dati affidabili)
create or replace function public.admin_launch_growth(p_market text default 'taranto', p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  m public.markets := public.launch_market(p_market);
  v_from timestamptz := now() - make_interval(days => least(greatest(p_days, 1), 365));
  v_min int := public.billing_setting_int('cac_min_conversions', 5);
  v_rest_cost numeric; v_user_cost numeric; v_new_paying int; v_new_users int;
begin
  perform public.launch_assert_admin();
  select coalesce(sum(amount_cents), 0) into v_rest_cost from public.acquisition_costs where market_id = m.id and audience = 'restaurants' and spent_on >= (v_from at time zone 'Europe/Rome')::date;
  select coalesce(sum(amount_cents), 0) into v_user_cost from public.acquisition_costs where market_id = m.id and audience = 'users' and spent_on >= (v_from at time zone 'Europe/Rome')::date;
  select count(distinct s.restaurant_id) into v_new_paying from public.subscriptions s where s.source = 'stripe' and s.paid_started_at >= v_from and s.restaurant_id in (select public.launch_market_ids(m.id));
  select count(*) into v_new_users from public.profiles where role = 'customer' and created_at >= v_from;
  return jsonb_build_object(
    'days', p_days,
    'visits_by_channel', coalesce((select jsonb_object_agg(channel, n) from (select channel, count(*) n from public.acquisition_visits
                                   where created_at >= v_from and (market_id = m.id or market_id is null) group by channel) t), '{}'::jsonb),
    'campaigns', coalesce((select jsonb_agg(jsonb_build_object('utm_source', utm_source, 'utm_medium', utm_medium, 'utm_campaign', utm_campaign, 'visits', n) order by n desc)
                           from (select utm_source, utm_medium, utm_campaign, count(*) n from public.acquisition_visits where created_at >= v_from and utm_campaign is not null
                                  group by 1, 2, 3 order by 4 desc limit 30) t), '[]'::jsonb),
    'signups_by_channel', coalesce((select jsonb_object_agg(channel, n) from (select channel, count(*) n from public.user_acquisition where created_at >= v_from group by channel) t), '{}'::jsonb),
    'signups_total', v_new_users,
    'signups_attributed', (select count(*) from public.user_acquisition where created_at >= v_from),
    'codes', coalesce((select jsonb_agg(to_jsonb(c) order by c.uses desc) from public.acquisition_codes c where c.market_id = m.id or c.market_id is null), '[]'::jsonb),
    'qr_by_kind', coalesce((select jsonb_object_agg(k, n) from (select e.metadata ->> 'kind' k, count(*) n from public.analytics_events e
                            join public.launch_market_ids(m.id) mr(id) on mr.id = e.restaurant_id where e.event_type = 'qr_scan' and e.created_at >= v_from group by 1) t), '{}'::jsonb),
    'referral_funnel', (select jsonb_build_object('invited', count(*) filter (where created_at >= v_from), 'registered', count(*) filter (where registered_at >= v_from),
                          'qualified', count(*) filter (where qualified_at >= v_from), 'rewarded', count(*) filter (where rewarded_at >= v_from)) from public.referrals),
    'restaurant_referral_funnel', (select jsonb_build_object('invited', count(*) filter (where created_at >= v_from),
                          'qualified', count(*) filter (where qualified_at >= v_from), 'rewarded', count(*) filter (where status = 'rewarded' and created_at >= v_from)) from public.business_referrals),
    'ambassadors', (select jsonb_build_object('applied', count(*) filter (where status = 'applied'), 'approved', count(*) filter (where status = 'approved')) from public.ambassadors where market_id = m.id),
    'experiments', coalesce((select jsonb_agg(to_jsonb(e) || jsonb_build_object('exposures', (select coalesce(jsonb_object_agg(v, n), '{}'::jsonb) from (
                                select a.metadata ->> 'variant' v, count(*) n from public.app_events a where a.event_type = 'experiment_exposure' and a.metadata ->> 'experiment' = e.key group by 1) t))
                              order by e.created_at desc) from public.experiments e), '[]'::jsonb),
    'costs', jsonb_build_object('restaurants_cents', v_rest_cost, 'users_cents', v_user_cost,
      'rows', coalesce((select jsonb_agg(to_jsonb(c) order by c.spent_on desc) from public.acquisition_costs c where c.market_id = m.id and c.spent_on >= (v_from at time zone 'Europe/Rome')::date), '[]'::jsonb)),
    -- CAC solo con dati affidabili: costi registrati e almeno N conversioni nel periodo; altrimenti null con motivo
    'cac', jsonb_build_object(
      'restaurant_cents', case when v_rest_cost > 0 and v_new_paying >= v_min then round(v_rest_cost / v_new_paying) end,
      'restaurant_reason', case when v_rest_cost = 0 then 'no_costs' when v_new_paying < v_min then 'too_few_conversions' end,
      'restaurant_conversions', v_new_paying,
      'user_cents', case when v_user_cost > 0 and v_new_users >= v_min then round(v_user_cost / v_new_users) end,
      'user_reason', case when v_user_cost = 0 then 'no_costs' when v_new_users < v_min then 'too_few_conversions' end,
      'user_conversions', v_new_users, 'min_conversions', v_min),
    -- LTV (preparazione): ricavi reali per ristorante finora; nessun valore attribuito ai singoli utenti
    'revenue_per_restaurant', coalesce((select jsonb_agg(to_jsonb(t) order by t.total_cents desc) from (
        select r.id, r.name,
               coalesce((select round(sum(i.amount_paid_cents)) from public.billing_invoices i where i.restaurant_id = r.id and i.status = 'paid'), 0) as subscription_cents,
               coalesce((select round(sum((o.platform_fee + o.service_fee) * 100)) from public.orders o where o.restaurant_id = r.id and o.status = 'completed'), 0) as order_fees_cents,
               0 as ads_cents,
               coalesce((select round(sum(i.amount_paid_cents)) from public.billing_invoices i where i.restaurant_id = r.id and i.status = 'paid'), 0)
                 + coalesce((select round(sum((o.platform_fee + o.service_fee) * 100)) from public.orders o where o.restaurant_id = r.id and o.status = 'completed'), 0) as total_cents
          from public.restaurants r where r.owner_id is not null and r.id in (select public.launch_market_ids(m.id))) t where t.total_cents > 0), '[]'::jsonb));
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 17. GESTIONE (Admin): fasi, obiettivi, costi, esperimenti, piano, contenuti, codici, feedback, incidenti, ambassador
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_launch_set_phase(p_market text, p_phase text)
returns void language plpgsql security definer set search_path = public as $$
declare m public.markets := public.launch_market(p_market);
begin
  perform public.launch_assert_admin();
  if p_phase not in ('planned', 'private_beta', 'local_beta', 'public_launch', 'paused') then raise exception 'Fase non valida'; end if;
  update public.markets set status = p_phase, updated_at = now(), launched_at = case when p_phase = 'public_launch' then coalesce(launched_at, now()) else launched_at end
   where id = m.id;
  if m.slug = 'taranto' and p_phase in ('private_beta', 'local_beta', 'public_launch') then
    update public.platform_settings set value = to_jsonb(p_phase) where key = 'launch_phase';
  end if;
  perform public.audit_admin('launch_phase_changed', 'market', m.id::text, jsonb_build_object('from', m.status, 'to', p_phase));
end $$;

create or replace function public.admin_goal_upsert(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p ->> 'id', '')::uuid; m public.markets := public.launch_market(coalesce(p ->> 'market', 'taranto'));
begin
  perform public.launch_assert_admin();
  if v_id is null then
    insert into public.growth_goals (market_id, metric_key, target_value, period_start, period_end)
    values (m.id, p ->> 'metric_key', (p ->> 'target_value')::numeric, (p ->> 'period_start')::date, (p ->> 'period_end')::date)
    returning id into v_id;
  else
    update public.growth_goals set target_value = coalesce((p ->> 'target_value')::numeric, target_value),
      period_start = coalesce((p ->> 'period_start')::date, period_start), period_end = coalesce((p ->> 'period_end')::date, period_end) where id = v_id;
  end if;
  perform public.launch_goals_refresh(m.id);
  return v_id;
end $$;

create or replace function public.admin_goal_delete(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin perform public.launch_assert_admin(); delete from public.growth_goals where id = p_id; end $$;

create or replace function public.admin_cost_add(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  perform public.launch_assert_admin();
  insert into public.acquisition_costs (market_id, audience, category, channel, amount_cents, spent_on, notes)
  values ((public.launch_market(coalesce(p ->> 'market', 'taranto'))).id, p ->> 'audience', p ->> 'category', nullif(p ->> 'channel', ''),
          (p ->> 'amount_cents')::int, coalesce((p ->> 'spent_on')::date, current_date), nullif(p ->> 'notes', ''))
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.admin_cost_delete(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin perform public.launch_assert_admin(); delete from public.acquisition_costs where id = p_id; end $$;

create or replace function public.admin_experiment_upsert(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p ->> 'id', '')::uuid; v_vars text[];
begin
  perform public.launch_assert_admin();
  if p ? 'variants' then select array_agg(lower(regexp_replace(x, '[^A-Za-z0-9_]', '', 'g'))) into v_vars from jsonb_array_elements_text(p -> 'variants') x; end if;
  if v_id is null then
    insert into public.experiments (key, name, hypothesis, primary_metric, variants)
    values (lower(p ->> 'key'), p ->> 'name', nullif(p ->> 'hypothesis', ''), nullif(p ->> 'primary_metric', ''), coalesce(v_vars, array['control', 'variant_b']))
    returning id into v_id;
  else
    update public.experiments set name = coalesce(p ->> 'name', name), hypothesis = coalesce(p ->> 'hypothesis', hypothesis),
      primary_metric = coalesce(p ->> 'primary_metric', primary_metric), variants = case when status = 'draft' then coalesce(v_vars, variants) else variants end
     where id = v_id;
  end if;
  return v_id;
end $$;

-- Mai decine di esperimenti insieme: limite configurabile
create or replace function public.admin_experiment_set_status(p_id uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  if p_status not in ('draft', 'running', 'stopped') then raise exception 'Stato non valido'; end if;
  if p_status = 'running' and (select count(*) from public.experiments where status = 'running' and id <> p_id) >= public.billing_setting_int('experiments_max_running', 2) then
    raise exception 'Troppi esperimenti attivi: fermane uno prima di avviarne un altro' using errcode = 'P0001';
  end if;
  update public.experiments set status = p_status,
    started_at = case when p_status = 'running' then coalesce(started_at, now()) else started_at end,
    stopped_at = case when p_status = 'stopped' then now() else null end where id = p_id;
  perform public.audit_admin('experiment_' || p_status, 'experiment', p_id::text, '{}'::jsonb);
end $$;

create or replace function public.admin_plan_items(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(i) || jsonb_build_object('owner_name', (select coalesce(p.display_name, p.full_name) from public.profiles p where p.id = i.owner_id))
                    order by i.horizon, i.bucket, i.sort, i.title)
                   from public.launch_plan_items i where i.market_id = (public.launch_market(p_market)).id), '[]'::jsonb);
end $$;

create or replace function public.admin_plan_item_update(p_id uuid, p jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  update public.launch_plan_items set
    status = coalesce(p ->> 'status', status),
    owner_id = case when p ? 'owner_id' then nullif(p ->> 'owner_id', '')::uuid else owner_id end,
    due_date = case when p ? 'due_date' then nullif(p ->> 'due_date', '')::date else due_date end,
    done_at = case when (p ->> 'status') = 'done' then coalesce(done_at, now()) when p ? 'status' then null else done_at end
   where id = p_id;
end $$;

create or replace function public.admin_content_list(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(c) || jsonb_build_object('restaurant_name', (select name from public.restaurants where id = c.restaurant_id))
                    order by coalesce(c.scheduled_for, c.created_at))
                   from public.marketing_content c where c.market_id = (public.launch_market(p_market)).id), '[]'::jsonb);
end $$;

create or replace function public.admin_content_upsert(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p ->> 'id', '')::uuid; c public.marketing_content;
begin
  perform public.launch_assert_admin();
  if v_id is null then
    insert into public.marketing_content (market_id, platform, content_type, title) values
      ((public.launch_market(coalesce(p ->> 'market', 'taranto'))).id, p ->> 'platform', p ->> 'content_type', nullif(p ->> 'title', ''))
    returning id into v_id;
  end if;
  select * into c from public.marketing_content where id = v_id;
  update public.marketing_content set
    platform = coalesce(p ->> 'platform', c.platform), content_type = coalesce(p ->> 'content_type', c.content_type),
    restaurant_id = case when p ? 'restaurant_id' then nullif(p ->> 'restaurant_id', '')::uuid else c.restaurant_id end,
    title = case when p ? 'title' then nullif(p ->> 'title', '') else c.title end,
    caption = case when p ? 'caption' then nullif(p ->> 'caption', '') else c.caption end,
    media_url = case when p ? 'media_url' then nullif(p ->> 'media_url', '') else c.media_url end,
    status = coalesce(p ->> 'status', c.status),
    scheduled_for = case when p ? 'scheduled_for' then nullif(p ->> 'scheduled_for', '')::timestamptz else c.scheduled_for end,
    published_at = case when (p ->> 'status') = 'published' then coalesce(c.published_at, now()) when p ? 'status' then null else c.published_at end,
    is_sponsored = coalesce((p ->> 'is_sponsored')::boolean, c.is_sponsored),
    rights_confirmed = coalesce((p ->> 'rights_confirmed')::boolean, c.rights_confirmed),
    compliance_checked = coalesce((p ->> 'compliance_checked')::boolean, c.compliance_checked),
    notes = case when p ? 'notes' then nullif(p ->> 'notes', '') else c.notes end,
    updated_at = now()
   where id = v_id;
  return v_id;
end $$;

create or replace function public.admin_content_delete(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin perform public.launch_assert_admin(); delete from public.marketing_content where id = p_id; end $$;

-- Calendario social di 30 giorni come BOZZE (idee/testi generici, da personalizzare con dati reali; nessuna pubblicazione)
create or replace function public.admin_seed_social_calendar(p_market text default 'taranto', p_start date default null)
returns int language plpgsql security definer set search_path = public as $$
declare m public.markets := public.launch_market(p_market); v_start date := coalesce(p_start, current_date + 1); n int;
begin
  perform public.launch_assert_admin();
  insert into public.marketing_content (market_id, platform, content_type, title, caption, status, notes)
  select m.id, x.platform, x.ctype, x.title, x.caption, 'idea', 'Giorno ' || x.day || ' — data suggerita ' || to_char(v_start + x.day - 1, 'DD/MM/YYYY')
    from (values
      (1, 'instagram', 'launch', 'Annuncio: AsiaFood arriva a Taranto', 'Finalmente tutta la cucina asiatica di Taranto in un’unica app. Scopri, confronta, prenota. Link in bio.'),
      (2, 'tiktok', 'map', 'Tour della mappa', 'Dove si mangia sushi a Taranto? Ti mostriamo la mappa di AsiaFood in 20 secondi. [inserire solo locali presenti]'),
      (3, 'facebook', 'local', 'Taranto e provincia: i comuni coperti', 'Da Taranto a Martina Franca, da Massafra a Manduria: [N] locali asiatici già su AsiaFood. [aggiornare N dai dati]'),
      (4, 'instagram', 'quiz', 'Sushi quiz: nigiri o uramaki?', 'Quiz del giorno: qual è la differenza tra nigiri e uramaki? Rispondi nei commenti!'),
      (5, 'instagram', 'restaurant_spotlight', 'Scopri [Ristorante] (solo partner che ha dato il consenso)', 'Oggi vi portiamo da [Ristorante]. [descrizione approvata dal locale]. Se sponsorizzato: aggiungere #adv.'),
      (6, 'tiktok', 'where_would_you_eat', 'Dove mangeresti stasera?', 'AYCE, poke o ramen? Dove mangeresti stasera a Taranto? Vota!'),
      (7, 'instagram', 'ayce', 'Guida all’All You Can Eat', 'Come funziona l’All You Can Eat? Prezzi pranzo/cena sono sulle schede dei locali su AsiaFood. [solo dati reali]'),
      (8, 'facebook', 'new_partners', 'Benvenuti ai primi Partner Fondatori', 'Diamo il benvenuto ai primi ristoranti Partner Fondatori di AsiaFood Taranto. [solo aderenti reali, con consenso]'),
      (9, 'instagram', 'offers', 'Le offerte della settimana', 'Le offerte attive questa settimana su AsiaFood. Condizioni decise da ogni ristorante. [solo offerte attive]'),
      (10, 'tiktok', 'behind_scenes', 'Dietro le quinte', 'Come verifichiamo le schede dei ristoranti: fonti, telefonate, foto. Nessuna recensione inventata.'),
      (11, 'instagram', 'dish_of_day', 'Piatto del giorno: ramen', 'Il ramen: brodo, noodles, topping. Dove trovarlo a Taranto? Cerca "ramen" su AsiaFood.'),
      (12, 'instagram', 'ugc', 'Tagga @AsiaFood', 'Hai provato un ristorante asiatico? Taggaci! Ripubblichiamo solo con il tuo permesso.'),
      (13, 'facebook', 'map', 'Vicino a te', 'Attiva la posizione e trova i locali asiatici più vicini. La posizione non viene salvata.'),
      (14, 'instagram', 'quiz', 'Quiz: cos’è il gyoza?', 'Ravioli giapponesi alla piastra: sai come si chiamano? Rispondi!'),
      (15, 'tiktok', 'restaurant_spotlight', 'Ristorante della settimana', 'Ristorante della settimana: [Ristorante]. [contenuto approvato]. Se sponsorizzato: #adv obbligatorio.'),
      (16, 'instagram', 'local', 'Sushi a Massafra, Martina Franca, Grottaglie', 'Non solo Taranto: i locali di sushi in provincia su AsiaFood. [solo comuni con locali]'),
      (17, 'instagram', 'tips', 'Come prenotare in 3 tap', 'Prenota un tavolo in 3 tap dai locali che accettano prenotazioni su AsiaFood.'),
      (18, 'facebook', 'offers', 'Coupon: come funzionano', 'Salva un coupon e mostralo in cassa. Le condizioni sono sempre indicate sul coupon.'),
      (19, 'instagram', 'where_would_you_eat', 'Pranzo veloce: poke o bao?', 'Pausa pranzo a Taranto: poke o bao? Scegli e trova il locale su AsiaFood.'),
      (20, 'tiktok', 'behind_scenes', 'Come nasce AsiaFood', 'Perché una piattaforma solo per la cucina asiatica? Ve lo raccontiamo.'),
      (21, 'instagram', 'giveaway', 'Giveaway (SOLO dopo verifica legale)', 'BOZZA — non pubblicare senza checklist di conformità (regolamento, ministero se necessario, privacy).'),
      (22, 'instagram', 'new_partners', 'Nuovi locali verificati', 'Nuovi locali verificati questa settimana su AsiaFood. [solo dati reali]'),
      (23, 'facebook', 'tips', 'Invita un amico', 'Invita un amico su AsiaFood e ricevete AsiaPoints secondo il regolamento del programma.'),
      (24, 'instagram', 'dish_of_day', 'Piatto del giorno: dim sum', 'Dim sum: piccoli bocconi al vapore. Dove trovarli? Cerca su AsiaFood.'),
      (25, 'tiktok', 'map', 'Sfida: 3 locali in 3 comuni', 'Tre comuni, tre locali asiatici: la mappa di AsiaFood. [solo locali presenti]'),
      (26, 'instagram', 'quiz', 'Quiz: wasabi vero o no?', 'Sapevi che il wasabi servito spesso è rafano colorato? Vero o falso?'),
      (27, 'instagram', 'restaurant_spotlight', 'Scopri [Ristorante]', 'Scopri [Ristorante] su AsiaFood: menu, orari, prenotazione. Se sponsorizzato: #adv.'),
      (28, 'facebook', 'local', 'Grazie Taranto', 'Grazie ai primi utenti e ristoranti di Taranto! [solo numeri reali]'),
      (29, 'instagram', 'offers', 'Offerte del weekend', 'Le offerte del weekend dai locali su AsiaFood. [solo offerte attive]'),
      (30, 'tiktok', 'tips', 'Aggiungi AsiaFood alla schermata Home', 'Aggiungi AsiaFood alla schermata Home in 2 passaggi: si apre come un’app.')
    ) as x(day, platform, ctype, title, caption)
   where not exists (select 1 from public.marketing_content c where c.market_id = m.id and c.title = x.title);
  get diagnostics n = row_count;
  return n;
end $$;

create or replace function public.admin_code_upsert(p jsonb)
returns text language plpgsql security definer set search_path = public as $$
declare v_code text := upper(regexp_replace(coalesce(p ->> 'code', ''), '[^A-Za-z0-9]', '', 'g'));
begin
  perform public.launch_assert_admin();
  insert into public.acquisition_codes (code, market_id, kind, restaurant_id, lead_id, description, is_active)
  values (v_code, (public.launch_market(coalesce(p ->> 'market', 'taranto'))).id, coalesce(p ->> 'kind', 'campaign'),
          nullif(p ->> 'restaurant_id', '')::uuid, nullif(p ->> 'lead_id', '')::uuid, nullif(p ->> 'description', ''), coalesce((p ->> 'is_active')::boolean, true))
  on conflict (code) do update set kind = excluded.kind, restaurant_id = excluded.restaurant_id, lead_id = excluded.lead_id,
    description = excluded.description, is_active = excluded.is_active;
  return v_code;
end $$;

create or replace function public.admin_feedback_list(p_type text default null, p_status text default null, p_limit int default 50, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  return jsonb_build_object(
    'total', (select count(*) from public.product_feedback where (p_type is null or type = p_type) and (p_status is null or status = p_status)),
    'rows', coalesce((select jsonb_agg(to_jsonb(f) || jsonb_build_object('restaurant_name', (select name from public.restaurants where id = f.restaurant_id)) order by f.created_at desc)
                       from (select * from public.product_feedback where (p_type is null or type = p_type) and (p_status is null or status = p_status)
                              order by created_at desc limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)) f), '[]'::jsonb));
end $$;

create or replace function public.admin_feedback_update(p_id uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  update public.product_feedback set status = p_status where id = p_id;
end $$;

create or replace function public.admin_incident_upsert(p jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p ->> 'id', '')::uuid;
begin
  perform public.launch_assert_admin();
  if v_id is null then
    insert into public.launch_incidents (market_id, title, description, area, severity)
    values ((public.launch_market(coalesce(p ->> 'market', 'taranto'))).id, trim(p ->> 'title'), nullif(p ->> 'description', ''), coalesce(p ->> 'area', 'other'), p ->> 'severity')
    returning id into v_id;
    perform public.audit_admin('launch_incident_opened', 'incident', v_id::text, jsonb_build_object('severity', p ->> 'severity'));
  else
    update public.launch_incidents set status = coalesce(p ->> 'status', status), severity = coalesce(p ->> 'severity', severity),
      description = coalesce(p ->> 'description', description),
      resolved_at = case when (p ->> 'status') = 'resolved' then coalesce(resolved_at, now()) when p ? 'status' then null else resolved_at end
     where id = v_id;
  end if;
  return v_id;
end $$;

create or replace function public.admin_ambassadors(p_market text default 'taranto')
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(a) || jsonb_build_object('name', coalesce(p.display_name, p.full_name), 'email', p.email,
                     'referrals', (select count(*) from public.referrals r where r.referrer_user_id = a.user_id),
                     'qualified', (select count(*) from public.referrals r where r.referrer_user_id = a.user_id and r.qualified_at is not null))
                    order by a.joined_at desc)
                   from public.ambassadors a join public.profiles p on p.id = a.user_id where a.market_id = (public.launch_market(p_market)).id), '[]'::jsonb);
end $$;

create or replace function public.admin_ambassador_set_status(p_id uuid, p_status text, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  if p_status not in ('applied', 'approved', 'paused', 'rejected') then raise exception 'Stato non valido'; end if;
  update public.ambassadors set status = p_status, approved_at = case when p_status = 'approved' then coalesce(approved_at, now()) else approved_at end,
    notes = coalesce(p_notes, notes) where id = p_id;
  perform public.audit_admin('ambassador_' || p_status, 'ambassador', p_id::text, '{}'::jsonb);
end $$;

-- Preparazione espansione: segnali dai dati (nessuna previsione). Per provincia fuori dal mercato attivo.
create or replace function public.admin_expansion_signals()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.launch_assert_admin();
  return coalesce((select jsonb_agg(to_jsonb(t) order by t.score desc, t.province) from (
    select pr.name as province, pr.code,
           (select count(*) from public.restaurants r where r.province_id = pr.id and not r.is_demo) as restaurants,
           (select count(*) from public.restaurant_claims c join public.restaurants r on r.id = c.restaurant_id where r.province_id = pr.id) as claims,
           (select count(*) from public.crm_leads l join public.cities ci on ci.id = l.city_id where ci.province_id = pr.id) as leads,
           (select count(*) from public.favorites f join public.restaurants r on r.id = f.restaurant_id where r.province_id = pr.id and not r.is_demo) as favorites,
           (select count(*) from public.restaurants r where r.province_id = pr.id and not r.is_demo)
             + 3 * (select count(*) from public.restaurant_claims c join public.restaurants r on r.id = c.restaurant_id where r.province_id = pr.id)
             + (select count(*) from public.favorites f join public.restaurants r on r.id = f.restaurant_id where r.province_id = pr.id and not r.is_demo) as score
      from public.provinces pr where not exists (select 1 from public.markets mk where mk.province_id = pr.id)) t
   where t.score > 0), '[]'::jsonb);
end $$;

-- Manutenzione giornaliera (backend, system-cron): obiettivi, follow-up automatici, fine beneficio Fondatori, retention CRM
create or replace function public.launch_daily_maintenance()
returns jsonb language plpgsql security definer set search_path = public as $$
declare m record; v_tasks int := 0; v_done int; v_anon int;
begin
  perform public.assert_service();
  update public.founding_partners set status = 'completed' where status = 'active' and benefit_ends_at is not null and benefit_ends_at < now();
  get diagnostics v_done = row_count;
  for m in select id from public.markets where status <> 'planned' loop
    perform public.launch_goals_refresh(m.id);
    v_tasks := v_tasks + public.launch_generate_followups(m.id);
  end loop;
  -- Lead persi/non interessati da oltre N giorni: dati di contatto rimossi (resta lo storico aggregato)
  update public.crm_leads set contact_name = null, phone = null, email = null, instagram = null, tiktok = null, notes = null
   where status in ('lost', 'not_interested', 'do_not_contact') and updated_at < now() - make_interval(days => public.billing_setting_int('crm_lost_retention_days', 730))
     and coalesce(contact_name, phone, email, instagram, tiktok, notes) is not null;
  get diagnostics v_anon = row_count;
  -- Visite: retention come gli eventi analytics
  delete from public.acquisition_visits where created_at < now() - make_interval(days => public.billing_setting_int('retention_analytics_days', 395));
  return jsonb_build_object('founding_completed', v_done, 'followup_tasks', v_tasks, 'crm_anonymized', v_anon);
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 18. PIANO 30 GIORNI E ROADMAP 90 GIORNI (checklist operative, modificabili)
-- ────────────────────────────────────────────────────────────────────
insert into public.launch_plan_items (market_id, horizon, bucket, sort, title, description)
select m.id, x.h, x.b, x.s, x.t, x.d from public.markets m cross join (values
  ('30d', 'week1', 1, 'Beta privata aperta (inviti)', 'beta_invite_only attivo, 5–10 ristoranti e 50–100 utenti invitati.'),
  ('30d', 'week1', 2, 'QA dei dati: coordinate, orari, telefoni', 'Launch Control → Qualità dati: azzerare coordinate mancanti e duplicati nei comuni prioritari.'),
  ('30d', 'week1', 3, 'Sincronizzare i lead CRM dai ristoranti', 'Launch Control → CRM → "Crea lead dai ristoranti".'),
  ('30d', 'week1', 4, 'Primi 5 Partner Fondatori', 'Dalla lista First 50: contatto, demo, rivendicazione, attivazione Partner Fondatore.'),
  ('30d', 'week1', 5, 'Bug fixing dalla beta', 'Rivedere feedback e incidenti ogni giorno (Operations → Oggi).'),
  ('30d', 'week2', 1, 'Outreach First 50 (10 contatti/giorno)', 'Script telefono/WhatsApp/email del Sales Playbook; registrare ogni contatto nel CRM.'),
  ('30d', 'week2', 2, 'Distribuzione QR Kit ai partner', 'Table card A6 e counter card A5 stampate e consegnate; segnare nel kit di lancio.'),
  ('30d', 'week2', 3, 'Contenuti organici (calendario social)', 'Generare il calendario 30 giorni (bozze) e approvare i primi post con dati reali.'),
  ('30d', 'week2', 4, 'Prima offerta per ogni partner', 'Il ristoratore sceglie le condizioni; AsiaFood non inventa offerte.'),
  ('30d', 'week3', 1, 'Lancio consumer: landing /taranto', 'Link della landing con UTM su social, QR e partner locali.'),
  ('30d', 'week3', 2, 'Campagna referral "Invita un amico"', 'Verificare regole AsiaPoints e messaggi prima di promuoverla.'),
  ('30d', 'week3', 3, 'Partnership locali (hotel, B&B, università)', 'CRM → Partner; QR "Dove mangiare sushi a Taranto?" tracciati per partner.'),
  ('30d', 'week3', 4, 'Beta locale (pubblico limitato)', 'Passare la fase a local_beta quando i blocker critici sono chiusi.'),
  ('30d', 'week4', 1, 'Conversione trial → abbonamento', 'Daily: piani in scadenza; follow-up con i dati ROI del partner (senza promettere risultati).'),
  ('30d', 'week4', 2, 'Analisi retention (coorti)', 'Weekly → Coorti: ritorno in settimana 2, attivazione ristoranti.'),
  ('30d', 'week4', 3, 'Preparazione espansione', 'Expansion signals: raccogliere dati, nessuna decisione senza numeri.'),
  ('90d', 'month1', 1, 'Validazione Taranto', 'Prime connessioni reali (North Star), feedback, primi paganti.'),
  ('90d', 'month2', 1, 'Saturazione provincia di Taranto', 'Copertura comuni prioritari ≥ target, qualità dati, SEO locale pronta.'),
  ('90d', 'month3', 1, 'Preparazione secondo mercato', 'Scelta della seconda area basata sui segnali di espansione e sui costi di acquisizione reali.')
) as x(h, b, s, t, d)
where m.slug = 'taranto'
on conflict do nothing;

-- ────────────────────────────────────────────────────────────────────
-- 19. GRANT MINIMI (stesso schema della Fase 11: nessuna funzione admin o interna eseguibile da anonimi)
-- ────────────────────────────────────────────────────────────────────
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig, p.proname, p.prosrc from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prokind = 'f' and p.prorettype <> 'trigger'::regtype
       and (p.proname like 'admin\_%' or p.proname like 'launch\_%' or p.proname like 'crm\_%' or p.proname = 'restaurant_completion')
  loop
    execute format('revoke execute on function %s from public, anon', f.sig);
    if f.prosrc like '%perform public.assert_service()%' then
      execute format('revoke execute on function %s from authenticated', f.sig);
      execute format('grant execute on function %s to service_role', f.sig);
    elsif f.proname like 'admin\_%' then
      execute format('grant execute on function %s to authenticated, service_role', f.sig);
    else
      -- Funzioni interne (calcoli, trigger helper): nessun accesso diretto dai client
      execute format('revoke execute on function %s from authenticated', f.sig);
      execute format('grant execute on function %s to service_role', f.sig);
    end if;
  end loop;
end $$;
-- Il kit di lancio è chiamato dal ristoratore
grant execute on function public.launch_kit_status(uuid), public.launch_kit_mark(uuid, text) to authenticated;
-- Utente autenticato
revoke execute on function public.attribute_my_signup(jsonb), public.nps_should_ask(), public.ambassador_apply(text), public.my_ambassador() from public, anon;
grant execute on function public.attribute_my_signup(jsonb), public.nps_should_ask(), public.ambassador_apply(text), public.my_ambassador() to authenticated;
-- Pubbliche (aggregati, rate limit interno, nessun dato personale)
grant execute on function public.track_qr_scan(text, text), public.record_visit(jsonb), public.founding_badge(uuid), public.market_landing(text),
  public.running_experiments(), public.submit_feedback(jsonb) to anon, authenticated;
-- Trigger/helper interni
revoke execute on function public.founding_foodie_assign(), public.profiles_protect_founding(), public.crm_leads_touch(),
  public.crm_activity_after(), public.crm_claim_sync(), public.crm_subscription_sync() from public, anon, authenticated;
