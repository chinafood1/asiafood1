-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0001 · Schema core
--  Struttura pensata per scala nazionale: regioni → province → comuni.
--  Nessun vincolo legato a Taranto: il mercato di lancio è solo un dato.
-- ════════════════════════════════════════════════════════════════════

create extension if not exists pgcrypto;
create extension if not exists pg_trgm;

-- ─── Enum ────────────────────────────────────────────────────────────
create type public.user_role as enum ('customer', 'restaurant_owner', 'admin');
create type public.claim_status as enum ('pending', 'approved', 'rejected');
create type public.subscription_status as enum ('trialing', 'active', 'past_due', 'canceled', 'incomplete');
create type public.discount_type as enum ('percent', 'amount', 'fixed_price', 'free_item', 'other');
create type public.sponsored_placement as enum ('home_hero', 'home_featured', 'search_top', 'category_top', 'city_top');
create type public.analytics_event_type as enum (
  'view', 'click_phone', 'click_whatsapp', 'click_directions', 'click_menu',
  'click_reservation', 'click_website', 'click_social', 'coupon_reveal', 'coupon_redeem'
);
create type public.menu_type as enum ('a_la_carte', 'all_you_can_eat', 'lunch', 'takeaway', 'drinks', 'other');

-- ─── Utility: updated_at ─────────────────────────────────────────────
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  GEOGRAFIA
-- ════════════════════════════════════════════════════════════════════
create table public.regions (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  slug        text not null unique,
  code        text unique,                 -- codice ISTAT regione (es. '16' Puglia)
  country_code char(2) not null default 'IT',
  is_active   boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.provinces (
  id          uuid primary key default gen_random_uuid(),
  region_id   uuid not null references public.regions(id) on delete restrict,
  name        text not null,
  slug        text not null unique,
  code        text not null unique,        -- sigla (TA, BA, LE…)
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index provinces_region_idx on public.provinces(region_id);

create table public.cities (
  id          uuid primary key default gen_random_uuid(),
  province_id uuid not null references public.provinces(id) on delete restrict,
  region_id   uuid not null references public.regions(id) on delete restrict,
  name        text not null,
  -- Slug univoco a livello nazionale (usato in /ristoranti/:city).
  -- Per comuni omonimi aggiungere la sigla: es. 'calliano-tn'.
  slug        text not null unique,
  istat_code  text unique,
  postal_code text,
  latitude    double precision,
  longitude   double precision,
  population  int,
  is_active   boolean not null default true,
  is_launch_market boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index cities_province_idx on public.cities(province_id);
create index cities_region_idx on public.cities(region_id);
create index cities_name_trgm on public.cities using gin (name gin_trgm_ops);

-- ════════════════════════════════════════════════════════════════════
--  PROFILI (1:1 con auth.users)
-- ════════════════════════════════════════════════════════════════════
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  role        public.user_role not null default 'customer',
  full_name   text,
  email       text,
  phone       text,
  avatar_url  text,
  city_id     uuid references public.cities(id) on delete set null,
  marketing_opt_in boolean not null default false,
  is_blocked  boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index profiles_role_idx on public.profiles(role);

-- Crea automaticamente il profilo alla registrazione
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ════════════════════════════════════════════════════════════════════
--  PIANI (monetizzazione futura: Free / Business / Premium / Top)
-- ════════════════════════════════════════════════════════════════════
create table public.subscription_plans (
  code           text primary key,          -- 'free' | 'business' | 'premium' | 'top'
  name           text not null,
  description    text,
  monthly_price  numeric(10,2) not null default 0,
  yearly_price   numeric(10,2),
  currency       char(3) not null default 'EUR',
  features       jsonb not null default '{}'::jsonb,   -- limiti/feature flag (max_images, offers, analytics…)
  sort_order     int not null default 0,
  is_active      boolean not null default true,
  stripe_price_monthly_id text,             -- Fase 2
  stripe_price_yearly_id  text,             -- Fase 2
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

-- ════════════════════════════════════════════════════════════════════
--  CATEGORIE
-- ════════════════════════════════════════════════════════════════════
create table public.categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  slug        text not null unique,        -- usato in /:categoria/:citta (es. /sushi/taranto)
  emoji       text,
  description text,
  seo_title   text,
  seo_description text,
  image_url   text,
  sort_order  int not null default 0,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ════════════════════════════════════════════════════════════════════
--  RISTORANTI
-- ════════════════════════════════════════════════════════════════════
create table public.restaurants (
  id                  uuid primary key default gen_random_uuid(),
  owner_id            uuid references public.profiles(id) on delete set null,
  name                text not null,
  slug                text not null unique,  -- /ristorante/:slug  (es. 'kaizen-sushi-taranto')
  short_description   text,
  description         text,
  address             text,
  city_id             uuid not null references public.cities(id) on delete restrict,
  province_id         uuid references public.provinces(id) on delete restrict,
  region_id           uuid references public.regions(id) on delete restrict,
  postal_code         text,
  latitude            double precision,
  longitude           double precision,
  phone               text,
  whatsapp            text,
  email               text,
  website             text,
  instagram           text,
  facebook            text,
  tiktok              text,
  logo_url            text,
  cover_url           text,
  price_range         smallint check (price_range between 1 and 4),   -- € … €€€€
  average_price       numeric(8,2),
  is_all_you_can_eat  boolean not null default false,
  ayce_lunch_price    numeric(8,2),
  ayce_dinner_price   numeric(8,2),
  ayce_weekend_price  numeric(8,2),
  has_delivery        boolean not null default false,
  has_takeaway        boolean not null default false,
  has_reservation     boolean not null default false,
  reservation_url     text,
  services            text[] not null default '{}',   -- es. {wifi,dehors,parcheggio,accessibile,pet_friendly}
  timezone            text not null default 'Europe/Rome',
  is_verified         boolean not null default false, -- proprietario verificato
  is_active           boolean not null default true,
  is_featured         boolean not null default false,
  is_sponsored        boolean not null default false,
  is_demo             boolean not null default false, -- dati dimostrativi, NON reali
  subscription_plan   text not null default 'free' references public.subscription_plans(code),
  popularity_score    int not null default 0,
  opened_at           date,                           -- per "Nuove aperture"
  meta_title          text,
  meta_description    text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  search_vector tsvector generated always as (
    setweight(to_tsvector('italian', coalesce(name, '')), 'A') ||
    setweight(to_tsvector('italian', coalesce(short_description, '')), 'B') ||
    setweight(to_tsvector('italian', coalesce(description, '')), 'C')
  ) stored
);
create index restaurants_city_idx      on public.restaurants(city_id) where is_active;
create index restaurants_province_idx  on public.restaurants(province_id) where is_active;
create index restaurants_region_idx    on public.restaurants(region_id) where is_active;
create index restaurants_owner_idx     on public.restaurants(owner_id);
create index restaurants_ayce_idx      on public.restaurants(is_all_you_can_eat) where is_active and is_all_you_can_eat;
create index restaurants_featured_idx  on public.restaurants(is_featured, is_sponsored) where is_active;
create index restaurants_popular_idx   on public.restaurants(popularity_score desc) where is_active;
create index restaurants_geo_idx       on public.restaurants(latitude, longitude) where is_active;
create index restaurants_search_idx    on public.restaurants using gin (search_vector);
create index restaurants_name_trgm     on public.restaurants using gin (name gin_trgm_ops);

-- Denormalizza provincia/regione a partire dal comune (coerenza garantita)
create or replace function public.restaurants_fill_geo()
returns trigger language plpgsql as $$
begin
  select c.province_id, c.region_id, coalesce(new.postal_code, c.postal_code)
    into new.province_id, new.region_id, new.postal_code
  from public.cities c where c.id = new.city_id;
  return new;
end $$;

create trigger restaurants_fill_geo
  before insert or update of city_id on public.restaurants
  for each row execute function public.restaurants_fill_geo();

create table public.restaurant_categories (
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  category_id   uuid not null references public.categories(id) on delete cascade,
  is_primary    boolean not null default false,
  created_at    timestamptz not null default now(),
  primary key (restaurant_id, category_id)
);
create index restaurant_categories_category_idx on public.restaurant_categories(category_id);

create table public.restaurant_images (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  url           text not null,
  storage_path  text,                       -- path nel bucket, se caricata su Supabase Storage
  alt           text,
  kind          text not null default 'gallery' check (kind in ('gallery', 'dish', 'interior', 'exterior', 'menu')),
  sort_order    int not null default 0,
  created_at    timestamptz not null default now()
);
create index restaurant_images_restaurant_idx on public.restaurant_images(restaurant_id, sort_order);

-- Orari: più fasce per giorno (pranzo/cena). day_of_week ISO: 1 = lunedì … 7 = domenica.
-- closes_at < opens_at indica chiusura dopo mezzanotte.
create table public.restaurant_hours (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  day_of_week   smallint not null check (day_of_week between 1 and 7),
  opens_at      time,
  closes_at     time,
  is_closed     boolean not null default false,
  label         text,                       -- 'Pranzo' | 'Cena'
  created_at    timestamptz not null default now(),
  check (is_closed or (opens_at is not null and closes_at is not null))
);
create index restaurant_hours_restaurant_idx on public.restaurant_hours(restaurant_id, day_of_week);

-- ════════════════════════════════════════════════════════════════════
--  MENU
-- ════════════════════════════════════════════════════════════════════
create table public.menus (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name          text not null,
  description   text,
  menu_type     public.menu_type not null default 'a_la_carte',
  price         numeric(8,2),               -- prezzo fisso (menu pranzo / AYCE)
  is_active     boolean not null default true,
  sort_order    int not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index menus_restaurant_idx on public.menus(restaurant_id, sort_order);

create table public.menu_categories (
  id            uuid primary key default gen_random_uuid(),
  menu_id       uuid not null references public.menus(id) on delete cascade,
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name          text not null,
  description   text,
  sort_order    int not null default 0,
  created_at    timestamptz not null default now()
);
create index menu_categories_menu_idx on public.menu_categories(menu_id, sort_order);

create table public.menu_items (
  id               uuid primary key default gen_random_uuid(),
  menu_category_id uuid not null references public.menu_categories(id) on delete cascade,
  restaurant_id    uuid not null references public.restaurants(id) on delete cascade,
  name             text not null,
  description      text,
  price            numeric(8,2),
  image_url        text,
  pieces           smallint,                -- es. 8 pezzi
  allergens        text[] not null default '{}',   -- codici allergeni UE (1–14)
  tags             text[] not null default '{}',   -- vegetarian, vegan, spicy, gluten_free, signature
  is_available     boolean not null default true,
  is_ayce_included boolean not null default false,
  ayce_limit       smallint,                -- max porzioni in AYCE
  sort_order       int not null default 0,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index menu_items_category_idx on public.menu_items(menu_category_id, sort_order);
create index menu_items_restaurant_idx on public.menu_items(restaurant_id);

-- restaurant_id su menu_categories/menu_items è derivato (semplifica RLS e query)
create or replace function public.menu_categories_fill_restaurant()
returns trigger language plpgsql as $$
begin
  select m.restaurant_id into new.restaurant_id from public.menus m where m.id = new.menu_id;
  return new;
end $$;
create trigger menu_categories_fill_restaurant
  before insert or update of menu_id on public.menu_categories
  for each row execute function public.menu_categories_fill_restaurant();

create or replace function public.menu_items_fill_restaurant()
returns trigger language plpgsql as $$
begin
  select mc.restaurant_id into new.restaurant_id from public.menu_categories mc where mc.id = new.menu_category_id;
  return new;
end $$;
create trigger menu_items_fill_restaurant
  before insert or update of menu_category_id on public.menu_items
  for each row execute function public.menu_items_fill_restaurant();

-- ════════════════════════════════════════════════════════════════════
--  PREFERITI
-- ════════════════════════════════════════════════════════════════════
create table public.favorites (
  user_id       uuid not null references public.profiles(id) on delete cascade,
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  created_at    timestamptz not null default now(),
  primary key (user_id, restaurant_id)
);
create index favorites_restaurant_idx on public.favorites(restaurant_id);

-- ════════════════════════════════════════════════════════════════════
--  RIVENDICAZIONI ("Sei il proprietario? Rivendica questo ristorante")
-- ════════════════════════════════════════════════════════════════════
create table public.restaurant_claims (
  id             uuid primary key default gen_random_uuid(),
  restaurant_id  uuid not null references public.restaurants(id) on delete cascade,
  user_id        uuid not null references public.profiles(id) on delete cascade,
  status         public.claim_status not null default 'pending',
  full_name      text not null,
  business_role  text,                      -- titolare, socio, gestore…
  phone          text not null,
  email          text not null,
  vat_number     text,                      -- P.IVA
  message        text,
  proof_url      text,                      -- documento (visura) su Storage privato — Fase 2
  admin_notes    text,
  reviewed_by    uuid references public.profiles(id) on delete set null,
  reviewed_at    timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index restaurant_claims_status_idx on public.restaurant_claims(status, created_at desc);
create index restaurant_claims_user_idx on public.restaurant_claims(user_id);
-- Un utente può avere una sola richiesta in attesa per ristorante
create unique index restaurant_claims_one_pending
  on public.restaurant_claims(restaurant_id, user_id) where status = 'pending';

-- ════════════════════════════════════════════════════════════════════
--  OFFERTE e COUPON
-- ════════════════════════════════════════════════════════════════════
create table public.offers (
  id             uuid primary key default gen_random_uuid(),
  restaurant_id  uuid not null references public.restaurants(id) on delete cascade,
  title          text not null,
  description    text,
  discount_type  public.discount_type not null default 'other',
  discount_value numeric(8,2),
  image_url      text,
  days_of_week   smallint[] not null default '{}',  -- vuoto = tutti i giorni
  starts_at      timestamptz not null default now(),
  ends_at        timestamptz,
  terms          text,
  is_active      boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  check (ends_at is null or ends_at > starts_at)
);
create index offers_active_idx on public.offers(restaurant_id, is_active, ends_at);

create table public.coupons (
  id                uuid primary key default gen_random_uuid(),
  restaurant_id     uuid not null references public.restaurants(id) on delete cascade,
  offer_id          uuid references public.offers(id) on delete set null,
  code              text not null,
  title             text not null,
  description       text,
  discount_type     public.discount_type not null default 'percent',
  discount_value    numeric(8,2),
  min_spend         numeric(8,2),
  max_redemptions   int,
  redemptions_count int not null default 0,
  valid_from        timestamptz not null default now(),
  valid_until       timestamptz,
  terms             text,
  is_active         boolean not null default true,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (restaurant_id, code)
);
create index coupons_active_idx on public.coupons(restaurant_id, is_active, valid_until);

-- Predisposizione conversioni coupon (Fase 2)
create table public.coupon_redemptions (
  id          uuid primary key default gen_random_uuid(),
  coupon_id   uuid not null references public.coupons(id) on delete cascade,
  user_id     uuid references public.profiles(id) on delete set null,
  redeemed_at timestamptz not null default now(),
  metadata    jsonb not null default '{}'::jsonb
);
create index coupon_redemptions_coupon_idx on public.coupon_redemptions(coupon_id);

-- ════════════════════════════════════════════════════════════════════
--  ABBONAMENTI e SPONSORIZZAZIONI
-- ════════════════════════════════════════════════════════════════════
create table public.subscriptions (
  id                     uuid primary key default gen_random_uuid(),
  restaurant_id          uuid not null references public.restaurants(id) on delete cascade,
  plan_code              text not null references public.subscription_plans(code),
  status                 public.subscription_status not null default 'active',
  billing_interval       text not null default 'month' check (billing_interval in ('month', 'year')),
  current_period_start   timestamptz not null default now(),
  current_period_end     timestamptz,
  cancel_at_period_end   boolean not null default false,
  stripe_customer_id     text,              -- Fase 2
  stripe_subscription_id text unique,       -- Fase 2
  notes                  text,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);
create index subscriptions_restaurant_idx on public.subscriptions(restaurant_id, status);

create table public.sponsored_restaurants (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  placement     public.sponsored_placement not null default 'home_featured',
  -- Targeting opzionale: null = nazionale
  region_id     uuid references public.regions(id) on delete cascade,
  province_id   uuid references public.provinces(id) on delete cascade,
  city_id       uuid references public.cities(id) on delete cascade,
  category_id   uuid references public.categories(id) on delete cascade,
  priority      int not null default 0,
  starts_at     timestamptz not null default now(),
  ends_at       timestamptz,
  budget        numeric(10,2),
  is_active     boolean not null default true,
  campaign_name text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index sponsored_active_idx on public.sponsored_restaurants(placement, is_active, priority desc);

-- ════════════════════════════════════════════════════════════════════
--  ANALYTICS (predisposizione statistiche)
-- ════════════════════════════════════════════════════════════════════
create table public.analytics_events (
  id            bigint generated always as identity primary key,
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  event_type    public.analytics_event_type not null,
  user_id       uuid references public.profiles(id) on delete set null,
  session_id    text,
  source        text,                       -- home, explore, seo_city, map…
  metadata      jsonb not null default '{}'::jsonb,
  created_at    timestamptz not null default now()
);
create index analytics_events_restaurant_idx on public.analytics_events(restaurant_id, event_type, created_at desc);
create index analytics_events_created_idx on public.analytics_events(created_at desc);

-- ─── Trigger updated_at ──────────────────────────────────────────────
do $$
declare t text;
begin
  foreach t in array array[
    'regions','provinces','cities','profiles','subscription_plans','categories','restaurants',
    'menus','menu_items','restaurant_claims','offers','coupons','subscriptions','sponsored_restaurants'
  ] loop
    execute format('create trigger %I_updated_at before update on public.%I for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;
