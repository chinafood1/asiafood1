-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0003 · Row Level Security
--  Regole:
--   • Visitatori: sola lettura dei contenuti pubblici attivi.
--   • Clienti: gestiscono solo profilo, preferiti e proprie rivendicazioni.
--   • Ristoratori: modificano SOLO i ristoranti di cui sono owner (claim approvato).
--   • Admin: accesso completo.
-- ════════════════════════════════════════════════════════════════════

alter table public.regions               enable row level security;
alter table public.provinces             enable row level security;
alter table public.cities                enable row level security;
alter table public.profiles              enable row level security;
alter table public.subscription_plans    enable row level security;
alter table public.categories            enable row level security;
alter table public.restaurants           enable row level security;
alter table public.restaurant_categories enable row level security;
alter table public.restaurant_images     enable row level security;
alter table public.restaurant_hours      enable row level security;
alter table public.menus                 enable row level security;
alter table public.menu_categories       enable row level security;
alter table public.menu_items            enable row level security;
alter table public.favorites             enable row level security;
alter table public.restaurant_claims     enable row level security;
alter table public.offers                enable row level security;
alter table public.coupons               enable row level security;
alter table public.coupon_redemptions    enable row level security;
alter table public.subscriptions         enable row level security;
alter table public.sponsored_restaurants enable row level security;
alter table public.analytics_events      enable row level security;

-- ─── Dati di riferimento: lettura pubblica, scrittura Admin ──────────
do $$
declare t text;
begin
  foreach t in array array['regions','provinces','cities','categories','subscription_plans'] loop
    execute format($f$create policy "%1$s_public_read" on public.%1$I for select using (is_active or public.is_admin())$f$, t);
    execute format($f$create policy "%1$s_admin_write" on public.%1$I for all to authenticated using (public.is_admin()) with check (public.is_admin())$f$, t);
  end loop;
end $$;

-- ─── Profili ─────────────────────────────────────────────────────────
create policy "profiles_select_own_or_admin" on public.profiles
  for select to authenticated using (id = auth.uid() or public.is_admin());
create policy "profiles_update_own_or_admin" on public.profiles
  for update to authenticated using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());
create policy "profiles_admin_delete" on public.profiles
  for delete to authenticated using (public.is_admin());
-- INSERT gestito dal trigger handle_new_user (security definer)

-- ─── Ristoranti ──────────────────────────────────────────────────────
create policy "restaurants_public_read" on public.restaurants
  for select using (is_active or owner_id = auth.uid() or public.is_admin());
create policy "restaurants_admin_insert" on public.restaurants
  for insert to authenticated with check (public.is_admin());
create policy "restaurants_owner_or_admin_update" on public.restaurants
  for update to authenticated
  using (public.can_manage_restaurant(id))
  with check (public.can_manage_restaurant(id));
create policy "restaurants_admin_delete" on public.restaurants
  for delete to authenticated using (public.is_admin());

-- ─── Tabelle figlie del ristorante (stesso schema di permessi) ───────
-- Lettura pubblica se il ristorante è attivo; scrittura owner/admin.
do $$
declare t text;
begin
  foreach t in array array['restaurant_categories','restaurant_images','restaurant_hours','menus','menu_categories','menu_items'] loop
    execute format($f$
      create policy "%1$s_public_read" on public.%1$I for select using (
        exists (select 1 from public.restaurants r where r.id = restaurant_id and r.is_active)
        or public.can_manage_restaurant(restaurant_id)
      )$f$, t);
    execute format($f$
      create policy "%1$s_manage" on public.%1$I for all to authenticated
        using (public.can_manage_restaurant(restaurant_id))
        with check (public.can_manage_restaurant(restaurant_id))$f$, t);
  end loop;
end $$;

-- ─── Offerte e coupon: visibili se attivi e validi ───────────────────
create policy "offers_public_read" on public.offers
  for select using (
    (is_active and starts_at <= now() and (ends_at is null or ends_at > now())
      and exists (select 1 from public.restaurants r where r.id = restaurant_id and r.is_active))
    or public.can_manage_restaurant(restaurant_id)
  );
create policy "offers_manage" on public.offers
  for all to authenticated
  using (public.can_manage_restaurant(restaurant_id))
  with check (public.can_manage_restaurant(restaurant_id));

create policy "coupons_public_read" on public.coupons
  for select using (
    (is_active and valid_from <= now() and (valid_until is null or valid_until > now())
      and exists (select 1 from public.restaurants r where r.id = restaurant_id and r.is_active))
    or public.can_manage_restaurant(restaurant_id)
  );
create policy "coupons_manage" on public.coupons
  for all to authenticated
  using (public.can_manage_restaurant(restaurant_id))
  with check (public.can_manage_restaurant(restaurant_id));

create policy "coupon_redemptions_read" on public.coupon_redemptions
  for select to authenticated using (
    user_id = auth.uid() or public.is_admin()
    or exists (select 1 from public.coupons c where c.id = coupon_id and public.owns_restaurant(c.restaurant_id))
  );
create policy "coupon_redemptions_admin" on public.coupon_redemptions
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ─── Preferiti: solo i propri ────────────────────────────────────────
create policy "favorites_own" on public.favorites
  for all to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- ─── Rivendicazioni ──────────────────────────────────────────────────
create policy "claims_select_own_or_admin" on public.restaurant_claims
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "claims_insert_own_pending" on public.restaurant_claims
  for insert to authenticated with check (
    user_id = auth.uid() and status = 'pending'
    and reviewed_by is null and reviewed_at is null and admin_notes is null
    -- non si può rivendicare un locale già assegnato
    and exists (select 1 from public.restaurants r where r.id = restaurant_id and r.owner_id is null and r.is_active)
  );
create policy "claims_admin_update" on public.restaurant_claims
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "claims_admin_delete" on public.restaurant_claims
  for delete to authenticated using (public.is_admin());

-- ─── Abbonamenti: lettura owner, gestione Admin (Stripe in Fase 2 via service role) ───
create policy "subscriptions_read" on public.subscriptions
  for select to authenticated using (public.can_manage_restaurant(restaurant_id));
create policy "subscriptions_admin" on public.subscriptions
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ─── Sponsorizzazioni: lettura pubblica delle campagne attive ────────
create policy "sponsored_public_read" on public.sponsored_restaurants
  for select using (
    (is_active and starts_at <= now() and (ends_at is null or ends_at > now()))
    or public.is_admin()
  );
create policy "sponsored_admin" on public.sponsored_restaurants
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ─── Analytics: nessun INSERT diretto (usare RPC track_event) ────────
create policy "analytics_read_owner_admin" on public.analytics_events
  for select to authenticated using (public.can_manage_restaurant(restaurant_id));
