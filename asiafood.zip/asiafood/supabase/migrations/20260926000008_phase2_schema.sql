-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0008 · Fase 2: dati reali, fonti, rivendicazioni,
--  team del ristorante, segnalazioni, import, RLS aggiornate.
--  Migrazione additiva: nessun dato esistente viene eliminato.
-- ════════════════════════════════════════════════════════════════════

-- ════════════════════════════════════════════════════════════════════
--  1. IMPOSTAZIONI DI PIATTAFORMA
-- ════════════════════════════════════════════════════════════════════
create table public.platform_settings (
  key         text primary key,
  value       jsonb not null,
  description text,
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.profiles(id) on delete set null
);
create trigger platform_settings_updated_at before update on public.platform_settings
  for each row execute function public.set_updated_at();

insert into public.platform_settings (key, value, description) values
  ('show_demo_data', 'true'::jsonb, 'Mostra al pubblico i ristoranti DEMO (is_demo = true). Disattivare al lancio con dati reali.')
on conflict (key) do nothing;

create or replace function public.demo_data_visible()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select (value #>> '{}')::boolean from public.platform_settings where key = 'show_demo_data'), true);
$$;

-- Admin autenticato oppure chiave service_role (script di import lato server)
create or replace function public.is_admin_or_service()
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_admin() or coalesce(auth.role(), '') = 'service_role';
$$;

-- ════════════════════════════════════════════════════════════════════
--  2. RESTAURANTS: provenienza e affidabilità del dato
-- ════════════════════════════════════════════════════════════════════
alter table public.restaurants
  add column source_name                    text,
  add column source_url                     text,
  add column external_id                    text,
  add column google_place_id                text,
  add column data_status                    public.data_status not null default 'unverified',
  add column last_verified_at               timestamptz,
  add column claimed_at                     timestamptz,
  add column claimed_by                     uuid references public.profiles(id) on delete set null,
  add column verification_notes             text,
  add column menu_last_verified_at          timestamptz,
  add column opening_hours_last_verified_at timestamptz,
  add column is_temporarily_closed          boolean not null default false,
  add column is_permanently_closed          boolean not null default false;

alter table public.restaurants
  add constraint restaurants_source_url_http check (source_url is null or source_url ~* '^https?://'),
  add constraint restaurants_lat_range check (latitude is null or latitude between -90 and 90),
  add constraint restaurants_lng_range check (longitude is null or longitude between -180 and 180);

-- Backfill: i locali già rivendicati passano a "claimed"
update public.restaurants
   set data_status = 'claimed', claimed_by = owner_id, claimed_at = coalesce(claimed_at, updated_at)
 where owner_id is not null;

-- Indici (deduplicazione, filtri Admin, performance)
create unique index restaurants_google_place_id_key on public.restaurants(google_place_id) where google_place_id is not null;
create index restaurants_external_idx       on public.restaurants(source_name, external_id) where external_id is not null;
create index restaurants_city_all_idx       on public.restaurants(city_id);
create index restaurants_is_active_idx      on public.restaurants(is_active);
create index restaurants_is_sponsored_idx   on public.restaurants(is_sponsored) where is_sponsored;
create index restaurants_data_status_idx    on public.restaurants(data_status);
create index restaurants_claimed_by_idx     on public.restaurants(claimed_by);
create index restaurant_claims_restaurant_idx on public.restaurant_claims(restaurant_id);
-- restaurant_categories: la PK (restaurant_id, category_id) copre già le ricerche per restaurant_id;
-- restaurant_categories_category_idx (0001) copre category_id.

-- Slug univoco lato DB (usato da import e duplicazione)
create or replace function public.unique_restaurant_slug(p_base text, p_exclude uuid default null)
returns text language plpgsql stable set search_path = public as $$
declare
  v_base text := coalesce(nullif(regexp_replace(lower(p_base), '[^a-z0-9-]+', '-', 'g'), ''), 'ristorante');
  v_slug text;
  n int := 2;
begin
  v_base := trim(both '-' from regexp_replace(v_base, '-{2,}', '-', 'g'));
  v_slug := v_base;
  while exists (select 1 from public.restaurants where slug = v_slug and id is distinct from p_exclude) loop
    v_slug := v_base || '-' || n;
    n := n + 1;
  end loop;
  return v_slug;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  3. TEAM DEL RISTORANTE (restaurant_members)
--  owner_id resta come "titolare principale" (compatibilità + query veloci),
--  ma i permessi derivano dalla membership attiva.
-- ════════════════════════════════════════════════════════════════════
create table public.restaurant_members (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id       uuid not null references public.profiles(id) on delete cascade,
  role          public.member_role not null default 'owner',
  status        public.member_status not null default 'active',
  invited_by    uuid references public.profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (restaurant_id, user_id)
);
create index restaurant_members_user_idx on public.restaurant_members(user_id) where status = 'active';
create unique index restaurant_members_one_owner on public.restaurant_members(restaurant_id) where role = 'owner' and status = 'active';
create trigger restaurant_members_updated_at before update on public.restaurant_members
  for each row execute function public.set_updated_at();

insert into public.restaurant_members (restaurant_id, user_id, role, status)
select id, owner_id, 'owner', 'active' from public.restaurants where owner_id is not null
on conflict (restaurant_id, user_id) do nothing;

-- Permessi: owner e manager gestiscono il locale; staff predisposto per il futuro (sola lettura)
create or replace function public.owns_restaurant(p_restaurant_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.restaurant_members m
    join public.profiles p on p.id = m.user_id
    where m.restaurant_id = p_restaurant_id and m.user_id = auth.uid()
      and m.status = 'active' and m.role in ('owner', 'manager') and not p.is_blocked
  );
$$;

create or replace function public.can_manage_restaurant(p_restaurant_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_admin() or public.owns_restaurant(p_restaurant_id);
$$;

-- Visibile al pubblico: attivo e (non demo oppure demo abilitati)
create or replace function public.restaurant_is_public(p_restaurant_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.restaurants r
    where r.id = p_restaurant_id and r.is_active and (not r.is_demo or public.demo_data_visible())
  );
$$;

-- Rivendicabile: pubblico, senza titolare e non chiuso definitivamente
create or replace function public.restaurant_is_claimable(p_restaurant_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.restaurants r
    where r.id = p_restaurant_id and r.is_active and r.owner_id is null and not r.is_permanently_closed
      and not exists (select 1 from public.restaurant_members m where m.restaurant_id = r.id and m.role = 'owner' and m.status = 'active')
  );
$$;

-- Il ruolo "restaurant_owner" del profilo è derivato dalle membership attive (mai impostabile dal client)
create or replace function public.refresh_profile_role(p_user_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_user_id is null then return; end if;
  update public.profiles
     set role = case
       when exists (select 1 from public.restaurant_members m where m.user_id = p_user_id and m.status = 'active')
       then 'restaurant_owner'::public.user_role else 'customer'::public.user_role end
   where id = p_user_id and role <> 'admin';
end $$;

-- Sincronizza owner_id ⇄ membership "owner" (qualunque sia il percorso: claim, Admin, import)
create or replace function public.restaurants_sync_owner_member()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_old uuid := case when tg_op = 'UPDATE' then old.owner_id end;
begin
  if tg_op = 'INSERT' or new.owner_id is distinct from old.owner_id then
    update public.restaurant_members
       set status = 'revoked'
     where restaurant_id = new.id and role = 'owner' and status = 'active' and user_id is distinct from new.owner_id;
    if new.owner_id is not null then
      insert into public.restaurant_members (restaurant_id, user_id, role, status, invited_by)
      values (new.id, new.owner_id, 'owner', 'active', auth.uid())
      on conflict (restaurant_id, user_id) do update set role = 'owner', status = 'active';
    end if;
    perform public.refresh_profile_role(v_old);
    perform public.refresh_profile_role(new.owner_id);
  end if;
  return null;
end $$;

create trigger restaurants_sync_owner_member
  after insert or update of owner_id on public.restaurants
  for each row execute function public.restaurants_sync_owner_member();

-- Campi riservati all'Admin (estende la versione Fase 1)
create or replace function public.protect_restaurant_admin_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    new.owner_id              := old.owner_id;
    new.is_verified           := old.is_verified;
    new.is_active             := old.is_active;
    new.is_featured           := old.is_featured;
    new.is_sponsored          := old.is_sponsored;
    new.is_demo               := old.is_demo;
    new.subscription_plan     := old.subscription_plan;
    new.popularity_score      := old.popularity_score;
    new.slug                  := old.slug;
    new.city_id               := old.city_id;
    -- provenienza e verifica del dato
    new.data_status           := old.data_status;
    new.source_name           := old.source_name;
    new.source_url            := old.source_url;
    new.external_id           := old.external_id;
    new.google_place_id       := old.google_place_id;
    new.last_verified_at      := old.last_verified_at;
    new.claimed_at            := old.claimed_at;
    new.claimed_by            := old.claimed_by;
    new.verification_notes    := old.verification_notes;
    new.is_permanently_closed := old.is_permanently_closed;
    -- il titolare può invece segnare chiusura temporanea e confermare menu/orari
  end if;
  return new;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  4. FONTI (una attività, più fonti)
-- ════════════════════════════════════════════════════════════════════
create table public.import_batches (
  id            uuid primary key default gen_random_uuid(),
  created_by    uuid references public.profiles(id) on delete set null default auth.uid(),
  file_name     text,
  format        text check (format in ('csv', 'json')),
  total_rows    int not null default 0,
  created_count int not null default 0,
  updated_count int not null default 0,
  merged_count  int not null default 0,
  skipped_count int not null default 0,
  error_count   int not null default 0,
  errors        jsonb not null default '[]'::jsonb,
  options       jsonb not null default '{}'::jsonb,
  created_at    timestamptz not null default now()
);
create index import_batches_created_idx on public.import_batches(created_at desc);

create table public.restaurant_sources (
  id              uuid primary key default gen_random_uuid(),
  restaurant_id   uuid not null references public.restaurants(id) on delete cascade,
  source_type     public.source_type not null default 'other',
  source_name     text,
  source_url      text check (source_url is null or source_url ~* '^https?://'),
  external_id     text,
  is_primary      boolean not null default false,
  notes           text,
  last_checked_at timestamptz,
  import_batch_id uuid references public.import_batches(id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  check (source_url is not null or source_name is not null)
);
create index restaurant_sources_restaurant_idx on public.restaurant_sources(restaurant_id);
create unique index restaurant_sources_url_key on public.restaurant_sources(restaurant_id, source_url) where source_url is not null;
create unique index restaurant_sources_one_primary on public.restaurant_sources(restaurant_id) where is_primary;
create trigger restaurant_sources_updated_at before update on public.restaurant_sources
  for each row execute function public.set_updated_at();

-- ════════════════════════════════════════════════════════════════════
--  5. RIVENDICAZIONI: dati richiedente, metodo di verifica, cronologia
-- ════════════════════════════════════════════════════════════════════
alter table public.restaurant_claims rename column email to business_email;
alter table public.restaurant_claims rename column business_role to role;
alter table public.restaurant_claims rename column proof_url to verification_document_url; -- path nel bucket privato

alter table public.restaurant_claims
  add column first_name          text,
  add column last_name           text,
  add column business_name       text,
  add column tax_code            text,
  add column website             text,
  add column verification_method public.verification_method not null default 'manual',
  add column submitted_at        timestamptz not null default now(),
  add column approved_at         timestamptz,
  add column rejected_at         timestamptz,
  add column info_requested_at   timestamptz;

update public.restaurant_claims
   set first_name   = coalesce(nullif(split_part(trim(full_name), ' ', 1), ''), '—'),
       last_name    = coalesce(nullif(trim(substr(trim(full_name), length(split_part(trim(full_name), ' ', 1)) + 1)), ''), '—'),
       submitted_at = created_at,
       approved_at  = case when status = 'approved' then reviewed_at end,
       rejected_at  = case when status = 'rejected' then reviewed_at end;

alter table public.restaurant_claims
  alter column first_name set not null,
  alter column last_name set not null,
  drop column full_name,
  add constraint restaurant_claims_lengths check (
    length(first_name) between 1 and 80 and length(last_name) between 1 and 80
    and length(phone) between 5 and 30
    and (message is null or length(message) <= 2000)
    and (business_name is null or length(business_name) <= 200)
    and (admin_notes is null or length(admin_notes) <= 4000)
  ),
  add constraint restaurant_claims_email check (business_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$');

-- Una sola richiesta aperta per utente e locale
drop index if exists public.restaurant_claims_one_pending;
create unique index restaurant_claims_one_open on public.restaurant_claims(restaurant_id, user_id)
  where status in ('pending', 'under_review', 'more_information_required');

-- Date di invio non falsificabili dal client
create or replace function public.restaurant_claims_before_insert()
returns trigger language plpgsql as $$
begin
  new.submitted_at := now();
  new.created_at := now();
  return new;
end $$;
create trigger restaurant_claims_before_insert before insert on public.restaurant_claims
  for each row execute function public.restaurant_claims_before_insert();

-- Conversazione Admin ⇄ richiedente ("Informazioni aggiuntive richieste")
create table public.restaurant_claim_messages (
  id              uuid primary key default gen_random_uuid(),
  claim_id        uuid not null references public.restaurant_claims(id) on delete cascade,
  author_id       uuid references public.profiles(id) on delete set null,
  author_role     text not null check (author_role in ('admin', 'claimant')),
  body            text not null check (length(body) between 1 and 4000),
  attachment_path text,
  created_at      timestamptz not null default now()
);
create index restaurant_claim_messages_claim_idx on public.restaurant_claim_messages(claim_id, created_at);

-- ════════════════════════════════════════════════════════════════════
--  6. SEGNALAZIONI "Informazioni errate"
-- ════════════════════════════════════════════════════════════════════
create table public.restaurant_reports (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id       uuid references public.profiles(id) on delete set null,
  report_type   public.report_type not null,
  description   text not null check (length(description) between 5 and 2000),
  email         text check (email is null or email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  status        public.report_status not null default 'open',
  admin_notes   text,
  resolved_by   uuid references public.profiles(id) on delete set null,
  resolved_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index restaurant_reports_status_idx on public.restaurant_reports(status, created_at desc);
create index restaurant_reports_restaurant_idx on public.restaurant_reports(restaurant_id);
create trigger restaurant_reports_updated_at before update on public.restaurant_reports
  for each row execute function public.set_updated_at();

-- Normalizza e limita le segnalazioni (anti-flood senza tracciare IP)
create or replace function public.restaurant_reports_before_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then
    new.status := 'open';
    new.admin_notes := null;
    new.resolved_by := null;
    new.resolved_at := null;
    new.created_at := now();
    if (select count(*) from public.restaurant_reports
         where restaurant_id = new.restaurant_id and created_at > now() - interval '1 day') >= 30 then
      raise exception 'Troppe segnalazioni per questo locale: riprova più tardi.' using errcode = 'P0001';
    end if;
    if new.user_id is not null and (select count(*) from public.restaurant_reports
         where user_id = new.user_id and created_at > now() - interval '1 hour') >= 10 then
      raise exception 'Hai inviato troppe segnalazioni: riprova più tardi.' using errcode = 'P0001';
    end if;
  end if;
  return new;
end $$;
create trigger restaurant_reports_before_insert before insert on public.restaurant_reports
  for each row execute function public.restaurant_reports_before_insert();

-- ════════════════════════════════════════════════════════════════════
--  7. RPC: WORKFLOW RIVENDICAZIONE
-- ════════════════════════════════════════════════════════════════════
create or replace function public.approve_claim(p_claim_id uuid, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_claim public.restaurant_claims;
begin
  if not public.is_admin() then
    raise exception 'Solo un amministratore può approvare le rivendicazioni' using errcode = '42501';
  end if;
  select * into v_claim from public.restaurant_claims where id = p_claim_id for update;
  if not found then raise exception 'Richiesta non trovata'; end if;
  if v_claim.status not in ('pending', 'under_review', 'more_information_required') then
    raise exception 'La richiesta è già stata gestita';
  end if;
  if exists (select 1 from public.restaurants where id = v_claim.restaurant_id and owner_id is not null and owner_id <> v_claim.user_id) then
    raise exception 'Il locale ha già un titolare: usa "Trasferisci proprietà"';
  end if;

  -- Il trigger restaurants_sync_owner_member crea la membership e aggiorna il ruolo del profilo
  update public.restaurants
     set owner_id = v_claim.user_id, claimed_by = v_claim.user_id, claimed_at = now(),
         is_verified = true, data_status = 'claimed'
   where id = v_claim.restaurant_id;

  update public.restaurant_claims
     set status = 'approved', admin_notes = coalesce(p_notes, admin_notes),
         reviewed_by = auth.uid(), reviewed_at = now(), approved_at = now()
   where id = p_claim_id;

  -- Le altre richieste aperte sullo stesso locale vengono chiuse
  update public.restaurant_claims
     set status = 'rejected', rejected_at = now(), reviewed_by = auth.uid(), reviewed_at = now(),
         admin_notes = coalesce(admin_notes, 'Rivendicazione assegnata ad altro richiedente')
   where restaurant_id = v_claim.restaurant_id and id <> p_claim_id
     and status in ('pending', 'under_review', 'more_information_required');
end $$;

create or replace function public.reject_claim(p_claim_id uuid, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then
    raise exception 'Solo un amministratore può rifiutare le rivendicazioni' using errcode = '42501';
  end if;
  update public.restaurant_claims
     set status = 'rejected', admin_notes = coalesce(p_notes, admin_notes),
         reviewed_by = auth.uid(), reviewed_at = now(), rejected_at = now()
   where id = p_claim_id and status in ('pending', 'under_review', 'more_information_required');
  if not found then raise exception 'Richiesta non trovata o già gestita'; end if;
end $$;

create or replace function public.set_claim_under_review(p_claim_id uuid, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  update public.restaurant_claims
     set status = 'under_review', admin_notes = coalesce(p_notes, admin_notes), reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_claim_id and status in ('pending', 'more_information_required', 'under_review');
  if not found then raise exception 'Richiesta non trovata o già gestita'; end if;
end $$;

create or replace function public.request_claim_info(p_claim_id uuid, p_message text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if coalesce(trim(p_message), '') = '' then raise exception 'Scrivi quali informazioni servono'; end if;
  update public.restaurant_claims
     set status = 'more_information_required', info_requested_at = now(), admin_notes = p_message,
         reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_claim_id and status in ('pending', 'under_review', 'more_information_required');
  if not found then raise exception 'Richiesta non trovata o già gestita'; end if;
  insert into public.restaurant_claim_messages (claim_id, author_id, author_role, body)
  values (p_claim_id, auth.uid(), 'admin', p_message);
end $$;

create or replace function public.respond_to_claim(p_claim_id uuid, p_message text, p_attachment_path text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_claim public.restaurant_claims;
begin
  select * into v_claim from public.restaurant_claims where id = p_claim_id and user_id = auth.uid() for update;
  if not found then raise exception 'Richiesta non trovata' using errcode = '42501'; end if;
  if v_claim.status not in ('pending', 'under_review', 'more_information_required') then
    raise exception 'La richiesta è chiusa';
  end if;
  if coalesce(trim(p_message), '') = '' then raise exception 'Il messaggio è vuoto'; end if;
  if p_attachment_path is not null and p_attachment_path not like (auth.uid()::text || '/%') then
    raise exception 'Allegato non valido' using errcode = '42501';
  end if;
  insert into public.restaurant_claim_messages (claim_id, author_id, author_role, body, attachment_path)
  values (p_claim_id, auth.uid(), 'claimant', p_message, p_attachment_path);
  if v_claim.status = 'more_information_required' then
    update public.restaurant_claims set status = 'under_review' where id = p_claim_id;
  end if;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  8. RPC: GESTIONE PROPRIETÀ (solo Admin)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.admin_transfer_ownership(p_restaurant_id uuid, p_user_id uuid, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if not exists (select 1 from public.profiles where id = p_user_id) then raise exception 'Utente non trovato'; end if;
  update public.restaurants
     set owner_id = p_user_id, claimed_by = p_user_id, claimed_at = now(), is_verified = true, data_status = 'claimed',
         verification_notes = coalesce(p_notes, verification_notes)
   where id = p_restaurant_id;
  if not found then raise exception 'Ristorante non trovato'; end if;
end $$;

create or replace function public.admin_revoke_ownership(p_restaurant_id uuid, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_users uuid[];
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select array_agg(user_id) into v_users from public.restaurant_members where restaurant_id = p_restaurant_id and status = 'active';
  update public.restaurant_members set status = 'revoked' where restaurant_id = p_restaurant_id and status <> 'revoked';
  update public.restaurants
     set owner_id = null, claimed_by = null, claimed_at = null, is_verified = false,
         data_status = case when last_verified_at is not null then 'partially_verified'::public.data_status else 'unverified'::public.data_status end,
         verification_notes = coalesce(p_notes, verification_notes)
   where id = p_restaurant_id;
  if not found then raise exception 'Ristorante non trovato'; end if;
  perform public.refresh_profile_role(u) from unnest(coalesce(v_users, '{}')) u;
end $$;

create or replace function public.admin_set_member(p_restaurant_id uuid, p_user_id uuid, p_role public.member_role)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p_role = 'owner' then
    perform public.admin_transfer_ownership(p_restaurant_id, p_user_id, null);
    return;
  end if;
  insert into public.restaurant_members (restaurant_id, user_id, role, status, invited_by)
  values (p_restaurant_id, p_user_id, p_role, 'active', auth.uid())
  on conflict (restaurant_id, user_id) do update set role = excluded.role, status = 'active';
  perform public.refresh_profile_role(p_user_id);
end $$;

create or replace function public.admin_remove_member(p_member_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v public.restaurant_members;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into v from public.restaurant_members where id = p_member_id;
  if not found then raise exception 'Membro non trovato'; end if;
  if v.role = 'owner' and v.status = 'active' then
    perform public.admin_revoke_ownership(v.restaurant_id, null);
  else
    update public.restaurant_members set status = 'revoked' where id = p_member_id;
    perform public.refresh_profile_role(v.user_id);
  end if;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  9. RPC: IMPORT E DUPLICAZIONE
-- ════════════════════════════════════════════════════════════════════
-- Crea o aggiorna un ristorante in modo atomico (dati + categorie + fonte).
-- La logica di confronto/merge è nel client (anteprima Admin): qui solo
-- whitelist dei campi, slug univoco e scrittura.
create or replace function public.admin_import_restaurant(
  p_restaurant_id     uuid,
  p_data              jsonb,
  p_category_slugs    text[] default null,
  p_replace_categories boolean default false,
  p_source            jsonb default null,
  p_batch_id          uuid default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  allowed text[] := array[
    'name','slug','short_description','description','address','city_id','postal_code','latitude','longitude',
    'phone','whatsapp','email','website','instagram','facebook','tiktok','logo_url','cover_url',
    'price_range','average_price','is_all_you_can_eat','ayce_lunch_price','ayce_dinner_price','ayce_weekend_price',
    'has_delivery','has_takeaway','has_reservation','reservation_url','services',
    'source_name','source_url','external_id','google_place_id','data_status','last_verified_at',
    'verification_notes','opening_hours_last_verified_at','menu_last_verified_at',
    'is_active','is_temporarily_closed','is_permanently_closed','opened_at'
  ];
  v_cols text[];
  v_list text;
  v_id uuid;
  v_action text;
begin
  if not public.is_admin_or_service() then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  select coalesce(array_agg(k), '{}') into v_cols from jsonb_object_keys(p_data) k where k = any(allowed);

  if p_restaurant_id is null then
    if coalesce(p_data->>'name', '') = '' or coalesce(p_data->>'city_id', '') = '' then
      raise exception 'name e city_id sono obbligatori';
    end if;
    p_data := p_data || jsonb_build_object('slug', public.unique_restaurant_slug(coalesce(nullif(p_data->>'slug', ''), p_data->>'name')));
    v_cols := array_append(array_remove(v_cols, 'slug'), 'slug');
    select string_agg(quote_ident(c), ',') into v_list from unnest(v_cols) c;
    execute format('insert into public.restaurants (%s) select %s from jsonb_populate_record(null::public.restaurants, $1) returning id', v_list, v_list)
      into v_id using p_data;
    v_action := 'created';
  else
    v_id := p_restaurant_id;
    v_cols := array_remove(v_cols, 'slug'); -- lo slug (URL SEO) non si cambia via import
    if array_length(v_cols, 1) > 0 then
      select string_agg(quote_ident(c), ',') into v_list from unnest(v_cols) c;
      execute format('update public.restaurants set (%s) = (select %s from jsonb_populate_record(null::public.restaurants, $1)) where id = $2', v_list, v_list)
        using p_data, v_id;
    end if;
    if not exists (select 1 from public.restaurants where id = v_id) then raise exception 'Ristorante non trovato'; end if;
    v_action := 'updated';
  end if;

  if p_category_slugs is not null then
    if p_replace_categories then
      delete from public.restaurant_categories where restaurant_id = v_id;
    end if;
    insert into public.restaurant_categories (restaurant_id, category_id, is_primary)
    select v_id, c.id,
           array_position(p_category_slugs, c.slug) = (select min(array_position(p_category_slugs, c2.slug)) from public.categories c2 where c2.slug = any(p_category_slugs))
           and not exists (select 1 from public.restaurant_categories x where x.restaurant_id = v_id and x.is_primary)
    from public.categories c where c.slug = any(p_category_slugs)
    on conflict (restaurant_id, category_id) do nothing;
  end if;

  if p_source is not null and (nullif(p_source->>'source_url', '') is not null or nullif(p_source->>'source_name', '') is not null) then
    if nullif(p_source->>'source_url', '') is not null then
      insert into public.restaurant_sources (restaurant_id, source_type, source_name, source_url, external_id, is_primary, last_checked_at, import_batch_id)
      values (v_id, coalesce(nullif(p_source->>'source_type', ''), 'import')::public.source_type, nullif(p_source->>'source_name', ''),
              p_source->>'source_url', nullif(p_source->>'external_id', ''),
              not exists (select 1 from public.restaurant_sources where restaurant_id = v_id and is_primary),
              coalesce(nullif(p_source->>'last_checked_at', '')::timestamptz, now()), p_batch_id)
      on conflict (restaurant_id, source_url) where source_url is not null do update
        set last_checked_at = excluded.last_checked_at,
            source_name = coalesce(excluded.source_name, restaurant_sources.source_name),
            external_id = coalesce(excluded.external_id, restaurant_sources.external_id),
            import_batch_id = coalesce(excluded.import_batch_id, restaurant_sources.import_batch_id);
    elsif not exists (select 1 from public.restaurant_sources where restaurant_id = v_id and source_url is null and source_name = p_source->>'source_name') then
      insert into public.restaurant_sources (restaurant_id, source_type, source_name, is_primary, last_checked_at, import_batch_id)
      values (v_id, coalesce(nullif(p_source->>'source_type', ''), 'import')::public.source_type, p_source->>'source_name',
              not exists (select 1 from public.restaurant_sources where restaurant_id = v_id and is_primary),
              coalesce(nullif(p_source->>'last_checked_at', '')::timestamptz, now()), p_batch_id);
    end if;
  end if;

  return jsonb_build_object('id', v_id, 'slug', (select slug from public.restaurants where id = v_id), 'action', v_action);
end $$;

-- Duplica una scheda (es. catene): copia dati, categorie e orari; NON copia titolare, fonti, ID esterni, menu.
create or replace function public.admin_duplicate_restaurant(p_restaurant_id uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_src public.restaurants;
  v_cols text;
  v_new uuid := gen_random_uuid();
  v_patch jsonb;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into v_src from public.restaurants where id = p_restaurant_id;
  if not found then raise exception 'Ristorante non trovato'; end if;
  v_patch := jsonb_build_object(
    'id', v_new, 'name', v_src.name || ' (copia)', 'slug', public.unique_restaurant_slug(v_src.slug || '-copia'),
    'owner_id', null, 'claimed_by', null, 'claimed_at', null, 'is_verified', false, 'is_active', false,
    'is_featured', false, 'is_sponsored', false, 'data_status', 'unverified', 'google_place_id', null,
    'external_id', null, 'source_url', null, 'source_name', null, 'last_verified_at', null,
    'popularity_score', 0, 'created_at', now(), 'updated_at', now()
  );
  select string_agg(quote_ident(column_name), ',' order by ordinal_position) into v_cols
    from information_schema.columns
   where table_schema = 'public' and table_name = 'restaurants' and is_generated = 'NEVER';
  execute format('insert into public.restaurants (%1$s) select %1$s from jsonb_populate_record($1, $2)', v_cols) using v_src, v_patch;
  insert into public.restaurant_categories (restaurant_id, category_id, is_primary)
    select v_new, category_id, is_primary from public.restaurant_categories where restaurant_id = p_restaurant_id;
  insert into public.restaurant_hours (restaurant_id, day_of_week, opens_at, closes_at, is_closed, label)
    select v_new, day_of_week, opens_at, closes_at, is_closed, label from public.restaurant_hours where restaurant_id = p_restaurant_id;
  return v_new;
end $$;

-- KPI dashboard Admin (estesi)
create or replace function public.admin_dashboard_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb;
begin
  if not public.is_admin() then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  select jsonb_build_object(
    'restaurants_total',      (select count(*) from public.restaurants),
    'restaurants_active',     (select count(*) from public.restaurants where is_active),
    'restaurants_draft',      (select count(*) from public.restaurants where not is_active),
    'restaurants_claimed',    (select count(*) from public.restaurants where owner_id is not null),
    'restaurants_demo',       (select count(*) from public.restaurants where is_demo),
    'restaurants_real',       (select count(*) from public.restaurants where not is_demo),
    'restaurants_verified',   (select count(*) from public.restaurants where data_status in ('verified', 'claimed')),
    'restaurants_unverified', (select count(*) from public.restaurants where data_status in ('unverified', 'outdated')),
    'claims_pending',         (select count(*) from public.restaurant_claims where status in ('pending', 'under_review')),
    'claims_more_info',       (select count(*) from public.restaurant_claims where status = 'more_information_required'),
    'reports_open',           (select count(*) from public.restaurant_reports where status in ('open', 'in_progress')),
    'users_total',            (select count(*) from public.profiles),
    'owners_total',           (select count(distinct user_id) from public.restaurant_members where status = 'active'),
    'offers_active',          (select count(*) from public.offers where is_active and (ends_at is null or ends_at > now())),
    'coupons_active',         (select count(*) from public.coupons where is_active and (valid_until is null or valid_until > now())),
    'sponsored_active',       (select count(*) from public.sponsored_restaurants where is_active and (ends_at is null or ends_at > now())),
    'events_30d',             (select count(*) from public.analytics_events where created_at >= now() - interval '30 days'),
    'views_30d',              (select count(*) from public.analytics_events where event_type = 'view' and created_at >= now() - interval '30 days'),
    'show_demo_data',         public.demo_data_visible()
  ) into v;
  return v;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  10. ROW LEVEL SECURITY
-- ════════════════════════════════════════════════════════════════════
alter table public.platform_settings         enable row level security;
alter table public.restaurant_members        enable row level security;
alter table public.restaurant_sources        enable row level security;
alter table public.restaurant_claim_messages enable row level security;
alter table public.restaurant_reports        enable row level security;
alter table public.import_batches            enable row level security;

-- Impostazioni: lettura pubblica (servono al frontend), scrittura Admin
create policy "platform_settings_read" on public.platform_settings for select using (true);
create policy "platform_settings_admin" on public.platform_settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Ristoranti: il pubblico vede solo i locali pubblicati (demo solo se abilitati)
drop policy "restaurants_public_read" on public.restaurants;
create policy "restaurants_public_read" on public.restaurants for select using (
  (is_active and (not is_demo or (select public.demo_data_visible())))
  or public.can_manage_restaurant(id)
);

-- Tabelle figlie: stesso criterio di pubblicazione
do $$
declare t text;
begin
  foreach t in array array['restaurant_categories','restaurant_images','restaurant_hours','menus','menu_categories','menu_items'] loop
    execute format('drop policy %I on public.%I', t || '_public_read', t);
    execute format($f$
      create policy "%1$s_public_read" on public.%1$I for select using (
        public.restaurant_is_public(restaurant_id) or public.can_manage_restaurant(restaurant_id)
      )$f$, t);
  end loop;
end $$;

drop policy "offers_public_read" on public.offers;
create policy "offers_public_read" on public.offers for select using (
  (is_active and starts_at <= now() and (ends_at is null or ends_at > now()) and public.restaurant_is_public(restaurant_id))
  or public.can_manage_restaurant(restaurant_id)
);
drop policy "coupons_public_read" on public.coupons;
create policy "coupons_public_read" on public.coupons for select using (
  (is_active and valid_from <= now() and (valid_until is null or valid_until > now()) and public.restaurant_is_public(restaurant_id))
  or public.can_manage_restaurant(restaurant_id)
);

-- Membri: ognuno vede le proprie membership, il team del proprio locale e l'Admin tutto.
-- Scrittura SOLO tramite RPC Admin (nessuna auto-assegnazione possibile).
create policy "restaurant_members_read" on public.restaurant_members for select to authenticated using (
  user_id = (select auth.uid()) or public.can_manage_restaurant(restaurant_id)
);
create policy "restaurant_members_admin" on public.restaurant_members for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Fonti: pubbliche per trasparenza, gestite dall'Admin
create policy "restaurant_sources_public_read" on public.restaurant_sources for select using (
  public.restaurant_is_public(restaurant_id) or public.can_manage_restaurant(restaurant_id)
);
create policy "restaurant_sources_admin" on public.restaurant_sources for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Rivendicazioni: inserimento solo proprio, in stato iniziale, su locale rivendicabile
drop policy "claims_insert_own_pending" on public.restaurant_claims;
create policy "claims_insert_own" on public.restaurant_claims for insert to authenticated with check (
  user_id = (select auth.uid())
  and status = 'pending'
  and reviewed_by is null and reviewed_at is null and admin_notes is null
  and approved_at is null and rejected_at is null and info_requested_at is null
  and (verification_document_url is null or verification_document_url like ((select auth.uid())::text || '/%'))
  and public.restaurant_is_claimable(restaurant_id)
);

-- Messaggi claim: lettura richiedente/Admin; scrittura solo via RPC
create policy "claim_messages_read" on public.restaurant_claim_messages for select to authenticated using (
  public.is_admin()
  or exists (select 1 from public.restaurant_claims c where c.id = claim_id and c.user_id = (select auth.uid()))
);

-- Segnalazioni: chiunque può inviarne (anche anonimo) su locali pubblici; lettura propria/Admin
create policy "reports_insert" on public.restaurant_reports for insert to anon, authenticated with check (
  (user_id is null or user_id = (select auth.uid()))
  and status = 'open' and admin_notes is null and resolved_by is null
  and public.restaurant_is_public(restaurant_id)
);
create policy "reports_read" on public.restaurant_reports for select to authenticated using (
  public.is_admin() or user_id = (select auth.uid())
);
create policy "reports_admin_update" on public.restaurant_reports for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy "reports_admin_delete" on public.restaurant_reports for delete to authenticated
  using (public.is_admin());

-- Import: solo Admin
create policy "import_batches_admin" on public.import_batches for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ════════════════════════════════════════════════════════════════════
--  11. STORAGE PRIVATO: documenti di verifica
--  Path: <user_id>/<uuid>/<file>. Accesso: solo chi carica e Admin.
-- ════════════════════════════════════════════════════════════════════
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('claim-documents', 'claim-documents', false, 10485760,
        array['application/pdf', 'image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = false;

create policy "claim_documents_insert_own" on storage.objects for insert to authenticated with check (
  bucket_id = 'claim-documents' and (storage.foldername(name))[1] = (select auth.uid())::text
);
create policy "claim_documents_read_own_or_admin" on storage.objects for select to authenticated using (
  bucket_id = 'claim-documents' and ((storage.foldername(name))[1] = (select auth.uid())::text or public.is_admin())
);
create policy "claim_documents_delete_own_or_admin" on storage.objects for delete to authenticated using (
  bucket_id = 'claim-documents' and ((storage.foldername(name))[1] = (select auth.uid())::text or public.is_admin())
);

-- ════════════════════════════════════════════════════════════════════
--  12. PRIVILEGI
-- ════════════════════════════════════════════════════════════════════
grant select on public.platform_settings, public.restaurant_sources to anon, authenticated;
grant insert, update, delete on public.platform_settings, public.restaurant_sources to authenticated;
grant select, insert, update, delete on public.restaurant_members, public.import_batches to authenticated;
grant select on public.restaurant_claim_messages to authenticated;
grant insert on public.restaurant_reports to anon, authenticated;
grant select, update, delete on public.restaurant_reports to authenticated;

revoke all on function public.approve_claim(uuid, text) from public, anon;
revoke all on function public.reject_claim(uuid, text) from public, anon;
revoke all on function public.set_claim_under_review(uuid, text) from public, anon;
revoke all on function public.request_claim_info(uuid, text) from public, anon;
revoke all on function public.respond_to_claim(uuid, text, text) from public, anon;
revoke all on function public.admin_transfer_ownership(uuid, uuid, text) from public, anon;
revoke all on function public.admin_revoke_ownership(uuid, text) from public, anon;
revoke all on function public.admin_set_member(uuid, uuid, public.member_role) from public, anon;
revoke all on function public.admin_remove_member(uuid) from public, anon;
revoke all on function public.admin_import_restaurant(uuid, jsonb, text[], boolean, jsonb, uuid) from public, anon;
revoke all on function public.admin_duplicate_restaurant(uuid) from public, anon;
revoke all on function public.refresh_profile_role(uuid) from public, anon, authenticated;
grant execute on function public.approve_claim(uuid, text), public.reject_claim(uuid, text),
  public.set_claim_under_review(uuid, text), public.request_claim_info(uuid, text),
  public.respond_to_claim(uuid, text, text), public.admin_transfer_ownership(uuid, uuid, text),
  public.admin_revoke_ownership(uuid, text), public.admin_set_member(uuid, uuid, public.member_role),
  public.admin_remove_member(uuid), public.admin_duplicate_restaurant(uuid) to authenticated;
grant execute on function public.admin_import_restaurant(uuid, jsonb, text[], boolean, jsonb, uuid) to authenticated, service_role;
grant execute on function public.demo_data_visible(), public.restaurant_is_public(uuid),
  public.restaurant_is_claimable(uuid) to anon, authenticated;
