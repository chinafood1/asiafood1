-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0009 · Dati di riferimento Fase 2 (GENERATO da scripts/generate-seed-sql.ts)
--  Stato completo: regioni, province pugliesi, 29 comuni della provincia
--  di Taranto, categorie (incl. Bubble Tea, Asian Bakery, Asian Grocery), piani.
--  Idempotente (on conflict do nothing): aggiunge solo le righe mancanti.
-- ════════════════════════════════════════════════════════════════════

insert into public.regions (id, name, slug, code, country_code, is_active, sort_order) values
  ('a0000000-0000-4000-8000-000000000001', 'Piemonte', 'piemonte', '01', 'IT', false, 0),
  ('a0000000-0000-4000-8000-000000000002', 'Valle d''Aosta', 'valle-d-aosta', '02', 'IT', false, 1),
  ('a0000000-0000-4000-8000-000000000003', 'Lombardia', 'lombardia', '03', 'IT', false, 2),
  ('a0000000-0000-4000-8000-000000000004', 'Trentino-Alto Adige', 'trentino-alto-adige', '04', 'IT', false, 3),
  ('a0000000-0000-4000-8000-000000000005', 'Veneto', 'veneto', '05', 'IT', false, 4),
  ('a0000000-0000-4000-8000-000000000006', 'Friuli-Venezia Giulia', 'friuli-venezia-giulia', '06', 'IT', false, 5),
  ('a0000000-0000-4000-8000-000000000007', 'Liguria', 'liguria', '07', 'IT', false, 6),
  ('a0000000-0000-4000-8000-000000000008', 'Emilia-Romagna', 'emilia-romagna', '08', 'IT', false, 7),
  ('a0000000-0000-4000-8000-000000000009', 'Toscana', 'toscana', '09', 'IT', false, 8),
  ('a0000000-0000-4000-8000-00000000000a', 'Umbria', 'umbria', '10', 'IT', false, 9),
  ('a0000000-0000-4000-8000-00000000000b', 'Marche', 'marche', '11', 'IT', false, 10),
  ('a0000000-0000-4000-8000-00000000000c', 'Lazio', 'lazio', '12', 'IT', false, 11),
  ('a0000000-0000-4000-8000-00000000000d', 'Abruzzo', 'abruzzo', '13', 'IT', false, 12),
  ('a0000000-0000-4000-8000-00000000000e', 'Molise', 'molise', '14', 'IT', false, 13),
  ('a0000000-0000-4000-8000-00000000000f', 'Campania', 'campania', '15', 'IT', false, 14),
  ('a0000000-0000-4000-8000-000000000010', 'Puglia', 'puglia', '16', 'IT', true, 15),
  ('a0000000-0000-4000-8000-000000000011', 'Basilicata', 'basilicata', '17', 'IT', false, 16),
  ('a0000000-0000-4000-8000-000000000012', 'Calabria', 'calabria', '18', 'IT', false, 17),
  ('a0000000-0000-4000-8000-000000000013', 'Sicilia', 'sicilia', '19', 'IT', false, 18),
  ('a0000000-0000-4000-8000-000000000014', 'Sardegna', 'sardegna', '20', 'IT', false, 19)
on conflict (id) do nothing;

insert into public.provinces (id, region_id, name, slug, code, is_active) values
  ('b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Taranto', 'provincia-di-taranto', 'TA', true),
  ('b0000000-0000-4000-8000-000000000002', 'a0000000-0000-4000-8000-000000000010', 'Bari', 'citta-metropolitana-di-bari', 'BA', false),
  ('b0000000-0000-4000-8000-000000000003', 'a0000000-0000-4000-8000-000000000010', 'Brindisi', 'provincia-di-brindisi', 'BR', false),
  ('b0000000-0000-4000-8000-000000000004', 'a0000000-0000-4000-8000-000000000010', 'Lecce', 'provincia-di-lecce', 'LE', false),
  ('b0000000-0000-4000-8000-000000000005', 'a0000000-0000-4000-8000-000000000010', 'Foggia', 'provincia-di-foggia', 'FG', false),
  ('b0000000-0000-4000-8000-000000000006', 'a0000000-0000-4000-8000-000000000010', 'Barletta-Andria-Trani', 'provincia-bat', 'BT', false)
on conflict (id) do nothing;

insert into public.cities (id, province_id, region_id, name, slug, istat_code, postal_code, latitude, longitude, population, is_active, is_launch_market) values
  ('c0000000-0000-4000-8000-000000000001', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Taranto', 'taranto', null, '74121', 40.4644, 17.247, null, true, true),
  ('c0000000-0000-4000-8000-000000000002', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Massafra', 'massafra', null, '74016', 40.5875, 17.1128, null, true, true),
  ('c0000000-0000-4000-8000-000000000003', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Martina Franca', 'martina-franca', null, '74015', 40.7056, 17.3361, null, true, true),
  ('c0000000-0000-4000-8000-000000000004', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Grottaglie', 'grottaglie', null, '74023', 40.5363, 17.4368, null, true, true),
  ('c0000000-0000-4000-8000-000000000005', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Manduria', 'manduria', null, '74024', 40.402, 17.634, null, true, true),
  ('c0000000-0000-4000-8000-000000000006', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Castellaneta', 'castellaneta', null, '74011', 40.629, 16.938, null, true, true),
  ('c0000000-0000-4000-8000-000000000007', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Ginosa', 'ginosa', null, '74013', 40.578, 16.757, null, true, true),
  ('c0000000-0000-4000-8000-000000000008', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Laterza', 'laterza', null, '74014', 40.626, 16.8, null, true, true),
  ('c0000000-0000-4000-8000-000000000009', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Palagiano', 'palagiano', null, '74019', 40.578, 17.04, null, true, true),
  ('c0000000-0000-4000-8000-00000000000a', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Mottola', 'mottola', null, '74017', 40.634, 17.038, null, true, true),
  ('c0000000-0000-4000-8000-00000000000b', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Pulsano', 'pulsano', null, '74026', 40.383, 17.354, null, true, true),
  ('c0000000-0000-4000-8000-00000000000c', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Leporano', 'leporano', null, '74020', 40.382, 17.334, null, true, true),
  ('c0000000-0000-4000-8000-00000000000d', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'San Giorgio Ionico', 'san-giorgio-ionico', null, '74027', 40.459, 17.379, null, true, true),
  ('c0000000-0000-4000-8000-00000000000e', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Statte', 'statte', null, '74010', 40.564, 17.206, null, true, true),
  ('c0000000-0000-4000-8000-00000000000f', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Monteiasi', 'monteiasi', null, '74020', 40.5, 17.383, null, true, true),
  ('c0000000-0000-4000-8000-000000000010', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Montemesola', 'montemesola', null, '74020', 40.568, 17.336, null, true, true),
  ('c0000000-0000-4000-8000-000000000011', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Carosino', 'carosino', null, '74021', 40.466, 17.398, null, true, true),
  ('c0000000-0000-4000-8000-000000000012', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Faggiano', 'faggiano', null, '74020', 40.42, 17.388, null, true, true),
  ('c0000000-0000-4000-8000-000000000013', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Fragagnano', 'fragagnano', null, '74022', 40.434, 17.472, null, true, true),
  ('c0000000-0000-4000-8000-000000000014', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Lizzano', 'lizzano', null, '74020', 40.391, 17.447, null, true, true),
  ('c0000000-0000-4000-8000-000000000015', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Torricella', 'torricella', null, '74020', 40.356, 17.5, null, true, true),
  ('c0000000-0000-4000-8000-000000000016', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Maruggio', 'maruggio', null, '74020', 40.322, 17.572, null, true, true),
  ('c0000000-0000-4000-8000-000000000017', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Sava', 'sava', null, '74028', 40.403, 17.556, null, true, true),
  ('c0000000-0000-4000-8000-000000000018', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Avetrana', 'avetrana', null, '74020', 40.353, 17.733, null, true, true),
  ('c0000000-0000-4000-8000-000000000019', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Monteparano', 'monteparano', null, '74020', 40.444, 17.414, null, true, true),
  ('c0000000-0000-4000-8000-00000000001a', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'San Marzano di San Giuseppe', 'san-marzano-di-san-giuseppe', null, '74020', 40.454, 17.505, null, true, true),
  ('c0000000-0000-4000-8000-00000000001b', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Roccaforzata', 'roccaforzata', null, '74020', 40.438, 17.389, null, true, true),
  ('c0000000-0000-4000-8000-00000000001c', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Crispiano', 'crispiano', null, '74012', 40.604, 17.23, null, true, true),
  ('c0000000-0000-4000-8000-00000000001d', 'b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000010', 'Palagianello', 'palagianello', null, '74018', 40.609, 16.978, null, true, true)
on conflict (id) do nothing;

insert into public.categories (id, name, slug, emoji, description, seo_title, seo_description, image_url, sort_order, is_active) values
  ('d0000000-0000-4000-8000-000000000001', 'Sushi', 'sushi', '🍣', 'Nigiri, uramaki, sashimi e roll creativi.', null, null, null, 0, true),
  ('d0000000-0000-4000-8000-000000000002', 'Giapponese', 'giapponese', '🍱', 'Cucina giapponese tradizionale e contemporanea.', null, null, null, 1, true),
  ('d0000000-0000-4000-8000-000000000003', 'Cinese', 'cinese', '🥢', 'Ravioli, noodles, wok e specialità regionali cinesi.', null, null, null, 2, true),
  ('d0000000-0000-4000-8000-000000000004', 'Thai', 'thai', '🌶️', 'Pad thai, curry e sapori del sud-est asiatico.', null, null, null, 3, true),
  ('d0000000-0000-4000-8000-000000000005', 'Coreano', 'coreano', '🥩', 'Barbecue coreano, bibimbap e kimchi.', null, null, null, 4, true),
  ('d0000000-0000-4000-8000-000000000006', 'Poke', 'poke', '🥗', 'Bowl hawaiane fresche e personalizzabili.', null, null, null, 5, true),
  ('d0000000-0000-4000-8000-000000000007', 'Ramen', 'ramen', '🍜', 'Brodi lenti, noodles fatti a mano e topping.', null, null, null, 6, true),
  ('d0000000-0000-4000-8000-000000000008', 'Asian Fusion', 'fusion', '✨', 'Contaminazioni creative tra Asia e Mediterraneo.', null, null, null, 7, true),
  ('d0000000-0000-4000-8000-000000000009', 'Asian Street Food', 'street-food', '🥟', 'Bao, gyoza, dumpling e snack da strada.', null, null, null, 8, true),
  ('d0000000-0000-4000-8000-00000000000a', 'All You Can Eat', 'all-you-can-eat', '♾️', 'Formula a prezzo fisso, pranzo e cena.', null, null, null, 9, true),
  ('d0000000-0000-4000-8000-00000000000b', 'Bubble Tea', 'bubble-tea', '🧋', 'Tè al latte, perle di tapioca e bevande asiatiche.', null, null, null, 10, true),
  ('d0000000-0000-4000-8000-00000000000c', 'Asian Bakery', 'asian-bakery', '🥮', 'Dolci e prodotti da forno della tradizione asiatica.', null, null, null, 11, true),
  ('d0000000-0000-4000-8000-00000000000d', 'Asian Grocery', 'asian-grocery', '🛒', 'Alimentari asiatici con cucina o somministrazione.', null, null, null, 12, true)
on conflict (id) do nothing;

insert into public.subscription_plans (code, name, description, monthly_price, yearly_price, currency, features, sort_order, is_active) values
  ('free', 'Free', 'Scheda base, contatti e orari.', 0, 0, 'EUR', '{"max_images":3,"menu":true,"offers":0,"coupons":0,"analytics":false,"badge":false}'::jsonb, 0, true),
  ('business', 'Business', 'Galleria estesa, offerte e statistiche base.', 19, 190, 'EUR', '{"max_images":15,"menu":true,"offers":3,"coupons":3,"analytics":"basic","badge":false}'::jsonb, 1, true),
  ('premium', 'Premium', 'Offerte illimitate, statistiche avanzate, priorità nei risultati.', 49, 490, 'EUR', '{"max_images":40,"menu":true,"offers":-1,"coupons":-1,"analytics":"advanced","badge":true,"search_boost":1}'::jsonb, 2, true),
  ('top', 'Top', 'Visibilità massima: evidenza in home, città e categoria.', 99, 990, 'EUR', '{"max_images":-1,"menu":true,"offers":-1,"coupons":-1,"analytics":"advanced","badge":true,"search_boost":2,"home_featured":true}'::jsonb, 3, true)
on conflict (code) do nothing;

