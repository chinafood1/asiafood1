-- ════════════════════════════════════════════════════════════════════
--  FASE 13 · BUSINESS INTELLIGENCE — parte 2 (dashboard: ogni RPC risponde a una domanda operativa)
--  Tutte le RPC admin_growth_* richiedono il ruolo Admin. Nessun SQL arbitrario, nessun dato personale
--  in uscita (solo aggregati; nomi di ristoranti = dati pubblici di business).
-- ════════════════════════════════════════════════════════════════════

create or replace function public.growth_assert_admin()
returns void language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
end $$;

create or replace function public.growth_min_sample()
returns int language sql stable security definer set search_path = public as $$
  select public.billing_setting_int('growth_min_sample', 30);
$$;

-- Ristoranti del mercato (per slug; null = tutti) nel perimetro delle metriche
create or replace function public.growth_market_restaurants(p_market text)
returns setof uuid language sql stable security definer set search_path = public as $$
  select r.id from public.restaurants r join public.cities c on c.id = r.city_id
   where public.growth_in_scope(r.is_demo)
     and (p_market is null or p_market = '' or c.province_id = (select province_id from public.markets where slug = p_market));
$$;

-- Supporto ai reclami: le riaperture non erano tracciate → contatore additivo (da ora in avanti)
alter table public.support_tickets add column if not exists reopened_count int not null default 0;
create or replace function public.support_ticket_reopen_count()
returns trigger language plpgsql as $$
begin
  if old.status in ('resolved', 'closed') and new.status in ('open', 'in_progress', 'waiting_customer') then
    new.reopened_count := old.reopened_count + 1;
  end if;
  return new;
end $$;
drop trigger if exists support_ticket_reopen_count on public.support_tickets;
create trigger support_ticket_reopen_count before update of status on public.support_tickets for each row execute function public.support_ticket_reopen_count();

-- Feedback prodotto: categoria (Bug / Feature / UX / Dati ristorante / Prezzo / Consegna / Altro), impostabile dall'Admin
alter table public.product_feedback add column if not exists category text
  check (category is null or category in ('bug', 'feature_request', 'ux', 'restaurant_data', 'pricing', 'delivery', 'other'));

-- Motivi di disdetta standard (i codici storici restano validi e vengono mappati)
create or replace function public.growth_churn_reason(p text)
returns text language sql immutable as $$
  select case coalesce(p, '')
    when 'too_expensive' then 'too_expensive' when 'not_enough_results' then 'not_enough_results'
    when 'too_complicated' then 'too_complicated' when 'no_time' then 'too_complicated'
    when 'missing_feature' then 'missing_feature' when 'missing_features' then 'missing_feature'
    when 'business_closed' then 'business_closed' when 'closing' then 'business_closed'
    when 'seasonal' then 'seasonal' when 'competitor' then 'competitor' when 'using_other' then 'competitor'
    when 'temporary_pause' then 'temporary_pause' when '' then 'unknown'
    else 'other' end;
$$;

-- ────────────────────────────────────────────────────────────────────
--  1. TOTALI DI PERIODO (dagli aggregati) + QUALITÀ DEI DATI
-- ────────────────────────────────────────────────────────────────────
create or replace function public.growth_period_totals(p_from date, p_to date, p_market text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb; v_days int; v_cov int;
begin
  v_days := p_to - p_from + 1;
  select count(*) into v_cov from public.growth_computed_days where day between p_from and p_to;
  if p_market is null or p_market = '' then
    select jsonb_build_object(
      'visits', coalesce(sum(visits), 0), 'new_users', coalesce(sum(new_users), 0), 'sessions', coalesce(sum(sessions), 0),
      'searches', coalesce(sum(searches), 0), 'zero_result_searches', coalesce(sum(zero_result_searches), 0), 'ai_queries', coalesce(sum(ai_queries), 0),
      'restaurant_views', coalesce(sum(restaurant_views), 0), 'menu_views', coalesce(sum(menu_views), 0), 'intents', coalesce(sum(intents), 0),
      'reservations', coalesce(sum(reservations), 0), 'reservations_completed', coalesce(sum(reservations_completed), 0),
      'orders', coalesce(sum(orders), 0), 'orders_completed', coalesce(sum(orders_completed), 0), 'checkouts', coalesce(sum(checkouts), 0),
      'payment_failures', coalesce(sum(payment_failures), 0), 'gmv_cents', coalesce(sum(gmv_cents), 0),
      'order_fees_cents', coalesce(sum(order_fees_cents), 0), 'subscription_revenue_cents', coalesce(sum(subscription_revenue_cents), 0),
      'platform_revenue_cents', coalesce(sum(platform_revenue_cents), 0), 'coupon_claims', coalesce(sum(coupon_claims), 0),
      'coupon_redemptions', coalesce(sum(coupon_redemptions), 0), 'reviews', coalesce(sum(reviews), 0), 'referrals_qualified', coalesce(sum(referrals_qualified), 0),
      'new_paid_restaurants', coalesce(sum(new_paid_restaurants), 0), 'ai_cost_micros', coalesce(sum(ai_cost_micros), 0), 'ai_errors', coalesce(sum(ai_errors), 0),
      'active_users', (select count(distinct a.user_id) from public.user_activity_days a join public.profiles p on p.id = a.user_id
                        where a.day between p_from and p_to and p.role::text <> 'admin'))
      into v from public.daily_platform_metrics where date between p_from and p_to;
  else
    select jsonb_build_object(
      'visits', coalesce(sum(visits), 0), 'searches', coalesce(sum(searches), 0), 'zero_result_searches', coalesce(sum(zero_result_searches), 0),
      'restaurant_views', coalesce(sum(restaurant_views), 0), 'reservations', coalesce(sum(reservations), 0), 'orders', coalesce(sum(orders), 0),
      'gmv_cents', coalesce(sum(gmv_cents), 0))
      into v from public.daily_market_metrics d join public.markets m on m.id = d.market_id where m.slug = p_market and d.date between p_from and p_to;
    v := v || (select jsonb_build_object(
      'coupon_redemptions', coalesce(sum(d.coupon_redemptions), 0), 'coupon_claims', coalesce(sum(d.coupon_claims), 0),
      'reservations_completed', coalesce(sum(d.bookings_completed), 0), 'orders_completed', coalesce(sum(d.orders_completed), 0),
      'intents', coalesce(sum(d.calls + d.whatsapp + d.directions + d.add_to_cart + d.favorites + d.item_views), 0), 'reviews', coalesce(sum(d.reviews), 0))
      from public.daily_restaurant_metrics d where d.date between p_from and p_to and d.restaurant_id in (select public.growth_market_restaurants(p_market)));
  end if;
  return v || jsonb_build_object('days', v_days, 'days_computed', v_cov, 'complete', v_cov >= v_days);
end $$;

-- Conversioni del periodo (definizione unica, documentata): prenotazioni inviate + ordini pagati + coupon utilizzati
-- (+ indicazioni/chiamate se growth_directions_as_conversion = true)
create or replace function public.growth_conversions(p_tot jsonb, p_from date, p_to date, p_market text default null)
returns bigint language plpgsql stable security definer set search_path = public as $$
declare v bigint;
begin
  v := coalesce((p_tot ->> 'reservations')::bigint, 0) + coalesce((p_tot ->> 'orders')::bigint, 0) + coalesce((p_tot ->> 'coupon_redemptions')::bigint, 0);
  if public.billing_setting_bool('growth_directions_as_conversion', false) then
    v := v + coalesce((select sum(d.directions + d.calls) from public.daily_restaurant_metrics d
                        where d.date between p_from and p_to and d.restaurant_id in (select public.growth_market_restaurants(p_market))), 0);
  end if;
  return v;
end $$;

create or replace function public.growth_data_quality()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v jsonb := '[]'::jsonb; v_today date := (now() at time zone 'Europe/Rome')::date;
  v_visits bigint; v_sessions bigint; v_utm bigint; v_missing_days int; v_last timestamptz; v_ev_7 bigint; v_ev_prev bigint; v_min int := public.growth_min_sample();
begin
  select coalesce(sum(visits), 0), coalesce(sum(sessions), 0) into v_visits, v_sessions from public.daily_platform_metrics where date > v_today - 30;
  if v_visits >= v_min and v_sessions::numeric / v_visits < 0.3 then
    v := v || jsonb_build_object('key', 'low_consent', 'severity', 'info',
      'message', format('Solo il %s%% delle visite ha il consenso "Statistiche": funnel e ricerche per sessione sono un campione, non il totale.', round(v_sessions * 100.0 / v_visits)));
  end if;
  select count(*) filter (where utm_source is null and channel in ('other', 'direct')), count(*) into v_utm, v_visits
    from public.acquisition_visits where created_at > now() - interval '30 days';
  if v_visits >= v_min and v_utm::numeric / v_visits > 0.8 then
    v := v || jsonb_build_object('key', 'missing_campaign', 'severity', 'info',
      'message', format('%s%% delle visite non ha sorgente/campagna: usa link con UTM (Launch Control → Marketing) per attribuire i canali.', round(v_utm * 100.0 / v_visits)));
  end if;
  select count(*) into v_missing_days from generate_series(v_today - 29, v_today, interval '1 day') d
   where not exists (select 1 from public.growth_computed_days g where g.day = d::date);
  if v_missing_days > 0 then
    v := v || jsonb_build_object('key', 'aggregates_missing', 'severity', 'warning',
      'message', format('%s giorni degli ultimi 30 non sono ancora aggregati: esegui il backfill (Growth → Dati) per confronti completi.', v_missing_days));
  end if;
  select max(computed_at) into v_last from public.growth_computed_days where day < v_today;
  if v_last is not null and v_last < now() - interval '36 hours' then
    v := v || jsonb_build_object('key', 'aggregates_stale', 'severity', 'warning', 'message', 'Aggregazione giornaliera non eseguita da oltre 36 ore: verificare il job pianificato.');
  end if;
  select count(*) filter (where created_at > now() - interval '7 days'), count(*) filter (where created_at <= now() - interval '7 days')
    into v_ev_7, v_ev_prev from public.analytics_events where created_at > now() - interval '14 days';
  if v_ev_prev >= v_min and v_ev_7 = 0 then
    v := v || jsonb_build_object('key', 'tracking_gap', 'severity', 'critical', 'message', 'Nessun evento analytics negli ultimi 7 giorni (erano presenti la settimana prima): tracciamento interrotto?');
  end if;
  if exists (select 1 from public.restaurants r join public.cities c on c.id = r.city_id
              where r.is_active and public.growth_in_scope(r.is_demo) and not exists (select 1 from public.markets m where m.province_id = c.province_id)) then
    v := v || jsonb_build_object('key', 'restaurants_outside_markets', 'severity', 'info',
      'message', 'Alcuni ristoranti attivi sono in province senza mercato: compaiono nei totali ma non nelle viste per mercato.');
  end if;
  if (select count(*) from public.search_events where created_at > now() - interval '7 days') = 0
     and (select count(*) from public.app_events where event_type = 'search' and created_at > now() - interval '7 days') > 0 then
    v := v || jsonb_build_object('key', 'search_log_inactive', 'severity', 'warning', 'message', 'Ricerche registrate solo come evento generico (senza testo/risultati): aggiornare il client.');
  end if;
  if public.demo_data_visible() then
    v := v || jsonb_build_object('key', 'demo_included', 'severity', 'warning', 'message', 'Le metriche includono i locali DEMO (show_demo_data attivo): non sono risultati reali.');
  end if;
  return v;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  2. GROWTH COMMAND CENTER
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_overview(p_from date, p_to date, p_market text default null)
returns jsonb language plpgsql volatile security definer set search_path = public as $$
declare
  v_days int; v_pfrom date; v_pto date; v_cur jsonb; v_prev jsonb; v_today date := (now() at time zone 'Europe/Rome')::date;
  v_fresh timestamptz; v_min int := public.growth_min_sample(); v_conv bigint; v_pconv bigint; v_mkt text := nullif(p_market, '');
  v_rest uuid[];
begin
  perform public.growth_assert_admin();
  if p_from is null or p_to is null or p_to < p_from or p_to - p_from > 400 then raise exception 'Intervallo non valido' using errcode = '22023'; end if;
  if p_to >= v_today then v_fresh := public.growth_refresh_today(5); end if;
  v_days := p_to - p_from + 1; v_pto := p_from - 1; v_pfrom := p_from - v_days;
  v_cur := public.growth_period_totals(p_from, p_to, v_mkt);
  v_prev := public.growth_period_totals(v_pfrom, v_pto, v_mkt);
  v_conv := public.growth_conversions(v_cur, p_from, p_to, v_mkt);
  v_pconv := public.growth_conversions(v_prev, v_pfrom, v_pto, v_mkt);
  select array_agg(x) into v_rest from public.growth_market_restaurants(v_mkt) x;
  return jsonb_build_object(
    'range', jsonb_build_object('from', p_from, 'to', p_to, 'days', v_days, 'prev_from', v_pfrom, 'prev_to', v_pto),
    'market', v_mkt,
    'current', v_cur || jsonb_build_object('conversions', v_conv),
    -- Confronto solo se il periodo precedente è interamente aggregato (altrimenti il % sarebbe falso)
    'previous', case when (v_prev ->> 'complete')::boolean then v_prev || jsonb_build_object('conversions', v_pconv) end,
    'conversion_rate', case when coalesce((v_cur ->> 'visits')::int, 0) >= v_min then round(v_conv * 100.0 / (v_cur ->> 'visits')::int, 1) end,
    'state', jsonb_build_object(
      'users_total', (select count(*) from public.profiles where role::text = 'customer'),
      'users_today', (select count(*) from public.user_activity_days a join public.profiles p on p.id = a.user_id where a.day = v_today and p.role::text <> 'admin'),
      'users_7d', (select count(distinct a.user_id) from public.user_activity_days a join public.profiles p on p.id = a.user_id where a.day > v_today - 7 and p.role::text <> 'admin'),
      'users_30d', (select count(distinct a.user_id) from public.user_activity_days a join public.profiles p on p.id = a.user_id where a.day > v_today - 30 and p.role::text <> 'admin'),
      'new_users_7d', (select count(*) from public.profiles where role::text = 'customer' and created_at > now() - interval '7 days'),
      'restaurants_active', (select count(*) from public.restaurants where id = any(v_rest) and is_active),
      'restaurants_claimed', (select count(*) from public.restaurants where id = any(v_rest) and owner_id is not null),
      'restaurants_paying', (select count(distinct s.restaurant_id) from public.subscriptions s where s.restaurant_id = any(v_rest)
                               and public.subscription_in_env(s) and s.paid_started_at is not null and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
      'trials_active', (select count(*) from public.subscriptions s where s.restaurant_id = any(v_rest) and public.subscription_in_env(s) and s.status = 'trialing' and public.subscription_grants_access(s)),
      'trials_expiring_7d', (select count(*) from public.subscriptions s where s.restaurant_id = any(v_rest) and public.subscription_in_env(s) and s.status = 'trialing'
                               and s.trial_end between now() and now() + interval '7 days'),
      'mrr_cents', (select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) from public.subscriptions s where s.restaurant_id = any(v_rest)
                      and public.subscription_in_env(s) and s.status in ('active', 'past_due') and public.subscription_grants_access(s)),
      'retention_d30', (select case when count(*) >= v_min then round(count(*) filter (where exists (
                              select 1 from public.user_activity_days a where a.user_id = p.id and a.day > (p.created_at at time zone 'Europe/Rome')::date
                                and a.day <= (p.created_at at time zone 'Europe/Rome')::date + 30)) * 100.0 / count(*), 1) end
                          from public.profiles p where p.role::text = 'customer' and p.created_at < now() - interval '30 days' and p.created_at > now() - interval '180 days')),
    'series', coalesce((select jsonb_agg(jsonb_build_object('date', d.date, 'visits', d.visits, 'active_users', d.active_users, 'new_users', d.new_users,
                          'searches', d.searches, 'reservations', d.reservations, 'orders', d.orders, 'gmv_cents', d.gmv_cents, 'mrr_cents', d.mrr_cents) order by d.date)
                        from public.daily_platform_metrics d where d.date between p_from and p_to), '[]'::jsonb),
    'freshness', jsonb_build_object('today_at', coalesce(v_fresh, (select computed_at from public.growth_computed_days where day = v_today)),
                                    'batch_at', (select max(computed_at) from public.growth_computed_days where day < v_today)),
    'data_quality', public.growth_data_quality(),
    'min_sample', v_min,
    'demo_included', public.demo_data_visible());
end $$;

-- ────────────────────────────────────────────────────────────────────
--  3. FUNNEL CONSUMER (per sessione con consenso) e B2B (stato cumulativo + velocità)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_funnels(p_from date, p_to date, p_market text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_from timestamptz := p_from::timestamp at time zone 'Europe/Rome';
  v_to timestamptz := (p_to + 1)::timestamp at time zone 'Europe/Rome';
  v_win int := public.billing_setting_int('growth_return_window_days', 30);
  v_dir boolean := public.billing_setting_bool('growth_directions_as_conversion', false);
  v_mkt text := nullif(p_market, '');
  v_consumer jsonb; v_b2b jsonb; v_vel jsonb; v_ret jsonb;
begin
  perform public.growth_assert_admin();
  with s_all as (
    select session_id sid from public.analytics_events where created_at >= v_from and created_at < v_to and session_id is not null
    union select session_id from public.app_events where created_at >= v_from and created_at < v_to and session_id is not null
    union select session_id from public.search_events where created_at >= v_from and created_at < v_to and session_id is not null),
  s_search as (
    select session_id sid from public.search_events where created_at >= v_from and created_at < v_to and session_id is not null
    union select session_id from public.app_events where created_at >= v_from and created_at < v_to and session_id is not null
                                                     and event_type in ('search', 'near_me_search', 'map_area_search')),
  s_view as (select distinct session_id sid from public.analytics_events where created_at >= v_from and created_at < v_to and session_id is not null
                                                     and event_type in ('restaurant_view', 'view')),
  s_intent as (
    select distinct session_id sid from public.analytics_events where created_at >= v_from and created_at < v_to and session_id is not null
       and event_type in ('directions_click', 'phone_click', 'whatsapp_click', 'menu_item_view', 'reservation_start', 'add_to_cart', 'checkout_started',
                          'click_directions', 'click_phone', 'click_whatsapp', 'click_reservation', 'offer_view')
    union select session_id from public.app_events where created_at >= v_from and created_at < v_to and session_id is not null
       and (event_type = 'favorite_added' or (event_type = 'conversion' and metadata ->> 'kind' = 'coupon_claimed'))),
  s_conv as (
    select session_id sid from public.app_events where created_at >= v_from and created_at < v_to and session_id is not null
       and event_type = 'conversion' and metadata ->> 'kind' in ('reservation_completed', 'order_completed')
    union select session_id from public.orders where paid_at >= v_from and paid_at < v_to and session_id is not null and payment_status in ('paid', 'partially_refunded')
    union select session_id from public.analytics_events where v_dir and created_at >= v_from and created_at < v_to and session_id is not null
       and event_type in ('directions_click', 'phone_click', 'click_directions', 'click_phone'))
  select jsonb_build_array(
    jsonb_build_object('key', 'visit', 'label', 'Visita (sessione)', 'value', (select count(*) from s_all)),
    jsonb_build_object('key', 'search', 'label', 'Ricerca', 'value', (select count(*) from s_search where sid in (select sid from s_all))),
    jsonb_build_object('key', 'view', 'label', 'Scheda ristorante', 'value', (select count(*) from s_view)),
    jsonb_build_object('key', 'intent', 'label', 'Intenzione', 'value', (select count(*) from s_intent)),
    jsonb_build_object('key', 'conversion', 'label', 'Conversione', 'value', (select count(*) from s_conv)))
  into v_consumer;

  -- Ritorno: utenti registrati con una conversione nel periodo che hanno un giorno di attività successivo entro la finestra
  with conv as (
    select user_id, min(at) at from (
      select user_id, created_at at from public.reservations where created_at >= v_from and created_at < v_to and user_id is not null and status::text <> 'rejected'
      union all select user_id, paid_at from public.orders where paid_at >= v_from and paid_at < v_to and user_id is not null and payment_status in ('paid', 'partially_refunded')
      union all select user_id, redeemed_at from public.coupon_claims where redeemed_at >= v_from and redeemed_at < v_to and user_id is not null and status::text = 'redeemed') x
    group by user_id)
  select jsonb_build_object('window_days', v_win, 'converted_users', count(*),
    'returned_users', count(*) filter (where exists (select 1 from public.user_activity_days a where a.user_id = conv.user_id
                                         and a.day > (conv.at at time zone 'Europe/Rome')::date and a.day <= (conv.at at time zone 'Europe/Rome')::date + v_win)),
    'window_open', count(*) filter (where conv.at > now() - make_interval(days => v_win)))
    into v_ret from conv;

  -- B2B: stato cumulativo per fase (lead CRM + ristoranti censiti nel perimetro)
  with rs as (select id from public.growth_market_restaurants(v_mkt) id),
  lead as (select l.* from public.crm_leads l where l.kind = 'restaurant'
            and (v_mkt is null or l.market_id = (select id from public.markets where slug = v_mkt))),
  paid as (select distinct s.restaurant_id from public.subscriptions s join rs on rs.id = s.restaurant_id
            where public.subscription_in_env(s) and s.paid_started_at is not null)
  select jsonb_build_array(
    jsonb_build_object('key', 'discovered', 'label', 'Ristoranti censiti', 'value', (select count(*) from public.restaurants r join rs on rs.id = r.id where r.is_active)),
    jsonb_build_object('key', 'lead', 'label', 'Lead CRM', 'value', (select count(*) from lead)),
    jsonb_build_object('key', 'contacted', 'label', 'Contattati', 'value', (select count(*) from lead where public.crm_status_rank(status) >= public.crm_status_rank('contacted'))),
    jsonb_build_object('key', 'replied', 'label', 'Hanno risposto', 'value', (select count(*) from lead where public.crm_status_rank(status) >= public.crm_status_rank('replied'))),
    jsonb_build_object('key', 'claimed', 'label', 'Rivendicati', 'value', (select count(*) from public.restaurants r join rs on rs.id = r.id where r.owner_id is not null)),
    jsonb_build_object('key', 'trial', 'label', 'Prova avviata', 'value', (select count(*) from public.billing_trials t join rs on rs.id = t.restaurant_id)),
    jsonb_build_object('key', 'activated', 'label', 'Attivati', 'value', (select count(*) from public.restaurants r join rs on rs.id = r.id
                                                                        where r.owner_id is not null and public.launch_restaurant_activated(r.id))),
    jsonb_build_object('key', 'paid', 'label', 'Paganti (almeno una volta)', 'value', (select count(*) from paid)),
    jsonb_build_object('key', 'retained', 'label', 'Ancora paganti dopo 30 giorni', 'value', (select count(distinct s.restaurant_id) from public.subscriptions s join rs on rs.id = s.restaurant_id
        where public.subscription_in_env(s) and s.paid_started_at < now() - interval '30 days' and s.status in ('active', 'past_due') and public.subscription_grants_access(s))))
  into v_b2b;

  -- Velocità: tempi medi (giorni) tra le fasi, con numerosità
  with rs as (select id from public.growth_market_restaurants(v_mkt) id),
  lr as (select l.id, l.created_at, r.claimed_at, r.id rid from public.crm_leads l left join public.restaurants r on r.id = l.restaurant_id
          where l.kind = 'restaurant' and (l.restaurant_id is null or l.restaurant_id in (select id from rs))
            and (v_mkt is null or l.market_id = (select id from public.markets where slug = v_mkt))),
  fc as (select lr.id, lr.created_at, min(a.created_at) first_contact from lr join public.crm_activities a on a.lead_id = lr.id
          where a.type in ('call', 'whatsapp', 'email', 'instagram_dm', 'visit', 'demo', 'claim_link_sent', 'follow_up') group by 1, 2),
  ct as (select r.claimed_at, t.started_at from public.billing_trials t join public.restaurants r on r.id = t.restaurant_id join rs on rs.id = r.id
          where r.claimed_at is not null and t.started_at >= r.claimed_at),
  tp as (select t.started_at, min(s.paid_started_at) paid_at from public.billing_trials t join rs on rs.id = t.restaurant_id
           join public.subscriptions s on s.restaurant_id = t.restaurant_id and s.paid_started_at is not null and public.subscription_in_env(s)
          group by t.restaurant_id, t.started_at)
  select jsonb_build_object(
    'lead_to_contact', (select jsonb_build_object('avg_days', round(avg(extract(epoch from first_contact - created_at) / 86400)::numeric, 1), 'n', count(*)) from fc),
    'lead_to_claim', (select jsonb_build_object('avg_days', round(avg(extract(epoch from claimed_at - created_at) / 86400)::numeric, 1), 'n', count(*)) from lr where claimed_at is not null and claimed_at >= created_at),
    'claim_to_trial', (select jsonb_build_object('avg_days', round(avg(extract(epoch from started_at - claimed_at) / 86400)::numeric, 1), 'n', count(*)) from ct),
    'trial_to_paid', (select jsonb_build_object('avg_days', round(avg(extract(epoch from paid_at - started_at) / 86400)::numeric, 1), 'n', count(*)) from tp where paid_at >= started_at))
  into v_vel;

  return jsonb_build_object('consumer', v_consumer, 'return', v_ret, 'b2b', v_b2b, 'velocity', v_vel,
    'min_sample', public.growth_min_sample(), 'directions_as_conversion', v_dir,
    'definitions', jsonb_build_object(
      'unit', 'Sessioni con consenso "Statistiche" (le visite senza consenso non sono collegabili tra loro).',
      'intent', 'Indicazioni, chiamata, WhatsApp, piatto aperto, prenotazione iniziata, carrello/checkout, offerta vista, preferito, coupon richiesto.',
      'conversion', case when v_dir then 'Prenotazione inviata, ordine pagato, indicazioni o chiamata (impostazione attiva).' else 'Prenotazione inviata o ordine pagato.' end,
      'return', format('Utente registrato con una conversione che ha un giorno di attività nei %s giorni successivi.', v_win)));
end $$;

-- ────────────────────────────────────────────────────────────────────
--  4. RETENTION: D1/D7/D30 ("tornato entro N giorni"), coorti settimanali, retention ristoranti
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_retention(p_weeks int default 8)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_today date := (now() at time zone 'Europe/Rome')::date; v_d jsonb; v_coh jsonb; v_rest jsonb; v_weeks int := least(greatest(coalesce(p_weeks, 8), 1), 26);
begin
  perform public.growth_assert_admin();
  with u as (select p.id, (p.created_at at time zone 'Europe/Rome')::date d0 from public.profiles p
              where p.role::text = 'customer' and p.created_at > now() - interval '180 days')
  select jsonb_build_object(
    'd1', (select jsonb_build_object('eligible', count(*), 'returned', count(*) filter (where exists (select 1 from public.user_activity_days a where a.user_id = u.id and a.day = u.d0 + 1))) from u where u.d0 <= v_today - 1),
    'd7', (select jsonb_build_object('eligible', count(*), 'returned', count(*) filter (where exists (select 1 from public.user_activity_days a where a.user_id = u.id and a.day between u.d0 + 1 and u.d0 + 7))) from u where u.d0 <= v_today - 7),
    'd30', (select jsonb_build_object('eligible', count(*), 'returned', count(*) filter (where exists (select 1 from public.user_activity_days a where a.user_id = u.id and a.day between u.d0 + 1 and u.d0 + 30))) from u where u.d0 <= v_today - 30))
  into v_d;

  with w as (select generate_series(date_trunc('week', v_today::timestamp)::date - 7 * (v_weeks - 1), date_trunc('week', v_today::timestamp)::date, interval '7 days')::date ws),
  u as (select p.id, (p.created_at at time zone 'Europe/Rome')::date d0, date_trunc('week', (p.created_at at time zone 'Europe/Rome'))::date ws
          from public.profiles p where p.role::text = 'customer')
  select coalesce(jsonb_agg(jsonb_build_object('week', w.ws, 'size', (select count(*) from u where u.ws = w.ws),
    'weeks', (select jsonb_agg(case when w.ws + 7 * k > v_today then null
                                    else (select count(*) from u where u.ws = w.ws and exists (
                                            select 1 from public.user_activity_days a where a.user_id = u.id and a.day > u.d0
                                               and a.day between w.ws + 7 * k and w.ws + 7 * k + 6)) end order by k)
              from generate_series(0, 4) k)) order by w.ws desc), '[]'::jsonb)
  into v_coh from w;

  select jsonb_build_object(
    'trial_to_paid', (select jsonb_build_object('ended', count(*) filter (where ends_at <= now() or converted_at is not null), 'converted', count(*) filter (where converted_at is not null))
                        from public.billing_trials t join public.restaurants r on r.id = t.restaurant_id where public.growth_in_scope(r.is_demo)),
    'paid_m1_m2', (select jsonb_build_object('base', count(*) filter (where coalesce(s.ended_at, 'infinity') > s.paid_started_at + interval '30 days'),
                                             'retained', count(*) filter (where coalesce(s.ended_at, 'infinity') > s.paid_started_at + interval '60 days'))
                     from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
                    where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.paid_started_at < now() - interval '60 days'),
    'paid_m2_m3', (select jsonb_build_object('base', count(*) filter (where coalesce(s.ended_at, 'infinity') > s.paid_started_at + interval '60 days'),
                                             'retained', count(*) filter (where coalesce(s.ended_at, 'infinity') > s.paid_started_at + interval '90 days'))
                     from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
                    where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.paid_started_at < now() - interval '90 days'))
  into v_rest;

  return jsonb_build_object('users', v_d, 'cohorts', v_coh, 'restaurants', v_rest, 'min_sample', public.growth_min_sample(),
    'definitions', jsonb_build_object(
      'return', 'Un utente registrato "torna" se ha un giorno di attività (accesso all''app) dopo il giorno di registrazione.',
      'd1', 'Attivo il giorno successivo alla registrazione.', 'd7', 'Attivo almeno un giorno entro 7 giorni.', 'd30', 'Attivo almeno un giorno entro 30 giorni.',
      'cohort', 'Righe = settimana di registrazione (lunedì). Colonne = settimana 0…4: utenti attivi in quella settimana (esclusa la giornata di registrazione). Celle vuote = settimana non ancora conclusa.',
      'restaurant', 'Trial → pagante sulle prove concluse. M1→M2: abbonamenti paganti ancora attivi a 60 giorni tra quelli attivi a 30 giorni.'));
end $$;

-- ────────────────────────────────────────────────────────────────────
--  5. RISTORANTI: health score interno (non è la qualità del ristorante) e segnali di rischio
-- ────────────────────────────────────────────────────────────────────
-- Pesi documentati in docs/growth/METRICS.md. Componenti non applicabili (es. nessun ordine) sono esclusi
-- e il punteggio è rinormalizzato sui componenti disponibili. Specchio TS: shared/growth.ts → healthScore().
create or replace function public.growth_health_score(p_components jsonb)
returns jsonb language plpgsql immutable as $$
declare
  w jsonb := '{"completeness": 20, "recent_login": 15, "menu_updated": 10, "reservation_response": 10, "order_acceptance": 10, "offers": 10, "customer_actions": 15, "subscription": 10}';
  k text; v_sum numeric := 0; v_w numeric := 0; v numeric;
begin
  for k in select jsonb_object_keys(w) loop
    if p_components ? k and jsonb_typeof(p_components -> k) = 'number' then
      v := greatest(0, least(1, (p_components ->> k)::numeric));
      v_sum := v_sum + v * (w ->> k)::numeric;
      v_w := v_w + (w ->> k)::numeric;
    end if;
  end loop;
  if v_w = 0 then return jsonb_build_object('score', null, 'status', 'unknown'); end if;
  v := round(v_sum * 100 / v_w);
  return jsonb_build_object('score', v, 'status', case when v >= 70 then 'healthy' when v >= 40 then 'needs_attention' else 'at_risk' end);
end $$;

create or replace function public.growth_restaurant_health(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r public.restaurants; s public.subscriptions; v_comp jsonb := '{}'::jsonb; v_sig jsonb := '[]'::jsonb; v_h jsonb;
  v_last date; v_menu timestamptz; v_res_n int; v_res_ok int; v_ord_acc int; v_ord_rej int; v_act int; v_completion int; v_unanswered int;
  v_today date := (now() at time zone 'Europe/Rome')::date;
begin
  select * into r from public.restaurants where id = p_id;
  if not found then return null; end if;
  if r.owner_id is null then
    return jsonb_build_object('score', null, 'status', 'not_claimed', 'components', '{}'::jsonb, 'signals', '[]'::jsonb);
  end if;
  v_completion := coalesce((public.restaurant_completion(p_id) ->> 'score')::int, 0);
  v_comp := v_comp || jsonb_build_object('completeness', v_completion / 100.0);

  select max(a.day) into v_last from public.user_activity_days a
   where a.user_id = r.owner_id or a.user_id in (select user_id from public.restaurant_members where restaurant_id = p_id and status = 'active');
  v_comp := v_comp || jsonb_build_object('recent_login', case when v_last >= v_today - 7 then 1 when v_last >= v_today - 30 then 0.5 else 0 end);

  select max(updated_at) into v_menu from public.menu_items where restaurant_id = p_id;
  v_comp := v_comp || jsonb_build_object('menu_updated', case when v_menu is null then 0 when v_menu > now() - interval '60 days' then 1 when v_menu > now() - interval '180 days' then 0.5 else 0 end);

  -- Prenotazioni gestite: non lasciate "pending" oltre la data (ultimi 60 giorni)
  select count(*), count(*) filter (where status::text <> 'pending' or reservation_date >= v_today),
         count(*) filter (where status::text = 'pending' and reservation_date < v_today and reservation_date >= v_today - 30)
    into v_res_n, v_res_ok, v_unanswered from public.reservations where restaurant_id = p_id and created_at > now() - interval '60 days';
  if v_res_n > 0 then v_comp := v_comp || jsonb_build_object('reservation_response', v_res_ok::numeric / v_res_n); end if;

  select count(*) filter (where accepted_at is not null), count(*) filter (where rejected_at is not null)
    into v_ord_acc, v_ord_rej from public.orders where restaurant_id = p_id and created_at > now() - interval '60 days';
  if v_ord_acc + v_ord_rej > 0 then v_comp := v_comp || jsonb_build_object('order_acceptance', v_ord_acc::numeric / (v_ord_acc + v_ord_rej)); end if;

  v_comp := v_comp || jsonb_build_object('offers', case when exists (select 1 from public.offers where restaurant_id = p_id and is_active and (ends_at is null or ends_at > now()))
                                                     or exists (select 1 from public.coupons where restaurant_id = p_id and is_active and (valid_until is null or valid_until > now())) then 1 else 0 end);

  select coalesce(sum(calls + whatsapp + directions + bookings + orders + coupon_redemptions), 0) into v_act
    from public.daily_restaurant_metrics where restaurant_id = p_id and date > v_today - 30;
  v_comp := v_comp || jsonb_build_object('customer_actions', case when v_act >= 10 then 1 when v_act >= 1 then 0.5 else 0 end);

  select * into s from public.subscriptions x where x.restaurant_id = p_id and (x.source <> 'stripe' or public.subscription_in_env(x))
   order by (x.status in ('active', 'trialing', 'past_due')) desc, x.created_at desc limit 1;
  v_comp := v_comp || jsonb_build_object('subscription', case
    when s.id is null then 0.5
    when s.status in ('past_due', 'unpaid') then 0
    when s.cancel_at_period_end then 0.25
    when s.status = 'trialing' then 0.75
    when s.status = 'active' and s.paid_started_at is not null then 1
    else 0.5 end);

  -- Segnali di rischio (fatti verificabili, mai giudizi sul locale)
  if s.status = 'trialing' and s.trial_end between now() and now() + interval '7 days' then
    v_sig := v_sig || jsonb_build_object('key', 'trial_ending', 'label', format('Prova in scadenza il %s', to_char(s.trial_end at time zone 'Europe/Rome', 'DD/MM')));
  end if;
  if s.status in ('past_due', 'unpaid') then v_sig := v_sig || jsonb_build_object('key', 'payment_failed', 'label', 'Pagamento non riuscito'); end if;
  if v_last is null or v_last < v_today - 30 then
    v_sig := v_sig || jsonb_build_object('key', 'no_login_30d', 'label', case when v_last is null then 'Nessun accesso registrato' else format('Nessun accesso da %s giorni', v_today - v_last) end);
  end if;
  if v_completion < 60 then v_sig := v_sig || jsonb_build_object('key', 'profile_incomplete', 'label', format('Profilo completo al %s%%', v_completion)); end if;
  if v_act = 0 then v_sig := v_sig || jsonb_build_object('key', 'zero_actions', 'label', 'Nessuna azione dei clienti negli ultimi 30 giorni'); end if;
  if v_unanswered > 0 then v_sig := v_sig || jsonb_build_object('key', 'reservations_unanswered', 'label', format('%s prenotazioni rimaste senza risposta', v_unanswered)); end if;
  if v_ord_rej >= 3 and v_ord_rej::numeric / nullif(v_ord_acc + v_ord_rej, 0) >= 0.3 then
    v_sig := v_sig || jsonb_build_object('key', 'orders_rejected', 'label', format('%s ordini rifiutati su %s', v_ord_rej, v_ord_acc + v_ord_rej));
  end if;

  v_h := public.growth_health_score(v_comp);
  if v_sig @> '[{"key": "payment_failed"}]' then v_h := v_h || jsonb_build_object('status', 'at_risk'); end if;
  return v_h || jsonb_build_object('components', v_comp, 'signals', v_sig, 'last_login', v_last);
end $$;

create or replace function public.admin_growth_restaurants(p_from date, p_to date, p_market text default null, p_status text default null,
                                                           p_search text default null, p_limit int default 50, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_rows jsonb; v_total int;
begin
  perform public.growth_assert_admin();
  with base as (
    select r.id, r.name, r.slug, r.subscription_plan, r.owner_id is not null claimed, c.name city
      from public.restaurants r join public.cities c on c.id = r.city_id
     where r.id in (select public.growth_market_restaurants(nullif(p_market, '')))
       and r.is_active and (p_search is null or p_search = '' or r.name ilike '%' || p_search || '%')),
  m as (select d.restaurant_id rid, sum(views) views, sum(menu_views + item_views) menu_views, sum(directions) directions, sum(calls) calls, sum(whatsapp) whatsapp,
               sum(bookings) bookings, sum(orders) orders, sum(coupon_redemptions) coupon_redemptions, sum(reviews) reviews, sum(revenue_cents) revenue_cents,
               sum(impressions) impressions
          from public.daily_restaurant_metrics d where d.date between p_from and p_to group by 1),
  rep as (select restaurant_id rid, count(*) repeat_customers from (
            select restaurant_id, user_id from (
              select restaurant_id, user_id from public.reservations where user_id is not null and status::text not in ('rejected', 'cancelled')
                 and created_at >= p_from::timestamp at time zone 'Europe/Rome' - interval '90 days'
              union all select restaurant_id, user_id from public.orders where user_id is not null and payment_status in ('paid', 'partially_refunded')
                 and paid_at >= p_from::timestamp at time zone 'Europe/Rome' - interval '90 days') x
            group by 1, 2 having count(*) >= 2) y group by 1),
  rows as (
    select b.*, coalesce(m.views, 0) views, coalesce(m.menu_views, 0) menu_views, coalesce(m.directions, 0) directions, coalesce(m.calls, 0) calls,
           coalesce(m.whatsapp, 0) whatsapp, coalesce(m.bookings, 0) bookings, coalesce(m.orders, 0) orders, coalesce(m.coupon_redemptions, 0) coupon_redemptions,
           coalesce(m.reviews, 0) reviews, coalesce(m.revenue_cents, 0) revenue_cents, coalesce(m.impressions, 0) impressions, coalesce(rep.repeat_customers, 0) repeat_customers,
           public.growth_restaurant_health(b.id) health
      from base b left join m on m.rid = b.id left join rep on rep.rid = b.id),
  filtered as (select * from rows where p_status is null or p_status = '' or health ->> 'status' = p_status)
  select (select count(*) from filtered),
         coalesce((select jsonb_agg(to_jsonb(f) || jsonb_build_object(
              'conversion_actions', f.directions + f.calls + f.whatsapp + f.bookings + f.orders + f.coupon_redemptions,
              'conversion_rate', case when f.views > 0 then round((f.directions + f.calls + f.whatsapp + f.bookings + f.orders + f.coupon_redemptions) * 100.0 / f.views, 1) end)
            order by (f.health ->> 'status' = 'at_risk') desc, f.views desc, f.name)
           from (select * from filtered order by (health ->> 'status' = 'at_risk') desc, views desc, name limit least(coalesce(p_limit, 50), 200) offset greatest(coalesce(p_offset, 0), 0)) f), '[]'::jsonb)
    into v_total, v_rows;
  return jsonb_build_object('total', v_total, 'rows', v_rows,
    'definitions', jsonb_build_object('conversion', 'Azioni di conversione (indicazioni + chiamate + WhatsApp + prenotazioni + ordini + coupon utilizzati) / visualizzazioni della scheda.',
      'health', 'Punteggio interno 0–100 di salute commerciale del rapporto (completezza, accessi, menu, gestione prenotazioni/ordini, offerte, azioni clienti, abbonamento). Non è un giudizio sulla qualità del ristorante.'));
end $$;

-- ────────────────────────────────────────────────────────────────────
--  6. CHURN E MRR
-- ────────────────────────────────────────────────────────────────────
create or replace function public.growth_mrr_movements(p_from date, p_to date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_from timestamptz := p_from::timestamp at time zone 'Europe/Rome'; v_to timestamptz := (p_to + 1)::timestamp at time zone 'Europe/Rome';
  v_new numeric; v_churn numeric; v_exp numeric; v_con numeric; v_obs boolean;
begin
  select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) into v_new from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
   where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.paid_started_at >= v_from and s.paid_started_at < v_to;
  select coalesce(round(sum(public.subscription_mrr_cents(s))), 0) into v_churn from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
   where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.paid_started_at is not null and s.ended_at >= v_from and s.ended_at < v_to;
  -- Espansione/contrazione: solo da fotografie MRR osservate (inizio e fine periodo), mai ricostruite
  v_obs := coalesce((select mrr_observed from public.growth_computed_days where day = p_from - 1), false)
       and coalesce((select mrr_observed from public.growth_computed_days where day = p_to), false);
  if v_obs then
    with a as (select restaurant_id, mrr_cents from public.daily_restaurant_metrics where date = p_from - 1 and mrr_cents > 0),
         b as (select restaurant_id, mrr_cents from public.daily_restaurant_metrics where date = p_to and mrr_cents > 0)
    select coalesce(sum(greatest(b.mrr_cents - a.mrr_cents, 0)), 0), coalesce(sum(greatest(a.mrr_cents - b.mrr_cents, 0)), 0)
      into v_exp, v_con from a join b on a.restaurant_id = b.restaurant_id;
  end if;
  return jsonb_build_object('new_mrr_cents', v_new, 'churned_mrr_cents', v_churn,
    'expansion_mrr_cents', case when v_obs then v_exp end, 'contraction_mrr_cents', case when v_obs then v_con end,
    'expansion_available', v_obs,
    'note', case when not v_obs then 'Espansione/contrazione richiedono la fotografia MRR osservata al giorno prima dell''inizio e alla fine del periodo (disponibile dai giorni aggregati in tempo reale).' end);
end $$;

create or replace function public.admin_growth_churn(p_from date, p_to date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_from timestamptz := p_from::timestamp at time zone 'Europe/Rome'; v_to timestamptz := (p_to + 1)::timestamp at time zone 'Europe/Rome';
  v_base int; v_lost int;
begin
  perform public.growth_assert_admin();
  -- Base paganti a inizio periodo e persi durante il periodo (stessa base: nessun gonfiaggio)
  select count(distinct s.restaurant_id), count(distinct s.restaurant_id) filter (where s.ended_at >= v_from and s.ended_at < v_to)
    into v_base, v_lost
    from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
   where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo)
     and s.paid_started_at < v_from and coalesce(s.ended_at, 'infinity') >= v_from;
  return jsonb_build_object(
    'churn', jsonb_build_object('base', v_base, 'lost', v_lost, 'rate', case when v_base > 0 then round(v_lost * 100.0 / v_base, 1) end),
    'mrr', public.growth_mrr_movements(p_from, p_to),
    'lists', jsonb_build_object(
      'cancelled', coalesce((select jsonb_agg(jsonb_build_object('restaurant_id', r.id, 'name', r.name, 'plan', s.plan_code, 'ended_at', s.ended_at,
                              'mrr_cents', round(public.subscription_mrr_cents(s))) order by s.ended_at desc)
                              from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
                             where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.paid_started_at is not null and s.ended_at >= v_from and s.ended_at < v_to), '[]'::jsonb),
      'cancel_scheduled', coalesce((select jsonb_agg(jsonb_build_object('restaurant_id', r.id, 'name', r.name, 'plan', s.plan_code, 'until', s.current_period_end,
                              'mrr_cents', round(public.subscription_mrr_cents(s))) order by s.current_period_end)
                              from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
                             where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.cancel_at_period_end and s.status in ('active', 'trialing', 'past_due')), '[]'::jsonb),
      'past_due', coalesce((select jsonb_agg(jsonb_build_object('restaurant_id', r.id, 'name', r.name, 'plan', s.plan_code, 'since', s.payment_failed_at,
                              'mrr_cents', round(public.subscription_mrr_cents(s))))
                              from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
                             where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.status in ('past_due', 'unpaid')), '[]'::jsonb),
      'inactive_trials', coalesce((select jsonb_agg(jsonb_build_object('restaurant_id', r.id, 'name', r.name, 'trial_end', s.trial_end,
                              'last_login', (select max(a.day) from public.user_activity_days a where a.user_id = r.owner_id)))
                              from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
                             where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.status = 'trialing' and public.subscription_grants_access(s)
                               and not exists (select 1 from public.user_activity_days a where a.user_id = r.owner_id and a.day > (now() at time zone 'Europe/Rome')::date - 7)), '[]'::jsonb),
      'at_risk', coalesce((select jsonb_agg(jsonb_build_object('restaurant_id', x.id, 'name', x.name, 'health', x.h))
                             from (select r.id, r.name, public.growth_restaurant_health(r.id) h from public.restaurants r
                                    where public.growth_in_scope(r.is_demo) and r.owner_id is not null and exists (
                                      select 1 from public.subscriptions s where s.restaurant_id = r.id and s.status in ('active', 'trialing', 'past_due')
                                         and public.subscription_in_env(s))) x
                            where x.h ->> 'status' = 'at_risk'), '[]'::jsonb)),
    'reasons', coalesce((select jsonb_agg(jsonb_build_object('reason', reason, 'count', c) order by c desc)
                           from (select public.growth_churn_reason(reason) reason, count(*) c from public.product_feedback
                                  where type = 'cancellation' and created_at >= v_from and created_at < v_to group by 1) t), '[]'::jsonb),
    'definitions', jsonb_build_object('churn_rate', 'Ristoranti paganti persi nel periodo / ristoranti paganti all''inizio del periodo.',
      'reasons', 'Motivo facoltativo indicato alla disdetta (mai obbligatorio). "unknown" = nessun motivo indicato.'));
end $$;

create or replace function public.admin_growth_revenue(p_from date, p_to date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_mrr numeric; v_paying int; v_tot jsonb; v_months int; v_churn_rate numeric; v_sponsor numeric; v_base int; v_lost int;
begin
  perform public.growth_assert_admin();
  select coalesce(round(sum(public.subscription_mrr_cents(s))), 0), count(distinct s.restaurant_id) into v_mrr, v_paying
    from public.subscriptions s join public.restaurants r on r.id = s.restaurant_id
   where public.subscription_in_env(s) and public.growth_in_scope(r.is_demo) and s.paid_started_at is not null and s.status in ('active', 'past_due') and public.subscription_grants_access(s);
  v_tot := public.growth_period_totals(p_from, p_to, null);
  select coalesce(round(sum(c.spend) * 100), 0) into v_sponsor from public.sponsored_campaigns c join public.restaurants r on r.id = c.restaurant_id
   where public.growth_in_scope(r.is_demo) and c.start_date <= p_to and (c.end_date is null or c.end_date >= p_from);
  -- LTV solo con storico sufficiente: ≥ 3 mesi di abbonamenti paganti, base ≥ campione minimo e churn osservato > 0
  select count(distinct date_trunc('month', s.paid_started_at)) into v_months from public.subscriptions s where public.subscription_in_env(s) and s.paid_started_at is not null;
  select count(distinct s.restaurant_id), count(distinct s.restaurant_id) filter (where s.ended_at > now() - interval '90 days')
    into v_base, v_lost from public.subscriptions s where public.subscription_in_env(s) and s.paid_started_at < now() - interval '90 days'
     and coalesce(s.ended_at, 'infinity') > now() - interval '90 days';
  v_churn_rate := case when v_base >= public.growth_min_sample() and v_lost > 0 then v_lost::numeric / v_base / 3 end;   -- mensile medio su 90 giorni
  return jsonb_build_object(
    'mrr_cents', v_mrr, 'arr_cents', v_mrr * 12, 'paying_restaurants', v_paying,
    'arpa_cents', case when v_paying > 0 then round(v_mrr / v_paying) end,
    'movements', public.growth_mrr_movements(p_from, p_to),
    'sources', jsonb_build_array(
      jsonb_build_object('key', 'subscriptions', 'label', 'Abbonamenti (fatture pagate)', 'cents', (v_tot ->> 'subscription_revenue_cents')::bigint),
      jsonb_build_object('key', 'orders', 'label', 'Commissioni e costi di servizio ordini', 'cents', (v_tot ->> 'order_fees_cents')::bigint),
      jsonb_build_object('key', 'ads', 'label', 'Sponsorizzazioni (spesa registrata delle campagne attive nel periodo, cumulativa)', 'cents', v_sponsor),
      jsonb_build_object('key', 'other', 'label', 'Altro', 'cents', 0)),
    'gmv_cents', (v_tot ->> 'gmv_cents')::bigint,
    'ltv_cents', case when v_months >= 3 and v_churn_rate is not null and v_paying > 0 then round((v_mrr / v_paying) / v_churn_rate) end,
    'ltv_reason', case when v_months < 3 then 'Dati insufficienti: servono almeno 3 mesi di abbonamenti paganti.'
                       when v_churn_rate is null then format('Dati insufficienti: base paganti < %s o nessuna disdetta osservata (il churn non è stimabile).', public.growth_min_sample()) end,
    'mrr_series', coalesce((select jsonb_agg(jsonb_build_object('date', date, 'mrr_cents', mrr_cents) order by date)
                              from public.daily_platform_metrics where date between p_from and p_to), '[]'::jsonb),
    'complete', (v_tot ->> 'complete')::boolean,
    'definitions', jsonb_build_object('arpa', 'MRR / ristoranti paganti (solo paganti).', 'ltv', 'ARPA / churn mensile medio (ultimi 90 giorni), solo con storico sufficiente.',
      'mrr', 'Somma dei canoni mensili degli abbonamenti Stripe attivi (annuali /12), ambiente Stripe in uso.'));
end $$;

-- ────────────────────────────────────────────────────────────────────
--  7. ACQUISIZIONE (first touch, last touch, costi, CAC solo con dati affidabili)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_acquisition(p_from date, p_to date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_from timestamptz := p_from::timestamp at time zone 'Europe/Rome'; v_to timestamptz := (p_to + 1)::timestamp at time zone 'Europe/Rome';
  v_min int := public.billing_setting_int('cac_min_conversions', 5);
begin
  perform public.growth_assert_admin();
  return jsonb_build_object(
    'channels', coalesce((
      with ch as (select channel, sum(visits) visits, sum(signups) signups from public.daily_acquisition_metrics where date between p_from and p_to group by 1),
      users as (select ua.user_id, public.growth_channel(ua.channel, ua.utm_source) ch from public.user_acquisition ua join public.profiles p on p.id = ua.user_id
                 where p.created_at >= v_from and p.created_at < v_to),
      act as (select u.ch,
                count(distinct u.user_id) filter (where exists (select 1 from public.reservations x where x.user_id = u.user_id and x.status::text <> 'rejected')
                                                  or exists (select 1 from public.orders o where o.user_id = u.user_id and o.payment_status in ('paid', 'partially_refunded'))
                                                  or exists (select 1 from public.coupon_claims c where c.user_id = u.user_id)) activated,
                (select count(*) from public.reservations x where x.user_id in (select user_id from users u2 where u2.ch = u.ch) and x.created_at >= v_from and x.created_at < v_to and x.status::text <> 'rejected') reservations,
                (select count(*) from public.orders o where o.user_id in (select user_id from users u2 where u2.ch = u.ch) and o.paid_at >= v_from and o.paid_at < v_to and o.payment_status in ('paid', 'partially_refunded')) orders
              from users u group by u.ch),
      paying as (select public.growth_channel(ua.channel, ua.utm_source) ch, count(distinct r.id) n
                   from public.restaurants r join public.user_acquisition ua on ua.user_id = r.owner_id
                  where exists (select 1 from public.subscriptions s where s.restaurant_id = r.id and public.subscription_in_env(s) and s.paid_started_at is not null) group by 1),
      -- Il canale del costo è testo libero: se è già un canale di business lo si usa, altrimenti si classifica come canale tecnico
      cost as (select case when lower(coalesce(channel, '')) in ('organic_google', 'direct', 'instagram', 'facebook', 'tiktok', 'restaurant_qr', 'referral', 'creator',
                                                                   'paid_social', 'partner', 'email', 'other_social', 'other')
                           then lower(channel) else public.growth_channel(lower(coalesce(channel, 'other')), lower(coalesce(channel, ''))) end ch, sum(amount_cents) cents
                 from public.acquisition_costs where spent_on between p_from and p_to group by 1),
      keys as (select channel k from ch union select ch from act union select ch from cost union select ch from paying)
      select jsonb_agg(jsonb_build_object('channel', k.k, 'visits', coalesce(ch.visits, 0), 'signups', coalesce(ch.signups, 0), 'activated', coalesce(act.activated, 0),
               'reservations', coalesce(act.reservations, 0), 'orders', coalesce(act.orders, 0), 'paying_restaurants', coalesce(paying.n, 0),
               'cost_cents', cost.cents,
               'cac_cents', case when coalesce(cost.cents, 0) > 0 and coalesce(ch.signups, 0) >= v_min then round(cost.cents::numeric / ch.signups) end,
               'cac_reason', case when coalesce(cost.cents, 0) = 0 then 'N/A: nessun costo registrato' when coalesce(ch.signups, 0) < v_min then format('N/A: meno di %s iscrizioni attribuite', v_min) end)
             order by coalesce(ch.visits, 0) desc)
        from keys k left join ch on ch.channel = k.k left join act on act.ch = k.k left join cost on cost.ch = k.k left join paying on paying.ch = k.k), '[]'::jsonb),
    'campaigns', coalesce((select jsonb_agg(to_jsonb(t) order by t.visits desc) from (
        select utm_source, utm_campaign, sum(visits) visits, sum(signups) signups from public.daily_acquisition_metrics
         where date between p_from and p_to and (utm_source <> '' or utm_campaign <> '') group by 1, 2 order by 3 desc limit 30) t), '[]'::jsonb),
    'last_touch', coalesce((select jsonb_agg(jsonb_build_object('channel', ch, 'signups', n) order by n desc) from (
        select public.growth_channel(coalesce(ua.last_channel, ua.channel), coalesce(ua.last_utm_source, ua.utm_source)) ch, count(*) n
          from public.user_acquisition ua join public.profiles p on p.id = ua.user_id where p.created_at >= v_from and p.created_at < v_to group by 1) t), '[]'::jsonb),
    'coverage', jsonb_build_object('signups_total', (select count(*) from public.profiles where role::text = 'customer' and created_at >= v_from and created_at < v_to),
                                   'signups_attributed', (select count(*) from public.user_acquisition ua join public.profiles p on p.id = ua.user_id where p.created_at >= v_from and p.created_at < v_to)),
    'definitions', jsonb_build_object('model', 'First touch = primo canale noto del browser (con consenso) · Last touch = canale della sessione di iscrizione. Nessun modello multi-touch.',
      'cac', format('Costo registrato del canale / iscrizioni attribuite, solo con almeno %s iscrizioni e costi reali inseriti.', v_min),
      'activated', 'Utenti iscritti nel periodo con almeno una prenotazione, un ordine pagato o un coupon richiesto.'));
end $$;

-- ────────────────────────────────────────────────────────────────────
--  8. RICERCA, ZERO RISULTATI, SUPPLY GAP
-- ────────────────────────────────────────────────────────────────────
-- Search demand score (0–100), trasparente: volume (40) + quota senza risultati (30) + ripetizione (15) + gap di conversione (15)
create or replace function public.growth_search_demand_score(p_searches bigint, p_max bigint, p_zero_share numeric, p_repeat_share numeric, p_conv_gap numeric)
returns int language sql immutable as $$
  select least(100, round(
      40 * (ln(1 + greatest(p_searches, 0)) / nullif(ln(1 + greatest(p_max, 1)), 0))
    + 30 * coalesce(p_zero_share, 0)
    + 15 * coalesce(p_repeat_share, 0)
    + 15 * coalesce(p_conv_gap, 0)))::int;
$$;

create or replace function public.growth_supply_gap(p_from date, p_to date, p_market text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_min int := public.billing_setting_int('growth_supply_gap_min_searches', 5); v_prov uuid; v_max bigint;
begin
  if nullif(p_market, '') is not null then select province_id into v_prov from public.markets where slug = p_market; end if;
  with agg as (
    select d.city_slug, d.category_slug, case when d.category_slug = '' then d.query_norm else '' end term,
           sum(d.searches) searches, sum(d.zero_results) zero, sum(d.ai_searches) ai
      from public.daily_search_metrics d
      left join public.cities c on c.slug = d.city_slug
     where d.date between p_from and p_to and d.city_slug <> '' and (d.category_slug <> '' or d.query_norm <> '')
       and (v_prov is null or c.province_id = v_prov)
     group by 1, 2, 3 having sum(d.searches) >= v_min),
  sup as (select a.*, (select count(*) from public.restaurants r join public.cities c on c.id = r.city_id
                        where c.slug = a.city_slug and r.is_active and public.growth_in_scope(r.is_demo) and not r.is_permanently_closed
                          and (a.category_slug = '' or exists (select 1 from public.restaurant_categories rc join public.categories cat on cat.id = rc.category_id
                                                                 where rc.restaurant_id = r.id and cat.slug = a.category_slug)
                               or (a.category_slug = 'all-you-can-eat' and r.is_all_you_can_eat))) supply
            from agg a)
  select max(searches) into v_max from agg;
  return coalesce((select jsonb_agg(jsonb_build_object('city_slug', s.city_slug, 'city', (select name from public.cities where slug = s.city_slug),
      'category_slug', nullif(s.category_slug, ''), 'category', (select name from public.categories where slug = s.category_slug), 'term', nullif(s.term, ''),
      'searches', s.searches, 'zero_results', s.zero, 'ai_searches', s.ai, 'supply', s.supply,
      'zero_pct', round(s.zero * 100.0 / s.searches),
      'score', least(100, round(40 * ln(1 + s.searches) / nullif(ln(1 + v_max), 0) + 40 * s.zero::numeric / s.searches
                             + 20 * case when s.supply = 0 then 1 when s.supply < 3 then 0.5 else 0 end)),
      'breakdown', jsonb_build_object('demand', round(40 * ln(1 + s.searches) / nullif(ln(1 + v_max), 0)), 'zero_results', round(40 * s.zero::numeric / s.searches),
                                      'low_supply', 20 * case when s.supply = 0 then 1 when s.supply < 3 then 0.5 else 0 end))
      order by s.zero desc, s.searches desc)
    from (with agg as (
            select d.city_slug, d.category_slug, case when d.category_slug = '' then d.query_norm else '' end term,
                   sum(d.searches) searches, sum(d.zero_results) zero, sum(d.ai_searches) ai
              from public.daily_search_metrics d left join public.cities c on c.slug = d.city_slug
             where d.date between p_from and p_to and d.city_slug <> '' and (d.category_slug <> '' or d.query_norm <> '')
               and (v_prov is null or c.province_id = v_prov)
             group by 1, 2, 3 having sum(d.searches) >= v_min)
          select a.*, (select count(*) from public.restaurants r join public.cities c on c.id = r.city_id
                        where c.slug = a.city_slug and r.is_active and public.growth_in_scope(r.is_demo) and not r.is_permanently_closed
                          and (a.category_slug = '' or exists (select 1 from public.restaurant_categories rc join public.categories cat on cat.id = rc.category_id
                                                                 where rc.restaurant_id = r.id and cat.slug = a.category_slug)
                               or (a.category_slug = 'all-you-can-eat' and r.is_all_you_can_eat))) supply
            from agg a) s), '[]'::jsonb);
end $$;

create or replace function public.admin_growth_search(p_from date, p_to date, p_market text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_from timestamptz := p_from::timestamp at time zone 'Europe/Rome'; v_to timestamptz := (p_to + 1)::timestamp at time zone 'Europe/Rome';
  v_prov uuid; v_top jsonb; v_max bigint; v_conv jsonb;
begin
  perform public.growth_assert_admin();
  if nullif(p_market, '') is not null then select province_id into v_prov from public.markets where slug = p_market; end if;
  select max(t.searches) into v_max from (select sum(searches) searches from public.daily_search_metrics d left join public.cities c on c.slug = d.city_slug
     where d.date between p_from and p_to and (v_prov is null or c.province_id = v_prov) group by d.query_norm, d.city_slug, d.category_slug) t;

  -- Ricerche "convertite": nella stessa sessione (con consenso) segue una scheda ristorante entro 30 minuti
  with s as (select se.id, se.session_id, se.created_at, coalesce(se.query_norm, '') q, coalesce(se.city_slug, '') city, coalesce(se.category_slug, '') cat
               from public.search_events se left join public.cities c on c.slug = se.city_slug
              where se.created_at >= v_from and se.created_at < v_to and se.session_id is not null and (v_prov is null or c.province_id = v_prov)),
  sc as (select s.*, exists (select 1 from public.analytics_events e where e.session_id = s.session_id and e.event_type in ('restaurant_view', 'view')
                               and e.created_at between s.created_at and s.created_at + interval '30 minutes') converted from s),
  combo as (select q, city, cat, count(*) n, count(*) filter (where converted) conv, count(distinct session_id) sess,
                   count(distinct session_id) filter (where session_id in (select session_id from s s2 where s2.q = sc.q and s2.city = sc.city and s2.cat = sc.cat group by session_id having count(*) > 1)) rep
              from sc group by 1, 2, 3)
  select jsonb_build_object('with_session', (select count(*) from sc), 'converted', (select count(*) from sc where converted),
    'combos', coalesce((select jsonb_object_agg(q || '|' || city || '|' || cat, jsonb_build_object('n', n, 'conv', conv, 'sess', sess, 'rep', rep)) from combo), '{}'::jsonb))
  into v_conv;

  select coalesce(jsonb_agg(jsonb_build_object('query', nullif(t.query_norm, ''), 'city_slug', nullif(t.city_slug, ''), 'category_slug', nullif(t.category_slug, ''),
      'city', (select name from public.cities where slug = t.city_slug), 'category', (select name from public.categories where slug = t.category_slug),
      'searches', t.searches, 'zero_results', t.zero, 'sessions', t.sessions, 'ai_searches', t.ai,
      'converted', (v_conv -> 'combos' -> (t.query_norm || '|' || t.city_slug || '|' || t.category_slug) ->> 'conv')::int,
      'with_session', (v_conv -> 'combos' -> (t.query_norm || '|' || t.city_slug || '|' || t.category_slug) ->> 'n')::int,
      'demand_score', public.growth_search_demand_score(t.searches, v_max, t.zero::numeric / nullif(t.searches, 0),
          (v_conv -> 'combos' -> (t.query_norm || '|' || t.city_slug || '|' || t.category_slug) ->> 'rep')::numeric
            / nullif((v_conv -> 'combos' -> (t.query_norm || '|' || t.city_slug || '|' || t.category_slug) ->> 'sess')::numeric, 0),
          1 - (v_conv -> 'combos' -> (t.query_norm || '|' || t.city_slug || '|' || t.category_slug) ->> 'conv')::numeric
            / nullif((v_conv -> 'combos' -> (t.query_norm || '|' || t.city_slug || '|' || t.category_slug) ->> 'n')::numeric, 0)))
      order by t.searches desc), '[]'::jsonb)
    into v_top
    from (select d.query_norm, d.city_slug, d.category_slug, sum(d.searches) searches, sum(d.zero_results) zero, sum(d.sessions) sessions, sum(d.ai_searches) ai
            from public.daily_search_metrics d left join public.cities c on c.slug = d.city_slug
           where d.date between p_from and p_to and (v_prov is null or c.province_id = v_prov)
           group by 1, 2, 3 order by 4 desc limit 50) t;

  return jsonb_build_object(
    'totals', (select jsonb_build_object('searches', coalesce(sum(searches), 0), 'zero_results', coalesce(sum(zero_results), 0), 'ai_searches', coalesce(sum(ai_searches), 0))
                 from public.daily_search_metrics d left join public.cities c on c.slug = d.city_slug where d.date between p_from and p_to and (v_prov is null or c.province_id = v_prov)),
    'top', v_top,
    'zero_results', coalesce((select jsonb_agg(x order by (x ->> 'zero_results')::int desc) from jsonb_array_elements(v_top) x where (x ->> 'zero_results')::int > 0), '[]'::jsonb),
    'categories', coalesce((select jsonb_agg(jsonb_build_object('slug', t.category_slug, 'name', (select name from public.categories where slug = t.category_slug), 'searches', t.n, 'zero_results', t.z) order by t.n desc)
                   from (select category_slug, sum(searches) n, sum(zero_results) z from public.daily_search_metrics d left join public.cities c on c.slug = d.city_slug
                          where d.date between p_from and p_to and d.category_slug <> '' and (v_prov is null or c.province_id = v_prov) group by 1) t), '[]'::jsonb),
    'cities', coalesce((select jsonb_agg(jsonb_build_object('slug', t.city_slug, 'name', (select name from public.cities where slug = t.city_slug), 'searches', t.n, 'zero_results', t.z) order by t.n desc)
                   from (select city_slug, sum(searches) n, sum(zero_results) z from public.daily_search_metrics d left join public.cities c on c.slug = d.city_slug
                          where d.date between p_from and p_to and d.city_slug <> '' and (v_prov is null or c.province_id = v_prov) group by 1) t), '[]'::jsonb),
    'conversion', jsonb_build_object('with_session', (v_conv ->> 'with_session')::int, 'converted', (v_conv ->> 'converted')::int),
    'supply_gap', public.growth_supply_gap(p_from, p_to, p_market),
    'min_sample', public.growth_min_sample(),
    'definitions', jsonb_build_object(
      'zero_result', 'Ricerca con 0 risultati mostrati all''utente (Esplora) o 0 ristoranti proposti dall''assistente AI.',
      'converted', 'Ricerca seguita, nella stessa sessione con consenso, dall''apertura di una scheda ristorante entro 30 minuti.',
      'demand_score', 'Punteggio 0–100 = volume (40, logaritmico) + quota senza risultati (30) + sessioni che ripetono la ricerca (15) + ricerche non seguite da una scheda (15).',
      'supply_gap', 'Combinazioni comune/categoria (o termine) con almeno growth_supply_gap_min_searches ricerche. Punteggio = domanda (40) + quota senza risultati (40) + offerta scarsa (20).',
      'privacy', 'Testo normalizzato; ricerche con email, numeri lunghi o link non vengono salvate. Nessun utente associato.'));
end $$;

-- ────────────────────────────────────────────────────────────────────
--  9. OFFERTE, MENU, AI, REFERRAL, LOYALTY, RECENSIONI
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_engagement(p_from date, p_to date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_from timestamptz := p_from::timestamp at time zone 'Europe/Rome'; v_to timestamptz := (p_to + 1)::timestamp at time zone 'Europe/Rome';
  v_min int := public.growth_min_sample(); v_win int := public.billing_setting_int('growth_return_window_days', 30);
  v_ai jsonb; v_ai_conv bigint; v_ai_cost numeric; v_reg bigint; v_users bigint;
begin
  perform public.growth_assert_admin();
  select count(*) filter (where status in ('ok', 'fallback', 'cached')), coalesce(sum(estimated_cost), 0) into v_users, v_ai_cost
    from public.ai_usage where created_at >= v_from and created_at < v_to;
  v_ai_conv := (select count(*) from public.reservations where source::text = 'ai' and created_at >= v_from and created_at < v_to)
             + (select count(*) from public.orders where source = 'ai' and paid_at >= v_from and paid_at < v_to and payment_status in ('paid', 'partially_refunded'));
  v_ai := jsonb_build_object(
    'queries', v_users,
    'errors', (select count(*) from public.ai_usage where created_at >= v_from and created_at < v_to and status = 'error'),
    'intents', coalesce((select jsonb_agg(jsonb_build_object('intent', intent, 'count', n) order by n desc) from (
        select coalesce(intent, 'sconosciuto') intent, count(*) n from public.ai_usage where created_at >= v_from and created_at < v_to and status in ('ok', 'fallback', 'cached') group by 1) t), '[]'::jsonb),
    'result_clicks', (select count(*) from public.analytics_events where event_type = 'ai_result_click' and created_at >= v_from and created_at < v_to),
    'map_opens', (select count(*) from public.analytics_events where event_type = 'ai_map_open' and created_at >= v_from and created_at < v_to),
    'reservation_clicks', (select count(*) from public.analytics_events where event_type = 'ai_reservation_click' and created_at >= v_from and created_at < v_to),
    'bookings', (select count(*) from public.reservations where source::text = 'ai' and created_at >= v_from and created_at < v_to),
    'orders', (select count(*) from public.orders where source = 'ai' and paid_at >= v_from and paid_at < v_to and payment_status in ('paid', 'partially_refunded')),
    'no_results', (select count(*) from public.ai_usage where no_results and created_at >= v_from and created_at < v_to),
    'no_result_top', coalesce((select jsonb_agg(jsonb_build_object('city', search_city, 'category', search_category, 'term', search_term, 'count', n) order by n desc) from (
        select search_city, search_category, search_term, count(*) n from public.ai_usage where no_results and created_at >= v_from and created_at < v_to
           and coalesce(search_city, search_category, search_term) is not null group by 1, 2, 3 order by 4 desc limit 15) t), '[]'::jsonb),
    'cost_cents', round(v_ai_cost * 100, 2),
    'cost_per_assisted_conversion_cents', case when v_ai_conv > 0 then round(v_ai_cost * 100 / v_ai_conv, 2) end,
    'note', 'Conversioni "assistite": prenotazioni/ordini con origine AI. Non è un ROI: l''attribuzione non esclude che l''utente avrebbe convertito comunque.');

  select count(*) into v_reg from public.referrals where registered_at >= v_from and registered_at < v_to;
  select count(*) into v_users from public.profiles where role::text = 'customer' and created_at >= v_from and created_at < v_to;

  return jsonb_build_object(
    'offers', jsonb_build_object(
      'views', (select count(*) from public.analytics_events where event_type in ('offer_view', 'coupon_reveal') and created_at >= v_from and created_at < v_to),
      'coupons', coalesce((select jsonb_agg(to_jsonb(t) order by t.redemptions desc, t.claims desc) from (
          select c.id, c.title, r.name restaurant, c.discount_type::text discount_type,
                 count(cc.id) filter (where cc.claimed_at >= v_from and cc.claimed_at < v_to) claims,
                 count(cc.id) filter (where cc.status::text = 'redeemed' and cc.redeemed_at >= v_from and cc.redeemed_at < v_to) redemptions,
                 (select count(*) from public.orders o where o.coupon_id = c.id and o.paid_at >= v_from and o.paid_at < v_to and o.payment_status in ('paid', 'partially_refunded')) orders
            from public.coupons c join public.restaurants r on r.id = c.restaurant_id left join public.coupon_claims cc on cc.coupon_id = c.id
           where public.growth_in_scope(r.is_demo) group by c.id, c.title, r.name, c.discount_type
          having count(cc.id) filter (where cc.claimed_at >= v_from and cc.claimed_at < v_to) > 0
              or count(cc.id) filter (where cc.redeemed_at >= v_from and cc.redeemed_at < v_to) > 0 limit 50) t), '[]'::jsonb),
      'by_type', coalesce((select jsonb_agg(to_jsonb(t) order by t.claims desc) from (
          select c.discount_type::text discount_type, count(cc.id) claims, count(cc.id) filter (where cc.status::text = 'redeemed') redemptions
            from public.coupon_claims cc join public.coupons c on c.id = cc.coupon_id join public.restaurants r on r.id = c.restaurant_id
           where public.growth_in_scope(r.is_demo) and cc.claimed_at >= v_from and cc.claimed_at < v_to group by 1 having count(cc.id) >= v_min) t), '[]'::jsonb)),
    'menu', jsonb_build_object(
      'items', coalesce((select jsonb_agg(to_jsonb(t) order by t.views desc) from (
          select mi.id, mi.name, r.name restaurant, v.views, coalesce(ac.n, 0) add_to_cart, coalesce(od.qty, 0) ordered,
                 case when v.views >= v_min then round(coalesce(od.qty, 0) * 100.0 / v.views, 1) end order_rate
            from (select (metadata ->> 'item') item, count(*) views from public.analytics_events
                   where event_type = 'menu_item_view' and created_at >= v_from and created_at < v_to and metadata ->> 'item' ~ '^[0-9a-f-]{36}$' group by 1) v
            join public.menu_items mi on mi.id = v.item::uuid join public.restaurants r on r.id = mi.restaurant_id
            left join (select (metadata ->> 'item') item, count(*) n from public.analytics_events where event_type = 'add_to_cart' and created_at >= v_from and created_at < v_to group by 1) ac on ac.item = v.item
            left join (select oi.menu_item_id, sum(oi.quantity) qty from public.order_items oi join public.orders o on o.id = oi.order_id
                        where o.paid_at >= v_from and o.paid_at < v_to and o.payment_status in ('paid', 'partially_refunded') group by 1) od on od.menu_item_id = mi.id
           where public.growth_in_scope(r.is_demo) order by v.views desc limit 30) t), '[]'::jsonb),
      'searched_terms', coalesce((select jsonb_agg(jsonb_build_object('term', query_norm, 'searches', n, 'zero_results', z) order by n desc) from (
          select query_norm, sum(searches) n, sum(zero_results) z from public.daily_search_metrics where date between p_from and p_to and query_norm <> '' and category_slug = ''
           group by 1 order by 2 desc limit 20) t), '[]'::jsonb)),
    'ai', v_ai,
    'referral', jsonb_build_object(
      'shared', (select count(*) from public.app_events where event_type = 'referral_shared' and created_at >= v_from and created_at < v_to),
      'registered', v_reg,
      'qualified', (select count(*) from public.referrals where qualified_at >= v_from and qualified_at < v_to),
      'points_issued', (select coalesce(sum(points), 0) from public.loyalty_transactions where type = 'referral' and points > 0 and created_at >= v_from and created_at < v_to),
      'point_value_cents', public.setting_num('loyalty_point_value_cents', null),
      -- K-factor mostrato solo con campione sufficiente di nuovi utenti e inviti
      'k_factor', case when v_users >= v_min and v_reg >= v_min then round(v_reg::numeric / v_users, 2) end,
      'k_factor_note', 'Iscrizioni da invito / nuove iscrizioni del periodo (approssimazione del coefficiente virale). Nascosto con dati insufficienti.'),
    'loyalty', jsonb_build_object(
      'points_issued', (select coalesce(sum(points), 0) from public.loyalty_transactions where points > 0 and type in ('earn', 'bonus', 'referral') and status = 'completed' and created_at >= v_from and created_at < v_to),
      'points_redeemed', (select coalesce(-sum(points), 0) from public.loyalty_transactions where points < 0 and type = 'redeem' and created_at >= v_from and created_at < v_to),
      'outstanding', (select coalesce(sum(points_balance), 0) from public.loyalty_accounts),
      'reward_claims', (select count(*) from public.reward_redemptions where created_at >= v_from and created_at < v_to),
      'repeat_users', (select count(*) from (select user_id from (
          select user_id from public.reservations where user_id is not null and created_at >= v_from and created_at < v_to and status::text not in ('rejected', 'cancelled')
          union all select user_id from public.orders where user_id is not null and paid_at >= v_from and paid_at < v_to and payment_status in ('paid', 'partially_refunded')) x
          group by 1 having count(*) >= 2) y)),
    'reviews', (with rv as (select * from public.reviews x where x.created_at >= v_from and x.created_at < v_to),
                     ret as (select rv.user_id, exists (select 1 from public.user_activity_days a where a.user_id = rv.user_id
                                  and a.day > (rv.created_at at time zone 'Europe/Rome')::date and a.day <= (rv.created_at at time zone 'Europe/Rome')::date + v_win) back from rv)
      select jsonb_build_object('new', count(*), 'verified', count(*) filter (where is_verified),
        'avg_rating', round(avg(rating_overall) filter (where status = 'published'), 2),
        'responded', count(*) filter (where exists (select 1 from public.review_responses rr where rr.review_id = rv.id)),
        'reviewers_returned', (select count(*) filter (where back) from ret), 'reviewers', (select count(*) from ret),
        'note', 'Ritorno dei recensori: correlazione osservata, non un effetto causale della recensione.')
      from rv),
    'min_sample', v_min);
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 10. VOCE DEL CLIENTE: feedback prodotto e supporto (sintesi deterministica, niente temi inventati)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.growth_feedback_category(f public.product_feedback)
returns text language sql immutable as $$
  select coalesce(f.category, case
    when f.type = 'bug' then 'bug'
    when f.type = 'feature_request' then 'feature_request'
    when f.type = 'cancellation' and public.growth_churn_reason(f.reason) = 'too_expensive' then 'pricing'
    when f.type = 'cancellation' and public.growth_churn_reason(f.reason) = 'missing_feature' then 'feature_request'
    when f.type = 'cancellation' and public.growth_churn_reason(f.reason) = 'too_complicated' then 'ux'
    else 'uncategorized' end);
$$;

create or replace function public.admin_growth_voice(p_from date, p_to date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_from timestamptz := p_from::timestamp at time zone 'Europe/Rome'; v_to timestamptz := (p_to + 1)::timestamp at time zone 'Europe/Rome';
  v_thr int := 5;
begin
  perform public.growth_assert_admin();
  return jsonb_build_object(
    'feedback', jsonb_build_object(
      'total', (select count(*) from public.product_feedback where created_at >= v_from and created_at < v_to and type <> 'nps'),
      'by_category', coalesce((select jsonb_agg(jsonb_build_object('category', c, 'count', n,
            'recent', (select jsonb_agg(jsonb_build_object('id', f2.id, 'message', left(f2.message, 280), 'type', f2.type, 'page', f2.page, 'created_at', f2.created_at) order by f2.created_at desc)
                         from (select * from public.product_feedback f3 where public.growth_feedback_category(f3) = t.c and f3.created_at >= v_from and f3.created_at < v_to
                                 and coalesce(f3.message, '') <> '' order by f3.created_at desc limit 5) f2)) order by n desc)
          from (select public.growth_feedback_category(f) c, count(*) n from public.product_feedback f where f.created_at >= v_from and f.created_at < v_to and f.type <> 'nps' group by 1) t), '[]'::jsonb),
      'nps', (select jsonb_build_object('responses', count(*), 'promoters', count(*) filter (where rating >= 9), 'detractors', count(*) filter (where rating <= 6))
                from public.product_feedback where type = 'nps' and created_at >= v_from and created_at < v_to),
      'summary_basis', 'Sintesi deterministica: conteggi per categoria e ultimi messaggi. Nessun tema generato automaticamente.'),
    'support', jsonb_build_object(
      'total', (select count(*) from public.support_tickets where created_at >= v_from and created_at < v_to),
      'open', (select count(*) from public.support_tickets where status in ('open', 'in_progress', 'waiting_customer')),
      'reopened', (select coalesce(sum(reopened_count), 0) from public.support_tickets where created_at >= v_from and created_at < v_to),
      'median_resolution_hours', (select round((percentile_cont(0.5) within group (order by extract(epoch from resolved_at - created_at) / 3600))::numeric, 1)
                                    from public.support_tickets where resolved_at is not null and created_at >= v_from and created_at < v_to),
      'by_category', coalesce((select jsonb_agg(jsonb_build_object('category', category, 'count', n) order by n desc)
          from (select category, count(*) n from public.support_tickets where created_at >= v_from and created_at < v_to group by 1) t), '[]'::jsonb),
      'product_insights', coalesce((select jsonb_agg(jsonb_build_object('category', category, 'count', n,
            'message', format('%s ticket "%s" nel periodo: verificare se c''è un problema di prodotto ricorrente.', n, category)) order by n desc)
          from (select category, count(*) n from public.support_tickets where created_at >= v_from and created_at < v_to group by 1 having count(*) >= v_thr) t), '[]'::jsonb),
      'insight_threshold', v_thr));
end $$;

create or replace function public.admin_feedback_set_category(p_id uuid, p_category text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.growth_assert_admin();
  update public.product_feedback set category = nullif(p_category, '') where id = p_id;
end $$;

-- ────────────────────────────────────────────────────────────────────
-- 11. SEGMENTI (solo conteggi, dati non sensibili; nessuna lista di persone)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.admin_growth_segments()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_today date := (now() at time zone 'Europe/Rome')::date; v_c jsonb; v_r jsonb;
begin
  perform public.growth_assert_admin();
  with u as (
    select p.id, p.created_at, coalesce(np.marketing, false) mkt,
           (select max(day) from public.user_activity_days a where a.user_id = p.id) last_day,
           exists (select 1 from public.user_activity_days a where a.user_id = p.id and a.day between v_today - 90 and v_today - 31) active_before
      from public.profiles p left join public.notification_preferences np on np.user_id = p.id
     where p.role::text = 'customer' and not p.is_blocked),
  cat as (select x.user_id, cat.slug, count(*) n from (
            select user_id, restaurant_id from public.favorites
            union all select user_id, restaurant_id from public.reservations where user_id is not null and status::text not in ('rejected', 'cancelled')
            union all select user_id, restaurant_id from public.orders where user_id is not null and payment_status in ('paid', 'partially_refunded')) x
          join public.restaurant_categories rc on rc.restaurant_id = x.restaurant_id join public.categories cat on cat.id = rc.category_id group by 1, 2),
  seg as (
    select 'new' k, id, mkt from u where created_at > now() - interval '14 days'
    union all select 'active', id, mkt from u where last_day >= v_today - 7
    union all select 'returning', id, mkt from u where last_day >= v_today - 30 and active_before
    union all select 'dormant', id, mkt from u where last_day < v_today - 30 and last_day >= v_today - 180
    union all select 'sushi_lovers', u.id, u.mkt from u where exists (select 1 from cat where cat.user_id = u.id and cat.slug = 'sushi' and cat.n >= 2)
    union all select 'ayce_users', u.id, u.mkt from u where exists (select 1 from (
                 select restaurant_id from public.favorites f where f.user_id = u.id
                 union all select restaurant_id from public.reservations x where x.user_id = u.id) y join public.restaurants r on r.id = y.restaurant_id where r.is_all_you_can_eat)
    union all select 'offer_seekers', u.id, u.mkt from u where (select count(*) from public.coupon_claims c where c.user_id = u.id and c.claimed_at > now() - interval '90 days') >= 2
    union all select 'order_users', u.id, u.mkt from u where exists (select 1 from public.orders o where o.user_id = u.id and o.payment_status in ('paid', 'partially_refunded'))
    union all select 'booking_users', u.id, u.mkt from u where exists (select 1 from public.reservations x where x.user_id = u.id))
  select jsonb_agg(jsonb_build_object('key', k.k, 'count', coalesce(s.n, 0), 'marketing_consent', coalesce(s.m, 0)) order by k.o)
    into v_c
    from (values ('new', 1), ('active', 2), ('returning', 3), ('dormant', 4), ('sushi_lovers', 5), ('ayce_users', 6), ('offer_seekers', 7), ('order_users', 8), ('booking_users', 9)) k(k, o)
    left join (select k, count(*) n, count(*) filter (where mkt) m from seg group by k) s on s.k = k.k;

  with rs as (select r.id, r.owner_id, public.growth_restaurant_health(r.id) h from public.restaurants r where public.growth_in_scope(r.is_demo) and r.is_active),
  sub as (select distinct on (s.restaurant_id) s.* from public.subscriptions s where public.subscription_in_env(s) order by s.restaurant_id, s.created_at desc)
  select jsonb_build_array(
    jsonb_build_object('key', 'new_lead', 'count', (select count(*) from public.crm_leads where kind = 'restaurant' and status in ('new', 'researched'))),
    jsonb_build_object('key', 'claimed', 'count', (select count(*) from rs where owner_id is not null and not exists (select 1 from sub where sub.restaurant_id = rs.id))),
    jsonb_build_object('key', 'trial', 'count', (select count(*) from sub join rs on rs.id = sub.restaurant_id where sub.status = 'trialing' and public.subscription_grants_access(sub))),
    jsonb_build_object('key', 'activated', 'count', (select count(*) from rs where owner_id is not null and public.launch_restaurant_activated(rs.id))),
    jsonb_build_object('key', 'paid', 'count', (select count(*) from sub join rs on rs.id = sub.restaurant_id where sub.paid_started_at is not null and sub.status in ('active', 'past_due') and public.subscription_grants_access(sub))),
    jsonb_build_object('key', 'high_engagement', 'count', (select count(*) from rs where (select coalesce(sum(calls + whatsapp + directions + bookings + orders + coupon_redemptions), 0)
                                                                     from public.daily_restaurant_metrics d where d.restaurant_id = rs.id and d.date > v_today - 30) >= 20)),
    jsonb_build_object('key', 'at_risk', 'count', (select count(*) from rs where h ->> 'status' = 'at_risk')),
    jsonb_build_object('key', 'churned', 'count', (select count(*) from sub join rs on rs.id = sub.restaurant_id where sub.paid_started_at is not null and sub.ended_at is not null)))
  into v_r;
  return jsonb_build_object('customers', v_c, 'restaurants', v_r,
    'definitions', jsonb_build_object(
      'new', 'Iscritti da ≤ 14 giorni', 'active', 'Attivi negli ultimi 7 giorni', 'returning', 'Attivi negli ultimi 30 giorni e anche tra 31 e 90 giorni fa',
      'dormant', 'Ultima attività tra 30 e 180 giorni fa', 'sushi_lovers', 'Almeno 2 tra preferiti/prenotazioni/ordini in locali Sushi',
      'ayce_users', 'Preferito o prenotazione in un locale All You Can Eat', 'offer_seekers', 'Almeno 2 coupon richiesti in 90 giorni',
      'order_users', 'Almeno un ordine pagato', 'booking_users', 'Almeno una prenotazione',
      'marketing_consent', 'Quanti nel segmento hanno scelto di ricevere comunicazioni promozionali (unici contattabili per marketing).'));
end $$;
