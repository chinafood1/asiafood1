-- ════════════════════════════════════════════════════════════════════
--  FASE 6 · AI Assistant nativo (database-first)
--
--  Principi:
--  • Il modello NON esegue SQL: può solo scegliere filtri validati che il
--    backend passa a queste funzioni controllate (ai_search_*).
--  • Le funzioni restituiscono solo dati pubblici e solo i campi utili.
--  • "Aperto ora", distanze, prezzi e disponibilità sono calcolati qui,
--    in modo deterministico, mai dal modello.
--  • Conversazioni temporanee (retention configurabile), niente coordinate
--    salvate, costi e limiti tracciati in ai_usage.
-- ════════════════════════════════════════════════════════════════════

-- ════════════════════════════════════════════════════════════════════
--  1. CONFIGURAZIONE (Admin → AI). Le chiavi API restano secret di ambiente.
-- ════════════════════════════════════════════════════════════════════
insert into public.platform_settings (key, value, description) values
  ('ai_enabled', 'true', 'Assistente AI attivo'),
  ('ai_provider', 'null', 'Provider del modello (anthropic | openai | gemini | openai_compatible | none). null = variabile AI_PROVIDER'),
  ('ai_model', 'null', 'Modello. null = variabile AI_MODEL'),
  ('ai_guest_limit_per_hour', '10', 'Richieste per ora per ospite (sessione)'),
  ('ai_user_limit_per_hour', '30', 'Richieste per ora per utente registrato'),
  ('ai_premium_limit_per_hour', '60', 'Richieste per ora per titolari con piano Premium o Top'),
  ('ai_ip_limit_per_hour', '60', 'Richieste per ora per indirizzo di rete (hash, anti-abuso ospiti)'),
  ('ai_max_restaurants', '5', 'Ristoranti massimi per risposta (3–8)'),
  ('ai_temperature', 'null', 'Temperatura del modello (0–1). null = variabile AI_TEMPERATURE, altrimenti 0.2'),
  ('ai_max_tokens', 'null', 'Token massimi di risposta. null = variabile AI_MAX_TOKENS, altrimenti 600'),
  ('ai_chat_retention_days', '7', 'Giorni di conservazione delle conversazioni (0 = non salvare i messaggi)'),
  ('ai_cache_ttl_seconds', '300', 'Durata cache delle risposte generiche (0 = disattivata)'),
  ('ai_cost_input_per_mtok', '3', 'Costo stimato per milione di token in ingresso (USD)'),
  ('ai_cost_output_per_mtok', '15', 'Costo stimato per milione di token in uscita (USD)')
on conflict (key) do nothing;

create or replace function public.ai_setting_num(p_key text, p_default numeric)
returns numeric language sql stable security definer set search_path = public as $$
  select coalesce((select case when jsonb_typeof(value) = 'number' then (value #>> '{}')::numeric end
                   from public.platform_settings where key = p_key), p_default);
$$;

-- ════════════════════════════════════════════════════════════════════
--  2. FUNZIONI DETERMINISTICHE: apertura, prezzo a persona
-- ════════════════════════════════════════════════════════════════════
create or replace function public.time_minutes(t time)
returns int language sql immutable as $$ select (extract(hour from t) * 60 + extract(minute from t))::int $$;

-- Stato a un istante: 'open' | 'closed' | 'unknown' (nessun orario pubblicato).
-- Considera fasce spezzate, orari oltre la mezzanotte, chiusure straordinarie e chiusure temporanee.
create or replace function public.restaurant_open_status(p_restaurant uuid, p_at timestamptz default now())
returns text language plpgsql stable security definer set search_path = public as $$
declare
  r public.restaurants; v_local timestamp; v_day int; v_min int; v_prev int; h record; o int; c int;
begin
  select * into r from public.restaurants where id = p_restaurant;
  if not found then return 'unknown'; end if;
  if r.is_permanently_closed or r.is_temporarily_closed then return 'closed'; end if;
  v_local := p_at at time zone coalesce(r.timezone, 'Europe/Rome');
  if exists (select 1 from public.restaurant_closures x where x.restaurant_id = r.id and x.date = v_local::date
             and (x.start_time is null or (v_local::time >= x.start_time and v_local::time < x.end_time))) then
    return 'closed';
  end if;
  if not exists (select 1 from public.restaurant_hours where restaurant_id = r.id) then return 'unknown'; end if;
  v_day := extract(isodow from v_local)::int;
  v_prev := case when v_day = 1 then 7 else v_day - 1 end;
  v_min := public.time_minutes(v_local::time);
  for h in select * from public.restaurant_hours where restaurant_id = r.id and not is_closed and opens_at is not null and closes_at is not null loop
    o := public.time_minutes(h.opens_at); c := public.time_minutes(h.closes_at);
    if h.day_of_week = v_day and ((c > o and v_min >= o and v_min < c) or (c <= o and v_min >= o)) then return 'open'; end if;
    if c <= o and h.day_of_week = v_prev and v_min < c then return 'open'; end if;
  end loop;
  return 'closed';
end $$;

-- Aperto almeno in parte nella finestra [from, to) di una data (es. "stasera" 19:00–23:00)
create or replace function public.restaurant_open_in_window(p_restaurant uuid, p_date date, p_from time, p_to time)
returns text language plpgsql stable security definer set search_path = public as $$
declare
  r public.restaurants; v_day int; v_prev int; f int := public.time_minutes(p_from); t int := public.time_minutes(p_to); h record; o int; c int;
begin
  select * into r from public.restaurants where id = p_restaurant;
  if not found then return 'unknown'; end if;
  if r.is_permanently_closed or r.is_temporarily_closed then return 'closed'; end if;
  if t <= f then t := 24 * 60; end if;
  if exists (select 1 from public.restaurant_closures x where x.restaurant_id = r.id and x.date = p_date
             and (x.start_time is null or (x.start_time <= p_from and x.end_time >= p_to))) then
    return 'closed';
  end if;
  if not exists (select 1 from public.restaurant_hours where restaurant_id = r.id) then return 'unknown'; end if;
  v_day := extract(isodow from p_date)::int;
  v_prev := case when v_day = 1 then 7 else v_day - 1 end;
  for h in select * from public.restaurant_hours where restaurant_id = r.id and not is_closed and opens_at is not null and closes_at is not null loop
    o := public.time_minutes(h.opens_at); c := public.time_minutes(h.closes_at);
    if h.day_of_week = v_day and o < t and (case when c <= o then 24 * 60 else c end) > f then return 'open'; end if;
    if c <= o and h.day_of_week = v_prev and f < c then return 'open'; end if;
  end loop;
  return 'closed';
end $$;

-- Prezzo indicativo a persona: formula AYCE del pasto (weekend se previsto) oppure prezzo medio.
-- Nessun valore stimato dalla fascia di prezzo (€€): se manca il dato → null.
create or replace function public.restaurant_price_pp(r public.restaurants, p_meal text, p_date date, p_basis text)
returns numeric language sql stable as $$
  with a as (
    select case when not r.is_all_you_can_eat then null
                when p_date is not null and extract(isodow from p_date) in (6, 7) and r.ayce_weekend_price is not null then r.ayce_weekend_price
                when p_meal = 'lunch' then coalesce(r.ayce_lunch_price, r.ayce_dinner_price)
                else coalesce(r.ayce_dinner_price, r.ayce_lunch_price) end as ayce
  )
  select case when p_basis = 'ayce' then a.ayce else coalesce(r.average_price, a.ayce) end from a;
$$;

-- ════════════════════════════════════════════════════════════════════
--  3. TOOL DI RICERCA (solo dati pubblici, input validati)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.ai_like_escape(p text)
returns text language sql immutable as $$ select replace(replace(replace(p, '\', '\\'), '%', '\%'), '_', '\_') $$;

create or replace function public.ai_text_array(p jsonb, p_key text, p_re text, p_max int)
returns text[] language sql immutable as $$
  select case when jsonb_typeof(p -> p_key) = 'array'
    then (select array_agg(x) from (select lower(left(x, 60)) x from jsonb_array_elements_text(p -> p_key) x where x ~ p_re limit p_max) s) end;
$$;

create or replace function public.ai_catalog()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'categories', coalesce((select jsonb_agg(jsonb_build_object('slug', slug, 'name', name) order by sort_order) from public.categories where is_active), '[]'::jsonb),
    'cities', coalesce((select jsonb_agg(jsonb_build_object('slug', c.slug, 'name', c.name) order by
      (select count(*) from public.restaurants r where r.city_id = c.id and public.restaurant_is_public(r.id)) desc, c.name)
      from public.cities c where c.is_active), '[]'::jsonb));
$$;

-- searchRestaurants / findNearbyRestaurants
create or replace function public.ai_search_restaurants(p jsonb)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_lat float8 := case when (p ->> 'lat') ~ '^-?\d{1,3}(\.\d+)?$' then (p ->> 'lat')::float8 end;
  v_lng float8 := case when (p ->> 'lng') ~ '^-?\d{1,3}(\.\d+)?$' then (p ->> 'lng')::float8 end;
  v_radius float8 := least(greatest(coalesce(case when (p ->> 'radius_km') ~ '^\d+(\.\d+)?$' then (p ->> 'radius_km')::float8 end, 10), 0.5), 100);
  v_limit int := least(greatest(coalesce(case when (p ->> 'limit') ~ '^\d{1,2}$' then (p ->> 'limit')::int end, 5), 1), 20);
  v_city_slug text := nullif(p ->> 'city', '');
  v_city uuid;
  v_cats text[] := public.ai_text_array(p, 'categories', '^[a-z0-9-]{2,40}$', 8);
  v_services text[] := public.ai_text_array(p, 'services', '^[a-z_]{2,30}$', 8);
  v_ids uuid[] := case when jsonb_typeof(p -> 'ids') = 'array' then (select array_agg(x::uuid) from (select x from jsonb_array_elements_text(p -> 'ids') x
                    where x ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' limit 10) s) end;
  v_text text := nullif(left(trim(coalesce(p ->> 'text', '')), 60), '');
  v_at timestamptz := case when (p ->> 'open_at') ~ '^\d{4}-\d{2}-\d{2}T' then (p ->> 'open_at')::timestamptz end;
  v_wdate date := case when (p ->> 'window_date') ~ '^\d{4}-\d{2}-\d{2}$' then (p ->> 'window_date')::date end;
  v_wfrom time := case when (p ->> 'window_from') ~ '^\d{2}:\d{2}$' then (p ->> 'window_from')::time end;
  v_wto time := case when (p ->> 'window_to') ~ '^\d{2}:\d{2}$' then (p ->> 'window_to')::time end;
  v_open_req boolean := coalesce((p ->> 'open_required')::boolean, false);
  v_meal text := case when p ->> 'meal' in ('lunch', 'dinner') then p ->> 'meal' else 'dinner' end;
  v_ayce boolean := coalesce((p ->> 'ayce')::boolean, false);
  v_max numeric := case when (p ->> 'max_price') ~ '^\d{1,4}(\.\d+)?$' then (p ->> 'max_price')::numeric end;
  v_min numeric := case when (p ->> 'min_price') ~ '^\d{1,4}(\.\d+)?$' then (p ->> 'min_price')::numeric end;
  v_sort text := coalesce(p ->> 'sort', 'relevance');
  v_price_date date;
  v_out jsonb;
begin
  if v_city_slug is not null then
    select id into v_city from public.cities where slug = v_city_slug;
    if v_city is null then return jsonb_build_object('items', '[]'::jsonb, 'total', 0, 'excluded_no_price', 0, 'unknown_hours', 0); end if;
  end if;
  if v_ayce or 'all-you-can-eat' = any(coalesce(v_cats, '{}')) then v_ayce := true; end if;
  v_price_date := coalesce(v_wdate, (coalesce(v_at, now()) at time zone 'Europe/Rome')::date);

  with base as (
    select r.*,
      case when v_lat is not null and v_lng is not null and r.latitude is not null and r.longitude is not null
           then public.geo_distance_km(v_lat, v_lng, r.latitude, r.longitude) end as dist,
      public.restaurant_price_pp(r, v_meal, v_price_date, case when v_ayce then 'ayce' else 'auto' end) as pp,
      (v_text is not null and (r.name ilike '%' || public.ai_like_escape(v_text) || '%')) as name_match
    from public.restaurants r
    where public.restaurant_is_public(r.id) and not r.is_permanently_closed
      and (v_ids is null or r.id = any(v_ids))
      and (v_city is null or r.city_id = v_city)
      and (v_cats is null or cardinality(v_cats) = 0
           or exists (select 1 from public.restaurant_categories rc join public.categories c on c.id = rc.category_id
                      where rc.restaurant_id = r.id and c.slug = any(v_cats) and c.slug <> 'all-you-can-eat')
           or (v_cats = array['all-you-can-eat'] and r.is_all_you_can_eat))
      and (not v_ayce or r.is_all_you_can_eat)
      and (not coalesce((p ->> 'delivery')::boolean, false) or r.has_delivery)
      and (not coalesce((p ->> 'takeaway')::boolean, false) or r.has_takeaway)
      and (not coalesce((p ->> 'reservation')::boolean, false) or (
            public.restaurant_has_feature(r.id, 'reservations_enabled')
            and exists (select 1 from public.reservation_settings s where s.restaurant_id = r.id and s.reservation_enabled)))
      and (v_services is null or r.services @> v_services)
      and (v_text is null or r.name ilike '%' || public.ai_like_escape(v_text) || '%'
           or r.short_description ilike '%' || public.ai_like_escape(v_text) || '%')
      and (not coalesce((p ->> 'vegetarian')::boolean, false) or 'vegetariano' = any(r.services) or exists (
            select 1 from public.menu_items i where i.restaurant_id = r.id and i.is_available and (i.is_vegetarian or i.is_vegan)
              and public.menu_category_is_public(i.menu_category_id)))
      and (not coalesce((p ->> 'vegan')::boolean, false) or 'vegano' = any(r.services) or exists (
            select 1 from public.menu_items i where i.restaurant_id = r.id and i.is_available and i.is_vegan
              and public.menu_category_is_public(i.menu_category_id)))
      and (not coalesce((p ->> 'gluten_free')::boolean, false) or 'senza_glutine' = any(r.services) or exists (
            select 1 from public.menu_items i where i.restaurant_id = r.id and i.is_available and i.is_gluten_free
              and public.menu_category_is_public(i.menu_category_id)))
      and (not coalesce((p ->> 'spicy')::boolean, false) or exists (
            select 1 from public.menu_items i where i.restaurant_id = r.id and i.is_available and i.is_spicy
              and public.menu_category_is_public(i.menu_category_id)))
      and (not coalesce((p ->> 'has_offers')::boolean, false) or (public.restaurant_has_feature(r.id, 'offers_enabled') and exists (
            select 1 from public.offers o where o.restaurant_id = r.id and o.is_active and o.starts_at <= now() and (o.ends_at is null or o.ends_at > now()))))
  ), located as (
    select b.*,
      case when v_wdate is not null and v_wfrom is not null and v_wto is not null then public.restaurant_open_in_window(b.id, v_wdate, v_wfrom, v_wto)
           else public.restaurant_open_status(b.id, coalesce(v_at, now())) end as open_status
    from base b
    where v_lat is null or (b.dist is not null and b.dist <= v_radius)
  ), counted as (
    select l.*,
      (v_max is not null or v_min is not null) and l.pp is null as no_price,
      (v_open_req and l.open_status = 'unknown') as no_hours
    from located l
  ), matched as (
    select c.* from counted c
    where not c.no_price
      and (v_max is null or c.pp <= v_max) and (v_min is null or c.pp >= v_min)
      and (not v_open_req or c.open_status = 'open')
  ), ranked as (
    select m.*, row_number() over (order by
      case when v_sort = 'distance' then m.dist end asc nulls last,
      case when v_sort = 'price' then m.pp end asc nulls last,
      m.name_match desc,
      case when v_at is not null or v_wdate is not null then (m.open_status = 'open') end desc nulls last,
      case when v_lat is not null then m.dist end asc nulls last,
      (m.data_status in ('verified', 'claimed')) desc,
      m.popularity_score desc, m.name) as rn
    from matched m
  )
  select jsonb_build_object(
    'total', (select count(*) from matched),
    'excluded_no_price', (select count(*) from counted where no_price),
    'unknown_hours', (select count(*) from counted where no_hours),
    'items', coalesce((select jsonb_agg(jsonb_build_object(
      'id', x.id, 'slug', x.slug, 'name', x.name,
      'city', (select name from public.cities where id = x.city_id),
      'city_slug', (select slug from public.cities where id = x.city_id),
      'categories', coalesce((select jsonb_agg(c.name order by rc.is_primary desc, c.sort_order) from public.restaurant_categories rc
                              join public.categories c on c.id = rc.category_id where rc.restaurant_id = x.id), '[]'::jsonb),
      'distance_km', case when x.dist is not null then round(x.dist::numeric, 1) end,
      'price_per_person', x.pp, 'average_price', x.average_price, 'price_range', x.price_range,
      'is_all_you_can_eat', x.is_all_you_can_eat, 'ayce_lunch_price', x.ayce_lunch_price, 'ayce_dinner_price', x.ayce_dinner_price,
      'ayce_weekend_price', x.ayce_weekend_price, 'services', to_jsonb(x.services),
      'has_delivery', x.has_delivery, 'has_takeaway', x.has_takeaway,
      'reservations_online', public.restaurant_has_feature(x.id, 'reservations_enabled')
                             and exists (select 1 from public.reservation_settings s where s.restaurant_id = x.id and s.reservation_enabled),
      'open_status', x.open_status, 'has_hours', exists (select 1 from public.restaurant_hours h where h.restaurant_id = x.id),
      'cover_url', x.cover_url, 'latitude', x.latitude, 'longitude', x.longitude, 'phone', x.phone, 'is_demo', x.is_demo,
      'offer', case when public.restaurant_has_feature(x.id, 'offers_enabled') then (
          select jsonb_build_object('id', o.id, 'title', o.title) from public.offers o
          where o.restaurant_id = x.id and o.is_active and o.starts_at <= now() and (o.ends_at is null or o.ends_at > now())
          order by o.is_featured desc, o.starts_at desc limit 1) end,
      'offers_count', case when public.restaurant_has_feature(x.id, 'offers_enabled') then (
          select count(*) from public.offers o where o.restaurant_id = x.id and o.is_active and o.starts_at <= now() and (o.ends_at is null or o.ends_at > now())) else 0 end
    ) order by x.rn) from ranked x where x.rn <= v_limit), '[]'::jsonb)
  ) into v_out;
  return v_out;
end $$;

-- searchMenuItems: cerca nei menu strutturati (ILIKE su nome, descrizione, ingredienti, tag)
create or replace function public.ai_search_menu(p jsonb)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_terms text[] := public.ai_text_array(p, 'terms', '^[[:alnum:] àèéìòù''-]{2,40}$', 5);
  v_rest uuid := case when (p ->> 'restaurant_id') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then (p ->> 'restaurant_id')::uuid end;
  v_city uuid := (select id from public.cities where slug = p ->> 'city');
  v_cats text[] := public.ai_text_array(p, 'categories', '^[a-z0-9-]{2,40}$', 8);
  v_lat float8 := case when (p ->> 'lat') ~ '^-?\d{1,3}(\.\d+)?$' then (p ->> 'lat')::float8 end;
  v_lng float8 := case when (p ->> 'lng') ~ '^-?\d{1,3}(\.\d+)?$' then (p ->> 'lng')::float8 end;
  v_radius float8 := least(greatest(coalesce(case when (p ->> 'radius_km') ~ '^\d+(\.\d+)?$' then (p ->> 'radius_km')::float8 end, 10), 0.5), 100);
  v_max numeric := case when (p ->> 'max_price') ~ '^\d{1,4}(\.\d+)?$' then (p ->> 'max_price')::numeric end;
  v_limit int := least(greatest(coalesce(case when (p ->> 'limit') ~ '^\d{1,2}$' then (p ->> 'limit')::int end, 6), 1), 20);
  v_match text := case when p ->> 'match' = 'any' then 'any' else 'all' end;
begin
  if (p ->> 'city') is not null and v_city is null then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(row_to_json(x)::jsonb - 'sort_key' order by x.sort_key) from (
      select i.id, i.name, left(i.description, 140) as description,
             i.price, i.discount_price, i.allergens, i.is_vegetarian, i.is_vegan, i.is_gluten_free, i.is_spicy,
             mc.name as menu_category,
             jsonb_build_object('id', r.id, 'slug', r.slug, 'name', r.name, 'city', (select name from public.cities where id = r.city_id),
               'distance_km', case when v_lat is not null and r.latitude is not null then round(public.geo_distance_km(v_lat, v_lng, r.latitude, r.longitude)::numeric, 1) end) as restaurant,
             row_number() over (order by
               case when v_lat is not null and r.latitude is not null then public.geo_distance_km(v_lat, v_lng, r.latitude, r.longitude) end asc nulls last,
               coalesce(i.discount_price, i.price) asc nulls last, i.name) as sort_key
      from public.menu_items i
      join public.menu_categories mc on mc.id = i.menu_category_id
      join public.restaurants r on r.id = i.restaurant_id
      where i.is_available and public.menu_category_is_public(mc.id) and not r.is_permanently_closed
        and (v_rest is null or r.id = v_rest)
        and (v_city is null or r.city_id = v_city)
        and (v_cats is null or exists (select 1 from public.restaurant_categories rc join public.categories c on c.id = rc.category_id
                                       where rc.restaurant_id = r.id and c.slug = any(v_cats)))
        and (v_lat is null or (r.latitude is not null and public.geo_distance_km(v_lat, v_lng, r.latitude, r.longitude) <= v_radius))
        and (v_terms is null or (
              case when v_match = 'any' then exists (select 1 from unnest(v_terms) t where
                     i.name ilike '%' || public.ai_like_escape(t) || '%' or coalesce(i.description, '') ilike '%' || public.ai_like_escape(t) || '%'
                     or exists (select 1 from unnest(coalesce(i.ingredients, '{}') || coalesce(i.tags, '{}')) g where g ilike '%' || public.ai_like_escape(t) || '%'))
                   else not exists (select 1 from unnest(v_terms) t where not (
                     i.name ilike '%' || public.ai_like_escape(t) || '%' or coalesce(i.description, '') ilike '%' || public.ai_like_escape(t) || '%'
                     or exists (select 1 from unnest(coalesce(i.ingredients, '{}') || coalesce(i.tags, '{}')) g where g ilike '%' || public.ai_like_escape(t) || '%')
                     or mc.name ilike '%' || public.ai_like_escape(t) || '%'))
              end))
        and (not coalesce((p ->> 'vegetarian')::boolean, false) or i.is_vegetarian or i.is_vegan)
        and (not coalesce((p ->> 'vegan')::boolean, false) or i.is_vegan)
        and (not coalesce((p ->> 'gluten_free')::boolean, false) or i.is_gluten_free)
        and (not coalesce((p ->> 'spicy')::boolean, false) or i.is_spicy)
        and (v_max is null or (coalesce(i.discount_price, i.price) is not null and coalesce(i.discount_price, i.price) <= v_max))
    ) x where x.sort_key <= v_limit), '[]'::jsonb);
end $$;

-- searchOffers: offerte valide nella data/ora indicata + coupon ottenibili
create or replace function public.ai_search_offers(p jsonb)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_date date := coalesce(case when (p ->> 'date') ~ '^\d{4}-\d{2}-\d{2}$' then (p ->> 'date')::date end, (now() at time zone 'Europe/Rome')::date);
  v_city uuid := (select id from public.cities where slug = p ->> 'city');
  v_cats text[] := public.ai_text_array(p, 'categories', '^[a-z0-9-]{2,40}$', 8);
  v_rest uuid := case when (p ->> 'restaurant_id') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then (p ->> 'restaurant_id')::uuid end;
  v_lat float8 := case when (p ->> 'lat') ~ '^-?\d{1,3}(\.\d+)?$' then (p ->> 'lat')::float8 end;
  v_lng float8 := case when (p ->> 'lng') ~ '^-?\d{1,3}(\.\d+)?$' then (p ->> 'lng')::float8 end;
  v_radius float8 := least(greatest(coalesce(case when (p ->> 'radius_km') ~ '^\d+(\.\d+)?$' then (p ->> 'radius_km')::float8 end, 10), 0.5), 100);
  v_limit int := least(greatest(coalesce(case when (p ->> 'limit') ~ '^\d{1,2}$' then (p ->> 'limit')::int end, 6), 1), 20);
  v_day_start timestamptz := v_date::timestamp at time zone 'Europe/Rome';
begin
  if (p ->> 'city') is not null and v_city is null then return jsonb_build_object('offers', '[]'::jsonb, 'coupons', '[]'::jsonb, 'date', v_date); end if;
  return jsonb_build_object('date', v_date,
    'offers', coalesce((select jsonb_agg(o order by o ->> 'restaurant_distance' nulls last) from (
      select jsonb_build_object('id', o.id, 'title', o.title, 'description', left(o.description, 160), 'offer_type', o.offer_type,
        'discount_type', o.discount_type, 'discount_value', o.discount_value, 'minimum_spend', o.minimum_spend,
        'days_of_week', to_jsonb(o.days_of_week), 'start_time', to_char(o.start_time, 'HH24:MI'), 'end_time', to_char(o.end_time, 'HH24:MI'),
        'ends_at', o.ends_at, 'terms', left(o.terms, 160),
        'restaurant', jsonb_build_object('id', r.id, 'slug', r.slug, 'name', r.name, 'city', (select name from public.cities where id = r.city_id),
          'distance_km', case when v_lat is not null and r.latitude is not null then round(public.geo_distance_km(v_lat, v_lng, r.latitude, r.longitude)::numeric, 1) end)) as o
      from public.offers o join public.restaurants r on r.id = o.restaurant_id
      where o.is_active and public.restaurant_is_public(r.id) and not r.is_permanently_closed
        and public.restaurant_has_feature(r.id, 'offers_enabled')
        and o.starts_at < v_day_start + interval '1 day' and (o.ends_at is null or o.ends_at > v_day_start)
        and (cardinality(o.days_of_week) = 0 or extract(isodow from v_date)::smallint = any(o.days_of_week))
        and (v_rest is null or r.id = v_rest) and (v_city is null or r.city_id = v_city)
        and (v_cats is null or exists (select 1 from public.restaurant_categories rc join public.categories c on c.id = rc.category_id
                                       where rc.restaurant_id = r.id and c.slug = any(v_cats))
             or ('all-you-can-eat' = any(v_cats) and (r.is_all_you_can_eat or o.offer_type = 'ayce_promo')))
        and (v_lat is null or (r.latitude is not null and public.geo_distance_km(v_lat, v_lng, r.latitude, r.longitude) <= v_radius))
      limit v_limit) s), '[]'::jsonb),
    'coupons', coalesce((select jsonb_agg(c) from (
      select jsonb_build_object('id', c.id, 'title', c.title, 'discount_type', c.discount_type, 'discount_value', c.discount_value,
        'minimum_spend', c.minimum_spend, 'valid_until', c.valid_until,
        'restaurant', jsonb_build_object('id', r.id, 'slug', r.slug, 'name', r.name, 'city', (select name from public.cities where id = r.city_id))) as c
      from public.coupons c join public.restaurants r on r.id = c.restaurant_id
      where c.is_active and c.valid_from <= now() and (c.valid_until is null or c.valid_until > now())
        and (c.max_redemptions is null or c.claims_count < c.max_redemptions)
        and public.restaurant_is_public(r.id) and not r.is_permanently_closed and public.restaurant_has_feature(r.id, 'coupons_enabled')
        and (v_rest is null or r.id = v_rest) and (v_city is null or r.city_id = v_city)
        and (v_cats is null or exists (select 1 from public.restaurant_categories rc join public.categories cc on cc.id = rc.category_id
                                       where rc.restaurant_id = r.id and cc.slug = any(v_cats)))
        and (v_lat is null or (r.latitude is not null and public.geo_distance_km(v_lat, v_lng, r.latitude, r.longitude) <= v_radius))
      limit v_limit) s), '[]'::jsonb));
end $$;

-- getRestaurantDetails: scheda pubblica per le domande su un ristorante (prezzi, orari, servizi, menu)
create or replace function public.ai_restaurant_detail(p_ref text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare r public.restaurants;
begin
  if p_ref ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    select * into r from public.restaurants where id = p_ref::uuid;
  else
    select * into r from public.restaurants where slug = left(p_ref, 120);
  end if;
  if not found or not public.restaurant_is_public(r.id) then return null; end if;
  return jsonb_build_object(
    'id', r.id, 'slug', r.slug, 'name', r.name, 'city', (select name from public.cities where id = r.city_id),
    'short_description', left(r.short_description, 200), 'description', left(r.description, 400), 'address', r.address,
    'phone', r.phone, 'average_price', r.average_price, 'price_range', r.price_range,
    'is_all_you_can_eat', r.is_all_you_can_eat, 'ayce_lunch_price', r.ayce_lunch_price, 'ayce_dinner_price', r.ayce_dinner_price,
    'ayce_weekend_price', r.ayce_weekend_price, 'services', to_jsonb(r.services), 'has_delivery', r.has_delivery, 'has_takeaway', r.has_takeaway,
    'is_temporarily_closed', r.is_temporarily_closed, 'timezone', r.timezone, 'cover_url', r.cover_url, 'latitude', r.latitude, 'longitude', r.longitude,
    'categories', coalesce((select jsonb_agg(c.name) from public.restaurant_categories rc join public.categories c on c.id = rc.category_id where rc.restaurant_id = r.id), '[]'::jsonb),
    'open_status', public.restaurant_open_status(r.id, now()),
    'hours', coalesce((select jsonb_agg(jsonb_build_object('day', h.day_of_week, 'opens', to_char(h.opens_at, 'HH24:MI'), 'closes', to_char(h.closes_at, 'HH24:MI'),
                         'is_closed', h.is_closed, 'label', h.label) order by h.day_of_week, h.opens_at) from public.restaurant_hours h where h.restaurant_id = r.id), '[]'::jsonb),
    'closures', coalesce((select jsonb_agg(jsonb_build_object('date', x.date, 'from', to_char(x.start_time, 'HH24:MI'), 'to', to_char(x.end_time, 'HH24:MI'))
                         order by x.date) from public.restaurant_closures x where x.restaurant_id = r.id and x.date between current_date and current_date + 14), '[]'::jsonb),
    'menu_summary', jsonb_build_object(
      'items', (select count(*) from public.menu_items i where i.restaurant_id = r.id and i.is_available and public.menu_category_is_public(i.menu_category_id)),
      'vegetarian', (select count(*) from public.menu_items i where i.restaurant_id = r.id and i.is_available and (i.is_vegetarian or i.is_vegan) and public.menu_category_is_public(i.menu_category_id)),
      'vegan', (select count(*) from public.menu_items i where i.restaurant_id = r.id and i.is_available and i.is_vegan and public.menu_category_is_public(i.menu_category_id)),
      'gluten_free', (select count(*) from public.menu_items i where i.restaurant_id = r.id and i.is_available and i.is_gluten_free and public.menu_category_is_public(i.menu_category_id)),
      'spicy', (select count(*) from public.menu_items i where i.restaurant_id = r.id and i.is_available and i.is_spicy and public.menu_category_is_public(i.menu_category_id))),
    'reservations_online', public.restaurant_has_feature(r.id, 'reservations_enabled')
                           and exists (select 1 from public.reservation_settings s where s.restaurant_id = r.id and s.reservation_enabled),
    'has_offers', public.restaurant_has_feature(r.id, 'offers_enabled') and exists (
        select 1 from public.offers o where o.restaurant_id = r.id and o.is_active and o.starts_at <= now() and (o.ends_at is null or o.ends_at > now())));
end $$;

-- ════════════════════════════════════════════════════════════════════
--  4. SESSIONI CHAT (temporanee), PREFERENZE, UTILIZZO E COSTI, CACHE
-- ════════════════════════════════════════════════════════════════════
create table public.ai_chat_sessions (
  id            uuid primary key default gen_random_uuid(),
  token_hash    text not null unique check (token_hash ~ '^[0-9a-f]{64}$'),   -- sha256 dell'ID di sessione del browser
  user_id       uuid references public.profiles(id) on delete cascade,
  restaurant_id uuid references public.restaurants(id) on delete set null,   -- contesto "chiedi su questo ristorante"
  last_filters  jsonb not null default '{}'::jsonb,                          -- mai coordinate
  message_count int not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  expires_at    timestamptz not null default now() + interval '7 days'
);
create index ai_chat_sessions_user_idx on public.ai_chat_sessions(user_id);
create index ai_chat_sessions_expiry_idx on public.ai_chat_sessions(expires_at);

create table public.ai_chat_messages (
  id              bigint generated always as identity primary key,
  chat_session_id uuid not null references public.ai_chat_sessions(id) on delete cascade,
  role            text not null check (role in ('user', 'assistant')),
  content         text not null check (char_length(content) <= 2000),
  metadata        jsonb not null default '{}'::jsonb,                        -- intento, ID risultati: niente coordinate
  created_at      timestamptz not null default now()
);
create index ai_chat_messages_session_idx on public.ai_chat_messages(chat_session_id, created_at);

create table public.ai_user_preferences (
  user_id               uuid primary key references public.profiles(id) on delete cascade,
  favorite_categories   text[] not null default '{}' check (cardinality(favorite_categories) <= 10),
  preferred_price_range smallint check (preferred_price_range between 1 and 4),
  dietary_preferences   text[] not null default '{}' check (dietary_preferences <@ array['vegetarian', 'vegan', 'gluten_free', 'no_spicy']),
  favorite_cities       text[] not null default '{}' check (cardinality(favorite_cities) <= 10),
  updated_at            timestamptz not null default now()
);
create trigger ai_user_preferences_updated_at before update on public.ai_user_preferences
  for each row execute function public.set_updated_at();

create table public.ai_usage (
  id             bigint generated always as identity primary key,
  user_id        uuid references public.profiles(id) on delete set null,
  session_id     text,                  -- hash della sessione (non reversibile)
  ip_hash        text,                  -- hash salato dell'indirizzo di rete (solo rate limit)
  provider       text,
  model          text,
  input_tokens   int not null default 0,
  output_tokens  int not null default 0,
  estimated_cost numeric(12, 6) not null default 0,
  request_type   text not null default 'chat' check (request_type in ('chat', 'restaurant_chat')),
  intent         text,
  status         text not null check (status in ('ok', 'fallback', 'error', 'rate_limited', 'cached', 'disabled')),
  result_count   int not null default 0,
  no_results     boolean not null default false,
  latency_ms     int,
  created_at     timestamptz not null default now()
);
create index ai_usage_created_idx on public.ai_usage(created_at desc);
create index ai_usage_session_idx on public.ai_usage(session_id, created_at desc);
create index ai_usage_user_idx on public.ai_usage(user_id, created_at desc);
create index ai_usage_ip_idx on public.ai_usage(ip_hash, created_at desc);

create table public.ai_cache (
  key        text primary key check (key ~ '^[0-9a-f]{64}$'),
  payload    jsonb not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index ai_cache_expiry_idx on public.ai_cache(expires_at);

-- Attribuzione conversioni: coupon ottenuto partendo dall'assistente
alter table public.coupon_claims add column if not exists source text not null default 'web' check (source in ('web', 'app', 'ai'));

-- ─── RPC server-side (solo service_role) ─────────────────────────────
create or replace function public.ai_session_open(p_token_hash text, p_user uuid, p_restaurant uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare s public.ai_chat_sessions; v_days int := public.ai_setting_num('ai_chat_retention_days', 7)::int;
begin
  perform public.assert_service();
  if p_token_hash !~ '^[0-9a-f]{64}$' then return jsonb_build_object('ok', false, 'error', 'BAD_SESSION'); end if;
  select * into s from public.ai_chat_sessions where token_hash = p_token_hash;
  if found then
    -- La sessione di un utente registrato non è accessibile da altri (né da ospiti)
    if s.user_id is not null and s.user_id is distinct from p_user then return jsonb_build_object('ok', false, 'error', 'FORBIDDEN'); end if;
    if s.expires_at <= now() then
      delete from public.ai_chat_sessions where id = s.id;
    else
      if s.user_id is null and p_user is not null then update public.ai_chat_sessions set user_id = p_user where id = s.id; end if;
      if p_restaurant is not null and s.restaurant_id is distinct from p_restaurant then
        update public.ai_chat_sessions set restaurant_id = p_restaurant, last_filters = '{}'::jsonb where id = s.id;
        s.last_filters := '{}'::jsonb;
      end if;
      return jsonb_build_object('ok', true, 'id', s.id, 'last_filters', s.last_filters, 'message_count', s.message_count,
        'history', coalesce((select jsonb_agg(jsonb_build_object('role', m.role, 'content', m.content) order by m.id) from (
            select * from public.ai_chat_messages where chat_session_id = s.id order by id desc limit 6) m), '[]'::jsonb));
    end if;
  end if;
  insert into public.ai_chat_sessions (token_hash, user_id, restaurant_id, expires_at)
  values (p_token_hash, p_user, p_restaurant, now() + make_interval(days => greatest(v_days, 1)))
  returning * into s;
  return jsonb_build_object('ok', true, 'id', s.id, 'last_filters', '{}'::jsonb, 'message_count', 0, 'history', '[]'::jsonb);
end $$;

create or replace function public.ai_session_append(p_session uuid, p_user_msg text, p_assistant_msg text, p_metadata jsonb, p_filters jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare v_days int := public.ai_setting_num('ai_chat_retention_days', 7)::int; v_filters jsonb := coalesce(p_filters, '{}'::jsonb);
begin
  perform public.assert_service();
  -- Mai coordinate nel contesto salvato
  v_filters := v_filters - 'lat' - 'lng' - 'latitude' - 'longitude';
  if v_days > 0 then
    insert into public.ai_chat_messages (chat_session_id, role, content, metadata) values
      (p_session, 'user', left(p_user_msg, 2000), '{}'::jsonb),
      (p_session, 'assistant', left(p_assistant_msg, 2000), coalesce(p_metadata, '{}'::jsonb) - 'lat' - 'lng');
  end if;
  update public.ai_chat_sessions set last_filters = v_filters, message_count = message_count + 2, updated_at = now(),
         expires_at = now() + make_interval(days => greatest(v_days, 1))
   where id = p_session;
end $$;

create or replace function public.ai_session_delete(p_token_hash text, p_user uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare s public.ai_chat_sessions;
begin
  perform public.assert_service();
  select * into s from public.ai_chat_sessions where token_hash = p_token_hash;
  if not found then return true; end if;
  if s.user_id is not null and s.user_id is distinct from p_user then return false; end if;
  delete from public.ai_chat_sessions where id = s.id;
  return true;
end $$;

-- Rate limit centralizzato: limiti letti dalla configurazione, mai scritti nel codice
create or replace function public.ai_rate_check(p_user uuid, p_session text, p_ip text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_limit int; v_used int; v_ip_used int; v_ip_limit int := public.ai_setting_num('ai_ip_limit_per_hour', 60)::int;
begin
  perform public.assert_service();
  if p_user is not null then
    -- Titolari di un piano Premium/Top: limite dedicato (configurabile)
    v_limit := case when exists (select 1 from public.restaurants r where r.owner_id = p_user and r.subscription_plan in ('premium', 'top'))
                    then public.ai_setting_num('ai_premium_limit_per_hour', 60)::int
                    else public.ai_setting_num('ai_user_limit_per_hour', 30)::int end;
    select count(*) into v_used from public.ai_usage where user_id = p_user and status <> 'rate_limited' and created_at > now() - interval '1 hour';
  else
    v_limit := public.ai_setting_num('ai_guest_limit_per_hour', 10)::int;
    select count(*) into v_used from public.ai_usage where session_id = p_session and user_id is null and status <> 'rate_limited' and created_at > now() - interval '1 hour';
    if p_ip is not null then
      select count(*) into v_ip_used from public.ai_usage where ip_hash = p_ip and user_id is null and status <> 'rate_limited' and created_at > now() - interval '1 hour';
      if v_ip_used >= v_ip_limit then return jsonb_build_object('ok', false, 'limit', v_ip_limit, 'remaining', 0); end if;
    end if;
  end if;
  return jsonb_build_object('ok', v_used < v_limit, 'limit', v_limit, 'remaining', greatest(v_limit - v_used - 1, 0));
end $$;

create or replace function public.ai_log_usage(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare v_in int := greatest(coalesce((p ->> 'input_tokens')::int, 0), 0); v_out int := greatest(coalesce((p ->> 'output_tokens')::int, 0), 0);
begin
  perform public.assert_service();
  insert into public.ai_usage (user_id, session_id, ip_hash, provider, model, input_tokens, output_tokens, estimated_cost,
    request_type, intent, status, result_count, no_results, latency_ms)
  values (nullif(p ->> 'user_id', '')::uuid, left(p ->> 'session_id', 64), left(p ->> 'ip_hash', 64), left(p ->> 'provider', 40), left(p ->> 'model', 80),
    v_in, v_out,
    round((v_in * public.ai_setting_num('ai_cost_input_per_mtok', 3) + v_out * public.ai_setting_num('ai_cost_output_per_mtok', 15)) / 1000000.0, 6),
    coalesce(p ->> 'request_type', 'chat'), left(p ->> 'intent', 40), p ->> 'status', coalesce((p ->> 'result_count')::int, 0),
    coalesce((p ->> 'no_results')::boolean, false), (p ->> 'latency_ms')::int);
end $$;

create or replace function public.ai_cache_get(p_key text)
returns jsonb language sql stable security definer set search_path = public as $$
  select payload from public.ai_cache where key = p_key and expires_at > now() and coalesce(auth.uid()::text, '') = '';
$$;
create or replace function public.ai_cache_put(p_key text, p_payload jsonb, p_ttl int)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_service();
  if p_ttl <= 0 then return; end if;
  insert into public.ai_cache (key, payload, expires_at) values (p_key, p_payload, now() + make_interval(secs => least(p_ttl, 3600)))
  on conflict (key) do update set payload = excluded.payload, created_at = now(), expires_at = excluded.expires_at;
end $$;

-- Contesto personale minimo (solo utenti registrati): preferenze + categorie dei preferiti
create or replace function public.ai_user_context(p_user uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select case when coalesce(auth.uid()::text, '') <> '' then null else jsonb_build_object(
    'preferences', (select to_jsonb(x) - 'user_id' - 'updated_at' from public.ai_user_preferences x where x.user_id = p_user),
    'favorite_ids', coalesce((select jsonb_agg(f.restaurant_id) from public.favorites f where f.user_id = p_user), '[]'::jsonb),
    'favorite_categories', coalesce((select jsonb_agg(slug) from (
        select c.slug from public.favorites f join public.restaurant_categories rc on rc.restaurant_id = f.restaurant_id
        join public.categories c on c.id = rc.category_id where f.user_id = p_user and c.slug <> 'all-you-can-eat'
        group by c.slug order by count(*) desc limit 3) s), '[]'::jsonb)) end;
$$;

-- Configurazione di runtime per il backend (nessun segreto: le chiavi API sono solo variabili d'ambiente)
create or replace function public.ai_runtime_config()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(key, value), '{}'::jsonb) from public.platform_settings where key like 'ai\_%';
$$;

-- Pulizia (cron): conversazioni scadute, cache, utilizzo oltre 13 mesi
create or replace function public.ai_purge()
returns jsonb language plpgsql security definer set search_path = public as $$
declare a int; b int; c int;
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  delete from public.ai_chat_sessions where expires_at <= now(); get diagnostics a = row_count;
  delete from public.ai_cache where expires_at <= now(); get diagnostics b = row_count;
  delete from public.ai_usage where created_at < now() - interval '13 months'; get diagnostics c = row_count;
  return jsonb_build_object('sessions', a, 'cache', b, 'usage', c);
end $$;

-- ─── Statistiche ─────────────────────────────────────────────────────
create or replace function public.ai_admin_stats(p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_days int := least(greatest(coalesce(p_days, 30), 1), 365); v_today timestamptz := date_trunc('day', now() at time zone 'Europe/Rome') at time zone 'Europe/Rome';
begin
  -- Admin, oppure backend (service_role, senza utente). anon non ha il permesso di esecuzione.
  if auth.uid() is not null and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  return jsonb_build_object(
    'requests_today', (select count(*) from public.ai_usage where created_at >= v_today),
    'requests_month', (select count(*) from public.ai_usage where created_at >= date_trunc('month', now() at time zone 'Europe/Rome') at time zone 'Europe/Rome'),
    'requests_period', (select count(*) from public.ai_usage where created_at >= now() - make_interval(days => v_days)),
    'input_tokens', (select coalesce(sum(input_tokens), 0) from public.ai_usage where created_at >= now() - make_interval(days => v_days)),
    'output_tokens', (select coalesce(sum(output_tokens), 0) from public.ai_usage where created_at >= now() - make_interval(days => v_days)),
    'estimated_cost', (select coalesce(round(sum(estimated_cost), 4), 0) from public.ai_usage where created_at >= now() - make_interval(days => v_days)),
    'error_rate', (select case when count(*) = 0 then 0 else round(count(*) filter (where status = 'error') * 100.0 / count(*), 1) end
                   from public.ai_usage where created_at >= now() - make_interval(days => v_days) and status <> 'rate_limited'),
    'fallback_rate', (select case when count(*) = 0 then 0 else round(count(*) filter (where status = 'fallback') * 100.0 / count(*), 1) end
                      from public.ai_usage where created_at >= now() - make_interval(days => v_days) and status not in ('rate_limited', 'disabled')),
    'no_results_rate', (select case when count(*) = 0 then 0 else round(count(*) filter (where no_results) * 100.0 / count(*), 1) end
                        from public.ai_usage where created_at >= now() - make_interval(days => v_days) and status in ('ok', 'fallback', 'cached')),
    'rate_limited', (select count(*) from public.ai_usage where created_at >= now() - make_interval(days => v_days) and status = 'rate_limited'),
    'cache_hits', (select count(*) from public.ai_usage where created_at >= now() - make_interval(days => v_days) and status = 'cached'),
    'avg_latency_ms', (select coalesce(round(avg(latency_ms)), 0) from public.ai_usage where created_at >= now() - make_interval(days => v_days) and latency_ms is not null and status <> 'rate_limited'),
    'intents', coalesce((select jsonb_agg(jsonb_build_object('intent', intent, 'count', n) order by n desc) from (
        select coalesce(intent, 'unknown') as intent, count(*) n from public.ai_usage
        where created_at >= now() - make_interval(days => v_days) and status <> 'rate_limited' group by 1 order by 2 desc limit 8) s), '[]'::jsonb),
    'daily', (select jsonb_agg(jsonb_build_object('day', to_char(d, 'YYYY-MM-DD'),
                'requests', (select count(*) from public.ai_usage u where u.created_at >= d at time zone 'Europe/Rome' and u.created_at < (d + interval '1 day') at time zone 'Europe/Rome'),
                'errors', (select count(*) from public.ai_usage u where u.status = 'error' and u.created_at >= d at time zone 'Europe/Rome' and u.created_at < (d + interval '1 day') at time zone 'Europe/Rome'))
              order by d)
              from generate_series(date_trunc('day', now() at time zone 'Europe/Rome') - make_interval(days => least(v_days, 60) - 1),
                                   date_trunc('day', now() at time zone 'Europe/Rome'), interval '1 day') d),
    'conversions', jsonb_build_object(
      'result_clicks', (select count(*) from public.analytics_events where event_type = 'ai_result_click' and created_at >= now() - make_interval(days => v_days)),
      'reservations', (select count(*) from public.reservations where source = 'ai' and created_at >= now() - make_interval(days => v_days)),
      'coupon_claims', (select count(*) from public.coupon_claims where source = 'ai' and claimed_at >= now() - make_interval(days => v_days)),
      'map_opens', (select count(*) from public.analytics_events where event_type = 'ai_map_open' and created_at >= now() - make_interval(days => v_days))),
    'active_sessions', (select count(*) from public.ai_chat_sessions where expires_at > now()));
end $$;

-- "Clienti arrivati dall'AI" (ristoratori Premium/Top): solo eventi reali con origine AI
create or replace function public.restaurant_ai_stats(p_restaurant uuid, p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_since timestamptz := now() - make_interval(days => least(greatest(coalesce(p_days, 30), 1), 365));
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if not public.is_admin() and not public.restaurant_has_feature(p_restaurant, 'advanced_analytics') then
    raise exception 'PLAN_FEATURE:advanced_analytics' using hint = 'upgrade';
  end if;
  return jsonb_build_object(
    'profile_views', (select count(*) from public.analytics_events where restaurant_id = p_restaurant and event_type = 'restaurant_view' and source = 'ai' and created_at >= v_since),
    'result_clicks', (select count(*) from public.analytics_events where restaurant_id = p_restaurant and event_type = 'ai_result_click' and created_at >= v_since),
    'directions_clicks', (select count(*) from public.analytics_events where restaurant_id = p_restaurant and event_type = 'directions_click' and source = 'ai' and created_at >= v_since),
    'phone_clicks', (select count(*) from public.analytics_events where restaurant_id = p_restaurant and event_type = 'phone_click' and source = 'ai' and created_at >= v_since),
    'reservations', (select count(*) from public.reservations where restaurant_id = p_restaurant and source = 'ai' and created_at >= v_since),
    'coupon_claims', (select count(*) from public.coupon_claims where restaurant_id = p_restaurant and source = 'ai' and claimed_at >= v_since));
end $$;

-- ════════════════════════════════════════════════════════════════════
--  5. ANALYTICS: eventi ai_* (anche senza ristorante) e coupon con origine
-- ════════════════════════════════════════════════════════════════════
create or replace function public.track_event(
  p_restaurant_id uuid,
  p_event_type public.analytics_event_type,
  p_session_id text default null,
  p_source text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_type text := case p_event_type::text
    when 'view' then 'restaurant_view' when 'click_phone' then 'phone_click' when 'click_whatsapp' then 'whatsapp_click'
    when 'click_directions' then 'directions_click' when 'click_menu' then 'menu_view' when 'click_reservation' then 'reservation_start'
    when 'click_website' then 'website_click' when 'click_social' then 'social_click' when 'coupon_reveal' then 'offer_view'
    else p_event_type::text end;
  v_meta jsonb := coalesce(p_metadata, '{}'::jsonb);
  k text;
begin
  -- Conversioni e impression sponsorizzate: solo lato server
  if v_type in ('reservation_completed', 'coupon_claim', 'coupon_redeem', 'sponsored_impression', 'sponsored_click') then return; end if;
  if p_restaurant_id is null then
    if v_type <> 'map_view' and v_type not like 'ai\_%' then return; end if;
  elsif not exists (select 1 from public.restaurants where id = p_restaurant_id and is_active) then
    return;
  end if;
  if jsonb_typeof(v_meta) <> 'object' then v_meta := '{}'::jsonb; end if;
  for k in select jsonb_object_keys(v_meta) loop
    if k ~* '(lat|lng|lon|coord|position|location|address|email|phone|name|message|text|query)' then v_meta := v_meta - k; end if;
  end loop;
  if pg_column_size(v_meta) > 2000 then v_meta := '{}'::jsonb; end if;
  insert into public.analytics_events (restaurant_id, event_type, user_id, session_id, source, metadata)
  values (p_restaurant_id, v_type::public.analytics_event_type, null, left(p_session_id, 64), left(p_source, 40), v_meta);
end $$;

alter function public.claim_coupon(uuid, text) rename to claim_coupon_core;
revoke all on function public.claim_coupon_core(uuid, text) from public, anon, authenticated;

create or replace function public.claim_coupon(p_coupon_id uuid, p_email text default null, p_source text default 'web')
returns jsonb language plpgsql security definer set search_path = public as $$
declare v jsonb;
begin
  v := public.claim_coupon_core(p_coupon_id, p_email);
  if p_source in ('ai', 'app') and not coalesce((v ->> 'already')::boolean, false) then
    update public.coupon_claims set source = p_source where claim_code = v ->> 'claim_code' and source = 'web';
  end if;
  return v;
end $$;

-- Analytics del ristorante: le prenotazioni online includono quelle arrivate dall'assistente
create or replace function public.restaurant_analytics(p_restaurant_id uuid, p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_days int := least(greatest(coalesce(p_days, 30), 1), 365);
  v_since timestamptz := now() - make_interval(days => v_days);
  v_adv boolean;
  v_events jsonb; v_res jsonb; v_cou jsonb; v_daily jsonb := '[]'::jsonb; v_sources jsonb := '{}'::jsonb;
begin
  if not public.can_manage_restaurant(p_restaurant_id) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  perform public.assert_feature(p_restaurant_id, 'analytics_enabled');
  v_adv := public.is_admin() or public.restaurant_has_feature(p_restaurant_id, 'advanced_analytics');

  select coalesce(jsonb_object_agg(event_type, n), '{}'::jsonb) into v_events from (
    select event_type::text, count(*) n from public.analytics_events
    where restaurant_id = p_restaurant_id and created_at >= v_since group by event_type) e;

  select jsonb_build_object(
    'total', count(*) filter (where source in ('web', 'app', 'ai')),
    'manual', count(*) filter (where source in ('restaurant', 'admin')),
    'pending', count(*) filter (where status = 'pending'),
    'confirmed', count(*) filter (where status = 'confirmed'),
    'completed', count(*) filter (where status = 'completed'),
    'no_show', count(*) filter (where status = 'no_show'),
    'cancelled', count(*) filter (where status in ('cancelled', 'rejected')),
    'covers', coalesce(sum(party_size) filter (where status in ('confirmed', 'completed')), 0))
  into v_res from public.reservations where restaurant_id = p_restaurant_id and created_at >= v_since;

  select jsonb_build_object(
    'claimed', (select count(*) from public.coupon_claims where restaurant_id = p_restaurant_id and claimed_at >= v_since),
    'redeemed', (select count(*) from public.coupon_claims where restaurant_id = p_restaurant_id and redeemed_at >= v_since))
  into v_cou;

  if v_adv then
    select coalesce(jsonb_agg(jsonb_build_object('date', d::date, 'views', coalesce(v.views, 0), 'contacts', coalesce(v.contacts, 0)) order by d), '[]'::jsonb)
    into v_daily
    from generate_series((now() - make_interval(days => v_days - 1))::date, now()::date, interval '1 day') d
    left join (
      select created_at::date as day,
             count(*) filter (where event_type = 'restaurant_view') as views,
             count(*) filter (where event_type in ('phone_click', 'whatsapp_click', 'directions_click', 'reservation_start')) as contacts
      from public.analytics_events where restaurant_id = p_restaurant_id and created_at >= v_since group by 1
    ) v on v.day = d::date;
    select coalesce(jsonb_object_agg(src, n), '{}'::jsonb) into v_sources from (
      select coalesce(source, 'direct') src, count(*) n from public.analytics_events
      where restaurant_id = p_restaurant_id and created_at >= v_since and event_type = 'restaurant_view' group by 1) s;
  end if;

  return jsonb_build_object('days', v_days, 'advanced', v_adv, 'events', v_events, 'reservations', v_res,
                            'coupons', v_cou, 'daily', v_daily, 'sources', v_sources);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  6. RLS E PRIVILEGI
-- ════════════════════════════════════════════════════════════════════
alter table public.ai_chat_sessions    enable row level security;
alter table public.ai_chat_messages    enable row level security;
alter table public.ai_user_preferences enable row level security;
alter table public.ai_usage            enable row level security;
alter table public.ai_cache            enable row level security;

-- Conversazioni: l'utente registrato vede ed elimina solo le proprie; gli ospiti passano dal backend
create policy "ai_sessions_own_read" on public.ai_chat_sessions for select to authenticated using (user_id = auth.uid());
create policy "ai_sessions_own_delete" on public.ai_chat_sessions for delete to authenticated using (user_id = auth.uid());
create policy "ai_messages_own_read" on public.ai_chat_messages for select to authenticated
  using (exists (select 1 from public.ai_chat_sessions s where s.id = chat_session_id and s.user_id = auth.uid()));
-- Preferenze: solo il titolare, modificabili ed eliminabili
create policy "ai_prefs_own" on public.ai_user_preferences for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
-- Utilizzo e costi: solo Admin. Cache: nessun accesso dal client.
create policy "ai_usage_admin" on public.ai_usage for select to authenticated using (public.is_admin());

grant select, delete on public.ai_chat_sessions to authenticated;
grant select on public.ai_chat_messages to authenticated;
grant select, insert, update, delete on public.ai_user_preferences to authenticated;
grant select on public.ai_usage to authenticated;
revoke all on public.ai_cache from anon, authenticated;
revoke insert, update on public.ai_chat_sessions, public.ai_chat_messages from anon, authenticated;
revoke insert, update, delete on public.ai_usage from anon, authenticated;

do $$ declare f text;
begin
  foreach f in array array[
    'ai_search_restaurants(jsonb)', 'ai_search_menu(jsonb)', 'ai_search_offers(jsonb)', 'ai_restaurant_detail(text)', 'ai_catalog()',
    'ai_session_open(text, uuid, uuid)', 'ai_session_append(uuid, text, text, jsonb, jsonb)', 'ai_session_delete(text, uuid)',
    'ai_rate_check(uuid, text, text)', 'ai_log_usage(jsonb)', 'ai_runtime_config()', 'ai_cache_get(text)', 'ai_cache_put(text, jsonb, int)', 'ai_user_context(uuid)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;
grant execute on function public.ai_admin_stats(int), public.restaurant_ai_stats(uuid, int), public.ai_purge() to authenticated, service_role;
revoke all on function public.ai_admin_stats(int), public.restaurant_ai_stats(uuid, int), public.ai_purge() from anon;
grant execute on function public.restaurant_open_status(uuid, timestamptz), public.restaurant_open_in_window(uuid, date, time, time) to anon, authenticated, service_role;
grant execute on function public.claim_coupon(uuid, text, text) to anon, authenticated;
