-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0006 · Privilegi espliciti per la Data API
--  I progetti Supabase recenti possono non concedere automaticamente
--  i privilegi su public ad anon/authenticated. Li dichiariamo qui in
--  modo esplicito: la sicurezza effettiva resta affidata alle RLS.
-- ════════════════════════════════════════════════════════════════════

grant usage on schema public to anon, authenticated;

-- Lettura pubblica (filtrata dalle policy RLS)
grant select on
  public.regions, public.provinces, public.cities, public.categories, public.subscription_plans,
  public.restaurants, public.restaurant_categories, public.restaurant_images, public.restaurant_hours,
  public.menus, public.menu_categories, public.menu_items,
  public.offers, public.coupons, public.sponsored_restaurants
to anon, authenticated;

-- Scrittura per utenti autenticati (ogni riga è comunque vincolata dalle RLS)
grant insert, update, delete on
  public.regions, public.provinces, public.cities, public.categories, public.subscription_plans,
  public.restaurants, public.restaurant_categories, public.restaurant_images, public.restaurant_hours,
  public.menus, public.menu_categories, public.menu_items,
  public.offers, public.coupons, public.sponsored_restaurants,
  public.favorites, public.restaurant_claims, public.subscriptions, public.coupon_redemptions
to authenticated;

grant select on
  public.profiles, public.favorites, public.restaurant_claims, public.subscriptions,
  public.coupon_redemptions, public.analytics_events
to authenticated;
grant update, delete on public.profiles to authenticated;

-- analytics_events: nessun INSERT diretto, solo tramite RPC track_event (security definer)
revoke insert, update, delete on public.analytics_events from anon, authenticated;

-- Funzioni helper usate nelle policy
grant execute on function public.is_admin(), public.owns_restaurant(uuid),
  public.can_manage_restaurant(uuid), public.current_user_role() to anon, authenticated;
