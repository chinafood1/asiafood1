-- ════════════════════════════════════════════════════════════════════
--  FASE 12 · GO-TO-MARKET — valori enum (in una migrazione separata:
--  Postgres non permette di usare un valore enum nella stessa transazione in cui viene aggiunto)
-- ════════════════════════════════════════════════════════════════════
-- Scansione di un QR del kit ristorante (profilo, menu, recensioni, prenotazione, offerte). Scritto solo dal backend
-- tramite track_qr_scan(): nessun dato personale, solo il tipo di QR.
alter type public.analytics_event_type add value if not exists 'qr_scan';
