-- ════════════════════════════════════════════════════════════════════
--  FASE 7 · Fidelizzazione: recensioni, AsiaPoints, rewards, referral,
--  notifiche (in-app, push, email), campagne, badge, retention.
--
--  Principi:
--  • Tutto ciò che vale qualcosa (punti, badge, "verificata", referral
--    completato, invio campagne) si decide SOLO qui, lato server.
--  • Idempotenza: la stessa azione non produce mai due volte punti o notifiche.
--  • I punti non sono denaro: non convertibili, non prelevabili.
--  • Comunicazioni essenziali separate dal marketing (opt-in esplicito).
-- ════════════════════════════════════════════════════════════════════

-- ════════════════════════════════════════════════════════════════════
--  1. CONFIGURAZIONE (Admin). Nessun valore di business nel codice.
-- ════════════════════════════════════════════════════════════════════
insert into public.platform_settings (key, value, description) values
  ('allow_unverified_reviews', 'true', 'Consente recensioni senza visita verificata (senza badge)'),
  ('auto_publish_verified_reviews', 'true', 'Pubblica subito le recensioni con visita verificata'),
  ('auto_publish_unverified_reviews', 'false', 'Pubblica subito le recensioni non verificate (false = coda di moderazione)'),
  ('review_cooldown_days', '90', 'Giorni minimi tra due recensioni dello stesso utente sullo stesso ristorante'),
  ('review_daily_limit', '5', 'Recensioni massime inviate da un utente in un giorno'),
  ('review_min_length', '20', 'Lunghezza minima del testo della recensione'),
  ('review_flag_threshold', '3', 'Segnalazioni distinte che mettono una recensione in revisione'),
  ('review_verification_window_days', '180', 'Giorni entro cui una visita (prenotazione/coupon) rende verificata la recensione'),
  ('review_request_delay_hours', '2', 'Ore dopo la visita completata per chiedere una recensione'),
  ('loyalty_enabled', 'true', 'Programma punti attivo'),
  ('loyalty_program_name', '"AsiaPoints"', 'Nome del programma punti'),
  ('points_expire_after_months', 'null', 'Scadenza dei punti in mesi (null = nessuna scadenza)'),
  ('referral_enabled', 'true', 'Programma "Invita un amico" attivo'),
  ('referral_max_per_month', '20', 'Inviti registrati massimi per utente al mese'),
  ('referral_signup_window_days', '14', 'Giorni dalla registrazione entro cui si può inserire un codice invito'),
  ('reservation_reminder_hours', '[24, 2]', 'Promemoria prenotazione: ore prima dell''arrivo'),
  ('coupon_expiry_reminder_hours', '24', 'Promemoria coupon in scadenza: ore prima della scadenza'),
  ('campaign_max_per_user_week', '3', 'Notifiche promozionali massime per utente in 7 giorni (tutte le campagne)'),
  ('campaign_max_recipients', '5000', 'Destinatari massimi per singola campagna'),
  ('push_enabled', 'true', 'Notifiche push attive')
on conflict (key) do nothing;

-- Funzioni di piano per le campagne del ristoratore (feature flag esistenti, niente nomi di piano nel codice)
insert into public.plan_features (plan_code, feature_key, enabled, limit_value)
select p.code, f.key,
       case p.code when 'free' then f.free when 'business' then f.business when 'premium' then f.premium else f.top end,
       case p.code when 'free' then f.l_free when 'business' then f.l_business when 'premium' then f.l_premium else f.l_top end
from public.subscription_plans p
cross join (values
  ('push_campaigns_enabled', false, false, true, true, null::int, null::int, null::int, null::int),
  ('monthly_campaign_limit', false, false, true, true, 0, 0, 2, 8)
) as f(key, free, business, premium, top, l_free, l_business, l_premium, l_top)
where p.code in ('free', 'business', 'premium', 'top')
on conflict (plan_code, feature_key) do nothing;

-- Email della Fase 7 (coda esistente; rispettano le preferenze)
alter table public.email_outbox drop constraint if exists email_outbox_event_type_check;
alter table public.email_outbox add constraint email_outbox_event_type_check check (event_type in (
  'reservation_created', 'reservation_confirmed', 'reservation_rejected', 'reservation_cancelled', 'reservation_new_for_restaurant',
  'billing_welcome', 'billing_trial_started', 'billing_trial_ending', 'billing_subscription_activated',
  'billing_payment_succeeded', 'billing_payment_failed', 'billing_subscription_cancelled',
  'reservation_reminder', 'review_request', 'referral_completed', 'reward_redeemed', 'coupon_expiring', 'marketing_campaign'
));

-- ════════════════════════════════════════════════════════════════════
--  2. AUDIT ADMIN, ATTIVITÀ UTENTI, NOME PUBBLICO
-- ════════════════════════════════════════════════════════════════════
create table public.admin_audit_logs (
  id          bigint generated always as identity primary key,
  admin_id    uuid references public.profiles(id) on delete set null,
  action      text not null check (char_length(action) <= 60),
  entity_type text not null check (char_length(entity_type) <= 40),
  entity_id   text,
  details     jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);
create index admin_audit_logs_created_idx on public.admin_audit_logs(created_at desc);

create or replace function public.audit_admin(p_action text, p_entity text, p_id text, p_details jsonb default '{}'::jsonb)
returns void language sql security definer set search_path = public as $$
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
  values (auth.uid(), left(p_action, 60), left(p_entity, 40), p_id, coalesce(p_details, '{}'::jsonb));
$$;

-- Giorni di attività (DAU/WAU/MAU): un record per utente al giorno, niente dettagli di navigazione
create table public.user_activity_days (
  user_id uuid not null references public.profiles(id) on delete cascade,
  day     date not null,
  primary key (user_id, day)
);
create index user_activity_days_day_idx on public.user_activity_days(day);

create or replace function public.touch_activity(p_user uuid)
returns void language sql security definer set search_path = public as $$
  insert into public.user_activity_days (user_id, day)
  select p_user, (now() at time zone 'Europe/Rome')::date where p_user is not null
  on conflict do nothing;
$$;

-- Accesso autenticato all'app (una volta al giorno): è l'"evento significativo" di base per DAU/WAU/MAU
create or replace function public.record_activity()
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  perform public.touch_activity(auth.uid());
end $$;

-- Nome mostrato pubblicamente (recensioni): mai email, telefono o cognome completo
alter table public.profiles add column if not exists display_name text
  check (display_name is null or (char_length(trim(display_name)) between 2 and 40 and display_name !~ '@' and display_name !~ '[0-9]{5,}'));

create or replace function public.public_display_name(p_user uuid)
returns text language sql stable security definer set search_path = public as $$
  select coalesce(
    nullif(trim(p.display_name), ''),
    nullif(trim(split_part(trim(coalesce(p.full_name, '')), ' ', 1)
      || case when split_part(trim(coalesce(p.full_name, '')), ' ', 2) <> '' then ' ' || upper(left(split_part(trim(p.full_name), ' ', 2), 1)) || '.' else '' end), ''),
    'Utente')
  from public.profiles p where p.id = p_user;
$$;

-- ════════════════════════════════════════════════════════════════════
--  3. NOTIFICHE: in-app (tabella esistente), preferenze, push, log invii
-- ════════════════════════════════════════════════════════════════════
-- notifications esiste dalla Fase 4 (body = messaggio, link = action_url): si aggiungono metadati e scadenza
alter table public.notifications add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.notifications add column if not exists expires_at timestamptz;
create index if not exists notifications_unread_idx on public.notifications(user_id) where read_at is null;

create table public.notification_preferences (
  user_id               uuid primary key references public.profiles(id) on delete cascade,
  -- Essenziali (transazionali): attive di default, disattivabili
  reservation_updates   boolean not null default true,
  reservation_reminders boolean not null default true,
  coupon_expiry         boolean not null default true,
  loyalty_updates       boolean not null default true,
  referral_updates      boolean not null default true,
  -- Promozionali: solo con scelta esplicita
  new_offers            boolean not null default false,
  favorite_restaurants  boolean not null default false,
  marketing             boolean not null default false,
  -- Canali
  push_enabled          boolean not null default false,
  email_enabled         boolean not null default true,
  push_prompt_dismissed_at timestamptz,
  updated_at            timestamptz not null default now()
);
create trigger notification_preferences_updated_at before update on public.notification_preferences
  for each row execute function public.set_updated_at();

create table public.push_subscriptions (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  endpoint     text not null unique check (endpoint ~ '^https://' and char_length(endpoint) <= 1000),
  p256dh       text not null check (p256dh ~ '^[A-Za-z0-9_-]{40,200}={0,2}$'),
  auth         text not null check (auth ~ '^[A-Za-z0-9_-]{10,60}={0,2}$'),
  device_name  text check (char_length(device_name) <= 80),
  platform     text check (char_length(platform) <= 40),
  is_active    boolean not null default true,
  failure_count int not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  last_used_at timestamptz
);
create index push_subscriptions_user_idx on public.push_subscriptions(user_id) where is_active;
create trigger push_subscriptions_updated_at before update on public.push_subscriptions
  for each row execute function public.set_updated_at();

-- Log anti-duplicato di ogni invio programmato (promemoria, richieste recensione, avvisi follower…)
create table public.notification_delivery_log (
  id              bigint generated always as identity primary key,
  dedupe_key      text not null unique check (char_length(dedupe_key) <= 160),
  user_id         uuid references public.profiles(id) on delete cascade,
  kind            text not null check (char_length(kind) <= 40),
  status          text not null check (status in ('sent', 'skipped')),
  channels        text[] not null default '{}',
  notification_id uuid references public.notifications(id) on delete set null,
  created_at      timestamptz not null default now()
);
create index notification_delivery_log_user_idx on public.notification_delivery_log(user_id, created_at desc);

-- Coda push: la svuota la funzione server (Web Push VAPID). Mai endpoint verso il browser di altri.
create table public.push_outbox (
  id                   bigint generated always as identity primary key,
  user_id              uuid not null references public.profiles(id) on delete cascade,
  notification_id      uuid references public.notifications(id) on delete set null,
  campaign_delivery_id uuid,
  title                text not null check (char_length(title) <= 140),
  body                 text check (char_length(body) <= 500),
  url                  text check (url is null or url ~ '^/'),
  tag                  text check (char_length(tag) <= 80),
  status               text not null default 'pending' check (status in ('pending', 'sending', 'sent', 'failed', 'skipped')),
  attempts             int not null default 0,
  error                text,
  created_at           timestamptz not null default now(),
  sent_at              timestamptz
);
create index push_outbox_pending_idx on public.push_outbox(status, created_at) where status in ('pending', 'sending');

-- Preferenze sempre presenti (valori di default prudenti)
create or replace function public.user_prefs(p_user uuid)
returns public.notification_preferences language plpgsql security definer set search_path = public as $$
declare x public.notification_preferences;
begin
  select * into x from public.notification_preferences where user_id = p_user;
  if not found then
    insert into public.notification_preferences (user_id) values (p_user) on conflict (user_id) do nothing;
    select * into x from public.notification_preferences where user_id = p_user;
  end if;
  return x;
end $$;

/**
 * Dispatcher centrale. p_pref = chiave di preferenza (null = comunicazione essenziale non disattivabile).
 * p_dedupe = chiave anti-duplicato. Restituisce l'id della notifica o null se non inviata.
 */
create or replace function public.notify_user(
  p_user uuid, p_type text, p_title text, p_body text, p_link text,
  p_pref text default null, p_dedupe text default null, p_metadata jsonb default '{}'::jsonb,
  p_restaurant uuid default null, p_email_event text default null, p_email_payload jsonb default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare
  pr public.notification_preferences;
  v_log bigint;
  v_id uuid;
  v_channels text[] := array['in_app'];
  v_email text;
begin
  if p_user is null then return null; end if;
  if exists (select 1 from public.profiles where id = p_user and is_blocked) then return null; end if;
  if p_dedupe is not null then
    insert into public.notification_delivery_log (dedupe_key, user_id, kind, status)
    values (left(p_dedupe, 160), p_user, left(p_type, 40), 'sent')
    on conflict (dedupe_key) do nothing returning id into v_log;
    if v_log is null then return null; end if;
  end if;
  pr := public.user_prefs(p_user);
  if p_pref is not null and coalesce((to_jsonb(pr) ->> p_pref)::boolean, false) = false then
    if v_log is not null then update public.notification_delivery_log set status = 'skipped' where id = v_log; end if;
    return null;
  end if;
  insert into public.notifications (user_id, restaurant_id, type, title, body, link, metadata)
  values (p_user, p_restaurant, left(p_type, 40), left(p_title, 140), left(p_body, 500), p_link, coalesce(p_metadata, '{}'::jsonb))
  returning id into v_id;
  if pr.push_enabled and public.billing_setting_bool('push_enabled', true)
     and exists (select 1 from public.push_subscriptions s where s.user_id = p_user and s.is_active) then
    insert into public.push_outbox (user_id, notification_id, title, body, url, tag)
    values (p_user, v_id, left(p_title, 140), left(p_body, 500), p_link, left(p_type, 40));
    v_channels := array_append(v_channels, 'push');
  end if;
  if p_email_event is not null and pr.email_enabled then
    select email into v_email from public.profiles where id = p_user;
    if v_email is not null then
      perform public.enqueue_email(p_email_event, v_email, coalesce(p_email_payload, '{}'::jsonb) || jsonb_build_object('title', p_title, 'body', p_body, 'link', p_link), p_restaurant, null);
      v_channels := array_append(v_channels, 'email');
    end if;
  end if;
  if v_log is not null then update public.notification_delivery_log set channels = v_channels, notification_id = v_id where id = v_log; end if;
  return v_id;
end $$;

-- Iscrizione push del dispositivo (l'utente può averne più d'uno)
create or replace function public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text, p_device text default null, p_platform text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Accedi per attivare le notifiche.' using errcode = '42501'; end if;
  insert into public.push_subscriptions (user_id, endpoint, p256dh, auth, device_name, platform, is_active, failure_count)
  values (v_uid, p_endpoint, p_p256dh, p_auth, left(p_device, 80), left(p_platform, 40), true, 0)
  on conflict (endpoint) do update set user_id = v_uid, p256dh = excluded.p256dh, auth = excluded.auth,
    device_name = excluded.device_name, platform = excluded.platform, is_active = true, failure_count = 0
  returning id into v_id;
  -- Massimo 10 dispositivi attivi: si disattivano i più vecchi
  update public.push_subscriptions set is_active = false
   where user_id = v_uid and is_active and id not in (
     select id from public.push_subscriptions where user_id = v_uid and is_active order by updated_at desc limit 10);
  perform public.user_prefs(v_uid);
  update public.notification_preferences set push_enabled = true where user_id = v_uid;
  return v_id;
end $$;

create or replace function public.remove_push_subscription(p_endpoint text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  update public.push_subscriptions set is_active = false where endpoint = p_endpoint and user_id = auth.uid();
  if not exists (select 1 from public.push_subscriptions where user_id = auth.uid() and is_active) then
    update public.notification_preferences set push_enabled = false where user_id = auth.uid();
  end if;
end $$;

-- Coda push per il server (solo service_role): prende un blocco e lo marca "sending"
create or replace function public.push_claim_batch(p_limit int default 100)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v jsonb;
begin
  perform public.assert_service();
  with picked as (
    select o.id from public.push_outbox o
    where o.status = 'pending' or (o.status = 'sending' and o.created_at < now() - interval '15 minutes' and o.attempts < 3)
    order by o.created_at limit least(greatest(coalesce(p_limit, 100), 1), 500)
    for update skip locked
  ), upd as (
    update public.push_outbox o set status = 'sending', attempts = o.attempts + 1
    from picked where o.id = picked.id returning o.*
  )
  select coalesce(jsonb_agg(jsonb_build_object(
    'id', u.id, 'title', u.title, 'body', u.body, 'url', u.url, 'tag', u.tag,
    'subscriptions', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'endpoint', s.endpoint, 'p256dh', s.p256dh, 'auth', s.auth))
                               from public.push_subscriptions s where s.user_id = u.user_id and s.is_active), '[]'::jsonb))), '[]'::jsonb)
  into v from upd u;
  return v;
end $$;

-- Esito dell'invio: [{id, sent: n, failed: n, gone: [subscription ids], error}]
create or replace function public.push_report(p jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare x jsonb; o public.push_outbox;
begin
  perform public.assert_service();
  for x in select * from jsonb_array_elements(coalesce(p, '[]'::jsonb)) loop
    select * into o from public.push_outbox where id = (x ->> 'id')::bigint;
    if not found then continue; end if;
    update public.push_subscriptions set is_active = false
     where id in (select (g #>> '{}')::uuid from jsonb_array_elements(coalesce(x -> 'gone', '[]'::jsonb)) g);
    if coalesce((x ->> 'sent')::int, 0) > 0 then
      update public.push_outbox set status = 'sent', sent_at = now(), error = null where id = o.id;
      update public.push_subscriptions set last_used_at = now(), failure_count = 0
       where user_id = o.user_id and is_active;
      if o.campaign_delivery_id is not null then
        update public.campaign_deliveries set status = 'sent', sent_at = now(), error = null where id = o.campaign_delivery_id;
      end if;
    else
      update public.push_outbox set status = case when coalesce((x ->> 'no_subscription')::boolean, false) then 'skipped' else 'failed' end,
             error = left(coalesce(x ->> 'error', 'send_failed'), 200) where id = o.id;
      if o.campaign_delivery_id is not null then
        update public.campaign_deliveries set status = case when coalesce((x ->> 'no_subscription')::boolean, false) then 'skipped' else 'failed' end,
               error = left(coalesce(x ->> 'error', 'send_failed'), 200) where id = o.campaign_delivery_id;
      end if;
    end if;
  end loop;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  4. LOYALTY (AsiaPoints): punti promozionali, NON denaro
-- ════════════════════════════════════════════════════════════════════
create table public.loyalty_levels (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null unique check (char_length(name) between 2 and 40),
  min_lifetime_points int not null check (min_lifetime_points >= 0),
  benefits_json       jsonb not null default '[]'::jsonb,   -- nessun vantaggio promesso finché non esiste davvero
  display_order       int not null default 0,
  is_active           boolean not null default true
);
insert into public.loyalty_levels (name, min_lifetime_points, display_order) values
  ('Explorer', 0, 1), ('Foodie', 500, 2), ('Insider', 1500, 3), ('Master', 4000, 4);

create table public.loyalty_accounts (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null unique references public.profiles(id) on delete cascade,
  points_balance  int not null default 0 check (points_balance >= 0),
  lifetime_points int not null default 0 check (lifetime_points >= 0),
  level           text not null default 'Explorer',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create trigger loyalty_accounts_updated_at before update on public.loyalty_accounts
  for each row execute function public.set_updated_at();

create table public.loyalty_rules (
  id            uuid primary key default gen_random_uuid(),
  event_key     text not null unique check (event_key ~ '^[a-z][a-z0-9_]{2,40}$'),
  points        int not null default 0 check (points between 0 and 100000),
  daily_limit   int check (daily_limit is null or daily_limit >= 0),
  monthly_limit int check (monthly_limit is null or monthly_limit >= 0),
  enabled       boolean not null default true,
  description   text check (char_length(description) <= 200),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create trigger loyalty_rules_updated_at before update on public.loyalty_rules
  for each row execute function public.set_updated_at();
-- Solo azioni reali e verificabili: niente punti per click o visite
insert into public.loyalty_rules (event_key, points, daily_limit, monthly_limit, description) values
  ('account_created', 50, null, null, 'Registrazione'),
  ('profile_completed', 50, null, null, 'Profilo completo (nome e cognome, telefono, comune)'),
  ('reservation_completed', 100, 3, 20, 'Prenotazione completata presso un ristorante'),
  ('verified_review', 50, 3, 10, 'Recensione con visita verificata pubblicata (mai in base al voto)'),
  ('coupon_redeemed', 20, 3, 20, 'Coupon utilizzato in cassa'),
  ('referral_completed', 150, null, 10, 'Amico invitato che completa la prima visita'),
  ('referral_welcome', 50, null, null, 'Benvenuto per chi si registra con un invito, dopo la prima visita');

create table public.loyalty_transactions (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid not null references public.profiles(id) on delete cascade,
  type             text not null check (type in ('earn', 'redeem', 'expire', 'adjustment', 'bonus', 'referral')),
  points           int not null check (points <> 0),
  balance_after    int not null check (balance_after >= 0),
  event_key        text not null,
  source_type      text not null check (source_type in ('reservation', 'review', 'coupon', 'referral', 'campaign', 'admin', 'profile', 'reward', 'achievement', 'other')),
  source_id        uuid,
  description      text check (char_length(description) <= 200),
  status           text not null default 'completed' check (status in ('completed', 'reversed')),
  points_remaining int not null default 0,   -- per la scadenza FIFO dei punti guadagnati
  created_at       timestamptz not null default now(),
  expires_at       timestamptz
);
create index loyalty_transactions_user_idx on public.loyalty_transactions(user_id, created_at desc);
-- Idempotenza: la stessa fonte non assegna mai due volte lo stesso evento
create unique index loyalty_transactions_idem_idx on public.loyalty_transactions(user_id, event_key, source_type, source_id) where source_id is not null;
create index loyalty_transactions_expiry_idx on public.loyalty_transactions(expires_at) where points_remaining > 0 and expires_at is not null;

create table public.rewards (
  id            uuid primary key default gen_random_uuid(),
  title         text not null check (char_length(title) between 3 and 100),
  description   text check (char_length(description) <= 500),
  points_cost   int not null check (points_cost > 0),
  reward_type   text not null check (reward_type in ('platform_coupon', 'restaurant_coupon', 'bonus', 'perk', 'other')),
  restaurant_id uuid references public.restaurants(id) on delete cascade,
  coupon_id     uuid references public.coupons(id) on delete set null,
  stock         int check (stock is null or stock >= 0),
  per_user_limit int check (per_user_limit is null or per_user_limit > 0),
  starts_at     timestamptz not null default now(),
  ends_at       timestamptz,
  is_active     boolean not null default true,
  image_url     text,
  terms         text check (char_length(terms) <= 1000),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  check (reward_type <> 'restaurant_coupon' or coupon_id is not null)
);
create trigger rewards_updated_at before update on public.rewards for each row execute function public.set_updated_at();

create table public.reward_redemptions (
  id              uuid primary key default gen_random_uuid(),
  reward_id       uuid not null references public.rewards(id) on delete restrict,
  user_id         uuid not null references public.profiles(id) on delete cascade,
  points_spent    int not null check (points_spent > 0),
  redemption_code text not null unique,
  coupon_claim_id uuid references public.coupon_claims(id) on delete set null,
  status          text not null default 'claimed' check (status in ('claimed', 'used', 'expired', 'cancelled')),
  created_at      timestamptz not null default now(),
  redeemed_at     timestamptz,
  expires_at      timestamptz
);
create index reward_redemptions_user_idx on public.reward_redemptions(user_id, created_at desc);

create or replace function public.loyalty_level_for(p_lifetime int)
returns text language sql stable security definer set search_path = public as $$
  select coalesce((select name from public.loyalty_levels where is_active and min_lifetime_points <= p_lifetime
                   order by min_lifetime_points desc limit 1), 'Explorer');
$$;

create or replace function public.loyalty_account(p_user uuid)
returns public.loyalty_accounts language plpgsql security definer set search_path = public as $$
declare a public.loyalty_accounts;
begin
  insert into public.loyalty_accounts (user_id) values (p_user) on conflict (user_id) do nothing;
  select * into a from public.loyalty_accounts where user_id = p_user for update;
  return a;
end $$;

/**
 * Assegna punti (SOLO server). Idempotente su (utente, evento, fonte). Limiti giornalieri/mensili dalla regola.
 * p_points = punti espliciti (badge), altrimenti quelli della regola. Restituisce i punti assegnati (0 se nessuno).
 */
create or replace function public.loyalty_award(p_user uuid, p_event text, p_source_type text, p_source_id uuid,
                                                p_description text default null, p_points int default null)
returns int language plpgsql security definer set search_path = public as $$
declare
  r public.loyalty_rules;
  a public.loyalty_accounts;
  v_points int;
  v_id uuid;
  v_months int := public.billing_setting_int('points_expire_after_months', 0);
  v_name text := public.billing_setting_text('loyalty_program_name', 'AsiaPoints');
  v_type text;
begin
  if p_user is null or not public.billing_setting_bool('loyalty_enabled', true) then return 0; end if;
  if exists (select 1 from public.profiles where id = p_user and is_blocked) then return 0; end if;
  if p_points is not null then
    v_points := p_points;
  else
    select * into r from public.loyalty_rules where event_key = p_event;
    if not found or not r.enabled then return 0; end if;
    v_points := r.points;
    if r.daily_limit is not null and (select count(*) from public.loyalty_transactions
        where user_id = p_user and event_key = p_event and created_at >= date_trunc('day', now() at time zone 'Europe/Rome') at time zone 'Europe/Rome') >= r.daily_limit then
      return 0;
    end if;
    if r.monthly_limit is not null and (select count(*) from public.loyalty_transactions
        where user_id = p_user and event_key = p_event and created_at >= date_trunc('month', now() at time zone 'Europe/Rome') at time zone 'Europe/Rome') >= r.monthly_limit then
      return 0;
    end if;
  end if;
  if coalesce(v_points, 0) <= 0 then return 0; end if;
  a := public.loyalty_account(p_user);   -- blocca la riga del saldo
  v_type := case when p_event like 'referral%' then 'referral' when p_source_type = 'achievement' then 'bonus' else 'earn' end;
  insert into public.loyalty_transactions (user_id, type, points, balance_after, event_key, source_type, source_id, description, points_remaining, expires_at)
  values (p_user, v_type, v_points, a.points_balance + v_points, p_event, p_source_type, p_source_id, left(p_description, 200), v_points,
          case when v_months > 0 then now() + make_interval(months => v_months) end)
  on conflict (user_id, event_key, source_type, source_id) where source_id is not null do nothing
  returning id into v_id;
  if v_id is null then return 0; end if;
  update public.loyalty_accounts set points_balance = points_balance + v_points, lifetime_points = lifetime_points + v_points,
         level = public.loyalty_level_for(lifetime_points + v_points)
   where user_id = p_user;
  perform public.notify_user(p_user, 'loyalty', format('+%s %s', v_points, v_name), coalesce(p_description, 'Punti accreditati'),
    '/profile/loyalty', 'loyalty_updates', null, jsonb_build_object('points', v_points, 'event', p_event));
  return v_points;
end $$;

-- Consuma punti dalle transazioni più vecchie (serve alla scadenza FIFO)
create or replace function public.loyalty_consume(p_user uuid, p_points int)
returns void language plpgsql security definer set search_path = public as $$
declare t record; v_left int := p_points; v_take int;
begin
  for t in select id, points_remaining from public.loyalty_transactions
           where user_id = p_user and points_remaining > 0 order by coalesce(expires_at, 'infinity'::timestamptz), created_at for update loop
    exit when v_left <= 0;
    v_take := least(v_left, t.points_remaining);
    update public.loyalty_transactions set points_remaining = points_remaining - v_take where id = t.id;
    v_left := v_left - v_take;
  end loop;
end $$;

create or replace function public.gen_code(p_prefix text, p_len int)
returns text language sql volatile as $$
  select p_prefix || string_agg(substr('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 1 + floor(random() * 32)::int, 1), '')
  from generate_series(1, p_len);
$$;

/** Riscatto reward: transazione atomica (saldo e stock bloccati, niente saldo negativo). */
create or replace function public.redeem_reward(p_reward uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  rw public.rewards;
  a public.loyalty_accounts;
  v_code text;
  v_claim uuid;
  v_claimj jsonb;
  v_red uuid;
  v_name text := public.billing_setting_text('loyalty_program_name', 'AsiaPoints');
begin
  if v_uid is null then raise exception 'Accedi per riscattare i premi.' using errcode = '42501'; end if;
  if exists (select 1 from public.profiles where id = v_uid and is_blocked) then raise exception 'Account non abilitato.' using errcode = '42501'; end if;
  if not public.billing_setting_bool('loyalty_enabled', true) then raise exception 'Il programma punti non è attivo.'; end if;
  select * into rw from public.rewards where id = p_reward for update;
  if not found or not rw.is_active or rw.starts_at > now() or (rw.ends_at is not null and rw.ends_at <= now()) then
    raise exception 'Questo premio non è disponibile.';
  end if;
  if rw.stock is not null and rw.stock <= 0 then raise exception 'Premio esaurito.'; end if;
  if rw.per_user_limit is not null and (select count(*) from public.reward_redemptions
      where reward_id = rw.id and user_id = v_uid and status <> 'cancelled') >= rw.per_user_limit then
    raise exception 'Hai già riscattato questo premio il numero massimo di volte.';
  end if;
  a := public.loyalty_account(v_uid);
  if a.points_balance < rw.points_cost then
    raise exception 'Punti insufficienti: ti mancano % %.', rw.points_cost - a.points_balance, v_name using hint = 'insufficient_points';
  end if;
  if rw.reward_type = 'restaurant_coupon' then
    -- Coupon reale del ristorante: codice personale validato in cassa con il flusso esistente
    v_claimj := public.claim_coupon_core(rw.coupon_id, null);
    v_code := v_claimj ->> 'claim_code';
    select id into v_claim from public.coupon_claims where claim_code = v_code;
  else
    loop
      v_code := public.gen_code('AP-', 6);
      exit when not exists (select 1 from public.reward_redemptions where redemption_code = v_code);
    end loop;
  end if;
  perform public.loyalty_consume(v_uid, rw.points_cost);
  update public.loyalty_accounts set points_balance = points_balance - rw.points_cost where user_id = v_uid;
  insert into public.reward_redemptions (reward_id, user_id, points_spent, redemption_code, coupon_claim_id, expires_at)
  values (rw.id, v_uid, rw.points_cost, v_code, v_claim, coalesce(rw.ends_at, now() + interval '30 days'))
  returning id into v_red;
  insert into public.loyalty_transactions (user_id, type, points, balance_after, event_key, source_type, source_id, description)
  values (v_uid, 'redeem', -rw.points_cost, a.points_balance - rw.points_cost, 'reward_redeemed', 'reward', v_red, left('Premio: ' || rw.title, 200));
  if rw.stock is not null then update public.rewards set stock = stock - 1 where id = rw.id; end if;
  perform public.touch_activity(v_uid);
  perform public.notify_user(v_uid, 'loyalty', 'Premio riscattato', rw.title || ' · codice ' || v_code, '/profile/loyalty',
    null, 'reward_redeemed:' || v_red, jsonb_build_object('redemption_id', v_red), rw.restaurant_id,
    'reward_redeemed', jsonb_build_object('reward', rw.title, 'code', v_code));
  return jsonb_build_object('redemption_id', v_red, 'code', v_code, 'title', rw.title, 'points_spent', rw.points_cost,
    'balance', a.points_balance - rw.points_cost, 'expires_at', coalesce(rw.ends_at, now() + interval '30 days'));
end $$;

-- Wallet dell'utente: saldo, livello, prossimo livello, ultime transazioni (paginate)
create or replace function public.my_loyalty(p_limit int default 20, p_offset int default 0)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); a public.loyalty_accounts; nxt public.loyalty_levels;
begin
  if v_uid is null then raise exception 'Accedi per vedere i tuoi punti.' using errcode = '42501'; end if;
  insert into public.loyalty_accounts (user_id) values (v_uid) on conflict (user_id) do nothing;
  select * into a from public.loyalty_accounts where user_id = v_uid;
  select * into nxt from public.loyalty_levels where is_active and min_lifetime_points > a.lifetime_points order by min_lifetime_points limit 1;
  return jsonb_build_object(
    'program_name', public.billing_setting_text('loyalty_program_name', 'AsiaPoints'),
    'enabled', public.billing_setting_bool('loyalty_enabled', true),
    'balance', a.points_balance, 'lifetime', a.lifetime_points, 'level', a.level,
    'level_min', (select min_lifetime_points from public.loyalty_levels where name = a.level),
    'next_level', case when nxt.id is not null then jsonb_build_object('name', nxt.name, 'min', nxt.min_lifetime_points, 'missing', nxt.min_lifetime_points - a.lifetime_points) end,
    'expire_months', (select case when jsonb_typeof(value) = 'number' then (value #>> '{}')::int end from public.platform_settings where key = 'points_expire_after_months'),
    'expiring_soon', (select coalesce(sum(points_remaining), 0) from public.loyalty_transactions
                      where user_id = v_uid and points_remaining > 0 and expires_at is not null and expires_at < now() + interval '30 days'),
    'transactions', coalesce((select jsonb_agg(t order by t.created_at desc) from (
        select id, type, points, balance_after, event_key, source_type, description, created_at, expires_at
        from public.loyalty_transactions where user_id = v_uid order by created_at desc
        limit least(greatest(coalesce(p_limit, 20), 1), 50) offset greatest(coalesce(p_offset, 0), 0)) t), '[]'::jsonb),
    'transactions_total', (select count(*) from public.loyalty_transactions where user_id = v_uid),
    'redemptions', coalesce((select jsonb_agg(x order by x.created_at desc) from (
        select rr.id, rr.redemption_code, rr.status, rr.points_spent, rr.created_at, rr.expires_at, rw.title, rw.reward_type,
               (select slug from public.restaurants where id = rw.restaurant_id) as restaurant_slug
        from public.reward_redemptions rr join public.rewards rw on rw.id = rr.reward_id
        where rr.user_id = v_uid order by rr.created_at desc limit 10) x), '[]'::jsonb),
    'rules', coalesce((select jsonb_agg(jsonb_build_object('event_key', event_key, 'points', points, 'description', description) order by points desc)
                       from public.loyalty_rules where enabled and points > 0), '[]'::jsonb));
end $$;

-- Rettifica manuale (Admin), sempre tracciata
create or replace function public.admin_loyalty_adjust(p_user uuid, p_points int, p_reason text)
returns int language plpgsql security definer set search_path = public as $$
declare a public.loyalty_accounts;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if coalesce(p_points, 0) = 0 or abs(p_points) > 100000 then raise exception 'Valore non valido.'; end if;
  if char_length(trim(coalesce(p_reason, ''))) < 3 then raise exception 'Indica il motivo della rettifica.'; end if;
  a := public.loyalty_account(p_user);
  if a.points_balance + p_points < 0 then raise exception 'Il saldo non può diventare negativo (saldo attuale %).', a.points_balance; end if;
  if p_points < 0 then perform public.loyalty_consume(p_user, -p_points); end if;
  update public.loyalty_accounts set points_balance = points_balance + p_points,
         lifetime_points = lifetime_points + greatest(p_points, 0),
         level = public.loyalty_level_for(lifetime_points + greatest(p_points, 0))
   where user_id = p_user;
  insert into public.loyalty_transactions (user_id, type, points, balance_after, event_key, source_type, description, points_remaining)
  values (p_user, 'adjustment', p_points, a.points_balance + p_points, 'admin_adjustment', 'admin', left(trim(p_reason), 200), greatest(p_points, 0));
  perform public.audit_admin('loyalty_adjustment', 'user', p_user::text, jsonb_build_object('points', p_points, 'reason', left(trim(p_reason), 200)));
  return a.points_balance + p_points;
end $$;

-- Stato di un riscatto (Admin): usato o annullato (annullo = punti restituiti, una sola volta)
create or replace function public.admin_update_redemption(p_id uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
declare x public.reward_redemptions; a public.loyalty_accounts;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if p_status not in ('used', 'cancelled') then raise exception 'Stato non valido.'; end if;
  select * into x from public.reward_redemptions where id = p_id for update;
  if not found or x.status <> 'claimed' then raise exception 'Riscatto non modificabile.'; end if;
  update public.reward_redemptions set status = p_status, redeemed_at = case when p_status = 'used' then now() end where id = p_id;
  if p_status = 'cancelled' then
    a := public.loyalty_account(x.user_id);
    insert into public.loyalty_transactions (user_id, type, points, balance_after, event_key, source_type, source_id, description, points_remaining)
    values (x.user_id, 'adjustment', x.points_spent, a.points_balance + x.points_spent, 'redemption_refund', 'reward', x.id, 'Premio annullato: punti restituiti', x.points_spent)
    on conflict (user_id, event_key, source_type, source_id) where source_id is not null do nothing;
    if found then update public.loyalty_accounts set points_balance = points_balance + x.points_spent where user_id = x.user_id; end if;
    update public.rewards set stock = stock + 1 where id = x.reward_id and stock is not null;
  end if;
  perform public.audit_admin('redemption_' || p_status, 'reward_redemption', p_id::text, '{}'::jsonb);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  5. BADGE / ACHIEVEMENT (leggeri, assegnati solo dal server)
-- ════════════════════════════════════════════════════════════════════
create table public.achievements (
  id            uuid primary key default gen_random_uuid(),
  key           text not null unique check (key ~ '^[a-z][a-z0-9_]{2,40}$'),
  name          text not null check (char_length(name) <= 40),
  description   text check (char_length(description) <= 200),
  icon          text check (char_length(icon) <= 8),
  criteria_json jsonb not null,
  points_bonus  int not null default 0 check (points_bonus between 0 and 10000),
  is_active     boolean not null default true
);
insert into public.achievements (key, name, description, icon, criteria_json) values
  ('first_sushi', 'Primo sushi', 'Prima visita completata in un ristorante di sushi', '🍣', '{"type":"reservations_completed","count":1,"category":"sushi"}'),
  ('five_reservations', '5 prenotazioni', 'Cinque visite completate con AsiaFood', '🥢', '{"type":"reservations_completed","count":5}'),
  ('food_explorer', 'Food Explorer', 'Visite completate in 3 cucine diverse', '🧭', '{"type":"distinct_categories","count":3}'),
  ('reviewer', 'Reviewer', 'Tre recensioni pubblicate', '✍️', '{"type":"reviews_published","count":3}'),
  ('taranto_foodie', 'Taranto Foodie', 'Cinque visite completate a Taranto', '⭐', '{"type":"reservations_completed","count":5,"city":"taranto"}');

create table public.user_achievements (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references public.profiles(id) on delete cascade,
  achievement_id uuid not null references public.achievements(id) on delete cascade,
  earned_at      timestamptz not null default now(),
  unique (user_id, achievement_id)
);

create or replace function public.check_achievements(p_user uuid)
returns int language plpgsql security definer set search_path = public as $$
declare a record; v_n int; v_need int; v_new int := 0; v_id uuid; c jsonb;
begin
  if p_user is null then return 0; end if;
  for a in select * from public.achievements x where x.is_active
             and not exists (select 1 from public.user_achievements u where u.user_id = p_user and u.achievement_id = x.id) loop
    c := a.criteria_json;
    v_need := coalesce((c ->> 'count')::int, 1);
    v_n := case c ->> 'type'
      when 'reservations_completed' then (
        select count(*) from public.reservations x join public.restaurants r on r.id = x.restaurant_id
        where x.user_id = p_user and x.status = 'completed'
          and (c ->> 'city' is null or exists (select 1 from public.cities ci where ci.id = r.city_id and ci.slug = c ->> 'city'))
          and (c ->> 'category' is null or exists (select 1 from public.restaurant_categories rc join public.categories k on k.id = rc.category_id
                                                   where rc.restaurant_id = r.id and k.slug = c ->> 'category')))
      when 'distinct_categories' then (
        select count(distinct k.id) from public.reservations x join public.restaurant_categories rc on rc.restaurant_id = x.restaurant_id
        join public.categories k on k.id = rc.category_id
        where x.user_id = p_user and x.status = 'completed' and k.slug <> 'all-you-can-eat')
      when 'reviews_published' then (select count(*) from public.reviews where user_id = p_user and status = 'published')
      when 'coupons_redeemed' then (select count(*) from public.coupon_claims where user_id = p_user and status = 'redeemed')
      else 0 end;
    if v_n >= v_need then
      insert into public.user_achievements (user_id, achievement_id) values (p_user, a.id) on conflict do nothing returning id into v_id;
      if v_id is not null then
        v_new := v_new + 1;
        perform public.notify_user(p_user, 'loyalty', 'Nuovo badge: ' || a.name, coalesce(a.description, ''), '/profile/loyalty',
          'loyalty_updates', 'achievement:' || a.id || ':' || p_user);
        if a.points_bonus > 0 then
          perform public.loyalty_award(p_user, 'achievement_bonus', 'achievement', a.id, 'Badge: ' || a.name, a.points_bonus);
        end if;
      end if;
    end if;
  end loop;
  return v_new;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  6. RECENSIONI
-- ════════════════════════════════════════════════════════════════════
create table public.reviews (
  id                        uuid primary key default gen_random_uuid(),
  restaurant_id             uuid not null references public.restaurants(id) on delete cascade,
  user_id                   uuid not null references public.profiles(id) on delete cascade,
  reservation_id            uuid unique references public.reservations(id) on delete set null,
  coupon_claim_id           uuid unique references public.coupon_claims(id) on delete set null,
  rating_overall            smallint not null check (rating_overall between 1 and 5),
  rating_food               smallint check (rating_food between 1 and 5),
  rating_service            smallint check (rating_service between 1 and 5),
  rating_value              smallint check (rating_value between 1 and 5),
  rating_atmosphere         smallint check (rating_atmosphere between 1 and 5),
  title                     text check (char_length(title) <= 100),
  content                   text not null check (char_length(content) between 1 and 2000),
  is_verified               boolean not null default false,
  verification_source       text check (verification_source in ('reservation', 'coupon')),
  status                    text not null default 'pending' check (status in ('pending', 'published', 'rejected', 'hidden', 'flagged')),
  moderation_flags          text[] not null default '{}',
  moderation_note           text check (char_length(moderation_note) <= 300),
  is_edited                 boolean not null default false,
  helpful_count             int not null default 0,
  restaurant_response_count int not null default 0,
  created_at                timestamptz not null default now(),
  updated_at                timestamptz not null default now(),
  published_at              timestamptz,
  moderated_at              timestamptz,
  moderated_by              uuid references public.profiles(id) on delete set null,
  check (not is_verified or verification_source is not null)
);
create index reviews_restaurant_idx on public.reviews(restaurant_id, status, published_at desc);
create index reviews_user_idx on public.reviews(user_id, created_at desc);
create index reviews_status_idx on public.reviews(status, created_at desc);
create trigger reviews_updated_at before update on public.reviews for each row execute function public.set_updated_at();

create table public.review_versions (
  id               uuid primary key default gen_random_uuid(),
  review_id        uuid not null references public.reviews(id) on delete cascade,
  previous_title   text,
  previous_content text not null,
  previous_rating  smallint not null,
  created_at       timestamptz not null default now()
);
create index review_versions_review_idx on public.review_versions(review_id, created_at desc);

create table public.review_responses (
  id            uuid primary key default gen_random_uuid(),
  review_id     uuid not null unique references public.reviews(id) on delete cascade,  -- una risposta ufficiale per recensione
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id       uuid references public.profiles(id) on delete set null,
  content       text not null check (char_length(content) between 2 and 1000),
  status        text not null default 'published' check (status in ('published', 'hidden')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create trigger review_responses_updated_at before update on public.review_responses for each row execute function public.set_updated_at();

create table public.review_votes (
  id         uuid primary key default gen_random_uuid(),
  review_id  uuid not null references public.reviews(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  vote_type  text not null default 'helpful' check (vote_type in ('helpful')),
  created_at timestamptz not null default now(),
  unique (review_id, user_id, vote_type)
);
create index review_votes_review_idx on public.review_votes(review_id);
create index review_votes_user_idx on public.review_votes(user_id, created_at desc);

create table public.review_reports (
  id               uuid primary key default gen_random_uuid(),
  review_id        uuid not null references public.reviews(id) on delete cascade,
  reporter_user_id uuid not null references public.profiles(id) on delete cascade,
  reason           text not null check (reason in ('spam', 'offensive', 'false_info', 'conflict_of_interest', 'personal_data', 'other')),
  details          text check (char_length(details) <= 500),
  status           text not null default 'open' check (status in ('open', 'upheld', 'dismissed')),
  created_at       timestamptz not null default now(),
  reviewed_at      timestamptz,
  reviewed_by      uuid references public.profiles(id) on delete set null,
  unique (review_id, reporter_user_id)
);
create index review_reports_review_idx on public.review_reports(review_id, status);

-- Il personale del locale non recensisce il proprio ristorante (anche se revocato di recente)
create or replace function public.is_restaurant_insider(p_user uuid, p_restaurant uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.restaurant_members m where m.restaurant_id = p_restaurant and m.user_id = p_user
                 and (m.status in ('active', 'invited') or m.updated_at > now() - interval '180 days'))
      or exists (select 1 from public.restaurants r where r.id = p_restaurant and (r.owner_id = p_user or r.claimed_by = p_user));
$$;

-- Segnali per la moderazione umana (mai decisione automatica finale)
create or replace function public.review_content_flags(p_text text)
returns text[] language sql immutable as $$
  select array_remove(array[
    case when p_text ~* '(https?://|www\.[a-z0-9-]+\.)' then 'link' end,
    case when p_text ~* '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}' then 'email' end,
    case when p_text ~ '(\+?[0-9][0-9 .-]{8,}[0-9])' then 'phone' end,
    case when char_length(regexp_replace(p_text, '[^A-Z]', '', 'g')) > 40
          and char_length(regexp_replace(p_text, '[^A-Z]', '', 'g')) > 0.6 * char_length(regexp_replace(p_text, '[^A-Za-z]', '', 'g')) then 'shouting' end
  ], null);
$$;

-- Visita reale utilizzabile per la verifica (prenotazione completata o coupon riscattato, non ancora usati)
create or replace function public.review_verification_for(p_user uuid, p_restaurant uuid, p_reservation uuid default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_days int := public.billing_setting_int('review_verification_window_days', 180); x record;
begin
  select id, reservation_date as d into x from public.reservations r
   where r.user_id = p_user and r.restaurant_id = p_restaurant and r.status = 'completed'
     and (p_reservation is null or r.id = p_reservation)
     and r.reservation_date >= (now() - make_interval(days => v_days))::date
     and not exists (select 1 from public.reviews v where v.reservation_id = r.id)
   order by r.reservation_date desc limit 1;
  if found then return jsonb_build_object('source', 'reservation', 'id', x.id, 'date', x.d); end if;
  if p_reservation is not null then return null; end if;
  select id, (redeemed_at at time zone 'Europe/Rome')::date as d into x from public.coupon_claims c
   where c.user_id = p_user and c.restaurant_id = p_restaurant and c.status = 'redeemed'
     and c.redeemed_at >= now() - make_interval(days => v_days)
     and not exists (select 1 from public.reviews v where v.coupon_claim_id = c.id)
   order by c.redeemed_at desc limit 1;
  if found then return jsonb_build_object('source', 'coupon', 'id', x.id, 'date', x.d); end if;
  return null;
end $$;

-- Stato per il form "Scrivi una recensione"
create or replace function public.my_review_status(p_restaurant uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_cool int := public.billing_setting_int('review_cooldown_days', 90); v_rev public.reviews; v_ver jsonb;
begin
  if v_uid is null then return jsonb_build_object('authenticated', false); end if;
  select * into v_rev from public.reviews where user_id = v_uid and restaurant_id = p_restaurant
     and status in ('published', 'pending', 'flagged') and created_at > now() - make_interval(days => v_cool)
   order by created_at desc limit 1;
  v_ver := public.review_verification_for(v_uid, p_restaurant);
  return jsonb_build_object(
    'authenticated', true,
    'blocked', case when public.is_restaurant_insider(v_uid, p_restaurant) then 'insider'
                    when exists (select 1 from public.profiles where id = v_uid and is_blocked) then 'blocked'
                    when v_rev.id is not null then 'cooldown'
                    when v_ver is null and not public.billing_setting_bool('allow_unverified_reviews', true) then 'unverified_not_allowed'
                    end,
    'verification', v_ver,
    'allow_unverified', public.billing_setting_bool('allow_unverified_reviews', true),
    'cooldown_days', v_cool,
    'min_length', public.billing_setting_int('review_min_length', 20),
    'display_name', public.public_display_name(v_uid),
    'existing', case when v_rev.id is not null then jsonb_build_object('id', v_rev.id, 'status', v_rev.status, 'rating_overall', v_rev.rating_overall,
      'rating_food', v_rev.rating_food, 'rating_service', v_rev.rating_service, 'rating_value', v_rev.rating_value,
      'rating_atmosphere', v_rev.rating_atmosphere, 'title', v_rev.title, 'content', v_rev.content, 'is_verified', v_rev.is_verified,
      'created_at', v_rev.created_at, 'editable_until', null) end);
end $$;

create or replace function public.review_rating_field(p jsonb, k text, required boolean)
returns smallint language plpgsql immutable as $$
declare v text := p ->> k;
begin
  if v is null or v = '' then
    if required then raise exception 'La valutazione generale è obbligatoria.'; end if;
    return null;
  end if;
  if v !~ '^[1-5]$' then raise exception 'Valutazione non valida (1–5).'; end if;
  return v::smallint;
end $$;

create or replace function public.submit_review(p_restaurant uuid, p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_content text := trim(coalesce(p ->> 'content', ''));
  v_title text := nullif(trim(coalesce(p ->> 'title', '')), '');
  v_min int := public.billing_setting_int('review_min_length', 20);
  v_ver jsonb;
  v_flags text[];
  v_status text;
  v_id uuid;
  v_overall smallint := public.review_rating_field(p, 'rating_overall', true);
begin
  if v_uid is null then raise exception 'Accedi per scrivere una recensione.' using errcode = '42501'; end if;
  if exists (select 1 from public.profiles where id = v_uid and is_blocked) then raise exception 'Account non abilitato.' using errcode = '42501'; end if;
  if not public.restaurant_is_public(p_restaurant) then raise exception 'Ristorante non trovato.'; end if;
  if public.is_restaurant_insider(v_uid, p_restaurant) then
    raise exception 'Chi gestisce o lavora nel ristorante non può recensirlo.' using errcode = '42501', hint = 'insider';
  end if;
  if char_length(v_content) < v_min then raise exception 'La recensione deve avere almeno % caratteri.', v_min; end if;
  if char_length(v_content) > 2000 then raise exception 'Massimo 2000 caratteri.'; end if;
  if v_title is not null and char_length(v_title) > 100 then raise exception 'Titolo troppo lungo (max 100).'; end if;
  if exists (select 1 from public.reviews where user_id = v_uid and restaurant_id = p_restaurant
             and status in ('published', 'pending', 'flagged')
             and created_at > now() - make_interval(days => public.billing_setting_int('review_cooldown_days', 90))) then
    raise exception 'Hai già recensito questo ristorante di recente: puoi modificare la tua recensione.' using hint = 'cooldown';
  end if;
  if (select count(*) from public.reviews where user_id = v_uid and created_at > now() - interval '24 hours')
       >= public.billing_setting_int('review_daily_limit', 5) then
    raise exception 'Hai raggiunto il numero massimo di recensioni per oggi.' using hint = 'rate_limited';
  end if;
  v_ver := public.review_verification_for(v_uid, p_restaurant,
             case when (p ->> 'reservation_id') ~* '^[0-9a-f-]{36}$' then (p ->> 'reservation_id')::uuid end);
  if v_ver is null and not public.billing_setting_bool('allow_unverified_reviews', true) then
    raise exception 'Puoi recensire dopo una visita verificata (prenotazione completata o coupon utilizzato).' using hint = 'unverified_not_allowed';
  end if;
  v_flags := public.review_content_flags(coalesce(v_title, '') || ' ' || v_content);
  v_status := case
    when cardinality(v_flags) > 0 then 'pending'
    when v_ver is not null and public.billing_setting_bool('auto_publish_verified_reviews', true) then 'published'
    when v_ver is null and public.billing_setting_bool('auto_publish_unverified_reviews', false) then 'published'
    else 'pending' end;
  insert into public.reviews (restaurant_id, user_id, reservation_id, coupon_claim_id, rating_overall, rating_food, rating_service,
                              rating_value, rating_atmosphere, title, content, is_verified, verification_source, status, moderation_flags, published_at)
  values (p_restaurant, v_uid,
          case when v_ver ->> 'source' = 'reservation' then (v_ver ->> 'id')::uuid end,
          case when v_ver ->> 'source' = 'coupon' then (v_ver ->> 'id')::uuid end,
          v_overall, public.review_rating_field(p, 'rating_food', false), public.review_rating_field(p, 'rating_service', false),
          public.review_rating_field(p, 'rating_value', false), public.review_rating_field(p, 'rating_atmosphere', false),
          v_title, v_content, v_ver is not null, v_ver ->> 'source', v_status, coalesce(v_flags, '{}'),
          case when v_status = 'published' then now() end)
  returning id into v_id;
  perform public.touch_activity(v_uid);
  if v_status = 'pending' then
    perform public.notify_admins('review_pending', 'Recensione da moderare', left(v_content, 120), '/admin/reviews');
  end if;
  return jsonb_build_object('id', v_id, 'status', v_status, 'is_verified', v_ver is not null, 'verification_source', v_ver ->> 'source');
end $$;

create or replace function public.update_review(p_id uuid, p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  x public.reviews;
  v_content text := trim(coalesce(p ->> 'content', ''));
  v_title text := nullif(trim(coalesce(p ->> 'title', '')), '');
  v_min int := public.billing_setting_int('review_min_length', 20);
  v_flags text[];
  v_status text;
begin
  select * into x from public.reviews where id = p_id for update;
  if not found or x.user_id is distinct from auth.uid() then raise exception 'Recensione non trovata.' using errcode = '42501'; end if;
  if x.status in ('rejected', 'hidden') then raise exception 'Questa recensione non è più modificabile.'; end if;
  if char_length(v_content) < v_min or char_length(v_content) > 2000 then raise exception 'La recensione deve avere tra % e 2000 caratteri.', v_min; end if;
  if (select count(*) from public.review_versions where review_id = p_id) >= 10 then raise exception 'Hai raggiunto il numero massimo di modifiche.'; end if;
  insert into public.review_versions (review_id, previous_title, previous_content, previous_rating) values (x.id, x.title, x.content, x.rating_overall);
  v_flags := public.review_content_flags(coalesce(v_title, '') || ' ' || v_content);
  v_status := case when cardinality(v_flags) > 0 then 'pending' else x.status end;
  update public.reviews set
    rating_overall = public.review_rating_field(p, 'rating_overall', true),
    rating_food = public.review_rating_field(p, 'rating_food', false), rating_service = public.review_rating_field(p, 'rating_service', false),
    rating_value = public.review_rating_field(p, 'rating_value', false), rating_atmosphere = public.review_rating_field(p, 'rating_atmosphere', false),
    title = v_title, content = v_content, is_edited = true, status = v_status, moderation_flags = coalesce(v_flags, '{}')
  where id = p_id;
  return jsonb_build_object('id', p_id, 'status', v_status);
end $$;

create or replace function public.vote_review(p_id uuid, p_on boolean)
returns int language plpgsql security definer set search_path = public as $$
declare x public.reviews; v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Accedi per votare.' using errcode = '42501'; end if;
  select * into x from public.reviews where id = p_id;
  if not found or x.status <> 'published' then raise exception 'Recensione non trovata.'; end if;
  if x.user_id = v_uid then raise exception 'Non puoi votare la tua recensione.'; end if;
  if p_on then
    if (select count(*) from public.review_votes where user_id = v_uid and created_at > now() - interval '24 hours') >= 100 then
      raise exception 'Troppi voti in poco tempo.' using hint = 'rate_limited';
    end if;
    insert into public.review_votes (review_id, user_id) values (p_id, v_uid) on conflict do nothing;
  else
    delete from public.review_votes where review_id = p_id and user_id = v_uid;
  end if;
  return (select helpful_count from public.reviews where id = p_id);
end $$;

create or replace function public.review_votes_count()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.reviews set helpful_count = (select count(*) from public.review_votes where review_id = coalesce(new.review_id, old.review_id))
   where id = coalesce(new.review_id, old.review_id);
  return null;
end $$;
create trigger review_votes_count after insert or delete on public.review_votes for each row execute function public.review_votes_count();

create or replace function public.report_review(p_id uuid, p_reason text, p_details text default null)
returns void language plpgsql security definer set search_path = public as $$
declare x public.reviews; v_uid uuid := auth.uid(); v_n int;
begin
  if v_uid is null then raise exception 'Accedi per segnalare.' using errcode = '42501'; end if;
  select * into x from public.reviews where id = p_id for update;
  if not found or x.status not in ('published', 'flagged') then raise exception 'Recensione non trovata.'; end if;
  if x.user_id = v_uid then raise exception 'Non puoi segnalare la tua recensione.'; end if;
  if (select count(*) from public.review_reports where reporter_user_id = v_uid and created_at > now() - interval '24 hours') >= 10 then
    raise exception 'Troppe segnalazioni in poco tempo.' using hint = 'rate_limited';
  end if;
  insert into public.review_reports (review_id, reporter_user_id, reason, details)
  values (p_id, v_uid, p_reason, nullif(left(trim(coalesce(p_details, '')), 500), ''))
  on conflict (review_id, reporter_user_id) do nothing;
  -- Una sola segnalazione non nasconde nulla: solo segnalazioni distinte oltre la soglia mettono in revisione
  select count(*) into v_n from public.review_reports where review_id = p_id and status = 'open';
  if x.status = 'published' and v_n >= public.billing_setting_int('review_flag_threshold', 3) then
    update public.reviews set status = 'flagged' where id = p_id;
    perform public.notify_admins('review_flagged', 'Recensione segnalata più volte', left(x.content, 120), '/admin/reviews');
  end if;
end $$;

create or replace function public.respond_to_review(p_review uuid, p_content text)
returns void language plpgsql security definer set search_path = public as $$
declare x public.reviews; v_text text := trim(coalesce(p_content, '')); r public.restaurants;
begin
  select * into x from public.reviews where id = p_review;
  if not found or x.status not in ('published', 'flagged') then raise exception 'Recensione non trovata.'; end if;
  if not public.can_manage_restaurant(x.restaurant_id) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
  if char_length(v_text) < 2 or char_length(v_text) > 1000 then raise exception 'La risposta deve avere tra 2 e 1000 caratteri.'; end if;
  insert into public.review_responses (review_id, restaurant_id, user_id, content)
  values (x.id, x.restaurant_id, auth.uid(), v_text)
  on conflict (review_id) do update set content = excluded.content, user_id = excluded.user_id, status = 'published';
  update public.reviews set restaurant_response_count = 1 where id = x.id and restaurant_response_count <> 1;
  select * into r from public.restaurants where id = x.restaurant_id;
  perform public.notify_user(x.user_id, 'review', 'Il ristorante ha risposto alla tua recensione', r.name,
    '/ristorante/' || r.slug || '#recensioni', null, 'review_response:' || x.id || ':' || to_char(now(), 'YYYYMMDD'),
    '{}'::jsonb, r.id);
end $$;

create or replace function public.moderate_review(p_id uuid, p_action text, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare x public.reviews; v_status text; r public.restaurants;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into x from public.reviews where id = p_id for update;
  if not found then raise exception 'Recensione non trovata.'; end if;
  v_status := case p_action when 'publish' then 'published' when 'restore' then 'published' when 'hide' then 'hidden' when 'reject' then 'rejected' end;
  if v_status is null then raise exception 'Azione non valida.'; end if;
  update public.reviews set status = v_status, moderated_at = now(), moderated_by = auth.uid(),
         moderation_note = nullif(left(trim(coalesce(p_note, '')), 300), ''),
         published_at = case when v_status = 'published' then coalesce(published_at, now()) else published_at end
   where id = p_id;
  update public.review_reports set status = case when v_status = 'published' then 'dismissed' else 'upheld' end,
         reviewed_at = now(), reviewed_by = auth.uid()
   where review_id = p_id and status = 'open';
  perform public.audit_admin('review_' || p_action, 'review', p_id::text, jsonb_build_object('from', x.status, 'to', v_status, 'note', p_note));
  if v_status in ('rejected', 'hidden') and x.status <> v_status then
    select * into r from public.restaurants where id = x.restaurant_id;
    perform public.notify_user(x.user_id, 'review', 'La tua recensione non è stata pubblicata',
      coalesce(nullif(trim(coalesce(p_note, '')), ''), 'Non rispetta le linee guida delle recensioni.'), '/ristorante/' || r.slug || '#recensioni');
  end if;
end $$;

-- Effetti della pubblicazione: punti (solo verificate e mai in base al voto), badge, avviso al ristorante
create or replace function public.reviews_after_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare r public.restaurants;
begin
  if new.status = 'published' and (tg_op = 'INSERT' or old.status is distinct from 'published') then
    if new.is_verified then
      perform public.loyalty_award(new.user_id, 'verified_review', 'review', new.id, 'Recensione verificata pubblicata');
    end if;
    perform public.check_achievements(new.user_id);
    select * into r from public.restaurants where id = new.restaurant_id;
    if tg_op = 'INSERT' or old.published_at is null then
      perform public.notify_restaurant(new.restaurant_id, 'review', 'Nuova recensione',
        format('%s/5%s', new.rating_overall, case when new.is_verified then ' · visita verificata' else '' end),
        format('/dashboard/restaurants/%s/reviews', new.restaurant_id));
    end if;
  end if;
  return null;
end $$;
create trigger reviews_after_change after insert or update of status on public.reviews
  for each row execute function public.reviews_after_change();

-- Valutazione del ristorante: SEMPRE calcolata dalle recensioni pubblicate (nessun valore manuale)
create or replace function public.restaurant_rating(p_restaurant uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'count', count(*),
    'average', case when count(*) > 0 then round(avg(rating_overall)::numeric, 1) end,
    'verified_count', count(*) filter (where is_verified),
    'distribution', jsonb_build_object('5', count(*) filter (where rating_overall = 5), '4', count(*) filter (where rating_overall = 4),
                                       '3', count(*) filter (where rating_overall = 3), '2', count(*) filter (where rating_overall = 2),
                                       '1', count(*) filter (where rating_overall = 1)),
    'food', round(avg(rating_food)::numeric, 1), 'service', round(avg(rating_service)::numeric, 1),
    'value', round(avg(rating_value)::numeric, 1), 'atmosphere', round(avg(rating_atmosphere)::numeric, 1))
  from public.reviews where restaurant_id = p_restaurant and status = 'published';
$$;

-- Media e conteggio per più ristoranti (card nei risultati)
create or replace function public.restaurants_rating(p_ids uuid[])
returns table (restaurant_id uuid, average numeric, review_count bigint)
language sql stable security definer set search_path = public as $$
  select v.restaurant_id, round(avg(v.rating_overall)::numeric, 1), count(*)
  from public.reviews v where v.restaurant_id = any(p_ids[1:200]) and v.status = 'published'
  group by v.restaurant_id;
$$;

-- Elenco pubblico paginato: solo nome pubblico (mai email/telefono/cognome)
create or replace function public.list_reviews(p_restaurant uuid, p_sort text default 'recent', p_filter text default null,
                                               p_limit int default 10, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_lim int := least(greatest(coalesce(p_limit, 10), 1), 20); v_off int := greatest(coalesce(p_offset, 0), 0);
begin
  return jsonb_build_object(
    'total', (select count(*) from public.reviews v where v.restaurant_id = p_restaurant and v.status = 'published'
              and (p_filter is null or (p_filter = 'verified' and v.is_verified) or (p_filter ~ '^[1-5]$' and v.rating_overall = p_filter::int))),
    'items', coalesce((select jsonb_agg(j) from (
      select jsonb_build_object(
        'id', v.id, 'author', public.public_display_name(v.user_id), 'is_verified', v.is_verified,
        'verification_source', v.verification_source,
        'rating_overall', v.rating_overall, 'rating_food', v.rating_food, 'rating_service', v.rating_service,
        'rating_value', v.rating_value, 'rating_atmosphere', v.rating_atmosphere,
        'title', v.title, 'content', v.content, 'is_edited', v.is_edited, 'helpful_count', v.helpful_count,
        'published_at', v.published_at, 'created_at', v.created_at, 'is_mine', v.user_id = v_uid,
        'my_vote', exists (select 1 from public.review_votes rv where rv.review_id = v.id and rv.user_id = v_uid),
        'response', (select jsonb_build_object('content', rr.content, 'updated_at', rr.updated_at, 'created_at', rr.created_at)
                     from public.review_responses rr where rr.review_id = v.id and rr.status = 'published')) as j
      from public.reviews v
      where v.restaurant_id = p_restaurant and v.status = 'published'
        and (p_filter is null or (p_filter = 'verified' and v.is_verified) or (p_filter ~ '^[1-5]$' and v.rating_overall = p_filter::int))
      order by
        case when p_sort = 'helpful' then v.helpful_count end desc nulls last,
        case when p_sort = 'high' then v.rating_overall end desc nulls last,
        case when p_sort = 'low' then v.rating_overall end asc nulls last,
        v.published_at desc
      limit v_lim offset v_off) s), '[]'::jsonb));
end $$;

-- Recensioni per il ristoratore (anche quelle segnalate), senza dati personali
create or replace function public.restaurant_reviews_manage(p_restaurant uuid, p_limit int default 20, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
  return jsonb_build_object(
    'rating', public.restaurant_rating(p_restaurant),
    'items', coalesce((select jsonb_agg(j) from (
      select jsonb_build_object('id', v.id, 'author', public.public_display_name(v.user_id), 'is_verified', v.is_verified,
        'rating_overall', v.rating_overall, 'title', v.title, 'content', v.content, 'status', v.status, 'is_edited', v.is_edited,
        'published_at', v.published_at, 'helpful_count', v.helpful_count,
        'my_report', exists (select 1 from public.review_reports rp where rp.review_id = v.id and rp.reporter_user_id = auth.uid()),
        'response', (select jsonb_build_object('content', rr.content, 'updated_at', rr.updated_at) from public.review_responses rr where rr.review_id = v.id)) as j
      from public.reviews v where v.restaurant_id = p_restaurant and v.status in ('published', 'flagged')
      order by v.published_at desc nulls last limit least(greatest(coalesce(p_limit, 20), 1), 50) offset greatest(coalesce(p_offset, 0), 0)) s), '[]'::jsonb));
end $$;

-- Coda di moderazione (Admin)
create or replace function public.admin_list_reviews(p_status text default null, p_limit int default 50, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  return coalesce((select jsonb_agg(j) from (
    select jsonb_build_object('id', v.id, 'restaurant', jsonb_build_object('id', r.id, 'name', r.name, 'slug', r.slug),
      'author', public.public_display_name(v.user_id), 'user_id', v.user_id, 'rating_overall', v.rating_overall, 'title', v.title, 'content', v.content,
      'is_verified', v.is_verified, 'verification_source', v.verification_source, 'status', v.status, 'moderation_flags', v.moderation_flags,
      'moderation_note', v.moderation_note, 'is_edited', v.is_edited, 'created_at', v.created_at, 'published_at', v.published_at,
      'reports_open', (select count(*) from public.review_reports rp where rp.review_id = v.id and rp.status = 'open'),
      'reports', coalesce((select jsonb_agg(jsonb_build_object('reason', rp.reason, 'details', rp.details, 'status', rp.status, 'created_at', rp.created_at) order by rp.created_at desc)
                           from public.review_reports rp where rp.review_id = v.id), '[]'::jsonb)) as j
    from public.reviews v join public.restaurants r on r.id = v.restaurant_id
    where p_status is null or v.status = p_status
       or (p_status = 'queue' and v.status in ('pending', 'flagged'))
       or (p_status in ('reported', 'queue') and exists (select 1 from public.review_reports rp where rp.review_id = v.id and rp.status = 'open'))
    order by case v.status when 'flagged' then 0 when 'pending' then 1 else 2 end, v.created_at desc
    limit least(greatest(coalesce(p_limit, 50), 1), 200) offset greatest(coalesce(p_offset, 0), 0)) s), '[]'::jsonb);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  7. REFERRAL (utenti e ristoratori)
-- ════════════════════════════════════════════════════════════════════
create table public.referral_codes (
  user_id    uuid primary key references public.profiles(id) on delete cascade,
  code       text not null unique check (code ~ '^[A-Z0-9]{4}-[A-Z0-9]{4}$'),
  created_at timestamptz not null default now()
);

create table public.referrals (
  id               uuid primary key default gen_random_uuid(),
  referrer_user_id uuid not null references public.profiles(id) on delete cascade,
  referred_user_id uuid unique references public.profiles(id) on delete cascade,   -- una sola attribuzione per utente
  referral_code    text not null,
  invite_email     text check (invite_email is null or invite_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  status           text not null default 'invited' check (status in ('invited', 'registered', 'qualified', 'rewarded', 'invalid')),
  invalid_reason   text check (char_length(invalid_reason) <= 200),
  registered_at    timestamptz,
  qualified_at     timestamptz,
  rewarded_at      timestamptz,
  created_at       timestamptz not null default now(),
  check (referred_user_id is null or referred_user_id <> referrer_user_id)
);
create index referrals_referrer_idx on public.referrals(referrer_user_id, created_at desc);

create or replace function public.ensure_referral_code(p_user uuid)
returns text language plpgsql security definer set search_path = public as $$
declare v text;
begin
  select code into v from public.referral_codes where user_id = p_user;
  if v is not null then return v; end if;
  loop
    v := public.gen_code('', 4) || '-' || public.gen_code('', 4);
    begin
      insert into public.referral_codes (user_id, code) values (p_user, v);
      return v;
    exception when unique_violation then
      select code into v from public.referral_codes where user_id = p_user;
      if v is not null then return v; end if;
    end;
  end loop;
end $$;

-- Il nuovo utente collega il codice invito (dopo la registrazione; attribuzione conservata nel browser)
create or replace function public.apply_referral_code(p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_code text := upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9-]', '', 'g'));
  v_ref uuid;
  v_created timestamptz;
begin
  if v_uid is null then raise exception 'Accedi per usare un codice invito.' using errcode = '42501'; end if;
  if not public.billing_setting_bool('referral_enabled', true) then raise exception 'Il programma inviti non è attivo.'; end if;
  select user_id into v_ref from public.referral_codes where code = v_code;
  if v_ref is null then raise exception 'Codice invito non valido.' using hint = 'invalid_code'; end if;
  if v_ref = v_uid then raise exception 'Non puoi usare il tuo codice invito.' using hint = 'self_referral'; end if;
  if exists (select 1 from public.referrals where referred_user_id = v_uid) then
    raise exception 'Hai già usato un codice invito.' using hint = 'already_referred';
  end if;
  select created_at into v_created from public.profiles where id = v_uid;
  if v_created < now() - make_interval(days => public.billing_setting_int('referral_signup_window_days', 14)) then
    raise exception 'Il codice invito si può usare solo nei primi giorni dopo la registrazione.' using hint = 'too_late';
  end if;
  if exists (select 1 from public.profiles where id = v_ref and is_blocked) then raise exception 'Codice invito non valido.' using hint = 'invalid_code'; end if;
  -- Inviti incrociati (A invita B e B invita A) non sono validi
  if exists (select 1 from public.referrals where referrer_user_id = v_uid and referred_user_id = v_ref) then
    raise exception 'Codice invito non valido.' using hint = 'mutual';
  end if;
  if (select count(*) from public.referrals where referrer_user_id = v_ref and registered_at >= date_trunc('month', now()))
       >= public.billing_setting_int('referral_max_per_month', 20) then
    raise exception 'Questo codice ha raggiunto il limite di inviti del mese.' using hint = 'referrer_limit';
  end if;
  insert into public.referrals (referrer_user_id, referred_user_id, referral_code, status, registered_at)
  values (v_ref, v_uid, v_code, 'registered', now());
  perform public.notify_user(v_ref, 'referral', 'Un amico si è registrato con il tuo invito',
    'Riceverai i punti quando completerà la prima visita.', '/profile/referrals', 'referral_updates');
  return jsonb_build_object('ok', true, 'status', 'registered');
end $$;

-- Qualifica: email verificata + prima azione reale (prenotazione completata o coupon utilizzato). Solo server.
create or replace function public.referral_qualify(p_user uuid, p_force boolean default false)
returns boolean language plpgsql security definer set search_path = public as $$
declare x public.referrals; v_verified boolean; v_action boolean; a int; b int;
begin
  select * into x from public.referrals where referred_user_id = p_user and status = 'registered' for update;
  if not found then return false; end if;
  select coalesce(u.email_confirmed_at is not null, false) into v_verified from auth.users u where u.id = p_user;
  v_action := exists (select 1 from public.reservations where user_id = p_user and status = 'completed')
           or exists (select 1 from public.coupon_claims where user_id = p_user and status = 'redeemed');
  if not p_force and not (coalesce(v_verified, false) and v_action) then return false; end if;
  update public.referrals set status = 'qualified', qualified_at = now() where id = x.id;
  a := public.loyalty_award(x.referrer_user_id, 'referral_completed', 'referral', x.id, 'Amico invitato: prima visita completata');
  b := public.loyalty_award(p_user, 'referral_welcome', 'referral', x.id, 'Bonus di benvenuto per l''invito');
  update public.referrals set status = 'rewarded', rewarded_at = now() where id = x.id;
  perform public.notify_user(x.referrer_user_id, 'referral', 'Invito completato',
    case when a > 0 then format('Il tuo amico ha completato la prima visita: +%s punti.', a) else 'Il tuo amico ha completato la prima visita.' end,
    '/profile/referrals', 'referral_updates', 'referral_done:' || x.id, '{}'::jsonb, null,
    'referral_completed', jsonb_build_object('points', a));
  return true;
end $$;

create or replace function public.my_referrals()
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Accedi per invitare i tuoi amici.' using errcode = '42501'; end if;
  return jsonb_build_object(
    'code', public.ensure_referral_code(v_uid),
    'enabled', public.billing_setting_bool('referral_enabled', true),
    'registered', (select count(*) from public.referrals where referrer_user_id = v_uid and status in ('registered', 'qualified', 'rewarded')),
    'qualified', (select count(*) from public.referrals where referrer_user_id = v_uid and status in ('qualified', 'rewarded')),
    'points', (select coalesce(sum(points), 0) from public.loyalty_transactions where user_id = v_uid and event_key = 'referral_completed'),
    'reward_points', (select points from public.loyalty_rules where event_key = 'referral_completed' and enabled),
    'welcome_points', (select points from public.loyalty_rules where event_key = 'referral_welcome' and enabled),
    'referred_by_me', exists (select 1 from public.referrals where referred_user_id = v_uid),
    'items', coalesce((select jsonb_agg(jsonb_build_object('status', r.status, 'registered_at', r.registered_at, 'qualified_at', r.qualified_at,
                         'name', public.public_display_name(r.referred_user_id)) order by r.created_at desc)
                       from (select * from public.referrals where referrer_user_id = v_uid order by created_at desc limit 50) r), '[]'::jsonb));
end $$;

create or replace function public.admin_referral_action(p_id uuid, p_action text, p_reason text default null)
returns void language plpgsql security definer set search_path = public as $$
declare x public.referrals;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into x from public.referrals where id = p_id for update;
  if not found then raise exception 'Invito non trovato.'; end if;
  if p_action = 'invalidate' then
    if x.status in ('rewarded') then raise exception 'Invito già premiato: rettifica i punti dalla sezione loyalty.'; end if;
    update public.referrals set status = 'invalid', invalid_reason = left(coalesce(p_reason, 'Annullato dall''amministrazione'), 200) where id = p_id;
  elsif p_action = 'qualify' then
    if x.status <> 'registered' then raise exception 'Solo gli inviti registrati possono essere qualificati.'; end if;
    perform public.referral_qualify(x.referred_user_id, true);
  else
    raise exception 'Azione non valida.';
  end if;
  perform public.audit_admin('referral_' || p_action, 'referral', p_id::text, jsonb_build_object('reason', p_reason));
end $$;

create or replace function public.admin_list_referrals(p_status text default null, p_limit int default 100)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  return coalesce((select jsonb_agg(j) from (
    select jsonb_build_object('id', r.id, 'status', r.status, 'code', r.referral_code, 'created_at', r.created_at, 'registered_at', r.registered_at,
      'qualified_at', r.qualified_at, 'rewarded_at', r.rewarded_at, 'invalid_reason', r.invalid_reason,
      'referrer', public.public_display_name(r.referrer_user_id), 'referrer_id', r.referrer_user_id,
      'referred', public.public_display_name(r.referred_user_id), 'referred_id', r.referred_user_id,
      'email_verified', (select u.email_confirmed_at is not null from auth.users u where u.id = r.referred_user_id)) as j
    from public.referrals r where p_status is null or r.status = p_status
    order by r.created_at desc limit least(greatest(coalesce(p_limit, 100), 1), 500)) s), '[]'::jsonb);
end $$;

-- Referral B2B: un ristoratore segnala un altro locale; il premio lo approva l'Admin (nessun credito automatico)
create table public.business_referrals (
  id                      uuid primary key default gen_random_uuid(),
  referrer_restaurant_id  uuid not null references public.restaurants(id) on delete cascade,
  referrer_user_id        uuid references public.profiles(id) on delete set null,
  referred_business_email text not null check (referred_business_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  referred_business_name  text check (char_length(referred_business_name) <= 120),
  referred_restaurant_id  uuid references public.restaurants(id) on delete set null,
  code                    text not null unique,
  status                  text not null default 'invited' check (status in ('invited', 'registered', 'qualified', 'approved', 'rewarded', 'rejected')),
  qualified_at            timestamptz,
  reward_type             text check (reward_type in ('trial_extension', 'promo_months', 'sponsorship_credits', 'manual_admin_reward')),
  reward_value            int check (reward_value is null or reward_value between 0 and 10000),
  admin_note              text check (char_length(admin_note) <= 300),
  created_at              timestamptz not null default now(),
  unique (referrer_restaurant_id, referred_business_email)
);

create or replace function public.create_business_referral(p_restaurant uuid, p_email text, p_name text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_code text; v_id uuid;
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
  if p_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Email non valida.'; end if;
  if (select count(*) from public.business_referrals where referrer_restaurant_id = p_restaurant and created_at > now() - interval '30 days') >= 10 then
    raise exception 'Hai raggiunto il limite di segnalazioni del mese.' using hint = 'rate_limited';
  end if;
  loop
    v_code := public.gen_code('B-', 6);
    exit when not exists (select 1 from public.business_referrals where code = v_code);
  end loop;
  insert into public.business_referrals (referrer_restaurant_id, referrer_user_id, referred_business_email, referred_business_name, code)
  values (p_restaurant, auth.uid(), lower(trim(p_email)), nullif(left(trim(coalesce(p_name, '')), 120), ''), v_code)
  on conflict (referrer_restaurant_id, referred_business_email) do nothing returning id into v_id;
  if v_id is null then raise exception 'Hai già segnalato questo locale.'; end if;
  perform public.notify_admins('business_referral', 'Nuova segnalazione di un ristorante', lower(trim(p_email)), '/admin/referrals');
  return jsonb_build_object('id', v_id, 'code', v_code);
end $$;

create or replace function public.admin_business_referral_update(p_id uuid, p_status text, p_reward_type text default null,
                                                                 p_reward_value int default null, p_referred_restaurant uuid default null, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  update public.business_referrals set status = p_status, reward_type = coalesce(p_reward_type, reward_type),
         reward_value = coalesce(p_reward_value, reward_value), referred_restaurant_id = coalesce(p_referred_restaurant, referred_restaurant_id),
         admin_note = coalesce(nullif(left(trim(coalesce(p_note, '')), 300), ''), admin_note),
         qualified_at = case when p_status in ('qualified', 'approved', 'rewarded') then coalesce(qualified_at, now()) else qualified_at end
   where id = p_id;
  if not found then raise exception 'Segnalazione non trovata.'; end if;
  perform public.audit_admin('business_referral_' || p_status, 'business_referral', p_id::text,
    jsonb_build_object('reward_type', p_reward_type, 'reward_value', p_reward_value));
end $$;

-- ════════════════════════════════════════════════════════════════════
--  8. FOLLOW (preferiti con notifiche esplicite)
-- ════════════════════════════════════════════════════════════════════
alter table public.favorites add column if not exists notifications_enabled boolean not null default false;
create index if not exists favorites_follow_idx on public.favorites(restaurant_id) where notifications_enabled;

create or replace function public.set_follow(p_restaurant uuid, p_on boolean)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Accedi per seguire un ristorante.' using errcode = '42501'; end if;
  if p_on then
    if not public.restaurant_is_public(p_restaurant) then raise exception 'Ristorante non trovato.'; end if;
    insert into public.favorites (user_id, restaurant_id, notifications_enabled) values (v_uid, p_restaurant, true)
    on conflict (user_id, restaurant_id) do update set notifications_enabled = true;
    -- Seguire è una scelta esplicita: attiva gli avvisi dei ristoranti seguiti
    perform public.user_prefs(v_uid);
    update public.notification_preferences set favorite_restaurants = true where user_id = v_uid;
  else
    update public.favorites set notifications_enabled = false where user_id = v_uid and restaurant_id = p_restaurant;
  end if;
  perform public.touch_activity(v_uid);
  return p_on;
end $$;

-- Novità ai follower (solo opt-in, massimo un avviso al giorno per ristorante)
create or replace function public.notify_followers(p_restaurant uuid, p_kind text, p_title text, p_body text, p_ref uuid)
returns int language plpgsql security definer set search_path = public as $$
declare f record; n int := 0; r public.restaurants; v_day text := to_char(now() at time zone 'Europe/Rome', 'YYYYMMDD');
begin
  select * into r from public.restaurants where id = p_restaurant;
  if not found or not public.restaurant_is_public(p_restaurant) then return 0; end if;
  for f in select fv.user_id from public.favorites fv where fv.restaurant_id = p_restaurant and fv.notifications_enabled limit 5000 loop
    if public.notify_user(f.user_id, 'restaurant', p_title, p_body, '/ristorante/' || r.slug || '#offerte', 'favorite_restaurants',
         'follow:' || p_restaurant || ':' || f.user_id || ':' || v_day, jsonb_build_object('kind', p_kind, 'ref', p_ref), p_restaurant) is not null then
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

create or replace function public.offers_notify_followers()
returns trigger language plpgsql security definer set search_path = public as $$
declare r public.restaurants;
begin
  if not new.is_active or (tg_op = 'UPDATE' and old.is_active) then return null; end if;
  select * into r from public.restaurants where id = new.restaurant_id;
  if tg_table_name = 'offers' then
    if new.starts_at > now() + interval '1 day' then return null; end if;
    perform public.notify_followers(new.restaurant_id, 'offer', 'Nuova offerta da ' || r.name, new.title, new.id);
  else
    perform public.notify_followers(new.restaurant_id, 'coupon', 'Nuovo coupon da ' || r.name, new.title, new.id);
  end if;
  return null;
end $$;
create trigger offers_notify_followers after insert or update of is_active on public.offers
  for each row execute function public.offers_notify_followers();
create trigger coupons_notify_followers after insert or update of is_active on public.coupons
  for each row execute function public.offers_notify_followers();

-- ════════════════════════════════════════════════════════════════════
--  9. CAMPAGNE (Admin e ristoratore) — l'invio lo fa la piattaforma
-- ════════════════════════════════════════════════════════════════════
create table public.campaigns (
  id               uuid primary key default gen_random_uuid(),
  scope            text not null check (scope in ('platform', 'restaurant')),
  restaurant_id    uuid references public.restaurants(id) on delete cascade,
  created_by       uuid references public.profiles(id) on delete set null,
  title            text not null check (char_length(title) between 3 and 80),
  message          text not null check (char_length(message) between 3 and 240),
  action_url       text check (action_url is null or (action_url ~ '^/' and char_length(action_url) <= 200)),
  target           text not null check (target in ('followers', 'coupon_users', 'past_customers', 'all_eligible',
                                                   'all_users', 'city', 'favorite_category', 'upcoming_reservation', 'active_users', 'loyalty_level')),
  targeting        jsonb not null default '{}'::jsonb,
  channels         text[] not null default array['in_app', 'push'] check (channels <@ array['in_app', 'push', 'email'] and cardinality(channels) > 0),
  send_at          timestamptz not null default now(),
  status           text not null default 'scheduled' check (status in ('draft', 'scheduled', 'sending', 'sent', 'cancelled', 'failed')),
  recipients_count int not null default 0,
  error            text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  sent_at          timestamptz,
  cancelled_at     timestamptz,
  check ((scope = 'restaurant') = (restaurant_id is not null)),
  check (scope = 'platform' or target in ('followers', 'coupon_users', 'past_customers', 'all_eligible')),
  check (scope = 'restaurant' or target not in ('followers', 'coupon_users', 'past_customers', 'all_eligible'))
);
create index campaigns_due_idx on public.campaigns(status, send_at);
create index campaigns_restaurant_idx on public.campaigns(restaurant_id, created_at desc);
create trigger campaigns_updated_at before update on public.campaigns for each row execute function public.set_updated_at();

create table public.campaign_deliveries (
  id              uuid primary key default gen_random_uuid(),
  campaign_id     uuid not null references public.campaigns(id) on delete cascade,
  user_id         uuid not null references public.profiles(id) on delete cascade,
  channel         text not null check (channel in ('in_app', 'push', 'email')),
  status          text not null default 'queued' check (status in ('queued', 'sent', 'delivered', 'failed', 'skipped')),
  notification_id uuid references public.notifications(id) on delete set null,
  sent_at         timestamptz,
  delivered_at    timestamptz,   -- solo con conferma reale (in-app: salvata; push: il servizio non conferma la consegna al dispositivo)
  opened_at       timestamptz,
  clicked_at      timestamptz,
  error           text,
  unique (campaign_id, user_id, channel)
);
create index campaign_deliveries_campaign_idx on public.campaign_deliveries(campaign_id, status);
create index campaign_deliveries_user_idx on public.campaign_deliveries(user_id, sent_at desc);
alter table public.push_outbox add constraint push_outbox_delivery_fk foreign key (campaign_delivery_id) references public.campaign_deliveries(id) on delete set null;

-- Destinatari: SOLO utenti che hanno scelto di riceverli (marketing o follow esplicito). Il ristoratore non li vede mai.
create or replace function public.campaign_audience(p_scope text, p_restaurant uuid, p_target text, p_targeting jsonb)
returns table (user_id uuid) language sql stable security definer set search_path = public as $$
  with base as (
    -- Ristorante
    select f.user_id from public.favorites f
     where p_scope = 'restaurant' and p_target in ('followers', 'all_eligible') and f.restaurant_id = p_restaurant and f.notifications_enabled
    union
    select c.user_id from public.coupon_claims c
     where p_scope = 'restaurant' and p_target in ('coupon_users', 'all_eligible') and c.restaurant_id = p_restaurant and c.user_id is not null
    union
    select x.user_id from public.reservations x
     where p_scope = 'restaurant' and p_target in ('past_customers', 'all_eligible') and x.restaurant_id = p_restaurant
       and x.user_id is not null and x.status = 'completed'
    union
    -- Piattaforma
    select p.id from public.profiles p where p_scope = 'platform' and p_target = 'all_users'
    union
    select p.id from public.profiles p join public.cities c on c.id = p.city_id
     where p_scope = 'platform' and p_target = 'city' and c.slug = p_targeting ->> 'city_slug'
    union
    select f.user_id from public.favorites f join public.restaurant_categories rc on rc.restaurant_id = f.restaurant_id
      join public.categories k on k.id = rc.category_id
     where p_scope = 'platform' and p_target = 'favorite_category' and k.slug = p_targeting ->> 'category_slug'
    union
    select x.user_id from public.reservations x
     where p_scope = 'platform' and p_target = 'upcoming_reservation' and x.user_id is not null and x.status in ('pending', 'confirmed')
       and x.reservation_date between (now() at time zone 'Europe/Rome')::date and (now() at time zone 'Europe/Rome')::date + 7
    union
    select d.user_id from public.user_activity_days d
     where p_scope = 'platform' and p_target = 'active_users' and d.day >= (now() at time zone 'Europe/Rome')::date - 30
    union
    select a.user_id from public.loyalty_accounts a
     where p_scope = 'platform' and p_target = 'loyalty_level' and a.level = p_targeting ->> 'level'
  )
  select b.user_id from base b
  join public.profiles p on p.id = b.user_id and not p.is_blocked
  left join public.notification_preferences np on np.user_id = b.user_id
  where coalesce(np.marketing, false)
     or (p_scope = 'restaurant' and coalesce(np.favorite_restaurants, false)
         and exists (select 1 from public.favorites f2 where f2.user_id = b.user_id and f2.restaurant_id = p_restaurant and f2.notifications_enabled))
  -- Il personale del locale non riceve le proprie campagne
    and not (p_scope = 'restaurant' and public.is_restaurant_insider(b.user_id, p_restaurant));
$$;

-- Solo numeri aggregati per l'anteprima
create or replace function public.campaign_audience_count(p_scope text, p_restaurant uuid, p_target text, p_targeting jsonb default '{}'::jsonb)
returns int language plpgsql stable security definer set search_path = public as $$
begin
  if p_scope = 'restaurant' then
    if not public.can_manage_restaurant(p_restaurant) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
  elsif not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  return (select count(*) from public.campaign_audience(p_scope, p_restaurant, p_target, coalesce(p_targeting, '{}'::jsonb)));
end $$;

create or replace function public.create_campaign(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_scope text := p ->> 'scope';
  v_rest uuid := case when (p ->> 'restaurant_id') ~* '^[0-9a-f-]{36}$' then (p ->> 'restaurant_id')::uuid end;
  v_limit int;
  v_used int;
  v_send timestamptz := coalesce((p ->> 'send_at')::timestamptz, now());
  v_channels text[];
  v_url text := nullif(trim(coalesce(p ->> 'action_url', '')), '');
  v_status text := case when p ->> 'status' = 'draft' then 'draft' else 'scheduled' end;
  r public.restaurants;
  v_id uuid;
begin
  if auth.uid() is null then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select coalesce(array_agg(distinct c), '{}') into v_channels
    from jsonb_array_elements_text(coalesce(p -> 'channels', '["in_app","push"]'::jsonb)) c where c in ('in_app', 'push', 'email');
  if cardinality(v_channels) = 0 then raise exception 'Scegli almeno un canale.'; end if;
  if v_send < now() - interval '5 minutes' or v_send > now() + interval '60 days' then raise exception 'Data di invio non valida.'; end if;
  if v_scope = 'restaurant' then
    if v_rest is null or not public.can_manage_restaurant(v_rest) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
    if not public.is_admin() and not exists (select 1 from public.restaurant_members m where m.restaurant_id = v_rest and m.user_id = auth.uid()
                                             and m.status = 'active' and m.role in ('owner', 'manager')) then
      raise exception 'Solo titolari e manager possono creare campagne.' using errcode = '42501';
    end if;
    perform public.assert_feature(v_rest, 'push_campaigns_enabled');
    v_limit := public.restaurant_feature_limit(v_rest, 'monthly_campaign_limit');
    select count(*) into v_used from public.campaigns
     where restaurant_id = v_rest and status in ('scheduled', 'sending', 'sent') and created_at >= date_trunc('month', now());
    if v_limit is not null and v_used >= v_limit then
      raise exception 'Hai raggiunto il limite di campagne del mese (%).', v_limit using hint = 'PLAN_LIMIT:monthly_campaign_limit';
    end if;
    if exists (select 1 from public.campaigns where restaurant_id = v_rest and status in ('scheduled', 'sending', 'sent')
               and created_at > now() - interval '24 hours') then
      raise exception 'Puoi creare al massimo una campagna al giorno.' using hint = 'rate_limited';
    end if;
    if p ->> 'target' not in ('followers', 'coupon_users', 'past_customers', 'all_eligible') then raise exception 'Destinatari non validi.'; end if;
    select * into r from public.restaurants where id = v_rest;
    -- Il ristoratore porta solo alla propria scheda; niente email dirette
    v_url := '/ristorante/' || r.slug || case when v_url ~ '^#(offerte|menu|prenota|recensioni)$' then v_url else '' end;
    v_channels := array(select unnest(v_channels) except select 'email');
    if cardinality(v_channels) = 0 then v_channels := array['in_app']; end if;
  elsif v_scope = 'platform' then
    if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
    if p ->> 'target' not in ('all_users', 'city', 'favorite_category', 'upcoming_reservation', 'active_users', 'loyalty_level') then
      raise exception 'Destinatari non validi.';
    end if;
    if v_url is not null and v_url !~ '^/[A-Za-z0-9/_#?=&.-]*$' then raise exception 'Link non valido: usa un percorso interno (es. /offers).'; end if;
  else
    raise exception 'Tipo di campagna non valido.';
  end if;
  insert into public.campaigns (scope, restaurant_id, created_by, title, message, action_url, target, targeting, channels, send_at, status)
  values (v_scope, v_rest, auth.uid(), trim(p ->> 'title'), trim(p ->> 'message'), v_url, p ->> 'target',
          coalesce(p -> 'targeting', '{}'::jsonb), v_channels, v_send, v_status)
  returning id into v_id;
  if v_scope = 'platform' then perform public.audit_admin('campaign_created', 'campaign', v_id::text, jsonb_build_object('target', p ->> 'target')); end if;
  return jsonb_build_object('id', v_id, 'status', v_status,
    'audience', (select count(*) from public.campaign_audience(v_scope, v_rest, p ->> 'target', coalesce(p -> 'targeting', '{}'::jsonb))));
end $$;

create or replace function public.cancel_campaign(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare c public.campaigns;
begin
  select * into c from public.campaigns where id = p_id for update;
  if not found then raise exception 'Campagna non trovata.'; end if;
  if c.scope = 'restaurant' and not public.can_manage_restaurant(c.restaurant_id) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
  if c.scope = 'platform' and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  if c.status not in ('draft', 'scheduled') then raise exception 'La campagna è già stata inviata.'; end if;
  update public.campaigns set status = 'cancelled', cancelled_at = now() where id = p_id;
  if public.is_admin() then perform public.audit_admin('campaign_cancelled', 'campaign', p_id::text, jsonb_build_object('scope', c.scope)); end if;
end $$;

-- Invio (solo scheduler/Admin): crea le consegne per canale, rispetta il tetto settimanale per utente
create or replace function public.campaign_dispatch(p_id uuid)
returns int language plpgsql security definer set search_path = public as $$
declare
  c public.campaigns;
  u record;
  v_n int := 0;
  v_cap int := public.billing_setting_int('campaign_max_per_user_week', 3);
  v_max int := public.billing_setting_int('campaign_max_recipients', 5000);
  v_notif uuid;
  v_del uuid;
  v_link text;
  pr public.notification_preferences;
  ch text;
  r public.restaurants;
begin
  select * into c from public.campaigns where id = p_id for update skip locked;
  if not found or c.status <> 'scheduled' or c.send_at > now() then return 0; end if;
  update public.campaigns set status = 'sending' where id = p_id;
  if c.scope = 'restaurant' then
    select * into r from public.restaurants where id = c.restaurant_id;
    if not public.restaurant_has_feature(c.restaurant_id, 'push_campaigns_enabled') then
      update public.campaigns set status = 'failed', error = 'Funzione non inclusa nel piano attuale' where id = p_id;
      return 0;
    end if;
  end if;
  for u in select a.user_id from public.campaign_audience(c.scope, c.restaurant_id, c.target, c.targeting) a limit v_max loop
    -- Tetto promozionale settimanale per persona (tutte le campagne)
    if (select count(distinct d.campaign_id) from public.campaign_deliveries d
        where d.user_id = u.user_id and d.status in ('sent', 'delivered', 'queued') and d.sent_at > now() - interval '7 days') >= v_cap then
      insert into public.campaign_deliveries (campaign_id, user_id, channel, status, error)
      values (p_id, u.user_id, c.channels[1], 'skipped', 'frequency_cap') on conflict do nothing;
      continue;
    end if;
    pr := public.user_prefs(u.user_id);
    foreach ch in array c.channels loop
      insert into public.campaign_deliveries (campaign_id, user_id, channel, status, sent_at)
      values (p_id, u.user_id, ch, 'queued', now()) on conflict do nothing returning id into v_del;
      continue when v_del is null;
      v_link := coalesce(c.action_url, '/') || case when coalesce(c.action_url, '/') ~ '\?' then '&' else '?' end || 'cd=' || v_del;
      if ch = 'in_app' then
        insert into public.notifications (user_id, restaurant_id, type, title, body, link, metadata)
        values (u.user_id, c.restaurant_id, 'promotion', c.title, c.message, v_link, jsonb_build_object('campaign_id', c.id, 'delivery_id', v_del))
        returning id into v_notif;
        update public.campaign_deliveries set status = 'delivered', notification_id = v_notif, delivered_at = now() where id = v_del;
      elsif ch = 'push' then
        if pr.push_enabled and exists (select 1 from public.push_subscriptions s where s.user_id = u.user_id and s.is_active) then
          insert into public.push_outbox (user_id, campaign_delivery_id, title, body, url, tag)
          values (u.user_id, v_del, c.title, c.message, v_link, 'campaign-' || left(c.id::text, 8));
        else
          update public.campaign_deliveries set status = 'skipped', error = 'no_push_subscription' where id = v_del;
        end if;
      elsif ch = 'email' then
        if pr.email_enabled then
          perform public.enqueue_email('marketing_campaign', (select email from public.profiles where id = u.user_id),
            jsonb_build_object('title', c.title, 'body', c.message, 'link', v_link), c.restaurant_id, null);
          update public.campaign_deliveries set status = 'sent' where id = v_del;
        else
          update public.campaign_deliveries set status = 'skipped', error = 'email_disabled' where id = v_del;
        end if;
      end if;
    end loop;
    v_n := v_n + 1;
  end loop;
  update public.campaigns set status = 'sent', sent_at = now(), recipients_count = v_n where id = p_id;
  return v_n;
exception when others then
  update public.campaigns set status = 'failed', error = left(sqlerrm, 200) where id = p_id;
  return 0;
end $$;

-- Aperture (notifica in-app letta) e click (link con ?cd=) — mai inventati
create or replace function public.notifications_campaign_open()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.read_at is not null and old.read_at is null and new.metadata ? 'delivery_id' then
    update public.campaign_deliveries set opened_at = coalesce(opened_at, new.read_at)
     where id = (new.metadata ->> 'delivery_id')::uuid;
  end if;
  return null;
end $$;
create trigger notifications_campaign_open after update of read_at on public.notifications
  for each row execute function public.notifications_campaign_open();

create or replace function public.track_campaign_click(p_delivery uuid)
returns void language sql security definer set search_path = public as $$
  update public.campaign_deliveries set clicked_at = coalesce(clicked_at, now()), opened_at = coalesce(opened_at, now())
   where id = p_delivery and status in ('sent', 'delivered');
$$;

create or replace function public.push_campaign_stats(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare c public.campaigns;
begin
  select * into c from public.campaigns where id = p_id;
  if not found then raise exception 'Campagna non trovata.'; end if;
  if not (public.is_admin() or (c.scope = 'restaurant' and public.can_manage_restaurant(c.restaurant_id))) then
    raise exception 'Operazione non consentita.' using errcode = '42501';
  end if;
  return (select jsonb_build_object(
    'recipients', c.recipients_count,
    'sent', count(*) filter (where status in ('sent', 'delivered')),
    'delivered', count(*) filter (where status = 'delivered'),
    'opened', count(*) filter (where opened_at is not null),
    'clicked', count(*) filter (where clicked_at is not null),
    'skipped', count(*) filter (where status = 'skipped'),
    'failed', count(*) filter (where status = 'failed'),
    'ctr', case when count(*) filter (where status in ('sent', 'delivered')) > 0
                then round(count(*) filter (where clicked_at is not null) * 100.0 / count(*) filter (where status in ('sent', 'delivered')), 1) else 0 end,
    'by_channel', coalesce((select jsonb_object_agg(channel, n) from (select channel, count(*) n from public.campaign_deliveries
                            where campaign_id = p_id and status in ('sent', 'delivered') group by channel) s), '{}'::jsonb))
  from public.campaign_deliveries where campaign_id = p_id);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  10. EFFETTI DEGLI EVENTI REALI (trigger)
-- ════════════════════════════════════════════════════════════════════
alter table public.reservations add column if not exists completed_at timestamptz;

create or replace function public.reservations_engagement_before()
returns trigger language plpgsql as $$
begin
  if new.status = 'completed' and (tg_op = 'INSERT' or old.status is distinct from 'completed') then new.completed_at := now(); end if;
  return new;
end $$;
create trigger reservations_engagement_before before insert or update of status on public.reservations
  for each row execute function public.reservations_engagement_before();

create or replace function public.reservations_engagement_after()
returns trigger language plpgsql security definer set search_path = public as $$
declare r public.restaurants; v_when text;
begin
  if new.user_id is null then return null; end if;
  if tg_op = 'INSERT' then
    perform public.touch_activity(new.user_id);
    return null;
  end if;
  if new.status is not distinct from old.status then return null; end if;
  select * into r from public.restaurants where id = new.restaurant_id;
  v_when := to_char(new.reservation_date, 'DD/MM') || ' alle ' || to_char(new.reservation_time, 'HH24:MI');
  if new.status = 'completed' then
    perform public.loyalty_award(new.user_id, 'reservation_completed', 'reservation', new.id, 'Visita da ' || r.name);
    perform public.referral_qualify(new.user_id);
    perform public.check_achievements(new.user_id);
  elsif new.status in ('confirmed', 'rejected') then
    perform public.notify_user(new.user_id, 'reservation',
      case new.status when 'confirmed' then 'Prenotazione confermata' else 'Prenotazione non accettata' end,
      r.name || ' · ' || v_when, '/dashboard/reservations', 'reservation_updates',
      'reservation_status:' || new.id || ':' || new.status, '{}'::jsonb, r.id);
  elsif new.status = 'cancelled' and new.status_changed_by is distinct from new.user_id then
    perform public.notify_user(new.user_id, 'reservation', 'Prenotazione cancellata dal ristorante', r.name || ' · ' || v_when,
      '/dashboard/reservations', 'reservation_updates', 'reservation_status:' || new.id || ':cancelled', '{}'::jsonb, r.id);
  end if;
  return null;
end $$;
create trigger reservations_engagement_after after insert or update of status on public.reservations
  for each row execute function public.reservations_engagement_after();

create or replace function public.coupon_claims_engagement()
returns trigger language plpgsql security definer set search_path = public as $$
declare c public.coupons;
begin
  if new.user_id is null then return null; end if;
  if tg_op = 'INSERT' then
    perform public.touch_activity(new.user_id);
  elsif new.status = 'redeemed' and old.status is distinct from 'redeemed' then
    select * into c from public.coupons where id = new.coupon_id;
    perform public.loyalty_award(new.user_id, 'coupon_redeemed', 'coupon', new.id, 'Coupon utilizzato: ' || coalesce(c.title, ''));
    perform public.referral_qualify(new.user_id);
    perform public.check_achievements(new.user_id);
  end if;
  return null;
end $$;
create trigger coupon_claims_engagement after insert or update of status on public.coupon_claims
  for each row execute function public.coupon_claims_engagement();

-- Nuovo profilo: saldo punti, codice invito, preferenze prudenti, bonus di registrazione (se previsto)
create or replace function public.profiles_engagement_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.loyalty_accounts (user_id) values (new.id) on conflict do nothing;
  insert into public.notification_preferences (user_id, marketing) values (new.id, coalesce(new.marketing_opt_in, false)) on conflict do nothing;
  perform public.ensure_referral_code(new.id);
  perform public.loyalty_award(new.id, 'account_created', 'profile', new.id, 'Benvenuto in AsiaFood');
  return null;
end $$;
create trigger profiles_engagement_insert after insert on public.profiles
  for each row execute function public.profiles_engagement_insert();

create or replace function public.profiles_engagement_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if array_length(regexp_split_to_array(trim(coalesce(new.full_name, '')), '\s+'), 1) >= 2
     and nullif(trim(coalesce(new.phone, '')), '') is not null and new.city_id is not null then
    perform public.loyalty_award(new.id, 'profile_completed', 'profile', new.id, 'Profilo completato');
  end if;
  return null;
end $$;
create trigger profiles_engagement_update after update of full_name, phone, city_id on public.profiles
  for each row execute function public.profiles_engagement_update();

-- Profili già esistenti: saldo, codice e preferenze (nessun punto retroattivo)
insert into public.loyalty_accounts (user_id) select id from public.profiles on conflict do nothing;
insert into public.notification_preferences (user_id, marketing) select id, marketing_opt_in from public.profiles on conflict do nothing;
select public.ensure_referral_code(id) from public.profiles;

-- ════════════════════════════════════════════════════════════════════
--  11. SCHEDULER (Netlify scheduled function / Admin): promemoria, richieste
--      di recensione, campagne programmate, scadenze. Mai affidato al browser.
-- ════════════════════════════════════════════════════════════════════
create or replace function public.engagement_tick(p_now timestamptz default now())
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_hours int[];
  v_h int; v_next int; i int;
  x record;
  v_start timestamptz;
  v_local_date date;
  v_today date := (p_now at time zone 'Europe/Rome')::date;
  v_text text;
  v_res int := 0; v_guest int := 0; v_cpn int := 0; v_rev int := 0; v_ref int := 0; v_camp int := 0; v_exp int := 0;
  v_delay int := public.billing_setting_int('review_request_delay_hours', 2);
  v_cpn_h int := public.billing_setting_int('coupon_expiry_reminder_hours', 24);
  v_cool int := public.billing_setting_int('review_cooldown_days', 90);
  a public.loyalty_accounts;
  v_take int;
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;

  -- 1) Promemoria prenotazione (es. 24 h e 2 h prima), mai per prenotazioni annullate/rifiutate/completate
  select coalesce(array_agg(h order by h desc), array[24, 2]) into v_hours
    from (select (jsonb_array_elements_text(value))::int h from public.platform_settings where key = 'reservation_reminder_hours') s where h between 1 and 168;
  for i in 1 .. coalesce(array_length(v_hours, 1), 0) loop
    v_h := v_hours[i];
    v_next := coalesce(v_hours[i + 1], 0);
    for x in select rv.*, r.name as rname, r.slug as rslug, coalesce(r.timezone, 'Europe/Rome') as tz
             from public.reservations rv join public.restaurants r on r.id = rv.restaurant_id
             where rv.status in ('pending', 'confirmed')
               and rv.reservation_date between v_today - 1 and v_today + 8 loop
      v_start := (x.reservation_date + x.reservation_time) at time zone x.tz;
      continue when not (v_start - p_now <= make_interval(hours => v_h) and v_start - p_now > make_interval(hours => v_next));
      v_local_date := x.reservation_date;
      v_text := case when v_local_date = v_today then 'Oggi' when v_local_date = v_today + 1 then 'Domani' else 'Il ' || to_char(v_local_date, 'DD/MM') end
                || ' alle ' || to_char(x.reservation_time, 'HH24:MI') || ' hai una prenotazione da ' || x.rname || '.'
                || case when x.status = 'pending' then ' È ancora in attesa di conferma.' else '' end;
      if x.user_id is not null then
        if public.notify_user(x.user_id, 'reservation', 'Promemoria prenotazione', v_text, '/dashboard/reservations', 'reservation_reminders',
             'reservation_reminder:' || v_h || ':' || x.id, jsonb_build_object('reservation_id', x.id, 'hours', v_h), x.restaurant_id,
             case when i = 1 then 'reservation_reminder' end,
             jsonb_build_object('restaurant', x.rname, 'date', x.reservation_date, 'time', to_char(x.reservation_time, 'HH24:MI'), 'code', x.confirmation_code)) is not null then
          v_res := v_res + 1;
        end if;
      elsif i = 1 and x.guest_email is not null then
        -- Ospite senza account: solo il primo promemoria via email (transazionale), una volta
        insert into public.notification_delivery_log (dedupe_key, kind, status, channels)
        values ('reservation_reminder:' || v_h || ':' || x.id, 'reservation', 'sent', array['email']) on conflict do nothing;
        if found then
          perform public.enqueue_email('reservation_reminder', x.guest_email, jsonb_build_object('restaurant', x.rname, 'restaurant_slug', x.rslug,
            'guest_name', x.guest_name, 'date', x.reservation_date, 'time', to_char(x.reservation_time, 'HH24:MI'), 'code', x.confirmation_code,
            'body', v_text), x.restaurant_id, x.id);
          v_guest := v_guest + 1;
        end if;
      end if;
    end loop;
  end loop;

  -- 2) Coupon in scadenza (ancora da usare, non scaduti)
  for x in select cc.id, cc.user_id, cc.restaurant_id, c.title, c.valid_until, r.name as rname, r.slug as rslug
           from public.coupon_claims cc join public.coupons c on c.id = cc.coupon_id join public.restaurants r on r.id = cc.restaurant_id
           where cc.status = 'claimed' and cc.user_id is not null and c.is_active
             and c.valid_until > p_now and c.valid_until <= p_now + make_interval(hours => v_cpn_h) loop
    v_text := 'Il tuo coupon “' || x.title || '” di ' || x.rname || ' scade '
              || case when (x.valid_until at time zone 'Europe/Rome')::date = v_today then 'oggi alle ' || to_char(x.valid_until at time zone 'Europe/Rome', 'HH24:MI')
                      else 'domani' end || '.';
    if public.notify_user(x.user_id, 'coupon', 'Coupon in scadenza', v_text, '/dashboard/coupons', 'coupon_expiry',
         'coupon_expiry:' || x.id, jsonb_build_object('claim_id', x.id), x.restaurant_id, 'coupon_expiring',
         jsonb_build_object('restaurant', x.rname, 'coupon', x.title, 'valid_until', x.valid_until)) is not null then
      v_cpn := v_cpn + 1;
    end if;
  end loop;

  -- 3) Richiesta di recensione dopo la visita (una sola, niente se già recensita)
  for x in select rv.id, rv.user_id, rv.restaurant_id, r.name as rname, r.slug as rslug
           from public.reservations rv join public.restaurants r on r.id = rv.restaurant_id
           where rv.status = 'completed' and rv.user_id is not null and rv.completed_at is not null
             and rv.completed_at <= p_now - make_interval(hours => v_delay) and rv.completed_at > p_now - interval '14 days'
             and not exists (select 1 from public.reviews v where v.reservation_id = rv.id)
             and not exists (select 1 from public.reviews v where v.user_id = rv.user_id and v.restaurant_id = rv.restaurant_id
                             and v.status in ('published', 'pending', 'flagged') and v.created_at > p_now - make_interval(days => v_cool))
             and not public.is_restaurant_insider(rv.user_id, rv.restaurant_id) loop
    if public.notify_user(x.user_id, 'review', 'Com’è andata da ' || x.rname || '?', 'Racconta la tua esperienza: la tua recensione aiuta altre persone a scegliere.',
         '/ristorante/' || x.rslug || '?review=1#recensioni', 'reservation_updates', 'review_request:' || x.id,
         jsonb_build_object('reservation_id', x.id), x.restaurant_id, 'review_request',
         jsonb_build_object('restaurant', x.rname, 'restaurant_slug', x.rslug)) is not null then
      v_rev := v_rev + 1;
    end if;
  end loop;

  -- 4) Referral in attesa (email verificata più tardi)
  for x in select referred_user_id from public.referrals where status = 'registered' and referred_user_id is not null limit 500 loop
    if public.referral_qualify(x.referred_user_id) then v_ref := v_ref + 1; end if;
  end loop;

  -- 5) Campagne programmate
  for x in select id from public.campaigns where status = 'scheduled' and send_at <= p_now order by send_at limit 20 loop
    perform public.campaign_dispatch(x.id);
    v_camp := v_camp + 1;
  end loop;

  -- 6) Scadenze: punti (FIFO), premi, notifiche
  for x in select * from public.loyalty_transactions where points_remaining > 0 and expires_at is not null and expires_at <= p_now limit 1000 loop
    a := public.loyalty_account(x.user_id);
    v_take := least(x.points_remaining, a.points_balance);
    update public.loyalty_transactions set points_remaining = 0 where id = x.id;
    if v_take > 0 then
      insert into public.loyalty_transactions (user_id, type, points, balance_after, event_key, source_type, source_id, description)
      values (x.user_id, 'expire', -v_take, a.points_balance - v_take, 'points_expired', 'other', x.id, 'Punti scaduti')
      on conflict (user_id, event_key, source_type, source_id) where source_id is not null do nothing;
      if found then
        update public.loyalty_accounts set points_balance = points_balance - v_take where user_id = x.user_id;
        v_exp := v_exp + 1;
      end if;
    end if;
  end loop;
  update public.reward_redemptions set status = 'expired' where status = 'claimed' and expires_at is not null and expires_at <= p_now;
  delete from public.notifications where expires_at is not null and expires_at <= p_now;

  return jsonb_build_object('reservation_reminders', v_res, 'guest_reminders', v_guest, 'coupon_reminders', v_cpn,
    'review_requests', v_rev, 'referrals_qualified', v_ref, 'campaigns', v_camp, 'points_expired', v_exp);
end $$;

-- ════════════════════════════════════════════════════════════════════
--  12. STATISTICHE: retention (Admin) e fidelizzazione (ristoratore)
-- ════════════════════════════════════════════════════════════════════
create or replace function public.admin_retention_stats(p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_days int := least(greatest(coalesce(p_days, 30), 7), 365);
  v_today date := (now() at time zone 'Europe/Rome')::date;
  v_since timestamptz := now() - make_interval(days => v_days);
  v_mau int;
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select count(distinct user_id) into v_mau from public.user_activity_days where day > v_today - 30;
  return jsonb_build_object(
    'definitions', jsonb_build_object(
      'active', 'Utente registrato con almeno un evento significativo nel giorno: accesso all''app, prenotazione, recensione, coupon, premio o follow.',
      'dau', 'Utenti attivi oggi', 'wau', 'Utenti attivi negli ultimi 7 giorni', 'mau', 'Utenti attivi negli ultimi 30 giorni',
      'returning', 'Attivi nel periodo che erano già stati attivi nel periodo precedente di pari durata'),
    'dau', (select count(*) from public.user_activity_days where day = v_today),
    'wau', (select count(distinct user_id) from public.user_activity_days where day > v_today - 7),
    'mau', v_mau,
    'returning_users', (select count(distinct d.user_id) from public.user_activity_days d where d.day > v_today - v_days
                        and exists (select 1 from public.user_activity_days e where e.user_id = d.user_id and e.day <= v_today - v_days and e.day > v_today - 2 * v_days)),
    'previous_period_users', (select count(distinct user_id) from public.user_activity_days where day <= v_today - v_days and day > v_today - 2 * v_days),
    'repeat_reservation_users', (select count(*) from (select user_id from public.reservations where user_id is not null and status = 'completed' group by user_id having count(*) >= 2) s),
    'reservation_users', (select count(distinct user_id) from public.reservations where user_id is not null and status = 'completed'),
    'completed_reservations', (select count(*) from public.reservations where status = 'completed' and completed_at >= v_since),
    'reviews_published', (select count(*) from public.reviews where status = 'published' and published_at >= v_since),
    'reviews_verified', (select count(*) from public.reviews where status = 'published' and is_verified and published_at >= v_since),
    'reviews_pending', (select count(*) from public.reviews where status in ('pending', 'flagged')),
    'referral_signups', (select count(*) from public.referrals where registered_at >= v_since),
    'referral_qualified', (select count(*) from public.referrals where qualified_at >= v_since),
    'points_issued', (select coalesce(sum(points), 0) from public.loyalty_transactions where points > 0 and type <> 'adjustment' and created_at >= v_since),
    'points_redeemed', (select coalesce(-sum(points), 0) from public.loyalty_transactions where type = 'redeem' and created_at >= v_since),
    'rewards_redeemed', (select count(*) from public.reward_redemptions where created_at >= v_since),
    'push_subscribers', (select count(distinct user_id) from public.push_subscriptions where is_active),
    'coupon_users', (select count(distinct user_id) from public.coupon_claims where user_id is not null and status = 'redeemed'),
    'coupon_repeat_users', (select count(*) from (select user_id from public.coupon_claims where user_id is not null and status = 'redeemed' group by user_id having count(*) >= 2) s),
    'followers', (select count(*) from public.favorites where notifications_enabled),
    'daily', (select jsonb_agg(jsonb_build_object('day', d::date, 'active', (select count(*) from public.user_activity_days a where a.day = d::date)) order by d)
              from generate_series(v_today - least(v_days, 60) + 1, v_today, interval '1 day') d));
end $$;

create or replace function public.restaurant_engagement_stats(p_restaurant uuid, p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_since timestamptz := now() - make_interval(days => least(greatest(coalesce(p_days, 30), 1), 365));
begin
  if not public.can_manage_restaurant(p_restaurant) then raise exception 'Operazione non consentita.' using errcode = '42501'; end if;
  perform public.assert_feature(p_restaurant, 'analytics_enabled');
  return jsonb_build_object(
    'rating', public.restaurant_rating(p_restaurant),
    'followers', (select count(*) from public.favorites where restaurant_id = p_restaurant and notifications_enabled),
    'favorites', (select count(*) from public.favorites where restaurant_id = p_restaurant),
    'customers', (select count(distinct user_id) from public.reservations where restaurant_id = p_restaurant and user_id is not null and status = 'completed'),
    'returning_customers', (select count(*) from (select user_id from public.reservations where restaurant_id = p_restaurant and user_id is not null
                            and status = 'completed' group by user_id having count(*) >= 2) s),
    'coupon_redemptions', (select count(*) from public.coupon_claims where restaurant_id = p_restaurant and status = 'redeemed' and redeemed_at >= v_since),
    'campaign_sends', (select count(*) from public.campaign_deliveries d join public.campaigns c on c.id = d.campaign_id
                       where c.restaurant_id = p_restaurant and d.status in ('sent', 'delivered') and d.sent_at >= v_since),
    'campaign_clicks', (select count(*) from public.campaign_deliveries d join public.campaigns c on c.id = d.campaign_id
                        where c.restaurant_id = p_restaurant and d.clicked_at >= v_since));
end $$;

-- ════════════════════════════════════════════════════════════════════
--  13. RLS E PRIVILEGI
-- ════════════════════════════════════════════════════════════════════
alter table public.admin_audit_logs         enable row level security;
alter table public.user_activity_days       enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.push_subscriptions       enable row level security;
alter table public.notification_delivery_log enable row level security;
alter table public.push_outbox              enable row level security;
alter table public.loyalty_levels           enable row level security;
alter table public.loyalty_accounts         enable row level security;
alter table public.loyalty_rules            enable row level security;
alter table public.loyalty_transactions     enable row level security;
alter table public.rewards                  enable row level security;
alter table public.reward_redemptions       enable row level security;
alter table public.achievements             enable row level security;
alter table public.user_achievements        enable row level security;
alter table public.reviews                  enable row level security;
alter table public.review_versions          enable row level security;
alter table public.review_responses         enable row level security;
alter table public.review_votes             enable row level security;
alter table public.review_reports           enable row level security;
alter table public.referral_codes           enable row level security;
alter table public.referrals                enable row level security;
alter table public.business_referrals       enable row level security;
alter table public.campaigns                enable row level security;
alter table public.campaign_deliveries      enable row level security;

create policy "audit_admin_read" on public.admin_audit_logs for select to authenticated using (public.is_admin());
create policy "activity_admin_read" on public.user_activity_days for select to authenticated using (public.is_admin());
create policy "prefs_own" on public.notification_preferences for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "push_subs_own_read" on public.push_subscriptions for select to authenticated using (user_id = auth.uid());
create policy "push_subs_own_delete" on public.push_subscriptions for delete to authenticated using (user_id = auth.uid());
create policy "levels_read" on public.loyalty_levels for select using (is_active or public.is_admin());
create policy "levels_admin" on public.loyalty_levels for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "loyalty_accounts_own" on public.loyalty_accounts for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "loyalty_rules_read" on public.loyalty_rules for select using (true);
create policy "loyalty_rules_admin" on public.loyalty_rules for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "loyalty_tx_own" on public.loyalty_transactions for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "rewards_read" on public.rewards for select using ((is_active and starts_at <= now() and (ends_at is null or ends_at > now())) or public.is_admin());
create policy "rewards_admin" on public.rewards for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "redemptions_own" on public.reward_redemptions for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "achievements_read" on public.achievements for select using (is_active or public.is_admin());
create policy "achievements_admin" on public.achievements for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "user_achievements_own" on public.user_achievements for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "reviews_read" on public.reviews for select
  using ((status = 'published' and public.restaurant_is_public(restaurant_id)) or user_id = auth.uid() or public.is_admin());
create policy "review_versions_own" on public.review_versions for select to authenticated
  using (public.is_admin() or exists (select 1 from public.reviews v where v.id = review_id and v.user_id = auth.uid()));
create policy "review_responses_read" on public.review_responses for select
  using (status = 'published' or public.can_manage_restaurant(restaurant_id));
create policy "review_votes_own" on public.review_votes for select to authenticated using (user_id = auth.uid());
create policy "review_reports_own" on public.review_reports for select to authenticated using (reporter_user_id = auth.uid() or public.is_admin());
create policy "referral_codes_own" on public.referral_codes for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "referrals_own" on public.referrals for select to authenticated
  using (referrer_user_id = auth.uid() or referred_user_id = auth.uid() or public.is_admin());
create policy "business_referrals_own" on public.business_referrals for select to authenticated
  using (referrer_user_id = auth.uid() or public.can_manage_restaurant(referrer_restaurant_id) or public.is_admin());
create policy "campaigns_manage_read" on public.campaigns for select to authenticated
  using (public.is_admin() or (scope = 'restaurant' and public.can_manage_restaurant(restaurant_id)));
create policy "campaign_deliveries_admin" on public.campaign_deliveries for select to authenticated using (public.is_admin());

-- Nessuna scrittura diretta dal client su saldi, recensioni, referral, campagne: solo funzioni controllate
grant select on public.loyalty_levels, public.loyalty_rules, public.rewards, public.achievements, public.reviews, public.review_responses to anon, authenticated;
grant select on public.loyalty_accounts, public.loyalty_transactions, public.reward_redemptions, public.user_achievements, public.review_versions,
                public.review_votes, public.review_reports, public.referral_codes, public.referrals, public.business_referrals, public.campaigns,
                public.campaign_deliveries, public.admin_audit_logs, public.user_activity_days, public.push_subscriptions to authenticated;
grant select, insert, update on public.notification_preferences to authenticated;
grant delete on public.push_subscriptions to authenticated;
grant insert, update, delete on public.loyalty_rules, public.loyalty_levels, public.rewards, public.achievements to authenticated;   -- solo Admin (RLS)
revoke insert, update, delete on public.loyalty_accounts, public.loyalty_transactions, public.reward_redemptions, public.user_achievements,
                                 public.reviews, public.review_versions, public.review_responses, public.review_votes, public.review_reports,
                                 public.referral_codes, public.referrals, public.business_referrals, public.campaigns, public.campaign_deliveries,
                                 public.admin_audit_logs, public.user_activity_days, public.push_outbox, public.notification_delivery_log from anon, authenticated;
revoke all on public.push_outbox, public.notification_delivery_log from anon, authenticated;

-- Funzioni interne: mai chiamabili dal browser
do $$ declare f text;
begin
  foreach f in array array[
    'audit_admin(text, text, text, jsonb)', 'touch_activity(uuid)', 'user_prefs(uuid)',
    'notify_user(uuid, text, text, text, text, text, text, jsonb, uuid, text, jsonb)',
    'loyalty_account(uuid)', 'loyalty_award(uuid, text, text, uuid, text, int)', 'loyalty_consume(uuid, int)',
    'check_achievements(uuid)', 'referral_qualify(uuid, boolean)', 'ensure_referral_code(uuid)', 'review_verification_for(uuid, uuid, uuid)',
    'notify_followers(uuid, text, text, text, uuid)', 'campaign_audience(text, uuid, text, jsonb)', 'campaign_dispatch(uuid)',
    'is_restaurant_insider(uuid, uuid)', 'gen_code(text, int)'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
  foreach f in array array['push_claim_batch(int)', 'push_report(jsonb)'] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
  foreach f in array array[
    'record_activity()', 'save_push_subscription(text, text, text, text, text)', 'remove_push_subscription(text)',
    'redeem_reward(uuid)', 'my_loyalty(int, int)', 'my_review_status(uuid)', 'submit_review(uuid, jsonb)', 'update_review(uuid, jsonb)',
    'vote_review(uuid, boolean)', 'report_review(uuid, text, text)', 'respond_to_review(uuid, text)', 'restaurant_reviews_manage(uuid, int, int)',
    'apply_referral_code(text)', 'my_referrals()', 'create_business_referral(uuid, text, text)', 'set_follow(uuid, boolean)',
    'campaign_audience_count(text, uuid, text, jsonb)', 'create_campaign(jsonb)', 'cancel_campaign(uuid)', 'push_campaign_stats(uuid)',
    'restaurant_engagement_stats(uuid, int)', 'moderate_review(uuid, text, text)', 'admin_list_reviews(text, int, int)',
    'admin_loyalty_adjust(uuid, int, text)', 'admin_update_redemption(uuid, text)', 'admin_referral_action(uuid, text, text)',
    'admin_list_referrals(text, int)', 'admin_business_referral_update(uuid, text, text, int, uuid, text)', 'admin_retention_stats(int)',
    'engagement_tick(timestamptz)'
  ] loop
    execute format('revoke all on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated, service_role', f);
  end loop;
  foreach f in array array['list_reviews(uuid, text, text, int, int)', 'restaurant_rating(uuid)', 'restaurants_rating(uuid[])',
                           'track_campaign_click(uuid)', 'public_display_name(uuid)'] loop
    execute format('grant execute on function public.%s to anon, authenticated, service_role', f);
  end loop;
end $$;

-- Realtime (se disponibile): solo le notifiche dell'utente (RLS), niente sottoscrizioni inutili
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin
      alter publication supabase_realtime add table public.notifications;
    exception when duplicate_object then null;
    end;
  end if;
end $$;
