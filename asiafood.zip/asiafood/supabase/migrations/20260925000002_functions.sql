-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0002 · Funzioni di dominio (ruoli, claim, ricerca, analytics)
-- ════════════════════════════════════════════════════════════════════

-- ─── Helper ruoli (security definer: evitano ricorsione RLS su profiles) ───
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin' and not p.is_blocked
  );
$$;

create or replace function public.owns_restaurant(p_restaurant_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.restaurants r
    join public.profiles p on p.id = r.owner_id
    where r.id = p_restaurant_id and r.owner_id = auth.uid() and not p.is_blocked
  );
$$;

create or replace function public.can_manage_restaurant(p_restaurant_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_admin() or public.owns_restaurant(p_restaurant_id);
$$;

create or replace function public.current_user_role()
returns public.user_role language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid();
$$;

-- ─── Protezione campi riservati all'Admin ────────────────────────────
-- Un ristoratore può aggiornare i dati del proprio locale, ma NON:
-- proprietà, verifica, attivazione, evidenza/sponsor, piano, popolarità, flag demo.
create or replace function public.protect_restaurant_admin_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    new.owner_id         := old.owner_id;
    new.is_verified      := old.is_verified;
    new.is_active        := old.is_active;
    new.is_featured      := old.is_featured;
    new.is_sponsored     := old.is_sponsored;
    new.is_demo          := old.is_demo;
    new.subscription_plan:= old.subscription_plan;
    new.popularity_score := old.popularity_score;
    new.slug             := old.slug;   -- lo slug è un URL SEO: lo cambia solo l'Admin (con redirect)
  end if;
  return new;
end $$;

create trigger restaurants_protect_admin_fields
  before update on public.restaurants
  for each row execute function public.protect_restaurant_admin_fields();

-- Un utente non può promuovere se stesso: ruolo e blocco li modifica solo l'Admin
create or replace function public.protect_profile_role()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    new.role := old.role;
    new.is_blocked := old.is_blocked;
  end if;
  return new;
end $$;

create trigger profiles_protect_role
  before update on public.profiles
  for each row execute function public.protect_profile_role();

-- ─── Workflow rivendicazione ─────────────────────────────────────────
create or replace function public.approve_claim(p_claim_id uuid, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_claim public.restaurant_claims;
begin
  if not public.is_admin() then
    raise exception 'Solo un amministratore può approvare le rivendicazioni' using errcode = '42501';
  end if;

  select * into v_claim from public.restaurant_claims where id = p_claim_id for update;
  if not found then raise exception 'Richiesta non trovata'; end if;
  if v_claim.status <> 'pending' then raise exception 'La richiesta è già stata gestita'; end if;

  update public.restaurants
     set owner_id = v_claim.user_id, is_verified = true
   where id = v_claim.restaurant_id;

  update public.profiles
     set role = 'restaurant_owner'
   where id = v_claim.user_id and role = 'customer';

  update public.restaurant_claims
     set status = 'approved', admin_notes = p_notes, reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_claim_id;

  -- Le altre richieste in attesa sullo stesso locale vengono chiuse
  update public.restaurant_claims
     set status = 'rejected',
         admin_notes = coalesce(admin_notes, 'Rivendicazione assegnata ad altro richiedente'),
         reviewed_by = auth.uid(), reviewed_at = now()
   where restaurant_id = v_claim.restaurant_id and status = 'pending' and id <> p_claim_id;
end $$;

create or replace function public.reject_claim(p_claim_id uuid, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then
    raise exception 'Solo un amministratore può rifiutare le rivendicazioni' using errcode = '42501';
  end if;
  update public.restaurant_claims
     set status = 'rejected', admin_notes = p_notes, reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_claim_id and status = 'pending';
  if not found then raise exception 'Richiesta non trovata o già gestita'; end if;
end $$;

-- ─── Ricerca per distanza (Haversine; migrabile a PostGIS senza cambiare l'API) ───
create or replace function public.restaurants_nearby(
  p_lat double precision,
  p_lng double precision,
  p_radius_km double precision default 25,
  p_limit int default 50
)
returns table (restaurant_id uuid, distance_km double precision)
language sql stable security invoker set search_path = public as $$
  select id, d from (
    select r.id,
           6371 * 2 * asin(sqrt(least(1,
             power(sin(radians(r.latitude - p_lat) / 2), 2) +
             cos(radians(p_lat)) * cos(radians(r.latitude)) *
             power(sin(radians(r.longitude - p_lng) / 2), 2)
           ))) as d
    from public.restaurants r
    where r.is_active and r.latitude is not null and r.longitude is not null
      -- prefiltro bounding box (usa l'indice lat/lng)
      and r.latitude  between p_lat - p_radius_km / 111.0 and p_lat + p_radius_km / 111.0
      and r.longitude between p_lng - p_radius_km / (111.0 * greatest(cos(radians(p_lat)), 0.01))
                          and p_lng + p_radius_km / (111.0 * greatest(cos(radians(p_lat)), 0.01))
  ) x
  where d <= p_radius_km
  order by d
  limit p_limit;
$$;

-- ─── Tracciamento eventi (unico punto d'ingresso, niente INSERT diretti) ───
create or replace function public.track_event(
  p_restaurant_id uuid,
  p_event_type public.analytics_event_type,
  p_session_id text default null,
  p_source text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.restaurants where id = p_restaurant_id and is_active) then
    return;
  end if;
  insert into public.analytics_events (restaurant_id, event_type, user_id, session_id, source, metadata)
  values (p_restaurant_id, p_event_type, auth.uid(), left(p_session_id, 64), left(p_source, 40),
          coalesce(p_metadata, '{}'::jsonb));
end $$;

-- Statistiche per ristorante (ultimi N giorni) — accessibile a proprietario e Admin
create or replace function public.restaurant_stats(p_restaurant_id uuid, p_days int default 30)
returns table (event_type public.analytics_event_type, total bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.can_manage_restaurant(p_restaurant_id) then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  return query
    select e.event_type, count(*)::bigint
    from public.analytics_events e
    where e.restaurant_id = p_restaurant_id and e.created_at >= now() - make_interval(days => p_days)
    group by e.event_type;
end $$;

-- KPI dashboard Admin
create or replace function public.admin_dashboard_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb;
begin
  if not public.is_admin() then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  select jsonb_build_object(
    'restaurants_total',    (select count(*) from public.restaurants),
    'restaurants_active',   (select count(*) from public.restaurants where is_active),
    'restaurants_claimed',  (select count(*) from public.restaurants where owner_id is not null),
    'restaurants_demo',     (select count(*) from public.restaurants where is_demo),
    'claims_pending',       (select count(*) from public.restaurant_claims where status = 'pending'),
    'users_total',          (select count(*) from public.profiles),
    'owners_total',         (select count(*) from public.profiles where role = 'restaurant_owner'),
    'offers_active',        (select count(*) from public.offers where is_active and (ends_at is null or ends_at > now())),
    'coupons_active',       (select count(*) from public.coupons where is_active and (valid_until is null or valid_until > now())),
    'sponsored_active',     (select count(*) from public.sponsored_restaurants where is_active and (ends_at is null or ends_at > now())),
    'events_30d',           (select count(*) from public.analytics_events where created_at >= now() - interval '30 days'),
    'views_30d',            (select count(*) from public.analytics_events where event_type = 'view' and created_at >= now() - interval '30 days')
  ) into v;
  return v;
end $$;

-- Permessi di esecuzione RPC
revoke all on function public.approve_claim(uuid, text) from public, anon;
revoke all on function public.reject_claim(uuid, text) from public, anon;
revoke all on function public.admin_dashboard_stats() from public, anon;
revoke all on function public.restaurant_stats(uuid, int) from public, anon;
grant execute on function public.approve_claim(uuid, text) to authenticated;
grant execute on function public.reject_claim(uuid, text) to authenticated;
grant execute on function public.admin_dashboard_stats() to authenticated;
grant execute on function public.restaurant_stats(uuid, int) to authenticated;
grant execute on function public.track_event(uuid, public.analytics_event_type, text, text, jsonb) to anon, authenticated;
grant execute on function public.restaurants_nearby(double precision, double precision, double precision, int) to anon, authenticated;
