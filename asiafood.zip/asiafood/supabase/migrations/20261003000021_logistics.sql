-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0021 · Fase 9: logistica proprietaria (Rider AsiaFood)
--
--  - Rider: candidatura, documenti privati, approvazione Admin, online/offline,
--    posizione (solo online, retention configurabile, controlli anti-spoofing).
--  - Delivery job per gli ordini con delivery_provider_type = 'asiafood':
--    dispatch automatico a raggi crescenti (3 → 5 → 8 → 10 km), offerte con
--    timeout, accettazione ATOMICA (un solo Rider), dispatch manuale Admin.
--  - Macchina a stati centrale, sincronizzazione con lo stato dell'ordine,
--    ETA stimata (range), prova di consegna (codice / foto / conferma).
--  - Compensi Rider da regole configurabili (nessun payout automatico).
--  - Tracking cliente/ristorante con posizione mostrata solo quando serve.
--  Il flusso "consegna del ristorante" (delivery_provider_type = 'restaurant')
--  resta invariato.
-- ════════════════════════════════════════════════════════════════════

-- ────────────────────────────────────────────────────────────────────
--  1. IMPOSTAZIONI (modificabili da Admin → Logistica → Impostazioni)
-- ────────────────────────────────────────────────────────────────────
insert into public.platform_settings (key, value, description) values
  ('logistics_enabled', 'true', 'Servizio Rider AsiaFood attivo (se false, nessuna nuova consegna AsiaFood)'),
  ('logistics_auto_dispatch_enabled', 'true', 'Assegnazione automatica delle consegne ai Rider'),
  ('logistics_search_radii', '"3,5,8,10"', 'Raggi di ricerca Rider (km), in ordine crescente'),
  ('logistics_initial_search_radius', '3', 'Raggio iniziale di ricerca Rider (km)'),
  ('logistics_max_search_radius', '10', 'Raggio massimo di ricerca Rider (km): oltre non si cerca'),
  ('logistics_offer_timeout_seconds', '30', 'Secondi per accettare un''offerta di consegna'),
  ('logistics_location_interval_active', '15', 'Secondi tra due posizioni durante una consegna attiva'),
  ('logistics_location_interval_idle', '60', 'Secondi tra due posizioni quando il Rider è online in attesa'),
  ('logistics_location_retention_hours', '24', 'Ore di conservazione delle posizioni precise dei Rider'),
  ('logistics_default_rider_capacity', '1', 'Consegne contemporanee per Rider (MVP: 1)'),
  ('logistics_delivery_code_required', 'false', 'Codice di consegna (OTP 4 cifre) richiesto per chiudere la consegna'),
  ('logistics_pickup_code_required', 'true', 'Il Rider inserisce il codice di ritiro comunicato dal ristorante'),
  ('logistics_proof_of_delivery_type', '"confirmation"', 'Prova di consegna: confirmation | otp | photo'),
  ('logistics_dispatch_strategy', '"immediate"', 'immediate = subito dopo l''accettazione; before_ready = X minuti prima di "pronto"'),
  ('logistics_dispatch_before_ready_minutes', '10', 'Minuti prima dell''orario "pronto" in cui cercare il Rider (strategia before_ready)'),
  ('logistics_max_dispatch_attempts', '20', 'Tentativi di ricerca automatica prima di richiedere intervento manuale'),
  ('logistics_alert_unassigned_minutes', '10', 'Avviso Admin se una consegna resta senza Rider per più minuti'),
  ('logistics_rider_stale_minutes', '5', 'Avviso se il Rider con consegna attiva non invia posizione/stato per più minuti'),
  ('logistics_rider_stationary_minutes', '12', 'Avviso se il Rider con consegna attiva resta fermo (oltre la tolleranza GPS) per più minuti'),
  ('logistics_late_minutes', '15', 'Avviso se la consegna supera l''ETA massima di più minuti'),
  ('logistics_customer_wait_minutes', '10', 'Attesa minima al cliente prima di poter chiudere come "cliente non disponibile"'),
  ('logistics_location_fresh_minutes', '3', 'Posizione considerata valida per il dispatch se più recente di N minuti'),
  ('logistics_max_accuracy_m', '150', 'Precisione GPS oltre la quale la posizione è segnalata come imprecisa'),
  ('logistics_arrival_radius_m', '100', 'Raggio in cui l''app SUGGERISCE l''arrivo (conferma sempre manuale)'),
  ('logistics_nearby_radius_m', '500', 'Distanza per la notifica "Il Rider è vicino"'),
  ('logistics_document_retention_days', '730', 'Giorni di conservazione dei documenti dopo la chiusura del profilo Rider'),
  ('logistics_delivery_data_retention_days', '365', 'Giorni dopo i quali coordinate e indirizzi delle consegne vengono anonimizzati')
on conflict (key) do nothing;

-- ────────────────────────────────────────────────────────────────────
--  2. RISTORANTI: provider di consegna e abilitazione AsiaFood
-- ────────────────────────────────────────────────────────────────────
alter table public.restaurant_order_settings add column if not exists asiafood_delivery_enabled boolean not null default false;
alter table public.restaurant_order_settings drop constraint if exists restaurant_order_settings_delivery_provider_type_check;
alter table public.restaurant_order_settings add constraint restaurant_order_settings_delivery_provider_type_check
  check (delivery_provider_type in ('restaurant', 'asiafood', 'external', 'platform_future', 'external_future'));

-- Solo l'Admin abilita i Rider AsiaFood; il ristorante può sceglierli solo se abilitato
create or replace function public.order_settings_logistics_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    new.asiafood_delivery_enabled := case when tg_op = 'UPDATE' then old.asiafood_delivery_enabled else false end;
  end if;
  if new.delivery_provider_type = 'asiafood' and not new.asiafood_delivery_enabled then
    raise exception 'Le consegne con Rider AsiaFood non sono ancora attive per questo ristorante.' using errcode = '42501';
  end if;
  return new;
end $$;
drop trigger if exists order_settings_logistics_guard on public.restaurant_order_settings;
create trigger order_settings_logistics_guard before insert or update on public.restaurant_order_settings
  for each row execute function public.order_settings_logistics_guard();

alter table public.order_events drop constraint if exists order_events_actor_type_check;
alter table public.order_events add constraint order_events_actor_type_check
  check (actor_type in ('customer', 'restaurant', 'admin', 'system', 'stripe', 'rider'));

-- ────────────────────────────────────────────────────────────────────
--  3. TABELLE
-- ────────────────────────────────────────────────────────────────────
create table public.delivery_service_zones (
  id               uuid primary key default gen_random_uuid(),
  name             text not null check (char_length(name) between 2 and 80),
  city_id          uuid references public.cities(id) on delete set null,
  center_latitude  double precision not null check (center_latitude between -90 and 90),
  center_longitude double precision not null check (center_longitude between -180 and 180),
  radius_km        numeric(6,2) not null check (radius_km > 0 and radius_km <= 60),
  is_active        boolean not null default true,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create table public.rider_profiles (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null unique references public.profiles(id) on delete cascade,
  status              text not null default 'pending' check (status in ('pending', 'approved', 'active', 'inactive', 'suspended', 'rejected')),
  first_name          text not null check (char_length(first_name) between 1 and 60),
  last_name           text not null check (char_length(last_name) between 1 and 60),
  phone               text not null check (char_length(phone) between 6 and 30),
  email               text not null check (char_length(email) between 5 and 160),
  city                text not null check (char_length(city) between 2 and 80),
  city_id             uuid references public.cities(id) on delete set null,
  zone_id             uuid references public.delivery_service_zones(id) on delete set null,
  vehicle_type        text not null check (vehicle_type in ('bike', 'e-bike', 'scooter', 'motorcycle', 'car', 'other')),
  vehicle_details     text check (char_length(vehicle_details) <= 200),
  profile_photo_url   text,
  terms_accepted_at   timestamptz not null,
  location_consent_at timestamptz,
  approved_at         timestamptz,
  approved_by         uuid,
  suspended_at        timestamptz,
  suspension_reason   text,
  rejected_reason     text,
  admin_notes         text,
  rating_internal     numeric(3,2),
  total_deliveries    int not null default 0,
  is_demo             boolean not null default false,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index rider_profiles_status_idx on public.rider_profiles(status);

create table public.rider_documents (
  id            uuid primary key default gen_random_uuid(),
  rider_id      uuid not null references public.rider_profiles(id) on delete cascade,
  document_type text not null check (document_type in ('identity', 'driving_license', 'vehicle_registration', 'vehicle_insurance', 'tax', 'other')),
  storage_path  text not null check (char_length(storage_path) between 5 and 300),
  status        text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'expired')),
  expires_at    date,
  review_note   text,
  uploaded_at   timestamptz not null default now(),
  reviewed_at   timestamptz,
  reviewed_by   uuid
);
create index rider_documents_rider_idx on public.rider_documents(rider_id);

create table public.rider_availability (
  rider_id                  uuid primary key references public.rider_profiles(id) on delete cascade,
  is_online                 boolean not null default false,
  online_since              timestamptz,
  offline_since             timestamptz,
  accepting_orders          boolean not null default true,
  current_capacity          int not null default 0 check (current_capacity >= 0),
  max_concurrent_deliveries int not null default 1 check (max_concurrent_deliveries between 1 and 5),
  -- Ultima posizione valida (solo mentre online): usata per il dispatch, mai pubblica
  last_latitude             double precision,
  last_longitude            double precision,
  last_accuracy             numeric,
  last_location_at          timestamptz,
  last_moved_at             timestamptz,
  last_offer_at             timestamptz,
  updated_at                timestamptz not null default now()
);
create index rider_availability_online_idx on public.rider_availability(is_online) where is_online;
create index rider_availability_geo_idx on public.rider_availability(last_latitude, last_longitude) where is_online;

create table public.rider_locations (
  id              bigint generated always as identity primary key,
  rider_id        uuid not null references public.rider_profiles(id) on delete cascade,
  latitude        double precision not null check (latitude between -90 and 90),
  longitude       double precision not null check (longitude between -180 and 180),
  accuracy        numeric,
  heading         numeric,
  speed           numeric,
  delivery_job_id uuid,
  flags           text[] not null default '{}',
  recorded_at     timestamptz not null,
  received_at     timestamptz not null default now()
);
create index rider_locations_rider_idx on public.rider_locations(rider_id, recorded_at desc);
create index rider_locations_received_idx on public.rider_locations(received_at);

create table public.delivery_jobs (
  id                          uuid primary key default gen_random_uuid(),
  order_id                    uuid not null unique references public.orders(id) on delete cascade,
  restaurant_id               uuid not null references public.restaurants(id) on delete cascade,
  rider_id                    uuid references public.rider_profiles(id) on delete set null,
  status                      text not null default 'waiting_assignment' check (status in ('waiting_assignment', 'offered', 'assigned', 'rider_to_restaurant',
                                'arrived_restaurant', 'picked_up', 'rider_to_customer', 'arrived_customer', 'delivered', 'failed', 'cancelled')),
  pickup_latitude             double precision,
  pickup_longitude            double precision,
  delivery_latitude           double precision,
  delivery_longitude          double precision,
  pickup_address_snapshot     jsonb,
  delivery_address_snapshot   jsonb,
  estimated_distance_km       numeric(7,2),
  estimated_duration_minutes  int,
  -- Codici (mai leggibili direttamente: solo tramite funzioni per chi ne ha diritto)
  pickup_code                 text,
  delivery_code               text,
  delivery_code_required      boolean not null default false,
  proof_type                  text not null default 'confirmation' check (proof_type in ('confirmation', 'otp', 'photo')),
  proof_photo_path            text,
  proof_note                  text,
  code_failures               int not null default 0,
  -- Dispatch
  dispatch_after              timestamptz not null default now(),
  dispatch_attempts           int not null default 0,
  last_dispatch_at            timestamptz,
  search_radius_km            numeric(5,2),
  reassignment_count          int not null default 0,
  batch_id                    uuid,          -- predisposto per consegne multiple (non usato nell'MVP)
  flags                       text[] not null default '{}',
  -- Tempi
  restaurant_ready_at         timestamptz,
  offered_at                  timestamptz,
  offer_expires_at            timestamptz,
  accepted_at                 timestamptz,
  rider_departed_at           timestamptz,
  arrived_at_restaurant_at    timestamptz,
  picked_up_at                timestamptz,
  out_for_delivery_at         timestamptz,
  arrived_at_customer_at      timestamptz,
  customer_wait_started_at    timestamptz,
  delivered_at                timestamptz,
  failed_at                   timestamptz,
  failure_reason              text,
  cancelled_at                timestamptz,
  cancel_reason               text,
  -- ETA (stima; "routing" se calcolata da un provider di percorsi)
  eta_pickup_at               timestamptz,
  eta_delivery_min_at         timestamptz,
  eta_delivery_max_at         timestamptz,
  eta_source                  text not null default 'estimate' check (eta_source in ('estimate', 'routing')),
  eta_updated_at              timestamptz,
  eta_ref_latitude            double precision,
  eta_ref_longitude           double precision,
  last_rider_update_at        timestamptz,
  created_at                  timestamptz not null default now(),
  updated_at                  timestamptz not null default now()
);
create index delivery_jobs_status_idx on public.delivery_jobs(status);
create index delivery_jobs_rider_idx on public.delivery_jobs(rider_id) where rider_id is not null;
create index delivery_jobs_restaurant_idx on public.delivery_jobs(restaurant_id, created_at desc);
create index delivery_jobs_dispatch_idx on public.delivery_jobs(dispatch_after) where status = 'waiting_assignment';

create table public.delivery_assignments (
  id                    uuid primary key default gen_random_uuid(),
  delivery_job_id       uuid not null references public.delivery_jobs(id) on delete cascade,
  rider_id              uuid not null references public.rider_profiles(id) on delete cascade,
  status                text not null default 'offered' check (status in ('offered', 'accepted', 'rejected', 'expired', 'cancelled')),
  score                 numeric,
  distance_to_pickup_km numeric(7,2),
  estimated_earning     numeric(8,2),
  manual                boolean not null default false,
  assigned_by           uuid,
  offered_at            timestamptz not null default now(),
  expires_at            timestamptz not null,
  responded_at          timestamptz,
  rejection_reason      text,
  created_at            timestamptz not null default now()
);
create index delivery_assignments_rider_idx on public.delivery_assignments(rider_id, status);
create index delivery_assignments_job_idx on public.delivery_assignments(delivery_job_id);
-- Un Rider riceve al massimo UNA offerta aperta alla volta
create unique index delivery_assignments_one_open_offer on public.delivery_assignments(rider_id) where status = 'offered';

create table public.rider_compensation_rules (
  id               uuid primary key default gen_random_uuid(),
  city_id          uuid references public.cities(id) on delete cascade,
  base_fee         numeric(8,2) not null check (base_fee >= 0),
  per_km_fee       numeric(8,2) not null check (per_km_fee >= 0),
  minimum_fee      numeric(8,2) not null default 0 check (minimum_fee >= 0),
  max_distance_fee numeric(8,2) check (max_distance_fee >= 0),
  weather_bonus    numeric(8,2) check (weather_bonus >= 0),  -- bonus MANUALE (nessun meteo automatico)
  peak_bonus       numeric(8,2) check (peak_bonus >= 0),     -- bonus MANUALE (nessun surge automatico)
  is_active        boolean not null default true,
  effective_from   timestamptz not null default now(),
  effective_to     timestamptz,
  note             text,
  created_at       timestamptz not null default now()
);

create table public.rider_earnings (
  id              uuid primary key default gen_random_uuid(),
  rider_id        uuid not null references public.rider_profiles(id) on delete cascade,
  delivery_job_id uuid references public.delivery_jobs(id) on delete set null,
  rule_id         uuid references public.rider_compensation_rules(id) on delete set null,
  base_fee        numeric(8,2) not null default 0,
  distance_fee    numeric(8,2) not null default 0,
  bonus           numeric(8,2) not null default 0,
  adjustment      numeric(8,2) not null default 0,
  total           numeric(8,2) not null default 0,
  status          text not null default 'pending' check (status in ('pending', 'approved', 'paid', 'cancelled')),
  note            text,
  created_at      timestamptz not null default now(),
  approved_at     timestamptz,
  paid_at         timestamptz,
  payout_reference text
);
create unique index rider_earnings_job_unique on public.rider_earnings(delivery_job_id) where delivery_job_id is not null and status <> 'cancelled';
create index rider_earnings_rider_idx on public.rider_earnings(rider_id, created_at desc);

-- Predisposizione payout futuri (Stripe Connect / SEPA / altro): nessun trasferimento automatico in questa fase
create table public.rider_payout_accounts (
  id                  uuid primary key default gen_random_uuid(),
  rider_id            uuid not null references public.rider_profiles(id) on delete cascade,
  provider            text not null check (provider in ('stripe_connect', 'sepa', 'other')),
  external_account_id text,
  status              text not null default 'not_configured' check (status in ('not_configured', 'pending', 'active', 'disabled')),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique (rider_id, provider)
);

create table public.delivery_ratings (
  id              uuid primary key default gen_random_uuid(),
  delivery_job_id uuid not null unique references public.delivery_jobs(id) on delete cascade,
  rider_id        uuid references public.rider_profiles(id) on delete set null,
  user_id         uuid not null references public.profiles(id) on delete cascade,
  rating          int not null check (rating between 1 and 5),
  comment         text check (char_length(comment) <= 500),
  created_at      timestamptz not null default now()
);

create table public.delivery_issues (
  id               uuid primary key default gen_random_uuid(),
  delivery_job_id  uuid not null references public.delivery_jobs(id) on delete cascade,
  reported_by_type text not null check (reported_by_type in ('rider', 'customer', 'restaurant', 'admin', 'system')),
  reported_by_id   uuid,
  issue_type       text not null check (issue_type in ('rider_not_found', 'customer_unavailable', 'wrong_address', 'damaged_order', 'restaurant_problem',
                     'order_not_ready', 'vehicle_problem', 'accident', 'cannot_complete', 'order_problem', 'support', 'other')),
  description      text not null default '' check (char_length(description) <= 1000),
  status           text not null default 'open' check (status in ('open', 'in_review', 'resolved', 'rejected')),
  resolution       text,
  created_at       timestamptz not null default now(),
  resolved_at      timestamptz
);
create index delivery_issues_job_idx on public.delivery_issues(delivery_job_id);
create index delivery_issues_open_idx on public.delivery_issues(status) where status in ('open', 'in_review');

-- Predisposizione chat futura (nessuna UI in questa fase)
create table public.delivery_messages (
  id              bigint generated always as identity primary key,
  delivery_job_id uuid not null references public.delivery_jobs(id) on delete cascade,
  sender_type     text not null check (sender_type in ('rider', 'customer', 'restaurant', 'support')),
  sender_id       uuid,
  body            text not null check (char_length(body) between 1 and 1000),
  created_at      timestamptz not null default now()
);

-- Timeline logistica completa (audit): nessuna coordinata precisa del percorso
create table public.delivery_events (
  id              bigint generated always as identity primary key,
  delivery_job_id uuid not null references public.delivery_jobs(id) on delete cascade,
  event_type      text not null check (char_length(event_type) <= 40),
  actor_type      text not null check (actor_type in ('rider', 'restaurant', 'customer', 'admin', 'system')),
  actor_id        uuid,
  metadata        jsonb not null default '{}'::jsonb,
  created_at      timestamptz not null default now()
);
create index delivery_events_job_idx on public.delivery_events(delivery_job_id, created_at);

-- Canale realtime leggero (nessun dato sensibile): cliente, ristorante e Rider rileggono tramite RPC
create table public.delivery_realtime (
  delivery_job_id uuid primary key references public.delivery_jobs(id) on delete cascade,
  order_id        uuid not null,
  restaurant_id   uuid not null,
  user_id         uuid,
  rider_user_id   uuid,
  status          text not null,
  seq             bigint not null default 0,
  updated_at      timestamptz not null default now()
);
create index delivery_realtime_restaurant_idx on public.delivery_realtime(restaurant_id);

create table public.logistics_alerts (
  id              uuid primary key default gen_random_uuid(),
  alert_type      text not null check (alert_type in ('no_rider', 'unassigned_too_long', 'dispatch_exhausted', 'rider_stale', 'rider_stationary',
                    'order_late', 'delivery_failed', 'cancelled_with_rider', 'cancelled_after_pickup', 'location_anomaly', 'customer_unavailable', 'issue')),
  delivery_job_id uuid references public.delivery_jobs(id) on delete cascade,
  rider_id        uuid references public.rider_profiles(id) on delete set null,
  message         text not null,
  status          text not null default 'open' check (status in ('open', 'acknowledged', 'resolved')),
  dedupe_key      text unique,
  created_at      timestamptz not null default now(),
  resolved_at     timestamptz,
  resolved_by     uuid
);
create index logistics_alerts_open_idx on public.logistics_alerts(status, created_at desc);

create trigger rider_profiles_updated_at before update on public.rider_profiles for each row execute function public.set_updated_at();
create trigger delivery_jobs_updated_at before update on public.delivery_jobs for each row execute function public.set_updated_at();
create trigger delivery_service_zones_updated_at before update on public.delivery_service_zones for each row execute function public.set_updated_at();

-- Zona di lancio (configurabile dall'Admin): Taranto e provincia
insert into public.delivery_service_zones (name, city_id, center_latitude, center_longitude, radius_km)
select 'Taranto città', c.id, coalesce(c.latitude, 40.4644), coalesce(c.longitude, 17.2470), 9 from public.cities c where c.slug = 'taranto'
union all
select 'Provincia di Taranto (area ovest)', c.id, coalesce(c.latitude, 40.5889), coalesce(c.longitude, 17.1170), 12 from public.cities c where c.slug = 'massafra';

-- Regola compensi di partenza (modificabile dall'Admin: nessun importo nel codice applicativo)
insert into public.rider_compensation_rules (city_id, base_fee, per_km_fee, minimum_fee, max_distance_fee, note)
values (null, 3.00, 0.60, 4.00, 6.00, 'Regola base iniziale (tutte le città)');

-- ────────────────────────────────────────────────────────────────────
--  4. FUNZIONI DI SUPPORTO
-- ────────────────────────────────────────────────────────────────────
create or replace function public.lg_rider_of(p_user uuid default null)
returns public.rider_profiles language sql stable security definer set search_path = public as $$
  select * from public.rider_profiles where user_id = coalesce(p_user, auth.uid());
$$;

create or replace function public.is_rider(p_user uuid default null)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.rider_profiles r join public.profiles p on p.id = r.user_id
                  where r.user_id = coalesce(p_user, auth.uid()) and r.status in ('approved', 'active') and not p.is_blocked);
$$;

-- Velocità media prudente per mezzo (km/h) e fattore strada 1,35 sulla distanza in linea d'aria
create or replace function public.lg_minutes(p_km numeric, p_vehicle text default 'scooter')
returns int language sql immutable as $$
  select greatest(1, ceil(coalesce(p_km, 0) * 1.35 / (case p_vehicle when 'bike' then 14 when 'e-bike' then 18 when 'scooter' then 24
                                                        when 'motorcycle' then 28 when 'car' then 22 else 15 end) * 60)::int + 2);
$$;

create or replace function public.lg_km(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision)
returns numeric language sql immutable as $$
  select case when lat1 is null or lng1 is null or lat2 is null or lng2 is null then null
              else round(public.geo_distance_km(lat1, lng1, lat2, lng2)::numeric, 3) end;
$$;

create or replace function public.lg_radii()
returns numeric[] language plpgsql stable security definer set search_path = public as $$
declare v numeric[]; v_min numeric := public.billing_setting_num('logistics_initial_search_radius', 3);
        v_max numeric := public.billing_setting_num('logistics_max_search_radius', 10);
begin
  select array_agg(x order by x) into v from (
    select distinct trim(t)::numeric x from unnest(string_to_array(public.billing_setting_text('logistics_search_radii', '3,5,8,10'), ',')) t
     where trim(t) ~ '^[0-9]+(\.[0-9]+)?$') s
   where x >= v_min and x <= v_max;
  if v is null or array_length(v, 1) is null then v := array[v_min, v_max]; end if;
  return v;
end $$;

create or replace function public.lg_log(p_job uuid, p_type text, p_actor_type text, p_actor uuid, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.delivery_events (delivery_job_id, event_type, actor_type, actor_id, metadata)
  values (p_job, left(p_type, 40), p_actor_type, p_actor, coalesce(p_meta, '{}'::jsonb));
end $$;

create or replace function public.lg_touch(p_job uuid)
returns void language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; o public.orders; v_rider uuid;
begin
  select * into j from public.delivery_jobs where id = p_job;
  if not found then return; end if;
  select * into o from public.orders where id = j.order_id;
  select user_id into v_rider from public.rider_profiles where id = j.rider_id;
  insert into public.delivery_realtime (delivery_job_id, order_id, restaurant_id, user_id, rider_user_id, status, seq, updated_at)
  values (j.id, j.order_id, j.restaurant_id, o.user_id, v_rider, j.status, 1, now())
  on conflict (delivery_job_id) do update set status = excluded.status, rider_user_id = excluded.rider_user_id, user_id = excluded.user_id,
    seq = public.delivery_realtime.seq + 1, updated_at = now();
end $$;

create or replace function public.lg_alert(p_type text, p_job uuid, p_rider uuid, p_message text, p_dedupe text default null)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into public.logistics_alerts (alert_type, delivery_job_id, rider_id, message, dedupe_key)
  values (p_type, p_job, p_rider, left(p_message, 300), coalesce(p_dedupe, p_type || ':' || coalesce(p_job::text, '') || ':' || coalesce(p_rider::text, '')))
  on conflict (dedupe_key) do nothing returning id into v_id;
  if v_id is not null then
    perform public.notify_admins('logistics', 'Logistica: ' || replace(p_type, '_', ' '), left(p_message, 300), '/admin/dispatch');
  end if;
  return v_id is not null;
end $$;

-- Notifica al Rider (in-app + push se attivo). Deduplicata.
create or replace function public.lg_notify_rider(p_rider uuid, p_kind text, p_title text, p_body text, p_link text, p_dedupe text)
returns void language plpgsql security definer set search_path = public as $$
declare v_user uuid;
begin
  select user_id into v_user from public.rider_profiles where id = p_rider;
  if v_user is null then return; end if;
  perform public.notify_user(v_user, 'rider', p_title, p_body, p_link, null, p_dedupe, jsonb_build_object('kind', p_kind), null, null, null);
end $$;

-- Notifica al cliente dell'ordine (riusa le notifiche transazionali della Fase 8)
create or replace function public.lg_notify_customer(p_job uuid, p_kind text, p_title text, p_body text)
returns void language plpgsql security definer set search_path = public as $$
declare o public.orders; j public.delivery_jobs;
begin
  select * into j from public.delivery_jobs where id = p_job;
  select * into o from public.orders where id = j.order_id;
  if o.id is null then return; end if;
  perform public.order_notify_customer(o, p_kind, p_title, p_body, null);
end $$;

-- Compenso stimato/definitivo dalla regola in vigore (città del ristorante, poi regola generale)
create or replace function public.lg_earning_quote(p_job uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare j public.delivery_jobs; r public.restaurants; k public.rider_compensation_rules; v_dist numeric; v_distance_fee numeric; v_total numeric;
begin
  select * into j from public.delivery_jobs where id = p_job;
  select * into r from public.restaurants where id = j.restaurant_id;
  select * into k from public.rider_compensation_rules
   where is_active and effective_from <= now() and (effective_to is null or effective_to > now()) and (city_id = r.city_id or city_id is null)
   order by (city_id is null), effective_from desc limit 1;
  if k.id is null then return jsonb_build_object('available', false); end if;
  v_dist := coalesce(j.estimated_distance_km, 0);
  v_distance_fee := round(k.per_km_fee * v_dist, 2);
  if k.max_distance_fee is not null then v_distance_fee := least(v_distance_fee, k.max_distance_fee); end if;
  v_total := greatest(k.minimum_fee, k.base_fee + v_distance_fee);
  return jsonb_build_object('available', true, 'rule_id', k.id, 'base_fee', k.base_fee, 'distance_fee', round(v_total - k.base_fee, 2),
                            'bonus', 0, 'total', round(v_total, 2), 'distance_km', v_dist);
end $$;

-- ETA (stima prudente, sempre come intervallo). Il backend può sostituirla con un provider di percorsi.
create or replace function public.lg_eta(p_job uuid)
returns void language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; o public.orders; a public.rider_availability; v_vehicle text := 'scooter';
        v_rest_to_cust int; v_to_pickup int; v_start timestamptz; v_eta timestamptz;
begin
  select * into j from public.delivery_jobs where id = p_job;
  if not found or j.status in ('delivered', 'failed', 'cancelled') then return; end if;
  select * into o from public.orders where id = j.order_id;
  if j.rider_id is not null then
    select vehicle_type into v_vehicle from public.rider_profiles where id = j.rider_id;
    select * into a from public.rider_availability where rider_id = j.rider_id;
  end if;
  v_rest_to_cust := public.lg_minutes(j.estimated_distance_km, v_vehicle);
  if j.status in ('waiting_assignment', 'offered') then
    v_eta := greatest(now(), coalesce(o.estimated_ready_at, now())) + make_interval(mins => v_rest_to_cust + 5);
    update public.delivery_jobs set eta_pickup_at = null where id = j.id;
  elsif j.status in ('assigned', 'rider_to_restaurant') then
    v_to_pickup := case when a.last_latitude is not null then public.lg_minutes(public.lg_km(a.last_latitude, a.last_longitude, j.pickup_latitude, j.pickup_longitude), v_vehicle) else 10 end;
    update public.delivery_jobs set eta_pickup_at = now() + make_interval(mins => v_to_pickup) where id = j.id;
    v_start := greatest(now() + make_interval(mins => v_to_pickup), coalesce(o.estimated_ready_at, now()));
    v_eta := v_start + make_interval(mins => v_rest_to_cust + 2);
  elsif j.status = 'arrived_restaurant' then
    v_eta := greatest(now(), coalesce(o.estimated_ready_at, now())) + make_interval(mins => v_rest_to_cust + 2);
  elsif j.status in ('picked_up', 'rider_to_customer') then
    v_eta := now() + make_interval(mins => case when a.last_latitude is not null
      then public.lg_minutes(public.lg_km(a.last_latitude, a.last_longitude, j.delivery_latitude, j.delivery_longitude), v_vehicle) else v_rest_to_cust end);
  else
    v_eta := now();
  end if;
  update public.delivery_jobs set
    eta_delivery_min_at = v_eta - make_interval(mins => greatest(2, round(extract(epoch from (v_eta - now())) / 60 * 0.1)::int)),
    eta_delivery_max_at = v_eta + make_interval(mins => greatest(5, round(extract(epoch from (v_eta - now())) / 60 * 0.25)::int)),
    eta_source = 'estimate', eta_updated_at = now(), eta_ref_latitude = a.last_latitude, eta_ref_longitude = a.last_longitude
   where id = j.id;
end $$;

-- Macchina a stati CENTRALE dei delivery job
create or replace function public.lg_transition_allowed(p_from text, p_to text)
returns boolean language sql immutable as $$
  select (p_from, p_to) in (
    ('waiting_assignment', 'offered'), ('waiting_assignment', 'assigned'), ('waiting_assignment', 'cancelled'), ('waiting_assignment', 'failed'),
    ('offered', 'assigned'), ('offered', 'waiting_assignment'), ('offered', 'cancelled'),
    ('assigned', 'rider_to_restaurant'), ('assigned', 'arrived_restaurant'), ('assigned', 'waiting_assignment'), ('assigned', 'cancelled'),
    ('rider_to_restaurant', 'arrived_restaurant'), ('rider_to_restaurant', 'waiting_assignment'), ('rider_to_restaurant', 'cancelled'),
    ('arrived_restaurant', 'picked_up'), ('arrived_restaurant', 'waiting_assignment'), ('arrived_restaurant', 'cancelled'),
    ('picked_up', 'rider_to_customer'), ('picked_up', 'failed'), ('picked_up', 'cancelled'),
    ('rider_to_customer', 'arrived_customer'), ('rider_to_customer', 'delivered'), ('rider_to_customer', 'failed'), ('rider_to_customer', 'cancelled'),
    ('arrived_customer', 'delivered'), ('arrived_customer', 'failed'), ('arrived_customer', 'rider_to_customer'), ('arrived_customer', 'cancelled'));
$$;

create or replace function public.lg_set_status(p_job uuid, p_to text, p_actor_type text, p_actor uuid, p_meta jsonb default '{}'::jsonb)
returns public.delivery_jobs language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs;
begin
  select * into j from public.delivery_jobs where id = p_job for update;
  if not found then raise exception 'Consegna non trovata.'; end if;
  if not public.lg_transition_allowed(j.status, p_to) then
    raise exception 'Passaggio di stato non consentito (% → %).', j.status, p_to using hint = 'INVALID_TRANSITION';
  end if;
  update public.delivery_jobs set status = p_to,
    rider_departed_at = case when p_to = 'rider_to_restaurant' then now() else rider_departed_at end,
    arrived_at_restaurant_at = case when p_to = 'arrived_restaurant' then now() else arrived_at_restaurant_at end,
    picked_up_at = case when p_to = 'picked_up' then now() else picked_up_at end,
    out_for_delivery_at = case when p_to = 'rider_to_customer' and out_for_delivery_at is null then now() else out_for_delivery_at end,
    arrived_at_customer_at = case when p_to = 'arrived_customer' then now() else arrived_at_customer_at end,
    delivered_at = case when p_to = 'delivered' then now() else delivered_at end,
    failed_at = case when p_to = 'failed' then now() else failed_at end,
    cancelled_at = case when p_to = 'cancelled' then now() else cancelled_at end,
    last_rider_update_at = case when p_actor_type = 'rider' then now() else last_rider_update_at end
   where id = p_job returning * into j;
  perform public.lg_log(p_job, p_to, p_actor_type, p_actor, p_meta);
  perform public.lg_touch(p_job);
  return j;
end $$;

-- Libera la capacità del Rider (fine consegna, rilascio, annullamento)
create or replace function public.lg_release_capacity(p_rider uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_rider is null then return; end if;
  update public.rider_availability set current_capacity = (
      select count(*) from public.delivery_jobs where rider_id = p_rider and status in ('assigned', 'rider_to_restaurant', 'arrived_restaurant', 'picked_up', 'rider_to_customer', 'arrived_customer')),
    updated_at = now()
   where rider_id = p_rider;
end $$;

-- Aggiorna l'ordine in modo coerente (le transizioni "in consegna"/"consegnato" degli ordini AsiaFood passano SOLO da qui)
create or replace function public.lg_sync_order(p_job uuid, p_event text, p_actor uuid)
returns void language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; o public.orders; r public.restaurants;
begin
  select * into j from public.delivery_jobs where id = p_job;
  select * into o from public.orders where id = j.order_id for update;
  select * into r from public.restaurants where id = o.restaurant_id;
  perform set_config('asiafood.lg_sync', 'on', true);
  if p_event = 'picked_up' and o.status in ('accepted', 'preparing', 'ready') then
    update public.orders set status = 'out_for_delivery', fulfillment_status = 'out_for_delivery', out_for_delivery_at = now(),
           picked_up_at = now(), ready_at = coalesce(ready_at, now()), preparing_at = coalesce(preparing_at, accepted_at)
     where id = o.id;
    perform public.order_log(o.id, 'out_for_delivery', 'rider', p_actor, jsonb_build_object('delivery_job_id', j.id));
  elsif p_event = 'delivered' and o.status in ('out_for_delivery', 'ready') then
    perform public.order_transition(o.id, 'complete', '{}'::jsonb, 'rider', p_actor);
  end if;
  perform set_config('asiafood.lg_sync', 'off', true);
end $$;

-- Gli ordini con Rider AsiaFood non possono essere messi "in consegna"/"consegnato" da ristorante o cliente
create or replace function public.orders_logistics_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.order_type = 'delivery' and new.delivery_provider_type = 'asiafood' and new.status is distinct from old.status
     and new.status in ('out_for_delivery', 'completed') and coalesce(current_setting('asiafood.lg_sync', true), '') <> 'on'
     and exists (select 1 from public.delivery_jobs where order_id = new.id and status not in ('cancelled', 'failed')) then
    raise exception 'Questa consegna è gestita da un Rider AsiaFood: lo stato «in consegna» e «consegnato» lo aggiorna il Rider.' using hint = 'INVALID_TRANSITION';
  end if;
  return new;
end $$;
create trigger orders_logistics_guard before update of status on public.orders
  for each row execute function public.orders_logistics_guard();

-- ────────────────────────────────────────────────────────────────────
--  5. DISPONIBILITÀ DEL SERVIZIO PER UN INDIRIZZO
-- ────────────────────────────────────────────────────────────────────
-- null = disponibile; altrimenti il messaggio per il cliente
create or replace function public.lg_service_check(p_restaurant uuid, p_lat double precision, p_lng double precision)
returns text language plpgsql stable security definer set search_path = public as $$
declare r public.restaurants; s public.restaurant_order_settings;
begin
  select * into r from public.restaurants where id = p_restaurant;
  select * into s from public.restaurant_order_settings where restaurant_id = p_restaurant;
  if not public.billing_setting_bool('logistics_enabled', true) or not coalesce(s.asiafood_delivery_enabled, false) then
    return 'Le consegne con Rider AsiaFood non sono disponibili in questo momento: scegli il ritiro al locale.';
  end if;
  if r.latitude is null or not exists (select 1 from public.delivery_service_zones z where z.is_active
        and public.geo_distance_km(z.center_latitude, z.center_longitude, r.latitude, r.longitude) <= z.radius_km) then
    return 'Il ristorante non è in una zona servita dai Rider AsiaFood.';
  end if;
  if p_lat is null or not exists (select 1 from public.delivery_service_zones z where z.is_active
        and public.geo_distance_km(z.center_latitude, z.center_longitude, p_lat, p_lng) <= z.radius_km) then
    return 'Questo ristorante non consegna ancora a questo indirizzo.';
  end if;
  return null;
end $$;

-- ────────────────────────────────────────────────────────────────────
--  6. CREAZIONE DEL DELIVERY JOB E DISPATCH
-- ────────────────────────────────────────────────────────────────────
create or replace function public.lg_job_create(p_order uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare o public.orders; r public.restaurants; c public.cities; v_id uuid; v_km numeric; v_after timestamptz;
        v_strategy text := public.billing_setting_text('logistics_dispatch_strategy', 'immediate');
        v_code_req boolean := public.billing_setting_bool('logistics_delivery_code_required', false);
        v_proof text := public.billing_setting_text('logistics_proof_of_delivery_type', 'confirmation');
begin
  select * into o from public.orders where id = p_order;
  if o.order_type <> 'delivery' or o.delivery_provider_type <> 'asiafood' then return null; end if;
  select id into v_id from public.delivery_jobs where order_id = p_order;
  if v_id is not null then return v_id; end if;
  select * into r from public.restaurants where id = o.restaurant_id;
  select * into c from public.cities where id = r.city_id;
  v_km := public.lg_km(r.latitude, r.longitude, (o.delivery_address_snapshot ->> 'latitude')::double precision, (o.delivery_address_snapshot ->> 'longitude')::double precision);
  v_after := case when v_strategy = 'before_ready' and o.estimated_ready_at is not null
                  then greatest(now(), o.estimated_ready_at - make_interval(mins => public.billing_setting_int('logistics_dispatch_before_ready_minutes', 10)))
                  else now() end;
  if v_proof not in ('confirmation', 'otp', 'photo') then v_proof := 'confirmation'; end if;
  insert into public.delivery_jobs (order_id, restaurant_id, pickup_latitude, pickup_longitude, delivery_latitude, delivery_longitude,
    pickup_address_snapshot, delivery_address_snapshot, estimated_distance_km, estimated_duration_minutes, pickup_code, delivery_code,
    delivery_code_required, proof_type, dispatch_after, restaurant_ready_at)
  values (o.id, r.id, r.latitude, r.longitude, (o.delivery_address_snapshot ->> 'latitude')::double precision, (o.delivery_address_snapshot ->> 'longitude')::double precision,
    jsonb_build_object('name', r.name, 'address', r.address, 'city', c.name, 'phone', r.phone),
    jsonb_build_object('address_line_1', o.delivery_address_snapshot ->> 'address_line_1', 'address_line_2', o.delivery_address_snapshot ->> 'address_line_2',
                       'postal_code', o.delivery_address_snapshot ->> 'postal_code', 'city', o.delivery_address_snapshot ->> 'city',
                       'delivery_notes', o.delivery_address_snapshot ->> 'delivery_notes'),
    v_km, public.lg_minutes(v_km, 'scooter'),
    lpad((floor(random() * 10000))::int::text, 4, '0'),
    case when v_code_req or v_proof = 'otp' then lpad((floor(random() * 10000))::int::text, 4, '0') end,
    v_code_req or v_proof = 'otp', v_proof, v_after, case when o.status = 'ready' then now() end)
  returning id into v_id;
  perform public.lg_log(v_id, 'created', 'system', null, jsonb_build_object('order_number', o.order_number, 'distance_km', v_km, 'dispatch_after', v_after));
  perform public.order_log(o.id, 'delivery_job_created', 'system', null, jsonb_build_object('delivery_job_id', v_id));
  if not public.billing_setting_bool('logistics_enabled', true) then
    perform public.lg_alert('no_rider', v_id, null, format('Servizio Rider disattivato: consegna %s da gestire manualmente.', o.order_number));
  end if;
  perform public.lg_eta(v_id);
  perform public.lg_touch(v_id);
  if v_after <= now() then perform public.lg_dispatch(v_id, false); end if;
  return v_id;
end $$;

-- Candidati: filtri trasparenti (stato, online, capacità, zona, distanza). Nessun dato personale nel ranking.
create or replace function public.lg_candidates(p_job uuid, p_radius numeric)
returns table (rider_id uuid, distance_km numeric, free_capacity int, same_restaurant boolean)
language plpgsql stable security definer set search_path = public as $$
declare j public.delivery_jobs; r public.restaurants; v_dlat double precision; v_dlng double precision;
        v_fresh int := public.billing_setting_int('logistics_location_fresh_minutes', 3);
begin
  select * into j from public.delivery_jobs where id = p_job;
  select * into r from public.restaurants where id = j.restaurant_id;
  if j.pickup_latitude is null then return; end if;
  -- Prefiltro a riquadro (usa l'indice su last_latitude/last_longitude), poi distanza reale
  v_dlat := p_radius / 111.32;
  v_dlng := p_radius / (111.32 * greatest(cos(radians(j.pickup_latitude)), 0.01));
  return query
  select a.rider_id, public.lg_km(a.last_latitude, a.last_longitude, j.pickup_latitude, j.pickup_longitude) as d,
         (a.max_concurrent_deliveries - a.current_capacity) as free,
         exists (select 1 from public.delivery_jobs x where x.rider_id = a.rider_id and x.restaurant_id = j.restaurant_id
                   and x.status in ('assigned', 'rider_to_restaurant', 'arrived_restaurant')) as same
    from public.rider_availability a
    join public.rider_profiles p on p.id = a.rider_id
    join public.profiles u on u.id = p.user_id
   where a.is_online and a.accepting_orders and p.status in ('approved', 'active') and not u.is_blocked
     and a.current_capacity < a.max_concurrent_deliveries
     and a.last_location_at > now() - make_interval(mins => v_fresh)
     and a.last_latitude between j.pickup_latitude - v_dlat and j.pickup_latitude + v_dlat
     and a.last_longitude between j.pickup_longitude - v_dlng and j.pickup_longitude + v_dlng
     and public.geo_distance_km(a.last_latitude, a.last_longitude, j.pickup_latitude, j.pickup_longitude) <= p_radius
     -- Zona compatibile: zona assegnata al Rider, altrimenti stessa città del ristorante
     and (case when p.zone_id is not null then exists (select 1 from public.delivery_service_zones z where z.id = p.zone_id and z.is_active
                 and public.geo_distance_km(z.center_latitude, z.center_longitude, j.pickup_latitude, j.pickup_longitude) <= z.radius_km)
               else p.city_id is null or p.city_id = r.city_id or exists (select 1 from public.delivery_service_zones z where z.is_active and z.city_id = p.city_id
                 and public.geo_distance_km(z.center_latitude, z.center_longitude, j.pickup_latitude, j.pickup_longitude) <= z.radius_km) end)
     -- nessuna offerta aperta per lui e nessun tentativo già fatto su questo job
     and not exists (select 1 from public.delivery_assignments x where x.rider_id = a.rider_id and x.status = 'offered')
     and not exists (select 1 from public.delivery_assignments x where x.rider_id = a.rider_id and x.delivery_job_id = j.id);
end $$;

-- dispatchDeliveryJob(): raggi crescenti, ordinamento per capacità libera, stesso ristorante, distanza.
-- p_manual_retry = true: ricerca richiesta dall'Admin anche oltre il limite di tentativi.
create or replace function public.lg_dispatch(p_job uuid, p_manual_retry boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; o public.orders; r public.restaurants; v_radius numeric; c record; v_asg uuid; v_timeout int;
        v_quote jsonb; v_max int := public.billing_setting_int('logistics_max_dispatch_attempts', 20); v_first boolean;
begin
  select * into j from public.delivery_jobs where id = p_job for update;
  if not found or j.status <> 'waiting_assignment' then return jsonb_build_object('ok', false, 'reason', 'NOT_WAITING'); end if;
  if not p_manual_retry and (not public.billing_setting_bool('logistics_auto_dispatch_enabled', true) or not public.billing_setting_bool('logistics_enabled', true)) then
    return jsonb_build_object('ok', false, 'reason', 'AUTO_DISPATCH_DISABLED');
  end if;
  if not p_manual_retry and 'dispatch_exhausted' = any(j.flags) then return jsonb_build_object('ok', false, 'reason', 'EXHAUSTED'); end if;
  select * into o from public.orders where id = j.order_id;
  select * into r from public.restaurants where id = j.restaurant_id;
  v_timeout := greatest(10, public.billing_setting_int('logistics_offer_timeout_seconds', 30));
  v_first := j.dispatch_attempts = 0;
  update public.delivery_jobs set dispatch_attempts = dispatch_attempts + 1, last_dispatch_at = now() where id = j.id;
  foreach v_radius in array public.lg_radii() loop
    for c in select * from public.lg_candidates(j.id, v_radius) x order by x.free_capacity desc, x.same_restaurant desc, x.distance_km asc limit 1 loop
      -- Lock del Rider: una sola offerta aperta per Rider (indice unico parziale)
      perform 1 from public.rider_availability where rider_id = c.rider_id for update;
      v_quote := public.lg_earning_quote(j.id);
      begin
        insert into public.delivery_assignments (delivery_job_id, rider_id, status, score, distance_to_pickup_km, estimated_earning, expires_at)
        values (j.id, c.rider_id, 'offered', c.distance_km, c.distance_km, nullif(v_quote ->> 'total', '')::numeric, now() + make_interval(secs => v_timeout))
        returning id into v_asg;
      exception when unique_violation then
        continue;
      end;
      update public.delivery_jobs set status = 'offered', offered_at = now(), offer_expires_at = now() + make_interval(secs => v_timeout), search_radius_km = v_radius
       where id = j.id;
      update public.rider_availability set last_offer_at = now() where rider_id = c.rider_id;
      perform public.lg_log(j.id, 'offer_sent', 'system', null, jsonb_build_object('assignment_id', v_asg, 'rider_id', c.rider_id, 'radius_km', v_radius,
                                                                                   'distance_to_pickup_km', c.distance_km));
      perform public.log_event(j.restaurant_id, 'delivery_offer_sent', 'server', jsonb_build_object('radius_km', v_radius));
      perform public.lg_notify_rider(c.rider_id, 'offer', 'Nuova consegna disponibile',
        format('%s · %s km · compenso stimato %s €. Rispondi entro %s secondi.', r.name, coalesce(j.estimated_distance_km::text, '?'),
               coalesce(to_char((v_quote ->> 'total')::numeric, 'FM990.00'), '—'), v_timeout), '/rider', 'offer:' || v_asg);
      perform public.lg_touch(j.id);
      return jsonb_build_object('ok', true, 'assignment_id', v_asg, 'rider_id', c.rider_id, 'radius_km', v_radius);
    end loop;
  end loop;
  -- Nessun Rider disponibile nel raggio massimo: nessuna ricerca infinita
  perform public.lg_log(j.id, 'no_rider_found', 'system', null, jsonb_build_object('attempt', j.dispatch_attempts + 1));
  perform public.log_event(j.restaurant_id, 'delivery_assignment_failed', 'server', jsonb_build_object('attempt', j.dispatch_attempts + 1));
  if v_first then
    perform public.lg_alert('no_rider', j.id, null, format('Nessun Rider disponibile entro %s km per l''ordine %s (%s).',
                                                           public.billing_setting_num('logistics_max_search_radius', 10), o.order_number, r.name));
  end if;
  if j.dispatch_attempts + 1 >= v_max and not ('dispatch_exhausted' = any(j.flags)) then
    update public.delivery_jobs set flags = array_append(flags, 'dispatch_exhausted') where id = j.id;
    perform public.lg_alert('dispatch_exhausted', j.id, null, format('Ordine %s: ricerca automatica terminata dopo %s tentativi, serve assegnazione manuale.', o.order_number, v_max));
  end if;
  return jsonb_build_object('ok', false, 'reason', 'NO_RIDER');
end $$;

-- Offerte scadute → expired, ricerca del successivo
create or replace function public.lg_expire_offers()
returns int language plpgsql security definer set search_path = public as $$
declare x record; n int := 0;
begin
  for x in select a.id, a.delivery_job_id, a.rider_id from public.delivery_assignments a
            where a.status = 'offered' and a.expires_at < now() for update skip locked loop
    update public.delivery_assignments set status = 'expired', responded_at = now() where id = x.id;
    perform public.lg_log(x.delivery_job_id, 'offer_expired', 'system', null, jsonb_build_object('assignment_id', x.id, 'rider_id', x.rider_id));
    if exists (select 1 from public.delivery_jobs where id = x.delivery_job_id and status = 'offered') then
      perform public.lg_set_status(x.delivery_job_id, 'waiting_assignment', 'system', null, jsonb_build_object('reason', 'offer_expired'));
      update public.delivery_jobs set offered_at = null, offer_expires_at = null where id = x.delivery_job_id;
      perform public.lg_dispatch(x.delivery_job_id, false);
    end if;
    n := n + 1;
  end loop;
  return n;
end $$;

-- Trigger sugli ordini: creazione del job all'accettazione, segnale "pronto", annullamenti
create or replace function public.orders_logistics_sync()
returns trigger language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; v_rider uuid;
begin
  if new.order_type <> 'delivery' or new.delivery_provider_type <> 'asiafood' or new.status is not distinct from old.status then return null; end if;
  if new.status = 'accepted' then
    perform public.lg_job_create(new.id);
    return null;
  end if;
  select * into j from public.delivery_jobs where order_id = new.id;
  if j.id is null then return null; end if;
  if new.status = 'ready' then
    update public.delivery_jobs set restaurant_ready_at = now(),
           dispatch_after = case when status = 'waiting_assignment' then least(dispatch_after, now()) else dispatch_after end
     where id = j.id;
    perform public.lg_log(j.id, 'restaurant_ready', 'restaurant', null, '{}'::jsonb);
    if j.rider_id is not null and j.status in ('assigned', 'rider_to_restaurant', 'arrived_restaurant') then
      perform public.lg_notify_rider(j.rider_id, 'ready', 'Ordine pronto', format('L''ordine %s è pronto per il ritiro.', new.order_number),
                                     '/rider/delivery/' || j.id, 'ready:' || j.id);
    elsif j.status = 'waiting_assignment' then
      perform public.lg_dispatch(j.id, false);
    end if;
    perform public.lg_touch(j.id);
  elsif new.status in ('cancelled', 'rejected', 'refunded') and j.status not in ('delivered', 'failed', 'cancelled') then
    v_rider := j.rider_id;
    update public.delivery_assignments set status = 'cancelled', responded_at = now() where delivery_job_id = j.id and status = 'offered';
    perform public.lg_set_status(j.id, 'cancelled', 'system', null, jsonb_build_object('reason', 'order_' || new.status, 'stage', j.status));
    update public.delivery_jobs set cancel_reason = 'Ordine ' || new.status || coalesce(': ' || coalesce(new.cancel_reason, new.reject_reason), '') where id = j.id;
    if v_rider is not null then
      perform public.lg_release_capacity(v_rider);
      perform public.lg_notify_rider(v_rider, 'cancelled', 'Consegna annullata', format('L''ordine %s è stato annullato.%s', new.order_number,
        case when j.status in ('picked_up', 'rider_to_customer', 'arrived_customer') then ' Contatta il supporto per la restituzione.' else ' Non devi ritirarlo.' end),
        '/rider', 'cancel:' || j.id);
      -- Conseguenze economiche: registrate e lasciate alla decisione dell'Admin (nessun compenso/rimborso improvvisato)
      perform public.lg_alert(case when j.status in ('picked_up', 'rider_to_customer', 'arrived_customer') then 'cancelled_after_pickup' else 'cancelled_with_rider' end,
        j.id, v_rider, format('Ordine %s annullato con Rider già in %s: valuta l''eventuale compenso.', new.order_number, j.status));
    end if;
  end if;
  return null;
end $$;
create trigger orders_logistics_sync after update of status on public.orders
  for each row execute function public.orders_logistics_sync();

-- ────────────────────────────────────────────────────────────────────
--  7. RIDER: candidatura, documenti, online/offline, posizione
-- ────────────────────────────────────────────────────────────────────
create or replace function public.rider_apply(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); r public.rider_profiles; v_city uuid; v_email text;
begin
  if v_uid is null then raise exception 'Accedi per candidarti come Rider.' using errcode = '42501'; end if;
  select * into r from public.rider_profiles where user_id = v_uid;
  if r.id is not null and r.status not in ('rejected') then
    raise exception 'Hai già inviato una candidatura.' using hint = 'ALREADY_APPLIED';
  end if;
  if coalesce((p ->> 'terms_accepted')::boolean, false) is not true then raise exception 'Devi accettare i termini del servizio Rider.'; end if;
  if coalesce(p ->> 'vehicle_type', '') not in ('bike', 'e-bike', 'scooter', 'motorcycle', 'car', 'other') then raise exception 'Scegli il veicolo.'; end if;
  if char_length(trim(coalesce(p ->> 'first_name', ''))) < 1 or char_length(trim(coalesce(p ->> 'last_name', ''))) < 1 then raise exception 'Inserisci nome e cognome.'; end if;
  if coalesce(p ->> 'phone', '') !~ '^\+?[0-9 ]{6,20}$' then raise exception 'Numero di telefono non valido.'; end if;
  select email into v_email from public.profiles where id = v_uid;
  v_email := coalesce(nullif(trim(p ->> 'email'), ''), v_email);
  if v_email is null or v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Email non valida.'; end if;
  select id into v_city from public.cities where slug = p ->> 'city_slug';
  if v_city is null and char_length(trim(coalesce(p ->> 'city', ''))) < 2 then raise exception 'Indica la zona operativa.'; end if;
  insert into public.rider_profiles (user_id, status, first_name, last_name, phone, email, city, city_id, zone_id, vehicle_type, vehicle_details, terms_accepted_at)
  values (v_uid, 'pending', left(trim(p ->> 'first_name'), 60), left(trim(p ->> 'last_name'), 60), left(trim(p ->> 'phone'), 30), left(v_email, 160),
          coalesce((select name from public.cities where id = v_city), left(trim(p ->> 'city'), 80)), v_city,
          case when coalesce(p ->> 'zone_id', '') ~* '^[0-9a-f-]{36}$' then (select id from public.delivery_service_zones where id = (p ->> 'zone_id')::uuid and is_active) end,
          p ->> 'vehicle_type', nullif(left(trim(coalesce(p ->> 'vehicle_details', '')), 200), ''), now())
  on conflict (user_id) do update set status = 'pending', first_name = excluded.first_name, last_name = excluded.last_name, phone = excluded.phone,
    email = excluded.email, city = excluded.city, city_id = excluded.city_id, zone_id = excluded.zone_id, vehicle_type = excluded.vehicle_type,
    vehicle_details = excluded.vehicle_details, terms_accepted_at = now(), rejected_reason = null
  returning * into r;
  insert into public.rider_availability (rider_id, max_concurrent_deliveries)
  values (r.id, greatest(1, least(5, public.billing_setting_int('logistics_default_rider_capacity', 1)))) on conflict (rider_id) do nothing;
  perform public.notify_admins('rider_application', 'Nuova candidatura Rider', r.first_name || ' ' || left(r.last_name, 1) || '. · ' || r.city, '/admin/riders?status=pending');
  return jsonb_build_object('ok', true, 'rider_id', r.id, 'status', r.status);
end $$;

-- Registra un documento già caricato nello storage privato (path: <user_id>/...)
create or replace function public.rider_document_add(p_type text, p_path text, p_expires date default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; v_id uuid;
begin
  r := public.lg_rider_of();
  if r.id is null then raise exception 'Candidatura Rider non trovata.' using errcode = '42501'; end if;
  if split_part(coalesce(p_path, ''), '/', 1) <> auth.uid()::text or p_path like '%..%' then raise exception 'Percorso del documento non valido.' using errcode = '42501'; end if;
  if (select count(*) from public.rider_documents where rider_id = r.id) >= 20 then raise exception 'Troppi documenti caricati.'; end if;
  insert into public.rider_documents (rider_id, document_type, storage_path, expires_at) values (r.id, p_type, p_path, p_expires) returning id into v_id;
  return v_id;
end $$;

create or replace function public.rider_set_online(p_online boolean, p_accepting boolean default true, p_location_consent boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; a public.rider_availability;
begin
  r := public.lg_rider_of();
  if r.id is null then raise exception 'Non sei un Rider.' using errcode = '42501'; end if;
  if p_online then
    if r.status not in ('approved', 'active') then raise exception 'Il tuo profilo Rider non è attivo.' using errcode = '42501'; end if;
    if exists (select 1 from public.profiles where id = r.user_id and is_blocked) then raise exception 'Account bloccato.' using errcode = '42501'; end if;
    if r.location_consent_at is null and not p_location_consent then
      raise exception 'Per andare online devi autorizzare l''uso della posizione mentre sei online.' using hint = 'LOCATION_CONSENT_REQUIRED';
    end if;
    if r.location_consent_at is null then update public.rider_profiles set location_consent_at = now() where id = r.id; end if;
    if r.status = 'approved' then update public.rider_profiles set status = 'active' where id = r.id; end if;
    insert into public.rider_availability (rider_id, is_online, online_since, accepting_orders, max_concurrent_deliveries)
    values (r.id, true, now(), coalesce(p_accepting, true), greatest(1, least(5, public.billing_setting_int('logistics_default_rider_capacity', 1))))
    on conflict (rider_id) do update set is_online = true, online_since = case when public.rider_availability.is_online then public.rider_availability.online_since else now() end,
      accepting_orders = coalesce(p_accepting, true), updated_at = now()
    returning * into a;
    perform public.log_event(null, 'rider_online', 'server', '{}'::jsonb);
  else
    if exists (select 1 from public.delivery_jobs where rider_id = r.id and status in ('assigned', 'rider_to_restaurant', 'arrived_restaurant', 'picked_up', 'rider_to_customer', 'arrived_customer')) then
      raise exception 'Hai una consegna in corso: completala o segnala un problema prima di andare offline.' using hint = 'ACTIVE_DELIVERY';
    end if;
    -- Offline = tracking disattivato: si cancella anche l'ultima posizione nota
    update public.rider_availability set is_online = false, offline_since = now(), accepting_orders = false,
           last_latitude = null, last_longitude = null, last_accuracy = null, last_location_at = null, updated_at = now()
     where rider_id = r.id returning * into a;
    perform public.lg_expire_rider_offers(r.id, 'offline');
    perform public.log_event(null, 'rider_offline', 'server', '{}'::jsonb);
  end if;
  return jsonb_build_object('ok', true, 'is_online', a.is_online, 'accepting_orders', a.accepting_orders);
end $$;

-- Offerte aperte di un Rider che va offline / viene sospeso → cancellate e ridistribuite
create or replace function public.lg_expire_rider_offers(p_rider uuid, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare x record;
begin
  for x in select id, delivery_job_id from public.delivery_assignments where rider_id = p_rider and status = 'offered' loop
    update public.delivery_assignments set status = 'cancelled', responded_at = now(), rejection_reason = p_reason where id = x.id;
    if exists (select 1 from public.delivery_jobs where id = x.delivery_job_id and status = 'offered') then
      perform public.lg_set_status(x.delivery_job_id, 'waiting_assignment', 'system', null, jsonb_build_object('reason', p_reason));
      perform public.lg_dispatch(x.delivery_job_id, false);
    end if;
  end loop;
end $$;

-- Posizione: solo online, frequenza limitata, controlli ragionevoli anti-spoofing (flag, mai sospensione automatica)
create or replace function public.rider_location(p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; a public.rider_availability; j public.delivery_jobs; o public.orders;
        v_lat double precision; v_lng double precision; v_acc numeric; v_at timestamptz; v_flags text[] := '{}'; v_moved numeric; v_kmh numeric;
        v_active boolean; v_interval int; v_hint text; v_d numeric; v_min_gap int;
begin
  r := public.lg_rider_of();
  if r.id is null or r.status not in ('approved', 'active') then raise exception 'Non autorizzato.' using errcode = '42501'; end if;
  select * into a from public.rider_availability where rider_id = r.id for update;
  if not coalesce(a.is_online, false) then
    return jsonb_build_object('accepted', false, 'reason', 'OFFLINE', 'tracking', false);
  end if;
  begin
    v_lat := (p ->> 'latitude')::double precision; v_lng := (p ->> 'longitude')::double precision;
    v_acc := nullif(p ->> 'accuracy', '')::numeric;
    v_at := coalesce(nullif(p ->> 'recorded_at', '')::timestamptz, now());
  exception when others then raise exception 'Posizione non valida.';
  end;
  if v_lat is null or v_lng is null or v_lat not between -90 and 90 or v_lng not between -180 and 180 then raise exception 'Posizione non valida.'; end if;
  select * into j from public.delivery_jobs where rider_id = r.id and status in ('assigned', 'rider_to_restaurant', 'arrived_restaurant', 'picked_up', 'rider_to_customer', 'arrived_customer')
   order by accepted_at limit 1;
  v_active := j.id is not null;
  v_interval := case when v_active then public.billing_setting_int('logistics_location_interval_active', 15) else public.billing_setting_int('logistics_location_interval_idle', 60) end;
  -- Timestamp vecchi o nel futuro: scartati
  if v_at < now() - interval '2 minutes' then return jsonb_build_object('accepted', false, 'reason', 'STALE', 'interval_seconds', v_interval, 'tracking', true); end if;
  if v_at > now() + interval '30 seconds' then v_flags := array_append(v_flags, 'future_timestamp'); v_at := now(); end if;
  -- Frequenza: non più di una posizione ogni metà intervallo (min 5 s)
  v_min_gap := greatest(5, v_interval / 2);
  if a.last_location_at is not null and v_at < a.last_location_at + make_interval(secs => v_min_gap) then
    return jsonb_build_object('accepted', false, 'reason', 'TOO_FREQUENT', 'interval_seconds', v_interval, 'tracking', true, 'high_accuracy', v_active);
  end if;
  if v_acc is not null and v_acc > public.billing_setting_int('logistics_max_accuracy_m', 150) then v_flags := array_append(v_flags, 'low_accuracy'); end if;
  if a.last_latitude is not null then
    v_moved := public.lg_km(a.last_latitude, a.last_longitude, v_lat, v_lng);
    v_kmh := v_moved / greatest(extract(epoch from (v_at - a.last_location_at)) / 3600.0, 1.0 / 3600);
    if v_kmh > 150 and v_moved > 1 then v_flags := array_append(v_flags, 'impossible_jump'); end if;
  end if;
  if (p ->> 'speed') ~ '^[0-9.]+$' and (p ->> 'speed')::numeric > 45 then v_flags := array_append(v_flags, 'speed_anomaly'); end if;
  insert into public.rider_locations (rider_id, latitude, longitude, accuracy, heading, speed, delivery_job_id, flags, recorded_at)
  values (r.id, v_lat, v_lng, v_acc, nullif(p ->> 'heading', '')::numeric, nullif(p ->> 'speed', '')::numeric, j.id, v_flags, v_at);
  if 'impossible_jump' = any(v_flags) or 'speed_anomaly' = any(v_flags) then
    -- Posizione anomala: registrata per revisione ma NON usata per dispatch/tracking; mai sospensione automatica
    perform public.lg_alert('location_anomaly', j.id, r.id, format('Posizione anomala del Rider %s %s. (%s): da verificare.', r.first_name, left(r.last_name, 1), array_to_string(v_flags, ', ')),
                            'location_anomaly:' || r.id || ':' || to_char(now(), 'YYYYMMDDHH24'));
    return jsonb_build_object('accepted', false, 'reason', 'ANOMALY', 'interval_seconds', v_interval, 'tracking', true, 'high_accuracy', v_active);
  end if;
  update public.rider_availability set last_latitude = v_lat, last_longitude = v_lng, last_accuracy = v_acc, last_location_at = v_at,
         last_moved_at = case when a.last_latitude is null or coalesce(v_moved, 1) > 0.05 then v_at else last_moved_at end, updated_at = now()
   where rider_id = r.id;
  if v_active then
    update public.delivery_jobs set last_rider_update_at = now() where id = j.id;
    -- ETA ricalcolata solo se lo spostamento è significativo (> 250 m) o l'ultima stima ha più di 2 minuti
    if j.eta_ref_latitude is null or public.lg_km(j.eta_ref_latitude, j.eta_ref_longitude, v_lat, v_lng) > 0.25 or j.eta_updated_at < now() - interval '2 minutes' then
      perform public.lg_eta(j.id);
    end if;
    -- Suggerimenti di arrivo (conferma SEMPRE manuale) e notifica "Rider vicino"
    if j.status in ('assigned', 'rider_to_restaurant') then
      v_d := public.lg_km(v_lat, v_lng, j.pickup_latitude, j.pickup_longitude) * 1000;
      if v_d <= public.billing_setting_int('logistics_arrival_radius_m', 100) then v_hint := 'near_restaurant'; end if;
    elsif j.status in ('picked_up', 'rider_to_customer') then
      v_d := public.lg_km(v_lat, v_lng, j.delivery_latitude, j.delivery_longitude) * 1000;
      if v_d <= public.billing_setting_int('logistics_arrival_radius_m', 100) then v_hint := 'near_customer'; end if;
      if v_d <= public.billing_setting_int('logistics_nearby_radius_m', 500) then
        perform public.lg_notify_customer(j.id, 'rider_nearby', 'Il Rider è vicino', 'Il tuo ordine sta arrivando: tieni il telefono a portata di mano.');
      end if;
    end if;
    perform public.lg_touch(j.id);
  end if;
  return jsonb_build_object('accepted', true, 'flags', v_flags, 'interval_seconds', v_interval, 'high_accuracy', v_active, 'tracking', true, 'hint', v_hint);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  8. RIDER: offerte e consegne
-- ────────────────────────────────────────────────────────────────────
create or replace function public.rider_offer_respond(p_assignment uuid, p_accept boolean, p_reason text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; x public.delivery_assignments; j public.delivery_jobs; a public.rider_availability; o public.orders; rs public.restaurants;
begin
  r := public.lg_rider_of();
  if r.id is null or r.status not in ('approved', 'active') then raise exception 'Non autorizzato.' using errcode = '42501'; end if;
  select * into x from public.delivery_assignments where id = p_assignment for update;
  if not found or x.rider_id <> r.id then raise exception 'Offerta non trovata.' using errcode = '42501'; end if;
  -- Lock del job: la transazione garantisce che un solo Rider ottenga la consegna
  select * into j from public.delivery_jobs where id = x.delivery_job_id for update;
  if x.status <> 'offered' then raise exception 'Questa offerta non è più disponibile.' using hint = 'OFFER_CLOSED'; end if;
  if x.expires_at < now() then
    update public.delivery_assignments set status = 'expired', responded_at = now() where id = x.id;
    raise exception 'L''offerta è scaduta.' using hint = 'OFFER_EXPIRED';
  end if;
  if not p_accept then
    if p_reason is not null and p_reason not in ('too_far', 'end_of_shift', 'vehicle_problem', 'not_available', 'other') then p_reason := 'other'; end if;
    update public.delivery_assignments set status = 'rejected', responded_at = now(), rejection_reason = p_reason where id = x.id;
    perform public.lg_log(j.id, 'offer_rejected', 'rider', auth.uid(), jsonb_build_object('assignment_id', x.id, 'reason', p_reason));
    perform public.log_event(j.restaurant_id, 'delivery_offer_rejected', 'server', jsonb_build_object('reason', p_reason));
    if j.status = 'offered' and j.rider_id is null then
      perform public.lg_set_status(j.id, 'waiting_assignment', 'rider', auth.uid(), jsonb_build_object('reason', 'offer_rejected'));
      update public.delivery_jobs set offered_at = null, offer_expires_at = null where id = j.id;
      perform public.lg_dispatch(j.id, false);
    end if;
    return jsonb_build_object('ok', true, 'status', 'rejected');
  end if;
  if j.rider_id is not null or j.status not in ('offered', 'waiting_assignment') then
    update public.delivery_assignments set status = 'cancelled', responded_at = now(), rejection_reason = 'already_assigned' where id = x.id;
    raise exception 'La consegna è già stata assegnata a un altro Rider.' using hint = 'ALREADY_ASSIGNED';
  end if;
  select * into a from public.rider_availability where rider_id = r.id for update;
  if not a.is_online or a.current_capacity >= a.max_concurrent_deliveries then
    raise exception 'Non puoi accettare altre consegne in questo momento.' using hint = 'NO_CAPACITY';
  end if;
  update public.delivery_assignments set status = 'accepted', responded_at = now() where id = x.id;
  update public.delivery_assignments set status = 'cancelled', responded_at = now(), rejection_reason = 'assigned_to_other'
   where delivery_job_id = j.id and status = 'offered' and id <> x.id;
  update public.delivery_jobs set rider_id = r.id, accepted_at = now(), offer_expires_at = null where id = j.id;
  perform public.lg_set_status(j.id, 'assigned', 'rider', auth.uid(), jsonb_build_object('assignment_id', x.id));
  perform public.lg_release_capacity(r.id);
  perform public.lg_eta(j.id);
  perform public.log_event(j.restaurant_id, 'delivery_offer_accepted', 'server', '{}'::jsonb);
  select * into o from public.orders where id = j.order_id;
  select * into rs from public.restaurants where id = j.restaurant_id;
  perform public.order_log(o.id, 'rider_assigned', 'rider', auth.uid(), jsonb_build_object('delivery_job_id', j.id));
  perform public.lg_notify_customer(j.id, 'rider_assigned', 'Rider assegnato', format('%s %s. porterà il tuo ordine %s.', r.first_name, left(r.last_name, 1), o.order_number));
  perform public.order_notify_restaurant(o, 'rider_assigned', 'Rider assegnato · ' || o.order_number, format('%s %s. sta arrivando a ritirare l''ordine.', r.first_name, left(r.last_name, 1)));
  return jsonb_build_object('ok', true, 'status', 'assigned', 'delivery_job_id', j.id);
end $$;

-- Azioni del Rider sulla propria consegna (stato validato dalla macchina a stati)
create or replace function public.rider_job_action(p_job uuid, p_action text, p jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; j public.delivery_jobs; o public.orders; rs public.restaurants; v_quote jsonb; v_issue uuid; v_wait int; v_proof text;
begin
  r := public.lg_rider_of();
  if r.id is null or r.status not in ('approved', 'active') then raise exception 'Non autorizzato.' using errcode = '42501'; end if;
  select * into j from public.delivery_jobs where id = p_job for update;
  if not found or j.rider_id is distinct from r.id then raise exception 'Consegna non trovata.' using errcode = '42501'; end if;
  select * into o from public.orders where id = j.order_id;
  select * into rs from public.restaurants where id = j.restaurant_id;
  p := coalesce(p, '{}'::jsonb);

  if p_action = 'depart' then
    perform public.lg_set_status(j.id, 'rider_to_restaurant', 'rider', auth.uid());
  elsif p_action = 'arrived_restaurant' then
    perform public.lg_set_status(j.id, 'arrived_restaurant', 'rider', auth.uid());
    perform public.log_event(j.restaurant_id, 'rider_arrived_restaurant', 'server', '{}'::jsonb);
    perform public.order_notify_restaurant(o, 'rider_arrived', 'Rider arrivato · ' || o.order_number, format('%s %s. è al locale per il ritiro.', r.first_name, left(r.last_name, 1)));
    perform public.lg_notify_customer(j.id, 'rider_arriving_restaurant', 'Il Rider è al ristorante', format('Il Rider sta ritirando il tuo ordine da %s.', rs.name));
  elsif p_action = 'not_ready' then
    if j.status <> 'arrived_restaurant' then raise exception 'Segnala l''attesa quando sei al ristorante.' using hint = 'INVALID_TRANSITION'; end if;
    perform public.lg_log(j.id, 'order_not_ready', 'rider', auth.uid(), '{}'::jsonb);
    perform public.order_notify_restaurant(o, 'rider_waiting:' || floor(extract(epoch from now()) / 300), 'Il Rider sta aspettando · ' || o.order_number, 'Il Rider è al locale e l''ordine non è ancora pronto.');
  elsif p_action = 'picked_up' then
    if j.status <> 'arrived_restaurant' then raise exception 'Conferma prima di essere arrivato al ristorante.' using hint = 'INVALID_TRANSITION'; end if;
    if public.billing_setting_bool('logistics_pickup_code_required', true) and coalesce(p ->> 'pickup_code', '') <> j.pickup_code then
      update public.delivery_jobs set code_failures = code_failures + 1 where id = j.id;
      perform public.lg_log(j.id, 'pickup_code_wrong', 'rider', auth.uid(), '{}'::jsonb);
      raise exception 'Codice di ritiro non corretto: chiedilo al ristorante (è sullo scontrino dell''ordine).' using hint = 'CODE_INVALID';
    end if;
    perform public.lg_set_status(j.id, 'picked_up', 'rider', auth.uid(), jsonb_build_object('waiting_minutes',
      round(extract(epoch from (now() - coalesce(j.arrived_at_restaurant_at, now()))) / 60.0, 1)));
    perform public.lg_sync_order(j.id, 'picked_up', auth.uid());
    perform public.lg_set_status(j.id, 'rider_to_customer', 'rider', auth.uid());
    perform public.lg_eta(j.id);
    perform public.log_event(j.restaurant_id, 'order_picked_up', 'server', '{}'::jsonb);
    perform public.lg_notify_customer(j.id, 'order_picked_up', 'Ordine ritirato', format('Il Rider ha ritirato il tuo ordine %s ed è in viaggio verso di te.', o.order_number));
  elsif p_action = 'arrived_customer' then
    perform public.lg_set_status(j.id, 'arrived_customer', 'rider', auth.uid());
    perform public.log_event(j.restaurant_id, 'rider_arrived_customer', 'server', '{}'::jsonb);
  elsif p_action = 'customer_unavailable' then
    if j.status not in ('arrived_customer', 'rider_to_customer') then raise exception 'Azione disponibile solo all''indirizzo di consegna.' using hint = 'INVALID_TRANSITION'; end if;
    if j.status = 'rider_to_customer' then perform public.lg_set_status(j.id, 'arrived_customer', 'rider', auth.uid()); end if;
    update public.delivery_jobs set customer_wait_started_at = coalesce(customer_wait_started_at, now()) where id = j.id;
    perform public.lg_log(j.id, 'customer_unavailable', 'rider', auth.uid(), jsonb_build_object('step', left(coalesce(p ->> 'step', 'waiting'), 20)));
    perform public.lg_notify_customer(j.id, 'rider_waiting', 'Il Rider è arrivato', 'Il Rider è al tuo indirizzo e non riesce a trovarti: rispondi al telefono.');
    if p ->> 'step' = 'support' then
      perform public.lg_alert('customer_unavailable', j.id, r.id, format('Ordine %s: cliente non disponibile, il Rider chiede supporto.', o.order_number));
    end if;
  elsif p_action = 'delivered' then
    if j.status not in ('arrived_customer', 'rider_to_customer') then raise exception 'Non puoi ancora completare questa consegna.' using hint = 'INVALID_TRANSITION'; end if;
    v_proof := j.proof_type;
    if j.delivery_code_required then
      if j.code_failures >= 5 then raise exception 'Troppi codici errati: contatta il supporto.' using hint = 'CODE_LOCKED'; end if;
      if coalesce(p ->> 'delivery_code', '') <> j.delivery_code then
        update public.delivery_jobs set code_failures = code_failures + 1 where id = j.id;
        perform public.lg_log(j.id, 'delivery_code_wrong', 'rider', auth.uid(), '{}'::jsonb);
        raise exception 'Codice di consegna non corretto: chiedilo al cliente.' using hint = 'CODE_INVALID';
      end if;
    end if;
    if v_proof = 'photo' then
      if coalesce(p ->> 'photo_path', '') = '' or split_part(p ->> 'photo_path', '/', 1) <> auth.uid()::text then
        raise exception 'Scatta una foto del pacco consegnato (non del cliente).' using hint = 'PROOF_REQUIRED';
      end if;
      update public.delivery_jobs set proof_photo_path = p ->> 'photo_path' where id = j.id;
    end if;
    update public.delivery_jobs set proof_note = nullif(left(trim(coalesce(p ->> 'note', '')), 200), '') where id = j.id;
    perform public.lg_set_status(j.id, 'delivered', 'rider', auth.uid(), jsonb_build_object('proof', v_proof, 'code_verified', j.delivery_code_required));
    perform public.lg_sync_order(j.id, 'delivered', auth.uid());
    v_quote := public.lg_earning_quote(j.id);
    if coalesce((v_quote ->> 'available')::boolean, false) then
      insert into public.rider_earnings (rider_id, delivery_job_id, rule_id, base_fee, distance_fee, bonus, total)
      values (r.id, j.id, (v_quote ->> 'rule_id')::uuid, (v_quote ->> 'base_fee')::numeric, (v_quote ->> 'distance_fee')::numeric, 0, (v_quote ->> 'total')::numeric)
      on conflict do nothing;
    end if;
    update public.rider_profiles set total_deliveries = total_deliveries + 1 where id = r.id;
    perform public.lg_release_capacity(r.id);
    perform public.log_event(j.restaurant_id, 'delivery_completed', 'server', jsonb_build_object('minutes', round(extract(epoch from (now() - j.accepted_at)) / 60.0)));
    perform public.order_log(o.id, 'delivered', 'rider', auth.uid(), jsonb_build_object('delivery_job_id', j.id, 'proof', v_proof));
    update public.logistics_alerts set status = 'resolved', resolved_at = now() where delivery_job_id = j.id and status = 'open' and alert_type in ('rider_stale', 'rider_stationary', 'order_late');
  elsif p_action = 'fail' then
    if j.status not in ('arrived_customer', 'rider_to_customer', 'picked_up') then raise exception 'Azione non disponibile.' using hint = 'INVALID_TRANSITION'; end if;
    v_wait := public.billing_setting_int('logistics_customer_wait_minutes', 10);
    if coalesce(p ->> 'reason', '') = 'customer_unavailable' and (j.customer_wait_started_at is null or j.customer_wait_started_at > now() - make_interval(mins => v_wait)) then
      raise exception 'Attendi almeno % minuti e prova a chiamare il cliente prima di chiudere la consegna.', v_wait using hint = 'WAIT_REQUIRED';
    end if;
    perform public.lg_set_status(j.id, 'failed', 'rider', auth.uid(), jsonb_build_object('reason', left(coalesce(p ->> 'reason', 'other'), 40)));
    update public.delivery_jobs set failure_reason = left(coalesce(p ->> 'reason', 'other'), 60) where id = j.id;
    insert into public.delivery_issues (delivery_job_id, reported_by_type, reported_by_id, issue_type, description)
    values (j.id, 'rider', auth.uid(), case when p ->> 'reason' in ('customer_unavailable', 'wrong_address', 'damaged_order', 'accident', 'vehicle_problem') then p ->> 'reason' else 'cannot_complete' end,
            left(coalesce(p ->> 'description', ''), 1000));
    perform public.lg_release_capacity(r.id);
    perform public.log_event(j.restaurant_id, 'delivery_failed', 'server', jsonb_build_object('reason', p ->> 'reason'));
    perform public.order_log(o.id, 'delivery_failed', 'rider', auth.uid(), jsonb_build_object('reason', p ->> 'reason'));
    perform public.lg_alert('delivery_failed', j.id, r.id, format('Consegna %s non completata (%s): serve una decisione del supporto su ordine e rimborso.', o.order_number, coalesce(p ->> 'reason', 'altro')));
  elsif p_action = 'cancel' then
    -- Annullamento del Rider PRIMA del ritiro: torna in assegnazione. Dopo il ritiro serve il supporto.
    if j.status not in ('assigned', 'rider_to_restaurant', 'arrived_restaurant') then
      raise exception 'Hai già ritirato l''ordine: usa «Ho un problema» per contattare il supporto.' using hint = 'SUPPORT_REQUIRED';
    end if;
    update public.delivery_assignments set status = 'cancelled', responded_at = now(), rejection_reason = left(coalesce(p ->> 'reason', 'rider_cancelled'), 60)
     where delivery_job_id = j.id and rider_id = r.id and status = 'accepted';
    perform public.lg_set_status(j.id, 'waiting_assignment', 'rider', auth.uid(), jsonb_build_object('reason', 'rider_cancelled', 'detail', p ->> 'reason'));
    update public.delivery_jobs set rider_id = null, accepted_at = null, rider_departed_at = null, arrived_at_restaurant_at = null,
           reassignment_count = reassignment_count + 1, dispatch_after = now() where id = j.id;
    perform public.lg_release_capacity(r.id);
    insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
    values (null, 'delivery_reassignment', 'delivery_job', j.id::text, jsonb_build_object('by', 'rider', 'rider_id', r.id, 'reason', p ->> 'reason'));
    perform public.order_notify_restaurant(o, 'rider_cancelled:' || j.reassignment_count, 'Nuovo Rider in ricerca · ' || o.order_number, 'Il Rider precedente non può più ritirare l''ordine: ne stiamo cercando un altro.');
    perform public.lg_dispatch(j.id, false);
    return jsonb_build_object('id', j.id, 'status', 'released');
  elsif p_action = 'problem' then
    insert into public.delivery_issues (delivery_job_id, reported_by_type, reported_by_id, issue_type, description)
    values (j.id, 'rider', auth.uid(), case when p ->> 'type' in ('order_problem', 'vehicle_problem', 'accident', 'cannot_complete', 'support', 'wrong_address', 'damaged_order', 'restaurant_problem', 'order_not_ready')
                                          then p ->> 'type' else 'other' end, left(coalesce(p ->> 'description', ''), 1000))
    returning id into v_issue;
    perform public.lg_log(j.id, 'problem_reported', 'rider', auth.uid(), jsonb_build_object('type', p ->> 'type'));
    perform public.lg_alert('issue', j.id, r.id, format('Il Rider segnala un problema (%s) sull''ordine %s.', coalesce(p ->> 'type', 'altro'), o.order_number), 'issue:' || v_issue);
  else
    raise exception 'Azione non valida.';
  end if;
  return public.rider_job(j.id);
end $$;

-- Vista della consegna per il Rider assegnato (indirizzo completo SOLO dopo l'accettazione)
create or replace function public.rider_job(p_job uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; j public.delivery_jobs; o public.orders; e public.rider_earnings;
begin
  r := public.lg_rider_of();
  select * into j from public.delivery_jobs where id = p_job;
  if r.id is null or j.id is null or j.rider_id is distinct from r.id then raise exception 'Consegna non trovata.' using errcode = '42501'; end if;
  select * into o from public.orders where id = j.order_id;
  select * into e from public.rider_earnings where delivery_job_id = j.id and status <> 'cancelled';
  return jsonb_build_object(
    'id', j.id, 'status', j.status, 'order_number', o.order_number, 'order_status', o.status,
    'restaurant', j.pickup_address_snapshot || jsonb_build_object('latitude', j.pickup_latitude, 'longitude', j.pickup_longitude),
    'restaurant_notes', o.restaurant_notes, 'ready', o.status = 'ready' or j.restaurant_ready_at is not null, 'estimated_ready_at', o.estimated_ready_at,
    'items', (select coalesce(jsonb_agg(jsonb_build_object('name', i.menu_item_name_snapshot, 'quantity', i.quantity, 'variant', i.variant_name_snapshot) order by i.created_at), '[]'::jsonb)
                from public.order_items i where i.order_id = o.id),
    'customer', case when j.status in ('delivered', 'failed', 'cancelled') then null else jsonb_build_object(
        'name', split_part(o.customer_name, ' ', 1), 'phone', o.customer_phone,
        'address', j.delivery_address_snapshot, 'latitude', j.delivery_latitude, 'longitude', j.delivery_longitude, 'notes', o.customer_notes) end,
    'pickup_code_required', public.billing_setting_bool('logistics_pickup_code_required', true),
    'delivery_code_required', j.delivery_code_required, 'proof_type', j.proof_type,
    'distance_km', j.estimated_distance_km, 'eta_pickup_at', j.eta_pickup_at, 'eta_delivery_min_at', j.eta_delivery_min_at, 'eta_delivery_max_at', j.eta_delivery_max_at,
    'accepted_at', j.accepted_at, 'arrived_at_restaurant_at', j.arrived_at_restaurant_at, 'picked_up_at', j.picked_up_at,
    'arrived_at_customer_at', j.arrived_at_customer_at, 'customer_wait_started_at', j.customer_wait_started_at, 'delivered_at', j.delivered_at,
    'customer_wait_minutes', public.billing_setting_int('logistics_customer_wait_minutes', 10),
    'earning', case when e.id is not null then jsonb_build_object('total', e.total, 'status', e.status, 'final', true)
                    else public.lg_earning_quote(j.id) || jsonb_build_object('final', false) end);
end $$;

-- Home del Rider: profilo, stato, offerta in corso (dati ridotti), consegne attive, statistiche personali
create or replace function public.rider_home()
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; a public.rider_availability; x public.delivery_assignments; j public.delivery_jobs; o public.orders;
        v_offer jsonb; v_done int; v_failed int; v_cancel int;
begin
  r := public.lg_rider_of();
  if r.id is null then return jsonb_build_object('rider', null); end if;
  perform public.lg_expire_offers();
  select * into a from public.rider_availability where rider_id = r.id;
  select * into x from public.delivery_assignments where rider_id = r.id and status = 'offered' and expires_at > now() order by offered_at desc limit 1;
  if x.id is not null then
    select * into j from public.delivery_jobs where id = x.delivery_job_id;
    select * into o from public.orders where id = j.order_id;
    -- Offerta: niente indirizzo completo del cliente prima dell'accettazione (solo CAP e comune)
    v_offer := jsonb_build_object('assignment_id', x.id, 'expires_at', x.expires_at, 'offered_at', x.offered_at, 'order_number', o.order_number,
      'restaurant', jsonb_build_object('name', j.pickup_address_snapshot ->> 'name', 'address', j.pickup_address_snapshot ->> 'address', 'city', j.pickup_address_snapshot ->> 'city'),
      'delivery_area', trim(coalesce(j.delivery_address_snapshot ->> 'postal_code', '') || ' ' || coalesce(j.delivery_address_snapshot ->> 'city', '')),
      'distance_to_pickup_km', x.distance_to_pickup_km, 'delivery_distance_km', j.estimated_distance_km,
      'estimated_minutes', public.lg_minutes(coalesce(x.distance_to_pickup_km, 0) + coalesce(j.estimated_distance_km, 0), r.vehicle_type),
      'estimated_earning', x.estimated_earning, 'ready_at', o.estimated_ready_at, 'scheduled_for', o.scheduled_for);
  end if;
  select count(*) filter (where status = 'delivered'), count(*) filter (where status = 'failed') into v_done, v_failed
    from public.delivery_jobs where id in (select delivery_job_id from public.delivery_assignments where rider_id = r.id and status in ('accepted', 'cancelled'));
  select count(*) into v_cancel from public.delivery_assignments where rider_id = r.id and status = 'cancelled' and rejection_reason is not null
     and rejection_reason not in ('assigned_to_other', 'already_assigned', 'offline', 'suspended', 'admin');
  return jsonb_build_object(
    'rider', jsonb_build_object('id', r.id, 'status', r.status, 'first_name', r.first_name, 'last_name', r.last_name, 'city', r.city, 'vehicle_type', r.vehicle_type,
      'vehicle_details', r.vehicle_details, 'suspension_reason', case when r.status = 'suspended' then r.suspension_reason end,
      'rejected_reason', case when r.status = 'rejected' then r.rejected_reason end, 'location_consent', r.location_consent_at is not null,
      'documents', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'type', d.document_type, 'status', d.status, 'expires_at', d.expires_at, 'uploaded_at', d.uploaded_at)
                     order by d.uploaded_at), '[]'::jsonb) from public.rider_documents d where d.rider_id = r.id)),
    'availability', jsonb_build_object('is_online', coalesce(a.is_online, false), 'accepting_orders', coalesce(a.accepting_orders, false), 'online_since', a.online_since,
      'current_capacity', coalesce(a.current_capacity, 0), 'max_concurrent_deliveries', coalesce(a.max_concurrent_deliveries, 1), 'last_location_at', a.last_location_at),
    'settings', jsonb_build_object('interval_active', public.billing_setting_int('logistics_location_interval_active', 15),
      'interval_idle', public.billing_setting_int('logistics_location_interval_idle', 60),
      'arrival_radius_m', public.billing_setting_int('logistics_arrival_radius_m', 100)),
    'offer', v_offer,
    'active', (select coalesce(jsonb_agg(jsonb_build_object('id', dj.id, 'status', dj.status, 'order_number', oo.order_number, 'restaurant', dj.pickup_address_snapshot ->> 'name')
                 order by dj.accepted_at), '[]'::jsonb)
                 from public.delivery_jobs dj join public.orders oo on oo.id = dj.order_id
                where dj.rider_id = r.id and dj.status in ('assigned', 'rider_to_restaurant', 'arrived_restaurant', 'picked_up', 'rider_to_customer', 'arrived_customer')),
    'stats', jsonb_build_object(
      'completed', v_done, 'failed', v_failed,
      'completion_rate', case when v_done + v_failed + v_cancel > 0 then round(v_done::numeric / (v_done + v_failed + v_cancel), 3) end,
      'avg_delivery_minutes', (select round(avg(extract(epoch from (delivered_at - accepted_at)) / 60.0), 1) from public.delivery_jobs where rider_id = r.id and status = 'delivered'),
      'total_deliveries', r.total_deliveries));
end $$;

create or replace function public.rider_earnings_summary()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare r public.rider_profiles; v_tz text := 'Europe/Rome';
begin
  r := public.lg_rider_of();
  if r.id is null then raise exception 'Non sei un Rider.' using errcode = '42501'; end if;
  return jsonb_build_object(
    'today', (select coalesce(sum(total), 0) from public.rider_earnings where rider_id = r.id and status <> 'cancelled' and (created_at at time zone v_tz)::date = (now() at time zone v_tz)::date),
    'week', (select coalesce(sum(total), 0) from public.rider_earnings where rider_id = r.id and status <> 'cancelled' and created_at >= date_trunc('week', now() at time zone v_tz) at time zone v_tz),
    'month', (select coalesce(sum(total), 0) from public.rider_earnings where rider_id = r.id and status <> 'cancelled' and created_at >= date_trunc('month', now() at time zone v_tz) at time zone v_tz),
    'to_pay', (select coalesce(sum(total), 0) from public.rider_earnings where rider_id = r.id and status in ('pending', 'approved')),
    'paid', (select coalesce(sum(total), 0) from public.rider_earnings where rider_id = r.id and status = 'paid'),
    'items', (select coalesce(jsonb_agg(jsonb_build_object('id', e.id, 'total', e.total, 'base_fee', e.base_fee, 'distance_fee', e.distance_fee, 'bonus', e.bonus,
                 'adjustment', e.adjustment, 'status', e.status, 'note', e.note, 'created_at', e.created_at, 'paid_at', e.paid_at,
                 'order_number', (select oo.order_number from public.delivery_jobs dj join public.orders oo on oo.id = dj.order_id where dj.id = e.delivery_job_id))
                 order by e.created_at desc), '[]'::jsonb)
                from (select * from public.rider_earnings where rider_id = r.id order by created_at desc limit 100) e));
end $$;

-- ────────────────────────────────────────────────────────────────────
--  9. CLIENTE E RISTORANTE
-- ────────────────────────────────────────────────────────────────────
-- Tracking della consegna (cliente registrato o ospite con token). Posizione del Rider SOLO dopo il ritiro.
create or replace function public.order_delivery(p_number text, p_token text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid; j public.delivery_jobs; o public.orders; rp public.rider_profiles; a public.rider_availability; v_pos jsonb; v_rated boolean;
begin
  v_id := public.order_access(p_number, p_token);
  if v_id is null then return null; end if;
  perform public.lg_expire_offers();
  select * into j from public.delivery_jobs where order_id = v_id;
  if j.id is null then return jsonb_build_object('provider', (select delivery_provider_type from public.orders where id = v_id), 'job', null); end if;
  select * into o from public.orders where id = v_id;
  if j.rider_id is not null then
    select * into rp from public.rider_profiles where id = j.rider_id;
    select * into a from public.rider_availability where rider_id = j.rider_id;
  end if;
  if j.status in ('picked_up', 'rider_to_customer', 'arrived_customer') and a.last_location_at > now() - interval '3 minutes' then
    v_pos := jsonb_build_object('latitude', round(a.last_latitude::numeric, 5), 'longitude', round(a.last_longitude::numeric, 5), 'at', a.last_location_at);
  end if;
  v_rated := exists (select 1 from public.delivery_ratings where delivery_job_id = j.id);
  return jsonb_build_object('provider', 'asiafood', 'job', jsonb_build_object(
    'status', j.status,
    'rider', case when rp.id is not null and j.status not in ('waiting_assignment', 'offered', 'cancelled') then jsonb_build_object(
      'name', rp.first_name || ' ' || left(rp.last_name, 1) || '.', 'vehicle_type', rp.vehicle_type, 'photo_url', rp.profile_photo_url) end,
    'rider_position', v_pos,
    'restaurant', jsonb_build_object('latitude', j.pickup_latitude, 'longitude', j.pickup_longitude, 'name', j.pickup_address_snapshot ->> 'name'),
    'destination', jsonb_build_object('latitude', j.delivery_latitude, 'longitude', j.delivery_longitude),
    'eta_min_at', j.eta_delivery_min_at, 'eta_max_at', j.eta_delivery_max_at, 'eta_source', j.eta_source, 'eta_updated_at', j.eta_updated_at,
    'delivery_code', case when j.delivery_code_required and j.status not in ('delivered', 'failed', 'cancelled') then j.delivery_code end,
    'accepted_at', j.accepted_at, 'picked_up_at', j.picked_up_at, 'arrived_at_customer_at', j.arrived_at_customer_at, 'delivered_at', j.delivered_at,
    'can_rate', j.status = 'delivered' and o.user_id is not null and o.user_id = auth.uid() and not v_rated, 'rated', v_rated));
end $$;

create or replace function public.delivery_rate(p_number text, p_rating int, p_comment text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid; j public.delivery_jobs; o public.orders;
begin
  if auth.uid() is null then raise exception 'Accedi per valutare la consegna.' using errcode = '42501'; end if;
  v_id := public.order_access(p_number, null);
  select * into o from public.orders where id = v_id;
  if o.id is null or o.user_id is distinct from auth.uid() then raise exception 'Ordine non trovato.' using errcode = '42501'; end if;
  select * into j from public.delivery_jobs where order_id = o.id;
  if j.id is null or j.status <> 'delivered' then raise exception 'Puoi valutare solo una consegna completata.'; end if;
  if p_rating not between 1 and 5 then raise exception 'Voto non valido.'; end if;
  insert into public.delivery_ratings (delivery_job_id, rider_id, user_id, rating, comment)
  values (j.id, j.rider_id, auth.uid(), p_rating, nullif(left(trim(coalesce(p_comment, '')), 500), ''))
  on conflict (delivery_job_id) do nothing;
  if not found then raise exception 'Hai già valutato questa consegna.' using hint = 'ALREADY_RATED'; end if;
  -- Media interna (mai pubblica)
  update public.rider_profiles set rating_internal = (select round(avg(rating)::numeric, 2) from public.delivery_ratings where rider_id = j.rider_id) where id = j.rider_id;
  return jsonb_build_object('ok', true);
end $$;

-- Consegne AsiaFood per il terminale del ristorante (nome Rider, arrivo stimato, codice di ritiro)
create or replace function public.restaurant_deliveries(p_restaurant uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.can_view_orders(p_restaurant) then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  perform public.lg_expire_offers();
  return (select coalesce(jsonb_agg(jsonb_build_object(
      'order_id', j.order_id, 'job_id', j.id, 'status', j.status, 'pickup_code', j.pickup_code,
      'rider', case when rp.id is not null then jsonb_build_object('name', rp.first_name || ' ' || left(rp.last_name, 1) || '.', 'vehicle_type', rp.vehicle_type) end,
      'eta_pickup_at', j.eta_pickup_at, 'arrived_at_restaurant_at', j.arrived_at_restaurant_at, 'picked_up_at', j.picked_up_at,
      'searching_since', case when j.status in ('waiting_assignment', 'offered') then j.created_at end) order by j.created_at desc), '[]'::jsonb)
    from public.delivery_jobs j left join public.rider_profiles rp on rp.id = j.rider_id
   where j.restaurant_id = p_restaurant and (j.status not in ('delivered', 'failed', 'cancelled') or j.updated_at > now() - interval '12 hours'));
end $$;

-- ────────────────────────────────────────────────────────────────────
--  10. ADMIN
-- ────────────────────────────────────────────────────────────────────
create or replace function public.lg_assert_admin()
returns void language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
end $$;

create or replace function public.admin_riders(p jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public.lg_assert_admin();
  return (select coalesce(jsonb_agg(x order by x ->> 'created_at' desc), '[]'::jsonb) from (
    select jsonb_build_object('id', r.id, 'user_id', r.user_id, 'name', r.first_name || ' ' || r.last_name, 'city', r.city, 'vehicle_type', r.vehicle_type,
      'status', r.status, 'is_online', coalesce(a.is_online, false), 'busy', coalesce(a.current_capacity, 0) > 0,
      'total_deliveries', r.total_deliveries, 'rating_internal', r.rating_internal, 'is_demo', r.is_demo,
      'documents', (select count(*) from public.rider_documents d where d.rider_id = r.id),
      'documents_pending', (select count(*) from public.rider_documents d where d.rider_id = r.id and d.status = 'pending'),
      'last_activity', greatest(a.updated_at, (select max(created_at) from public.delivery_events e where e.actor_id = r.user_id)),
      'created_at', r.created_at) x
      from public.rider_profiles r left join public.rider_availability a on a.rider_id = r.id
     where (coalesce(p ->> 'status', '') = '' or r.status = p ->> 'status')
       and (coalesce(p ->> 'q', '') = '' or (r.first_name || ' ' || r.last_name || ' ' || r.city) ilike '%' || (p ->> 'q') || '%')) s);
end $$;

create or replace function public.admin_rider_detail(p_rider uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; a public.rider_availability;
begin
  perform public.lg_assert_admin();
  select * into r from public.rider_profiles where id = p_rider;
  if not found then raise exception 'Rider non trovato.'; end if;
  select * into a from public.rider_availability where rider_id = r.id;
  return to_jsonb(r) || jsonb_build_object(
    'availability', to_jsonb(a) - 'last_latitude' - 'last_longitude',
    'documents', (select coalesce(jsonb_agg(to_jsonb(d) order by d.uploaded_at), '[]'::jsonb) from public.rider_documents d where d.rider_id = r.id),
    'recent_jobs', (select coalesce(jsonb_agg(jsonb_build_object('id', j.id, 'status', j.status, 'order_number', o.order_number, 'restaurant', j.pickup_address_snapshot ->> 'name',
                    'accepted_at', j.accepted_at, 'delivered_at', j.delivered_at) order by j.created_at desc), '[]'::jsonb)
                    from (select * from public.delivery_jobs where rider_id = r.id order by created_at desc limit 20) j join public.orders o on o.id = j.order_id),
    'earnings', jsonb_build_object('pending', (select coalesce(sum(total), 0) from public.rider_earnings where rider_id = r.id and status in ('pending', 'approved')),
                                   'paid', (select coalesce(sum(total), 0) from public.rider_earnings where rider_id = r.id and status = 'paid')),
    'ratings', jsonb_build_object('count', (select count(*) from public.delivery_ratings where rider_id = r.id), 'average', r.rating_internal),
    'flags', (select coalesce(jsonb_agg(jsonb_build_object('type', l.alert_type, 'message', l.message, 'created_at', l.created_at) order by l.created_at desc), '[]'::jsonb)
                from (select * from public.logistics_alerts where rider_id = r.id order by created_at desc limit 20) l));
end $$;

create or replace function public.admin_rider_action(p_rider uuid, p_action text, p_reason text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r public.rider_profiles; x record;
begin
  perform public.lg_assert_admin();
  select * into r from public.rider_profiles where id = p_rider for update;
  if not found then raise exception 'Rider non trovato.'; end if;
  if p_action = 'approve' then
    if r.status not in ('pending', 'rejected', 'inactive') then raise exception 'Il Rider non è in attesa di approvazione.'; end if;
    update public.rider_profiles set status = 'approved', approved_at = now(), approved_by = auth.uid(), rejected_reason = null where id = r.id;
    update public.profiles set role = 'rider' where id = r.user_id and role = 'customer';
    insert into public.rider_availability (rider_id, max_concurrent_deliveries)
    values (r.id, greatest(1, least(5, public.billing_setting_int('logistics_default_rider_capacity', 1)))) on conflict (rider_id) do nothing;
    perform public.notify_user(r.user_id, 'rider', 'Candidatura Rider approvata', 'Benvenuto nel team AsiaFood! Vai online quando vuoi ricevere consegne.', '/rider', null, 'rider_approved:' || r.id);
  elsif p_action = 'reject' then
    if r.status <> 'pending' then raise exception 'Solo le candidature in attesa possono essere rifiutate.'; end if;
    update public.rider_profiles set status = 'rejected', rejected_reason = nullif(left(trim(coalesce(p_reason, '')), 300), '') where id = r.id;
    perform public.notify_user(r.user_id, 'rider', 'Candidatura Rider non approvata', coalesce(nullif(trim(p_reason), ''), 'La candidatura non è stata approvata.'), '/rider/apply', null, null);
  elsif p_action = 'suspend' then
    if char_length(trim(coalesce(p_reason, ''))) < 3 then raise exception 'Indica il motivo della sospensione.'; end if;
    update public.rider_profiles set status = 'suspended', suspended_at = now(), suspension_reason = left(trim(p_reason), 300) where id = r.id;
    update public.rider_availability set is_online = false, accepting_orders = false, offline_since = now(), last_latitude = null, last_longitude = null, last_location_at = null where rider_id = r.id;
    perform public.lg_expire_rider_offers(r.id, 'suspended');
    -- Consegne non ancora ritirate: tornano in assegnazione; quelle già ritirate restano al supporto
    for x in select id, status from public.delivery_jobs where rider_id = r.id and status in ('assigned', 'rider_to_restaurant', 'arrived_restaurant') loop
      perform public.lg_set_status(x.id, 'waiting_assignment', 'admin', auth.uid(), jsonb_build_object('reason', 'rider_suspended'));
      update public.delivery_jobs set rider_id = null, accepted_at = null, reassignment_count = reassignment_count + 1, dispatch_after = now() where id = x.id;
      perform public.lg_dispatch(x.id, false);
    end loop;
    perform public.lg_release_capacity(r.id);
    perform public.notify_user(r.user_id, 'rider', 'Profilo Rider sospeso', left(trim(p_reason), 300), '/rider', null, null);
  elsif p_action = 'reactivate' then
    if r.status not in ('suspended', 'inactive') then raise exception 'Il Rider non è sospeso.'; end if;
    update public.rider_profiles set status = 'approved', suspended_at = null, suspension_reason = null where id = r.id;
    perform public.notify_user(r.user_id, 'rider', 'Profilo Rider riattivato', 'Puoi tornare online.', '/rider', null, null);
  elsif p_action = 'deactivate' then
    update public.rider_profiles set status = 'inactive' where id = r.id;
    update public.rider_availability set is_online = false, accepting_orders = false where rider_id = r.id;
    perform public.lg_expire_rider_offers(r.id, 'admin');
  elsif p_action = 'note' then
    update public.rider_profiles set admin_notes = left(trim(coalesce(p_reason, '')), 2000) where id = r.id;
  else
    raise exception 'Azione non valida.';
  end if;
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'rider_' || p_action, 'rider', r.id::text, jsonb_build_object('reason', left(coalesce(p_reason, ''), 300)));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_document_review(p_doc uuid, p_status text, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public.lg_assert_admin();
  if p_status not in ('approved', 'rejected', 'expired') then raise exception 'Stato non valido.'; end if;
  update public.rider_documents set status = p_status, review_note = nullif(left(trim(coalesce(p_note, '')), 300), ''), reviewed_at = now(), reviewed_by = auth.uid()
   where id = p_doc;
  if not found then raise exception 'Documento non trovato.'; end if;
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'rider_document_' || p_status, 'rider_document', p_doc::text, '{}'::jsonb);
  return jsonb_build_object('ok', true);
end $$;

-- Control center: consegne e Rider (posizioni SOLO per l'Admin)
create or replace function public.admin_dispatch_board()
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public.lg_assert_admin();
  perform public.lg_expire_offers();
  return jsonb_build_object(
    'jobs', (select coalesce(jsonb_agg(jsonb_build_object('id', j.id, 'status', j.status, 'order_number', o.order_number, 'order_status', o.status,
               'restaurant', j.pickup_address_snapshot ->> 'name', 'restaurant_id', j.restaurant_id,
               'pickup', jsonb_build_object('latitude', j.pickup_latitude, 'longitude', j.pickup_longitude),
               'dropoff', jsonb_build_object('latitude', j.delivery_latitude, 'longitude', j.delivery_longitude, 'area', j.delivery_address_snapshot ->> 'city'),
               'rider', case when rp.id is not null then jsonb_build_object('id', rp.id, 'name', rp.first_name || ' ' || left(rp.last_name, 1) || '.') end,
               'distance_km', j.estimated_distance_km, 'created_at', j.created_at, 'accepted_at', j.accepted_at, 'dispatch_attempts', j.dispatch_attempts,
               'offer_expires_at', j.offer_expires_at, 'eta_max_at', j.eta_delivery_max_at, 'flags', j.flags, 'ready', o.status = 'ready',
               'waiting_minutes', round(extract(epoch from (now() - j.created_at)) / 60.0)) order by j.created_at), '[]'::jsonb)
             from public.delivery_jobs j join public.orders o on o.id = j.order_id left join public.rider_profiles rp on rp.id = j.rider_id
            where j.status not in ('delivered', 'failed', 'cancelled')),
    'riders', (select coalesce(jsonb_agg(jsonb_build_object('id', r.id, 'name', r.first_name || ' ' || left(r.last_name, 1) || '.', 'vehicle_type', r.vehicle_type,
               'city', r.city, 'status', r.status, 'accepting_orders', a.accepting_orders, 'capacity', a.current_capacity, 'max', a.max_concurrent_deliveries,
               'busy', a.current_capacity > 0, 'latitude', a.last_latitude, 'longitude', a.last_longitude, 'location_at', a.last_location_at,
               'online_since', a.online_since) order by r.first_name), '[]'::jsonb)
             from public.rider_availability a join public.rider_profiles r on r.id = a.rider_id where a.is_online),
    'alerts', (select coalesce(jsonb_agg(to_jsonb(l) order by l.created_at desc), '[]'::jsonb) from (select * from public.logistics_alerts where status <> 'resolved' order by created_at desc limit 50) l),
    'auto_dispatch', public.billing_setting_bool('logistics_auto_dispatch_enabled', true),
    'service_enabled', public.billing_setting_bool('logistics_enabled', true));
end $$;

create or replace function public.admin_assign_job(p_job uuid, p_rider uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; r public.rider_profiles; a public.rider_availability; v_prev uuid; v_quote jsonb; o public.orders;
begin
  perform public.lg_assert_admin();
  select * into j from public.delivery_jobs where id = p_job for update;
  if not found then raise exception 'Consegna non trovata.'; end if;
  if j.status not in ('waiting_assignment', 'offered', 'assigned', 'rider_to_restaurant', 'arrived_restaurant') then
    raise exception 'Questa consegna non può essere riassegnata (stato %).', j.status using hint = 'INVALID_TRANSITION';
  end if;
  select * into r from public.rider_profiles where id = p_rider;
  if r.id is null or r.status not in ('approved', 'active') then raise exception 'Rider non attivo.'; end if;
  select * into a from public.rider_availability where rider_id = p_rider for update;
  if not coalesce(a.is_online, false) then raise exception 'Il Rider è offline.'; end if;
  if a.current_capacity >= a.max_concurrent_deliveries and j.rider_id is distinct from p_rider then raise exception 'Il Rider non ha capacità disponibile.'; end if;
  v_prev := j.rider_id;
  update public.delivery_assignments set status = 'cancelled', responded_at = now(), rejection_reason = 'admin' where delivery_job_id = j.id and status in ('offered', 'accepted');
  if j.status <> 'waiting_assignment' then
    perform public.lg_set_status(j.id, 'waiting_assignment', 'admin', auth.uid(), jsonb_build_object('reason', 'manual_reassignment'));
  end if;
  v_quote := public.lg_earning_quote(j.id);
  insert into public.delivery_assignments (delivery_job_id, rider_id, status, distance_to_pickup_km, estimated_earning, manual, assigned_by, expires_at, responded_at)
  values (j.id, p_rider, 'accepted', public.lg_km(a.last_latitude, a.last_longitude, j.pickup_latitude, j.pickup_longitude),
          nullif(v_quote ->> 'total', '')::numeric, true, auth.uid(), now(), now());
  update public.delivery_jobs set rider_id = p_rider, accepted_at = now(), offer_expires_at = null,
         reassignment_count = reassignment_count + case when v_prev is not null then 1 else 0 end,
         flags = array_remove(flags, 'dispatch_exhausted') where id = j.id;
  perform public.lg_set_status(j.id, 'assigned', 'admin', auth.uid(), jsonb_build_object('manual', true, 'rider_id', p_rider, 'previous_rider_id', v_prev));
  perform public.lg_release_capacity(p_rider);
  if v_prev is not null and v_prev <> p_rider then
    perform public.lg_release_capacity(v_prev);
    perform public.lg_notify_rider(v_prev, 'unassigned', 'Consegna riassegnata', 'Lo staff ha riassegnato una tua consegna non ancora ritirata.', '/rider', 'unassigned:' || j.id || ':' || v_prev);
  end if;
  perform public.lg_eta(j.id);
  select * into o from public.orders where id = j.order_id;
  perform public.lg_notify_rider(p_rider, 'assigned', 'Consegna assegnata', format('Lo staff ti ha assegnato l''ordine %s (%s).', o.order_number, j.pickup_address_snapshot ->> 'name'),
                                 '/rider/delivery/' || j.id, 'assigned:' || j.id || ':' || p_rider);
  perform public.lg_notify_customer(j.id, 'rider_assigned', 'Rider assegnato', format('%s %s. porterà il tuo ordine %s.', r.first_name, left(r.last_name, 1), o.order_number));
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
  values (auth.uid(), case when v_prev is null then 'delivery_manual_assignment' else 'delivery_reassignment' end, 'delivery_job', j.id::text,
          jsonb_build_object('rider_id', p_rider, 'previous_rider_id', v_prev));
  update public.logistics_alerts set status = 'resolved', resolved_at = now(), resolved_by = auth.uid()
   where delivery_job_id = j.id and status <> 'resolved' and alert_type in ('no_rider', 'unassigned_too_long', 'dispatch_exhausted');
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_job_action(p_job uuid, p_action text, p jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; v_res jsonb;
begin
  perform public.lg_assert_admin();
  select * into j from public.delivery_jobs where id = p_job;
  if not found then raise exception 'Consegna non trovata.'; end if;
  p := coalesce(p, '{}'::jsonb);
  if p_action = 'redispatch' then
    if j.status = 'offered' then
      update public.delivery_assignments set status = 'cancelled', responded_at = now(), rejection_reason = 'admin' where delivery_job_id = j.id and status = 'offered';
      perform public.lg_set_status(j.id, 'waiting_assignment', 'admin', auth.uid(), jsonb_build_object('reason', 'redispatch'));
    end if;
    update public.delivery_jobs set flags = array_remove(flags, 'dispatch_exhausted'), dispatch_attempts = 0, dispatch_after = now() where id = j.id;
    v_res := public.lg_dispatch(j.id, true);
  elsif p_action = 'release' then
    -- Rilascio manuale prima del ritiro (es. Rider bloccato): torna in assegnazione
    if j.status not in ('assigned', 'rider_to_restaurant', 'arrived_restaurant') then raise exception 'Rilascio possibile solo prima del ritiro.' using hint = 'INVALID_TRANSITION'; end if;
    update public.delivery_assignments set status = 'cancelled', responded_at = now(), rejection_reason = 'admin' where delivery_job_id = j.id and status = 'accepted';
    perform public.lg_set_status(j.id, 'waiting_assignment', 'admin', auth.uid(), jsonb_build_object('reason', 'released'));
    update public.delivery_jobs set rider_id = null, accepted_at = null, reassignment_count = reassignment_count + 1, dispatch_after = now() where id = j.id;
    perform public.lg_release_capacity(j.rider_id);
    v_res := public.lg_dispatch(j.id, true);
  elsif p_action = 'mark_failed' then
    perform public.lg_set_status(j.id, 'failed', 'admin', auth.uid(), jsonb_build_object('reason', p ->> 'reason'));
    update public.delivery_jobs set failure_reason = left(coalesce(p ->> 'reason', 'admin'), 60) where id = j.id;
    perform public.lg_release_capacity(j.rider_id);
  elsif p_action = 'mark_delivered' then
    -- Chiusura manuale (es. Rider senza connessione): tracciata come azione Admin
    if j.status not in ('picked_up', 'rider_to_customer', 'arrived_customer') then raise exception 'La consegna non è stata ritirata.' using hint = 'INVALID_TRANSITION'; end if;
    if j.status = 'picked_up' then perform public.lg_set_status(j.id, 'rider_to_customer', 'admin', auth.uid()); end if;
    perform public.lg_set_status(j.id, 'delivered', 'admin', auth.uid(), jsonb_build_object('manual', true, 'reason', p ->> 'reason'));
    perform public.lg_sync_order(j.id, 'delivered', auth.uid());
    perform public.lg_release_capacity(j.rider_id);
  elsif p_action = 'cancel' then
    update public.delivery_assignments set status = 'cancelled', responded_at = now(), rejection_reason = 'admin' where delivery_job_id = j.id and status in ('offered');
    perform public.lg_set_status(j.id, 'cancelled', 'admin', auth.uid(), jsonb_build_object('reason', p ->> 'reason'));
    update public.delivery_jobs set cancel_reason = left(coalesce(p ->> 'reason', 'Annullata dallo staff'), 200) where id = j.id;
    perform public.lg_release_capacity(j.rider_id);
  else
    raise exception 'Azione non valida.';
  end if;
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'delivery_' || p_action, 'delivery_job', j.id::text, jsonb_build_object('reason', p ->> 'reason'));
  return coalesce(v_res, '{}'::jsonb) || jsonb_build_object('ok', true);
end $$;

-- Timeline completa della consegna per l'Admin
create or replace function public.admin_job_detail(p_job uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; o public.orders;
begin
  perform public.lg_assert_admin();
  select * into j from public.delivery_jobs where id = p_job;
  if not found then
    select * into j from public.delivery_jobs where order_id = p_job;
  end if;
  if j.id is null then raise exception 'Consegna non trovata.'; end if;
  select * into o from public.orders where id = j.order_id;
  return to_jsonb(j) || jsonb_build_object(
    'order_number', o.order_number, 'order_status', o.status,
    'rider', (select jsonb_build_object('id', r.id, 'name', r.first_name || ' ' || r.last_name, 'phone', r.phone, 'vehicle_type', r.vehicle_type) from public.rider_profiles r where r.id = j.rider_id),
    'waiting_minutes', case when j.picked_up_at is not null and j.arrived_at_restaurant_at is not null then round(extract(epoch from (j.picked_up_at - j.arrived_at_restaurant_at)) / 60.0, 1) end,
    'events', (select coalesce(jsonb_agg(jsonb_build_object('type', e.event_type, 'actor', e.actor_type, 'metadata', e.metadata, 'created_at', e.created_at) order by e.created_at, e.id), '[]'::jsonb)
                 from public.delivery_events e where e.delivery_job_id = j.id),
    'assignments', (select coalesce(jsonb_agg(jsonb_build_object('id', x.id, 'rider', rr.first_name || ' ' || left(rr.last_name, 1) || '.', 'status', x.status, 'manual', x.manual,
                     'distance_to_pickup_km', x.distance_to_pickup_km, 'estimated_earning', x.estimated_earning, 'offered_at', x.offered_at, 'responded_at', x.responded_at,
                     'rejection_reason', x.rejection_reason) order by x.offered_at), '[]'::jsonb)
                      from public.delivery_assignments x join public.rider_profiles rr on rr.id = x.rider_id where x.delivery_job_id = j.id),
    'earnings', (select coalesce(jsonb_agg(to_jsonb(e)), '[]'::jsonb) from public.rider_earnings e where e.delivery_job_id = j.id),
    'issues', (select coalesce(jsonb_agg(to_jsonb(i) order by i.created_at), '[]'::jsonb) from public.delivery_issues i where i.delivery_job_id = j.id),
    'rating', (select to_jsonb(dr) - 'user_id' from public.delivery_ratings dr where dr.delivery_job_id = j.id),
    'location_points', (select count(*) from public.rider_locations l where l.delivery_job_id = j.id));
end $$;

create or replace function public.admin_earning_action(p_earning uuid, p_action text, p_amount numeric default null, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare e public.rider_earnings;
begin
  perform public.lg_assert_admin();
  select * into e from public.rider_earnings where id = p_earning for update;
  if not found then raise exception 'Compenso non trovato.'; end if;
  if p_action = 'approve' then
    if e.status <> 'pending' then raise exception 'Compenso non in attesa.'; end if;
    update public.rider_earnings set status = 'approved', approved_at = now() where id = e.id;
  elsif p_action = 'mark_paid' then
    -- Solo registrazione (pagamento eseguito fuori piattaforma): nessun trasferimento automatico
    if e.status not in ('approved', 'pending') then raise exception 'Compenso non pagabile.'; end if;
    update public.rider_earnings set status = 'paid', paid_at = now(), approved_at = coalesce(approved_at, now()),
           payout_reference = nullif(left(trim(coalesce(p_note, '')), 120), '') where id = e.id;
  elsif p_action = 'adjust' then
    if e.status = 'paid' then raise exception 'Compenso già pagato: registra una rettifica separata.'; end if;
    if p_amount is null or abs(p_amount) > 200 then raise exception 'Importo della rettifica non valido.'; end if;
    if char_length(trim(coalesce(p_note, ''))) < 3 then raise exception 'Indica il motivo della rettifica.'; end if;
    update public.rider_earnings set adjustment = round(p_amount, 2), total = greatest(0, base_fee + distance_fee + bonus + round(p_amount, 2)),
           note = left(trim(p_note), 300) where id = e.id;
  elsif p_action = 'bonus' then
    if e.status = 'paid' then raise exception 'Compenso già pagato.'; end if;
    if p_amount is null or p_amount < 0 or p_amount > 50 then raise exception 'Bonus non valido.'; end if;
    update public.rider_earnings set bonus = round(p_amount, 2), total = greatest(0, base_fee + distance_fee + round(p_amount, 2) + adjustment),
           note = coalesce(nullif(left(trim(coalesce(p_note, '')), 300), ''), note) where id = e.id;
  elsif p_action = 'cancel' then
    if e.status = 'paid' then raise exception 'Compenso già pagato.'; end if;
    update public.rider_earnings set status = 'cancelled', note = coalesce(nullif(left(trim(coalesce(p_note, '')), 300), ''), note) where id = e.id;
  else
    raise exception 'Azione non valida.';
  end if;
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'earning_' || p_action, 'rider_earning', e.id::text, jsonb_build_object('amount', p_amount, 'note', left(coalesce(p_note, ''), 300)));
  return jsonb_build_object('ok', true);
end $$;

-- Compenso per consegne annullate/fallite (decisione esplicita dell'Admin, mai automatica)
create or replace function public.admin_earning_create(p_job uuid, p_amount numeric, p_note text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; v_id uuid;
begin
  perform public.lg_assert_admin();
  select * into j from public.delivery_jobs where id = p_job;
  if j.id is null or j.rider_id is null then
    select rider_id into j.rider_id from public.delivery_assignments where delivery_job_id = p_job and status in ('accepted', 'cancelled') order by offered_at desc limit 1;
  end if;
  if j.rider_id is null then raise exception 'Nessun Rider collegato a questa consegna.'; end if;
  if p_amount is null or p_amount <= 0 or p_amount > 100 then raise exception 'Importo non valido.'; end if;
  if char_length(trim(coalesce(p_note, ''))) < 3 then raise exception 'Indica il motivo.'; end if;
  insert into public.rider_earnings (rider_id, delivery_job_id, base_fee, total, note, adjustment)
  values (j.rider_id, p_job, 0, round(p_amount, 2), left(trim(p_note), 300), round(p_amount, 2)) returning id into v_id;
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'earning_adjustment', 'rider_earning', v_id::text, jsonb_build_object('delivery_job_id', p_job, 'amount', p_amount, 'note', left(p_note, 300)));
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;

create or replace function public.admin_restaurant_logistics(p_restaurant uuid, p_enabled boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public.lg_assert_admin();
  update public.restaurant_order_settings set asiafood_delivery_enabled = p_enabled,
         delivery_provider_type = case when not p_enabled and delivery_provider_type = 'asiafood' then 'restaurant' else delivery_provider_type end
   where restaurant_id = p_restaurant;
  if not found then raise exception 'Configura prima gli ordini online del ristorante.'; end if;
  insert into public.admin_audit_logs (admin_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'restaurant_asiafood_delivery', 'restaurant', p_restaurant::text, jsonb_build_object('enabled', p_enabled));
  return jsonb_build_object('ok', true);
end $$;

-- Metriche logistiche (nessun ranking pubblico dei Rider)
create or replace function public.logistics_stats(p_days int default 30)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_from timestamptz := now() - make_interval(days => greatest(1, least(coalesce(p_days, 30), 365)));
        v_online int; v_busy int;
begin
  perform public.lg_assert_admin();
  select count(*), count(*) filter (where current_capacity > 0) into v_online, v_busy from public.rider_availability where is_online;
  return (select jsonb_build_object(
    'definitions', jsonb_build_object(
      'assignment_time', 'Minuti tra creazione del job e accettazione del Rider',
      'pickup_time', 'Minuti tra accettazione e ritiro al ristorante',
      'delivery_time', 'Minuti tra ritiro e consegna',
      'on_time_rate', 'Consegne completate entro l''ETA massima calcolata all''accettazione (+5 min di tolleranza)',
      'utilization', 'Rider online con almeno una consegna attiva / Rider online (istantaneo)',
      'wait_time', 'Minuti di attesa del Rider al ristorante (arrivo → ritiro)'),
    'active', (select count(*) from public.delivery_jobs where status in ('assigned', 'rider_to_restaurant', 'arrived_restaurant', 'picked_up', 'rider_to_customer', 'arrived_customer')),
    'waiting_assignment', (select count(*) from public.delivery_jobs where status in ('waiting_assignment', 'offered')),
    'jobs_period', count(*),
    'delivered', count(*) filter (where status = 'delivered'),
    'failed', count(*) filter (where status = 'failed'),
    'cancelled', count(*) filter (where status = 'cancelled'),
    'avg_assignment_minutes', round(avg(extract(epoch from (accepted_at - created_at)) / 60.0) filter (where accepted_at is not null), 1),
    'avg_pickup_minutes', round(avg(extract(epoch from (picked_up_at - accepted_at)) / 60.0) filter (where picked_up_at is not null and accepted_at is not null), 1),
    'avg_delivery_minutes', round(avg(extract(epoch from (delivered_at - picked_up_at)) / 60.0) filter (where delivered_at is not null and picked_up_at is not null), 1),
    'avg_wait_minutes', round(avg(extract(epoch from (picked_up_at - arrived_at_restaurant_at)) / 60.0) filter (where picked_up_at is not null and arrived_at_restaurant_at is not null), 1),
    'on_time_rate', case when count(*) filter (where status = 'delivered') > 0 then round(
      (count(*) filter (where status = 'delivered' and (select max((x.metadata ->> 'eta_max')::timestamptz) from public.delivery_events x where x.delivery_job_id = j.id and x.event_type = 'assigned') is null
                          or delivered_at <= (select max((x.metadata ->> 'eta_max')::timestamptz) from public.delivery_events x where x.delivery_job_id = j.id and x.event_type = 'assigned') + interval '5 minutes'))::numeric
       / count(*) filter (where status = 'delivered'), 3) end,
    'riders_online', v_online, 'riders_busy', v_busy,
    'utilization', case when v_online > 0 then round(v_busy::numeric / v_online, 3) end,
    'riders_total', (select count(*) from public.rider_profiles where status in ('approved', 'active')),
    'riders_pending', (select count(*) from public.rider_profiles where status = 'pending'),
    'offers', jsonb_build_object('sent', (select count(*) from public.delivery_assignments where offered_at >= v_from and not manual),
      'accepted', (select count(*) from public.delivery_assignments where offered_at >= v_from and not manual and status = 'accepted'),
      'rejected', (select count(*) from public.delivery_assignments where offered_at >= v_from and status = 'rejected'),
      'expired', (select count(*) from public.delivery_assignments where offered_at >= v_from and status = 'expired')),
    'slow_restaurants', (select coalesce(jsonb_agg(x order by (x ->> 'avg_wait_minutes')::numeric desc), '[]'::jsonb) from (
        select jsonb_build_object('restaurant', max(jj.pickup_address_snapshot ->> 'name'), 'deliveries', count(*),
               'avg_wait_minutes', round(avg(extract(epoch from (jj.picked_up_at - jj.arrived_at_restaurant_at)) / 60.0), 1),
               'not_ready_reports', (select count(*) from public.delivery_events e join public.delivery_jobs z on z.id = e.delivery_job_id
                                      where z.restaurant_id = jj.restaurant_id and e.event_type = 'order_not_ready' and e.created_at >= v_from)) x
          from public.delivery_jobs jj where jj.created_at >= v_from and jj.picked_up_at is not null and jj.arrived_at_restaurant_at is not null
         group by jj.restaurant_id having count(*) >= 1 limit 10) s),
    'open_alerts', (select count(*) from public.logistics_alerts where status = 'open'),
    'earnings', jsonb_build_object('pending', (select coalesce(sum(total), 0) from public.rider_earnings where status in ('pending', 'approved')),
                                   'paid_period', (select coalesce(sum(total), 0) from public.rider_earnings where status = 'paid' and paid_at >= v_from)))
    from public.delivery_jobs j where j.created_at >= v_from);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  11. SCHEDULER (ogni minuto): offerte scadute, dispatch, avvisi, retention
-- ────────────────────────────────────────────────────────────────────
create or replace function public.logistics_tick(p_now timestamptz default now())
returns jsonb language plpgsql security definer set search_path = public as $$
declare x record; v_expired int; v_dispatched int := 0; v_alerts int := 0; v_purged int; v_anon int; v_res jsonb; o public.orders;
        v_unassigned int := public.billing_setting_int('logistics_alert_unassigned_minutes', 10);
        v_stale int := public.billing_setting_int('logistics_rider_stale_minutes', 5);
        v_still int := public.billing_setting_int('logistics_rider_stationary_minutes', 12);
        v_late int := public.billing_setting_int('logistics_late_minutes', 15);
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  v_expired := public.lg_expire_offers();
  -- Promemoria "offerta in scadenza" (solo con timeout lunghi: la notifica arriva a metà tempo)
  for x in select a.id, a.rider_id from public.delivery_assignments a where a.status = 'offered'
            and a.expires_at > p_now and a.expires_at - p_now < (a.expires_at - a.offered_at) / 2 loop
    perform public.lg_notify_rider(x.rider_id, 'offer_expiring', 'Offerta in scadenza', 'Hai una consegna da accettare: l''offerta sta per scadere.', '/rider', 'expiring:' || x.id);
  end loop;
  -- Dispatch dei job pronti per la ricerca
  for x in select id from public.delivery_jobs where status = 'waiting_assignment' and dispatch_after <= p_now and not ('dispatch_exhausted' = any(flags))
            order by dispatch_after limit 50 loop
    v_res := public.lg_dispatch(x.id, false);
    if (v_res ->> 'ok')::boolean then v_dispatched := v_dispatched + 1; end if;
  end loop;
  -- Avvisi (con tolleranze: niente allarmi sul singolo dato GPS)
  for x in select j.*, o2.order_number from public.delivery_jobs j join public.orders o2 on o2.id = j.order_id
            where j.status in ('waiting_assignment', 'offered') and j.created_at < p_now - make_interval(mins => v_unassigned) loop
    if public.lg_alert('unassigned_too_long', x.id, null, format('Ordine %s senza Rider da oltre %s minuti.', x.order_number, v_unassigned)) then v_alerts := v_alerts + 1; end if;
  end loop;
  for x in select j.*, o2.order_number, a.last_location_at, a.last_moved_at from public.delivery_jobs j join public.orders o2 on o2.id = j.order_id
             join public.rider_availability a on a.rider_id = j.rider_id
            where j.status in ('assigned', 'rider_to_restaurant', 'picked_up', 'rider_to_customer') loop
    if greatest(x.last_location_at, x.last_rider_update_at) < p_now - make_interval(mins => v_stale) then
      if public.lg_alert('rider_stale', x.id, x.rider_id, format('Ordine %s: il Rider non aggiorna posizione o stato da oltre %s minuti.', x.order_number, v_stale)) then
        update public.delivery_jobs set flags = case when 'rider_no_response' = any(flags) then flags else array_append(flags, 'rider_no_response') end where id = x.id;
        v_alerts := v_alerts + 1;
      end if;
    elsif x.last_moved_at < p_now - make_interval(mins => v_still) and x.status in ('rider_to_restaurant', 'rider_to_customer') then
      if public.lg_alert('rider_stationary', x.id, x.rider_id, format('Ordine %s: il Rider risulta fermo da oltre %s minuti.', x.order_number, v_still)) then v_alerts := v_alerts + 1; end if;
    end if;
  end loop;
  for x in select j.id, j.rider_id, o2.order_number from public.delivery_jobs j join public.orders o2 on o2.id = j.order_id
            where j.status not in ('delivered', 'failed', 'cancelled') and j.eta_delivery_max_at < p_now - make_interval(mins => v_late) loop
    if public.lg_alert('order_late', x.id, x.rider_id, format('Ordine %s in ritardo di oltre %s minuti rispetto alla stima.', x.order_number, v_late)) then v_alerts := v_alerts + 1; end if;
  end loop;
  -- Retention: posizioni precise oltre N ore cancellate (restano solo gli eventi logistici essenziali)
  delete from public.rider_locations where received_at < p_now - make_interval(hours => greatest(1, public.billing_setting_int('logistics_location_retention_hours', 24)));
  get diagnostics v_purged = row_count;
  -- Rider online senza posizioni da molto tempo: messi offline (tracking disattivato)
  update public.rider_availability set is_online = false, accepting_orders = false, offline_since = p_now, last_latitude = null, last_longitude = null, last_location_at = null
   where is_online and current_capacity = 0 and coalesce(last_location_at, online_since) < p_now - interval '30 minutes';
  -- Anonimizzazione dei dati di consegna vecchi
  update public.delivery_jobs set delivery_latitude = null, delivery_longitude = null, delivery_address_snapshot = jsonb_build_object('city', delivery_address_snapshot ->> 'city'),
         delivery_code = null, pickup_code = null
   where status in ('delivered', 'failed', 'cancelled') and updated_at < p_now - make_interval(days => public.billing_setting_int('logistics_delivery_data_retention_days', 365))
     and delivery_latitude is not null;
  get diagnostics v_anon = row_count;
  return jsonb_build_object('expired_offers', v_expired, 'dispatched', v_dispatched, 'alerts', v_alerts, 'locations_purged', v_purged, 'jobs_anonymized', v_anon);
end $$;

-- ETA da provider di percorsi (chiamata dal backend): sostituisce la stima se disponibile
create or replace function public.lg_eta_context(p_job uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare j public.delivery_jobs; a public.rider_availability; v_vehicle text;
begin
  perform public.assert_service();
  select * into j from public.delivery_jobs where id = p_job;
  if not found or j.status in ('delivered', 'failed', 'cancelled') then return null; end if;
  select * into a from public.rider_availability where rider_id = j.rider_id;
  select vehicle_type into v_vehicle from public.rider_profiles where id = j.rider_id;
  return jsonb_build_object('status', j.status, 'vehicle_type', v_vehicle,
    'rider', case when a.last_latitude is not null then jsonb_build_object('lat', a.last_latitude, 'lng', a.last_longitude) end,
    'pickup', jsonb_build_object('lat', j.pickup_latitude, 'lng', j.pickup_longitude),
    'dropoff', jsonb_build_object('lat', j.delivery_latitude, 'lng', j.delivery_longitude));
end $$;

create or replace function public.lg_eta_apply(p_job uuid, p_to_pickup_minutes int, p_to_customer_minutes int)
returns jsonb language plpgsql security definer set search_path = public as $$
declare j public.delivery_jobs; o public.orders; v_eta timestamptz;
begin
  perform public.assert_service();
  select * into j from public.delivery_jobs where id = p_job for update;
  if not found or j.status in ('delivered', 'failed', 'cancelled') then return jsonb_build_object('ok', false); end if;
  select * into o from public.orders where id = j.order_id;
  if p_to_customer_minutes is null or p_to_customer_minutes < 0 or p_to_customer_minutes > 240 then return jsonb_build_object('ok', false); end if;
  if j.status in ('assigned', 'rider_to_restaurant') then
    update public.delivery_jobs set eta_pickup_at = now() + make_interval(mins => coalesce(p_to_pickup_minutes, 10)) where id = j.id;
    v_eta := greatest(now() + make_interval(mins => coalesce(p_to_pickup_minutes, 10)), coalesce(o.estimated_ready_at, now())) + make_interval(mins => p_to_customer_minutes + 2);
  elsif j.status = 'arrived_restaurant' then
    v_eta := greatest(now(), coalesce(o.estimated_ready_at, now())) + make_interval(mins => p_to_customer_minutes + 2);
  else
    v_eta := now() + make_interval(mins => p_to_customer_minutes);
  end if;
  update public.delivery_jobs set eta_delivery_min_at = v_eta - make_interval(mins => 2),
         eta_delivery_max_at = v_eta + make_interval(mins => greatest(4, round(p_to_customer_minutes * 0.15)::int)), eta_source = 'routing', eta_updated_at = now()
   where id = j.id;
  perform public.lg_touch(j.id);
  return jsonb_build_object('ok', true);
end $$;


-- Il backend verifica chi può chiedere il ricalcolo ETA (Rider assegnato o Admin)
create or replace function public.lg_can_refresh(p_job uuid, p_user uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_admin_user(p_user) or exists (select 1 from public.delivery_jobs j join public.rider_profiles r on r.id = j.rider_id
                                                 where j.id = p_job and r.user_id = p_user and r.status in ('approved', 'active'));
$$;

-- L'evento "assigned" memorizza l'ETA massima iniziale (per il tasso di puntualità)
create or replace function public.delivery_events_eta_snapshot()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.event_type = 'assigned' then
    new.metadata := new.metadata || jsonb_build_object('eta_max', (
      select coalesce(j.eta_delivery_max_at, now() + make_interval(mins => public.lg_minutes(j.estimated_distance_km, 'scooter') + 30))
        from public.delivery_jobs j where j.id = new.delivery_job_id));
  end if;
  return new;
end $$;
create trigger delivery_events_eta_snapshot before insert on public.delivery_events
  for each row execute function public.delivery_events_eta_snapshot();

-- ────────────────────────────────────────────────────────────────────
--  12. FUNZIONI SOSTITUITE (quote con verifica Rider AsiaFood, tracking eventi)
-- ────────────────────────────────────────────────────────────────────
create or replace function public.order_quote_core(p jsonb, p_user uuid, p_email text default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  v_rest uuid; r public.restaurants; s public.restaurant_order_settings;
  v_type text := p ->> 'order_type';
  v_errors jsonb := '[]'::jsonb;
  v_lines jsonb := '[]'::jsonb;
  e jsonb; a jsonb; v_opt text; idx int := 0;
  it public.menu_items; v public.menu_item_variants; ad public.menu_item_addons; op public.menu_options; g public.menu_option_groups;
  v_menu_ok boolean; v_base numeric; v_unit numeric; v_addons numeric; v_qty int; v_total_qty int := 0;
  v_opts jsonb; v_nvar int; v_line_ok boolean; v_group_counts jsonb;
  v_subtotal numeric := 0; v_delivery numeric := 0; v_service numeric := 0; v_coupon_disc numeric := 0; v_loyalty_disc numeric := 0;
  v_min numeric := 0; v_dist numeric; z public.delivery_zones; v_eta int; v_lat double precision; v_lng double precision;
  v_sched timestamptz; v_prep int; v_ready timestamptz; v_slot timestamptz; v_type_state text;
  v_codes jsonb := '[]'::jsonb; v_code jsonb; v_code_text text; v_max_lines int := public.billing_setting_int('order_max_items', 50);
  v_pay jsonb; v_total numeric; v_disc numeric; v_notes text; v_open text; v_asia text;
begin
  -- Ristorante e configurazione
  if coalesce(p ->> 'restaurant_id', '') !~* '^[0-9a-f-]{36}$' then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('RESTAURANT_NOT_FOUND', 'Ristorante non trovato.')));
  end if;
  v_rest := (p ->> 'restaurant_id')::uuid;
  select * into r from public.restaurants where id = v_rest;
  select * into s from public.restaurant_order_settings where restaurant_id = v_rest;
  if r.id is null or not public.restaurant_is_public(v_rest) then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('RESTAURANT_NOT_FOUND', 'Ristorante non trovato.')));
  end if;
  if not public.billing_setting_bool('orders_enabled', true) or s.id is null or not s.orders_enabled or r.is_permanently_closed then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(public.order_err('ORDERS_DISABLED', 'Questo ristorante non accetta ordini online.')));
  end if;
  if r.is_temporarily_closed then
    v_errors := v_errors || public.order_err('RESTAURANT_CLOSED', 'Il ristorante è chiuso temporaneamente.');
  end if;
  if v_type is null or v_type not in ('takeaway', 'delivery') then
    v_type := case when s.takeaway_enabled then 'takeaway' else 'delivery' end;
  end if;
  v_type_state := public.order_type_open(s, v_type);
  if v_type_state = 'disabled' then
    v_errors := v_errors || public.order_err('TYPE_UNAVAILABLE',
      case when v_type = 'delivery' then 'Questo ristorante non effettua consegne a domicilio.' else 'Questo ristorante non offre il ritiro al locale.' end);
  elsif v_type_state = 'paused' then
    v_errors := v_errors || public.order_err('RESTAURANT_PAUSED',
      case when v_type = 'delivery' then 'Le consegne sono in pausa: riprova tra poco o scegli il ritiro.' else 'Il ristorante ha messo in pausa gli ordini: riprova tra poco.' end);
  end if;

  -- Righe: prezzi SEMPRE dal database
  if jsonb_typeof(p -> 'items') <> 'array' or jsonb_array_length(p -> 'items') = 0 then
    v_errors := v_errors || public.order_err('EMPTY_CART', 'Il carrello è vuoto.');
  elsif jsonb_array_length(p -> 'items') > v_max_lines then
    v_errors := v_errors || public.order_err('TOO_MANY_ITEMS', format('Puoi ordinare al massimo %s prodotti diversi.', v_max_lines));
  else
    for e in select * from jsonb_array_elements(p -> 'items') loop
      v_line_ok := true; v_opts := '[]'::jsonb; v_addons := 0; it := null; v := null;
      v_qty := case when (e ->> 'quantity') ~ '^[0-9]{1,3}$' then (e ->> 'quantity')::int else 0 end;
      v_notes := nullif(left(trim(coalesce(e ->> 'notes', '')), 200), '');
      if coalesce(e ->> 'menu_item_id', '') ~* '^[0-9a-f-]{36}$' then
        select * into it from public.menu_items where id = (e ->> 'menu_item_id')::uuid and restaurant_id = v_rest;
      end if;
      if it.id is null then
        v_errors := v_errors || public.order_err('ITEM_NOT_FOUND', 'Un prodotto nel tuo carrello non esiste più.', jsonb_build_object('index', idx));
        v_lines := v_lines || jsonb_build_object('index', idx, 'menu_item_id', e ->> 'menu_item_id', 'available', false, 'name', null);
        idx := idx + 1; continue;
      end if;
      select exists (select 1 from public.menu_categories c join public.menus m on m.id = c.menu_id
                      where c.id = it.menu_category_id and c.is_active and public.menu_is_public(m.id) and m.menu_type <> 'all_you_can_eat')
        into v_menu_ok;
      if v_qty < 1 or v_qty > 20 then
        v_errors := v_errors || public.order_err('QUANTITY_INVALID', 'Quantità non valida (1–20).', jsonb_build_object('index', idx));
        v_line_ok := false; v_qty := greatest(least(v_qty, 20), 1);
      end if;
      if not v_menu_ok or not public.menu_item_in_stock(it) then
        v_errors := v_errors || public.order_err('ITEM_UNAVAILABLE', 'Un prodotto nel tuo carrello non è più disponibile.', jsonb_build_object('index', idx, 'name', it.name));
        v_line_ok := false;
      end if;
      -- Variante: obbligatoria se il piatto ne ha di disponibili
      select count(*) into v_nvar from public.menu_item_variants where menu_item_id = it.id and is_available;
      if coalesce(e ->> 'variant_id', '') ~* '^[0-9a-f-]{36}$' then
        select * into v from public.menu_item_variants where id = (e ->> 'variant_id')::uuid and menu_item_id = it.id;
        if v.id is null or not v.is_available then
          v_errors := v_errors || public.order_err('OPTION_INVALID', format('La variante scelta per «%s» non è più disponibile.', it.name), jsonb_build_object('index', idx));
          v_line_ok := false;
        end if;
      elsif v_nvar > 0 then
        v_errors := v_errors || public.order_err('OPTIONS_REQUIRED', format('Scegli una variante per «%s».', it.name), jsonb_build_object('index', idx));
        v_line_ok := false;
      end if;
      v_base := coalesce(v.price, case when it.discount_price is not null and it.price is not null and it.discount_price < it.price then it.discount_price else it.price end);
      if v_base is null then
        v_errors := v_errors || public.order_err('PRICE_MISSING', format('«%s» non è ordinabile online.', it.name), jsonb_build_object('index', idx));
        v_line_ok := false; v_base := 0;
      end if;
      -- Extra
      if jsonb_typeof(e -> 'addons') = 'array' then
        if jsonb_array_length(e -> 'addons') > 15 then
          v_errors := v_errors || public.order_err('OPTION_INVALID', 'Troppi extra.', jsonb_build_object('index', idx)); v_line_ok := false;
        else
          for a in select * from jsonb_array_elements(e -> 'addons') loop
            ad := null;
            if coalesce(a ->> 'id', '') ~* '^[0-9a-f-]{36}$' then
              select * into ad from public.menu_item_addons where id = (a ->> 'id')::uuid and menu_item_id = it.id;
            end if;
            if ad.id is null or not ad.is_available then
              v_errors := v_errors || public.order_err('OPTION_INVALID', format('Un extra di «%s» non è più disponibile.', it.name), jsonb_build_object('index', idx));
              v_line_ok := false; continue;
            end if;
            v_addons := v_addons + coalesce(ad.price, 0) * greatest(least(coalesce((a ->> 'quantity')::int, 1), 5), 1);
            v_opts := v_opts || jsonb_build_object('kind', 'addon', 'id', ad.id, 'group', 'Extra', 'name', ad.name,
              'price', coalesce(ad.price, 0), 'quantity', greatest(least(coalesce((a ->> 'quantity')::int, 1), 5), 1));
          end loop;
        end if;
      end if;
      -- Scelte strutturate (gruppi di opzioni)
      v_group_counts := '{}'::jsonb;
      if jsonb_typeof(e -> 'options') = 'array' then
        for v_opt in select * from jsonb_array_elements_text(e -> 'options') loop
          op := null; g := null;
          if v_opt ~* '^[0-9a-f-]{36}$' then
            select o.* into op from public.menu_options o join public.menu_option_groups gg on gg.id = o.option_group_id
             where o.id = v_opt::uuid and gg.menu_item_id = it.id and gg.is_active;
          end if;
          if op.id is null or not op.is_available then
            v_errors := v_errors || public.order_err('OPTION_INVALID', format('Una scelta per «%s» non è più disponibile.', it.name), jsonb_build_object('index', idx));
            v_line_ok := false; continue;
          end if;
          select * into g from public.menu_option_groups where id = op.option_group_id;
          v_group_counts := jsonb_set(v_group_counts, array[g.id::text], to_jsonb(coalesce((v_group_counts ->> g.id::text)::int, 0) + 1));
          v_addons := v_addons + op.price;
          v_opts := v_opts || jsonb_build_object('kind', 'option', 'id', op.id, 'group', g.name, 'name', op.name, 'price', op.price, 'quantity', 1);
        end loop;
      end if;
      for g in select * from public.menu_option_groups where menu_item_id = it.id and is_active loop
        if coalesce((v_group_counts ->> g.id::text)::int, 0) < greatest(g.min_select, case when g.required then 1 else 0 end)
           or coalesce((v_group_counts ->> g.id::text)::int, 0) > g.max_select then
          v_errors := v_errors || public.order_err('OPTIONS_REQUIRED', format('Completa la scelta «%s» per «%s».', g.name, it.name), jsonb_build_object('index', idx));
          v_line_ok := false;
        end if;
      end loop;
      v_unit := round(v_base + v_addons, 2);
      v_total_qty := v_total_qty + v_qty;
      v_subtotal := v_subtotal + round(v_unit * v_qty, 2);
      v_lines := v_lines || jsonb_build_object('index', idx, 'menu_item_id', it.id, 'name', it.name, 'variant_id', v.id, 'variant_name', v.name,
        'base_price', round(v_base, 2), 'addons_total', round(v_addons, 2), 'unit_price', v_unit, 'quantity', v_qty,
        'line_total', round(v_unit * v_qty, 2), 'options', v_opts, 'notes', v_notes, 'available', v_line_ok);
      idx := idx + 1;
    end loop;
    if v_total_qty > 100 then v_errors := v_errors || public.order_err('TOO_MANY_ITEMS', 'Quantità totale troppo alta per un ordine online.'); end if;
  end if;

  -- Orario: il prima possibile oppure programmato
  v_prep := public.order_prep_minutes(s);
  if nullif(p ->> 'scheduled_for', '') is not null then
    begin
      v_sched := (p ->> 'scheduled_for')::timestamptz;
    exception when others then
      v_errors := v_errors || public.order_err('SLOT_INVALID', 'Orario non valido.');
    end;
  end if;
  if v_sched is not null then
    if not s.allow_scheduled_orders then
      v_errors := v_errors || public.order_err('SLOT_INVALID', 'Questo ristorante non accetta ordini programmati.');
    elsif v_sched < now() + make_interval(mins => v_prep + case when v_type = 'delivery' then s.delivery_estimated_minutes else 0 end) - interval '2 minutes' then
      v_errors := v_errors || public.order_err('SLOT_INVALID', 'L''orario scelto è troppo vicino: scegline uno successivo.');
    elsif v_sched > now() + make_interval(days => s.max_advance_days + 1) then
      v_errors := v_errors || public.order_err('SLOT_INVALID', format('Puoi programmare al massimo %s giorni prima.', s.max_advance_days));
    elsif public.restaurant_open_status(v_rest, v_sched - make_interval(mins => case when v_type = 'delivery' then s.delivery_estimated_minutes else 0 end)) <> 'open' then
      v_errors := v_errors || public.order_err('SLOT_INVALID', 'Il ristorante è chiuso all''orario scelto.');
    end if;
    v_ready := v_sched - make_interval(mins => case when v_type = 'delivery' then s.delivery_estimated_minutes else 0 end);
  else
    v_open := public.restaurant_open_status(v_rest, now());
    v_ready := now() + make_interval(mins => v_prep);
    if v_open <> 'open' or public.restaurant_open_status(v_rest, v_ready) <> 'open' then
      v_errors := v_errors || public.order_err('RESTAURANT_CLOSED',
        case when v_open = 'unknown' then 'Orari del ristorante non disponibili: non è possibile ordinare ora.'
             when s.allow_scheduled_orders then 'Il ristorante è chiuso in questo momento: programma l''ordine per più tardi.'
             else 'Il ristorante è chiuso in questo momento.' end,
        jsonb_build_object('next_slot', case when s.allow_scheduled_orders then public.order_next_slot(v_rest, v_type) end));
    end if;
  end if;
  v_slot := public.order_slot_start(coalesce(v_ready, now()), s.slot_interval_minutes);
  if s.max_orders_per_slot is not null and public.order_slot_count(v_rest, v_slot) >= s.max_orders_per_slot then
    v_errors := v_errors || public.order_err('SLOT_FULL', 'La fascia oraria scelta è al completo: scegli un altro orario.',
      jsonb_build_object('next_slot', case when s.allow_scheduled_orders then public.order_next_slot(v_rest, v_type) end));
  end if;

  -- Consegna: distanza calcolata qui (mai dal modello AI né dal browser)
  if v_type = 'delivery' then
    v_eta := s.delivery_estimated_minutes;
    begin
      v_lat := nullif(p #>> '{address,latitude}', '')::double precision;
      v_lng := nullif(p #>> '{address,longitude}', '')::double precision;
    exception when others then v_lat := null; v_lng := null;
    end;
    if v_lat is null or v_lng is null or v_lat not between -90 and 90 or v_lng not between -180 and 180 then
      v_errors := v_errors || public.order_err('ADDRESS_REQUIRED', 'Inserisci un indirizzo di consegna verificato.');
    elsif r.latitude is null or r.longitude is null then
      v_errors := v_errors || public.order_err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.');
    else
      v_dist := round(public.geo_distance_km(r.latitude, r.longitude, v_lat, v_lng)::numeric, 2);
      -- Fase 9: consegna con Rider AsiaFood → zona servita, servizio attivo, ristorante abilitato
      if s.delivery_provider_type = 'asiafood' then
        v_asia := public.lg_service_check(v_rest, v_lat, v_lng);
        if v_asia is not null then
          v_errors := v_errors || public.order_err('OUTSIDE_AREA', v_asia, jsonb_build_object('distance_km', v_dist, 'provider', 'asiafood'));
        end if;
      end if;
      if s.delivery_radius_km is not null and v_dist > s.delivery_radius_km then
        v_errors := v_errors || public.order_err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.', jsonb_build_object('distance_km', v_dist));
      elsif s.delivery_fee_type in ('distance', 'zone') then
        select * into z from public.delivery_zones
         where restaurant_id = v_rest and is_active and (
           (zone_type = 'radius' and v_dist <= radius_km) or
           (zone_type = 'distance' and v_dist >= coalesce(min_distance_km, 0) and v_dist < max_distance_km))
         order by coalesce(max_distance_km, radius_km) asc limit 1;
        if z.id is null then
          v_errors := v_errors || public.order_err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.', jsonb_build_object('distance_km', v_dist));
        else
          v_delivery := z.delivery_fee; v_eta := z.estimated_delivery_minutes;
          v_min := greatest(v_min, z.minimum_order);
        end if;
      elsif s.delivery_radius_km is null then
        v_errors := v_errors || public.order_err('OUTSIDE_AREA', 'Questo ristorante non consegna ancora a questo indirizzo.');
      else
        v_delivery := case when s.delivery_fee_type = 'free' then 0 else s.delivery_fee end;
      end if;
      if s.free_delivery_threshold is not null and v_subtotal >= s.free_delivery_threshold then v_delivery := 0; end if;
    end if;
    v_min := greatest(v_min, coalesce(s.delivery_minimum_order, s.minimum_order_amount, 0));
  else
    v_min := greatest(v_min, coalesce(s.takeaway_minimum_order, s.minimum_order_amount, 0));
  end if;
  if v_subtotal > 0 and v_subtotal < v_min then
    v_errors := v_errors || public.order_err('MINIMUM_NOT_REACHED',
      format('L''ordine minimo è %s €: aggiungi ancora %s €.', to_char(v_min, 'FM999990.00'), to_char(v_min - v_subtotal, 'FM999990.00')),
      jsonb_build_object('minimum', v_min, 'missing', round(v_min - v_subtotal, 2)));
  end if;

  -- Codici sconto (coupon del ristorante o codice personale da premio AsiaPoints)
  foreach v_code_text in array array[p ->> 'coupon_code', p ->> 'reward_code'] loop
    if nullif(trim(coalesce(v_code_text, '')), '') is not null then
      v_code := public.order_validate_code(v_rest, v_code_text, p_user, p_email, v_subtotal, coalesce(v_sched, now()));
      v_codes := v_codes || v_code;
      if not (v_code ->> 'ok')::boolean then
        v_errors := v_errors || public.order_err(v_code ->> 'error', v_code ->> 'message', jsonb_build_object('field', 'coupon'));
      end if;
    end if;
  end loop;
  if (select count(*) from jsonb_array_elements(v_codes) x where (x ->> 'ok')::boolean) > 1 then
    if not public.billing_setting_bool('allow_coupon_stacking', false) then
      v_errors := v_errors || public.order_err('COUPON_NOT_STACKABLE', 'I codici sconto non sono cumulabili: usane uno solo.', jsonb_build_object('field', 'coupon'));
    elsif (select count(distinct x ->> 'coupon_id') from jsonb_array_elements(v_codes) x where (x ->> 'ok')::boolean) < 2 then
      v_errors := v_errors || public.order_err('COUPON_NOT_STACKABLE', 'Lo stesso coupon non può essere usato due volte.', jsonb_build_object('field', 'coupon'));
    end if;
  end if;
  for v_code in select * from jsonb_array_elements(v_codes) loop
    if (v_code ->> 'ok')::boolean then
      v_disc := least((v_code ->> 'discount')::numeric, v_subtotal - v_coupon_disc - v_loyalty_disc);
      if (v_code ->> 'is_reward')::boolean then v_loyalty_disc := v_loyalty_disc + v_disc; else v_coupon_disc := v_coupon_disc + v_disc; end if;
    end if;
  end loop;

  -- Costo di servizio (piattaforma), sempre mostrato prima del pagamento
  if public.billing_setting_bool('service_fee_enabled', false) and s.service_fee_enabled and v_subtotal > 0 then
    v_service := public.billing_setting_num('service_fee_amount', 0.99);
  end if;

  v_total := round(v_subtotal - v_coupon_disc - v_loyalty_disc + v_delivery + v_service, 2);
  if v_subtotal > 0 and v_total < 0.5 then
    v_errors := v_errors || public.order_err('TOTAL_TOO_LOW', 'L''importo minimo per il pagamento online è 0,50 €.');
  end if;
  v_pay := public.order_payment_setup(v_rest);
  if not (v_pay ->> 'ready')::boolean then
    v_errors := v_errors || public.order_err('PAYMENTS_NOT_READY', 'Questo ristorante non ha ancora attivato i pagamenti online.');
  end if;

  return jsonb_build_object(
    'ok', jsonb_array_length(v_errors) = 0,
    'errors', v_errors,
    'restaurant', jsonb_build_object('id', r.id, 'name', r.name, 'slug', r.slug),
    'order_type', v_type,
    'lines', v_lines,
    'subtotal', round(v_subtotal, 2),
    'coupon_discount', round(v_coupon_disc, 2),
    'loyalty_discount', round(v_loyalty_disc, 2),
    'discount_total', round(v_coupon_disc + v_loyalty_disc, 2),
    'delivery_fee', round(v_delivery, 2),
    'service_fee', round(v_service, 2),
    'tax_total', null,
    'total', greatest(v_total, 0),
    'currency', 'EUR',
    'minimum_order', v_min,
    'codes', v_codes,
    'delivery', case when v_type = 'delivery' then jsonb_build_object('distance_km', v_dist, 'zone_id', z.id, 'zone_name', z.name, 'eta_minutes', v_eta) end,
    'scheduled_for', v_sched,
    'estimated_ready_at', v_ready,
    'estimated_delivery_at', case when v_type = 'delivery' then v_ready + make_interval(mins => coalesce(v_eta, s.delivery_estimated_minutes)) end,
    'slot_at', v_slot,
    'preparation_minutes', v_prep,
    'payment_mode', v_pay ->> 'mode',
    'payments_ready', (v_pay ->> 'ready')::boolean);
end $$;

create or replace function public.track_event(
  p_restaurant_id uuid,
  p_event_type public.analytics_event_type,
  p_session_id text default null,
  p_source text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_type text := case p_event_type::text
    when 'view' then 'restaurant_view' when 'click_phone' then 'phone_click' when 'click_whatsapp' then 'whatsapp_click'
    when 'click_directions' then 'directions_click' when 'click_menu' then 'menu_view' when 'click_reservation' then 'reservation_start'
    when 'click_website' then 'website_click' when 'click_social' then 'social_click' when 'coupon_reveal' then 'offer_view'
    else p_event_type::text end;
  v_meta jsonb := coalesce(p_metadata, '{}'::jsonb);
  k text;
begin
  -- Conversioni, impression sponsorizzate ed eventi di pagamento/ordine: solo lato server
  if v_type in ('reservation_completed', 'coupon_claim', 'coupon_redeem', 'sponsored_impression', 'sponsored_click',
                'payment_success', 'payment_failed', 'order_created', 'order_accepted', 'order_completed', 'order_cancelled', 'abandoned_cart',
                'rider_online', 'rider_offline', 'delivery_offer_sent', 'delivery_offer_accepted', 'delivery_offer_rejected', 'delivery_assignment_failed',
                'rider_arrived_restaurant', 'order_picked_up', 'rider_arrived_customer', 'delivery_completed', 'delivery_failed') then return; end if;
  if p_restaurant_id is null then
    if v_type <> 'map_view' and v_type not like 'ai\_%' then return; end if;
  elsif not exists (select 1 from public.restaurants where id = p_restaurant_id and is_active) then
    return;
  end if;
  if jsonb_typeof(v_meta) <> 'object' then v_meta := '{}'::jsonb; end if;
  for k in select jsonb_object_keys(v_meta) loop
    if k ~* '(lat|lng|lon|coord|position|location|address|email|phone|name|message|text|query)' then v_meta := v_meta - k; end if;
  end loop;
  if pg_column_size(v_meta) > 2000 then v_meta := '{}'::jsonb; end if;
  insert into public.analytics_events (restaurant_id, event_type, user_id, session_id, source, metadata)
  values (p_restaurant_id, v_type::public.analytics_event_type, null, left(p_session_id, 64), left(p_source, 40), v_meta);
end $$;

-- ────────────────────────────────────────────────────────────────────
--  13. STORAGE PRIVATO: documenti Rider e prove di consegna
-- ────────────────────────────────────────────────────────────────────
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('rider-documents', 'rider-documents', false, 10485760, array['application/pdf', 'image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = false;
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('delivery-proofs', 'delivery-proofs', false, 5242880, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = false;

create policy "rider_documents_insert_own" on storage.objects for insert to authenticated with check (
  bucket_id = 'rider-documents' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "rider_documents_read_own_or_admin" on storage.objects for select to authenticated using (
  bucket_id = 'rider-documents' and ((storage.foldername(name))[1] = (select auth.uid())::text or public.is_admin()));
create policy "delivery_proofs_insert_rider" on storage.objects for insert to authenticated with check (
  bucket_id = 'delivery-proofs' and (storage.foldername(name))[1] = (select auth.uid())::text and public.is_rider());
create policy "delivery_proofs_read_own_or_admin" on storage.objects for select to authenticated using (
  bucket_id = 'delivery-proofs' and ((storage.foldername(name))[1] = (select auth.uid())::text or public.is_admin()));

-- ────────────────────────────────────────────────────────────────────
--  14. RLS
-- ────────────────────────────────────────────────────────────────────
alter table public.delivery_service_zones  enable row level security;
alter table public.rider_profiles          enable row level security;
alter table public.rider_documents         enable row level security;
alter table public.rider_availability      enable row level security;
alter table public.rider_locations         enable row level security;
alter table public.delivery_jobs           enable row level security;
alter table public.delivery_assignments    enable row level security;
alter table public.rider_compensation_rules enable row level security;
alter table public.rider_earnings          enable row level security;
alter table public.rider_payout_accounts   enable row level security;
alter table public.delivery_ratings        enable row level security;
alter table public.delivery_issues         enable row level security;
alter table public.delivery_messages       enable row level security;
alter table public.delivery_events         enable row level security;
alter table public.delivery_realtime       enable row level security;
alter table public.logistics_alerts        enable row level security;

create policy "service_zones_read" on public.delivery_service_zones for select using (is_active or public.is_admin());
create policy "service_zones_admin" on public.delivery_service_zones for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "rider_profiles_own_or_admin" on public.rider_profiles for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
create policy "rider_documents_own_or_admin" on public.rider_documents for select to authenticated using (
  public.is_admin() or rider_id in (select id from public.rider_profiles where user_id = (select auth.uid())));
create policy "rider_availability_own_or_admin" on public.rider_availability for select to authenticated using (
  public.is_admin() or rider_id in (select id from public.rider_profiles where user_id = (select auth.uid())));
-- Storico GPS: solo il Rider stesso (le proprie) e l'Admin. Nessun altro, mai pubblico.
create policy "rider_locations_own_or_admin" on public.rider_locations for select to authenticated using (
  public.is_admin() or rider_id in (select id from public.rider_profiles where user_id = (select auth.uid())));
-- Job: lettura diretta solo Admin (Rider/cliente/ristorante passano da funzioni che filtrano i campi)
create policy "delivery_jobs_admin" on public.delivery_jobs for select to authenticated using (public.is_admin());
create policy "delivery_assignments_own_or_admin" on public.delivery_assignments for select to authenticated using (
  public.is_admin() or rider_id in (select id from public.rider_profiles where user_id = (select auth.uid())));
create policy "compensation_rules_read" on public.rider_compensation_rules for select to authenticated using (public.is_admin() or public.is_rider());
create policy "compensation_rules_admin" on public.rider_compensation_rules for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "rider_earnings_own_or_admin" on public.rider_earnings for select to authenticated using (
  public.is_admin() or rider_id in (select id from public.rider_profiles where user_id = (select auth.uid())));
create policy "rider_payout_accounts_own_or_admin" on public.rider_payout_accounts for select to authenticated using (
  public.is_admin() or rider_id in (select id from public.rider_profiles where user_id = (select auth.uid())));
create policy "delivery_ratings_own_or_admin" on public.delivery_ratings for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
create policy "delivery_issues_own_or_admin" on public.delivery_issues for select to authenticated using (reported_by_id = (select auth.uid()) or public.is_admin());
create policy "delivery_messages_admin" on public.delivery_messages for select to authenticated using (public.is_admin());
create policy "delivery_events_admin" on public.delivery_events for select to authenticated using (public.is_admin());
create policy "delivery_realtime_participants" on public.delivery_realtime for select to authenticated using (
  user_id = (select auth.uid()) or rider_user_id = (select auth.uid()) or public.can_view_orders(restaurant_id) or public.is_admin());
create policy "logistics_alerts_admin" on public.logistics_alerts for select to authenticated using (public.is_admin());
create policy "logistics_alerts_admin_update" on public.logistics_alerts for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Privilegi: nessuna scrittura diretta dal browser (tutto passa dalle funzioni controllate)
revoke all on public.delivery_service_zones, public.rider_profiles, public.rider_documents, public.rider_availability, public.rider_locations,
  public.delivery_jobs, public.delivery_assignments, public.rider_compensation_rules, public.rider_earnings, public.rider_payout_accounts,
  public.delivery_ratings, public.delivery_issues, public.delivery_messages, public.delivery_events, public.delivery_realtime, public.logistics_alerts
  from anon, authenticated;
grant select on public.delivery_service_zones to anon, authenticated;
grant select on public.rider_profiles, public.rider_documents, public.rider_availability, public.rider_locations, public.delivery_jobs,
  public.delivery_assignments, public.rider_compensation_rules, public.rider_earnings, public.rider_payout_accounts, public.delivery_ratings,
  public.delivery_issues, public.delivery_messages, public.delivery_events, public.delivery_realtime, public.logistics_alerts to authenticated;
grant insert, update, delete on public.delivery_service_zones, public.rider_compensation_rules to authenticated;
grant update on public.logistics_alerts to authenticated;

-- Funzioni interne: solo backend/service (mai dal browser)
do $$
declare f text;
begin
  foreach f in array array[
    'lg_rider_of(uuid)', 'lg_log(uuid, text, text, uuid, jsonb)', 'lg_touch(uuid)', 'lg_alert(text, uuid, uuid, text, text)',
    'lg_notify_rider(uuid, text, text, text, text, text)', 'lg_notify_customer(uuid, text, text, text)', 'lg_earning_quote(uuid)', 'lg_eta(uuid)',
    'lg_set_status(uuid, text, text, uuid, jsonb)', 'lg_release_capacity(uuid)', 'lg_sync_order(uuid, text, uuid)', 'lg_service_check(uuid, double precision, double precision)',
    'lg_job_create(uuid)', 'lg_candidates(uuid, numeric)', 'lg_dispatch(uuid, boolean)', 'lg_expire_offers()', 'lg_expire_rider_offers(uuid, text)',
    'lg_eta_context(uuid)', 'lg_eta_apply(uuid, int, int)', 'lg_can_refresh(uuid, uuid)', 'lg_radii()', 'lg_assert_admin()'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;

grant execute on function public.is_rider(uuid) to authenticated;
revoke all on function public.rider_apply(jsonb), public.rider_document_add(text, text, date), public.rider_set_online(boolean, boolean, boolean),
  public.rider_location(jsonb), public.rider_offer_respond(uuid, boolean, text), public.rider_job_action(uuid, text, jsonb), public.rider_job(uuid),
  public.rider_home(), public.rider_earnings_summary(), public.delivery_rate(text, int, text), public.restaurant_deliveries(uuid),
  public.admin_riders(jsonb), public.admin_rider_detail(uuid), public.admin_rider_action(uuid, text, text), public.admin_document_review(uuid, text, text),
  public.admin_dispatch_board(), public.admin_assign_job(uuid, uuid), public.admin_job_action(uuid, text, jsonb), public.admin_job_detail(uuid),
  public.admin_earning_action(uuid, text, numeric, text), public.admin_earning_create(uuid, numeric, text), public.admin_restaurant_logistics(uuid, boolean),
  public.logistics_stats(int), public.logistics_tick(timestamptz) from public, anon;
grant execute on function public.rider_apply(jsonb), public.rider_document_add(text, text, date), public.rider_set_online(boolean, boolean, boolean),
  public.rider_location(jsonb), public.rider_offer_respond(uuid, boolean, text), public.rider_job_action(uuid, text, jsonb), public.rider_job(uuid),
  public.rider_home(), public.rider_earnings_summary(), public.delivery_rate(text, int, text), public.restaurant_deliveries(uuid),
  public.admin_riders(jsonb), public.admin_rider_detail(uuid), public.admin_rider_action(uuid, text, text), public.admin_document_review(uuid, text, text),
  public.admin_dispatch_board(), public.admin_assign_job(uuid, uuid), public.admin_job_action(uuid, text, jsonb), public.admin_job_detail(uuid),
  public.admin_earning_action(uuid, text, numeric, text), public.admin_earning_create(uuid, numeric, text), public.admin_restaurant_logistics(uuid, boolean),
  public.logistics_stats(int), public.logistics_tick(timestamptz) to authenticated, service_role;
-- Tracking ordine: anche ospiti (con token)
grant execute on function public.order_delivery(text, text) to anon, authenticated, service_role;

-- Realtime (solo il canale leggero, senza coordinate)
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    alter publication supabase_realtime add table public.delivery_realtime;
  end if;
end $$;
