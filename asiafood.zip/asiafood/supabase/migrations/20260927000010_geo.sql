-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0010 · Fase 3: geolocalizzazione e mappa
--  Scelta: latitude/longitude (double precision, ~1 cm di precisione)
--  + indice (lat, lng) e prefiltro a bounding box. PostGIS non serve alla
--  scala attuale; la firma delle RPC resta la stessa se in futuro si
--  migrerà a geography(Point, 4326) con indice GIST.
-- ════════════════════════════════════════════════════════════════════

-- Coordinate: entrambe o nessuna (NOT VALID: non blocca eventuali dati storici, vale per i nuovi)
alter table public.restaurants
  add constraint restaurants_coords_pair check ((latitude is null) = (longitude is null)) not valid;

-- Indice per le query per area su tutti i locali (anche bozze, per l'Admin)
create index if not exists restaurants_lat_lng_all_idx on public.restaurants(latitude, longitude) where latitude is not null;

-- Distanza Haversine in km (immutabile, riusabile da trigger e RPC)
create or replace function public.geo_distance_km(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision)
returns double precision language sql immutable parallel safe as $$
  select 6371 * 2 * asin(sqrt(least(1,
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2)
  )));
$$;

-- nearby_restaurants(lat, lng, radius_km): prefiltro bounding box (usa l'indice), poi distanza reale.
-- security invoker: rispetta le RLS (solo locali pubblicati, demo solo se visibili).
-- Non salva nulla: le coordinate dell'utente non vengono memorizzate.
create or replace function public.nearby_restaurants(
  p_lat double precision,
  p_lng double precision,
  p_radius_km double precision default 10,
  p_limit int default 200
)
returns table (restaurant_id uuid, distance_km double precision)
language sql stable security invoker set search_path = public as $$
  select id, d from (
    select r.id, public.geo_distance_km(p_lat, p_lng, r.latitude, r.longitude) as d
    from public.restaurants r
    where r.is_active and not r.is_permanently_closed and r.latitude is not null
      and r.latitude  between p_lat - p_radius_km / 111.0 and p_lat + p_radius_km / 111.0
      and r.longitude between p_lng - p_radius_km / (111.0 * greatest(cos(radians(p_lat)), 0.01))
                          and p_lng + p_radius_km / (111.0 * greatest(cos(radians(p_lat)), 0.01))
  ) x
  where d <= least(p_radius_km, 200)
  order by d
  limit least(greatest(p_limit, 1), 500);
$$;
grant execute on function public.nearby_restaurants(double precision, double precision, double precision, int) to anon, authenticated;
grant execute on function public.geo_distance_km(double precision, double precision, double precision, double precision) to anon, authenticated;

-- ════════════════════════════════════════════════════════════════════
--  EVENTI APP (mappa, geolocalizzazione) — senza coordinate né utente
-- ════════════════════════════════════════════════════════════════════
create table public.app_events (
  id            bigint generated always as identity primary key,
  event_type    text not null check (event_type in (
    'map_open', 'location_permission_requested', 'location_permission_granted', 'location_permission_denied',
    'restaurant_marker_click', 'directions_click', 'near_me_search', 'map_area_search'
  )),
  restaurant_id uuid references public.restaurants(id) on delete set null,
  session_id    text,
  source        text,
  metadata      jsonb not null default '{}'::jsonb,
  created_at    timestamptz not null default now()
);
create index app_events_type_created_idx on public.app_events(event_type, created_at desc);
alter table public.app_events enable row level security;
create policy "app_events_admin_read" on public.app_events for select to authenticated using (public.is_admin());
grant select on public.app_events to authenticated;

create or replace function public.track_app_event(
  p_event_type text,
  p_restaurant_id uuid default null,
  p_session_id text default null,
  p_source text default null,
  p_metadata jsonb default '{}'::jsonb
) returns void language plpgsql security definer set search_path = public as $$
declare
  v_meta jsonb := coalesce(p_metadata, '{}'::jsonb);
  k text;
begin
  if jsonb_typeof(v_meta) <> 'object' then v_meta := '{}'::jsonb; end if;
  -- Privacy: mai coordinate nel log, anche se inviate per errore
  for k in select jsonb_object_keys(v_meta) loop
    if k ~* '(lat|lng|lon|coord|position|location|address)' then v_meta := v_meta - k; end if;
  end loop;
  if pg_column_size(v_meta) > 2000 then v_meta := '{}'::jsonb; end if;
  insert into public.app_events (event_type, restaurant_id, session_id, source, metadata)
  values (p_event_type, p_restaurant_id, left(p_session_id, 64), left(p_source, 40), v_meta);
exception when check_violation or foreign_key_violation then
  return; -- evento non valido: ignorato, l'analytics non deve mai rompere la UI
end $$;
grant execute on function public.track_app_event(text, uuid, text, text, jsonb) to anon, authenticated;

-- ════════════════════════════════════════════════════════════════════
--  CORREZIONI POSIZIONE proposte dal ristoratore (approvate dall'Admin)
-- ════════════════════════════════════════════════════════════════════
create type public.change_request_status as enum ('pending', 'approved', 'rejected');

create table public.restaurant_change_requests (
  id            uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id       uuid not null references public.profiles(id) on delete cascade,
  kind          text not null default 'location' check (kind in ('location')),
  -- { address, postal_code, latitude, longitude }
  payload       jsonb not null check (jsonb_typeof(payload) = 'object'),
  note          text check (note is null or length(note) <= 1000),
  status        public.change_request_status not null default 'pending',
  admin_notes   text,
  reviewed_by   uuid references public.profiles(id) on delete set null,
  reviewed_at   timestamptz,
  created_at    timestamptz not null default now()
);
create index restaurant_change_requests_status_idx on public.restaurant_change_requests(status, created_at desc);
create index restaurant_change_requests_restaurant_idx on public.restaurant_change_requests(restaurant_id);
alter table public.restaurant_change_requests enable row level security;

create policy "change_requests_insert_member" on public.restaurant_change_requests for insert to authenticated with check (
  user_id = (select auth.uid()) and status = 'pending' and admin_notes is null and reviewed_by is null
  and public.owns_restaurant(restaurant_id)
);
create policy "change_requests_read" on public.restaurant_change_requests for select to authenticated using (
  user_id = (select auth.uid()) or public.can_manage_restaurant(restaurant_id)
);
create policy "change_requests_admin_update" on public.restaurant_change_requests for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy "change_requests_admin_delete" on public.restaurant_change_requests for delete to authenticated
  using (public.is_admin());
grant select, insert on public.restaurant_change_requests to authenticated;
grant update, delete on public.restaurant_change_requests to authenticated;

create or replace function public.review_change_request(p_id uuid, p_approve boolean, p_notes text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  v public.restaurant_change_requests;
  v_lat double precision;
  v_lng double precision;
begin
  if not public.is_admin() then raise exception 'Non autorizzato' using errcode = '42501'; end if;
  select * into v from public.restaurant_change_requests where id = p_id for update;
  if not found or v.status <> 'pending' then raise exception 'Richiesta non trovata o già gestita'; end if;
  if p_approve then
    v_lat := nullif(v.payload->>'latitude', '')::double precision;
    v_lng := nullif(v.payload->>'longitude', '')::double precision;
    if (v_lat is null) <> (v_lng is null) or (v_lat is not null and (v_lat not between -90 and 90 or v_lng not between -180 and 180)) then
      raise exception 'Coordinate non valide';
    end if;
    update public.restaurants set
      address     = case when v.payload ? 'address' then nullif(v.payload->>'address', '') else address end,
      postal_code = case when v.payload ? 'postal_code' then nullif(v.payload->>'postal_code', '') else postal_code end,
      latitude    = case when v.payload ? 'latitude' then v_lat else latitude end,
      longitude   = case when v.payload ? 'longitude' then v_lng else longitude end
    where id = v.restaurant_id;
  end if;
  update public.restaurant_change_requests
     set status = case when p_approve then 'approved'::public.change_request_status else 'rejected'::public.change_request_status end,
         admin_notes = p_notes, reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_id;
end $$;
revoke all on function public.review_change_request(uuid, boolean, text) from public, anon;
grant execute on function public.review_change_request(uuid, boolean, text) to authenticated;

-- ════════════════════════════════════════════════════════════════════
--  Protezione campi: il titolare può solo rifinire la posizione (≤ 300 m).
--  Indirizzo, CAP e spostamenti maggiori passano da una richiesta all'Admin.
-- ════════════════════════════════════════════════════════════════════
create or replace function public.protect_restaurant_admin_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    new.owner_id              := old.owner_id;
    new.is_verified           := old.is_verified;
    new.is_active             := old.is_active;
    new.is_featured           := old.is_featured;
    new.is_sponsored          := old.is_sponsored;
    new.is_demo               := old.is_demo;
    new.subscription_plan     := old.subscription_plan;
    new.popularity_score      := old.popularity_score;
    new.slug                  := old.slug;
    new.city_id               := old.city_id;
    new.data_status           := old.data_status;
    new.source_name           := old.source_name;
    new.source_url            := old.source_url;
    new.external_id           := old.external_id;
    new.google_place_id       := old.google_place_id;
    new.last_verified_at      := old.last_verified_at;
    new.claimed_at            := old.claimed_at;
    new.claimed_by            := old.claimed_by;
    new.verification_notes    := old.verification_notes;
    new.is_permanently_closed := old.is_permanently_closed;
    -- Fase 3: indirizzo e posizione
    new.address               := old.address;
    new.postal_code           := old.postal_code;
    if new.latitude is distinct from old.latitude or new.longitude is distinct from old.longitude then
      if old.latitude is null or new.latitude is null or new.longitude is null
         or public.geo_distance_km(old.latitude, old.longitude, new.latitude, new.longitude) > 0.3 then
        new.latitude  := old.latitude;
        new.longitude := old.longitude;
      end if;
    end if;
  end if;
  return new;
end $$;

-- ════════════════════════════════════════════════════════════════════
--  KPI Admin: aggiunge coordinate mancanti, correzioni e uso mappa
-- ════════════════════════════════════════════════════════════════════
create or replace function public.admin_dashboard_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb;
begin
  if not public.is_admin() then
    raise exception 'Non autorizzato' using errcode = '42501';
  end if;
  select jsonb_build_object(
    'restaurants_total',      (select count(*) from public.restaurants),
    'restaurants_active',     (select count(*) from public.restaurants where is_active),
    'restaurants_draft',      (select count(*) from public.restaurants where not is_active),
    'restaurants_claimed',    (select count(*) from public.restaurants where owner_id is not null),
    'restaurants_demo',       (select count(*) from public.restaurants where is_demo),
    'restaurants_real',       (select count(*) from public.restaurants where not is_demo),
    'restaurants_verified',   (select count(*) from public.restaurants where data_status in ('verified', 'claimed')),
    'restaurants_unverified', (select count(*) from public.restaurants where data_status in ('unverified', 'outdated')),
    'restaurants_no_coords',  (select count(*) from public.restaurants where latitude is null or longitude is null),
    'claims_pending',         (select count(*) from public.restaurant_claims where status in ('pending', 'under_review')),
    'claims_more_info',       (select count(*) from public.restaurant_claims where status = 'more_information_required'),
    'reports_open',           (select count(*) from public.restaurant_reports where status in ('open', 'in_progress')),
    'change_requests_pending',(select count(*) from public.restaurant_change_requests where status = 'pending'),
    'users_total',            (select count(*) from public.profiles),
    'owners_total',           (select count(distinct user_id) from public.restaurant_members where status = 'active'),
    'offers_active',          (select count(*) from public.offers where is_active and (ends_at is null or ends_at > now())),
    'coupons_active',         (select count(*) from public.coupons where is_active and (valid_until is null or valid_until > now())),
    'sponsored_active',       (select count(*) from public.sponsored_restaurants where is_active and (ends_at is null or ends_at > now())),
    'events_30d',             (select count(*) from public.analytics_events where created_at >= now() - interval '30 days'),
    'views_30d',              (select count(*) from public.analytics_events where event_type = 'view' and created_at >= now() - interval '30 days'),
    'map_opens_30d',          (select count(*) from public.app_events where event_type = 'map_open' and created_at >= now() - interval '30 days'),
    'near_me_30d',            (select count(*) from public.app_events where event_type = 'near_me_search' and created_at >= now() - interval '30 days'),
    'show_demo_data',         public.demo_data_visible()
  ) into v;
  return v;
end $$;
