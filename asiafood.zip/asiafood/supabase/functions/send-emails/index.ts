// ─────────────────────────────────────────────────────────────
//  Edge Function "send-emails": svuota la coda public.email_outbox.
//  Provider astratto: Resend, Brevo o SendGrid, scelto da EMAIL_PROVIDER.
//  Senza provider configurato la funzione non invia nulla (le email restano
//  in coda): prenotazioni, coupon e webhook Stripe non vengono mai bloccati.
//  Gli errori di invio restano sulla riga (last_error, status failed dopo 5 tentativi).
//
//  Deploy:   supabase functions deploy send-emails
//  Segreti:  supabase secrets set EMAIL_PROVIDER=resend EMAIL_API_KEY=... EMAIL_FROM="AsiaFood <noreply@tuodominio.it>" SITE_URL=https://...
//  Pianifica: ogni minuto (Supabase → Integrations → Cron) con una chiamata POST a questa funzione.
// ─────────────────────────────────────────────────────────────
import { createClient } from 'npm:@supabase/supabase-js@2';

type Provider = 'resend' | 'brevo' | 'sendgrid';
interface Email { to: string; subject: string; html: string; text: string }
interface OutboxRow { id: number; event_type: string; recipient: string; payload: Record<string, unknown>; attempts: number }

const env = (k: string) => Deno.env.get(k) ?? '';
const PROVIDER = env('EMAIL_PROVIDER') as Provider | '';
const FROM = env('EMAIL_FROM');
const SITE = env('SITE_URL').replace(/\/$/, '');

/** Interfaccia unica: aggiungere un provider = aggiungere un caso qui. */
async function send(e: Email): Promise<void> {
  const key = env('EMAIL_API_KEY');
  const [fromName, fromEmail] = /(.*)<(.+)>/.exec(FROM)?.slice(1).map((s) => s.trim()) ?? ['', FROM];
  let res: Response;
  if (PROVIDER === 'resend') {
    res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: FROM, to: [e.to], subject: e.subject, html: e.html, text: e.text }),
    });
  } else if (PROVIDER === 'brevo') {
    res = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: { 'api-key': key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ sender: { name: fromName, email: fromEmail }, to: [{ email: e.to }], subject: e.subject, htmlContent: e.html, textContent: e.text }),
    });
  } else if (PROVIDER === 'sendgrid') {
    res = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: e.to }] }], from: { email: fromEmail, name: fromName }, subject: e.subject,
        content: [{ type: 'text/plain', value: e.text }, { type: 'text/html', value: e.html }],
      }),
    });
  } else {
    throw new Error('Provider email non configurato');
  }
  if (!res.ok) throw new Error(`${PROVIDER} ${res.status}: ${(await res.text()).slice(0, 300)}`);
}

const esc = (s: unknown) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!);
const day = (d: unknown) => new Date(`${d}T12:00:00Z`).toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC' });

// ─── Fase 8: link di tracciamento per gli ordini degli ospiti ───
// Stesso token del backend (server/orders/handlers.ts): HMAC-SHA256(secret, "order:"+id) in base64url, 32 caratteri.
// Il DB conserva solo l'hash del token: il link si ricostruisce qui, lato server, mai nel browser.
async function hmacB64url(secret: string, msg: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg)));
  return btoa(String.fromCharCode(...sig)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
async function hmacHex(secret: string, msg: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return [...new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg)))].map((b) => b.toString(16).padStart(2, '0')).join('');
}
async function orderLink(p: Record<string, unknown>): Promise<string> {
  const base = `${SITE}/orders/${encodeURIComponent(String(p.order_number ?? ''))}`;
  if (!p.guest || typeof p.order_id !== 'string') return base;
  const secret = env('ORDER_TOKEN_SECRET') || (env('SUPABASE_SERVICE_ROLE_KEY') ? await hmacHex(env('SUPABASE_SERVICE_ROLE_KEY'), 'asiafood-order-token') : '');
  if (!secret) return base;
  return `${base}?t=${(await hmacB64url(secret, `order:${p.order_id}`)).slice(0, 32)}`;
}
const ORDER_DEFAULTS: Record<string, [string, string]> = {
  order_received: ['Ordine ricevuto', 'Abbiamo ricevuto il tuo ordine.'],
  order_payment_confirmed: ['Pagamento confermato', 'Il pagamento è confermato: ti avvisiamo appena il ristorante accetta l’ordine.'],
  order_accepted: ['Ordine accettato', 'Il ristorante ha accettato il tuo ordine.'],
  order_rejected: ['Ordine non accettato', 'Il ristorante non può preparare il tuo ordine. Se avevi pagato, il rimborso è in corso.'],
  order_ready: ['Ordine pronto', 'Il tuo ordine è pronto.'],
  order_cancelled: ['Ordine annullato', 'Il tuo ordine è stato annullato.'],
  order_refunded: ['Rimborso elaborato', 'Il rimborso è stato inviato al tuo metodo di pagamento: i tempi di accredito dipendono dalla banca.'],
};

/** Template in italiano per ogni evento della coda. */
async function render(row: OutboxRow): Promise<Email> {
  const p = row.payload;
  const when = `${day(p.date)} alle ${esc(p.time)}`;
  const details = `<p><strong>${esc(p.restaurant)}</strong><br>${when} · ${esc(p.party_size)} persone<br>Codice: <strong>${esc(p.code)}</strong></p>`;
  const manage = `<p>Per annullare: ${SITE}/prenotazione (codice ed email).</p>`;
  const wrap = (title: string, body: string) => `<!doctype html><html lang="it"><body style="font-family:system-ui,sans-serif;color:#16161A"><h1 style="font-size:20px">${title}</h1>${body}<p style="color:#888;font-size:12px">AsiaFood</p></body></html>`;
  const t = (html: string) => html.replace(/<br>/g, '\n').replace(/<[^>]+>/g, '').trim();
  let subject: string;
  let html: string;
  switch (row.event_type) {
    case 'reservation_created':
      subject = `Richiesta di prenotazione inviata · ${p.restaurant}`;
      html = wrap('Prenotazione inviata', `<p>Ciao ${esc(p.guest_name)}, il ristorante confermerà a breve.</p>${details}${manage}`);
      break;
    case 'reservation_confirmed':
      subject = `Prenotazione confermata · ${p.restaurant}`;
      html = wrap('Prenotazione confermata', `<p>Ti aspettiamo!</p>${details}${manage}`);
      break;
    case 'reservation_rejected':
      subject = `Prenotazione non disponibile · ${p.restaurant}`;
      html = wrap('Prenotazione non confermata', `<p>Il ristorante non può accogliere questa richiesta. Prova un altro orario.</p>${details}`);
      break;
    case 'reservation_cancelled':
      subject = `Prenotazione annullata · ${p.restaurant ?? ''}`;
      html = wrap('Prenotazione annullata', `<p>La prenotazione è stata annullata${p.by === 'restaurant' ? ' dal ristorante' : ''}.</p>${details}`);
      break;
    case 'reservation_new_for_restaurant':
      subject = `Nuova prenotazione ${p.status === 'pending' ? 'da confermare' : 'confermata'} · ${p.code}`;
      html = wrap('Nuova prenotazione', `${details}<p>Gestiscila dalla dashboard: ${SITE}/dashboard</p>`);
      break;
    // ─── Fase 5: fatturazione (testo di notifica generato dal DB, link alla dashboard) ───
    case 'billing_welcome':
    case 'billing_subscription_activated':
      subject = `${p.title ?? 'Abbonamento attivato'} · ${p.restaurant_name ?? ''}`;
      html = wrap(esc(p.title ?? 'Benvenuto in AsiaFood Business'), `<p>${esc(p.body)}</p><p>Gestisci piano e fatture: ${SITE}/dashboard/restaurants/${esc(p.restaurant_id)}/billing</p>`);
      break;
    case 'billing_trial_started':
    case 'billing_trial_ending':
      subject = `${p.title ?? 'Prova gratuita'} · ${p.restaurant_name ?? ''}`;
      html = wrap(esc(p.title), `<p>${esc(p.body)}</p>${p.has_payment_method === false ? '<p>Aggiungi un metodo di pagamento per continuare senza interruzioni.</p>' : ''}<p>${SITE}/dashboard/restaurants/${esc(p.restaurant_id)}/billing</p>`);
      break;
    case 'billing_payment_succeeded':
      subject = `Pagamento ricevuto · ${p.restaurant_name ?? ''}`;
      html = wrap('Pagamento ricevuto', `<p>${esc(p.body)}</p>${p.invoice_url ? `<p>Fattura: ${esc(p.invoice_url)}</p>` : ''}`);
      break;
    case 'billing_payment_failed':
      subject = `Problema con il pagamento del tuo abbonamento · ${p.restaurant_name ?? ''}`;
      html = wrap('Problema con il pagamento del tuo abbonamento', `<p>${esc(p.body)}</p><p>Aggiorna il metodo di pagamento: ${SITE}/dashboard/restaurants/${esc(p.restaurant_id)}/billing</p>`);
      break;
    case 'billing_subscription_cancelled':
      subject = `Abbonamento cancellato · ${p.restaurant_name ?? ''}`;
      html = wrap(esc(p.title ?? 'Abbonamento cancellato'), `<p>${esc(p.body)}</p><p>Puoi riattivarlo prima della scadenza: ${SITE}/dashboard/restaurants/${esc(p.restaurant_id)}/billing</p>`);
      break;
    // ─── Fase 7: fidelizzazione (rispettano le preferenze: il DB accoda solo se consentito) ───
    case 'reservation_reminder':
      subject = `Promemoria prenotazione · ${p.restaurant}`;
      html = wrap('Promemoria prenotazione', `<p>${esc(p.body ?? `Hai una prenotazione da ${p.restaurant}.`)}</p><p>Codice: <strong>${esc(p.code)}</strong></p>${manage}`);
      break;
    case 'review_request':
      subject = `Com’è andata da ${p.restaurant}?`;
      html = wrap(`Com’è andata da ${esc(p.restaurant)}?`, `<p>Racconta la tua esperienza: aiuta altre persone a scegliere.</p><p>${SITE}/ristorante/${esc(p.restaurant_slug)}?review=1#recensioni</p><p style="color:#888;font-size:12px">Puoi disattivare queste email dalle preferenze notifiche: ${SITE}/settings/notifications</p>`);
      break;
    case 'referral_completed':
      subject = 'Il tuo invito è stato completato';
      html = wrap('Invito completato', `<p>${esc(p.body)}</p><p>${SITE}/profile/referrals</p>`);
      break;
    case 'reward_redeemed':
      subject = `Premio riscattato · ${p.reward}`;
      html = wrap('Premio riscattato', `<p>${esc(p.reward)}</p><p>Codice: <strong>${esc(p.code)}</strong></p><p>${SITE}/profile/loyalty</p>`);
      break;
    case 'coupon_expiring':
      subject = `Il tuo coupon sta per scadere · ${p.restaurant}`;
      html = wrap('Coupon in scadenza', `<p>${esc(p.body)}</p><p>${SITE}/dashboard/coupons</p>`);
      break;
    case 'marketing_campaign':
      subject = String(p.title ?? 'Novità da AsiaFood');
      html = wrap(esc(p.title), `<p>${esc(p.body)}</p><p>${SITE}${esc(p.link ?? '/')}</p><p style="color:#888;font-size:12px">Ricevi questa email perché hai accettato le comunicazioni promozionali. Disattivale: ${SITE}/settings/notifications</p>`);
      break;
    // ─── Fase 8: ordini (email transazionali: sempre inviate, mai marketing) ───
    case 'order_received':
    case 'order_payment_confirmed':
    case 'order_accepted':
    case 'order_rejected':
    case 'order_ready':
    case 'order_cancelled':
    case 'order_refunded': {
      const [defTitle, defBody] = ORDER_DEFAULTS[row.event_type]!;
      const link = await orderLink(p);
      subject = `${p.title ?? defTitle} · ${p.order_number ?? ''}`;
      html = wrap(esc(p.title ?? defTitle), `<p>${esc(p.body ?? defBody)}</p><p><strong>${esc(p.restaurant)}</strong> · ordine <strong>${esc(p.order_number)}</strong>${p.total != null ? ` · totale ${esc(Number(p.total).toFixed(2).replace('.', ','))} €` : ''}</p><p>Segui l’ordine: ${esc(link)}</p><p style="color:#888;font-size:12px">Ricevuta non fiscale. Per problemi con l’ordine usa “Segnala un problema” dalla pagina dell’ordine.</p>`);
      break;
    }
    case 'order_new_for_restaurant':
      subject = `Nuovo ordine ${p.order_number ?? ''} · ${p.restaurant ?? ''}`;
      html = wrap('Nuovo ordine da accettare', `<p>È arrivato un nuovo ordine pagato${p.order_type ? ` (${p.order_type === 'delivery' ? 'consegna' : 'ritiro'})` : ''}.</p><p>Aprilo dal terminale ordini: ${SITE}/dashboard/restaurants/${esc(p.restaurant_id)}/orders</p>`);
      break;
    default:
      throw new Error(`Evento sconosciuto: ${row.event_type}`);
  }
  return { to: row.recipient, subject, html, text: t(html) };
}

Deno.serve(async (req) => {
  // Fase 11: con EMAIL_CRON_SECRET impostato la funzione (deploy con --no-verify-jwt) accetta solo il cron
  const cronSecret = env('EMAIL_CRON_SECRET');
  if (cronSecret && req.headers.get('x-cron-secret') !== cronSecret) return Response.json({ error: 'unauthorized' }, { status: 401 });
  if (!PROVIDER || !FROM) return Response.json({ sent: 0, skipped: 'EMAIL_PROVIDER/EMAIL_FROM non configurati: email lasciate in coda' });
  const db = createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });
  const { data, error } = await db.from('email_outbox').select('id,event_type,recipient,payload,attempts').eq('status', 'pending').lt('attempts', 5).order('created_at').limit(50);
  if (error) {
    console.error('email_outbox read failed', error.code);
    return Response.json({ error: 'internal' }, { status: 500 });
  }
  let sent = 0;
  for (const row of (data ?? []) as OutboxRow[]) {
    // Presa in carico ottimistica: se due esecuzioni si sovrappongono, solo una invia la stessa email
    const { data: claimed } = await db.from('email_outbox').update({ attempts: row.attempts + 1 }).eq('id', row.id).eq('attempts', row.attempts).eq('status', 'pending').select('id');
    if (!claimed?.length) continue;
    try {
      await send(await render(row));
      await db.from('email_outbox').update({ status: 'sent', sent_at: new Date().toISOString() }).eq('id', row.id);
      sent++;
    } catch (e) {
      await db.from('email_outbox').update({ attempts: row.attempts + 1, last_error: String(e).slice(0, 500), status: row.attempts + 1 >= 5 ? 'failed' : 'pending' }).eq('id', row.id);
    }
  }
  return Response.json({ sent, processed: data?.length ?? 0 });
});
