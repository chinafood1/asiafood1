# AsiaFood — v0.1.0-beta (Fasi 1–11: catalogo, SaaS B2B, AI, fidelizzazione, ordini, logistica, hardening)

Piattaforma verticale, mobile-first e installabile (PWA) dedicata ai ristoranti di cucina asiatica.
Mercato di lancio: **Taranto e provincia**. Architettura pronta per Puglia → Sud Italia → Italia.

> Il nome **AsiaFood** è provvisorio: si cambia con `VITE_APP_NAME` (titoli, manifest PWA, SEO) senza toccare il codice.

---

## Stack

| Livello | Tecnologia |
|---|---|
| Frontend | React 18 · Vite 5 · TypeScript (strict) · React Router 6 |
| Stile | Tailwind CSS 3 (design token in `tailwind.config.js`) |
| Backend | Supabase: PostgreSQL, Auth, Storage, RLS, RPC |
| Hosting | Netlify (`netlify.toml` già pronto) |
| PWA | `vite-plugin-pwa` (manifest, service worker, cache immagini) |
| Mappe | Astrazione `MapView`: `none` (mappa schematica integrata) · `google` · `mapbox` |
| Pagamenti | **Stripe Billing** (Checkout, Customer Portal, webhook) via **Netlify Functions**; chiavi segrete solo lato server |
| Backend serverless | `netlify/functions/*` → `server/billing/*` (logica testabile, Stripe e DB iniettati) |
| Email | Coda `email_outbox` + Edge Function `send-emails` (provider astratto: Resend / Brevo / SendGrid) |

---

## Avvio rapido (senza Supabase)

```bash
npm install
cp .env.example .env.local
npm run dev            # http://localhost:5173
```

Senza chiavi Supabase l'app parte in **modalità DEMO**: dati locali salvati nel browser, banner "Modalità DEMO" in alto.
Su `/accedi` trovi tre pulsanti per entrare come **Cliente**, **Ristoratore** o **Admin** demo e provare tutti i flussi
(preferiti, rivendicazione → approvazione, dashboard, editor). Dalla dashboard Admin puoi ripristinare i dati demo.

## Collegare Supabase (produzione)

1. **Crea un progetto** su [supabase.com](https://supabase.com) (regione UE consigliata, es. Frankfurt).
2. **Applica le migrazioni**, in uno dei due modi:
   - CLI: `npx supabase link --project-ref <ref>` poi `npx supabase db push`
   - Manuale: SQL Editor → esegui in ordine i file di `supabase/migrations/` (0001 → 0014). **Ognuno in un'esecuzione separata**: la 0007, la 0011 e la 0013 aggiungono valori agli enum che la 0008, la 0012 e la 0014 usano.
3. **Dati demo (facoltativo)**: esegui `supabase/seed.sql` nello SQL Editor.
   Tutti i locali demo hanno `is_demo = true`, nomi di fantasia e indirizzi "Via Esempio … (indirizzo DEMO)".
   Per rimuoverli prima del lancio: `npm run clean-demo-data` (dry-run; vedi sezione Fase 11) oppure `show_demo_data=false` per nasconderli. Il DELETE diretto è bloccato da un trigger di protezione.
4. **Variabili ambiente** in `.env.local` (Project Settings → API):
   `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` (+ facoltativo `VITE_MAPBOX_ACCESS_TOKEN`, vedi "Mappe").
5. **Auth** (Authentication → URL Configuration):
   - *Site URL*: l'URL Netlify (es. `https://asiafood.netlify.app`)
   - *Redirect URLs*: `https://<dominio>/**` e `http://localhost:5173/**`
   - Email: in Authentication → Providers → Email la conferma email è attiva di default (consigliato tenerla).
6. **Crea il primo Admin**: registrati dal sito, poi nello SQL Editor:
   ```sql
   update public.profiles set role = 'admin' where email = 'tua@email.it';
   ```
7. Riavvia `npm run dev`: il banner DEMO sparisce e i dati arrivano da Supabase.

## Deploy su Netlify

1. Collega il repository (o `npx netlify deploy`). Build command e publish dir sono in `netlify.toml`.
2. In *Site configuration → Environment variables* imposta almeno:
   `VITE_APP_NAME`, `VITE_SITE_URL`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
3. Pagamenti (Fase 5): aggiungi `VITE_STRIPE_PUBLISHABLE_KEY` e, **solo per le Functions** (scope "Functions", mai con prefisso `VITE_`),
   `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_MODE=test`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `APP_URL`
   (facoltativi `STRIPE_TAX_ENABLED`, `STRIPE_PORTAL_CONFIGURATION_ID`, `STRIPE_ALLOW_PROMOTION_CODES`). Vedi docs/STRIPE_SETUP.md.
   Le funzioni `netlify/functions/*` sono pubblicate su `/api/billing/*`; `billing-cron` gira ogni ora.
4. Ogni build rigenera `public/sitemap.xml` (letta con la chiave pubblica: solo locali pubblicati) e aggiorna `robots.txt` con `VITE_SITE_URL`.

---

## Script

| Comando | Cosa fa |
|---|---|
| `npm run dev` | Server di sviluppo |
| `npm run build` | Sitemap + typecheck + build di produzione in `dist/` |
| `npm run preview` | Serve la build (utile per testare la PWA) |
| `npm run typecheck` | Solo controllo TypeScript |
| `npm run sitemap` | Rigenera `public/sitemap.xml` (da Supabase se configurato, altrimenti dai dati locali) |
| `npm run lint` | ESLint (TypeScript + regole React hooks) |
| `npm run db:seed-sql` | Rigenera `0009_reference_phase2.sql` e `seed.sql` da `src/data/*` (fonte unica dei dati) |
| `npm run test:db` | **Test di sicurezza RLS e regole di business**: applica tutte le migrazioni + seed su Postgres in-memory e verifica 367 regole (permessi, piani, overbooking, coupon, analytics, abbonamenti, MRR, sponsorizzazioni, assistente AI) |
| `npm run test:billing` | **Test end-to-end della fatturazione**: veri handler + vere migrazioni + Stripe simulato con firme webhook reali (85 scenari: checkout, prova, upgrade, downgrade, cancellazione, pagamenti falliti, portal, sicurezza) |
| `npm run test:ai` | **Test end-to-end dell'assistente AI**: vero router `/api/ai/chat` + vere migrazioni + modelli simulati (corretto, "allucinato", manipolato, offline, lento): 139 scenari funzionali e di sicurezza |
| `npm run test:engagement` | Test end-to-end della Fase 7 (recensioni, AsiaPoints, inviti, notifiche, campagne) |
| `npm run test:orders` | **Test end-to-end degli ordini**: veri handler `/api/orders/*` + webhook firmati + vere migrazioni + Stripe simulato (151 scenari: prezzi dal server, coupon, zone, slot, pagamento, webhook idempotenti, Connect, rimborsi, RLS, token ospite) |
| `npm run test:logistics` | **Test end-to-end della logistica**: candidatura, dispatch, offerte/timeout, accettazione concorrente, stati, tracking e privacy, compensi, RLS (152 scenari) |
| `npm run test:hardening` | **Test di sicurezza Fase 11** (157): grant delle funzioni, rate limit, audit, consenso, export/cancellazione GDPR, upload, slug 301, supporto, inviti beta, kill switch, retention, launch checklist |
| `npm run test:platform` | Test del backend di piattaforma (49): env Zod, logger con redazione, errori standard, manutenzione, health/ready, cron con lock |
| `npm run test:unit` | Test unitari condivisi (59): validazione Zod, upload (MIME reale), redirect sicuri, importi in centesimi, scrubbing PII |
| `npm run test:launch` | Test Fase 12 (138): mercato, completezza, segmenti, First 50, CRM, Partner Fondatori, QR, attribuzione, feedback/NPS, ambassador, contenuti, esperimenti, obiettivi, dashboard, RLS |
| `npm run test:all` | Tutte le suite (≈ 1.460 controlli) |
| `npm run production-check` | Controllo di rilascio: variabili (solo nomi), segreti nel bundle, source map, budget, SEO, PWA, header. `-- --env=production --online` per i controlli sul DB |
| `npm run clean-demo-data` | Rimozione dati DEMO: **dry-run** di default; richiede `CLEAN_DEMO_DATA_ALLOWED=true`, `--confirm=DELETE-DEMO-DATA` e il ref del progetto digitato a mano |
| `npm run docs:rls` | Rigenera `docs/RLS_MATRIX.md` dalle migrazioni |
| `npm run import -- <file>` | Import CSV/JSON da terminale (simulazione; `--apply` per scrivere). Vedi [docs/IMPORT_FORMAT.md](docs/IMPORT_FORMAT.md) |

---

## Struttura del progetto

```
supabase/
  migrations/
    …0001_schema.sql          tabelle, enum, indici, trigger
    …0002_functions.sql       helper ruoli, approvazione claim, ricerca per distanza, analytics, KPI
    …0003_rls.sql             Row Level Security su tutte le tabelle
    …0004_storage.sql         bucket "restaurant-media" + policy
    …0005_reference_data.sql  regioni, province, comuni di lancio, categorie, piani
    …0006_grants.sql          privilegi espliciti per la Data API
    …0007_phase2_enums.sql    stati claim, data_status, ruoli team, tipi fonte e segnalazione
    …0008_phase2_schema.sql   fonti, team, claim estesi + messaggi, segnalazioni, import, bucket privato, RLS
    …0009_reference_phase2.sql 29 comuni della provincia di Taranto, nuove categorie
    …0010_geo.sql              ricerca per distanza, eventi mappa, proposte di spostamento
    …0011_commerce_enums.sql   nuovi eventi analytics, tipi menu/offerta, stati prenotazione e coupon
    …0012_commerce.sql         Fase 4: plan_features, menu completo, prenotazioni, coupon_claims, notifiche, email_outbox, analytics, RLS
    …0013_billing_enums.sql    stati Stripe completi, origine abbonamento, stati campagna, eventi sponsorizzati
    …0014_billing.sql          Fase 5: piano effettivo, billing_accounts, stripe_events, fatture, prove, promozioni B2B, campagne, ricavi, RLS
  functions/send-emails/      Edge Function che svuota la coda email (provider configurabile)
  seed.sql                    17 ristoranti DEMO con menu, orari, offerte, coupon, disponibilità e prenotazioni demo
server/billing/               logica Stripe server-side (checkout, portal, webhook, azioni, admin, cron)
netlify/functions/            endpoint /api/billing/* (wrapper sottili) + cron orario
scripts/                      sitemap, generatore SQL, test RLS, test fatturazione (lib/fake-stripe.ts), import
data/import/                  dataset reali pronti da importare (fonti pubbliche)
docs/IMPORT_FORMAT.md         formato importabile e regole di deduplicazione
docs/STRIPE_SETUP.md          configurazione Stripe in test mode (prodotti, prezzi, webhook, portal, carte di test)
src/
  config/app.ts               brand, URL, feature flag, provider mappe (tutto da env)
  types/domain.ts             tipi di dominio condivisi
  services/                   data layer: interfaccia DataSource + supabaseSource / demoSource
  context/                    Auth, Preferiti, Dati di riferimento
  lib/                        seo, orari/"aperto ora", geo, formattazione, maps/, searchQuery (ricerca libera),
                              import/ (parser CSV/JSON, validazione, deduplicazione — condiviso con lo script)
  components/
    ui/ layout/ search/ restaurant/   design system e blocchi pubblici
    editor/                   editor a sezioni: 19 sezioni Admin, 10 per il ristoratore
    claims/                   conversazione claim e documenti privati
    admin/CrudPage.tsx        CRUD generico configurabile per le tabelle Admin
  pages/                      pagine pubbliche, auth, owner/, admin/
  data/                       dati di riferimento + dati DEMO (fonte unica per app e SQL)
```

Il resto dell'app parla solo con `api` (`src/services/index.ts`): passare da demo a Supabase, o in futuro a un backend diverso, non tocca pagine e componenti.

---

## Schema database

**Geografia (scala nazionale):** `regions` → `provinces` → `cities` (slug univoco nazionale, coordinate, `is_launch_market`).
Tutte le 20 regioni sono già presenti; si attiva un territorio impostando `is_active = true`.

**Utenti:** `profiles` (1:1 con `auth.users`, creato da trigger) con `role` = `customer` | `restaurant_owner` | `admin`.

**Ristoranti:** `restaurants` (tutti i campi richiesti + `services[]`, `is_demo`, `popularity_score`, `opened_at`,
`meta_title/description`, ricerca full-text italiana e trigram). Provincia e regione sono ricavate automaticamente dal comune.
Tabelle figlie: `restaurant_categories`, `restaurant_images`, `restaurant_hours` (più fasce al giorno, gestione dopo mezzanotte),
`menus` → `menu_categories` → `menu_items` (prezzo, pezzi, allergeni UE, tag, inclusione AYCE).

**Community e business:** `favorites`, `restaurant_claims` (workflow rivendicazione), `offers`, `coupons`, `coupon_redemptions`,
`subscription_plans` (Free / Business / Premium / Top con feature flag JSON e campi Stripe), `subscriptions`,
`sponsored_restaurants` (campagne con placement e targeting per regione/provincia/città/categoria).

**Statistiche:** `analytics_events` (view, click telefono/WhatsApp/indicazioni/menu/prenotazione/sito/social, coupon).
Scrittura solo via RPC `track_event`; lettura aggregata via `restaurant_stats` (owner) e `admin_dashboard_stats` (admin).

**Fase 2:**
- `restaurants` + `source_name`, `source_url`, `external_id`, `google_place_id` (univoco), `data_status`
  (`verified | partially_verified | unverified | claimed | outdated`), `last_verified_at`, `claimed_at`, `claimed_by`,
  `verification_notes`, `menu_last_verified_at`, `opening_hours_last_verified_at`, `is_temporarily_closed`, `is_permanently_closed`.
- `restaurant_sources` (più fonti per attività), `restaurant_members` (owner/manager/staff: i permessi derivano da qui),
  `restaurant_claims` estesa (nome, cognome, ruolo, ragione sociale, P.IVA, CF, email aziendale, sito, metodo di verifica,
  documento privato, date di invio/revisione/approvazione/rifiuto; stati `pending | under_review | more_information_required | approved | rejected`),
  `restaurant_claim_messages`, `restaurant_reports`, `import_batches`, `platform_settings` (`show_demo_data`).

**Fase 3:** vincolo `restaurants_coords_pair` (lat/lng entrambe o nessuna), indice `(latitude, longitude)`,
`nearby_restaurants`, `geo_distance_km`, `app_events` + `track_app_event` (map_open, location_permission_*, restaurant_marker_click,
directions_click, near_me_search, map_area_search), `restaurant_change_requests` + `review_change_request`.

**RPC principali:** `approve_claim`, `reject_claim`, `set_claim_under_review`, `request_claim_info`, `respond_to_claim`,
`admin_transfer_ownership`, `admin_revoke_ownership`, `admin_set_member`, `admin_remove_member`, `admin_import_restaurant`,
`admin_duplicate_restaurant`, `restaurants_nearby`, `track_event`, `restaurant_stats`, `admin_dashboard_stats`.

## Sicurezza (RLS)

- **Visitatori**: sola lettura di contenuti attivi (ristoranti, menu, orari, offerte e coupon validi).
- **Clienti**: gestiscono solo il proprio profilo, i propri preferiti e le proprie richieste di rivendicazione.
  Non possono cambiare il proprio ruolo (trigger `protect_profile_role`).
- **Ristoratori**: modificano **solo** i locali per cui hanno una membership attiva (owner o manager), creata esclusivamente
  dall'approvazione di un claim o da un Admin. Non possono aggiungersi da soli a un team. Anche sul proprio locale non toccano campi
  riservati (titolare, verifica, pubblicazione, stato dati, fonti, sponsor, piano, slug, comune, chiusura definitiva): trigger
  `protect_restaurant_admin_fields`. Il ruolo `restaurant_owner` del profilo è derivato dalle membership, mai scrivibile dal client.
- **Documenti di verifica**: bucket **privato** `claim-documents`, cartella per utente; li leggono solo chi li ha caricati e l'Admin (URL firmati a 2 minuti).
- **Segnalazioni**: inviabili anche anonime su locali pubblici; stato forzato a "aperta" e limite anti-flood; lette solo dall'Admin.
- **Dati demo**: nascosti al pubblico a livello di RLS quando `show_demo_data = false` (interruttore in Admin → Panoramica).
- **Admin**: gestione completa; unico ruolo che approva/rifiuta claim, crea/elimina locali e gestisce sponsorizzazioni e piani.

Tutto questo è verificato da `npm run test:db`.

---

## Rotte

| Rotta | Pagina |
|---|---|
| `/` | Home: hero con ricerca, categorie, Vicino a te, AYCE, Popolari, In evidenza, Offerte di oggi, Nuove aperture, Città |
| `/restaurants` | Esplora: ricerca libera ("Sushi Taranto" → `?category=sushi&city=taranto`), filtri (categoria, comune, distanza, prezzo, AYCE, delivery, asporto, prenotazione, aperto ora, offerte), ordinamenti (pertinenza, più vicini, popolari, prezzo, nuove), viste card / lista (la vista mappa apre `/map` con gli stessi filtri) |
| `/map` | Mappa + lista sincronizzata. Parametri: `city`, `category`, `near=1&km=10`, `bbox=w,s,e,n`, `restaurant=slug`, `ids=…` (risultati dell'assistente) e tutti i filtri di Esplora. `/mappa` e `/restaurants/map` reindirizzano qui |
| `/assistant` | AI Food Assistant ("Cosa vuoi mangiare?"); `?q=` domanda iniziale (noindex). `/assistant/session/*` → `/assistant` (mai ID di sessione negli URL) |
| `/admin/ai` | Utilizzo, costi, qualità e configurazione dell'assistente |
| `/ristorante/:slug` | Scheda locale (es. `/ristorante/kaizen-sushi-lab-taranto`) |
| `/ristorante/:slug/rivendica` | Wizard "Rivendica questa attività" (accesso → attività → dati → metodo di verifica + documento) |
| `/ristoranti`, `/ristoranti/:citta` | Indice città e landing SEO per comune |
| `/business/pricing` | Prezzi pubblici e confronto piani (indicizzabile); `/prezzi` reindirizza |
| `/:categoria`, `/:categoria/:citta` | Landing SEO (es. `/sushi/taranto`, `/all-you-can-eat/massafra`) |
| `/ristorante/:slug/prenota` | Prenotazione tavolo in 6 passi (anche ospite), codice `ASF-XXXXX`; precompilabile dall'assistente (`?date&time&party&src=ai`, conferma sempre dell'utente) |
| `/prenotazione` | Gestione prenotazione per ospiti (codice + email → dettagli/annulla), senza enumerazione |
| `/offers` | Offerte indicizzabile: sezioni Vicino a te, Taranto, Oggi, AYCE, Sushi + filtri città/categoria/data/tipo (`/offerte` reindirizza) |
| `/preferiti`, `/profilo` | Preferiti, profilo |
| `/accedi`, `/registrati`, `/reimposta-password` | Autenticazione |
| `/per-ristoratori` | Landing B2B con piani |
| `/dashboard`, `/dashboard/claims`, `/dashboard/restaurants/:id/:sezione` | Area utente/ristoratore: richieste con messaggi, locali gestiti, editor |
| `/dashboard/restaurants/:id/menu` · `/reservations` · `/offerte` · `/coupon` · `/valida-coupon` · `/analytics` · `/panoramica` | Sezioni commerciali del locale |
| `/dashboard/reservations`, `/dashboard/coupons`, `/dashboard/notifications`, `/dashboard/plans` | Prenotazioni e coupon del cliente, notifiche, scelta piano (checkout) |
| `/dashboard/restaurants/:id/billing` · `/ads` · `/onboarding` | Fatturazione del locale, dashboard sponsorizzazioni (Top), configurazione guidata in 8 passi |
| `/cart`, `/checkout`, `/orders/:orderNumber`, `/profile/orders` | Carrello, checkout, tracciamento ordine (ospiti con token), storico ordini (noindex) |
| `/dashboard/restaurants/:id/orders` · `/order-settings` · `/payouts` | Terminale ordini, impostazioni ordini/zone/scelte, pagamenti Stripe Connect |
| `/admin/orders`, `/admin/marketplace` | Ordini del marketplace, metriche, commissioni |
| `/rider/apply`, `/rider`, `/rider/delivery/:id`, `/rider/earnings` | Candidatura e app Rider (mobile-first) |
| `/admin/riders`, `/admin/dispatch`, `/admin/logistics`, `/admin/logistics/settings` | Rider, control center, metriche e impostazioni logistiche |
| `/dashboard/billing`, `/dashboard/billing/success`, `/dashboard/billing/cancel` | Dati di fatturazione, ritorno dal checkout Stripe |
| `/admin/subscriptions`, `/admin/sponsorships`, `/admin/system/stripe`, `/admin/promozioni` | Abbonamenti (filtri e azioni), campagne sponsorizzate, stato Stripe + log webhook + impostazioni, promozioni B2B |
| `/notifications`, `/settings/notifications` | Centro notifiche (tutte/non lette, segna come lette), preferenze notifiche (transazionali vs promozionali, push, email) |
| `/profile/loyalty`, `/rewards`, `/profile/referrals`, `/invite/:codice` | Portafoglio AsiaPoints (saldo, livello, movimenti, badge), premi, inviti con condivisione, atterraggio invito |
| `/r/:slug`, `/r/:slug/menu`, `/r/:slug/review` | QR stampabili del locale (scheda, menu, "Racconta la tua esperienza") |
| `/dashboard/restaurants/:id/reviews` · `/campaigns` · `/qr` | Recensioni (risposta e segnalazione), campagne ai follower (Premium/Top) + inviti B2B, QR code |
| `/admin/reviews`, `/admin/loyalty`, `/admin/referrals`, `/admin/campaigns`, `/admin/retention` | Moderazione recensioni, AsiaPoints (regole, livelli, premi, badge, riscatti, rettifiche), inviti, campagne + scheduler, retention |
| `/admin/restaurants`, `/admin/import`, `/admin/claims`, `/admin/reports`, `/admin/modifiche`, `/admin/plans` | Area amministratore (+ utenti, categorie, territori, offerte, coupon, sponsor); `/admin/plans` = prezzi, matrice funzioni/limiti, richieste di upgrade |

**SEO:** title, description, canonical, Open Graph/Twitter e JSON-LD (`Restaurant`, `BreadcrumbList`, `ItemList`) per ogni pagina;
`sitemap.xml` e `robots.txt` generati in build; aree private in `noindex`.

> Nota SEO: essendo una SPA, i meta tag vengono impostati lato client. Google esegue il JavaScript e li legge, ma per
> massimizzare l'indicizzazione (e le anteprime social) il passo successivo consigliato è il prerendering delle pagine pubbliche
> (vedi "Prossimi passi").

## Mappe e geolocalizzazione (Fase 3)

**Provider.** Con `VITE_MAPBOX_ACCESS_TOKEN` la mappa usa **Mapbox GL** (stile `light-v11`, caricato da CDN solo aprendo una
pagina con mappa, clustering nativo). Senza token, o se Mapbox non risponde (token errato, rete, WebGL assente, timeout 15 s),
entra in automatico la **mappa integrata** (proiezione Web Mercator + clustering `supercluster`, pan/zoom/pinch/tastiera):
la pagina non si rompe mai e la lista resta sempre utilizzabile. `VITE_MAPS_PROVIDER` può forzare `mapbox`, `none` o `google`
(Google solo per le anteprime statiche).

**Configurare Mapbox**
1. Crea un account su mapbox.com → *Tokens* → *Create a token* con i soli scope pubblici (`styles:read`, `fonts:read`, `tiles:read`).
2. In *URL restrictions* aggiungi il dominio di produzione (es. `https://asiafood.netlify.app/*`) e `http://localhost:5173/*`.
3. Imposta `VITE_MAPBOX_ACCESS_TOKEN` in `.env.local` e su Netlify (*Site settings → Environment variables*), poi rideploya.
   Il token è pubblico per natura (`pk.…`): la protezione è la restrizione per URL. Mai usare token segreti (`sk.…`) nel frontend.
4. Lo stesso token abilita **“Trova coordinate”** nell'editor (Geocoding v6, solo su click, cache e max 1 richiesta/s).

**Privacy.** La posizione si chiede solo dopo un'azione esplicita (“Trova ristoranti vicino a me” / “Usa la mia posizione”),
viene arrotondata a ~11 m e resta nella sessione del browser (`sessionStorage`). Al server arriva al massimo un riquadro
arrotondato (~1 km); la distanza (haversine) si calcola nel browser. Nessuna cronologia, nessun salvataggio nel database.
Gli eventi analytics (`app_events`) scartano qualunque chiave che somigli a coordinate o indirizzi.
Il raggio preferito (1/3/5/10/20/50 km, default 10) è ricordato in `localStorage`.

**Database.** Migrazione `20260927000010_geo.sql`: RPC `nearby_restaurants(lat, lng, radius_km, limit)` (prefiltro bbox su indice
+ haversine, senza PostGIS), `track_app_event`, tabella `restaurant_change_requests` + `review_change_request` (solo Admin).
Il trigger `protect_restaurant_admin_fields` consente al titolare di spostare il segnaposto **al massimo di 300 m**; indirizzo,
CAP e spostamenti maggiori passano da una proposta approvata in **Admin → Modifiche posizione**.

**Indicazioni.** Link diretto ad Apple Maps su iOS/macOS e a Google Maps altrove: nessuna API necessaria.

---

## Fase 13: Business Intelligence & Growth Automation

Risposte operative in pochi minuti, solo da dati reali ("Dati insufficienti" quando il campione non basta).

- **Admin → Growth** (`/admin/growth`): Command Center (utenti, ristoranti, paganti, prove, MRR, GMV, prenotazioni, ordini, coupon, inviti, retention, conversione; periodi Oggi/Ieri/7/30/90/personalizzato con confronto solo se valido), brief "Oggi", funnel consumer e B2B con velocità di vendita, retention D1/D7/D30 e coorti, segmenti, ristoranti con health score interno e segnali di rischio, churn e motivi, ricavi/MRR/ARPA/LTV, acquisizione (first/last touch, UTM, CAC solo con dati), ricerche e **zero risultati**, **supply gap**, offerte/menu/AI/referral/AsiaPoints/recensioni, feedback e supporto, mercati e readiness, Taranto review, alert e anomalie, **automazioni** (kill switch, approvazione umana, storico), esperimenti con guardrail, report settimanale, task da insight e knowledge base, costi e unit economics, scenari su ipotesi, **Admin AI Analyst** (strumenti controllati), dati e soglie.
- **Admin → Prossimo mercato** (`/admin/expansion/next-market`): confronto città candidate con punteggio trasparente, "Start Research" (mai lancio automatico), playbook.
- **Ristoratore**: `AsiaFood Performance` e `Copilot` (`/dashboard/restaurants/:id/performance|copilot`) — solo i dati del proprio locale.
- **Database**: migrazioni `20261006000025_growth_core.sql`, `…026_growth_intel.sql`, `…027_growth_ops.sql` (aggregati giornalieri idempotenti + backfill, RLS su tutte le nuove tabelle, job orario/giornaliero); test `npm run test:growth`.

Documentazione: [docs/growth/README.md](docs/growth/README.md) · [Metriche](docs/growth/METRICS.md) · [Eventi](docs/growth/EVENTS.md) · [Automazioni](docs/growth/AUTOMATIONS.md) · [Espansione](docs/growth/EXPANSION.md).

## Fase 12: go-to-market Taranto

Strumenti per il lancio reale a Taranto e provincia — nessuna nuova funzione commerciale per i clienti finali, niente invii automatici.

- **Admin → Lancio Taranto** (`/admin/launch/taranto`): panoramica e avanzamento, vendite di oggi, operations, copertura per comune, First 50, CRM (ristoranti, creator, partner, stampa) con template di outreach, qualità dati, partner success e **Partner Fondatori**, crescita (review settimanale, funnel, coorti, UTM, codici, esperimenti, CAC), marketing (calendario, materiali stampabili, template), piano 30/90 giorni, obiettivi, scenario, feedback, ambassador, espansione.
- **Ristoratore**: `Kit QR` (5 QR, PNG/SVG, PDF stampabili) e `Kit di lancio` (checklist, prima offerta, annuncio social, feedback).
- **Pubblico**: landing `/taranto`, `/press`, `/app`; badge “Partner Fondatore” solo per gli aderenti; FAQ locali; feedback e NPS.
- **Database**: migrazioni `20261005000023_launch_enums.sql` e `20261005000024_launch.sql` (RLS su tutte le nuove tabelle, RPC admin protette, test `npm run test:launch`).

Guida operativa: [docs/launch/README.md](docs/launch/README.md) · [Sales playbook](docs/launch/SALES_PLAYBOOK.md) · [Marketing](docs/launch/MARKETING_PLAN.md) · [Piano](docs/launch/LAUNCH_PLAN.md) · [Metriche](docs/launch/METRICS.md) · [Search Console](docs/launch/SEARCH_CONSOLE.md).

## Fase 11: hardening e prontezza al lancio

Nessuna nuova funzione commerciale: sicurezza, privacy, affidabilità e operazioni.

- **Ambienti** `development/staging/production` (`APP_ENV`, impostato per contesto da `netlify.toml`) e validazione Zod delle variabili (`server/platform/env.ts`): in caso di configurazione mancante le API rispondono 503 senza rivelare nomi o valori.
- **Backend**: ogni funzione passa da `withPlatform` (request id, errori `{ error: { code, message, requestId } }` senza stack trace, rate limit condiviso nel DB, modalità manutenzione, log JSON con redazione, errori 5xx in `system_error_log` e Sentry facoltativo). Cron con lock condiviso e registro `background_jobs`.
- **Database** (migrazione `20261004000022_hardening.sql`): revoca dei permessi di esecuzione pubblici sulle funzioni Admin/servizio, rate limit su azioni pubbliche, audit Admin e sicurezza non cancellabili, consensi e versioni dei documenti legali, export e cancellazione account (ri-autenticazione, 7 giorni di ripensamento, anonimizzazione), retention, storico slug con 301, ticket di supporto, inviti beta, flag e kill switch, vincoli e indici, report di consistenza, launch checklist e readiness di Taranto.
- **Frontend**: banner cookie (Accetta tutti / Rifiuta non necessari / Personalizza), pagine legali **bozza** da revisionare, `/settings/privacy`, `/support`, 404, avviso di aggiornamento PWA, avviso offline, pagina di manutenzione, upload con verifica del tipo reale e ricompressione (EXIF rimossi), redirect sicuri, CSP senza `unsafe-eval`, font self-hosted, bundle senza DEMO in produzione (322 KB → 94 KB gzip).
- **Admin**: `/admin/system` (stato, errori, webhook, job, flag, privacy, audit, consistenza), `/admin/support`, `/admin/launch-checklist` (NOT_READY / READY_FOR_BETA / READY_FOR_PRODUCTION / BLOCKED; mai 100% con controlli critici aperti).
- **API**: `/api/health` (pubblico, senza dettagli), `/api/ready` (dettaglio con `X-Health-Token`), `/api/support`.

Documentazione: [ARCHITECTURE](docs/ARCHITECTURE.md) · [SECURITY](docs/SECURITY.md) · [RLS_MATRIX](docs/RLS_MATRIX.md) · [PRIVACY_DATA_MAP](docs/PRIVACY_DATA_MAP.md) · [DEPLOYMENT](docs/DEPLOYMENT.md) · [DISASTER_RECOVERY](docs/DISASTER_RECOVERY.md) · [RUNBOOK](docs/RUNBOOK.md) · [ANALYTICS_EVENTS](docs/ANALYTICS_EVENTS.md) · [PERFORMANCE](docs/PERFORMANCE.md) · [QA](docs/QA.md) · [DEPENDENCIES](docs/DEPENDENCIES.md) · [PRODUCTION_CHECKLIST](docs/PRODUCTION_CHECKLIST.md) · [CHANGELOG](CHANGELOG.md).

## Fase 9: logistica AsiaFood (Rider, dispatch, tracking)

Dettagli in [`docs/LOGISTICS.md`](docs/LOGISTICS.md). Migration `20261003000020_logistics_enums.sql` + `20261003000021_logistics.sql`, test `npm run test:logistics`.

- **Rider:** candidatura in 7 passi (`/rider/apply`, documenti in storage privato, nessuna approvazione automatica), app mobile-first `/rider`
  (online/offline con consenso posizione e indicatore "Posizione attiva", offerte con timeout, consegna passo per passo con navigazione
  esterna, codice di ritiro, OTP/foto/conferma di consegna, "Cliente non disponibile", "Ho un problema"), guadagni `/rider/earnings`.
- **Dispatch:** job creato all'accettazione degli ordini con `delivery_provider_type = asiafood`, ricerca a raggi crescenti 3→5→8→10 km,
  accettazione atomica (un solo Rider), riassegnazione prima del ritiro, dispatch manuale e control center `/admin/dispatch`.
- **Cliente e ristorante:** tracking con mappa ed ETA a intervallo (posizione del Rider solo dopo il ritiro), notifiche Rider assegnato /
  al ristorante / ritirato / vicino / consegnato, valutazione interna; nel terminale ristorante "Ricerca Rider in corso", "Rider in arrivo
  tra circa X min", codice di ritiro.
- **Admin:** `/admin/riders` (approva, rifiuta, sospendi, riattiva, documenti, note), `/admin/logistics` (metriche, compensi, regole, zone),
  `/admin/logistics/settings`.
- **DEMO:** accedi come "Rider (app consegne)" e scegli nel ristorante Seoul Grill House *Chi consegna → Rider AsiaFood*; la "flotta
  simulata" (dichiarata come tale) accetta e consegna da sola se il Rider demo è offline.

---

## Fase 8: ordini online (takeaway e delivery)

Dettagli completi in [`docs/ORDERS.md`](docs/ORDERS.md). Migration `20261002000018_orders_enums.sql` + `20261002000019_orders.sql`, test `npm run test:orders`.

- **Cliente:** menu ordinabile con varianti, extra, scelte obbligatorie e note; carrello di un solo ristorante (avviso "Hai già prodotti di un altro
  ristorante nel carrello."), barra fissa su mobile, `/cart`, `/checkout` (tipo, indirizzo verificato, orario ASAP o programmato,
  contatti, coupon/premi, riepilogo, pagamento), tracciamento `/orders/AF-…` in tempo reale, `/profile/orders`, riordina con verifica prezzi.
- **Pagamenti:** Stripe PaymentIntent (Payment Element), ordine pagato solo via webhook, Stripe Connect Express per i ristoranti,
  commissione salvata su ogni ordine, rimborsi totali/parziali. **Stripe resta in TEST** finché non si configura LIVE a mano.
- **Ristoratore:** `/dashboard/restaurants/:id/orders` (terminale con schede, accetta con tempo, rifiuta con motivo e rimborso automatico,
  stati fino a consegnato, stampa comanda, suono facoltativo, pausa/molto occupato, "Non disponibile oggi"),
  `/order-settings` (tipi, minimi, zone, orari, scelte del menu), `/payouts` (Configura pagamenti), statistiche senza dati personali.
- **Admin:** `/admin/orders` (filtri, dettaglio con cronologia, rimborsi, annullamento, resync Stripe, note interne, segnalazioni) e
  `/admin/marketplace` (GMV, AOV, ricavi, rimborsi, funnel, anomalie di pagamento, commissioni globali e per ristorante, scheduler).
- **Scoperta:** filtri "Ordina ora / Delivery disponibile / Takeaway disponibile" (`?order=now|delivery|takeaway`), sezione "Ordina adesso"
  in homepage, badge sulle card e sulla mappa, "Consegna qui" sulla mappa. L'assistente AI sa quali locali accettano ordini ma **non paga e non ordina**.
- **DEMO:** senza Supabase tutto funziona in locale con pagamento simulato (carta 4242 4242 4242 4242; 4000 0000 0000 0002 = rifiutata).
  Seoul Grill House (Massafra) ha ritiro e consegna, Ramen Kōen solo ritiro; il titolare demo gestisce entrambi.

---

## Fase 7: fidelizzazione (recensioni, AsiaPoints, inviti, notifiche, campagne)

Dettagli completi in [`docs/ENGAGEMENT.md`](docs/ENGAGEMENT.md). Migration `20261001000017_engagement.sql`, test `npm run test:engagement`.

- **Recensioni** solo da utenti registrati, "Visita verificata" solo con prenotazione completata o coupon utilizzato,
  1 ogni 90 giorni per locale, storico delle modifiche, moderazione umana, una risposta ufficiale del locale,
  voto "utile" e segnalazioni. Il voto medio è sempre calcolato ("Ancora nessuna recensione" se non ce ne sono).
- **AsiaPoints**: punti non monetari assegnati solo dal server per azioni reali (idempotenti, con limiti), livelli, premi con riscatto atomico, badge.
- **Inviti** `/invite/CODICE`: premio solo dopo email verificata e prima visita reale; autoinvito bloccato. Inviti B2B approvati dallo staff.
- **Notifiche** in-app (Realtime), push Web Push VAPID (permesso chiesto solo dopo un'azione), email via `email_outbox`, preferenze granulari.
  Promemoria prenotazione 24h/2h e coupon in scadenza.
- **Campagne** dei ristoranti (Premium/Top, `push_campaigns_enabled` + `monthly_campaign_limit`) e della piattaforma, solo con consenso,
  limite di frequenza settimanale, metriche reali.
- **Scheduler** `netlify/functions/engagement-cron.mts` ogni 15 minuti (`engagement_tick` + invio push).

**Push in produzione:** `npx web-push generate-vapid-keys` → imposta `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `PUSH_SUBJECT`
sulle variabili Netlify (mai con prefisso `VITE_`). Senza chiavi le notifiche in-app ed email funzionano comunque.

---

## Fase 6: AI Food Assistant (database-first)

**Principio.** L'assistente usa **solo dati reali della piattaforma**. Il modello linguistico non esegue SQL e non inventa:
interpreta (solo se il parser deterministico è incerto) e riformula; i dati arrivano da funzioni SQL controllate, e ogni
risposta del modello è **validata sul server** (JSON, ID esistenti, importi in € e distanze presenti nei dati, niente HTML/link).
Se la validazione fallisce, o il provider è lento/offline, si usa la risposta deterministica: l'assistente funziona anche senza modello.
Guida di configurazione: **[docs/AI_ASSISTANT.md](docs/AI_ASSISTANT.md)**.

```
browser ──POST /api/ai/chat──▶ Netlify Function (server/ai/aiRouter)
   (messaggio, id sessione casuale,     │ utente (JWT, facoltativo) · rate limit · sessione · cache
    JWT, posizione solo se serve)       ▼
                              shared/ai/engine  ── parser IT + date Europe/Rome (deterministici)
                                    │                 └─ modello (facoltativo): solo filtri validati
                                    ▼
                  tools: restaurantSearch · menuSearch · offersSearch · availability · location
                                    │  (RPC ai_search_* / get_reservation_availability: niente SQL libero)
                                    ▼
                  risposta: testo + ID → schede renderizzate dall'app (mai HTML dal modello)
```

| Pezzo | Dove |
|---|---|
| Endpoint | `POST /api/ai/chat` (`netlify/functions/ai-chat.mts`): `action` = `chat` · `history` · `delete` |
| Pulizia | `ai-cron` (giornaliera): conversazioni scadute, cache, utilizzo oltre 13 mesi |
| Provider | `server/ai/aiProvider.ts`: Anthropic, OpenAI, Gemini, compatibili OpenAI (`AI_BASE_URL`), `none` |
| Orchestratore | `shared/ai/engine.ts` (stesso codice in produzione e in modalità DEMO) |
| Interpretazione | `shared/ai/parse.ts`, `shared/ai/dates.ts` · prompt e validazione: `shared/ai/prompts.ts` |
| Strumenti | `server/ai/tools/*` (input validati) → `ai_search_restaurants`, `ai_search_menu`, `ai_search_offers`, `ai_restaurant_detail`, `get_reservation_availability` |
| UI | `/assistant`, pulsante "Chiedi ad AsiaFood" (header, Home, Esplora, Mappa, flottante su mobile), "Chiedi informazioni su questo ristorante" nella scheda |
| Admin | `/admin/ai`: richieste, token, costo stimato, errori, latenza, intenti, grafico, conversioni, configurazione (mai la chiave API) |
| Ristoratori | Statistiche → "Clienti arrivati dall'AI" (Premium/Top) |

**Regole deterministiche (mai lasciate al modello).** "Aperto ora" da orari con fasce spezzate, orari notturni, chiusure
straordinarie e chiusure temporanee (`restaurant_open_status`; senza orari → *orari non disponibili*). "Stasera", "domani",
"sabato", "questo weekend", "alle 21" → data concreta nel fuso Europe/Rome, mostrata all'utente. Budget: prezzo AYCE del pasto
(weekend se previsto) o prezzo medio, **mai stimato dalla fascia €€**, con la formula "compatibili con un budget indicativo di circa
25 € a persona"; i locali senza prezzo sono esclusi e contati. Confronti solo su fatti, senza vincitore. Prenotazioni: slot reali
verificati, **nessuna prenotazione automatica**: "Prenota" apre il flusso standard precompilato (`?date&time&party&src=ai`).
Offerte/coupon con le condizioni reali; "Ottieni coupon" usa il flusso standard (origine `ai`). Diete/allergie: solo i flag
dichiarati dal ristorante e sempre l'avviso di verificare con il locale.

**Sessioni e privacy.** ID di sessione casuale per scheda del browser (salvato solo come hash SHA-256); conversazioni
temporanee con conservazione configurabile (0 = non salvare i messaggi); le conversazioni di un utente registrato non sono
accessibili ad altri; eliminazione con "Nuova conversazione". La posizione si invia solo quando serve, arrotondata a ~100 m,
**mai salvata** (né in sessione, né nei log, né in cache). Preferenze facoltative (cucine, fascia di prezzo, esigenze
alimentari, città) modificabili ed eliminabili dal profilo; preferiti usati solo per utenti registrati. Nessun uso dei messaggi
per addestramento.

**Costi e limiti.** `ai_usage` registra provider, modello, token, costo stimato (prezzi per milione di token configurabili),
intento, esito, latenza. Limiti centralizzati in `platform_settings`: ospite 10/h, utente 30/h, titolari Premium/Top 60/h, più un
limite per rete (hash salato). Cache breve solo per richieste generiche (mai con posizione, utente, orari o disponibilità).

**Sicurezza.** Istruzioni di sistema, richiesta dell'utente e dati recuperati separati (`<data>` = dati non affidabili, ripuliti);
testo utente ripulito e limitato (500 caratteri, corpo max 8 KB); nessun SQL dal modello; chiavi solo nelle Functions; log senza
segreti né PII; sponsorizzati sempre **separati ed etichettati**, soggetti agli stessi filtri e mai passati al modello.

**Modalità DEMO.** Senza Supabase l'assistente gira nel browser con lo stesso motore sui dati di prova, senza modello
(risposte deterministiche, chiaramente indicate). Nessuna chiamata a provider esterni.

## Fase 5: SaaS B2B (Stripe Billing)

**Architettura.** Il browser chiama solo `/api/billing/*` (Netlify Functions) con il JWT Supabase e identificativi interni
(`restaurant_id`, codice piano, intervallo). Il server verifica utente e ruolo **titolare** nel DB, legge Price/Customer/Subscription
ID **dal database** (mai dal browser), parla con Stripe e scrive il DB con RPC riservate al `service_role`. Chiavi segrete
(`STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `SUPABASE_SERVICE_ROLE_KEY`) esistono solo nelle Functions: verificato che non
compaiono nel bundle. Configurazione passo passo: **[docs/STRIPE_SETUP.md](docs/STRIPE_SETUP.md)**.

| Endpoint | Funzione |
|---|---|
| `POST /api/billing/checkout` | `create-checkout-session`: prova gratuita (con o senza carta), promozioni B2B, Stripe Tax opzionale |
| `POST /api/billing/portal` | `create-customer-portal-session` (anche flusso "aggiorna metodo di pagamento") |
| `POST /api/billing/webhook` | firma verificata, idempotenza su `stripe_events`, ritentativi Stripe su errore |
| `POST /api/billing/actions` | anteprima/cambio piano, cancella, riattiva, annulla cambio programmato, conferma checkout, fatture |
| `POST /api/billing/admin` | stato, sincronizza (una o tutte), estendi prova, crea/aggiorna prezzi su Stripe |
| `billing-cron` (ogni ora) | fine tolleranza/periodo, scadenze manuali, avvisi fine prova |

**Piano effettivo.** `restaurant_effective_plan()` decide dal DB: `active`/`trialing` → piano; `past_due` → piano per
`payment_grace_period_days` (default 3) dal primo pagamento fallito, poi Free; `canceled` → fino a fine periodo già pagato;
concessioni Admin/manuali/promo fino alla scadenza. `restaurants.subscription_plan` ne è la cache (trigger + cron) e non si
imposta più a mano. `hasFeature()` e le regole DB leggono il piano effettivo. Ambienti test/live separati (`stripe_environment`).

**Prove gratuite.** Durata dall'Admin (default 30 giorni), `require_payment_method_for_trial` configurabile; una sola prova per
locale, per utente e per Partita IVA (`billing_trials`). Senza carta, alla fine della prova Stripe cancella e il locale torna Free.

**Upgrade / downgrade / cancellazione.** Upgrade immediato con addebito proporzionale (anteprima mostrata prima di confermare;
se la carta viene rifiutata il piano non cambia). Downgrade e annuale→mensile a fine ciclo con Subscription Schedule
("Il tuo piano passerà a Business il …"). Cancellazione con `cancel_at_period_end` e riattivazione prima della scadenza.
Mai subscription duplicate: il cambio intervallo aggiorna la stessa.

**Account di fatturazione.** `billing_accounts`: un cliente Stripe per titolare, più abbonamenti (uno per locale) → multi-location.
Dati italiani privati: ragione sociale, P.IVA, CF, indirizzo, CAP, comune, provincia, paese (IT), PEC, codice destinatario.

**Onboarding.** Wizard in 8 passi (`/dashboard/restaurants/:id/onboarding`) e checklist "Completa il tuo profilo" con
`profile_completion_percentage` calcolato dal DB (le voci non incluse nel piano non contano).

**Sponsorizzazioni (AsiaFood Ads).** `sponsored_campaigns` gestite dall'Admin (`/admin/sponsorships`): stato, placement
(`home_featured`, `search_top`, `category_top`, `city_top`, `map_featured`, `offers_featured`), date, priorità, budget e spesa
(fatturazione manuale), targeting comuni/categorie. Gli slot sono **separati dai risultati organici** e sempre etichettati
"Sponsorizzato"; in ricerca compaiono solo se il locale è già tra i risultati pertinenti. Eventi `sponsored_impression`
(≥50% visibile per 1 s, max 1 ogni 30 min per sessione) e `sponsored_click`, deduplicati anche lato server, senza fingerprint.
Dashboard campagne per il piano Top (`/dashboard/restaurants/:id/ads`) con impression, click, CTR e spesa reali.

**Ricavi (Admin).** MRR solo da abbonamenti Stripe attivi/in tolleranza (annuali /12), ARR stimato, nuovo MRR, MRR perso,
prove attive, conversione prova→pagante, cancellazioni, grafico MRR 12 mesi (zero se non ci sono dati).

**Modalità DEMO.** Senza Supabase il checkout, il portale e gli eventi Stripe sono **simulati** nel browser, chiaramente
etichettati, senza dati di carta: servono a provare tutti i flussi. In produzione non vengono mai usati.

## Fase 4: menu, prenotazioni, offerte, coupon, statistiche, piani

**Piani e funzioni.** (Fase 4, attivazione ora via Stripe o concessione Admin) Le regole non sono scritte nel codice: tabella `plan_features` (`plan_code`, `feature_key`, `enabled`,
`limit_value`, `null` = illimitato), modificabile da **Admin → Piani** (`/admin/plans`) insieme ai prezzi (Free 0 €, Business 29,90 €,
Premium 59,90 €, Top 99,90 € al mese). Il frontend usa solo `hasFeature` / `getFeatureLimit` (`src/lib/entitlements.ts`,
`useEntitlements`); il database applica le stesse regole con `restaurant_has_feature` / `assert_feature` / `assert_limit` nei trigger
e nelle RPC, quindi aggirare l'interfaccia non serve. Quando una funzione manca compare il modale
“Questa funzione è disponibile con il piano Premium.” → **Scopri i piani** (`/dashboard/plans`, lista d'attesa: “Pagamenti online in arrivo”).
L'Admin attiva il piano a mano dalla richiesta. Stripe: colonne pronte, nessuna chiave richiesta.

**Menu digitale.** Più menu per locale (principale, pranzo, cena, AYCE, bevande, dessert, asporto, stagionale) con validità,
categorie, piatti (prezzo, prezzo scontato, pezzi, disponibilità, in evidenza, vegetariano/vegano/senza glutine/piccante, ingredienti),
varianti, aggiunte e i **14 allergeni UE**. Pagina pubblica: categorie sticky con scroll alla sezione, filtri dieta, “Cerca nel menu”.
Editor: crea, modifica, duplica (piatto o menu), riordina, nascondi, non disponibile, prezzo rapido, immagine.
**Import CSV/JSON** con anteprima e template scaricabile (nessun OCR). Il menu resta dentro la scheda del locale (SEO).

**Prenotazioni.** `reservation_settings` (attive, conferma automatica, persone min/max, anticipo minimo, giorni prenotabili,
durata, messaggio), `reservation_slots` (fasce con `max_reservations` per orario e `max_guests` per fascia), `restaurant_closures`.
`get_reservation_availability` calcola gli orari; `create_reservation` rivalida tutto lato server, usa un **advisory lock** per
impedire l'overbooking, applica limiti anti-abuso (per email/utente e per locale) e restituisce il codice `ASF-XXXXX`.
Ospiti ammessi (nome, email, telefono). Il ristoratore gestisce tutto da **Prenotazioni**: schede Oggi / Domani / Prossime /
Passate / Cancellate, azioni Conferma / Rifiuta / Completata / No show / Cancella, agenda del giorno, inserimento manuale (telefono).

**Email.** Ogni evento (`reservation_created`, `_confirmed`, `_rejected`, `_cancelled` e avviso al locale) finisce in `email_outbox`
dentro la stessa transazione, ma **non blocca mai** la prenotazione. La Edge Function `send-emails` invia la coda con il provider
scelto. Configurazione:
```bash
npx supabase functions deploy send-emails --no-verify-jwt
npx supabase secrets set EMAIL_PROVIDER=resend EMAIL_API_KEY=re_xxx EMAIL_FROM="AsiaFood <noreply@tuodominio.it>" SITE_URL=https://asiafood.netlify.app
```
Poi pianifica la chiamata ogni minuto (Dashboard → Integrations → Cron, oppure `pg_cron` + `pg_net`). Senza provider le email
restano in coda (`status = pending`) e nulla si rompe. Le notifiche in-app (`notifications`) funzionano comunque.

**Offerte e coupon.** Offerte con tipo (percentuale, importo fisso, menu speciale, 2x1, happy hour, promo AYCE, piatto omaggio, altro),
spesa minima, giorni e fasce orarie, in evidenza, limite utilizzi. Coupon: “Ottieni coupon” (utente o ospite con email), codice
univoco (es. `SUSHI20-X7P4`) + QR, limiti per utente e totali, validazione dal ristoratore (**Valida coupon**, codice o QR) con
`redeem_coupon`. La pagina di un coupon riscattato è `noindex`.

**Statistiche.** `analytics_events` con i nuovi nomi (`restaurant_view`, `menu_view`, `phone_click`, `whatsapp_click`,
`directions_click`, `reservation_start`, `reservation_completed`, `offer_view`, `coupon_claim`, …) e `session_id` anonimo; l'ID utente
non viene salvato. Le conversioni (prenotazione completata, coupon ottenuto) le scrive solo il server. Sezione **Statistiche**
a 7/30/90 giorni: se un dato è zero si vede zero. **Panoramica attività** con carte riassuntive e **Azioni consigliate**.

## Dati reali: flusso di lavoro

1. Raccogli i locali da fonti pubbliche (sito ufficiale, Google Business Profile, Facebook/Instagram ufficiali). Dato non verificabile = vuoto.
2. Importa da **Admin → Importa** (o `npm run import`). I nuovi locali entrano **in bozza**, con fonte registrata.
   Un primo dataset è in `data/import/taranto-fonti-pubbliche-2026-09.json` (14 locali, tutti da verificare).
3. Apri ogni bozza, controlla i dati sulla fonte, completa (orari, coordinate) e premi **Verifica e pubblica** (sezione Stato).
4. Quando i locali reali sono sufficienti: Admin → Panoramica → disattiva **Mostra i dati demo al pubblico**.
5. Le segnalazioni degli utenti e le date "ultima verifica" aiutano l'aggiornamento continuo.

## Fuori scope (predisposto, non implementato)

Delivery proprietario · pagamento ordini clienti · loyalty/punti · recensioni complete · voice AI completa (l'interfaccia è predisposta, nessun microfono finto) · ricerca semantica con embedding/pgvector (interfaccia predisposta) · notifiche push · Ads CPC automatico · wallet · fatturazione elettronica SdI (solo dati predisposti).
Google Places: campo `google_place_id` e tipi di fonte pronti, nessuna chiamata API attiva.

## Prossimi passi consigliati

1. **Verifica e pubblicazione** del dataset iniziale e censimento del resto della provincia.
2. **Attivare le email**: deploy di `send-emails`, chiave del provider, cron ogni minuto; estendere ai claim.
3. **Google Places API** (lato server, Edge Function) per suggerire coordinate, orari e stato attività durante la verifica, nel rispetto dei termini d'uso.
4. **Prerendering SEO** delle pagine pubbliche per anteprime social e indicizzazione più rapida.
5. **Stripe in test mode end-to-end** (docs/STRIPE_SETUP.md), poi fatturazione elettronica SdI e Ads self-service.
6. **Assistente AI in produzione** (docs/AI_ASSISTANT.md): scegliere provider/modello, calibrare i costi per milione di token, osservare `/admin/ai` (nessun risultato, fallback) e arricchire i dati (orari, prezzi, menu strutturati) dove l'assistente trova lacune.
