/* eslint-disable @typescript-eslint/no-explicit-any */
// ─────────────────────────────────────────────────────────────
//  Test end-to-end della fatturazione (Fase 5).
//  Esegue i VERI handler (server/billing) contro le VERE migrazioni
//  (Postgres in-memory, PGlite) con uno Stripe simulato in memoria.
//  I webhook sono firmati e verificati con la libreria Stripe reale.
//  Uso: npm run test:billing
// ─────────────────────────────────────────────────────────────
import { PGlite } from '@electric-sql/pglite';
import { pg_trgm } from '@electric-sql/pglite/contrib/pg_trgm';
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto';
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  billingActions,
  billingAdmin,
  billingCron,
  createCheckoutSession,
  createCustomerPortalSession,
  stripeWebhook,
} from '../server/billing/handlers';
import type { BillingDeps, Handler, HttpResponse, Store } from '../server/billing/types';
import { resolveStripeEnvironment } from '../server/billing/runtime';
import { FakeStripe, type FakeEvent } from './lib/fake-stripe';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../supabase');
const db = new PGlite({ extensions: { pg_trgm, pgcrypto } });
await db.exec(`
create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
create schema auth; create schema storage;
create table auth.users (id uuid primary key, email text, raw_user_meta_data jsonb default '{}', email_confirmed_at timestamptz);
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
create function auth.role() returns text language sql stable as $$ select nullif(current_setting('request.jwt.claim.role', true), '') $$;
create table storage.buckets (id text primary key, name text, public boolean, file_size_limit bigint, allowed_mime_types text[]);
create table storage.objects (id uuid primary key default gen_random_uuid(), bucket_id text, name text, owner uuid);
alter table storage.objects enable row level security;
create function storage.foldername(name text) returns text[] language sql immutable as $$ select (string_to_array(name, '/'))[1:array_length(string_to_array(name,'/'),1)-1] $$;
grant usage on schema public, auth, storage to anon, authenticated, service_role;
grant all on storage.objects to anon, authenticated;
grant execute on all functions in schema auth to anon, authenticated, service_role;
`);
for (const f of readdirSync(`${root}/migrations`).sort()) await db.exec(readFileSync(`${root}/migrations/${f}`, 'utf8'));
await db.exec(readFileSync(`${root}/seed.sql`, 'utf8'));
await db.exec('grant all on all tables in schema public to service_role; grant usage on all sequences in schema public to service_role;');

const U = {
  admin: '11111111-1111-4111-8111-111111111111',
  ownerA: '22222222-2222-4222-8222-222222222222',
  ownerB: '66666666-6666-4666-8666-666666666666',
  cust: '33333333-3333-4333-8333-333333333333',
  mgr: '55555555-5555-4555-8555-555555555555',
};
for (const [k, id] of Object.entries(U)) await db.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1, $2, '{"full_name":"${k}"}')`, [id, `${k}@test.it`]);
await db.exec(`update public.profiles set role='admin' where id='${U.admin}'`);
const R = (n: number) => `e0000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const [RA, RA2, RB, RM] = [R(3), R(4), R(6), R(7)];
await db.exec(`
insert into public.restaurant_members (restaurant_id, user_id, role, status) values
  ('${RA}', '${U.ownerA}', 'owner', 'active'), ('${RA2}', '${U.ownerA}', 'owner', 'active'),
  ('${RB}', '${U.ownerB}', 'owner', 'active'), ('${RM}', '${U.mgr}', 'manager', 'active');
`);

// ── Store = RPC eseguite come service_role (come le Netlify Functions) ──
const SETOF = new Set(['billing_stripe_subscription_ids']);
const store: Store = {
  async rpc<T>(fn: string, args: Record<string, unknown>) {
    const keys = Object.keys(args);
    const call = `public.${fn}(${keys.map((k, i) => `${k} => $${i + 1}`).join(', ')})`;
    const sql = SETOF.has(fn) ? `select coalesce(array(select * from ${call}), '{}') as r` : `select ${call} as r`;
    const params = keys.map((k) => {
      const v = args[k];
      return v !== null && typeof v === 'object' ? JSON.stringify(v) : v;
    });
    await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', 'service_role', false); set role service_role;`);
    try {
      const res = await db.query<{ r: T }>(sql, params);
      return res.rows[0]!.r;
    } finally {
      await db.exec('reset role;');
    }
  },
};
const q1 = async <T = Record<string, unknown>>(sql: string) => (await db.query<T>(sql)).rows[0]!;

const stripe = new FakeStripe();
const WEBHOOK_SECRET = 'whsec_test_asiafood_billing';
const logs: string[] = [];
const deps: BillingDeps = {
  stripe: stripe.asStripe(),
  store,
  config: { env: 'test', appUrl: 'https://asiafood.test', webhookSecret: WEBHOOK_SECRET, taxEnabled: false, portalConfigurationId: null, allowPromotionCodes: false },
  verifyUser: async (t) => (t?.startsWith('tok-') ? t.slice(4) : null),
  log: (level, message, data) => logs.push(`${level} ${message} ${JSON.stringify(data ?? {})}`),
};
await store.rpc('billing_set_environment', { p_env: 'test' });

async function call(h: Handler, user: string | null, body: Record<string, unknown>, method = 'POST'): Promise<HttpResponse & { json: Record<string, any> }> {
  const res = await h({ method, header: (n) => (n === 'authorization' && user ? `Bearer tok-${user}` : null), body: JSON.stringify(body) }, deps);
  return { ...res, json: res.body as Record<string, any> };
}
async function deliver(events: FakeEvent[] = stripe.drain()) {
  const out: HttpResponse[] = [];
  for (const e of events) {
    const { payload, header } = stripe.sign(e, WEBHOOK_SECRET);
    out.push(await stripeWebhook({ method: 'POST', header: (n) => (n === 'stripe-signature' ? header : null), body: payload }, deps));
  }
  return out;
}
const effective = async (rid: string) => (await q1<{ p: string; c: string }>(`select public.restaurant_effective_plan('${rid}') p, (select subscription_plan from public.restaurants where id='${rid}') c`));
const sub = async (rid: string): Promise<Record<string, any> | null> =>
  (await db.query<Record<string, any>>(`select * from public.subscriptions where restaurant_id='${rid}' and source='stripe' order by created_at desc limit 1`)).rows[0] ?? null;
const activity = async (rid: string, ev: string) => (await q1<{ n: number }>(`select count(*)::int n from public.billing_activity where restaurant_id='${rid}' and event='${ev}'`)).n;

let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) {
    pass++;
    console.log('  ✓', name);
  } else {
    fail++;
    console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 600) : '');
  }
}

// ════════════════════════════════════════════════════════════════════
console.log('\n— Configurazione e sicurezza degli endpoint');
check('chiave test → ambiente test', resolveStripeEnvironment('sk_test_123', '') === 'test');
let threw = false;
try {
  resolveStripeEnvironment('sk_live_123', 'test');
} catch {
  threw = true;
}
check('STRIPE_MODE=test con chiave live → rifiutato (mai live per errore)', threw);
let r = await call(createCheckoutSession, null, { restaurant_id: RA, plan: 'business', billing_interval: 'month' });
check('checkout senza login → 401', r.status === 401 && r.json.error === 'UNAUTHORIZED', r);
r = await call(createCheckoutSession, U.ownerA, { restaurant_id: RA, plan: 'business', billing_interval: 'month' }, 'GET');
check('metodo non consentito → 405', r.status === 405, r);
r = await call(createCheckoutSession, U.ownerA, { restaurant_id: 'not-a-uuid', plan: 'business', billing_interval: 'month' });
check('input non valido → 400', r.status === 400 && r.json.error === 'BAD_REQUEST', r);
r = await call(createCheckoutSession, U.ownerA, { restaurant_id: RA, plan: 'business', billing_interval: 'month' });
check('prezzo non ancora configurato → messaggio chiaro', r.status === 409 && r.json.error === 'PRICE_NOT_CONFIGURED' && /non è ancora acquistabile/.test(r.json.message), r);
r = await call(billingAdmin, U.ownerA, { action: 'provision_prices' });
check('crea prezzi su Stripe: solo Admin', r.status === 403, r);
r = await call(billingAdmin, U.admin, { action: 'provision_prices' });
const plans = r.json.plans ?? {};
check('Admin crea prodotti e prezzi Stripe dai prezzi del DB', r.status === 200 && plans.business?.monthly && plans.premium?.yearly && plans.top?.monthly, r);
const priceRow = await q1<Record<string, string>>(`select stripe_monthly_price_id m, stripe_yearly_price_id y from public.subscription_plans where code='business'`);
check('Price ID salvati nel DB (2990 / 29900 cent)', stripe.prices.get(priceRow.m)?.unit_amount === 2990 && stripe.prices.get(priceRow.y)?.unit_amount === 29900, priceRow);
r = await call(billingAdmin, U.admin, { action: 'provision_prices' });
check('ripetere il provisioning non duplica i prezzi', stripe.prices.size === 6, stripe.prices.size);
r = await call(createCheckoutSession, U.cust, { restaurant_id: RA, plan: 'business', billing_interval: 'month' });
check('cliente qualsiasi → 403', r.status === 403 && r.json.error === 'FORBIDDEN', r);
r = await call(createCheckoutSession, U.ownerB, { restaurant_id: RA, plan: 'business', billing_interval: 'month' });
check('ristorante non appartenente all’utente → 403', r.status === 403, r);
r = await call(createCheckoutSession, U.mgr, { restaurant_id: RM, plan: 'business', billing_interval: 'month' });
check('manager (non titolare) non può abbonare il locale', r.status === 403, r);

console.log('\n— Free');
const ov = await q1<{ o: any }>(`select to_jsonb(public.restaurant_effective_plan('${RA}')) o`);
check('locale senza abbonamento = Free', ov.o === 'free');
check('Free: nessuna subscription Stripe', (await sub(RA)) === null);

console.log('\n— Business: checkout con prova gratuita senza carta');
r = await call(createCheckoutSession, U.ownerA, { restaurant_id: RA, plan: 'business', billing_interval: 'month', price_id: 'price_EVIL', customer: 'cus_EVIL' });
const csA = r.json.session_id as string;
const paramsA = stripe.sessions.get(csA)?._params;
check('checkout creato (URL Stripe)', r.status === 200 && /^https:\/\/checkout\.stripe\.com\//.test(r.json.url), r);
check('Price ID dal DB, non dal browser', paramsA?.line_items[0].price === priceRow.m);
check('cliente Stripe creato dal server (non dal browser)', paramsA?.customer !== 'cus_EVIL' && stripe.customers.has(paramsA?.customer));
check('prova 30 giorni senza carta (payment_method_collection = if_required)', paramsA?.subscription_data.trial_period_days === 30 && paramsA?.payment_method_collection === 'if_required', paramsA);
check('metadata con restaurant_id per il webhook', paramsA?.subscription_data.metadata.restaurant_id === RA);
check('URL di ritorno success/cancel', paramsA?.success_url.includes('/dashboard/billing/success?session_id={CHECKOUT_SESSION_ID}') && paramsA?.cancel_url.includes('/dashboard/billing/cancel'));
const again = await call(createCheckoutSession, U.ownerA, { restaurant_id: RA, plan: 'business', billing_interval: 'month' });
check('doppio click: stessa sessione (idempotenza), un solo cliente Stripe', again.json.session_id === csA && stripe.customers.size === 1, again.json);
check('success page prima del webhook: nessun piano attivato', (await effective(RA)).c === 'free');
const subA = stripe.completeCheckout(csA, { card: false });
const webhooks = await deliver();
check('webhook firmati accettati', webhooks.every((w) => w.status === 200), webhooks);
const sA = await sub(RA);
check('webhook → prova Business attiva (trialing)', sA?.status === 'trialing' && (await effective(RA)).c === 'business' && !!sA?.trial_end, sA);
check('trial_start / trial_end registrati', !!sA?.trial_start && Date.parse(sA.trial_end) - Date.parse(sA.trial_start) > 29 * 864e5);
check('feature sbloccate (offerte Business)', (await q1<{ f: boolean }>(`select public.restaurant_has_feature('${RA}', 'offers_enabled') f`)).f === true);
r = await call(billingActions, U.ownerA, { action: 'confirm_checkout', session_id: csA });
check('pagina success: conferma letta da Stripe lato server', r.status === 200 && r.json.status === 'complete' && r.json.effective_plan === 'business' && r.json.plan_code === 'business', r.json);
r = await call(billingActions, U.ownerB, { action: 'confirm_checkout', session_id: csA });
check('sessione di un altro locale → 403', r.status === 403, r);
const dup = await deliver(stripe.events.length ? stripe.drain() : []);
void dup;
const replay = stripe.sign({ id: (await q1<{ id: string }>(`select stripe_event_id id from public.stripe_events order by created_at limit 1`)).id, type: 'customer.subscription.created', livemode: false, created: 0, data: { object: { id: subA } }, object: 'event', api_version: 'x' }, WEBHOOK_SECRET);
const rep = await stripeWebhook({ method: 'POST', header: (n) => (n === 'stripe-signature' ? replay.header : null), body: replay.payload }, deps);
check('evento già elaborato → ignorato (idempotenza)', rep.status === 200 && (rep.body as any).duplicate === true, rep);
check('un solo evento trial_started', (await activity(RA, 'trial_started')) === 1);

console.log('\n— Sicurezza webhook');
let bad = await stripeWebhook({ method: 'POST', header: () => 't=1,v1=deadbeef', body: '{"id":"evt_x"}' }, deps);
check('firma non valida → 400', bad.status === 400);
const liveEvt = stripe.sign({ id: 'evt_LiveOne', type: 'invoice.paid', livemode: true, created: 0, data: { object: { id: 'in_x' } }, object: 'event', api_version: 'x' }, WEBHOOK_SECRET);
bad = await stripeWebhook({ method: 'POST', header: (n) => (n === 'stripe-signature' ? liveEvt.header : null), body: liveEvt.payload }, deps);
check('evento live con backend in test → ignorato (ambienti separati)', bad.status === 200 && (bad.body as any).ignored === 'environment');
const other = stripe.sign({ id: 'evt_Other1', type: 'charge.refunded', livemode: false, created: 0, data: { object: { id: 'ch_1' } }, object: 'event', api_version: 'x' }, WEBHOOK_SECRET);
bad = await stripeWebhook({ method: 'POST', header: (n) => (n === 'stripe-signature' ? other.header : null), body: other.payload }, deps);
check('evento non gestito → registrato come ignorato', bad.status === 200 && (await q1<{ s: string }>(`select processing_status s from public.stripe_events where stripe_event_id='evt_Other1'`)).s === 'ignored');

console.log('\n— Checkout annullato');
r = await call(createCheckoutSession, U.ownerA, { restaurant_id: RA2, plan: 'premium', billing_interval: 'month' });
const csCancel = r.json.session_id;
check('seconda attività dello stesso titolare: niente seconda prova', stripe.sessions.get(csCancel)?._params.subscription_data.trial_period_days === undefined && r.json.trial_days === 0, r.json);
r = await call(billingActions, U.ownerA, { action: 'confirm_checkout', session_id: csCancel });
check('checkout non completato: piano invariato (Free)', r.json.status === 'open' && (await effective(RA2)).c === 'free', r.json);

console.log('\n— Premium: checkout con carta e primo pagamento');
stripe.completeCheckout(csCancel, { card: true });
await deliver();
let sA2 = await sub(RA2);
check('Premium attivo dopo il webhook', sA2?.status === 'active' && (await effective(RA2)).c === 'premium', sA2);
check('carta salvata in forma sicura (marca + ultime 4)', sA2?.pm_brand === 'visa' && sA2?.pm_last4 === '4242' && !JSON.stringify(sA2).includes('4242424242424242'));
check('fattura registrata con link Stripe', (await q1<{ n: number }>(`select count(*)::int n from public.billing_invoices where restaurant_id='${RA2}' and status='paid' and hosted_invoice_url like 'https://%'`)).n === 1);
check('un solo cliente Stripe per titolare (multi-locale)', stripe.customers.size === 1);

console.log('\n— Top annuale: prova con carta obbligatoria (impostazione Admin)');
await db.exec(`update public.platform_settings set value='true' where key='billing_require_payment_method_for_trial'`);
r = await call(createCheckoutSession, U.ownerB, { restaurant_id: RB, plan: 'top', billing_interval: 'year' });
const csB = r.json.session_id;
check('prova con carta: payment_method_collection = always', stripe.sessions.get(csB)?._params.payment_method_collection === 'always' && stripe.sessions.get(csB)?._params.subscription_data.trial_period_days === 30);
let threwCard = false;
try {
  stripe.completeCheckout(csB, { card: false });
} catch {
  threwCard = true;
}
check('senza carta il checkout non si completa', threwCard);
const subB = stripe.completeCheckout(csB, { card: true });
await deliver();
check('Top in prova', (await sub(RB))?.status === 'trialing' && (await effective(RB)).c === 'top');
await db.exec(`update public.platform_settings set value='false' where key='billing_require_payment_method_for_trial'`);
r = await call(billingAdmin, U.ownerB, { action: 'extend_trial', subscription_id: (await sub(RB))!.id, days: 7 });
check('estendi prova: solo Admin', r.status === 403);
const trialEndBefore = Date.parse((await sub(RB))!.trial_end);
r = await call(billingAdmin, U.admin, { action: 'extend_trial', subscription_id: (await sub(RB))!.id, days: 7 });
check('Admin estende la prova di 7 giorni (su Stripe)', r.status === 200 && Date.parse((await sub(RB))!.trial_end) - trialEndBefore >= 7 * 864e5 - 5000, r.json);
stripe.drain();
stripe.endTrial(subB);
await deliver();
const sB = await sub(RB);
check('fine prova con carta → attivo + fattura (conversione)', sB?.status === 'active' && (await activity(RB, 'trial_ended')) === 1 && (await activity(RB, 'subscription_started')) === 1, sB);
check('conversione trial → paid registrata', !!(await q1<{ c: string }>(`select converted_at c from public.billing_trials where restaurant_id='${RB}'`)).c);

console.log('\n— Upgrade Premium → Top (addebito immediato della differenza)');
r = await call(billingActions, U.ownerA, { action: 'preview_change', restaurant_id: RA2, plan: 'top', billing_interval: 'month' });
check('anteprima upgrade: immediato con importo', r.status === 200 && r.json.kind === 'upgrade' && r.json.immediate === true && r.json.amount_due_cents > 0 && r.json.amount_due_cents <= 9990 - 5990, r.json);
stripe.declineNext = true;
r = await call(billingActions, U.ownerA, { action: 'change_plan', restaurant_id: RA2, plan: 'top', billing_interval: 'month' });
check('carta rifiutata: errore chiaro e piano invariato', r.status === 402 && r.json.error === 'PAYMENT_FAILED' && (await effective(RA2)).c === 'premium', r.json);
r = await call(billingActions, U.ownerA, { action: 'change_plan', restaurant_id: RA2, plan: 'top', billing_interval: 'month' });
await deliver();
check('upgrade applicato subito → Top', r.status === 200 && r.json.status === 'updated' && (await effective(RA2)).c === 'top' && (await activity(RA2, 'subscription_upgraded')) === 1, r.json);
check('fattura della differenza registrata', (await q1<{ n: number }>(`select count(*)::int n from public.billing_invoices where restaurant_id='${RA2}'`)).n === 2);
r = await call(billingActions, U.ownerA, { action: 'change_plan', restaurant_id: RA2, plan: 'top', billing_interval: 'month' });
check('stesso piano → errore esplicito', r.status === 400 && r.json.error === 'SAME_PLAN', r.json);

console.log('\n— Downgrade Top → Business (a fine ciclo)');
r = await call(billingActions, U.ownerA, { action: 'preview_change', restaurant_id: RA2, plan: 'business', billing_interval: 'month' });
check('anteprima downgrade: a fine periodo, nessun addebito', r.json.kind === 'downgrade' && r.json.immediate === false && r.json.amount_due_cents === 0 && !!r.json.effective_at, r.json);
r = await call(billingActions, U.ownerA, { action: 'change_plan', restaurant_id: RA2, plan: 'business', billing_interval: 'month' });
await deliver();
sA2 = await sub(RA2);
check('downgrade programmato (Subscription Schedule), funzioni Top mantenute', r.json.status === 'scheduled' && sA2?.scheduled_plan_code === 'business' && !!sA2?.stripe_schedule_id && (await effective(RA2)).c === 'top', { r: r.json, s: sA2?.scheduled_plan_code });
r = await call(billingActions, U.ownerA, { action: 'cancel_scheduled_change', restaurant_id: RA2 });
await deliver();
check('annulla il downgrade programmato', r.status === 200 && (await sub(RA2))?.scheduled_plan_code === null, r.json);
await call(billingActions, U.ownerA, { action: 'change_plan', restaurant_id: RA2, plan: 'business', billing_interval: 'month' });
await deliver();
stripe.reachPeriodEnd((await sub(RA2))!.stripe_subscription_id);
await deliver();
check('a fine ciclo: Business', (await effective(RA2)).c === 'business' && (await sub(RA2))?.scheduled_plan_code === null && (await activity(RA2, 'subscription_downgraded')) === 1);

console.log('\n— Cambio mensile ↔ annuale (stessa subscription)');
const subIdA2 = (await sub(RA2))!.stripe_subscription_id;
r = await call(billingActions, U.ownerA, { action: 'preview_change', restaurant_id: RA2, plan: 'business', billing_interval: 'year' });
check('mensile → annuale: immediato con addebito annuale al netto del credito', r.json.kind === 'interval_up' && r.json.immediate && r.json.amount_due_cents > 0 && r.json.amount_due_cents <= 29900, r.json);
await call(billingActions, U.ownerA, { action: 'change_plan', restaurant_id: RA2, plan: 'business', billing_interval: 'year' });
await deliver();
check('ora annuale, nessuna subscription duplicata', (await sub(RA2))?.billing_interval === 'year' && (await sub(RA2))?.stripe_subscription_id === subIdA2 && stripe.subs.size === 3);
r = await call(billingActions, U.ownerA, { action: 'change_plan', restaurant_id: RA2, plan: 'business', billing_interval: 'month' });
await deliver();
check('annuale → mensile: a fine periodo', r.json.status === 'scheduled' && (await sub(RA2))?.scheduled_interval === 'month' && (await sub(RA2))?.billing_interval === 'year', r.json);
await call(billingActions, U.ownerA, { action: 'cancel_scheduled_change', restaurant_id: RA2 });
await deliver();

console.log('\n— Pagamento fallito e recupero');
stripe.failRenewal(subIdA2);
await deliver();
check('rinnovo fallito: past_due, periodo di tolleranza (piano mantenuto)', (await sub(RA2))?.status === 'past_due' && (await effective(RA2)).c === 'business' && (await activity(RA2, 'payment_failed')) === 1);
check('notifica "Problema con il pagamento del tuo abbonamento."', (await q1<{ n: number }>(`select count(*)::int n from public.notifications where restaurant_id='${RA2}' and title like 'Problema con il pagamento%'`)).n >= 1);
stripe.payOpenInvoice(subIdA2);
await deliver();
check('carta aggiornata → pagamento recuperato', (await sub(RA2))?.status === 'active' && (await activity(RA2, 'payment_recovered')) === 1 && (await sub(RA2))?.payment_failed_at === null);

console.log('\n— Cancellazione a fine periodo e riattivazione');
r = await call(billingActions, U.ownerB, { action: 'cancel', restaurant_id: RB });
await deliver();
check('cancel_at_period_end = true, accesso fino a fine periodo', r.status === 200 && (await sub(RB))?.cancel_at_period_end === true && (await effective(RB)).c === 'top' && !!r.json.until, r.json);
r = await call(billingActions, U.ownerB, { action: 'resume', restaurant_id: RB });
await deliver();
check('riattiva abbonamento', r.status === 200 && (await sub(RB))?.cancel_at_period_end === false && (await activity(RB, 'subscription_resumed')) === 1);
await call(billingActions, U.ownerB, { action: 'cancel', restaurant_id: RB });
await deliver();
stripe.reachPeriodEnd(subB);
await deliver();
check('subscription deleted a fine periodo → Free', (await sub(RB))?.status === 'canceled' && (await effective(RB)).c === 'free' && (await activity(RB, 'subscription_ended')) === 1);
r = await call(billingActions, U.ownerB, { action: 'cancel', restaurant_id: RB });
check('nessun abbonamento attivo da cancellare → messaggio chiaro', r.status === 404 && r.json.error === 'SUBSCRIPTION_NOT_FOUND', r.json);

console.log('\n— Fine prova');
stripe.endTrial(subA);
await deliver();
check('prova Business: il cliente Stripe ha già una carta (altro locale) → addebito e attivazione', (await sub(RA))?.status === 'active' && (await effective(RA)).c === 'business');
// Nuovo titolare senza carta: la prova termina e il locale torna Free
const ownerC = '77777777-7777-4777-8777-777777777777';
const RC = R(10);
await db.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1, 'ownerc@test.it', '{"full_name":"ownerC"}')`, [ownerC]);
await db.exec(`insert into public.restaurant_members (restaurant_id, user_id, role, status) values ('${RC}', '${ownerC}', 'owner', 'active')`);
r = await call(createCheckoutSession, ownerC, { restaurant_id: RC, plan: 'business', billing_interval: 'month' });
const subC = stripe.completeCheckout(r.json.session_id, { card: false });
await deliver();
check('nuovo titolare: prova senza carta', (await sub(RC))?.status === 'trialing' && (await sub(RC))?.pm_last4 === null);
stripe.endTrial(subC);
await deliver();
check('prova terminata senza carta → Free (nessun trial infinito)', (await sub(RC))?.status === 'canceled' && (await effective(RC)).c === 'free' && (await activity(RC, 'trial_ended')) === 1);
r = await call(createCheckoutSession, ownerC, { restaurant_id: RC, plan: 'business', billing_interval: 'month' });
check('nuovo checkout sullo stesso locale: nessuna nuova prova', r.status === 200 && r.json.trial_days === 0, r.json);

console.log('\n— Customer Portal');
r = await call(createCustomerPortalSession, U.ownerA, { restaurant_id: RA2 });
check('portale: URL Stripe, ritorno alla pagina Fatturazione', r.status === 200 && /^https:\/\/billing\.stripe\.com\//.test(r.json.url) && stripe.calls.at(-1)?.params.return_url.endsWith(`/dashboard/restaurants/${RA2}/billing`), r.json);
r = await call(createCustomerPortalSession, U.ownerA, { restaurant_id: RA2, flow: 'payment_method_update' });
check('portale: flusso "aggiorna metodo di pagamento"', r.status === 200 && stripe.calls.at(-1)?.params.flow_data?.type === 'payment_method_update');
r = await call(createCustomerPortalSession, U.cust, { restaurant_id: RA2 });
check('portale di un altro titolare → 403', r.status === 403);
await db.exec(`insert into public.restaurant_members (restaurant_id, user_id, role, status) values ('${R(9)}', '${U.cust}', 'owner', 'active')`);
r = await call(createCustomerPortalSession, U.cust, { restaurant_id: R(9) });
check('portale senza cliente Stripe → messaggio chiaro', r.status === 409 && r.json.error === 'NO_CUSTOMER', r.json);

console.log('\n— Fatture, sync Admin, promozioni, cron, errori Stripe');
r = await call(billingActions, U.ownerA, { action: 'refresh_invoices', restaurant_id: RA2 });
check('aggiorna fatture da Stripe', r.status === 200 && r.json.invoices >= 3, r.json);
await db.exec(`update public.subscriptions set status='incomplete' where stripe_subscription_id='${subIdA2}'`);
r = await call(billingAdmin, U.admin, { action: 'sync', subscription_id: (await sub(RA2))!.id });
check('"Sincronizza con Stripe" ripristina lo stato reale', r.status === 200 && (await sub(RA2))?.status === 'active', r.json);
r = await call(billingAdmin, U.admin, { action: 'sync_all' });
check('sincronizza tutto', r.status === 200 && r.json.synced >= 1 && r.json.errors.length === 0, r.json);
r = await call(billingAdmin, U.admin, { action: 'status' });
check('stato configurazione senza segreti', r.status === 200 && r.json.environment === 'test' && !JSON.stringify(r.json).includes('whsec_'), r.json);
await db.exec(`insert into public.billing_promotions (code, discount_type, discount_value, duration, duration_in_months, applicable_plans) values ('LANCIO20', 'percent', 20, 'repeating', 3, '{}')`);
r = await call(createCheckoutSession, U.ownerB, { restaurant_id: RB, plan: 'premium', billing_interval: 'month', promotion_code: 'lancio20' });
const promoParams = stripe.sessions.get(r.json.session_id)?._params;
const coupon = stripe.coupons.get(promoParams?.discounts?.[0]?.coupon);
check('promozione B2B validata dal server → coupon Stripe (20% per 3 mesi)', r.status === 200 && coupon?.percent_off === 20 && coupon?.duration_in_months === 3, { r: r.json, coupon });
r = await call(createCheckoutSession, U.ownerB, { restaurant_id: RB, plan: 'premium', billing_interval: 'month', promotion_code: 'FALSO99' });
check('codice non valido → errore, nessuno sconto client-side', r.status === 400 && r.json.error === 'PROMO_INVALID', r.json);
const cron = await billingCron(deps);
check('cron orario eseguibile', typeof cron.changed === 'number' && typeof cron.expiring === 'number', cron);
stripe.down = true;
r = await call(createCustomerPortalSession, U.ownerA, { restaurant_id: RA2 });
check('Stripe non raggiungibile → 503 con messaggio, nessuno stack trace', r.status === 503 && r.json.error === 'STRIPE_UNAVAILABLE' && !/at \w+ \(/.test(JSON.stringify(r.json)), r.json);
stripe.down = false;

console.log('\n— Ricavi (solo abbonamenti reali)');
const rev = await q1<{ s: any }>(`select public.admin_revenue_stats() s from (select set_config('request.jwt.claim.sub', '${U.admin}', false)) x`);
check('MRR = Business mensile + Business annuale / 12 (Top cancellato e prove escluse)', rev.s.mrr_cents === 2990 + Math.round(29900 / 12) && rev.s.arr_cents === Math.round((2990 + 29900 / 12) * 12), rev.s);
check('conversione trial → paid: 2 su 3 prove terminate', rev.s.trials_converted === 2 && rev.s.trials_ended === 3 && Number(rev.s.trial_conversion_rate) === 66.7, rev.s);
check('clienti paganti (account di fatturazione) e churn', rev.s.paying_customers === 1 && rev.s.cancelled_30d >= 2, rev.s);
await db.exec(`select set_config('request.jwt.claim.sub', '', false)`);

console.log(`\n${pass} passati, ${fail} falliti`);
if (fail) console.log(logs.filter((l) => l.startsWith('error')).slice(-10).join('\n'));
process.exit(fail ? 1 : 0);
