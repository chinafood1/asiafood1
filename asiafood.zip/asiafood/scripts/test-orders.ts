/* eslint-disable @typescript-eslint/no-explicit-any */
// ─────────────────────────────────────────────────────────────
//  Test della Fase 8 (marketplace ordini) sulle VERE migrazioni
//  (PGlite) con i VERI handler (server/orders + webhook unico) e
//  uno Stripe simulato in memoria (eventi firmati e verificati con
//  la libreria Stripe reale).
//  Uso: npm run test:orders
// ─────────────────────────────────────────────────────────────
import { stripeWebhook } from '../server/billing/handlers';
import type { BillingDeps, HttpResponse } from '../server/billing/types';
import { createOrder, orderAccessToken, orderAction, ordersCron, payoutsConnect } from '../server/orders/handlers';
import type { OrdersDeps, OrdersHandler } from '../server/orders/types';
import { FakeStripe, type FakeEvent } from './lib/fake-stripe';
import { createTestDb } from './lib/pglite-db';

const { db, store } = await createTestDb();
const stripe = new FakeStripe();
const WEBHOOK_SECRET = 'whsec_test_orders';
const TOKEN_SECRET = 'test-order-token-secret';
const logs: string[] = [];
const log = (level: string, message: string, data?: Record<string, unknown>) => void logs.push(`${level} ${message} ${JSON.stringify(data ?? {})}`);

let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) {
    pass++;
    console.log('  ✓', name);
  } else {
    fail++;
    console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 600) : '');
  }
}
const section = (t: string) => console.log(`\n── ${t}`);

async function as(user: string | null, sql: string, params: unknown[] = [], role?: string) {
  const r = role ?? (user ? 'authenticated' : 'anon');
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${user ?? ''}', false); select set_config('request.jwt.claim.role', '${r}', false); set role ${r};`);
  try {
    const res = await db.query<any>(sql, params);
    return { ok: true as const, rows: res.rows, err: '' };
  } catch (e) {
    return { ok: false as const, rows: [] as any[], err: (e as Error).message };
  } finally {
    await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', '', false);`);
  }
}
const q1 = async (sql: string, params: unknown[] = []) => (await db.query<any>(sql, params)).rows[0];
const val = async (sql: string, params: unknown[] = []) => Object.values((await q1(sql, params)) ?? {})[0] as any;

const U = {
  admin: '91111111-1111-4111-8111-111111111111',
  owner: '92222222-2222-4222-8222-222222222222', // Seoul (5)
  staff: '93333333-3333-4333-8333-333333333333', // staff Seoul
  owner2: '94444444-4444-4444-8444-444444444444', // Ramen Kōen (2)
  alice: '95555555-5555-4555-8555-555555555555',
  bob: '96666666-6666-4666-8666-666666666666',
};
for (const [k, id] of Object.entries(U)) {
  await db.query(`insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values ($1, $2, $3, now())`, [id, `${k}@test.it`, JSON.stringify({ full_name: `${k[0]!.toUpperCase()}${k.slice(1)} Test` })]);
}
await db.exec(`update public.profiles set role = 'admin' where id = '${U.admin}'; update public.profiles set phone = '+39 333 0000000' where id = '${U.alice}';`);
const R = (n: number) => `e0000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const SEOUL = R(5);
const KOEN = R(2);
await db.exec(`
insert into public.restaurant_members (restaurant_id, user_id, role, status) values
  ('${SEOUL}', '${U.owner}', 'owner', 'active'), ('${SEOUL}', '${U.staff}', 'staff', 'active'), ('${KOEN}', '${U.owner2}', 'owner', 'active');
-- Orari deterministici per i test: sempre aperto (00:00 → 00:00 del giorno dopo)
delete from public.restaurant_hours where restaurant_id in ('${SEOUL}', '${KOEN}');
insert into public.restaurant_hours (restaurant_id, day_of_week, opens_at, closes_at, is_closed)
  select r, d, '00:00', '00:00', false from unnest(array['${SEOUL}'::uuid, '${KOEN}'::uuid]) r, generate_series(1, 7) d;
`);
await store.rpc('billing_set_environment', { p_env: 'test' });

const deps: OrdersDeps = {
  stripe: stripe.asStripe(),
  store,
  config: { env: 'test', appUrl: 'https://asiafood.test', tokenSecret: TOKEN_SECRET },
  verifyUser: async (t) => (t?.startsWith('tok-') && /^[0-9a-f-]{36}$/.test(t.slice(4)) ? t.slice(4) : null),
  log,
};
const billingDeps: BillingDeps = {
  stripe: stripe.asStripe(), store,
  config: { env: 'test', appUrl: 'https://asiafood.test', webhookSecret: WEBHOOK_SECRET, taxEnabled: false, portalConfigurationId: null, allowPromotionCodes: false },
  verifyUser: deps.verifyUser, log,
};
let ipN = 0;
async function call(h: OrdersHandler, user: string | null, body: Record<string, unknown>, ip = `203.0.113.${++ipN % 250}`): Promise<HttpResponse & { json: Record<string, any> }> {
  const res = await h({ method: 'POST', header: (n) => (n === 'authorization' && user ? `Bearer tok-${user}` : n === 'x-nf-client-connection-ip' ? ip : null), body: JSON.stringify(body) }, deps);
  return { ...res, json: res.body as Record<string, any> };
}
async function deliver(events: FakeEvent[] = stripe.drain()) {
  const out: HttpResponse[] = [];
  for (const e of events) {
    const { payload, header } = stripe.sign(e, WEBHOOK_SECRET);
    out.push(await stripeWebhook({ method: 'POST', header: (n) => (n === 'stripe-signature' ? header : null), body: payload }, billingDeps));
  }
  return out;
}

// Riferimenti al menu (dal seed)
const item = async (name: string) => q1(`select id, price from public.menu_items where restaurant_id = $1 and name = $2`, [SEOUL, name]);
const URA = await item('Uramaki salmone e avocado');
const BOWL = await item('Bibimbap bowl');
const WATER = await item('Acqua naturale');
const KIMBAP = await item('Kimbap bulgogi');
const V8 = await val(`select id from public.menu_item_variants where menu_item_id = $1 and name = '8 pezzi'`, [URA.id]);
const _V4 = await val(`select id from public.menu_item_variants where menu_item_id = $1 and name = '4 pezzi'`, [URA.id]);
const ADD_SALMON = await val(`select id from public.menu_item_addons where menu_item_id = $1 and name = 'Extra salmone'`, [URA.id]);
const opt = async (group: string, name: string) => val(`select o.id from public.menu_options o join public.menu_option_groups g on g.id = o.option_group_id where g.menu_item_id = $1 and g.name = $2 and o.name = $3`, [BOWL.id, group, name]);
const RISO_INT = await opt('Base', 'Riso integrale');
const SALMONE = await opt('Proteina', 'Salmone');
const MAYO = await opt('Salse', 'Maionese spicy');
const SOIA = await opt('Salse', 'Salsa di soia');
const GOCHU = await opt('Salse', 'Gochujang');
const rest = await q1(`select latitude, longitude from public.restaurants where id = $1`, [SEOUL]);
const at = (km: number) => ({ latitude: rest.latitude + km / 111.2, longitude: rest.longitude });
const addr = (km: number, extra: Record<string, unknown> = {}) => ({
  recipient_name: 'Alice Test', phone: '+39 333 1112223', address_line_1: 'Via Dante 10', city: 'Taranto', postal_code: '74121', ...at(km), geocode_source: 'geocoder', ...extra,
});
const sushiLine = { menu_item_id: URA.id, variant_id: V8, addons: [{ id: ADD_SALMON, quantity: 1 }], quantity: 2, notes: 'Senza sesamo' };
const bowlLine = { menu_item_id: BOWL.id, options: [RISO_INT, SALMONE, MAYO], quantity: 1 };
const quote = async (p: Record<string, unknown>, user: string | null = null) => (await as(user, `select public.order_quote($1::jsonb) q`, [JSON.stringify(p)])).rows[0]?.q;
const codes = (q: any) => (q?.errors ?? []).map((e: any) => e.code);
let idem = 0;
const newKey = () => `test-key-${Date.now()}-${++idem}`;
const orderBody = (extra: Record<string, unknown> = {}) => {
  const key = newKey();
  return {
    restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], session_id: `sess-${key}`, idempotency_key: key,
    contact: { name: 'Ospite Prova', email: idem === 1 ? 'ospite@test.it' : `ospite${idem}@test.it`, phone: '+39 333 4445556' }, ...extra,
  };
};
const orderRow = (id: string) => q1(`select * from public.orders where id = $1`, [id]);

// ════════════════════════════════════════════════════════════════════
section('Configurazione, menu pubblico e preventivo');
const info = (await as(null, `select public.order_public_info($1) i`, [SEOUL])).rows[0].i;
check('info pubblica: takeaway e delivery attivi, zone di consegna', info.enabled && info.takeaway.enabled && info.delivery.enabled && info.delivery.zones.length === 3, info);
check('pagamenti non ancora configurati (nessun account Connect)', info.payments_ready === false);
const koen = (await as(null, `select public.order_public_info($1) i`, [KOEN])).rows[0].i;
check('Ramen Kōen: solo takeaway (delivery non obbligatorio)', koen.takeaway.enabled && !koen.delivery.enabled);
const disabled = (await as(null, `select public.order_public_info($1) i`, [R(1)])).rows[0].i;
check('ristorante senza ordini online: enabled = false', disabled.enabled === false);
let q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine] });
check('preventivo: prezzo dal DB (variante 8 pz 11 € + extra salmone 2,50 €) × 2 = 27 €', Number(q.subtotal) === 27 && Number(q.lines[0].unit_price) === 13.5, q);
check('preventivo: senza Stripe Connect → PAYMENTS_NOT_READY', codes(q).includes('PAYMENTS_NOT_READY'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: URA.id, quantity: 1, unit_price: 0.01 }] });
check('variante obbligatoria mancante → OPTIONS_REQUIRED', codes(q).includes('OPTIONS_REQUIRED'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: BOWL.id, options: [SALMONE], quantity: 1 }] });
check('gruppo obbligatorio incompleto (Base) → OPTIONS_REQUIRED', codes(q).includes('OPTIONS_REQUIRED') && JSON.stringify(q.errors).includes('Base'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: BOWL.id, options: [RISO_INT, SALMONE, MAYO, SOIA, GOCHU], quantity: 1 }] });
check('troppe salse (max 2) → OPTIONS_REQUIRED', codes(q).includes('OPTIONS_REQUIRED'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [bowlLine] });
check('bowl: 12,50 + integrale 0,50 + salmone 2 + mayo 0,50 = 15,50 €', Number(q.subtotal) === 15.5, q.lines);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: URA.id, variant_id: V8, addons: [{ id: '00000000-0000-4000-8000-000000000000', quantity: 1 }], quantity: 1 }] });
check('extra inesistente → OPTION_INVALID', codes(q).includes('OPTION_INVALID'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: (await q1(`select id from public.menu_items where restaurant_id = $1 limit 1`, [R(1)])).id, quantity: 1 }] });
check('piatto di un altro ristorante → ITEM_NOT_FOUND (un ordine = un ristorante)', codes(q).includes('ITEM_NOT_FOUND'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: WATER.id, quantity: 1 }] });
check('ordine minimo (10 €) non raggiunto → MINIMUM_NOT_REACHED con importo mancante', codes(q).includes('MINIMUM_NOT_REACHED') && q.errors.find((e: any) => e.code === 'MINIMUM_NOT_REACHED').missing === 8);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: WATER.id, quantity: 25 }] });
check('quantità oltre 20 → QUANTITY_INVALID', codes(q).includes('QUANTITY_INVALID'));
q = await quote({ restaurant_id: SEOUL, order_type: 'delivery', items: [sushiLine], address: addr(1) });
check('delivery entro 3 km: consegna 2,50 €, zona e distanza calcolate dal server', Number(q.delivery_fee) === 2.5 && q.delivery.zone_name === 'Entro 3 km' && Number(q.delivery.distance_km) > 0.9 && Number(q.delivery.distance_km) < 1.1, q.delivery);
q = await quote({ restaurant_id: SEOUL, order_type: 'delivery', items: [sushiLine], address: addr(4.5) });
check('delivery a 4,5 km: fascia 3–6 km, 4 € (minimo 20 € rispettato)', Number(q.delivery_fee) === 4 && !codes(q).includes('MINIMUM_NOT_REACHED'));
q = await quote({ restaurant_id: SEOUL, order_type: 'delivery', items: [sushiLine], address: addr(12) });
check('fuori raggio (12 km) → OUTSIDE_AREA "non consegna ancora a questo indirizzo"', codes(q).includes('OUTSIDE_AREA') && JSON.stringify(q.errors).includes('non consegna ancora'));
q = await quote({ restaurant_id: SEOUL, order_type: 'delivery', items: [sushiLine] });
check('delivery senza indirizzo verificato → ADDRESS_REQUIRED', codes(q).includes('ADDRESS_REQUIRED'));
q = await quote({ restaurant_id: SEOUL, order_type: 'delivery', items: [{ ...sushiLine, quantity: 4 }], address: addr(1) });
check('consegna gratuita sopra la soglia (45 €)', Number(q.subtotal) >= 45 && Number(q.delivery_fee) === 0);
q = await quote({ restaurant_id: KOEN, order_type: 'delivery', items: [{ menu_item_id: (await q1(`select id from public.menu_items where restaurant_id = $1 and price > 10 limit 1`, [KOEN])).id, quantity: 1 }], address: addr(1) });
check('Ramen Kōen delivery → TYPE_UNAVAILABLE', codes(q).includes('TYPE_UNAVAILABLE'));

section('Disponibilità, pausa, chiusura, orari programmati');
await as(U.staff, `select public.set_menu_item_availability($1, 'today')`, [KIMBAP.id]);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: KIMBAP.id, quantity: 2 }] });
check('"non disponibile oggi" (anche dallo staff) → ITEM_UNAVAILABLE', codes(q).includes('ITEM_UNAVAILABLE'));
check('torna disponibile domani (unavailable_until = mezzanotte locale)', (await val(`select unavailable_until > now() and unavailable_until < now() + interval '25 hours' from public.menu_items where id = $1`, [KIMBAP.id])) === true);
await as(U.staff, `select public.set_menu_item_availability($1, 'on')`, [KIMBAP.id]);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ menu_item_id: KIMBAP.id, quantity: 2 }] });
check('riattivato → disponibile', !codes(q).includes('ITEM_UNAVAILABLE'));
const other = await as(U.owner2, `select public.set_menu_item_availability($1, 'off')`, [KIMBAP.id]);
check('ristoratore di un altro locale non può cambiare la disponibilità', !other.ok);
await as(U.owner, `select public.order_set_pause($1, 'all', 30)`, [SEOUL]);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine] });
check('pausa ordini 30 min → RESTAURANT_PAUSED', codes(q).includes('RESTAURANT_PAUSED'));
await as(U.owner, `select public.order_set_pause($1, 'all', 0)`, [SEOUL]);
await as(U.staff, `select public.order_set_pause($1, 'delivery', null)`, [SEOUL]);
const qd = await quote({ restaurant_id: SEOUL, order_type: 'delivery', items: [sushiLine], address: addr(1) });
const qt = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine] });
check('solo delivery in pausa "fino a riattivazione": takeaway resta attivo', codes(qd).includes('RESTAURANT_PAUSED') && !codes(qt).includes('RESTAURANT_PAUSED'));
await as(U.staff, `select public.order_set_pause($1, 'delivery', 0)`, [SEOUL]);
await as(U.owner, `select public.order_set_pause($1, 'busy', 25)`, [SEOUL]);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine] });
check('modalità occupato: tempo di preparazione 20 + 25 min', q.preparation_minutes === 45);
await as(U.owner, `select public.order_set_pause($1, 'busy', 0)`, [SEOUL]);
// Chiuso adesso: orari solo in un'altra fascia
await db.exec(`delete from public.restaurant_hours where restaurant_id = '${SEOUL}';
  insert into public.restaurant_hours (restaurant_id, day_of_week, opens_at, closes_at, is_closed)
  select '${SEOUL}', d, ((extract(hour from now() at time zone 'Europe/Rome')::int + 3) % 24 || ':00')::time,
         ((extract(hour from now() at time zone 'Europe/Rome')::int + 6) % 24 || ':00')::time, false from generate_series(1, 7) d;`);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine] });
const closedErr = (q.errors ?? []).find((e: any) => e.code === 'RESTAURANT_CLOSED');
check('fuori orario: niente ordini "il prima possibile", proposta del primo orario disponibile', !!closedErr && !!closedErr.next_slot?.at, q.errors);
const slotAt = closedErr?.next_slot?.at;
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], scheduled_for: slotAt });
check('ordine programmato nel primo slot: valido', !codes(q).some((c: string) => ['RESTAURANT_CLOSED', 'SLOT_INVALID'].includes(c)), q.errors);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], scheduled_for: new Date(Date.now() + 5 * 86400000).toISOString() });
check('oltre i giorni di anticipo consentiti → SLOT_INVALID', codes(q).includes('SLOT_INVALID'));
const slots = (await as(null, `select public.order_slots($1, (now() at time zone 'Europe/Rome')::date + 1, 'takeaway') s`, [SEOUL])).rows[0].s;
check('fasce di domani derivate dagli orari (ogni 15 min, 3 ore → 12 fasce)', slots.length === 12 && slots.every((s: any) => s.status === 'available'), slots.length);
await db.exec(`delete from public.restaurant_hours where restaurant_id = '${SEOUL}';
  insert into public.restaurant_hours (restaurant_id, day_of_week, opens_at, closes_at, is_closed) select '${SEOUL}', d, '00:00', '00:00', false from generate_series(1, 7) d;`);

section('Coupon e codici sconto (validati dal server)');
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], coupon_code: 'seoul5' });
check('coupon SEOUL5 (-5 € da 25 €) applicato: totale 22 €', Number(q.coupon_discount) === 5 && Number(q.total) === 22 && q.codes[0].ok, q.codes);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [{ ...sushiLine, quantity: 1 }], coupon_code: 'SEOUL5' });
check('sotto la spesa minima → COUPON_MIN_SPEND', codes(q).includes('COUPON_MIN_SPEND'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], coupon_code: 'NONESISTE' });
check('codice inesistente → COUPON_INVALID', codes(q).includes('COUPON_INVALID'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], coupon_code: 'KAIZEN10' });
check('coupon di un altro ristorante → non valido', codes(q).includes('COUPON_INVALID'));
await db.exec(`insert into public.coupons (restaurant_id, code, title, discount_type, discount_value, is_active, valid_from) values
  ('${SEOUL}', 'SEOUL10', '-10%', 'percent', 10, true, now() - interval '1 day'), ('${SEOUL}', 'OMAGGIO', 'Dolce omaggio', 'free_item', null, true, now() - interval '1 day')`);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], coupon_code: 'SEOUL10' });
check('coupon percentuale: -10% su 27 € = 2,70 €', Number(q.coupon_discount) === 2.7);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], coupon_code: 'OMAGGIO' });
check('coupon "omaggio" valido solo al ristorante → COUPON_IN_STORE_ONLY', codes(q).includes('COUPON_IN_STORE_ONLY'));
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], coupon_code: 'SEOUL5', reward_code: 'SEOUL10' });
check('due codici con allow_coupon_stacking = false → COUPON_NOT_STACKABLE', codes(q).includes('COUPON_NOT_STACKABLE'));

section('Stripe Connect Express (onboarding gestito da Stripe)');
let r = await call(payoutsConnect, U.staff, { restaurant_id: SEOUL, action: 'onboard' });
check('staff non può configurare i pagamenti (solo titolare)', r.status === 403);
r = await call(payoutsConnect, U.owner2, { restaurant_id: SEOUL, action: 'onboard' });
check('titolare di un altro locale → 403', r.status === 403);
r = await call(payoutsConnect, U.owner, { restaurant_id: SEOUL, action: 'onboard' });
check('onboarding: account Express creato + link Stripe (nessun IBAN raccolto da AsiaFood)', r.status === 200 && /connect\.stripe\.test\/setup\/acct_/.test(r.json.url), r.json);
const acct = await val(`select stripe_account_id from public.restaurant_payout_accounts where restaurant_id = $1`, [SEOUL]);
r = await call(payoutsConnect, U.owner, { restaurant_id: SEOUL, action: 'onboard' });
check('onboarding ripetuto: stesso account (idempotente)', (await val(`select count(*)::int from public.restaurant_payout_accounts where restaurant_id = $1`, [SEOUL])) === 1);
stripe.completeOnboarding(acct);
await deliver();
check('account.updated → charges_enabled, pagamenti pronti', (await as(null, `select public.order_public_info($1) i`, [SEOUL])).rows[0].i.payments_ready === true);
check('notifica al titolare: pagamenti online attivi', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Pagamenti online attivi'`, [U.owner])) === 1);
const pac = (await as(U.alice, `select count(*)::int n from public.restaurant_payout_accounts`)).rows[0].n;
check('RLS: un cliente non vede gli account di pagamento', pac === 0);

section('Creazione ordine (server) e sicurezza del prezzo');
r = await call(createOrder, null, { ...orderBody(), items: [{ ...sushiLine, unit_price: 0.01, line_total: 0.02 }], total: 0.5, platform_fee: 0 });
check('ospite: ordine creato "in attesa di pagamento" con PaymentIntent', r.status === 200 && /^AF-\d{6}-[A-Z0-9]{4}$/.test(r.json.order_number) && /_secret_/.test(r.json.client_secret), r.json);
const o1 = await orderRow(r.json.order_id);
check('prezzi manomessi dal browser ignorati: totale 27 € dal database', Number(o1.total) === 27 && o1.status === 'pending_payment' && o1.payment_status === 'pending');
const pi1 = stripe.intents.get(o1.stripe_payment_intent_id)!;
check('PaymentIntent: 2700 centesimi, destination charge + commissione 10% (270)', pi1.amount === 2700 && pi1.transfer_data?.destination === acct && pi1.application_fee_amount === 270, pi1);
check('metadati minimi (order_id, restaurant_id, environment), nessun dato personale', pi1.metadata.order_id === o1.id && pi1.metadata.environment === 'test' && !JSON.stringify(pi1.metadata).includes('ospite@'));
check('snapshot commissione: lordo 27, commissione 2,70, netto stimato 24,30', Number(o1.restaurant_gross) === 27 && Number(o1.platform_fee) === 2.7 && Number(o1.restaurant_net_estimated) === 24.3);
check('token ospite: nel DB solo l\'hash, uguale all\'HMAC del server',
  (await val(`select access_token_hash from public.order_secrets where order_id = $1`, [o1.id])) === (await val(`select public.order_hash_token($1)`, [orderAccessToken(TOKEN_SECRET, o1.id)])));
const tok1 = r.json.access_token as string;
const body1 = JSON.parse(JSON.stringify(r.json));
const dup = await call(createOrder, null, { ...orderBody(), idempotency_key: 'dup-key-000001' });
const dup2 = await call(createOrder, null, { ...orderBody(), idempotency_key: 'dup-key-000001' });
check('doppio click su "Paga": stesso ordine e stesso PaymentIntent (idempotenza)', dup.json.order_id === dup2.json.order_id && dup.json.client_secret === dup2.json.client_secret);
check('…e un solo PaymentIntent creato su Stripe', [...stripe.intents.values()].filter((p) => p.metadata.order_id === dup.json.order_id).length === 1);
r = await call(createOrder, null, { ...orderBody(), contact: { name: 'X', email: 'non-valida', phone: '1' } });
check('contatti non validi → 409 con errori per campo', r.status === 409 && r.json.errors?.[0]?.code === 'CONTACT_INVALID');
r = await call(createOrder, null, { ...orderBody(), items: [{ menu_item_id: WATER.id, quantity: 1 }] });
check('ordine minimo non raggiunto → rifiutato dal server', r.status === 409 && r.json.errors.some((e: any) => e.code === 'MINIMUM_NOT_REACHED'));
r = await call(createOrder, null, { ...orderBody(), order_type: 'delivery', address: addr(12) });
check('delivery fuori zona → rifiutato dal server', r.status === 409 && r.json.errors.some((e: any) => e.code === 'OUTSIDE_AREA'));
r = await call(createOrder, 'nonvalido', orderBody());
check('JWT non valido → 401 (mai declassato a ospite)', r.status === 401);
r = await call(createOrder, null, { ...orderBody(), session_id: null });
check('ospite senza sessione → 400', r.status === 400);

section('Pagamento: webhook come unica fonte di verità');
stripe.payIntent(o1.stripe_payment_intent_id, { decline: true });
await deliver();
let o = await orderRow(o1.id);
check('carta rifiutata: pagamento "non riuscito", ordine ancora pagabile', o.payment_status === 'failed' && o.status === 'pending_payment' && o.payment_failures === 1);
const trackFail = (await as(null, `select public.order_track($1, $2) t`, [o1.order_number, tok1])).rows[0].t;
check('tracking: "può pagare" dopo il rifiuto', trackFail.can_pay === true);
stripe.payIntent(o1.stripe_payment_intent_id);
const paidEvents = stripe.drain();
await deliver(paidEvents);
o = await orderRow(o1.id);
check('payment_intent.succeeded → pagato, in attesa del ristorante', o.payment_status === 'paid' && o.status === 'pending_restaurant' && Number(o.amount_paid) === 27);
const again = await deliver(paidEvents);
check('webhook duplicato: nessun doppio effetto (stripe_events)', (again[0]!.body as any).duplicate === true && (await val(`select count(*)::int from public.order_events where order_id = $1 and event_type = 'payment_succeeded'`, [o1.id])) === 1);
check('ristorante avvisato (titolare e staff): "Nuovo ordine"', (await val(`select count(distinct user_id)::int from public.notifications where title like 'Nuovo ordine%' and metadata ->> 'order_id' = $1`, [o1.id])) === 2);
check('email di conferma pagamento all\'ospite (coda, non bloccante)', (await val(`select count(*)::int from public.email_outbox where order_id = $1 and event_type = 'order_payment_confirmed'`, [o1.id])) === 1);
const fakeClientPaid = await as(null, `update public.orders set payment_status = 'paid' where id = $1`, [dup.json.order_id]);
check('il browser non può segnare un ordine come pagato (RLS)', !fakeClientPaid.ok || (await val(`select payment_status from public.orders where id = $1`, [dup.json.order_id])) !== 'paid');
const rpcPaid = await as(null, `select public.order_payment_event('{"type":"succeeded","payment_intent":"pi_x","amount":1}'::jsonb)`);
check('evento di pagamento non invocabile da anonimo/cliente', !rpcPaid.ok);

section('Tracking ospite: token sicuro, mai solo il numero');
let t = (await as(null, `select public.order_track($1, $2) t`, [o1.order_number, tok1])).rows[0].t;
check('ospite con token: vede stato e timeline, nessun dato interno', t?.status === 'pending_restaurant' && t.items.length === 1 && t.platform_fee === undefined && t.internal === undefined, t);
t = (await as(null, `select public.order_track($1, null) t`, [o1.order_number])).rows[0].t;
check('solo numero d\'ordine → nessun accesso', t === null);
t = (await as(U.bob, `select public.order_track($1, 'token-sbagliato') t`, [o1.order_number])).rows[0].t;
check('altro utente con token errato → nessun accesso', t === null);
for (let i = 0; i < 20; i++) await as(null, `select public.order_track($1, 'x') t`, [dup.json.order_number]);
const locked = await as(null, `select public.order_track($1, $2) t`, [dup.json.order_number, dup.json.access_token]);
check('tentativi ripetuti bloccati (anti brute-force)', !locked.ok && /Troppi tentativi/.test(locked.err));
const anonOrders = await as(null, `select count(*)::int n from public.orders`);
check('RLS: un ospite non può interrogare la tabella ordini', !anonOrders.ok || anonOrders.rows[0].n === 0);
const secrets = await as(U.admin, `select count(*) from public.order_secrets`);
check('segreti degli ordini non leggibili neanche dall\'Admin via client', !secrets.ok);

section('Terminale del ristorante: permessi e dati minimizzati');
const page = (await as(U.staff, `select public.restaurant_orders($1, 'new') p`, [SEOUL])).rows[0].p;
check('staff vede i nuovi ordini (orders.view)', page.items.length === 1 && page.counts.new === 1, page.counts);
check('staff non può rimborsare (refund.request solo owner/manager)', page.can_refund === false);
check('ordine: cliente, telefono, articoli, note, totale (email non mostrata)', page.items[0].customer_phone && page.items[0].items[0].notes === 'Senza sesamo' && !JSON.stringify(page.items[0]).includes('ospite@test.it'));
const foreign = await as(U.owner2, `select public.restaurant_orders($1, 'new') p`, [SEOUL]);
check('ristorante non autorizzato → negato', !foreign.ok);
const direct = await as(U.owner, `select count(*)::int n from public.orders where restaurant_id = $1`, [SEOUL]);
check('il ristoratore non legge la tabella ordini direttamente (solo RPC minimizzata)', direct.rows[0]?.n === 0);
const accept = await as(U.staff, `select public.order_action($1, 'accept', '{"preparation_minutes": 20}'::jsonb) r`, [o1.id]);
o = await orderRow(o1.id);
check('accetta con tempo di preparazione 20 min (staff: orders.manage)', accept.ok && o.status === 'accepted' && o.accepted_at && Math.abs(new Date(o.estimated_ready_at).getTime() - Date.now() - 20 * 60000) < 90000, accept.err);
const badTransition = await as(U.owner, `select public.order_action($1, 'accept', '{"preparation_minutes": 20}'::jsonb)`, [o1.id]);
check('transizione non valida rifiutata', !badTransition.ok && /non è in attesa/.test(badTransition.err));
await as(U.owner, `select public.order_action($1, 'preparing')`, [o1.id]);
const deliveryStepOnTakeaway = await as(U.owner, `select public.order_action($1, 'out_for_delivery')`, [o1.id]);
check('"in consegna" non consentito per il takeaway', !deliveryStepOnTakeaway.ok);
await as(U.owner, `select public.order_action($1, 'ready')`, [o1.id]);
t = (await as(null, `select public.order_track($1, $2) t`, [o1.order_number, tok1])).rows[0].t;
check('cliente vede "pronto" con timestamp reali', t.status === 'ready' && t.accepted_at && t.preparing_at && t.ready_at);
check('email "pronto per il ritiro" in coda', (await val(`select count(*)::int from public.email_outbox where order_id = $1 and event_type = 'order_ready'`, [o1.id])) === 1);
await as(U.owner, `select public.order_action($1, 'complete')`, [o1.id]);
o = await orderRow(o1.id);
check('ritirato → completato', o.status === 'completed' && o.fulfillment_status === 'picked_up' && o.picked_up_at && o.completed_at);

section('Cliente registrato: delivery con coupon, consegna, punti e recensione');
const addrIns = await as(U.alice, `insert into public.customer_addresses (user_id, label, recipient_name, phone, address_line_1, city, postal_code, latitude, longitude, geocode_source, is_default)
  values ($1, 'Casa', 'Alice Test', '+39 333 1112223', 'Via Dante 10', 'Taranto', '74121', $2, $3, 'geocoder', true) returning id`, [U.alice, at(1).latitude, at(1).longitude]);
check('indirizzo salvato dal proprietario', addrIns.ok);
const addrSpy = await as(U.bob, `select count(*)::int n from public.customer_addresses`);
check('RLS: indirizzi visibili solo al proprietario', addrSpy.rows[0].n === 0);
const couponBefore = Number(await val(`select redemptions_count from public.coupons where code = 'SEOUL5'`));
const pointsBefore = Number(await val(`select coalesce(points_balance, 0) from public.loyalty_accounts where user_id = $1`, [U.alice]) ?? 0);
r = await call(createOrder, U.alice, { restaurant_id: SEOUL, order_type: 'delivery', items: [sushiLine, bowlLine], address: { ...addr(1), id: addrIns.rows[0].id }, coupon_code: 'SEOUL5', idempotency_key: newKey(), notes: 'Citofono Test' });
const o2 = await orderRow(r.json.order_id);
check('delivery: 27 + 15,50 − 5 (SEOUL5) + 2,50 consegna = 40 €', Number(o2.total) === 40 && Number(o2.coupon_discount) === 5 && Number(o2.delivery_fee) === 2.5, { total: o2?.total, r: r.json });
check('dati dal profilo (nome, email) e indirizzo in snapshot', o2.customer_email === 'alice@test.it' && o2.delivery_address_snapshot.address_line_1 === 'Via Dante 10' && o2.delivery_address_id === addrIns.rows[0].id);
check('commissione su cibo scontato + consegna (40 € → 4 €)', Number(o2.restaurant_gross) === 40 && Number(o2.platform_fee) === 4);
stripe.payIntent(o2.stripe_payment_intent_id);
await deliver();
check('coupon consumato solo a pagamento confermato', Number(await val(`select redemptions_count from public.coupons where code = 'SEOUL5'`)) === couponBefore + 1);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], coupon_code: 'SEOUL5' }, U.alice);
check('stesso cliente: coupon già usato → COUPON_USED (limite per utente)', codes(q).includes('COUPON_USED'));
const mine = (await as(U.alice, `select public.my_orders(10, 0) m`)).rows[0].m;
check('cronologia ordini del cliente', mine.total === 1 && mine.items[0].order_number === o2.order_number);
check('il cliente legge i propri ordini (RLS)', (await as(U.alice, `select count(*)::int n from public.orders`)).rows[0].n === 1);
check('…ma non quelli degli altri', (await as(U.bob, `select count(*)::int n from public.orders`)).rows[0].n === 0);
check('realtime: il cliente riceve solo i propri aggiornamenti', (await as(U.alice, `select count(*)::int n from public.order_realtime`)).rows[0].n === 1
  && (await as(U.staff, `select count(*)::int n from public.order_realtime`)).rows[0].n >= 2);
await as(U.owner, `select public.order_action($1, 'accept', '{"preparation_minutes": 30}'::jsonb)`, [o2.id]);
check('notifica al cliente: ordine accettato', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Ordine accettato'`, [U.alice])) === 1);
await as(U.owner, `select public.order_action($1, 'ready')`, [o2.id]);
const early = await as(U.owner, `select public.order_action($1, 'complete')`, [o2.id]);
check('delivery: completato anche direttamente da "pronto"', early.ok);
// ricomincia con un ordine per testare il percorso completo
r = await call(createOrder, U.alice, { restaurant_id: SEOUL, order_type: 'delivery', items: [sushiLine], address: addr(4.5), idempotency_key: newKey() });
const o3 = await orderRow(r.json.order_id);
stripe.payIntent(o3.stripe_payment_intent_id); await deliver();
await as(U.owner, `select public.order_action($1, 'accept', '{"preparation_minutes": 15}'::jsonb)`, [o3.id]);
await as(U.owner, `select public.order_action($1, 'preparing')`, [o3.id]);
await as(U.owner, `select public.order_action($1, 'ready')`, [o3.id]);
await as(U.owner, `select public.order_action($1, 'out_for_delivery')`, [o3.id]);
t = (await as(U.alice, `select public.order_track($1, null) t`, [o3.order_number])).rows[0].t;
check('"Il tuo ordine è in consegna" (delivery gestita dal ristorante)', t.status === 'out_for_delivery' && t.out_for_delivery_at && t.is_owner === true);
await as(U.owner, `select public.order_action($1, 'complete')`, [o3.id]);
o = await orderRow(o3.id);
check('consegnato → completato', o.status === 'completed' && o.fulfillment_status === 'delivered');
const pointsAfter = Number(await val(`select points_balance from public.loyalty_accounts where user_id = $1`, [U.alice]));
check('AsiaPoints "ordine completato" assegnati (idempotenti, niente conversione in denaro)', pointsAfter - pointsBefore === 100
  && (await val(`select count(*)::int from public.loyalty_transactions where user_id = $1 and event_key = 'order_completed'`, [U.alice])) === 2, { pointsBefore, pointsAfter });
check('richiesta di recensione dopo l\'ordine completato (una sola volta)', (await val(`select count(*)::int from public.notifications where user_id = $1 and type = 'review' and title like 'Com’è andato il tuo ordine%'`, [U.alice])) === 1, (await db.query(`select type, title from public.notifications where user_id = $1`, [U.alice])).rows);
const rev = await as(U.alice, `select public.submit_review($1, '{"rating_overall":"5","content":"Sushi freschissimo e consegna puntuale, tutto perfetto."}'::jsonb) r`, [SEOUL]);
check('recensione verificata da ordine completato', rev.ok && rev.rows[0].r.is_verified === true && (await val(`select verification_source from public.reviews where user_id = $1`, [U.alice])) === 'order', rev.err);

section('Rifiuto con rimborso automatico, rimborsi parziali, annullamenti');
r = await call(createOrder, U.bob, { restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], idempotency_key: newKey(), contact: { phone: '+39 333 9998887' } });
const o4 = await orderRow(r.json.order_id);
stripe.payIntent(o4.stripe_payment_intent_id); await deliver();
const rej = await as(U.owner, `select public.order_action($1, 'reject', '{"reason":"too_busy"}'::jsonb) r`, [o4.id]);
check('rifiuto con motivo → rimborso in attesa', rej.ok && rej.rows[0].r.refund_pending === true);
const noReason = await as(U.owner, `select public.order_action($1, 'reject', '{"reason":"boh"}'::jsonb)`, [o3.id]);
check('motivo non valido rifiutato', !noReason.ok);
r = await call(orderAction, U.owner, { action: 'after_change', order_id: o4.id });
check('rimborso eseguito su Stripe dal server (storno trasferimento e commissione)', r.json.processed === 1 && [...stripe.refundsMap.values()].some((x) => x.payment_intent === o4.stripe_payment_intent_id && x.reverse_transfer && x.refund_application_fee && x.amount === 2700), r.json);
await deliver();
o = await orderRow(o4.id);
check('ordine rifiutato e rimborsato per intero', o.status === 'rejected' && o.payment_status === 'refunded' && Number(o.amount_refunded) === 27);
check('cliente avvisato del rimborso', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Rimborso effettuato'`, [U.bob])) === 1);
r = await call(orderAction, U.owner, { action: 'after_change', order_id: o4.id });
check('riesecuzione: nessun doppio rimborso', r.json.processed === 0 && [...stripe.refundsMap.values()].filter((x) => x.payment_intent === o4.stripe_payment_intent_id).length === 1);
// Rimborso parziale
r = await call(orderAction, U.staff, { action: 'refund', order_id: o3.id, amount: 5, reason: 'Bevanda mancante' });
check('staff: rimborso non consentito', r.status === 403);
r = await call(orderAction, U.owner2, { action: 'refund', order_id: o3.id, amount: 5, reason: 'Prova' });
check('titolare di un altro ristorante: rimborso negato', r.status === 403);
r = await call(orderAction, U.owner, { action: 'refund', order_id: o3.id, amount: 500, reason: 'Troppo' });
check('rimborso superiore al pagato → AMOUNT_INVALID', r.status === 400 && r.json.error === 'AMOUNT_INVALID');
r = await call(orderAction, U.owner, { action: 'refund', order_id: o3.id, amount: 5, reason: 'Bevanda mancante' });
await deliver();
o = await orderRow(o3.id);
check('rimborso parziale 5 € → rimborsato in parte', r.status === 200 && o.payment_status === 'partially_refunded' && o.status === 'partially_refunded' && Number(o.amount_refunded) === 5, { st: r.status, r: r.json, o: [o.payment_status, o.status, o.amount_refunded] });
// Annullamento del cliente
r = await call(createOrder, null, orderBody());
const o5 = await orderRow(r.json.order_id);
const tok5 = r.json.access_token;
stripe.payIntent(o5.stripe_payment_intent_id); await deliver();
const cancel = await as(null, `select public.order_customer_cancel($1, $2, 'Ho cambiato idea') r`, [o5.order_number, tok5]);
check('annullamento del cliente prima dell\'accettazione → rimborso', cancel.ok && cancel.rows[0].r.refund_pending === true, cancel.err);
await call(orderAction, null, { action: 'after_change', order_id: o5.id }); await deliver();
check('…eseguito', (await orderRow(o5.id)).payment_status === 'refunded');
const lateCancel = await as(U.alice, `select public.order_customer_cancel($1, null, 'tardi')`, [o3.order_number]);
check('dopo l\'accettazione: niente annullamento, "Segnala un problema"', !lateCancel.ok && /Segnala un problema/.test(lateCancel.err));
const issue = await as(U.alice, `select public.order_issue_create($1, null, 'missing_item', 'Manca una bevanda nel sacchetto.') i`, [o3.order_number]);
check('segnalazione problema dal cliente → Admin avvisato', issue.ok && (await val(`select count(*)::int from public.notifications where user_id = $1 and type = 'order_issue'`, [U.admin])) >= 1);

section('Automatismi: accettazione automatica, scadenze, timeout, pagato dopo annullamento');
await db.exec(`update public.restaurant_order_settings set accept_orders_automatically = true where restaurant_id = '${SEOUL}'`);
r = await call(createOrder, U.bob, { restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], idempotency_key: newKey(), contact: { phone: '+39 333 9998887' } });
const o6 = await orderRow(r.json.order_id);
stripe.payIntent(o6.stripe_payment_intent_id); await deliver();
check('accettazione automatica dopo il pagamento (tempo predefinito)', (await orderRow(o6.id)).status === 'accepted' && (await orderRow(o6.id)).preparation_minutes === 20);
await db.exec(`update public.restaurant_order_settings set accept_orders_automatically = false where restaurant_id = '${SEOUL}'`);
r = await call(createOrder, null, orderBody());
const o7 = await orderRow(r.json.order_id);
await db.exec(`update public.orders set created_at = now() - interval '40 minutes' where id = '${o7.id}'`);
r = await call(createOrder, null, orderBody());
const o8 = await orderRow(r.json.order_id);
stripe.payIntent(o8.stripe_payment_intent_id); await deliver();
await db.exec(`update public.orders set paid_at = now() - interval '25 minutes' where id = '${o8.id}'`);
const cron = await ordersCron(deps);
await deliver();
check('non pagato da 40 min → annullato e PaymentIntent annullato su Stripe', (await orderRow(o7.id)).status === 'cancelled' && stripe.intents.get(o7.stripe_payment_intent_id)!.status === 'canceled' && cron.expired >= 1, cron);
check('non accettato entro 20 min → annullato con rimborso automatico', (await orderRow(o8.id)).status === 'cancelled' && (await orderRow(o8.id)).payment_status === 'refunded', cron);
stripe.payIntent(o7.stripe_payment_intent_id);
await deliver();
check('pagato dopo l\'annullamento → rimborso automatico completo', (await orderRow(o7.id)).payment_status === 'refunded');
stripe.disputeIntent(o3.stripe_payment_intent_id); await deliver();
check('contestazione → flag di rischio e avviso Admin', (await orderRow(o3.id)).risk_flags.includes('dispute'));
const foreignPi = await stripe.asStripe().paymentIntents.create({ amount: 1000, currency: 'eur', metadata: {} } as any);
stripe.payIntent(foreignPi.id);
const ign = await deliver();
check('PaymentIntent non di un ordine → ignorato', (ign[0]!.body as any).status === 'ignored');

section('Slot al completo (niente overbooking)');
await db.exec(`update public.restaurant_order_settings set max_orders_per_slot = 1 where restaurant_id = '${SEOUL}'`);
const slotsNow = (await as(null, `select public.order_slots($1, (now() at time zone 'Europe/Rome')::date + 1, 'takeaway') s`, [SEOUL])).rows[0].s;
const target = slotsNow[40]?.at ?? slotsNow[0].at;
r = await call(createOrder, null, { ...orderBody(), scheduled_for: target });
check('ordine programmato occupa lo slot', r.status === 200, r.json);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine], scheduled_for: target });
check('secondo ordine nello stesso slot → SLOT_FULL', codes(q).includes('SLOT_FULL'));
await db.exec(`update public.restaurant_order_settings set max_orders_per_slot = null where restaurant_id = '${SEOUL}'`);

section('Commissioni: snapshot, override per ristorante, storico invariato');
await as(U.admin, `insert into public.restaurant_commission_settings (restaurant_id, percentage_fee, fixed_fee) values ($1, 12, 0.3)`, [SEOUL]);
const ownerComm = await as(U.owner, `insert into public.restaurant_commission_settings (restaurant_id, percentage_fee, fixed_fee) values ($1, 1, 0)`, [SEOUL]);
check('il ristoratore non può modificare la propria commissione', !ownerComm.ok);
r = await call(createOrder, null, orderBody());
const o9 = await orderRow(r.json.order_id);
check('nuovo ordine: 12% + 0,30 € → 3,54 €', Number(o9.commission_percent) === 12 && Number(o9.platform_fee) === 3.54);
check('ordini precedenti invariati (10%)', Number((await orderRow(o1.id)).platform_fee) === 2.7);
await db.exec(`update public.menu_items set price = 99 where id = '${URA.id}'; update public.menu_item_variants set price = 99 where id = '${V8}'`);
check('menu cambiato dopo l\'ordine: snapshot storico invariato', Number(await val(`select unit_price from public.order_items where order_id = $1`, [o1.id])) === 13.5);
await db.exec(`update public.menu_item_variants set price = 11 where id = '${V8}'`);

section('Costo di servizio (predisposto, disattivato di default)');
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine] });
check('default: nessun costo di servizio', Number(q.service_fee) === 0);
await db.exec(`update public.platform_settings set value = 'true' where key = 'service_fee_enabled'`);
q = await quote({ restaurant_id: SEOUL, order_type: 'takeaway', items: [sushiLine] });
check('attivato dall\'Admin: 0,99 € mostrato nel preventivo', Number(q.service_fee) === 0.99 && Number(q.total) === 27.99);
await db.exec(`update public.platform_settings set value = 'false' where key = 'service_fee_enabled'`);

section('Admin: ordini, dettaglio, resync, marketplace');
const adm = (await as(U.admin, `select public.admin_orders('{"restaurant_id":"${SEOUL}","status":"completed"}'::jsonb) a`)).rows[0].a;
check('lista ordini con filtri (ristorante, stato)', adm.total >= 2 && adm.items.every((x: any) => x.status === 'completed'));
check('lista negata ai non Admin', !(await as(U.owner, `select public.admin_orders('{}'::jsonb)`)).ok);
const det = (await as(U.admin, `select public.admin_order_detail($1) d`, [o4.id])).rows[0].d;
check('dettaglio: timeline, rimborsi, commissioni, PaymentIntent', det.events.length >= 4 && det.refunds_admin.length === 1 && det.internal.stripe_payment_intent_id === o4.stripe_payment_intent_id);
await as(U.admin, `select public.admin_order_update($1, '{"internal_notes":"Cliente contattato"}'::jsonb)`, [o4.id]);
check('nota interna Admin (non visibile al cliente)', (await orderRow(o4.id)).internal_notes === 'Cliente contattato'
  && !JSON.stringify((await as(U.bob, `select public.order_track($1, null) t`, [o4.order_number])).rows[0].t).includes('Cliente contattato'));
// Resync: il webhook è andato perso
r = await call(createOrder, null, orderBody());
if (!r.json.order_id) console.log("DBG o10", r.status, JSON.stringify(r.json));
const o10 = await orderRow(r.json.order_id);
stripe.payIntent(o10.stripe_payment_intent_id); stripe.drain();
check('webhook perso: ordine ancora in attesa di pagamento', (await orderRow(o10.id)).payment_status !== 'paid');
r = await call(orderAction, U.owner, { action: 'resync', order_id: o10.id });
check('resync negato ai non Admin', r.status === 403);
r = await call(orderAction, U.admin, { action: 'resync', order_id: o10.id });
check('resync Admin: stato letto da Stripe → pagato', r.status === 200 && (await orderRow(o10.id)).payment_status === 'paid', r.json);
const ms = (await as(U.admin, `select public.marketplace_stats(30) s`)).rows[0].s;
const expectedGmv = Number(await val(`select sum(total) from public.orders where payment_status in ('paid','partially_refunded') and status not in ('rejected','cancelled','refunded','pending_payment')`));
check('GMV = solo ordini validi (esclusi non pagati, rifiutati, annullati)', Number(ms.gmv) === expectedGmv && expectedGmv > 0, { gmv: ms.gmv, expectedGmv });
check('revenue piattaforma ≠ GMV (commissioni maturate su ordini completati)', Number(ms.platform_revenue) > 0 && Number(ms.platform_revenue) < Number(ms.gmv), ms.platform_revenue);
check('takeaway vs delivery, tasso di rimborso, pagamenti monitorati', ms.takeaway >= 1 && ms.delivery >= 1 && ms.refund_rate > 0 && ms.payments.disputes === 1);
check('funnel con definizioni (eventi ≠ utenti)', ms.funnel.length === 6 && ms.definitions.gmv.includes('prima delle commissioni'));
check('statistiche marketplace negate ai non Admin', !(await as(U.owner, `select public.marketplace_stats(30)`)).ok);
const rs = (await as(U.owner, `select public.restaurant_order_stats($1, 30) s`, [SEOUL])).rows[0].s;
check('statistiche ristoratore: ordini, lordo, AOV, top piatti, clienti abituali (senza dati personali)',
  rs.orders >= 3 && Number(rs.gross) > 0 && rs.top_items[0].name && rs.repeat_customers >= 1 && !JSON.stringify(rs).includes('@'), rs);
check('statistiche di un altro ristorante negate', !(await as(U.owner2, `select public.restaurant_order_stats($1, 30)`, [SEOUL])).ok);

section('Carrello salvato, eventi, limiti');
const saved = await as(U.bob, `select public.cart_save($1::jsonb) c`, [JSON.stringify({ restaurant_id: SEOUL, items: [{ ...sushiLine, unit_price: 13.5 }] })]);
const loaded = (await as(U.bob, `select public.cart_load() c`)).rows[0].c;
check('carrello salvato e ricaricato (sincronizzazione tra dispositivi)', saved.ok && loaded.items.length === 1 && loaded.items[0].addons.length === 1);
check('carrello di un altro utente non leggibile', (await as(U.alice, `select count(*)::int n from public.carts`)).rows[0].n === 0);
await db.exec(`alter table public.carts disable trigger carts_updated_at; update public.carts set updated_at = now() - interval '3 hours' where user_id = '${U.bob}'; alter table public.carts enable trigger carts_updated_at;`);
const cron2 = await ordersCron(deps);
check('carrello abbandonato: solo evento statistico, nessun promemoria', cron2.abandoned_carts === 1 && (await val(`select count(*)::int from public.notifications where user_id = $1 and title ilike '%carrello%'`, [U.bob])) === 0);
await as(null, `select public.track_event($1, 'payment_success', 'sess-x', 'web', '{}'::jsonb)`, [SEOUL]);
check('eventi di pagamento/ordine non falsificabili dal browser', (await val(`select count(*)::int from public.analytics_events where event_type = 'payment_success' and session_id = 'sess-x'`)) === 0);
await as(null, `select public.track_event($1, 'add_to_cart', 'sess-x', 'web', '{"email":"a@b.it","item":"x"}'::jsonb)`, [SEOUL]);
check('evento add_to_cart registrato senza dati personali', (await val(`select metadata::text from public.analytics_events where event_type = 'add_to_cart' and session_id = 'sess-x'`)) === '{"item": "x"}');
let limited = false;
for (let i = 0; i < 14; i++) {
  const x = await call(createOrder, null, { ...orderBody(), items: [{ menu_item_id: WATER.id, quantity: 1 }] }, '198.51.100.9');
  if (x.status === 429) limited = true;
}
check('limite di frequenza su create-order (per IP anonimizzato)', limited);
check('nessun dato di carta salvato (solo ID Stripe)', !(await val(`select string_agg(column_name, ',') from information_schema.columns where table_name = 'orders'`)).match(/card|pan|cvc|last4/));
check('log server senza token né email', !logs.join('\n').includes(tok1) && !logs.join('\n').includes('ospite@test.it'));
void body1;

console.log(`\n${pass} passati, ${fail} falliti`);
if (fail > 0) process.exit(1);
