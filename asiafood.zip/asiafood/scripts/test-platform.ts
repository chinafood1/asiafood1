/* eslint-disable @typescript-eslint/no-explicit-any */
// ─────────────────────────────────────────────────────────────
//  Fase 11 · Piattaforma backend: env validation, logger con redazione, formato errori standard,
//  rate limit/manutenzione, health/ready/support, cron con lock e job — con il database vero (PGlite).
//  Uso: npm run test:platform
// ─────────────────────────────────────────────────────────────
import { validateEnv, requireEnv, ConfigError, appEnv } from '../server/platform/env';
import { redact, redactString, createLogger } from '../server/platform/logger';
import { normalizeResponse, withPlatform, errorResponse, clientIpHash, __resetMaintenanceCache } from '../server/platform/http';
import { healthHandler, readyHandler, supportHandler, systemCron, recordSystemChecks } from '../server/platform/handlers';
import { runCronJob } from '../server/platform/cron';
import type { PlatformStore } from '../server/platform/store';
import { createTestDb } from './lib/pglite-db';

let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) { pass++; console.log('  ✓', name); } else { fail++; console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 600) : ''); }
}
const section = (t: string) => console.log(`\n── ${t}`);
const ENV0 = { ...process.env };
function setEnv(vars: Record<string, string | undefined>) {
  for (const k of Object.keys(process.env)) if (!(k in ENV0)) delete process.env[k];
  Object.assign(process.env, ENV0);
  for (const [k, v] of Object.entries(vars)) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
}
const quiet = () => undefined;

// ════════════════════════════════════════════════════════════
section('1. Ambienti e validazione env (Zod) — mai valori nei report');
{
  setEnv({ APP_ENV: undefined, CONTEXT: 'production' });
  check('Netlify CONTEXT=production → production', appEnv() === 'production');
  setEnv({ APP_ENV: undefined, CONTEXT: 'deploy-preview' });
  check('deploy preview → staging', appEnv() === 'staging');
  setEnv({ APP_ENV: 'development', CONTEXT: 'production' });
  check('APP_ENV esplicito ha priorità', appEnv() === 'development');
  const SECRET = 'eyJhbGciOiJIUzI1NiJ9.segreto-service-role-lunghissimo.firma';
  setEnv({ APP_ENV: 'production', SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_SERVICE_ROLE_KEY: SECRET, APP_URL: 'http://insicuro.it', VITE_SUPABASE_URL: undefined });
  const r = validateEnv(['core', 'stripe', 'orders']);
  check('produzione: APP_URL http rifiutato', r.invalid.some((i) => i.name === 'APP_URL'));
  check('produzione: secret Stripe e ORDER_TOKEN_SECRET mancanti segnalati per nome', ['STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET', 'ORDER_TOKEN_SECRET'].every((k) => r.missing.includes(k)), r);
  check('report senza valori dei segreti', !JSON.stringify(r).includes('segreto-service-role'));
  let thrown: unknown = null;
  try { requireEnv(['core', 'stripe']); } catch (e) { thrown = e; }
  check('requireEnv → ConfigError (fail safely)', thrown instanceof ConfigError && !(thrown as Error).message.includes('segreto'));
  setEnv({ APP_ENV: 'staging', SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_SERVICE_ROLE_KEY: SECRET, APP_URL: 'https://staging.asiafood.it', STRIPE_SECRET_KEY: 'sk_live_abcdef123456', STRIPE_WEBHOOK_SECRET: 'whsec_abc123', STRIPE_MODE: 'live' });
  check('staging con chiave Stripe LIVE → rifiutato', validateEnv(['core', 'stripe']).invalid.some((i) => /LIVE/.test(i.reason)));
  setEnv({ APP_ENV: 'production', SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_SERVICE_ROLE_KEY: SECRET, APP_URL: 'https://asiafood.it', STRIPE_SECRET_KEY: 'sk_test_abcdef123456', STRIPE_WEBHOOK_SECRET: 'whsec_abc123', STRIPE_MODE: 'live' });
  check('STRIPE_MODE diverso dal tipo di chiave → rifiutato', validateEnv(['stripe']).invalid.some((i) => i.name === 'STRIPE_MODE'));
  setEnv({ VITE_STRIPE_SECRET_KEY: 'sk_test_x', SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_SERVICE_ROLE_KEY: SECRET, APP_URL: 'https://asiafood.it' });
  check('segreto con prefisso VITE_ (finirebbe nel bundle) → rifiutato', validateEnv(['core']).invalid.some((i) => i.name === 'VITE_STRIPE_SECRET_KEY'));
  setEnv({});
}

// ════════════════════════════════════════════════════════════
section('2. Logger strutturato con redazione');
{
  const s = redactString('Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjMifQ.sig123456 sk_live_ABCDEF12345678 mario@rossi.it +39 333 1234567 https://x.supabase.co/storage/v1/object/sign/doc.pdf?token=abc123');
  check('JWT, chiavi Stripe, email, telefoni, URL firmati redatti', !/eyJ|sk_live_ABC|mario@|333 1234567|token=abc123/.test(s), s);
  const o = redact({ headers: { authorization: 'Bearer x', cookie: 'sb=1' }, email: 'a@b.it', phone: '123', stripe_secret: 'sk', input_tokens: 42, order_id: 'o1', nested: { api_key: 'k' } }) as any;
  check('chiavi sensibili → [redacted], metriche conservate', o.headers.authorization === '[redacted]' && o.headers.cookie === '[redacted]' && o.email === '[redacted]'
    && o.stripe_secret === '[redacted]' && o.nested.api_key === '[redacted]' && o.input_tokens === 42 && o.order_id === 'o1', o);
  const lines: string[] = [];
  const orig = console.log;
  console.log = (l: string) => lines.push(l);
  setEnv({ APP_ENV: 'production' });
  createLogger({ fn: 't' })('debug', 'debug nascosto');
  createLogger({ fn: 't', request_id: 'req-1' })('info', 'ordine', { payment_intent: 'pi_123', customer_email: 'x@y.it' });
  console.log = orig;
  setEnv({});
  check('produzione: debug disattivato', !lines.some((l) => l.includes('debug nascosto')));
  const j = JSON.parse(lines[0] ?? '{}');
  check('log JSON con request_id, livello e ambiente; email redatta', j.request_id === 'req-1' && j.level === 'info' && j.env === 'production' && j.customer_email === '[redacted]', j);
}

// ════════════════════════════════════════════════════════════
section('3. Formato errori standard { error: { code, message, requestId } }');
{
  const legacy = new Response(JSON.stringify({ error: 'RATE_LIMITED', message: 'Troppe richieste.', retry_after: 30 }), { status: 429, headers: { 'Content-Type': 'application/json' } });
  const n = await normalizeResponse(legacy, 'req-abc12345');
  const b = (await n.json()) as any;
  check('errore storico convertito, campi extra conservati, X-Request-Id', b.error.code === 'RATE_LIMITED' && b.error.message === 'Troppe richieste.' && b.error.requestId === 'req-abc12345'
    && b.retry_after === 30 && n.headers.get('X-Request-Id') === 'req-abc12345', b);
  const ok = await normalizeResponse(new Response(JSON.stringify({ ok: true }), { status: 200, headers: { 'Content-Type': 'application/json' } }), 'r1234567');
  check('risposte di successo invariate', ((await ok.json()) as any).ok === true && ok.headers.get('Cache-Control') === 'no-store');
  const boom = withPlatform('test', async () => { throw new Error('stack segreto at /var/task/x.js:1'); }, { store: () => null });
  const r = await boom(new Request('https://x.it/api/test', { method: 'POST' }));
  const rb = (await r.json()) as any;
  check('eccezione non gestita → 500 INTERNAL senza stack trace', r.status === 500 && rb.error.code === 'INTERNAL' && !JSON.stringify(rb).includes('stack') && /^[0-9a-f-]{36}$/.test(rb.error.requestId), rb);
  const rid = await withPlatform('test', async () => errorResponse(404, 'NOT_FOUND', 'Non trovato', 'x'), { store: () => null })(new Request('https://x.it/a', { headers: { 'x-request-id': 'client-req-123' } }));
  check('request id del client riusato se valido', rid.headers.get('X-Request-Id') === 'client-req-123');
  setEnv({ SUPABASE_URL: undefined, VITE_SUPABASE_URL: undefined, SUPABASE_SERVICE_ROLE_KEY: undefined });
  const nc = await withPlatform('test', async () => new Response('ok'), { envGroups: ['core'], store: () => null })(new Request('https://x.it/a'));
  check('env mancante → 503 NOT_CONFIGURED (fail safely)', nc.status === 503 && ((await nc.json()) as any).error.code === 'NOT_CONFIGURED');
  setEnv({});
  const h1 = clientIpHash(new Request('https://x.it', { headers: { 'x-nf-client-connection-ip': '203.0.113.5' } }));
  check('hash IP (32 hex) senza IP in chiaro', !!h1 && /^[0-9a-f]{32}$/.test(h1) && !h1.includes('203'));
}

// ════════════════════════════════════════════════════════════
section('4. Rate limit condiviso e manutenzione (database reale)');
const { db, store: testStore } = await createTestDb();
const store: PlatformStore = { rpc: (fn, args = {}) => testStore.rpc(fn, args), deleteAuthUser: async (id) => { deletedAuth.push(id); } };
const deletedAuth: string[] = [];
{
  let calls = 0;
  const h = withPlatform('limited', async () => { calls++; return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json' } }); },
    { store: () => store, rateLimit: { bucket: 'test_ep', limit: 3, windowSeconds: 60 } });
  const req = () => new Request('https://x.it/api/limited', { method: 'POST', headers: { 'x-nf-client-connection-ip': '198.51.100.1' } });
  const codes = [];
  for (let i = 0; i < 5; i++) codes.push((await h(req())).status);
  check('4ª e 5ª richiesta → 429, handler non eseguito', codes.join(',') === '200,200,200,429,429' && calls === 3, codes);
  const other = await h(new Request('https://x.it/api/limited', { method: 'POST', headers: { 'x-nf-client-connection-ip': '198.51.100.2' } }));
  check('altro IP non limitato', other.status === 200);
  await db.exec(`update public.platform_settings set value = 'true' where key = 'maintenance_mode'`);
  __resetMaintenanceCache();
  const m = withPlatform('create', async () => new Response('{}', { headers: { 'Content-Type': 'application/json' } }), { store: () => store, mutating: true });
  const mr = await m(new Request('https://x.it/api/orders/create', { method: 'POST' }));
  const mb = (await mr.json()) as any;
  check('manutenzione: endpoint che scrivono → 503 MAINTENANCE', mr.status === 503 && mb.error.code === 'MAINTENANCE' && /aggiornamento/.test(mb.error.message));
  const get = await m(new Request('https://x.it/api/orders/create', { method: 'GET' }));
  check('manutenzione: letture consentite', get.status === 200);
  await db.exec(`update public.platform_settings set value = 'false' where key = 'maintenance_mode'`);
  __resetMaintenanceCache();
  const err500 = withPlatform('fails', async () => new Response(JSON.stringify({ error: 'STRIPE_UNAVAILABLE', message: 'Il servizio di pagamento non risponde.' }), { status: 503, headers: { 'Content-Type': 'application/json' } }), { store: () => store });
  await err500(new Request('https://x.it/api/fails', { method: 'POST' }));
  const logged = (await db.query<any>(`select code, route, request_id from public.system_error_log where source = 'server' order by id desc limit 1`)).rows[0];
  check('errori 5xx registrati in system_error_log con codice, rotta e request id', logged?.code === 'STRIPE_UNAVAILABLE' && logged.route === '/api/fails' && !!logged.request_id, logged);
}

// ════════════════════════════════════════════════════════════
section('5. /api/health e /api/ready');
{
  const h = await healthHandler(new Request('https://x.it/api/health'), { store, log: quiet });
  const hb = (await h.json()) as any;
  check('health: 200, database ok, ora del server, nessun segreto', h.status === 200 && hb.status === 'ok' && hb.checks.database === 'ok' && !!hb.time
    && !JSON.stringify(hb).match(/key|secret|supabase\.co|password/i), hb);
  const down: PlatformStore = { rpc: async () => { throw new Error('connection refused'); } };
  const hd = await healthHandler(new Request('https://x.it/api/health'), { store: down, log: quiet });
  check('health: database giù → 503 "degraded" (per l\'uptime monitor)', hd.status === 503 && ((await hd.json()) as any).checks.database === 'unreachable');
  setEnv({ APP_ENV: 'production', HEALTH_CHECK_TOKEN: 'token-health-check-1234', SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_SERVICE_ROLE_KEY: 'x'.repeat(40), APP_URL: 'https://asiafood.it' });
  const pub = (await (await readyHandler(new Request('https://x.it/api/ready'), { store, log: quiet })).json()) as any;
  check('ready pubblico: solo esito', Object.keys(pub).join() === 'ready' && pub.ready === false);
  const det = (await (await readyHandler(new Request('https://x.it/api/ready', { headers: { 'x-health-token': 'token-health-check-1234' } }), { store, log: quiet })).json()) as any;
  check('ready con token: nomi delle variabili mancanti, mai valori', det.checks.missing.includes('STRIPE_SECRET_KEY') && !JSON.stringify(det).includes('x'.repeat(40)), det);
  const wrong = (await (await readyHandler(new Request('https://x.it/api/ready', { headers: { 'x-health-token': 'sbagliato' } }), { store, log: quiet })).json()) as any;
  check('token errato → nessun dettaglio', !('checks' in wrong));
  setEnv({});
}

// ════════════════════════════════════════════════════════════
section('6. /api/support (ospiti, Turnstile)');
{
  const post = (body: unknown, ip = '192.0.2.10') => new Request('https://x.it/api/support', { method: 'POST', headers: { 'x-nf-client-connection-ip': ip }, body: JSON.stringify(body) });
  const valid = { category: 'business', subject: 'Informazioni', description: 'Vorrei informazioni sui piani per il mio ristorante.', email: 'Mario@Test.it', name: 'Mario', turnstile_token: 'ok-token' };
  const turnstile = async (t: string | null | undefined) => ({ ok: t === 'ok-token', reason: t === 'ok-token' ? undefined : 'invalid' });
  const r1 = await supportHandler(post(valid), { store, log: quiet, turnstile });
  const b1 = (await r1.json()) as any;
  check('ticket creato con riferimento', r1.status === 201 && /^T-/.test(b1.reference), b1);
  const r2 = await supportHandler(post({ ...valid, turnstile_token: 'bot' }), { store, log: quiet, turnstile });
  check('Turnstile non superato → 400 CAPTCHA_FAILED', r2.status === 400 && ((await r2.json()) as any).error.code === 'CAPTCHA_FAILED');
  const r3 = await supportHandler(post({ ...valid, email: 'no', description: 'corta' }), { store, log: quiet, turnstile });
  const b3 = (await r3.json()) as any;
  check('validazione campi con errori per campo', r3.status === 422 && b3.fields.email && b3.fields.description, b3);
  const r4 = await supportHandler(new Request('https://x.it/api/support', { method: 'POST', body: '{"x":' }), { store, log: quiet, turnstile });
  check('JSON non valido → 400', r4.status === 400);
  const r5 = await supportHandler(post({ ...valid, category: '<script>' }), { store, log: quiet, turnstile });
  check('categoria sconosciuta normalizzata (niente valori arbitrari)', r5.status === 201);
  let limited = 0;
  for (let i = 0; i < 6; i++) {
    const r = await supportHandler(post(valid, '192.0.2.99'), { store, log: quiet, turnstile });
    if (r.status === 429) limited++;
  }
  check('ospite: oltre 5 ticket/ora dallo stesso IP → 429', limited >= 1, limited);
  const bad = await supportHandler(post({ ...valid, order_number: 'AF-000000-XXXX', order_token: 'x' }, '192.0.2.50'), { store, log: quiet, turnstile });
  check('ordine non accessibile → errore di campo (nessun dettaglio su altri ordini)', bad.status === 422 && ((await bad.json()) as any).fields.order_number);
}

// ════════════════════════════════════════════════════════════
section('7. Cron di sistema, lock, retention, cancellazioni');
{
  // Esecuzioni concorrenti: una sola passa
  let runs = 0;
  const slow = () => new Promise((res) => setTimeout(() => { runs++; res({ ok: true }); }, 50));
  const [a, b] = await Promise.all([runCronJob(store, 'orders-cron', 60, slow), runCronJob(store, 'orders-cron', 60, slow)]);
  check('due istanze in parallelo: una eseguita, l\'altra saltata', runs === 1 && [a.status, b.status].sort().join() === 'completed,skipped', [a, b]);
  const again = await runCronJob(store, 'orders-cron', 60, slow);
  check('lock rilasciato a fine job', again.status === 'completed');
  const failing = await runCronJob(store, 'billing-cron', 60, async () => { throw new Error('Stripe down'); });
  const job = (await db.query<any>(`select status, last_error from public.background_jobs where job_type = 'billing-cron' order by created_at desc limit 1`)).rows[0];
  check('job fallito registrato (stato, errore) e catturato', failing.status === 'failed' && job.status === 'failed' && /Stripe down/.test(job.last_error));
  check('errore cron in system_error_log', (await db.query<any>(`select count(*)::int n from public.system_error_log where source = 'cron'`)).rows[0].n >= 1);

  // Utente con cancellazione scaduta → anonimizzato dal DB, eliminato da Auth dal cron
  const uid = 'c9999999-9999-4999-8999-999999999999';
  await db.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1, 'del@test.it', '{"full_name":"Da Eliminare"}')`, [uid]);
  await db.query(`insert into public.account_deletion_requests (user_id, scheduled_for) values ($1, now() - interval '1 minute')`, [uid]);
  setEnv({ APP_ENV: 'staging', SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_SERVICE_ROLE_KEY: 'y'.repeat(40), APP_URL: 'https://staging.asiafood.it' });
  const fetchImpl = (async (u: string) => new Response(u.endsWith('sitemap.xml') ? '<?xml version="1.0"?><sitemapindex></sitemapindex>' : 'User-agent: *', { status: 200 })) as unknown as typeof fetch;
  const res = await systemCron({ store, log: quiet, fetchImpl });
  check('system-cron completato', res.status === 'completed', res);
  const r = res.result as any;
  check('controlli di sistema registrati (env, health, dominio, sitemap)', r.checks.mon_health === 'pass' && r.checks.env_secrets === 'pass' && r.checks.env_sitemap === 'pass', r.checks);
  check('retention eseguita e registrata', (r.retention as any)?.status === 'completed' && (await db.query<any>(`select count(*)::int n from public.background_jobs where job_type = 'retention_cleanup' and status = 'completed'`)).rows[0].n === 1);
  check('cancellazione: utente Auth eliminato dopo anonimizzazione', deletedAuth.includes(uid) && r.deletions.hard_deleted === 1);
  check('richiesta completata (hard_deleted)', (await db.query<any>(`select status from public.account_deletion_requests where user_id = $1`, [uid])).rows[0].status === 'completed');
  const res2 = await systemCron({ store, log: quiet, fetchImpl });
  check('retention non ripetuta entro 6 ore', !('retention' in (res2.result as any)));
  const checks = await recordSystemChecks({ store, log: quiet, fetchImpl });
  check('dominio .netlify.app o assente in staging → "pending" (non blocca)', ['pending', 'pass'].includes(checks.env_domain));
  const lc = (await db.query<any>(`select key, status, source from public.launch_checks where source = 'system' order by key`)).rows;
  check('checklist: esiti di sistema salvati (senza valori)', lc.length >= 7 && !JSON.stringify(lc).includes('y'.repeat(40)), lc);
  setEnv({});
}

console.log(`\n${pass} passati, ${fail} falliti`);
process.exit(fail ? 1 : 0);
