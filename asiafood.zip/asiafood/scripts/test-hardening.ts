/* eslint-disable @typescript-eslint/no-explicit-any */
// ─────────────────────────────────────────────────────────────
//  Fase 11 · Hardening: test di sicurezza (RLS/IDOR/escalation), GDPR, rate limit,
//  audit, job, kill switch, launch checklist — sulle VERE migrazioni (PGlite)
//  con i veri handler ordini/webhook e uno Stripe simulato.
//  Uso: npm run test:hardening
// ─────────────────────────────────────────────────────────────
import { stripeWebhook } from '../server/billing/handlers';
import type { BillingDeps, HttpResponse } from '../server/billing/types';
import { createOrder } from '../server/orders/handlers';
import type { OrdersDeps } from '../server/orders/types';
import { FakeStripe, type FakeEvent } from './lib/fake-stripe';
import { createTestDb } from './lib/pglite-db';

const { db, store } = await createTestDb();
const stripe = new FakeStripe();
const WEBHOOK_SECRET = 'whsec_test_hardening';
const log = () => undefined;

let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) { pass++; console.log('  ✓', name); } else { fail++; console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 700) : ''); }
}
const section = (t: string) => console.log(`\n── ${t}`);

/** Esegue come utente (authenticated) o anonimo. amrMinutesAgo simula una ri-autenticazione recente nel JWT. */
async function as(user: string | null, sql: string, params: unknown[] = [], opts: { amrMinutesAgo?: number; headers?: Record<string, string> } = {}) {
  const r = user ? 'authenticated' : 'anon';
  const claims = opts.amrMinutesAgo != null ? JSON.stringify({ sub: user, role: r, amr: [{ method: 'password', timestamp: Math.floor(Date.now() / 1000) - opts.amrMinutesAgo * 60 }] }) : '';
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${user ?? ''}', false); select set_config('request.jwt.claim.role', '${r}', false);
    select set_config('request.jwt.claims', '${claims}', false); select set_config('request.headers', '${JSON.stringify(opts.headers ?? {})}', false); set role ${r};`);
  try {
    const res = await db.query<any>(sql, params);
    return { ok: true as const, rows: res.rows, err: '' };
  } catch (e) {
    return { ok: false as const, rows: [] as any[], err: (e as Error).message };
  } finally {
    await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', '', false);
      select set_config('request.jwt.claims', '', false); select set_config('request.headers', '', false);`);
  }
}
const q1 = async (sql: string, params: unknown[] = []) => (await db.query<any>(sql, params)).rows[0];
const val = async (sql: string, params: unknown[] = []) => Object.values((await q1(sql, params)) ?? {})[0] as any;
const enc = (a: unknown) => (a !== null && typeof a === 'object' ? JSON.stringify(a) : a);
const rpc1 = async (user: string | null, fn: string, args: unknown[] = [], opts: Parameters<typeof as>[3] = {}) => {
  const r = await as(user, `select public.${fn}(${args.map((_, i) => `$${i + 1}`).join(', ')}) as r`, args.map(enc), opts);
  return { ok: r.ok, r: r.rows[0]?.r, err: r.err };
};
const denied = (r: { ok: boolean; err: string }) => !r.ok && /permission denied|Non autorizzato|Solo backend|42501|autorizz/i.test(r.err);

const U = {
  admin: 'b1111111-1111-4111-8111-111111111111',
  owner: 'b2222222-2222-4222-8222-222222222222',
  alice: 'b3333333-3333-4333-8333-333333333333',
  bob: 'b4444444-4444-4444-8444-444444444444',
  r1: 'b5555555-5555-4555-8555-555555555555',
  r2: 'b6666666-6666-4666-8666-666666666666',
  owner2: 'b7777777-7777-4777-8777-777777777777',
  carla: 'b8888888-8888-4888-8888-888888888888',
};
for (const [k, id] of Object.entries(U)) {
  await db.query(`insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values ($1, $2, $3, now())`, [id, `${k}@test.it`, JSON.stringify({ full_name: `${k} Test` })]);
}
await db.exec(`update public.profiles set role = 'admin' where id = '${U.admin}';`);
const R = (n: number) => `e0000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const SEOUL = R(5);
const KOEN = R(2);
await db.exec(`
insert into public.restaurant_members (restaurant_id, user_id, role, status) values ('${SEOUL}', '${U.owner}', 'owner', 'active'), ('${KOEN}', '${U.owner2}', 'owner', 'active');
delete from public.restaurant_hours where restaurant_id = '${SEOUL}';
insert into public.restaurant_hours (restaurant_id, day_of_week, opens_at, closes_at, is_closed) select '${SEOUL}', d, '00:00', '00:00', false from generate_series(1, 7) d;
update public.platform_settings set value = 'true' where key = 'marketplace_platform_collection_test';
`);
await store.rpc('billing_set_environment', { p_env: 'test' });

const ordersDeps: OrdersDeps = {
  stripe: stripe.asStripe(), store, config: { env: 'test', appUrl: 'https://asiafood.test', tokenSecret: 'secret-test' },
  verifyUser: async (t) => (t?.startsWith('tok-') ? t.slice(4) : null), log,
};
const billingDeps: BillingDeps = {
  stripe: stripe.asStripe(), store,
  config: { env: 'test', appUrl: 'https://asiafood.test', webhookSecret: WEBHOOK_SECRET, taxEnabled: false, portalConfigurationId: null, allowPromotionCodes: false },
  verifyUser: ordersDeps.verifyUser, log,
};
async function deliver(events: FakeEvent[] = stripe.drain()) {
  const out: HttpResponse[] = [];
  for (const e of events) {
    const { payload, header } = stripe.sign(e, WEBHOOK_SECRET);
    out.push(await stripeWebhook({ method: 'POST', header: (n) => (n === 'stripe-signature' ? header : null), body: payload }, billingDeps));
  }
  return out;
}
const URA = await q1(`select id from public.menu_items where restaurant_id = $1 and name = 'Uramaki salmone e avocado'`, [SEOUL]);
const V8 = await val(`select id from public.menu_item_variants where menu_item_id = $1 and name = '8 pezzi'`, [URA.id]);
let seq = 0;
async function paidOrder(user: string | null, orderType: 'takeaway' | 'delivery' = 'takeaway') {
  const key = `hd-${Date.now()}-${++seq}`;
  const body: any = {
    restaurant_id: SEOUL, order_type: orderType, items: [{ menu_item_id: URA.id, variant_id: V8, quantity: 1 }], session_id: `s-${key}`, idempotency_key: key,
    contact: { name: 'Alice Rossi', email: `cliente${seq}@test.it`, phone: '+39 333 1112223' },
  };
  const res = await createOrder({ method: 'POST', header: (n) => (n === 'authorization' && user ? `Bearer tok-${user}` : n === 'x-nf-client-connection-ip' ? `203.0.113.${seq}` : null), body: JSON.stringify(body) }, ordersDeps);
  const j = res.body as any;
  if (!j.ok) throw new Error(`createOrder: ${JSON.stringify(j)}`);
  const o = await q1(`select * from public.orders where id = $1`, [j.order_id]);
  stripe.payIntent(o.stripe_payment_intent_id);
  await deliver();
  return { id: j.order_id as string, number: j.order_number as string, token: j.access_token as string };
}

// ════════════════════════════════════════════════════════════
section('1. Funzioni esposte: nessuna funzione Admin/backend eseguibile da anonimi');
{
  const exposed = await db.query<any>(`
    select p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prosecdef and p.prorettype <> 'trigger'::regtype
       and has_function_privilege('anon', p.oid, 'execute')
       and (p.proname like 'admin\\_%' or p.prosrc like '%assert_service()%' or p.prosrc ~ 'auth\\.uid\\(\\) is not null and not public\\.is_admin\\(\\)')`);
  check('nessuna funzione admin_* / solo-backend eseguibile da anon', exposed.rows.length === 0, exposed.rows.map((r) => r.proname));
  // Allowlist rivista: ogni nuova funzione SECURITY DEFINER eseguibile da anon deve essere aggiunta qui consapevolmente
  const ALLOW = new Set(['auth_recent', 'can_manage_restaurant', 'can_refund_orders', 'can_view_orders', 'cancel_reservation_by_code', 'cart_load', 'cart_save', 'claim_coupon',
    'client_error_record', 'consent_record', 'create_reservation', 'current_user_role', 'demo_data_visible', 'get_reservation_availability', 'is_admin', 'is_rider', 'list_reviews',
    'loyalty_level_for', 'menu_category_is_public', 'menu_is_public', 'order_customer_cancel', 'order_delivery', 'order_issue_create', 'order_member_role', 'order_next_slot',
    'order_public_info', 'order_quote', 'order_slot_count', 'order_slots', 'order_track', 'orderable_restaurants', 'owns_restaurant', 'public_display_name', 'public_runtime_config',
    'restaurant_effective_plan', 'restaurant_effective_subscription', 'restaurant_feature_limit', 'restaurant_has_feature', 'restaurant_is_claimable', 'restaurant_is_public',
    'restaurant_open_in_window', 'restaurant_open_status', 'restaurant_rating', 'restaurant_slug_redirect', 'restaurant_slug_redirects', 'restaurants_available_on',
    'restaurants_delivering_to', 'restaurants_rating', 'review_votes_count', 'sponsored_now', 'sponsored_slots', 'subscription_grants_access', 'subscription_in_env',
    'system_ping', 'track_app_event', 'track_campaign_click', 'track_event', 'track_sponsored_event', 'web_vital_record', 'assert_feature', 'assert_limit',
    // Fase 12 (go-to-market): solo aggregati pubblici / eventi senza dati personali, con rate limit interno
    'founding_badge', 'market_landing', 'record_visit', 'running_experiments', 'submit_feedback', 'track_qr_scan',
    // Fase 13: ricerca anonima (rate limit), assegnazione e conversione esperimenti (solo con consenso, rate limit)
    'log_search', 'experiment_assign', 'experiment_goal']);
  const anonDefiner = await db.query<any>(`
    select distinct p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prosecdef and p.prorettype <> 'trigger'::regtype and has_function_privilege('anon', p.oid, 'execute')`);
  const extra = anonDefiner.rows.map((r) => r.proname).filter((n: string) => !ALLOW.has(n));
  check('funzioni SECURITY DEFINER eseguibili da anon = allowlist rivista', extra.length === 0, extra);

  for (const fn of ['marketplace_stats', 'ai_admin_stats', 'admin_orders', 'admin_revenue_stats', 'billing_trial_expiring', 'ai_purge', 'admin_system_status', 'retention_cleanup']) {
    const r = await as(null, `select public.${fn}()`);
    check(`anon → ${fn}() negato`, denied(r), r.err);
  }
  const s = await as(null, `select public.billing_setting('marketplace_platform_collection_test')`);
  check('anon non legge impostazioni interne con billing_setting()', denied(s), s.err);
  const direct = await as(null, `select key from public.platform_settings where key in ('ai_ip_limit_per_hour', 'marketplace_platform_collection_test', 'review_flag_threshold')`);
  check('RLS platform_settings: chiavi interne non leggibili dal pubblico', direct.ok && direct.rows.length === 0, direct.rows);
  const pub = await as(null, `select key from public.platform_settings where key in ('orders_enabled', 'maintenance_mode')`);
  check('chiavi pubbliche (allowlist) leggibili', pub.rows.length === 2);
  const cfg = await rpc1(null, 'public_runtime_config');
  check('public_runtime_config senza chiavi sensibili', cfg.ok && !('marketplace_platform_collection_test' in cfg.r.settings) && !('ai_ip_limit_per_hour' in cfg.r.settings) && 'maintenance_mode' in cfg.r.settings, Object.keys(cfg.r?.settings ?? {}));
  check('public_runtime_config include versioni documenti legali', cfg.r?.legal?.privacy?.url === '/privacy');
  const asUser = await rpc1(U.alice, 'admin_system_status');
  check('utente normale → /admin/system negato (server-side, non solo UI)', denied(asUser), asUser.err);
  const asAdmin = await rpc1(U.admin, 'admin_system_status');
  check('Admin → stato di sistema', asAdmin.ok && Array.isArray(asAdmin.r.flags) && asAdmin.r.db != null, asAdmin.err);
  const svc = await rpc1(null, 'job_lock_acquire', ['x', 'y', 10]);
  check('anon → funzioni solo-backend negate (assert_service rafforzato)', denied(svc), svc.err);
}

// ════════════════════════════════════════════════════════════
section('2. Escalation di privilegi e IDOR (utenti, ristoratori, Rider)');
const oA = await paidOrder(U.alice);
const oB = await paidOrder(U.bob);
{
  const esc = await as(U.alice, `update public.profiles set role = 'admin', is_blocked = false where id = $1 returning role`, [U.alice]);
  check('utente non può promuoversi Admin (ruolo invariato)', esc.ok && esc.rows[0]?.role === 'customer', esc);
  const rider = await as(U.alice, `update public.profiles set role = 'rider' where id = $1 returning role`, [U.alice]);
  check('utente non può assegnarsi il ruolo Rider', rider.rows[0]?.role === 'customer');
  const other = await as(U.alice, `update public.profiles set full_name = 'hack' where id = $1`, [U.bob]);
  const bobName = await val(`select full_name from public.profiles where id = $1`, [U.bob]);
  check('utente A non modifica il profilo di B', other.ok && bobName !== 'hack');
  const peek = await as(U.alice, `select id from public.orders where id = $1`, [oB.id]);
  check('User A → SELECT ordine di User B: DENY (0 righe)', peek.ok && peek.rows.length === 0);
  const own = await as(U.alice, `select id from public.orders where id = $1`, [oA.id]);
  check('User A legge il proprio ordine', own.rows.length === 1);
  const items = await as(U.alice, `select id from public.order_items where order_id = $1`, [oB.id]);
  check('User A → righe ordine di B: DENY', items.rows.length === 0);
  const track = await rpc1(null, 'order_track', [oB.number, 'token-sbagliato']);
  check('ospite con token errato non vede l\'ordine', track.ok ? track.r == null || track.r?.found === false : true, track);
  const addr = await as(U.alice, `select count(*)::int n from public.customer_addresses where user_id = $1`, [U.bob]);
  check('indirizzi di altri non leggibili', addr.rows[0]?.n === 0);
  const escalMember = await as(U.alice, `insert into public.restaurant_members (restaurant_id, user_id, role, status) values ($1, $2, 'owner', 'active')`, [SEOUL, U.alice]);
  check('utente non può aggiungersi come titolare di un locale', !escalMember.ok);

  // Ristoratore A vs locale B
  const upd = await as(U.owner, `update public.restaurants set name = 'hack' where id = $1`, [KOEN]);
  const koenName = await val(`select name from public.restaurants where id = $1`, [KOEN]);
  check('Restaurant A → UPDATE Restaurant B: DENY', upd.ok && koenName !== 'hack');
  const selfPromo = await as(U.owner, `update public.restaurants set is_sponsored = true, is_verified = true, subscription_plan = 'top', owner_id = $2 where id = $1`, [SEOUL, U.owner]);
  const s = await q1(`select is_sponsored, is_verified, subscription_plan from public.restaurants where id = $1`, [SEOUL]);
  check('ristoratore non può auto-assegnarsi sponsorizzazione/verifica/piano (mass assignment)', selfPromo.ok && !s.is_sponsored && s.subscription_plan !== 'top');
  for (const [fn, args] of [
    ['restaurant_orders', [KOEN, 'new', 50]], ['restaurant_analytics', [KOEN, 30]], ['get_billing_overview', [KOEN]], ['restaurant_order_stats', [KOEN, 30]],
    ['restaurant_reviews_manage', [KOEN, 20, 0]], ['restaurant_engagement_stats', [KOEN, 30]], ['restaurant_deliveries', [KOEN]],
  ] as const) {
    const r = await rpc1(U.owner, fn, [...args]);
    check(`Restaurant A → ${fn}(B): DENY`, !r.ok, r.err);
  }
  const resv = await as(U.owner, `select count(*)::int n from public.reservations where restaurant_id = $1`, [KOEN]);
  check('Restaurant A → prenotazioni di B: 0 righe', resv.rows[0]?.n === 0);
  const cpn = await as(U.owner, `select count(*)::int n from public.coupon_claims where restaurant_id = $1`, [KOEN]);
  check('Restaurant A → coupon riscattati di B: 0 righe', cpn.rows[0]?.n === 0);
  const subs = await as(U.owner, `select count(*)::int n from public.subscriptions where restaurant_id = $1`, [KOEN]);
  check('Restaurant A → abbonamento/billing di B: 0 righe', subs.rows[0]?.n === 0);
  const ordersB = await as(U.owner2, `select count(*)::int n from public.orders where restaurant_id = $1`, [SEOUL]);
  check('Restaurant B → ordini (clienti) di A: 0 righe', ordersB.rows[0]?.n === 0);
  const act = await rpc1(U.owner2, 'order_action', [oA.id, 'accept', { preparation_minutes: 20 }]);
  check('Restaurant B non può accettare un ordine di A', !act.ok, act.err);

  // Rider A vs Rider B
  for (const u of [U.r1, U.r2]) {
    await rpc1(u, 'rider_apply', [{ first_name: u === U.r1 ? 'Primo' : 'Secondo', last_name: 'Rider', phone: '+39 333 0000000', city: 'Taranto', vehicle_type: 'scooter', terms_accepted: true }]);
    const id = await val(`select id from public.rider_profiles where user_id = $1`, [u]);
    await rpc1(U.admin, 'admin_rider_action', [id, 'approve', null]);
  }
  const r2 = await val(`select id from public.rider_profiles where user_id = $1`, [U.r2]);
  const seeB = await as(U.r1, `select count(*)::int n from public.rider_profiles where id = $1`, [r2]);
  check('Rider A → profilo Rider B: DENY', seeB.rows[0]?.n === 0);
  const locB = await as(U.r1, `select count(*)::int n from public.rider_locations where rider_id = $1`, [r2]);
  check('Rider A → SELECT posizioni Rider B: DENY', locB.rows[0]?.n === 0);
  const avB = await as(U.r1, `select count(*)::int n from public.rider_availability where rider_id = $1`, [r2]);
  check('Rider A → disponibilità Rider B: DENY', avB.rows[0]?.n === 0);
  const jobs = await as(U.r1, `select count(*)::int n from public.delivery_jobs`);
  check('Rider A → nessun job non suo visibile', jobs.rows[0]?.n === 0);
  const orderPeek = await as(U.r1, `select count(*)::int n from public.orders`);
  check('Rider A → nessun ordine non pertinente visibile', orderPeek.rows[0]?.n === 0);
  const fake = await rpc1(U.r1, 'rider_job_action', ['00000000-0000-4000-8000-000000000001', 'picked_up', {}]);
  check('Rider A non modifica job non assegnati', !fake.ok);
  const earn = await as(U.r1, `update public.rider_earnings set total = 999`);
  check('Rider non modifica compensi', !earn.ok || (await val(`select count(*)::int from public.rider_earnings where total = 999`)) === 0);
}

// ════════════════════════════════════════════════════════════
section('3. Audit centralizzato');
{
  const bobProfile = U.bob;
  await as(U.admin, `update public.profiles set role = 'restaurant_owner' where id = $1`, [bobProfile]);
  const a = await q1(`select * from public.admin_audit_logs where action = 'role_change' and entity_id = $1`, [bobProfile]);
  check('cambio ruolo registrato in admin_audit_logs (attore, ruolo)', a && a.admin_id === U.admin && a.actor_role === 'admin' && a.details.changes.role.to === 'restaurant_owner', a);
  await as(U.admin, `update public.profiles set role = 'customer' where id = $1`, [bobProfile]);
  const del = await as(U.admin, `delete from public.admin_audit_logs`);
  check('log di audit non cancellabili nemmeno dall\'Admin', !del.ok && /non possono essere cancellati|permission/i.test(del.err), del.err);
  const hard = await as(U.admin, `delete from public.restaurants where id = $1`, [SEOUL]);
  check('locale con ordini: niente DELETE fisico (va disattivato)', !hard.ok && /disattivalo/.test(hard.err), hard.err);
  const delProfile = await as(U.admin, `delete from public.profiles where id = $1`, [U.carla]);
  check('profilo: niente DELETE diretto (workflow GDPR)', !delProfile.ok, delProfile.err);
  const sess = await rpc1(U.admin, 'record_admin_session');
  const sl = await q1(`select * from public.security_audit_logs where action = 'admin_session' and actor_user_id = $1`, [U.admin]);
  check('sessione Admin registrata in security_audit_logs', sess.ok && !!sl);
  await rpc1(U.admin, 'record_admin_session');
  check('sessione Admin non duplicata entro 1 ora', (await val(`select count(*)::int from public.security_audit_logs where action = 'admin_session'`)) === 1);
  const list = await rpc1(U.admin, 'admin_audit_list', ['admin', 10, 0, null]);
  check('Admin: log paginati', list.ok && list.r.total >= 1 && list.r.rows.length >= 1);
  const listUser = await rpc1(U.alice, 'admin_audit_list', ['admin', 10, 0, null]);
  check('utente: log Admin negati', denied(listUser));
}

// ════════════════════════════════════════════════════════════
section('4. Consensi (cookie/GDPR) e documenti legali');
{
  const anonId = 'anon_Test_1234567890';
  const c1 = await rpc1(null, 'consent_record', [{ analytics: true, marketing: false, personalization: false }, anonId, null, 'banner']);
  check('ospite: consenso registrato con ID anonimo', c1.ok && c1.r.choices.analytics.granted === true && c1.r.choices.necessary.granted === true, c1.err);
  const n1 = await val(`select count(*)::int from public.user_consents where anonymous_id = $1`, [anonId]);
  await rpc1(null, 'consent_record', [{ analytics: true, marketing: false, personalization: false }, anonId, null, 'banner']);
  const n2 = await val(`select count(*)::int from public.user_consents where anonymous_id = $1`, [anonId]);
  check('scelta invariata → nessuna riga duplicata', n1 === 4 && n2 === 4, { n1, n2 });
  await rpc1(null, 'consent_record', [{ analytics: false }, anonId, null, 'settings']);
  check('revoca registrata come nuova riga (storico)', (await val(`select count(*)::int from public.user_consents where anonymous_id = $1`, [anonId])) === 5);
  const badId = await rpc1(null, 'consent_record', [{ analytics: true }, 'x', null, 'banner']);
  check('ID anonimo non valido rifiutato', !badId.ok);
  const cu = await rpc1(U.alice, 'consent_record', [{ analytics: true, marketing: true, personalization: true }, null, null, 'settings']);
  check('utente: consenso marketing allinea preferenze', cu.ok && (await val(`select marketing_opt_in from public.profiles where id = $1`, [U.alice])) === true);
  const mine = await rpc1(U.alice, 'my_consents');
  check('utente: storico consensi', mine.ok && mine.r.history.length >= 4);
  const peek = await as(U.bob, `select count(*)::int n from public.user_consents where user_id = $1`, [U.alice]);
  check('consensi di altri non leggibili', peek.rows[0]?.n === 0);
  const direct = await as(U.alice, `insert into public.user_consents (user_id, consent_type, granted, policy_version) values ($1, 'analytics', true, 'x')`, [U.alice]);
  check('INSERT diretto nei consensi non consentito (solo RPC)', !direct.ok);
  const lv = await rpc1(U.admin, 'admin_legal_version_create', ['privacy', '2026-11-01', '/privacy', null, false]);
  const cur = await q1(`select version, is_draft from public.legal_document_versions where document_type = 'privacy' and is_current`);
  check('nuova versione privacy → corrente, precedente archiviata, policy_version aggiornata', lv.ok && cur.version === '2026-11-01'
    && (await val(`select value #>> '{}' from public.platform_settings where key = 'consent_policy_version'`)) === '2026-11-01');
  const lvUser = await rpc1(U.alice, 'admin_legal_version_create', ['privacy', 'x', '/privacy', null, false]);
  check('utente non registra versioni legali', denied(lvUser));
}

// ════════════════════════════════════════════════════════════
section('5. Export dati (diritto di accesso)');
{
  await as(U.alice, `insert into public.favorites (user_id, restaurant_id) values ($1, $2)`, [U.alice, SEOUL]);
  const ex = await rpc1(U.alice, 'privacy_export');
  const d = ex.r?.data;
  check('export: profilo, preferiti, ordini, consensi, loyalty', ex.ok && d.profile.email === 'alice@test.it' && d.favorites.length === 1 && d.orders.length >= 1 && d.consents.length >= 4 && 'loyalty' in d, ex.err);
  const txt = JSON.stringify(d);
  check('export senza segreti (token, hash, id Stripe, chiavi push)', !/token_hash|stripe_payment_intent|p256dh|access_token|pi_|whsec|sk_test/.test(txt));
  check('export: righe ordine incluse', d.orders[0].items.length >= 1);
  const other = await rpc1(null, 'privacy_export');
  check('export senza login negato', !other.ok);
  const direct = await rpc1(U.alice, 'privacy_export_data', [U.bob]);
  check('funzione interna privacy_export_data non chiamabile dal client (IDOR)', denied(direct), direct.err);
  await rpc1(U.alice, 'privacy_export');
  await rpc1(U.alice, 'privacy_export');
  const lim = await rpc1(U.alice, 'privacy_export');
  check('export: massimo 3 al giorno', !lim.ok && /RATE_LIMITED/.test(lim.err), lim.err);
  const st = await rpc1(U.alice, 'my_privacy_status');
  check('stato privacy: storico export', st.ok && st.r.exports.length >= 3);
}

// ════════════════════════════════════════════════════════════
section('6. Cancellazione account (ri-autenticazione, periodo di sicurezza, anonimizzazione)');
{
  const noAuth = await rpc1(U.alice, 'request_account_deletion', ['test']);
  check('senza ri-autenticazione recente → REAUTH_REQUIRED', !noAuth.ok && /REAUTH_REQUIRED/.test(noAuth.err), noAuth.err);
  const old = await rpc1(U.alice, 'request_account_deletion', ['test'], { amrMinutesAgo: 60 });
  check('login di un\'ora fa non basta', !old.ok && /REAUTH_REQUIRED/.test(old.err));
  const req = await rpc1(U.alice, 'request_account_deletion', ['Non uso più il servizio'], { amrMinutesAgo: 1 });
  check('richiesta programmata tra 7 giorni', req.ok && req.r.status === 'scheduled' && Date.parse(req.r.scheduled_for) - Date.now() > 6.9 * 86400_000, req.err);
  const again = await rpc1(U.alice, 'request_account_deletion', ['x'], { amrMinutesAgo: 1 });
  check('richiesta idempotente (una sola aperta)', again.ok && again.r.id === req.r.id);
  const notif = await val(`select count(*)::int from public.notifications where user_id = $1 and type = 'account'`, [U.alice]);
  check('notifica con possibilità di annullare', notif === 1);
  const cancel = await rpc1(U.alice, 'cancel_account_deletion');
  check('annullabile prima dell\'esecuzione', cancel.ok && cancel.r === true && (await val(`select status from public.account_deletion_requests where id = $1`, [req.r.id])) === 'cancelled');

  const req2 = await rpc1(U.alice, 'request_account_deletion', ['definitivo'], { amrMinutesAgo: 2 });
  const early = await store.rpc<any>('process_account_deletions', { p_limit: 10 });
  check('prima della scadenza non viene eseguita', early.hard_delete.length === 0);
  await db.query(`update public.account_deletion_requests set scheduled_for = now() - interval '1 minute' where id = $1`, [req2.r.id]);
  const post = await store.rpc<any>('process_account_deletions', { p_limit: 10 });
  check('ordine ancora in corso → cancellazione rimandata (niente perdita dati operativi)', post.postponed === 1 && post.hard_delete.length === 0, post);
  await db.query(`update public.orders set status = 'completed', completed_at = now() where id = $1`, [oA.id]);
  await db.query(`update public.account_deletion_requests set scheduled_for = now() - interval '1 minute' where id = $1`, [req2.r.id]);
  const orderBefore = await q1(`select customer_email, total from public.orders where id = $1`, [oA.id]);
  const run = await store.rpc<any>('process_account_deletions', { p_limit: 10 });
  check('scaduta → anonimizzata e pronta per eliminazione Auth', run.hard_delete.includes(U.alice), run);
  const ord = await q1(`select user_id, customer_name, customer_email, customer_phone, total from public.orders where id = $1`, [oA.id]);
  check('ordine conservato per obblighi contabili ma senza dati personali', ord.user_id === null && ord.customer_name === 'Cliente eliminato' && ord.customer_email !== orderBefore.customer_email
    && ord.customer_phone === '000000' && Number(ord.total) === Number(orderBefore.total), ord);
  const prof = await q1(`select full_name, email, phone, is_blocked from public.profiles where id = $1`, [U.alice]);
  check('profilo anonimizzato e bloccato (account_deleted)', prof.full_name === 'Utente eliminato' && prof.email === null && prof.is_blocked === true);
  check('preferiti eliminati', (await val(`select count(*)::int from public.favorites where user_id = $1`, [U.alice])) === 0);
  check('consensi conservati come prova ma scollegati dall\'utente', (await val(`select count(*)::int from public.user_consents where user_id = $1`, [U.alice])) === 0
    && (await val(`select count(*)::int from public.user_consents where anonymous_id like 'deleted-%'`)) >= 4);
  await store.rpc('account_deletion_mark_hard_deleted', { p_user: U.alice });
  check('dopo eliminazione Auth: completed (hard_deleted)', (await val(`select status from public.account_deletion_requests where id = $1`, [req2.r.id])) === 'completed');
  // Titolare di un locale: bloccata finché l'Admin non trasferisce la proprietà
  const ro = await rpc1(U.owner, 'request_account_deletion', ['chiudo'], { amrMinutesAgo: 1 });
  await db.query(`update public.account_deletion_requests set scheduled_for = now() - interval '1 minute' where id = $1`, [ro.r.id]);
  await store.rpc('process_account_deletions', { p_limit: 10 });
  const blocked = await q1(`select status, blocked_reason from public.account_deletion_requests where id = $1`, [ro.r.id]);
  check('titolare di un locale attivo → bloccata (serve trasferimento)', blocked.status === 'blocked' && blocked.blocked_reason === 'owns_restaurant', blocked);
  check('dati del titolare NON anonimizzati', (await val(`select full_name from public.profiles where id = $1`, [U.owner])) !== 'Utente eliminato');
  const adminList = await rpc1(U.admin, 'admin_privacy_requests');
  check('Admin: elenco richieste con email mascherata', adminList.ok && adminList.r.deletions.some((x: any) => x.status === 'blocked' && (x.email_masked ?? '').includes('•••')));
  const unblock = await rpc1(U.admin, 'admin_deletion_action', [ro.r.id, 'cancel']);
  check('Admin annulla la richiesta bloccata (audit)', unblock.ok && (await val(`select status from public.account_deletion_requests where id = $1`, [ro.r.id])) === 'cancelled');
  const directAnon = await rpc1(U.bob, 'account_anonymize', [U.carla]);
  check('anonimizzazione non chiamabile dal client', denied(directAnon));
}

// ════════════════════════════════════════════════════════════
section('7. Rate limit condiviso (database) e anti-abuso');
{
  const ok1 = await store.rpc<boolean>('rate_limit_check', { p_bucket: 'test_login', p_key: 'ip:abc', p_limit: 2, p_window_seconds: 60 });
  const ok2 = await store.rpc<boolean>('rate_limit_check', { p_bucket: 'test_login', p_key: 'ip:abc', p_limit: 2, p_window_seconds: 60 });
  const ok3 = await store.rpc<boolean>('rate_limit_check', { p_bucket: 'test_login', p_key: 'ip:abc', p_limit: 2, p_window_seconds: 60 });
  check('backend: 2 consentite, la 3ª bloccata', ok1 && ok2 && !ok3);
  const other = await store.rpc<boolean>('rate_limit_check', { p_bucket: 'test_login', p_key: 'ip:def', p_limit: 2, p_window_seconds: 60 });
  check('chiavi diverse indipendenti', other === true);
  const client = await rpc1(U.bob, 'rate_limit_check', ['x', 'y', 1, 60]);
  check('rate_limit_check non chiamabile dal browser (niente reset/abuso)', denied(client));
  // Segnalazioni anonime: prima nessun limite per IP (solo 30/giorno per locale); ora 10/ora per hash IP
  let blockedAt = 0;
  let lastErr = '';
  for (let i = 1; i <= 12; i++) {
    const r = await as(null, `insert into public.restaurant_reports (restaurant_id, report_type, description) values ($1, 'other', 'Segnalazione anonima ${i}')`, [KOEN], { headers: { 'x-forwarded-for': '198.51.100.23' } });
    if (!r.ok) { lastErr = r.err; if (/RATE_LIMITED/.test(r.err)) { blockedAt = i; break; } }
  }
  check('segnalazioni anonime: bloccate oltre 10/ora per IP', blockedAt === 11, { blockedAt, lastErr });
  const otherIp = await as(null, `insert into public.restaurant_reports (restaurant_id, report_type, description) values ($1, 'other', 'Da un altro IP')`, [KOEN], { headers: { 'x-forwarded-for': '198.51.100.99' } });
  check('altro IP non bloccato', otherIp.ok, otherIp.err);
  const rl = await q1(`select key_hash, hits, limit_value from public.rate_limits where bucket = 'restaurant_report' and hits >= limit_value`);
  check('soglia raggiunta registrata nel contatore, senza IP in chiaro', rl && /^ip:[0-9a-f]{32}$/.test(rl.key_hash) && !rl.key_hash.includes('198.51'), rl);
  const st = await rpc1(U.admin, 'admin_system_status');
  check('/admin/system: tentativi bloccati per bucket', st.r.security.rate_limited_buckets.restaurant_report >= 1, st.r.security);
  // Anonimi distinti per IP (hash salato)
  const h = { 'x-forwarded-for': '198.51.100.7, 10.0.0.1' };
  const key = await as(null, `select public.sys_ip_hash() h`, [], { headers: h });
  check('hash IP salato (mai IP in chiaro)', !key.ok || (key.rows[0]?.h ?? '').length === 32 || denied(key));
  const ipKey = await val(`select public.sys_ip_hash('198.51.100.7')`);
  check('IP → hash di 32 caratteri, non reversibile', typeof ipKey === 'string' && ipKey.length === 32 && !ipKey.includes('198'));
  // GPS Rider: flood scartato senza errore
  const r1 = await val(`select id from public.rider_profiles where user_id = $1`, [U.r1]);
  // Inserimento nel contesto del Rider (come farebbe una RPC security definer chiamata dal suo JWT)
  await db.exec(`select set_config('request.jwt.claim.sub', '${U.r1}', false); select set_config('request.jwt.claim.role', 'authenticated', false);`);
  for (let i = 0; i < 45; i++) await db.query(`insert into public.rider_locations (rider_id, latitude, longitude, accuracy, recorded_at) values ($1, 40.47, 17.24, 10, now())`, [r1]);
  await db.exec(`select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', '', false);`);
  const locCount = await val(`select count(*)::int from public.rider_locations where rider_id = $1`, [r1]);
  check('GPS: oltre 40 posizioni/minuto scartate (nessuna sospensione automatica)', locCount <= 40 && (await val(`select status from public.rider_profiles where id = $1`, [r1])) !== 'suspended', locCount);
  check('GPS flood tracciato una volta', (await val(`select count(*)::int from public.security_audit_logs where action = 'rider_gps_flood'`)) === 1);
}

// ════════════════════════════════════════════════════════════
section('8. Feature flag, kill switch e manutenzione');
{
  const bad = await rpc1(U.alice, 'admin_set_flag', ['reviews', false]);
  check('utente non cambia i flag', denied(bad));
  const unknown = await rpc1(U.admin, 'admin_set_flag', ['non_esiste', true]);
  check('flag sconosciuto rifiutato', !unknown.ok);
  const off = await rpc1(U.admin, 'admin_set_flag', ['reviews', false]);
  const rev = await rpc1(U.bob, 'submit_review', [SEOUL, { rating_overall: 5, content: 'Ottimo locale, servizio veloce e cortese. Torneremo presto!' }]);
  check('recensioni disattivate → nuove recensioni bloccate', off.ok && !rev.ok && /disattivate/.test(rev.err), rev.err);
  await rpc1(U.admin, 'admin_set_flag', ['reviews', true]);
  check('cambio flag in audit', (await val(`select count(*)::int from public.admin_audit_logs where action = 'flag_change'`)) >= 2);
  // Campagne: kill switch
  const camp = await q1(`insert into public.campaigns (scope, title, message, target, send_at, status, channels, targeting) values ('platform', 'Test', 'Messaggio di prova per tutti', 'all_users', now() - interval '1 minute', 'scheduled', array['in_app'], '{}'::jsonb) returning id`);
  await rpc1(U.admin, 'admin_set_flag', ['push_campaigns', false]);
  const sent = await val(`select public.campaign_dispatch($1)`, [camp.id]);
  check('kill switch campagne → nessun invio, resta programmata', sent === 0 && (await val(`select status from public.campaigns where id = $1`, [camp.id])) === 'scheduled');
  await rpc1(U.admin, 'admin_set_flag', ['push_campaigns', true]);
  await rpc1(U.admin, 'admin_set_flag', ['maintenance', true]);
  const cfg = await rpc1(null, 'public_runtime_config');
  check('manutenzione visibile a runtime (pubblico)', cfg.r.settings.maintenance_mode === true);
  await rpc1(U.admin, 'admin_set_flag', ['maintenance', false]);
  await rpc1(U.admin, 'admin_set_flag', ['riders', false]);
  const apply = await rpc1(U.carla, 'rider_apply', [{ first_name: 'Carla', last_name: 'Test', phone: '+39 333 0000001', city: 'Taranto', vehicle_type: 'bike', terms_accepted: true }]);
  check('candidature Rider chiuse dal flag', !apply.ok && /chiuse/.test(apply.err), apply.err);
  await rpc1(U.admin, 'admin_set_flag', ['riders', true]);
}

// ════════════════════════════════════════════════════════════
section('9. Supporto (ticket)');
{
  const t = await rpc1(U.bob, 'support_ticket_create', [{ category: 'order', subject: 'Ordine in ritardo', description: 'Il mio ordine non è ancora arrivato, potete verificare?', order_number: oB.number }]);
  check('utente apre un ticket sul proprio ordine (priorità alta)', t.ok && /^T-/.test(t.r.reference) && (await val(`select priority from public.support_tickets where id = $1`, [t.r.id])) === 'high', t.err);
  const idor = await rpc1(U.carla, 'support_ticket_create', [{ category: 'order', subject: 'Ordine altrui', description: 'Provo a collegare un ordine che non è mio.', order_number: oB.number }]);
  check('ordine di un altro utente non collegabile (IDOR)', !idor.ok && /non trovato/.test(idor.err));
  const anon = await rpc1(null, 'support_ticket_create', [{ category: 'other', subject: 'Ciao', description: 'Messaggio anonimo diretto senza backend.' }]);
  check('ospite: niente ticket diretti (solo /api/support con Turnstile)', denied(anon));
  const guest = await store.rpc<any>('support_ticket_create', { p: { category: 'business', subject: 'Info piani', description: 'Vorrei informazioni sui piani business.', email: 'Ristorante@Test.it', name: 'Mario' }, p_ip_hash: 'iphash1' });
  check('ospite via backend: ticket con email', guest.reference && (await val(`select contact_email from public.support_tickets where id = $1`, [guest.id])) === 'ristorante@test.it');
  const noMail = await store.rpc<any>('support_ticket_create', { p: { category: 'other', subject: 'Senza email', description: 'Richiesta senza indirizzo email.' }, p_ip_hash: 'iphash1' }).catch((e: Error) => e);
  check('ospite senza email rifiutato', noMail instanceof Error);
  const guestTok = await store.rpc<any>('support_ticket_create', { p: { category: 'order', subject: 'Ordine ospite', description: 'Collego il mio ordine con il link ricevuto.', email: 'g@test.it', order_number: oB.number, order_token: oB.token }, p_ip_hash: 'iphash2' });
  check('ospite collega il proprio ordine con numero + token', !!guestTok.id && (await val(`select order_id from public.support_tickets where id = $1`, [guestTok.id])) === oB.id);
  const mine = await rpc1(U.bob, 'my_support_tickets');
  check('utente vede solo i propri ticket', mine.ok && mine.r.length === 1);
  const list = await rpc1(U.admin, 'admin_support_tickets', ['orders', 20, 0]);
  check('Admin: filtro "orders" con numero ordine', list.ok && list.r.total >= 2 && list.r.rows.some((r: any) => r.order_number === oB.number));
  const urgent = await rpc1(U.admin, 'admin_support_tickets', ['urgent', 20, 0]);
  check('Admin: filtro "urgent"', urgent.ok && urgent.r.rows.every((r: any) => ['high', 'urgent'].includes(r.priority)));
  const upd = await rpc1(U.admin, 'admin_support_update', [t.r.id, { status: 'resolved', resolution: 'Ordine consegnato' }]);
  check('Admin risolve: notifica all\'utente', upd.ok && (await val(`select count(*)::int from public.notifications where user_id = $1 and type = 'support'`, [U.bob])) === 1);
  const userUpd = await rpc1(U.bob, 'admin_support_update', [t.r.id, { status: 'open' }]);
  check('utente non gestisce ticket', denied(userUpd));
}

// ════════════════════════════════════════════════════════════
section('10. Storico slug (redirect 301) e vincoli');
{
  const oldSlug = await val(`select slug from public.restaurants where id = $1`, [KOEN]);
  await as(U.owner2, `update public.restaurants set slug = 'nuovo-slug-owner' where id = $1`, [KOEN]);
  check('il ristoratore non cambia lo slug (URL SEO)', (await val(`select slug from public.restaurants where id = $1`, [KOEN])) === oldSlug);
  const ch = await as(U.admin, `update public.restaurants set slug = 'ramen-koen-taranto-centro' where id = $1`, [KOEN]);
  if (!ch.ok) console.log('    (cambio slug:', ch.err, ')');
  const redir = await rpc1(null, 'restaurant_slug_redirect', [oldSlug]);
  check('vecchio slug → nuovo (redirect)', redir.ok && redir.r === 'ramen-koen-taranto-centro', redir);
  const list = await as(null, `select * from public.restaurant_slug_redirects()`);
  check('elenco redirect per _redirects di build', list.rows.some((r: any) => r.old_slug === oldSlug && r.new_slug === 'ramen-koen-taranto-centro'));
  await as(U.admin, `update public.restaurants set slug = $2 where id = $1`, [KOEN, oldSlug]);
  const back = await rpc1(null, 'restaurant_slug_redirect', [oldSlug]);
  check('slug ripristinato: nessun loop di redirect', back.r == null);
  const lat = await as(U.admin, `update public.cities set latitude = 123 where slug = 'taranto'`);
  check('vincolo coordinate valide (latitudine 123 rifiutata)', !lat.ok && /cities_lat_lng_valid/.test(lat.err), lat.err);
  const money = await as(U.admin, `update public.orders set commission_percent = 150 where id = $1`, [oB.id]);
  check('vincolo percentuale commissione 0–100', !money.ok);
  check('currency esplicita su rimborsi e compensi', (await val(`select count(*)::int from information_schema.columns where column_name = 'currency' and table_name in ('order_refunds', 'rider_earnings')`)) === 2);
}

// ════════════════════════════════════════════════════════════
section('11. Job in background, lock, retention, errori, Web Vitals');
try {
  const a = await store.rpc<boolean>('job_lock_acquire', { p_name: 'orders-cron', p_holder: 'h1', p_ttl_seconds: 60 });
  const b = await store.rpc<boolean>('job_lock_acquire', { p_name: 'orders-cron', p_holder: 'h2', p_ttl_seconds: 60 });
  check('lock: seconda esecuzione concorrente rifiutata', a === true && b === false);
  await db.query(`update public.job_locks set locked_until = now() - interval '1 second' where name = 'orders-cron'`);
  check('lock scaduto (esecuzione bloccata) → riacquisibile', (await store.rpc<boolean>('job_lock_acquire', { p_name: 'orders-cron', p_holder: 'h3', p_ttl_seconds: 60 })) === true);
  await store.rpc('job_lock_release', { p_name: 'orders-cron', p_holder: 'h3' });
  const jid = await store.rpc<string>('background_job_start', { p_type: 'orders-cron', p_payload: {} });
  await store.rpc('background_job_finish', { p_id: jid, p_status: 'failed', p_error: 'timeout', p_result: null });
  const retry = await rpc1(U.admin, 'admin_retry_job', [jid]);
  check('retry controllato di un job fallito', retry.ok && (await val(`select status from public.background_jobs where id = $1`, [jid])) === 'queued');
  const claimed = await store.rpc<any[]>('background_jobs_claim', { p_types: '{orders-cron}', p_limit: 5 });
  check('job in coda preso in carico (attempts +1)', (claimed as any)?.length === 1 || (await val(`select attempts from public.background_jobs where id = $1`, [jid])) === 2);
  // Retention
  const r1 = await val(`select id from public.rider_profiles where user_id = $1`, [U.r1]);
  await db.query(`insert into public.rider_locations (rider_id, latitude, longitude, accuracy, recorded_at) values ($1, 40.4, 17.2, 10, now() - interval '3 days')`, [r1]);
  await db.query(`insert into public.system_error_log (source, message, created_at) values ('server', 'vecchio', now() - interval '200 days')`);
  await db.query(`insert into public.rate_limits (bucket, key_hash, window_start, hits) values ('old', 'k', now() - interval '5 days', 3)`);
  const paidBefore = await val(`select count(*)::int from public.orders where payment_status = 'paid'`);
  const ret = await store.rpc<any>('retention_cleanup', {});
  check('retention: GPS vecchio, log vecchi, rate limit scaduti rimossi', ret.rider_locations >= 1 && ret.system_error_log >= 1 && ret.rate_limits >= 1, ret);
  check('retention: ordini pagati (obbligo contabile) intatti', (await val(`select count(*)::int from public.orders where payment_status = 'paid'`)) === paidBefore);
  check('retention: log di audit conservati', (await val(`select count(*)::int from public.admin_audit_logs`)) > 0);
  const userRet = await rpc1(U.admin, 'retention_cleanup');
  check('retention non avviabile dal browser', denied(userRet));
  // Errori client con PII rimossa
  await rpc1(null, 'client_error_record', [{ message: 'Errore per mario.rossi@example.com tel +39 333 1234567 token=abcDEF123456 eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.abc', route: '/orders/AF-123?t=segreto', code: 'TypeError' }]);
  const e = await q1(`select message, route from public.system_error_log where source = 'client' order by id desc limit 1`);
  check('errori client: email/telefono/token/JWT rimossi', !/mario|333 1234567|abcDEF|eyJ/.test(e.message) && /\[email\]/.test(e.message), e.message);
  check('errori client: query string rimossa dalla route', e.route === '/orders/AF-123');
  await rpc1(null, 'web_vital_record', [{ metric: 'LCP', value: 1800, rating: 'good', route: '/ristorante/:slug?x=1', device: 'mobile' }]);
  await rpc1(null, 'web_vital_record', [{ metric: 'EVIL', value: 1 }]);
  check('Web Vitals: solo metriche note, route senza query', (await val(`select count(*)::int from public.web_vitals`)) === 1 && (await val(`select route from public.web_vitals`)) === '/ristorante/:slug');
  const read = await as(null, `select count(*)::int n from public.web_vitals`);
  check('Web Vitals e log errori non leggibili dal pubblico', read.rows[0]?.n === 0 || !read.ok);
} catch (e) {
  check('sezione 11 senza eccezioni', false, (e as Error).message);
}

// ════════════════════════════════════════════════════════════
section('12. Consistenza DB, launch checklist, readiness Taranto');
{
  const rep = await rpc1(U.admin, 'db_consistency_report');
  check('report consistenza: controlli eseguiti', rep.ok && rep.r.checks.length >= 12 && typeof rep.r.total_issues === 'number', rep.err);
  const repUser = await rpc1(U.bob, 'db_consistency_report');
  check('report consistenza non accessibile agli utenti', denied(repUser));
  const lc = await rpc1(U.admin, 'admin_launch_checklist');
  check('checklist: stato calcolato', lc.ok && ['BLOCKED', 'NOT_READY', 'READY_FOR_BETA', 'READY_FOR_PRODUCTION'].includes(lc.r.status), lc.err);
  check('checklist: con controlli critici aperti mai 100% né "production"', lc.r.score < 100 && lc.r.status !== 'READY_FOR_PRODUCTION');
  check('checklist: sezioni richieste presenti', ['SECURITY', 'PRIVACY', 'LEGAL', 'DATA', 'SEO', 'PERFORMANCE', 'PAYMENTS', 'ORDERS', 'DELIVERY', 'RIDER', 'AI', 'CRM', 'EMAIL', 'PUSH', 'ANALYTICS', 'BACKUP', 'MONITORING', 'SUPPORT']
    .every((s) => lc.r.checks.some((c: any) => c.section === s)));
  check('checklist: RLS e funzioni admin OK (controlli automatici)', lc.r.checks.find((c: any) => c.key === 'sec_rls')?.status === 'pass' && lc.r.checks.find((c: any) => c.key === 'sec_admin_rpc')?.status === 'pass');
  check('checklist: senza email di supporto → BLOCKED', lc.r.status === 'BLOCKED' && lc.r.blocking.some((b: any) => b.key === 'support_contact'));
  const man = await rpc1(U.admin, 'admin_set_launch_check', ['backup_enabled', 'pass', 'PITR attivo, verificato il 01/10']);
  check('controllo manuale registrato con autore', man.ok && (await val(`select checked_by from public.launch_checks where key = 'backup_enabled'`)) === U.admin);
  await store.rpc('system_record_check', { p_key: 'mon_health', p_status: 'pass', p_notes: 'ok' });
  const sysOverride = await rpc1(U.admin, 'admin_set_launch_check', ['mon_health', 'fail', 'x']);
  check('controlli di sistema non modificabili a mano', !sysOverride.ok);
  const city = await rpc1(U.admin, 'admin_city_readiness', ['TA']);
  check('Taranto readiness: solo locali reali (demo esclusi) → Not Ready', city.ok && city.r.restaurants === 0 && city.r.ready === false && city.r.score < 100, city.r);
  // Locale reale in provincia: il conteggio sale
  await db.query(`update public.restaurants set is_demo = false where id = $1`, [SEOUL]);
  const city2 = await rpc1(U.admin, 'admin_city_readiness', ['TA']);
  check('Taranto readiness: conta i locali reali', city2.r.restaurants === 1 && city2.r.checks.find((c: any) => c.key === 'coordinates').value === 100);
  await db.query(`update public.restaurants set is_demo = true where id = $1`, [SEOUL]);
  const cityUser = await rpc1(U.bob, 'admin_city_readiness', ['TA']);
  check('readiness non accessibile agli utenti', denied(cityUser));
}

// ════════════════════════════════════════════════════════════
section('13. Pulizia dati DEMO (safeguard)');
{
  const userTry = await rpc1(U.admin, 'clean_demo_data', ['DELETE-DEMO-DATA']);
  check('non eseguibile dal browser (nemmeno dall\'Admin)', denied(userTry), userTry.err);
  const dry = await store.rpc<any>('clean_demo_data', { p_confirm: null });
  const before = await val(`select count(*)::int from public.restaurants where is_demo`);
  check('dry-run di default: nessuna modifica', dry.dry_run === true && before > 0 && (await val(`select count(*)::int from public.restaurants where is_demo`)) === before);
  const run = await store.rpc<any>('clean_demo_data', { p_confirm: 'DELETE-DEMO-DATA' });
  check('esecuzione confermata: demo nascosti, locali senza storico eliminati, con storico disattivati', run.dry_run === false
    && (await val(`select value from public.platform_settings where key = 'show_demo_data'`)) === false
    && (await val(`select count(*)::int from public.restaurants where is_demo and is_active`)) === 0, run);
  check('ordini storici intatti (locale con ordini solo disattivato)', (await val(`select count(*)::int from public.orders where restaurant_id = $1`, [SEOUL])) >= 2
    && (await val(`select is_active from public.restaurants where id = $1`, [SEOUL])) === false);
  check('pulizia registrata nei log di sicurezza', (await val(`select count(*)::int from public.security_audit_logs where action = 'demo_data_cleaned'`)) === 1);
}

console.log(`\n${pass} passati, ${fail} falliti`);
process.exit(fail ? 1 : 0);
