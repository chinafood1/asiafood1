/* eslint-disable @typescript-eslint/no-explicit-any */
// ─────────────────────────────────────────────────────────────
//  Test della Fase 7 (fidelizzazione) sulle VERE migrazioni (PGlite):
//  recensioni, verifica, moderazione, punti, premi, referral, notifiche,
//  push (sender simulato), promemoria, campagne, badge, retention, RLS.
//  Uso: npm run test:engagement
// ─────────────────────────────────────────────────────────────
import { engagementCron } from '../server/engagement/cron';
import type { PushSender } from '../server/engagement/push';
import { createTestDb } from './lib/pglite-db';

const { db, store } = await createTestDb();

let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) {
    pass++;
    console.log('  ✓', name);
  } else {
    fail++;
    console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 500) : '');
  }
}
const section = (t: string) => console.log(`\n── ${t}`);

/** SQL come utente (RLS attive) o anon; null+service = backend. */
async function as(user: string | null, sql: string, params: unknown[] = [], role?: string) {
  const r = role ?? (user ? 'authenticated' : 'anon');
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${user ?? ''}', false); select set_config('request.jwt.claim.role', '${r}', false); set role ${r};`);
  try {
    const res = await db.query<any>(sql, params);
    return { ok: true as const, rows: res.rows, affected: res.affectedRows ?? 0, err: '' };
  } catch (e) {
    return { ok: false as const, rows: [] as any[], affected: 0, err: (e as Error).message };
  } finally {
    await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', '', false);`);
  }
}
const q1 = async (sql: string, params: unknown[] = []) => (await db.query<any>(sql, params)).rows[0];
const val = async (sql: string, params: unknown[] = []) => Object.values((await q1(sql, params)) ?? {})[0] as any;
const balance = (u: string) => val(`select points_balance from public.loyalty_accounts where user_id = $1`, [u]);

const U = {
  admin: '81111111-1111-4111-8111-111111111111',
  owner: '82222222-2222-4222-8222-222222222222',  // Kaizen (Top)
  staff: '83333333-3333-4333-8333-333333333333',
  alice: '84444444-4444-4444-8444-444444444444',
  bob: '85555555-5555-4555-8555-555555555555',
  carla: '86666666-6666-4666-8666-666666666666',
  dario: '87777777-7777-4777-8777-777777777777',
  owner2: '88888888-8888-4888-8888-888888888888', // Ramen Kōen (Business)
  owner3: '89999999-9999-4999-8999-999999999999', // Hanami (Premium)
};
const R = (n: number) => `e0000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const KAIZEN = R(1), RAMEN = R(2), HANAMI = R(8), DRAGO = R(3);

async function createUser(id: string, name: string, verified = true, extra = '') {
  await db.query(`insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values ($1, $2, $3, ${verified ? 'now()' : 'null'})`,
    [id, `${name.toLowerCase().replace(/\s+/g, '.')}@test.it`, JSON.stringify({ full_name: name })]);
  if (extra) await db.exec(extra);
}
for (const [k, id] of Object.entries(U)) {
  await createUser(id, k === 'alice' ? 'Alice Rossi Bianchi' : k === 'bob' ? 'Bob Verdi' : `${k[0]!.toUpperCase()}${k.slice(1)} Test`);
}
await db.exec(`
update public.profiles set role = 'admin' where id = '${U.admin}';
insert into public.restaurant_members (restaurant_id, user_id, role, status) values
  ('${KAIZEN}', '${U.owner}', 'owner', 'active'), ('${KAIZEN}', '${U.staff}', 'staff', 'active'),
  ('${RAMEN}', '${U.owner2}', 'owner', 'active'), ('${HANAMI}', '${U.owner3}', 'owner', 'active')
on conflict do nothing;
update public.restaurants set owner_id = '${U.owner}' where id = '${KAIZEN}';
update public.restaurants set owner_id = '${U.owner2}' where id = '${RAMEN}';
update public.restaurants set owner_id = '${U.owner3}' where id = '${HANAMI}';
`);

let codeN = 0;
/** Prenotazione passata già confermata (poi completata dal ristoratore con il flusso reale). */
async function pastReservation(user: string | null, restaurant: string, daysAgo = 1, status = 'confirmed') {
  codeN++;
  const r = await q1(
    `insert into public.reservations (restaurant_id, user_id, guest_name, guest_surname, guest_email, guest_phone, reservation_date, reservation_time, party_size, status, confirmation_code)
     values ($1, $2, 'Test', 'Cliente', 'guest@test.it', '+39 333 1111111', (now() at time zone 'Europe/Rome')::date - $3::int, '20:00', 2, $4, $5) returning id`,
    [restaurant, user, daysAgo, status, `ASF-T${String(codeN).padStart(4, '0')}`],
  );
  return r.id as string;
}
async function complete(owner: string, resId: string) {
  return as(owner, `select public.set_reservation_status($1, 'completed')`, [resId]);
}

// ═════════════════════════════════════════════════════════════
section('Registrazione, profilo, preferenze');
{
  check('saldo creato alla registrazione con bonus configurato (50)', (await balance(U.alice)) === 50);
  check('codice invito generato automaticamente (XXXX-XXXX)', /^[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(await val(`select code from public.referral_codes where user_id = $1`, [U.alice])));
  const pr = await q1(`select * from public.notification_preferences where user_id = $1`, [U.alice]);
  check('preferenze prudenti: marketing e push disattivati, essenziali attive', pr.marketing === false && pr.push_enabled === false && pr.new_offers === false && pr.reservation_reminders === true);
  const cityId = await val(`select id from public.cities where slug = 'taranto'`);
  await as(U.alice, `update public.profiles set phone = '+39 333 1234567', city_id = $1 where id = $2`, [cityId, U.alice]);
  check('profilo completo → +50 (nome e cognome, telefono, comune)', (await balance(U.alice)) === 100);
  await as(U.alice, `update public.profiles set phone = '+39 333 7654321' where id = $1`, [U.alice]);
  check('profilo completo premiato una sola volta', (await balance(U.alice)) === 100);
  const r = await as(U.alice, `update public.loyalty_accounts set points_balance = 99999 where user_id = $1`, [U.alice]);
  check('saldo NON modificabile dal browser', !r.ok || r.affected === 0);
  const t = await as(U.alice, `insert into public.loyalty_transactions (user_id, type, points, balance_after, event_key, source_type) values ($1, 'earn', 1000, 1100, 'x', 'other')`, [U.alice]);
  check('transazioni punti NON inseribili dal browser', !t.ok);
  const aw = await as(U.alice, `select public.loyalty_award($1, 'reservation_completed', 'reservation', gen_random_uuid(), 'x')`, [U.alice]);
  check('assegnazione punti non chiamabile dal browser', !aw.ok);
}

// ═════════════════════════════════════════════════════════════
section('Recensioni: verifica, anti-manipolazione, limiti');
let aliceReview = '';
{
  const res = await pastReservation(U.alice, KAIZEN, 2);
  const c = await complete(U.owner, res);
  check('il ristoratore completa la visita (flusso esistente)', c.ok, c.err);
  check('prenotazione completata → +100 punti', (await balance(U.alice)) === 200);
  const again = await complete(U.owner, res);
  check('la stessa prenotazione non dà punti due volte', !again.ok && (await balance(U.alice)) === 200);
  const st = await as(U.alice, `select public.my_review_status($1) s`, [KAIZEN]);
  check('stato form: "Visita verificata" disponibile', st.rows[0]?.s?.verification?.source === 'reservation' && !st.rows[0]?.s?.blocked, st.rows[0]?.s);
  const bad = await as(U.alice, `select public.submit_review($1, '{"rating_overall":"6","content":"Ottima cena, servizio veloce e sushi fresco."}'::jsonb)`, [KAIZEN]);
  check('valutazione fuori scala rifiutata', !bad.ok && /1–5/.test(bad.err), bad.err);
  const short = await as(U.alice, `select public.submit_review($1, '{"rating_overall":"4","content":"Buono"}'::jsonb)`, [KAIZEN]);
  check('testo troppo corto rifiutato', !short.ok && /almeno/.test(short.err));
  const ok = await as(U.alice, `select public.submit_review($1, $2::jsonb) r`, [KAIZEN, JSON.stringify({ rating_overall: 2, rating_food: 3, content: 'Pesce fresco ma servizio lento, abbiamo aspettato molto il secondo giro.' })]);
  const rv = ok.rows[0]?.r;
  aliceReview = rv?.id;
  check('recensione con visita verificata pubblicata subito', ok.ok && rv.status === 'published' && rv.is_verified && rv.verification_source === 'reservation', ok.err || rv);
  check('+50 punti per recensione verificata, anche con voto basso (mai in base al rating)', (await balance(U.alice)) === 250);
  const dup = await as(U.alice, `select public.submit_review($1, '{"rating_overall":"5","content":"Seconda recensione sullo stesso ristorante subito dopo."}'::jsonb)`, [KAIZEN]);
  check('limite: una recensione ogni 90 giorni per ristorante', !dup.ok && /di recente/.test(dup.err), dup.err);
  const own = await as(U.owner, `select public.submit_review($1, '{"rating_overall":"5","content":"Il migliore ristorante della città, assolutamente!"}'::jsonb)`, [KAIZEN]);
  check('titolare NON può recensire il proprio locale', !own.ok && /gestisce o lavora/.test(own.err));
  const staff = await as(U.staff, `select public.submit_review($1, '{"rating_overall":"5","content":"Il migliore ristorante della città, assolutamente!"}'::jsonb)`, [KAIZEN]);
  check('staff NON può recensire il proprio locale', !staff.ok);
  const anon = await as(null, `select public.submit_review($1, '{"rating_overall":"5","content":"Recensione anonima non consentita qui."}'::jsonb)`, [KAIZEN]);
  check('nessuna recensione anonima', !anon.ok);
  const direct = await as(U.bob, `insert into public.reviews (restaurant_id, user_id, rating_overall, content, is_verified, verification_source, status) values ($1, $2, 5, 'finta', true, 'reservation', 'published')`, [KAIZEN, U.bob]);
  check('"verificata" non impostabile dal browser (nessun insert diretto)', !direct.ok);
  const upd = await as(U.alice, `update public.reviews set is_verified = true, helpful_count = 999 where id = $1`, [aliceReview]);
  check('recensione non modificabile direttamente (contatori, verifica)', !upd.ok || upd.affected === 0);
  // Recensione non verificata → coda di moderazione
  const unv = await as(U.bob, `select public.submit_review($1, '{"rating_overall":"4","title":"Bella serata","content":"Locale accogliente, ramen saporito e personale gentile."}'::jsonb) r`, [RAMEN]);
  check('recensione non verificata → in moderazione, senza badge', unv.ok && unv.rows[0].r.status === 'pending' && unv.rows[0].r.is_verified === false, unv.err);
  const bobPts = await balance(U.bob);
  const pub = await as(null, `select count(*)::int n from public.reviews where restaurant_id = $1`, [RAMEN]);
  check('pubblico: le recensioni in attesa non sono visibili', pub.rows[0].n === 0);
  const mine = await as(U.bob, `select count(*)::int n from public.reviews where user_id = $1`, [U.bob]);
  check('l’autore vede la propria recensione in attesa', mine.rows[0].n === 1);
  const unvId = await val(`select id from public.reviews where user_id = $1`, [U.bob]);
  const queue = await as(U.admin, `select public.admin_list_reviews('queue') r`);
  check('Admin: coda "da gestire" include le recensioni in attesa', queue.ok && JSON.stringify(queue.rows[0].r).includes(unvId), queue.err);
  const queueNo = await as(U.bob, `select public.admin_list_reviews('queue') r`);
  check('coda moderazione negata ai non Admin', !queueNo.ok);
  const mod = await as(U.admin, `select public.moderate_review($1, 'publish')`, [unvId]);
  check('Admin pubblica; nessun punto per recensione non verificata', mod.ok && (await balance(U.bob)) === bobPts, mod.err);
  const link = await as(U.carla, `select public.submit_review($1, '{"rating_overall":"5","content":"Scrivetemi a promo@spam.it o visitate https://spam.example per sconti"}'::jsonb) r`, [HANAMI]);
  check('contenuti sospetti (link/email) → moderazione umana, non pubblicati', link.ok && link.rows[0].r.status === 'pending');
  check('segnali di moderazione registrati', (await val(`select moderation_flags::text from public.reviews where user_id = $1`, [U.carla])).includes('link'));
  const ed = await as(U.alice, `select public.update_review($1, '{"rating_overall":"3","content":"Aggiornamento: il servizio è migliorato alla seconda visita, pesce fresco."}'::jsonb)`, [aliceReview]);
  const edited = await q1(`select is_edited, rating_overall, (select count(*)::int from public.review_versions where review_id = $1) v from public.reviews where id = $1`, [aliceReview]);
  check('modifica: "Modificata" + versione precedente conservata', ed.ok && edited.is_edited && edited.rating_overall === 3 && edited.v === 1, ed.err || edited);
  const other = await as(U.bob, `select public.update_review($1, '{"rating_overall":"1","content":"Tentativo di modificare la recensione di altri utenti."}'::jsonb)`, [aliceReview]);
  check('non si modifica la recensione di altri', !other.ok);
}

// ═════════════════════════════════════════════════════════════
section('Risposta del ristoratore, utile, segnalazioni, moderazione');
{
  const r1 = await as(U.owner, `select public.respond_to_review($1, 'Grazie del riscontro, abbiamo rinforzato il personale in sala.')`, [aliceReview]);
  check('il titolare risponde alla recensione', r1.ok, r1.err);
  const r2 = await as(U.owner, `select public.respond_to_review($1, 'Risposta aggiornata: grazie ancora, vi aspettiamo.')`, [aliceReview]);
  check('una sola risposta ufficiale (modificabile)', r2.ok && (await val(`select count(*)::int from public.review_responses where review_id = $1`, [aliceReview])) === 1);
  const r3 = await as(U.owner2, `select public.respond_to_review($1, 'Risposta da un altro ristorante non autorizzato.')`, [aliceReview]);
  check('un altro ristoratore NON può rispondere', !r3.ok);
  const r4 = await as(U.staff, `select public.respond_to_review($1, 'Risposta dello staff non autorizzata.')`, [aliceReview]);
  check('lo staff NON risponde a nome del locale', !r4.ok);
  const del = await as(U.owner, `delete from public.reviews where id = $1`, [aliceReview]);
  check('il ristoratore NON può cancellare recensioni', !del.ok || del.affected === 0);
  check('notifica all’autore per la risposta', (await val(`select count(*)::int from public.notifications where user_id = $1 and type = 'review'`, [U.alice])) >= 1);

  const v1 = await as(U.bob, `select public.vote_review($1, true) n`, [aliceReview]);
  const v2 = await as(U.bob, `select public.vote_review($1, true) n`, [aliceReview]);
  check('"Utile": un voto per persona', v1.rows[0]?.n === 1 && v2.rows[0]?.n === 1, [v1, v2]);
  const v3 = await as(U.alice, `select public.vote_review($1, true)`, [aliceReview]);
  check('non si vota la propria recensione', !v3.ok);

  const rep1 = await as(U.bob, `select public.report_review($1, 'spam', 'sembra pubblicità')`, [aliceReview]);
  check('segnalazione singola: la recensione resta pubblicata', rep1.ok && (await val(`select status from public.reviews where id = $1`, [aliceReview])) === 'published');
  await as(U.bob, `select public.report_review($1, 'spam', 'di nuovo')`, [aliceReview]);
  check('segnalazione duplicata ignorata', (await val(`select count(*)::int from public.review_reports where review_id = $1`, [aliceReview])) === 1);
  const repOwner = await as(U.owner, `select public.report_review($1, 'false_info', 'informazioni non vere')`, [aliceReview]);
  check('il ristoratore può segnalare', repOwner.ok, repOwner.err);
  await as(U.dario, `select public.report_review($1, 'offensive', null)`, [aliceReview]);
  check('oltre la soglia (3 segnalazioni distinte) → "flagged", non pubblica', (await val(`select status from public.reviews where id = $1`, [aliceReview])) === 'flagged');
  const pubList = await as(null, `select public.list_reviews($1) l`, [KAIZEN]);
  check('la recensione segnalata non è nell’elenco pubblico', pubList.rows[0].l.total === 0);
  const nonAdmin = await as(U.owner, `select public.moderate_review($1, 'restore')`, [aliceReview]);
  check('solo l’Admin modera', !nonAdmin.ok);
  const restore = await as(U.admin, `select public.moderate_review($1, 'restore', 'Segnalazioni non fondate')`, [aliceReview]);
  check('Admin ripristina; segnalazioni archiviate; azione in audit log', restore.ok
    && (await val(`select count(*)::int from public.review_reports where review_id = $1 and status = 'dismissed'`, [aliceReview])) === 3
    && (await val(`select count(*)::int from public.admin_audit_logs where action = 'review_restore'`)) === 1);
  const list = await as(null, `select public.list_reviews($1, 'helpful') l`, [KAIZEN]);
  const item = list.rows[0].l.items[0];
  check('elenco pubblico: nome pubblico ("Alice R."), niente email/cognome completo', item?.author === 'Alice R.' && !JSON.stringify(list.rows[0].l).includes('@') && !JSON.stringify(list.rows[0].l).includes('Bianchi'), item);
  check('elenco: badge verificata, utile, risposta del ristorante, "modificata"', item.is_verified && item.helpful_count === 1 && item.response?.content && item.is_edited);
  const rating = await as(null, `select public.restaurant_rating($1) r`, [KAIZEN]);
  check('media calcolata SOLO dalle pubblicate (3.0, 1 recensione)', Number(rating.rows[0].r.average) === 3 && rating.rows[0].r.count === 1, rating.rows[0].r);
  const none = await as(null, `select public.restaurant_rating($1) r`, [DRAGO]);
  check('nessuna recensione → nessuna media (niente rating inventati)', none.rows[0].r.count === 0 && none.rows[0].r.average === null);
  const f5 = await as(null, `select public.list_reviews($1, 'recent', '5') l`, [KAIZEN]);
  check('filtro per stelle', f5.rows[0].l.total === 0);
}

// ═════════════════════════════════════════════════════════════
section('AsiaPoints: livelli, limiti, premi (transazione atomica)');
{
  // Livello Foodie a 500 punti totali
  await store.rpc('loyalty_award', { p_user: U.alice, p_event: 'achievement_bonus', p_source_type: 'other', p_source_id: '00000000-0000-4000-8000-0000000000a1', p_description: 'Test', p_points: 300 });
  const acc = await q1(`select points_balance, lifetime_points, level from public.loyalty_accounts where user_id = $1`, [U.alice]);
  check('livello calcolato dai punti totali (Foodie ≥ 500)', acc.level === 'Foodie' && acc.lifetime_points === 550, acc);
  const again = await store.rpc<number>('loyalty_award', { p_user: U.alice, p_event: 'achievement_bonus', p_source_type: 'other', p_source_id: '00000000-0000-4000-8000-0000000000a1', p_description: 'Test', p_points: 300 });
  check('idempotenza: stessa fonte + evento → 0 punti', again === 0 && (await balance(U.alice)) === 550);
  // Limite giornaliero coupon_redeemed = 3
  for (let i = 0; i < 4; i++) await store.rpc('loyalty_award', { p_user: U.dario, p_event: 'coupon_redeemed', p_source_type: 'coupon', p_source_id: `00000000-0000-4000-8000-0000000000b${i}` });
  check('limite giornaliero della regola rispettato (3 × 20)', (await val(`select count(*)::int from public.loyalty_transactions where user_id = $1 and event_key = 'coupon_redeemed'`, [U.dario])) === 3);
  await as(U.admin, `update public.loyalty_rules set points = 80 where event_key = 'reservation_completed'`);
  check('Admin modifica le regole (niente valori fissi nel codice)', (await val(`select points from public.loyalty_rules where event_key = 'reservation_completed'`)) === 80);
  const nonAdmin = await as(U.alice, `update public.loyalty_rules set points = 100000 where event_key = 'account_created'`);
  check('le regole non sono modificabili dagli utenti', !nonAdmin.ok || nonAdmin.affected === 0);
  await as(U.admin, `update public.loyalty_rules set points = 100 where event_key = 'reservation_completed'`);

  const coupon = await val(`select id from public.coupons where restaurant_id = $1 and is_active limit 1`, [KAIZEN]);
  await db.exec(`update public.coupons set valid_until = now() + interval '60 days', valid_from = now() - interval '1 day' where id = '${coupon}'`);
  const rw = await q1(`insert into public.rewards (title, points_cost, reward_type, stock, per_user_limit, terms) values ('Dolce in omaggio', 200, 'platform_coupon', 1, 1, 'Mostra il codice') returning id`);
  const rwC = await q1(`insert into public.rewards (title, points_cost, reward_type, restaurant_id, coupon_id) values ('Coupon Kaizen', 100, 'restaurant_coupon', $1, $2) returning id`, [KAIZEN, coupon]);
  const pubR = await as(null, `select count(*)::int n from public.rewards`);
  check('premi attivi leggibili pubblicamente', pubR.rows[0].n === 2);
  const before = await balance(U.alice);
  const red = await as(U.alice, `select public.redeem_reward($1) r`, [rw.id]);
  check('riscatto: saldo scalato, codice premio, transazione registrata', red.ok && red.rows[0].r.balance === before - 200 && /^AP-[A-Z0-9]{6}$/.test(red.rows[0].r.code)
    && (await balance(U.alice)) === before - 200 && (await val(`select count(*)::int from public.loyalty_transactions where user_id = $1 and type = 'redeem'`, [U.alice])) === 1, red.err || red.rows[0]);
  const sold = await as(U.bob, `select public.redeem_reward($1)`, [rw.id]);
  check('stock esaurito → rifiutato', !sold.ok && /esaurito|insufficienti/.test(sold.err), sold.err);
  const poor = await as(U.carla, `select public.redeem_reward($1)`, [rwC.id]);
  const carlaBal = await balance(U.carla);
  check('saldo insufficiente → errore, nessuna modifica (rollback)', !poor.ok && /insufficienti/.test(poor.err) && carlaBal === 50
    && (await val(`select count(*)::int from public.reward_redemptions where user_id = $1`, [U.carla])) === 0, poor.err);
  const coup = await as(U.alice, `select public.redeem_reward($1) r`, [rwC.id]);
  const claim = await q1(`select status, user_id from public.coupon_claims where claim_code = $1`, [coup.rows[0]?.r?.code]);
  check('premio "coupon ristorante" → coupon reale validabile in cassa', coup.ok && claim?.status === 'claimed' && claim.user_id === U.alice, coup.err);
  const my = await as(U.alice, `select public.my_loyalty(5, 0) w`);
  const w = my.rows[0].w;
  check('wallet: saldo, livello, prossimo livello, transazioni paginate, nome programma', w.program_name === 'AsiaPoints' && w.level === 'Foodie'
    && w.next_level?.name === 'Insider' && w.next_level.missing === 1500 - w.lifetime && w.transactions.length === 5 && w.transactions_total > 5, w);
  const adj = await as(U.admin, `select public.admin_loyalty_adjust($1, -99999, 'errore')`, [U.carla]);
  check('rettifica Admin: mai saldo negativo', !adj.ok && /negativo/.test(adj.err));
  const adj2 = await as(U.admin, `select public.admin_loyalty_adjust($1, 30, 'Compensazione disservizio')`, [U.carla]);
  check('rettifica Admin tracciata in audit log', adj2.ok && (await balance(U.carla)) === 80 && (await val(`select count(*)::int from public.admin_audit_logs where action = 'loyalty_adjustment'`)) === 1);
  const adj3 = await as(U.alice, `select public.admin_loyalty_adjust($1, 1000, 'furbata')`, [U.alice]);
  check('rettifica non consentita agli utenti', !adj3.ok);
  const redId = red.rows[0].r.redemption_id;
  const canc = await as(U.admin, `select public.admin_update_redemption($1, 'cancelled')`, [redId]);
  const canc2 = await as(U.admin, `select public.admin_update_redemption($1, 'cancelled')`, [redId]);
  check('annullo premio: punti restituiti una sola volta', canc.ok && !canc2.ok && (await val(`select count(*)::int from public.loyalty_transactions where event_key = 'redemption_refund'`)) === 1);
}

// ═════════════════════════════════════════════════════════════
section('Referral');
{
  const code = await val(`select code from public.referral_codes where user_id = $1`, [U.alice]);
  const E = '8aaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
  await createUser(E, 'Elena Neri', false);
  const self = await as(U.alice, `select public.apply_referral_code($1)`, [code]);
  check('auto-referral bloccato', !self.ok && /tuo codice/.test(self.err));
  const bad = await as(E, `select public.apply_referral_code('ZZZZ-ZZZZ')`);
  check('codice inesistente rifiutato', !bad.ok && /non valido/.test(bad.err));
  const ok = await as(E, `select public.apply_referral_code($1) r`, [code.toLowerCase()]);
  check('invito valido → "registered"', ok.ok && ok.rows[0].r.status === 'registered', ok.err);
  const dup = await as(E, `select public.apply_referral_code($1)`, [code]);
  check('secondo codice per lo stesso utente rifiutato', !dup.ok && /già usato/.test(dup.err));
  const eCode = await val(`select code from public.referral_codes where user_id = $1`, [E]);
  const mutual = await as(U.alice, `select public.apply_referral_code($1)`, [eCode]);
  check('invito incrociato / vecchio account rifiutato', !mutual.ok);
  await db.exec(`update public.profiles set created_at = now() - interval '30 days' where id = '${U.dario}'`);
  const late = await as(U.dario, `select public.apply_referral_code($1)`, [code]);
  check('codice usabile solo nei primi giorni dopo la registrazione', !late.ok && /primi giorni/.test(late.err), late.err);
  const force = await as(E, `select public.referral_qualify($1)`, [E]);
  check('qualifica NON chiamabile dal browser', !force.ok);
  const upd = await as(E, `update public.referrals set status = 'rewarded'`);
  check('stato referral non modificabile dal browser', !upd.ok || upd.affected === 0);
  const aliceBefore = await balance(U.alice);
  const res = await pastReservation(E, HANAMI, 1);
  await complete(U.owner3, res);
  check('prima visita ma email NON verificata → ancora "registered", nessun premio', (await val(`select status from public.referrals where referred_user_id = $1`, [E])) === 'registered' && (await balance(U.alice)) === aliceBefore);
  await db.exec(`update auth.users set email_confirmed_at = now() where id = '${E}'`);
  const tick = await store.rpc<any>('engagement_tick', {});
  const ref = await q1(`select status, qualified_at, rewarded_at from public.referrals where referred_user_id = $1`, [E]);
  check('email verificata → scheduler qualifica e premia', tick.referrals_qualified === 1 && ref.status === 'rewarded' && ref.qualified_at && ref.rewarded_at, { tick, ref });
  check('bonus a chi invita (150) e benvenuto all’invitato (50)', (await balance(U.alice)) === aliceBefore + 150
    && (await val(`select count(*)::int from public.loyalty_transactions where user_id = $1 and event_key = 'referral_welcome'`, [E])) === 1);
  const tick2 = await store.rpc<any>('engagement_tick', {});
  check('nessun premio doppio al giro successivo', tick2.referrals_qualified === 0 && (await balance(U.alice)) === aliceBefore + 150);
  const my = await as(U.alice, `select public.my_referrals() r`);
  check('pagina inviti: registrati, qualificati, punti guadagnati (senza email)', my.rows[0].r.qualified === 1 && my.rows[0].r.points === 150 && !JSON.stringify(my.rows[0].r).includes('@'), my.rows[0].r);
  const br = await as(U.owner, `select public.create_business_referral($1, 'amico@ristorante.it', 'Sushi Amico') r`, [KAIZEN]);
  check('referral B2B creato dal ristoratore (premio solo su approvazione Admin)', br.ok && /^B-/.test(br.rows[0].r.code));
  const br2 = await as(U.owner2, `select public.create_business_referral($1, 'x@ristorante.it')`, [KAIZEN]);
  check('referral B2B solo per il proprio locale', !br2.ok);
  const appr = await as(U.admin, `select public.admin_business_referral_update($1, 'approved', 'trial_extension', 30)`, [br.rows[0].r.id]);
  check('Admin approva con premio manuale (nessun credito automatico)', appr.ok && (await val(`select reward_type from public.business_referrals where id = $1`, [br.rows[0].r.id])) === 'trial_extension');
}

// ═════════════════════════════════════════════════════════════
section('Notifiche in-app e push');
{
  const n = await as(U.alice, `select count(*)::int n, count(*) filter (where read_at is null)::int u from public.notifications`);
  check('l’utente vede le proprie notifiche', n.rows[0].n > 0 && n.rows[0].u > 0);
  const other = await as(U.bob, `select count(*)::int n from public.notifications where user_id = $1`, [U.alice]);
  check('RLS: nessun accesso alle notifiche di altri', other.rows[0].n === 0);
  const one = await val(`select id from public.notifications where user_id = $1 order by created_at limit 1`, [U.alice]);
  await as(U.alice, `select public.mark_notifications_read(array[$1]::uuid[])`, [one]);
  check('segna come letta (una)', (await val(`select read_at is not null from public.notifications where id = $1`, [one])) === true);
  await as(U.alice, `select public.mark_notifications_read(null)`);
  check('segna tutte come lette', (await val(`select count(*)::int from public.notifications where user_id = $1 and read_at is null`, [U.alice])) === 0);

  const P256 = 'BNcRdreALRFXTkOOUHK1EtK2wtaz5Ry4YfYCA_0QTpQtUbVlUls0VJXg7A8u-Ts1XbjhazAkj7I99e8QcYP7DkM';
  const sub = await as(U.bob, `select public.save_push_subscription('https://fcm.googleapis.com/fcm/send/bob-1', $1, 'tBHItJI5svbpez7KI4CCXg', 'Chrome su Android', 'android')`, [P256]);
  check('iscrizione push del dispositivo (attiva le push)', sub.ok && (await val(`select push_enabled from public.notification_preferences where user_id = $1`, [U.bob])) === true, sub.err);
  const bad = await as(U.bob, `select public.save_push_subscription('http://insecure/ep', $1, 'tBHItJI5svbpez7KI4CCXg')`, [P256]);
  check('endpoint non HTTPS rifiutato', !bad.ok);
  const ssrf = await as(U.bob, `select public.save_push_subscription('https://169.254.169.254/latest/meta-data', $1, 'tBHItJI5svbpez7KI4CCXg')`, [P256]);
  check('Fase 11 · endpoint verso host arbitrario (SSRF) rifiutato', !ssrf.ok && /non supportato/.test(ssrf.err ?? ''), ssrf.err);
  const peek = await as(U.carla, `select count(*)::int n from public.push_subscriptions`);
  check('RLS: endpoint di altri non leggibili', peek.rows[0].n === 0);
  const outbox = await as(U.bob, `select count(*)::int n from public.push_outbox`);
  check('coda push inaccessibile dal browser', !outbox.ok);
  await as(U.bob, `select public.save_push_subscription('https://fcm.googleapis.com/fcm/send/bob-2', $1, 'tBHItJI5svbpez7KI4CCXg', 'Safari su iPhone', 'ios')`, [P256]);
  // Notifica essenziale → push in coda
  const res = await pastReservation(U.bob, KAIZEN, 0, 'pending');
  await as(U.owner, `select public.set_reservation_status($1, 'confirmed')`, [res]);
  check('conferma prenotazione → notifica + push in coda', (await val(`select count(*)::int from public.push_outbox where user_id = $1 and status = 'pending'`, [U.bob])) === 1);
  const sent: string[] = [];
  const fakeSend: PushSender = async (s) => {
    sent.push(s.endpoint);
    if (s.endpoint.endsWith('bob-2')) throw Object.assign(new Error('gone'), { statusCode: 410 });
    return { statusCode: 201 };
  };
  const logs: string[] = [];
  const cr = await engagementCron({ store, send: fakeSend, log: (l, m, d) => logs.push(`${l} ${m} ${JSON.stringify(d ?? {})}`) });
  check('invio push a tutti i dispositivi attivi (conferma + promemoria)', sent.length >= 2 && cr.push.items >= 1 && cr.push.sent === cr.push.items && cr.push.gone >= 1, cr);
  check('dispositivo scaduto (410) disattivato', (await val(`select is_active from public.push_subscriptions where endpoint = 'https://fcm.googleapis.com/fcm/send/bob-2'`)) === false);
  check('push marcata come inviata', (await val(`select status from public.push_outbox where user_id = $1`, [U.bob])) === 'sent');
  check('nessun endpoint o chiave nei log', !logs.some((l) => /fcm\.googleapis|tBHI|BNcR/.test(l)));
  await as(U.bob, `select public.remove_push_subscription('https://fcm.googleapis.com/fcm/send/bob-1')`);
  check('disiscrizione: nessun dispositivo attivo → push disattivate', (await val(`select push_enabled from public.notification_preferences where user_id = $1`, [U.bob])) === false);
  // Senza VAPID configurato
  await as(U.bob, `select public.save_push_subscription('https://fcm.googleapis.com/fcm/send/bob-3', $1, 'tBHItJI5svbpez7KI4CCXg')`, [P256]);
  await as(U.owner, `select public.set_reservation_status($1, 'cancelled')`, [res]);
  const cr2 = await engagementCron({ store, send: null, log: () => undefined });
  check('push non configurato → in-app comunque, push "failed" senza bloccare', cr2.push.failed >= 1 && (await val(`select count(*)::int from public.push_outbox where error = 'push_not_configured'`)) >= 1);
}

// ═════════════════════════════════════════════════════════════
section('Promemoria prenotazione, coupon in scadenza, richiesta recensione');
{
  codeN++;
  const r = await q1(`insert into public.reservations (restaurant_id, user_id, guest_name, guest_surname, guest_email, guest_phone, reservation_date, reservation_time, party_size, status, confirmation_code)
    values ($1, $2, 'Carla', 'Test', 'carla@test.it', '+39 333 2222222', (now() at time zone 'Europe/Rome')::date + 1, '21:00', 2, 'confirmed', $3) returning id`, [KAIZEN, U.carla, `ASF-R${String(codeN).padStart(4, '0')}`]);
  const start = await val(`select ((now() at time zone 'Europe/Rome')::date + 1 + time '21:00') at time zone 'Europe/Rome'`);
  const t24 = new Date(new Date(start).getTime() - 23 * 3600_000).toISOString();
  const a = await store.rpc<any>('engagement_tick', { p_now: t24 });
  const msg = await val(`select body from public.notifications where user_id = $1 and title = 'Promemoria prenotazione' order by created_at desc limit 1`, [U.carla]);
  check('promemoria 24 h: "Domani alle 21:00 hai una prenotazione da …"', a.reservation_reminders >= 1 && /^Domani alle 21:00 hai una prenotazione da Kaizen Sushi Lab\./.test(msg ?? ''), { a, msg });
  const b = await store.rpc<any>('engagement_tick', { p_now: t24 });
  check('nessun promemoria duplicato', b.reservation_reminders === 0 && (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Promemoria prenotazione'`, [U.carla])) === 1);
  const t2 = new Date(new Date(start).getTime() - 1.5 * 3600_000).toISOString();
  await store.rpc('engagement_tick', { p_now: t2 });
  check('promemoria 2 h inviato separatamente', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Promemoria prenotazione'`, [U.carla])) === 2);
  check('email promemoria (transazionale) in coda solo per il primo', (await val(`select count(*)::int from public.email_outbox where event_type = 'reservation_reminder' and recipient = 'carla.test@test.it'`)) === 1);
  // Prenotazione annullata: niente promemoria
  codeN++;
  const rc = await q1(`insert into public.reservations (restaurant_id, user_id, guest_name, guest_surname, guest_email, guest_phone, reservation_date, reservation_time, party_size, status, confirmation_code)
    values ($1, $2, 'Dario', 'Test', 'dario@test.it', '+39 333 3333333', (now() at time zone 'Europe/Rome')::date + 1, '21:00', 2, 'cancelled', $3) returning id`, [KAIZEN, U.dario, `ASF-R${String(codeN).padStart(4, '0')}`]);
  void rc;
  await store.rpc('engagement_tick', { p_now: t24 });
  check('nessun promemoria per prenotazioni annullate', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Promemoria prenotazione'`, [U.dario])) === 0);
  // Preferenza disattivata
  await as(U.carla, `update public.notification_preferences set reservation_reminders = false where user_id = $1`, [U.carla]);
  codeN++;
  await q1(`insert into public.reservations (restaurant_id, user_id, guest_name, guest_surname, guest_email, guest_phone, reservation_date, reservation_time, party_size, status, confirmation_code)
    values ($1, $2, 'Carla', 'Test', 'carla@test.it', '+39 333 2222222', (now() at time zone 'Europe/Rome')::date + 1, '21:30', 2, 'confirmed', $3) returning id`, [HANAMI, U.carla, `ASF-R${String(codeN).padStart(4, '0')}`]);
  const t24b = new Date(new Date(start).getTime() - 23 * 3600_000 + 30 * 60_000).toISOString();
  await store.rpc('engagement_tick', { p_now: t24b });
  check('preferenza disattivata → nessun promemoria', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Promemoria prenotazione'`, [U.carla])) === 2);
  await as(U.carla, `update public.notification_preferences set reservation_reminders = true where user_id = $1`, [U.carla]);
  void r;

  // Coupon in scadenza
  const cp = await q1(`insert into public.coupons (restaurant_id, title, description, discount_type, discount_value, valid_from, valid_until, is_active, code, max_redemptions_per_user)
    values ($1, 'Gyoza omaggio', 'Test', 'free_item', null, now() - interval '1 day', now() + interval '20 hours', true, 'GYOZA', 1) returning id`, [KAIZEN]);
  const cl = await as(U.carla, `select public.claim_coupon($1) c`, [cp.id]);
  const cl2 = await as(U.dario, `select public.claim_coupon($1) c`, [cp.id]);
  await as(U.owner, `select public.redeem_coupon($1, $2)`, [KAIZEN, cl2.rows[0].c.claim_code]);
  const c1 = await store.rpc<any>('engagement_tick', {});
  const c2 = await store.rpc<any>('engagement_tick', {});
  const cmsg = await val(`select body from public.notifications where user_id = $1 and title = 'Coupon in scadenza'`, [U.carla]);
  check('coupon in scadenza: un solo promemoria, solo se ancora da usare', cl.ok && c1.coupon_reminders === 1 && c2.coupon_reminders === 0 && /scade (domani|oggi)/.test(cmsg ?? ''), { c1, cmsg });
  check('coupon già usato: nessun promemoria', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Coupon in scadenza'`, [U.dario])) === 0);

  // Richiesta di recensione
  const res = await pastReservation(U.dario, HANAMI, 1);
  await complete(U.owner3, res);
  await db.exec(`update public.reservations set completed_at = now() - interval '3 hours' where id = '${res}'`);
  const rr = await store.rpc<any>('engagement_tick', {});
  const rrm = await q1(`select title, link from public.notifications where user_id = $1 and type = 'review' order by created_at desc limit 1`, [U.dario]);
  check('dopo la visita: "Com’è andata?" con link al form', rr.review_requests >= 1 && /^Com’è andata da Hanami/.test(rrm?.title ?? '') && /\?review=1#recensioni$/.test(rrm?.link ?? ''), rrm);
  const rr2 = await store.rpc<any>('engagement_tick', {});
  check('una sola richiesta di recensione', rr2.review_requests === 0);
  const res2 = await pastReservation(U.alice, KAIZEN, 1);
  await complete(U.owner, res2);
  await db.exec(`update public.reservations set completed_at = now() - interval '3 hours' where id = '${res2}'`);
  const rr3 = await store.rpc<any>('engagement_tick', {});
  check('nessuna richiesta se il locale è già stato recensito', rr3.review_requests === 0);
}

// ═════════════════════════════════════════════════════════════
section('Follow e badge');
{
  const f = await as(U.carla, `select public.set_follow($1, true)`, [HANAMI]);
  check('"Segui questo ristorante" (scelta esplicita)', f.ok && (await val(`select notifications_enabled from public.favorites where user_id = $1 and restaurant_id = $2`, [U.carla, HANAMI])) === true
    && (await val(`select favorite_restaurants from public.notification_preferences where user_id = $1`, [U.carla])) === true);
  await as(U.bob, `insert into public.favorites (user_id, restaurant_id) values ($1, $2)`, [U.bob, HANAMI]);
  await db.exec(`insert into public.offers (restaurant_id, title, description, offer_type, discount_type, is_active, starts_at) values ('${HANAMI}', 'Menu degustazione -15%', 'Test', 'percentage', 'percent', true, now())`);
  check('nuova offerta → avviso ai follower', (await val(`select count(*)::int from public.notifications where user_id = $1 and type = 'restaurant'`, [U.carla])) === 1);
  check('solo preferito senza follow → nessun avviso', (await val(`select count(*)::int from public.notifications where user_id = $1 and type = 'restaurant'`, [U.bob])) === 0);
  await db.exec(`insert into public.offers (restaurant_id, title, description, offer_type, discount_type, is_active, starts_at) values ('${HANAMI}', 'Seconda offerta', 'Test', 'percentage', 'percent', true, now())`);
  check('massimo un avviso al giorno per ristorante', (await val(`select count(*)::int from public.notifications where user_id = $1 and type = 'restaurant'`, [U.carla])) === 1);
  const badges = await as(U.alice, `select a.key from public.user_achievements u join public.achievements a on a.id = u.achievement_id`);
  check('badge assegnato dal server ("Primo sushi")', badges.rows.some((b: any) => b.key === 'first_sushi'), badges.rows);
  const fake = await as(U.bob, `insert into public.user_achievements (user_id, achievement_id) select $1, id from public.achievements limit 1`, [U.bob]);
  check('badge NON assegnabili dal browser', !fake.ok);
  const n1 = await store.rpc<number>('check_achievements', { p_user: U.alice });
  check('nessun badge duplicato', n1 === 0);
}

// ═════════════════════════════════════════════════════════════
section('Campagne (ristoratore e Admin)');
let campId = '';
{
  // Opt-in: Carla segue Hanami (favorite_restaurants), Alice accetta marketing
  await as(U.alice, `update public.notification_preferences set marketing = true where user_id = $1`, [U.alice]);
  await as(U.alice, `select public.set_follow($1, true)`, [HANAMI]);
  const cnt = await as(U.owner3, `select public.campaign_audience_count('restaurant', $1, 'followers') n`, [HANAMI]);
  check('anteprima: solo numeri aggregati', cnt.ok && cnt.rows[0].n === 2, cnt.err || cnt.rows);
  const c = await as(U.owner3, `select public.create_campaign($1::jsonb) c`, [JSON.stringify({ scope: 'restaurant', restaurant_id: HANAMI, title: 'Sushi night', message: 'Stasera uramaki speciali per chi ci segue', target: 'followers', channels: ['in_app', 'push', 'email'], action_url: 'https://evil.example' })]);
  campId = c.rows[0]?.c?.id;
  check('ristoratore Premium crea una campagna', c.ok && c.rows[0].c.status === 'scheduled', c.err);
  const camp = await q1(`select action_url, channels from public.campaigns where id = $1`, [campId]);
  check('link forzato alla propria scheda; niente email dal ristoratore', /^\/ristorante\/hanami/.test(camp.action_url) && !camp.channels.includes('email'), camp);
  const second = await as(U.owner3, `select public.create_campaign($1::jsonb)`, [JSON.stringify({ scope: 'restaurant', restaurant_id: HANAMI, title: 'Altra', message: 'Seconda campagna oggi', target: 'followers' })]);
  check('massimo una campagna al giorno', !second.ok && /una campagna al giorno/.test(second.err));
  const biz = await as(U.owner2, `select public.create_campaign($1::jsonb)`, [JSON.stringify({ scope: 'restaurant', restaurant_id: RAMEN, title: 'Ramen', message: 'Promo ramen per tutti', target: 'followers' })]);
  check('piano Business: campagne non incluse (feature flag)', !biz.ok && /PLAN_FEATURE/.test(biz.err), biz.err);
  const wrong = await as(U.owner3, `select public.create_campaign($1::jsonb)`, [JSON.stringify({ scope: 'restaurant', restaurant_id: KAIZEN, title: 'Furto', message: 'Campagna su un altro locale', target: 'followers' })]);
  check('campagna sul ristorante di altri → negata', !wrong.ok);
  const plat = await as(U.owner3, `select public.create_campaign($1::jsonb)`, [JSON.stringify({ scope: 'platform', title: 'Tutti', message: 'Messaggio a tutti gli utenti', target: 'all_users' })]);
  check('campagne di piattaforma solo per l’Admin', !plat.ok);
  const seeOther = await as(U.owner2, `select count(*)::int n from public.campaigns`);
  check('le campagne di altri locali non sono visibili', seeOther.rows[0].n === 0);
  const deliv = await as(U.owner3, `select count(*)::int n from public.campaign_deliveries`);
  check('il ristoratore non vede destinatari né consegne', deliv.rows[0].n === 0);
  const t = await store.rpc<any>('engagement_tick', {});
  const st = await as(U.owner3, `select public.push_campaign_stats($1) s`, [campId]);
  check('invio dallo scheduler: consegne in-app (salvate) + push solo a chi ha dispositivi', t.campaigns === 1 && st.rows[0]?.s?.recipients === 2 && st.rows[0]?.s?.delivered === 2, st.err || st.rows[0]?.s);
  const nid = await val(`select id from public.notifications where user_id = $1 and type = 'promotion'`, [U.alice]);
  const link = await val(`select link from public.notifications where id = $1`, [nid]);
  await as(U.alice, `select public.mark_notifications_read(array[$1]::uuid[])`, [nid]);
  const del = /cd=([0-9a-f-]{36})/.exec(link ?? '')?.[1];
  await as(null, `select public.track_campaign_click($1)`, [del]);
  const st2 = await as(U.owner3, `select public.push_campaign_stats($1) s`, [campId]);
  check('metriche reali: aperture (letta) e click (link tracciato), CTR', st2.rows[0].s.opened === 1 && st2.rows[0].s.clicked === 1 && Number(st2.rows[0].s.ctr) === 50, st2.rows[0].s);
  const push = await val(`select count(*)::int from public.campaign_deliveries where campaign_id = $1 and channel = 'push' and status = 'skipped'`, [campId]);
  check('push non inventate: "skipped" senza dispositivo, mai "delivered"', push === 2 && (await val(`select count(*)::int from public.campaign_deliveries where channel = 'push' and delivered_at is not null`)) === 0);
  // Limite mensile Premium (2)
  await db.exec(`update public.campaigns set created_at = now() - interval '2 days' where id = '${campId}'`);
  const c2 = await as(U.owner3, `select public.create_campaign($1::jsonb) c`, [JSON.stringify({ scope: 'restaurant', restaurant_id: HANAMI, title: 'Seconda', message: 'Seconda campagna del mese', target: 'all_eligible' })]);
  await db.exec(`update public.campaigns set created_at = now() - interval '1 day' where id = '${c2.rows[0]?.c?.id}'`);
  const c3 = await as(U.owner3, `select public.create_campaign($1::jsonb)`, [JSON.stringify({ scope: 'restaurant', restaurant_id: HANAMI, title: 'Terza', message: 'Terza campagna del mese', target: 'all_eligible' })]);
  check('limite mensile del piano (Premium = 2)', c2.ok && !c3.ok && /limite di campagne/.test(c3.err), [c2.err, c3.err]);
  const canc = await as(U.owner3, `select public.cancel_campaign($1)`, [c2.rows[0].c.id]);
  check('il ristoratore annulla una campagna programmata', canc.ok && (await val(`select status from public.campaigns where id = $1`, [c2.rows[0].c.id])) === 'cancelled');
  // Admin: tutti gli utenti (solo con consenso marketing) e città
  const a1 = await as(U.admin, `select public.create_campaign($1::jsonb) c`, [JSON.stringify({ scope: 'platform', title: 'Novità AsiaFood', message: 'Scopri le nuove offerte della settimana', target: 'all_users', action_url: '/offers' })]);
  await store.rpc('engagement_tick', {});
  const s1 = await as(U.admin, `select public.push_campaign_stats($1) s`, [a1.rows[0].c.id]);
  check('campagna Admin: raggiunge solo chi ha dato il consenso marketing', a1.ok && s1.rows[0].s.recipients === 1, s1.rows[0]?.s);
  const a2 = await as(U.admin, `select public.create_campaign($1::jsonb) c`, [JSON.stringify({ scope: 'platform', title: 'Taranto', message: 'Novità a Taranto per te', target: 'city', targeting: { city_slug: 'taranto' }, action_url: 'javascript:alert(1)' })]);
  check('link esterni/script rifiutati nelle campagne Admin', !a2.ok && /percorso interno/.test(a2.err));
  const a3 = await as(U.admin, `select public.create_campaign($1::jsonb) c`, [JSON.stringify({ scope: 'platform', title: 'Taranto', message: 'Novità a Taranto per te', target: 'city', targeting: { city_slug: 'taranto' }, send_at: new Date(Date.now() + 86400_000).toISOString() })]);
  const ca = await as(U.admin, `select public.cancel_campaign($1)`, [a3.rows[0].c.id]);
  check('campagna programmata annullata dall’Admin (audit log)', ca.ok && (await val(`select count(*)::int from public.admin_audit_logs where action = 'campaign_cancelled'`)) === 1);
  // Tetto settimanale per utente
  await as(U.admin, `update public.platform_settings set value = '1' where key = 'campaign_max_per_user_week'`);
  const a4 = await as(U.admin, `select public.create_campaign($1::jsonb) c`, [JSON.stringify({ scope: 'platform', title: 'Ancora', message: 'Terzo messaggio della settimana', target: 'all_users' })]);
  await store.rpc('engagement_tick', {});
  check('tetto promozionale per persona (frequenza) rispettato', (await val(`select count(*)::int from public.campaign_deliveries where campaign_id = $1 and status = 'skipped' and error = 'frequency_cap'`, [a4.rows[0].c.id])) === 1);
}

// ═════════════════════════════════════════════════════════════
section('Statistiche: retention (Admin) e fidelizzazione (ristoratore)');
{
  await as(U.bob, `select public.record_activity()`);
  const s = await as(U.admin, `select public.admin_retention_stats(30) s`);
  const x = s.rows[0]?.s;
  check('retention: DAU/WAU/MAU reali e definizioni', s.ok && x.dau >= 1 && x.wau >= x.dau && x.mau >= x.wau && x.definitions?.dau, s.err || x);
  check('retention: recensioni, referral, punti, push, coupon', x.reviews_published >= 2 && x.reviews_verified >= 1 && x.referral_qualified === 1 && x.points_issued > 0 && x.points_redeemed >= 300
    && typeof x.push_subscribers === 'number' && x.coupon_users >= 1, x);
  const denied = await as(U.alice, `select public.admin_retention_stats(30)`);
  check('retention solo Admin', !denied.ok);
  const e = await as(U.owner3, `select public.restaurant_engagement_stats($1, 30) s`, [HANAMI]);
  check('ristoratore: rating, follower, clienti di ritorno, campagne (senza dati personali)', e.ok && e.rows[0].s.followers === 2 && e.rows[0].s.campaign_sends >= 2 && !JSON.stringify(e.rows[0].s).includes('@'), e.err || e.rows[0].s);
  const eo = await as(U.owner2, `select public.restaurant_engagement_stats($1, 30)`, [HANAMI]);
  check('statistiche di un altro locale negate', !eo.ok);
  const act = await as(U.alice, `select count(*)::int n from public.user_activity_days`);
  check('attività degli utenti non leggibile dagli utenti', act.rows[0].n === 0);
  const aud = await as(U.alice, `select count(*)::int n from public.admin_audit_logs`);
  check('audit log solo Admin', aud.rows[0].n === 0);
}

console.log(`\n${pass} passati, ${fail} falliti`);
process.exit(fail ? 1 : 0);
