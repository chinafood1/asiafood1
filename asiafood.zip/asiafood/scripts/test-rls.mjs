// Test di sicurezza RLS: esegue migrazioni + seed su Postgres in-memory (PGlite)
// con uno stub di auth/storage Supabase e verifica i permessi di tutti i ruoli.
// Uso: npm run test:db
import { PGlite } from '@electric-sql/pglite';
import { pg_trgm } from '@electric-sql/pglite/contrib/pg_trgm';
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto';
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../supabase');
const db = new PGlite({ extensions: { pg_trgm, pgcrypto } });

// ── Stub minimale dell'ambiente Supabase ──
await db.exec(`
create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
create schema auth; create schema storage;
create table auth.users (id uuid primary key, email text, raw_user_meta_data jsonb default '{}', email_confirmed_at timestamptz);
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
create function auth.role() returns text language sql stable as $$ select nullif(current_setting('request.jwt.claim.role', true), '') $$;
create table storage.buckets (id text primary key, name text, public boolean, file_size_limit bigint, allowed_mime_types text[]);
create table storage.objects (id uuid primary key default gen_random_uuid(), bucket_id text, name text, owner uuid);
alter table storage.objects enable row level security;
create function storage.foldername(name text) returns text[] language sql immutable as $$ select (string_to_array(name, '/'))[1:array_length(string_to_array(name,'/'),1)-1] $$;
grant usage on schema public, auth, storage to anon, authenticated, service_role;
grant all on storage.objects to anon, authenticated;
grant execute on all functions in schema auth to anon, authenticated, service_role;
`);

const files = readdirSync(`${root}/migrations`).sort();
for (const f of files) {
  try { await db.exec(readFileSync(`${root}/migrations/${f}`, 'utf8')); console.log('OK  ', f); }
  catch (e) { console.log('FAIL', f, e.message); process.exit(1); }
}
try { await db.exec(readFileSync(`${root}/seed.sql`, 'utf8')); console.log('OK   seed.sql'); }
catch (e) { console.log('FAIL seed.sql', e.message); process.exit(1); }
// service_role: su Supabase ha tutti i privilegi sulle tabelle
await db.exec('grant all on all tables in schema public to service_role; grant usage on all sequences in schema public to service_role;');

const U = {
  admin: '11111111-1111-4111-8111-111111111111',
  owner: '22222222-2222-4222-8222-222222222222',
  cust: '33333333-3333-4333-8333-333333333333',
  other: '44444444-4444-4444-8444-444444444444',
  mgr: '55555555-5555-4555-8555-555555555555',
};
for (const [k, id] of Object.entries(U)) await db.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1, $2, '{"full_name":"${k}"}')`, [id, `${k}@test.it`]);
await db.exec(`update public.profiles set role='admin' where id='${U.admin}'`);

const R = (n) => `e0000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const R1 = R(1), R2 = R(2), R3 = R(3), R4 = R(4);
const TARANTO = 'c0000000-0000-4000-8000-000000000001';

async function as(user, sql, params = [], role) {
  const r = role ?? (user ? 'authenticated' : 'anon');
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${user ?? ''}', false); select set_config('request.jwt.claim.role', '${r}', false); set role ${r};`);
  try { const res = await db.query(sql, params); return { ok: true, rows: res.rows, affected: res.affectedRows }; }
  catch (e) { return { ok: false, err: e.message }; }
  finally { await db.exec('reset role;'); }
}
const q1 = async (sql) => (await db.query(sql)).rows[0];
let pass = 0, fail = 0;
function check(name, cond, extra) { if (cond) { pass++; console.log('  ✓', name); } else { fail++; console.log('  ✗', name, extra ? JSON.stringify(extra) : ''); } }
const claimSql = (rid, uid, extra = '') =>
  `insert into public.restaurant_claims (restaurant_id, user_id, first_name, last_name, role, phone, business_email, verification_method${extra ? ',' + extra.split('=')[0] : ''})
   values ('${rid}', '${uid}', 'Mario', 'Rossi', 'Titolare', '3331234567', 'mario@test.it', 'phone'${extra ? ",'" + extra.split('=')[1] + "'" : ''}) returning id`;

console.log('\n— Visitatori e clienti');
let r = await as(null, 'select count(*)::int n from public.restaurants');
check('anon legge ristoranti attivi (demo visibili di default)', r.ok && r.rows[0].n > 0, r);
r = await as(null, `update public.restaurants set name='x' where id='${R1}'`);
check('anon non può modificare', !r.ok || r.affected === 0, r);
r = await as(null, 'select count(*)::int n from public.profiles');
check('anon non vede profili', !r.ok || r.rows[0].n === 0, r);
r = await as(U.cust, `update public.restaurants set name='hack' where id='${R1}'`);
check('cliente non modifica ristoranti', !r.ok || r.affected === 0, r);
r = await as(U.cust, `update public.profiles set role='admin' where id='${U.cust}'`);
check('cliente non si auto-promuove admin', (await q1(`select role from public.profiles where id='${U.cust}'`)).role === 'customer', r);
r = await as(U.cust, `insert into public.restaurants (name, slug, city_id) values ('x','x-slug','${TARANTO}')`);
check('cliente non crea ristoranti', !r.ok, r);
r = await as(U.cust, `insert into public.favorites (user_id, restaurant_id) values ('${U.cust}', '${R1}')`);
check('cliente salva preferito', r.ok, r);
r = await as(U.cust, `insert into public.favorites (user_id, restaurant_id) values ('${U.owner}', '${R1}')`);
check('cliente non scrive preferiti altrui', !r.ok, r);
r = await as(U.cust, `insert into public.restaurant_members (restaurant_id, user_id, role) values ('${R1}', '${U.cust}', 'owner')`);
check('cliente NON si auto-assegna come titolare (restaurant_members)', !r.ok, r);
r = await as(U.cust, `update public.platform_settings set value='false' where key='show_demo_data'`);
check('cliente non cambia impostazioni piattaforma', !r.ok || r.affected === 0, r);

console.log('\n— Rivendicazione: invio');
r = await as(U.owner, claimSql(R1, U.owner));
check('utente invia rivendicazione', r.ok, r);
const claimId = r.rows?.[0]?.id;
r = await as(U.owner, claimSql(R1, U.owner));
check('niente seconda richiesta aperta sullo stesso locale', !r.ok, r);
r = await as(U.owner, claimSql(R2, U.owner, 'status=approved'));
check('non può auto-approvarsi', !r.ok, r);
r = await as(U.owner, claimSql(R2, U.cust));
check('non può inviare claim a nome di altri', !r.ok, r);
r = await as(U.owner, claimSql(R2, U.owner, `verification_document_url=${U.cust}/x/doc.pdf`));
check('non può allegare documenti di altri utenti', !r.ok, r);
r = await as(U.owner, `insert into storage.objects (bucket_id, name) values ('claim-documents', '${U.owner}/abc/visura.pdf')`);
check('storage privato: upload nella propria cartella', r.ok, r);
r = await as(U.owner, `insert into storage.objects (bucket_id, name) values ('claim-documents', '${U.cust}/abc/visura.pdf')`);
check('storage privato: NO upload nella cartella altrui', !r.ok, r);
r = await as(U.cust, `select count(*)::int n from storage.objects where bucket_id='claim-documents'`);
check('storage privato: altri utenti non vedono i documenti', r.ok && r.rows[0].n === 0, r);
r = await as(null, `select count(*)::int n from storage.objects where bucket_id='claim-documents'`);
check('storage privato: anon non vede i documenti', !r.ok || r.rows[0].n === 0, r);
r = await as(U.admin, `select count(*)::int n from storage.objects where bucket_id='claim-documents'`);
check('storage privato: Admin vede i documenti', r.ok && r.rows[0].n === 1, r);
check('bucket documenti privato', (await q1(`select public from storage.buckets where id='claim-documents'`)).public === false);
r = await as(U.cust, `select count(*)::int n from public.restaurant_claims`);
check('altri utenti non leggono claim altrui', r.ok && r.rows[0].n === 0, r);
r = await as(U.owner, `update public.restaurant_claims set status='approved' where id='${claimId}'`);
check('richiedente non modifica lo stato del claim', !r.ok || r.affected === 0, r);

console.log('\n— Rivendicazione: revisione Admin');
r = await as(U.owner, `select public.approve_claim('${claimId}')`);
check('non-admin non approva', !r.ok, r);
r = await as(U.owner, `select public.request_claim_info('${claimId}', 'x')`);
check('non-admin non richiede informazioni', !r.ok, r);
r = await as(U.admin, `select public.set_claim_under_review('${claimId}')`);
check('Admin mette in revisione', r.ok && (await q1(`select status from public.restaurant_claims where id='${claimId}'`)).status === 'under_review', r);
r = await as(U.admin, `select public.request_claim_info('${claimId}', 'Inviaci una visura camerale')`);
check('Admin richiede informazioni', r.ok && (await q1(`select status from public.restaurant_claims where id='${claimId}'`)).status === 'more_information_required', r);
r = await as(U.owner, `select body from public.restaurant_claim_messages where claim_id='${claimId}'`);
check('richiedente legge il messaggio Admin', r.ok && r.rows.length === 1, r);
r = await as(U.cust, `select count(*)::int n from public.restaurant_claim_messages`);
check('altri non leggono i messaggi', r.ok && r.rows[0].n === 0, r);
r = await as(U.cust, `select public.respond_to_claim('${claimId}', 'hack')`);
check('altri non rispondono al claim', !r.ok, r);
r = await as(U.owner, `insert into public.restaurant_claim_messages (claim_id, author_role, body) values ('${claimId}', 'admin', 'finto admin')`);
check('richiedente non inserisce messaggi diretti (solo RPC)', !r.ok, r);
r = await as(U.owner, `select public.respond_to_claim('${claimId}', 'Ecco la visura', '${U.owner}/abc/visura.pdf')`);
check('richiedente risponde → torna "in revisione"', r.ok && (await q1(`select status from public.restaurant_claims where id='${claimId}'`)).status === 'under_review', r);
r = await as(U.owner, `update public.restaurants set description='prima' where id='${R1}'`);
check('prima dell\'approvazione il richiedente non modifica', !r.ok || r.affected === 0, r);
r = await as(U.cust, claimSql(R1, U.cust));
check('un secondo utente può ancora chiedere (prima dell\'approvazione)', r.ok, r);
const claim2 = r.rows?.[0]?.id;
r = await as(U.admin, `select public.approve_claim('${claimId}', 'Verificato al telefono')`);
check('Admin approva', r.ok, r);
const own = await q1(`select r.owner_id, r.claimed_by, r.claimed_at, r.is_verified, r.data_status, p.role from public.restaurants r join public.profiles p on p.id = r.owner_id where r.id='${R1}'`);
check('owner_id, claimed_by, claimed_at, is_verified, data_status=claimed', own && own.owner_id === U.owner && own.claimed_by === U.owner && own.claimed_at && own.is_verified && own.data_status === 'claimed', own);
check('ruolo profilo → restaurant_owner', own?.role === 'restaurant_owner', own);
const mem = await q1(`select role, status from public.restaurant_members where restaurant_id='${R1}' and user_id='${U.owner}'`);
check('membership "owner" attiva creata', mem?.role === 'owner' && mem?.status === 'active', mem);
check('claim concorrente chiuso automaticamente', (await q1(`select status from public.restaurant_claims where id='${claim2}'`)).status === 'rejected');
check('approved_at valorizzato', !!(await q1(`select approved_at from public.restaurant_claims where id='${claimId}'`)).approved_at);
r = await as(U.other, claimSql(R1, U.other));
check('dopo l\'approvazione nessun altro può rivendicare', !r.ok, r);

console.log('\n— Ristoratore approvato');
r = await as(U.owner, `update public.restaurants set description='nuova', is_temporarily_closed=true where id='${R1}'`);
const after = await q1(`select description, is_temporarily_closed from public.restaurants where id='${R1}'`);
check('modifica il proprio locale (anche chiusura temporanea)', r.ok && after.description === 'nuova' && after.is_temporarily_closed, { r, after });
await db.exec(`update public.restaurants set is_temporarily_closed=false where id='${R1}'`);
r = await as(U.owner, `update public.restaurants set is_featured=false, data_status='verified', source_url='https://x.it', is_permanently_closed=true, subscription_plan='top', slug='hack' where id='${R1}'`);
const prot = await q1(`select is_featured, data_status, source_url, is_permanently_closed, subscription_plan, slug from public.restaurants where id='${R1}'`);
check('NON cambia campi riservati (evidenza, stato dati, fonte, chiusura definitiva, piano, slug)', prot.is_featured === true && prot.data_status === 'claimed' && prot.source_url === null && !prot.is_permanently_closed && prot.slug === 'kaizen-sushi-lab-taranto', prot);
r = await as(U.owner, `update public.restaurants set description='altro' where id='${R2}'`);
check('NON modifica locali altrui', !r.ok || r.affected === 0, r);
r = await as(U.owner, `insert into public.menus (restaurant_id, name) values ('${R1}', 'Nuovo menu') returning id`);
check('crea menu proprio', r.ok, r);
const menuId = r.rows?.[0]?.id;
r = await as(U.owner, `insert into public.menu_categories (menu_id, name) values ('${menuId}', 'Antipasti') returning id, restaurant_id`);
check('menu_category con restaurant_id derivato', r.ok && r.rows[0].restaurant_id === R1, r);
r = await as(U.owner, `insert into public.menu_items (menu_category_id, name, price) values ('${r.rows?.[0]?.id}', 'Edamame', 4.5)`);
check('crea piatto', r.ok, r);
r = await as(U.owner, `insert into public.menus (restaurant_id, name) values ('${R2}', 'X')`);
check('NON crea menu altrui', !r.ok, r);
r = await as(U.owner, `insert into public.restaurant_hours (restaurant_id, day_of_week, opens_at, closes_at) values ('${R1}', 1, '12:00', '15:00')`);
check('gestisce i propri orari', r.ok, r);
r = await as(U.owner, `insert into public.offers (restaurant_id, title) values ('${R1}', 'Promo')`);
check('crea offerta', r.ok, r);
r = await as(U.owner, `insert into public.coupons (restaurant_id, code, title) values ('${R2}', 'X', 'X')`);
check('NON crea coupon altrui', !r.ok, r);
r = await as(U.owner, `insert into public.sponsored_campaigns (restaurant_id, name) values ('${R1}', 'hack')`);
check('NON si auto-sponsorizza', !r.ok, r);
r = await as(U.owner, `insert into public.restaurant_sources (restaurant_id, source_name) values ('${R1}', 'fonte')`);
check('NON modifica le fonti (solo Admin)', !r.ok, r);
r = await as(U.owner, `insert into public.restaurant_members (restaurant_id, user_id, role) values ('${R1}', '${U.cust}', 'manager')`);
check('NON aggiunge membri al team (solo Admin)', !r.ok, r);
r = await as(U.owner, `insert into storage.objects (bucket_id, name) values ('restaurant-media', '${R1}/logo/a.png')`);
check('storage media: upload sul proprio locale', r.ok, r);
r = await as(U.owner, `insert into storage.objects (bucket_id, name) values ('restaurant-media', '${R2}/logo/a.png')`);
check('storage media: NO upload su locale altrui', !r.ok, r);
r = await as(U.owner, `select * from public.restaurant_stats('${R1}')`);
check('legge statistiche proprie', r.ok, r);
r = await as(U.owner, `select * from public.restaurant_stats('${R2}')`);
check('NON legge statistiche altrui', !r.ok, r);

console.log('\n— Team, trasferimento e revoca (Admin)');
r = await as(U.owner, `select public.admin_set_member('${R1}', '${U.mgr}', 'manager')`);
check('ristoratore non usa RPC Admin', !r.ok, r);
r = await as(U.admin, `select public.admin_set_member('${R1}', '${U.mgr}', 'manager')`);
check('Admin aggiunge un manager', r.ok, r);
r = await as(U.mgr, `update public.restaurants set short_description='dal manager' where id='${R1}'`);
check('il manager può modificare', r.ok && r.affected === 1, r);
r = await as(U.admin, `select public.admin_set_member('${R1}', '${U.other}', 'staff')`);
r = await as(U.other, `update public.restaurants set short_description='staff' where id='${R1}'`);
check('lo staff (futuro) NON modifica', !r.ok || r.affected === 0, r);
r = await as(U.admin, `select public.admin_transfer_ownership('${R1}', '${U.cust}')`);
check('Admin trasferisce la proprietà', r.ok, r);
check('nuovo titolare impostato', (await q1(`select owner_id from public.restaurants where id='${R1}'`)).owner_id === U.cust);
check('vecchia membership owner revocata', (await q1(`select status from public.restaurant_members where restaurant_id='${R1}' and user_id='${U.owner}'`)).status === 'revoked');
check('vecchio titolare torna "customer"', (await q1(`select role from public.profiles where id='${U.owner}'`)).role === 'customer');
r = await as(U.owner, `update public.restaurants set description='ex' where id='${R1}'`);
check('vecchio titolare non modifica più', !r.ok || r.affected === 0, r);
r = await as(U.cust, `update public.restaurants set description='nuovo titolare' where id='${R1}'`);
check('nuovo titolare modifica', r.ok && r.affected === 1, r);
r = await as(U.admin, `select public.admin_revoke_ownership('${R1}', 'test')`);
const rev = await q1(`select owner_id, claimed_by, is_verified, data_status from public.restaurants where id='${R1}'`);
check('Admin revoca: nessun titolare, non verificato', r.ok && rev.owner_id === null && rev.claimed_by === null && !rev.is_verified && rev.data_status === 'unverified', { r, rev });
r = await as(U.mgr, `update public.restaurants set short_description='x' where id='${R1}'`);
check('dopo la revoca anche il team perde l\'accesso', !r.ok || r.affected === 0, r);
check('ruoli ripristinati a customer', (await q1(`select count(*)::int n from public.profiles where id in ('${U.cust}','${U.mgr}') and role='customer'`)).n === 2);

console.log('\n— Segnalazioni');
r = await as(null, `insert into public.restaurant_reports (restaurant_id, report_type, description) values ('${R3}', 'wrong_phone', 'Il numero non risponde')`);
check('anon invia una segnalazione', r.ok, r);
r = await as(null, `insert into public.restaurant_reports (restaurant_id, user_id, report_type, description) values ('${R3}', '${U.cust}', 'other', 'finta identità')`);
check('anon non può firmarsi come altro utente', !r.ok, r);
r = await as(U.cust, `insert into public.restaurant_reports (restaurant_id, user_id, report_type, description, status, admin_notes) values ('${R3}', '${U.cust}', 'closed', 'Chiuso da mesi', 'resolved', 'x')`);
const forced = await q1(`select status, admin_notes from public.restaurant_reports where user_id='${U.cust}'`);
check('utente autenticato invia segnalazione, ma stato/nota sono forzati (open, nessuna nota)', r.ok && forced.status === 'open' && forced.admin_notes === null, { r, forced });
r = await as(null, `select count(*)::int n from public.restaurant_reports`);
check('anon non legge le segnalazioni', !r.ok || r.rows[0].n === 0, r);
r = await as(U.cust, `select count(*)::int n from public.restaurant_reports`);
check('utente vede solo le proprie', r.ok && r.rows[0].n === 1, r);
r = await as(U.admin, `update public.restaurant_reports set status='resolved' where report_type='wrong_phone'`);
check('Admin gestisce le segnalazioni', r.ok && r.affected === 1, r);

console.log('\n— Import e fonti');
r = await as(U.cust, `select public.admin_import_restaurant(null, '{"name":"X","city_id":"${TARANTO}"}'::jsonb)`);
check('cliente non importa', !r.ok, r);
r = await as(U.admin, `select public.admin_import_restaurant(null, $1::jsonb, array['sushi','giapponese'], false, $2::jsonb) res`,
  [JSON.stringify({ name: 'Import Test', slug: 'kaizen-sushi-lab-taranto', city_id: TARANTO, phone: '+39 099 000000', services: ['wifi'], latitude: 40.46, longitude: 17.24, data_status: 'unverified', is_active: false, owner_id: U.cust, is_featured: true }),
   JSON.stringify({ source_type: 'official_website', source_name: 'Sito ufficiale', source_url: 'https://example.org' })]);
const imp = r.rows?.[0]?.res;
check('Admin importa (slug reso univoco)', r.ok && imp?.action === 'created' && imp.slug === 'kaizen-sushi-lab-taranto-2', r);
const impRow = imp && await q1(`select owner_id, is_featured, services, is_active from public.restaurants where id='${imp.id}'`);
check('import ignora campi fuori whitelist (owner, evidenza)', impRow && impRow.owner_id === null && impRow.is_featured === false && impRow.services[0] === 'wifi' && impRow.is_active === false, impRow);
check('import crea categorie (principale = prima)', imp && (await q1(`select count(*)::int n, bool_or(is_primary and category_id='d0000000-0000-4000-8000-000000000001') p from public.restaurant_categories where restaurant_id='${imp.id}'`)).p === true);
check('import registra la fonte', imp && (await q1(`select count(*)::int n from public.restaurant_sources where restaurant_id='${imp.id}' and is_primary`)).n === 1);
r = await as(U.admin, `select public.admin_import_restaurant($1, $2::jsonb, array['poke'], false, $3::jsonb) res`,
  [imp?.id, JSON.stringify({ website: 'https://example.org' }), JSON.stringify({ source_name: 'Sito ufficiale', source_url: 'https://example.org' })]);
check('import aggiorna un singolo campo e unisce categorie', r.ok && (await q1(`select website from public.restaurants where id='${imp?.id}'`)).website === 'https://example.org' && (await q1(`select count(*)::int n from public.restaurant_categories where restaurant_id='${imp?.id}'`)).n === 3, r);
check('fonte non duplicata', (await q1(`select count(*)::int n from public.restaurant_sources where restaurant_id='${imp?.id}'`)).n === 1);
r = await as(null, `select public.admin_import_restaurant(null, '{"name":"Svc","city_id":"${TARANTO}"}'::jsonb) res`, [], 'service_role');
check('script server (service_role) importa', r.ok && r.rows[0].res.action === 'created', r);
r = await as(null, `select count(*)::int n from public.restaurant_sources where restaurant_id='${R3}'`);
check('fonti di locali pubblici leggibili da tutti', r.ok, r);
r = await as(U.admin, `select public.admin_duplicate_restaurant('${R3}') id`);
const dup = r.rows?.[0]?.id;
const dupRow = dup && await q1(`select name, slug, is_active, owner_id from public.restaurants where id='${dup}'`);
check('Admin duplica una scheda (inattiva, senza titolare)', r.ok && dupRow?.is_active === false && dupRow.slug.endsWith('-copia') && !dupRow.owner_id, { r, dupRow });

console.log('\n— Pubblicazione e dati demo');
await as(U.admin, `update public.restaurants set owner_id='${U.owner}' where id='${R4}'`);
r = await as(U.admin, `update public.platform_settings set value='false' where key='show_demo_data'`);
check('Admin nasconde i dati demo', r.ok && r.affected === 1, r);
r = await as(null, `select count(*)::int n from public.restaurants where is_demo`);
check('anon NON vede più ristoranti demo', r.ok && r.rows[0].n === 0, r);
r = await as(null, `select count(*)::int n from public.menus m join public.restaurants x on x.id = m.restaurant_id`);
check('…né i loro menu', r.ok && r.rows[0].n === 0, r);
r = await as(U.owner, `select count(*)::int n from public.restaurants where id='${R4}'`);
check('il titolare vede comunque il proprio locale', r.ok && r.rows[0].n === 1, r);
await as(U.admin, `update public.platform_settings set value='true' where key='show_demo_data'`);
r = await as(U.admin, `update public.restaurants set is_active=false where id='${R2}'`);
r = await as(null, `select count(*)::int n from public.restaurants where id='${R2}'`);
check('anon non vede locale disattivato', r.ok && r.rows[0].n === 0, r);
r = await as(null, `select count(*)::int n from public.menus where restaurant_id='${R2}'`);
check('anon non vede menu di locale disattivato', r.ok && r.rows[0].n === 0, r);
r = await as(U.cust, claimSql(R2, U.cust));
check('non si rivendica un locale non pubblicato', !r.ok, r);

console.log('\n— Varie');
r = await as(null, `select public.track_event('${R3}', 'view', 'sess', 'test')`);
check('anon traccia evento', r.ok, r);
r = await as(null, `insert into public.analytics_events (restaurant_id, event_type) values ('${R3}', 'view')`);
check('anon NON inserisce eventi diretti', !r.ok, r);
r = await as(U.admin, `select public.admin_dashboard_stats() s`);
check('Admin legge KPI', r.ok && r.rows[0].s.reports_open >= 1, r);
r = await as(U.cust, `select public.admin_dashboard_stats() s`);
check('cliente NON legge KPI', !r.ok, r);
r = await as(null, `select * from public.restaurants_nearby(40.4644, 17.247, 10)`);
check('ricerca per distanza', r.ok && r.rows.length > 0, { n: r.rows?.length, err: r.err });

console.log('\n— Fase 3: geo, eventi, correzioni posizione');
const R6 = R(6), R7 = R(7);
await db.exec(`update public.restaurants set owner_id='${U.owner}' where id='${R6}'`);
const pos0 = await q1(`select latitude, longitude, address from public.restaurants where id='${R6}'`);
r = await as(U.owner, `update public.restaurants set latitude=latitude+0.0005 where id='${R6}'`);
check('titolare: piccola correzione posizione (~55 m) consentita', r.ok && (await q1(`select latitude from public.restaurants where id='${R6}'`)).latitude !== pos0.latitude, r);
r = await as(U.owner, `update public.restaurants set latitude=latitude+0.05, address='Via Nuova 1' where id='${R6}'`);
const pos1 = await q1(`select latitude, address from public.restaurants where id='${R6}'`);
check('titolare: spostamento > 300 m e cambio indirizzo bloccati', Math.abs(pos1.latitude - pos0.latitude) < 0.001 && pos1.address === pos0.address, pos1);
r = await as(U.owner, `update public.restaurants set latitude=null, longitude=null where id='${R6}'`);
check('titolare: non può cancellare le coordinate', (await q1(`select latitude from public.restaurants where id='${R6}'`)).latitude !== null, r);
r = await as(U.owner, `insert into public.restaurant_change_requests (restaurant_id, user_id, payload, note) values ('${R6}', '${U.owner}', '{"address":"Via Nuova 1","latitude":40.62,"longitude":17.05}', 'Ci siamo trasferiti') returning id`);
check('titolare propone correzione posizione', r.ok, r);
const crId = r.rows?.[0]?.id;
r = await as(U.cust, `insert into public.restaurant_change_requests (restaurant_id, user_id, payload) values ('${R6}', '${U.cust}', '{}')`);
check('non titolare NON propone correzioni', !r.ok, r);
r = await as(U.owner, `insert into public.restaurant_change_requests (restaurant_id, user_id, payload, status) values ('${R6}', '${U.owner}', '{}', 'approved')`);
check('non si auto-approva una correzione', !r.ok, r);
r = await as(U.cust, `select count(*)::int n from public.restaurant_change_requests`);
check('altri non leggono le correzioni', r.ok && r.rows[0].n === 0, r);
r = await as(U.owner, `select public.review_change_request('${crId}', true)`);
check('titolare non approva la propria correzione', !r.ok, r);
r = await as(U.admin, `select public.review_change_request('${crId}', true, 'ok')`);
const pos2 = await q1(`select latitude, longitude, address from public.restaurants where id='${R6}'`);
check('Admin approva: posizione e indirizzo aggiornati', r.ok && pos2.latitude === 40.62 && pos2.address === 'Via Nuova 1', { r, pos2 });
r = await as(U.admin, `update public.restaurants set latitude=40.0 where id='${R7}'`);
check('Admin sposta liberamente', r.ok && (await q1(`select latitude from public.restaurants where id='${R7}'`)).latitude === 40, r);
r = await as(U.admin, `insert into public.restaurants (name, slug, city_id, latitude) values ('Solo lat', 'solo-lat', '${TARANTO}', 40.1)`);
check('coordinate: non si salva lat senza lng', !r.ok, r);
r = await as(null, `select restaurant_id, distance_km from public.nearby_restaurants(40.4644, 17.247, 3)`);
check('nearby_restaurants: risultati ordinati per distanza ≤ raggio', r.ok && r.rows.length > 0 && r.rows.every((x, i, a) => x.distance_km <= 3 && (i === 0 || a[i - 1].distance_km <= x.distance_km)), r);
r = await as(null, `select count(*)::int n from public.nearby_restaurants(40.4644, 17.247, 1000)`);
check('nearby_restaurants: raggio limitato lato server (≤ 200 km)', r.ok, r);
r = await as(null, `select public.track_app_event('near_me_search', null, 's1', 'map', '{"radius_km":10,"lat":40.46,"lng":17.24,"user_location":"x"}')`);
check('anon traccia evento app', r.ok, r);
const ev = await q1(`select metadata from public.app_events order by id desc limit 1`);
check('evento app: coordinate rimosse dai metadati', ev && ev.metadata.radius_km === 10 && !('lat' in ev.metadata) && !('lng' in ev.metadata) && !('user_location' in ev.metadata), ev);
r = await as(null, `select public.track_app_event('hack_event')`);
check('evento app sconosciuto ignorato senza errori', r.ok && (await q1(`select count(*)::int n from public.app_events where event_type='hack_event'`)).n === 0, r);
r = await as(null, `select count(*)::int n from public.app_events`);
check('anon non legge gli eventi', !r.ok || r.rows[0].n === 0, r);
r = await as(U.admin, `select public.admin_dashboard_stats() s`);
check('KPI: coordinate mancanti e correzioni in attesa', r.ok && 'restaurants_no_coords' in r.rows[0].s && 'change_requests_pending' in r.rows[0].s, r);


console.log('\n— Fase 4: piani e feature flag');
const R5 = R(5), R8 = R(8);
await as(U.admin, `select public.admin_transfer_ownership('${R1}', '${U.owner}')`);
r = await as(null, `select count(*)::int n from public.plan_features`);
check('anon legge le feature dei piani', r.ok && r.rows[0].n >= 60, r);
r = await as(U.owner, `update public.plan_features set enabled=true where plan_code='free'`);
check('ristoratore NON modifica le feature dei piani', !r.ok || r.affected === 0, r);
r = await as(U.owner, `update public.subscription_plans set monthly_price=0 where code='premium'`);
check('ristoratore NON cambia i prezzi', !r.ok || r.affected === 0, r);
r = await as(U.owner, `update public.restaurants set subscription_plan='top' where id='${R4}'`);
check('ristoratore NON si cambia piano', (await q1(`select subscription_plan from public.restaurants where id='${R4}'`)).subscription_plan === 'free', r);
r = await as(U.admin, `update public.plan_features set limit_value=3 where plan_code='business' and feature_key='max_active_offers'`);
check('Admin modifica un limite (jsonb sincronizzato)', r.ok && (await q1(`select features->>'max_active_offers' v from public.subscription_plans where code='business'`)).v === '3', r);
await as(U.admin, `update public.plan_features set limit_value=2 where plan_code='business' and feature_key='max_active_offers'`);

console.log('\n— Fase 4: menu digitale');
r = await as(U.owner, `insert into public.menus (restaurant_id, name) values ('${R4}', 'Menu free')`);
check('piano Free: menu self-service bloccato (PLAN_FEATURE)', !r.ok && /PLAN_FEATURE:menu_enabled/.test(r.err), r);
const cat1 = (await q1(`select id from public.menu_categories where restaurant_id='${R1}' order by sort_order limit 1`)).id;
r = await as(U.owner, `insert into public.menu_items (menu_category_id, name, price, allergens, ingredients, is_vegan) values ('${cat1}', 'Test allergeni', 5, '{Glutine,pesce,xyz,4}', '{" riso ",""}', true) returning id, allergens, ingredients, is_vegetarian`);
check('allergeni normalizzati (nomi IT, numeri UE, sconosciuti scartati)', r.ok && JSON.stringify([...r.rows[0].allergens].sort()) === '["fish","gluten"]' && r.rows[0].ingredients.length === 1 && r.rows[0].is_vegetarian === true, r);
const itemT = r.rows?.[0]?.id;
r = await as(U.owner, `insert into public.menu_item_variants (menu_item_id, name, price) values ('${itemT}', '8 pezzi', 9) returning restaurant_id`);
check('variante con restaurant_id derivato', r.ok && r.rows[0].restaurant_id === R1, r);
const itemR2 = (await q1(`select id from public.menu_items where restaurant_id='${R2}' limit 1`)).id;
r = await as(U.owner, `insert into public.menu_item_addons (menu_item_id, name, price) values ('${itemR2}', 'Extra', 1)`);
check('NON aggiunge extra ai piatti altrui', !r.ok, r);
r = await as(null, `select count(*)::int n from public.menu_item_variants where restaurant_id='${R1}'`);
check('anon legge le varianti del menu pubblico', r.ok && r.rows[0].n > 0, r);
const hiddenMenu = (await q1(`select m.id from public.menus m where m.restaurant_id='${R1}' and m.menu_type='drinks'`)).id;
await as(U.owner, `update public.menus set is_public=false where id='${hiddenMenu}'`);
r = await as(null, `select count(*)::int n from public.menu_items i join public.menu_categories c on c.id=i.menu_category_id where c.menu_id='${hiddenMenu}'`);
check('menu nascosto: piatti invisibili al pubblico', r.ok && r.rows[0].n === 0, r);
r = await as(U.owner, `select count(*)::int n from public.menu_items i join public.menu_categories c on c.id=i.menu_category_id where c.menu_id='${hiddenMenu}'`);
check('menu nascosto: visibile al titolare', r.ok && r.rows[0].n > 0, r);
await as(U.owner, `update public.menus set valid_until=current_date - 1, is_public=true where id='${hiddenMenu}'`);
r = await as(null, `select count(*)::int n from public.menus where id='${hiddenMenu}'`);
check('menu scaduto (valid_until) non pubblico', r.ok && r.rows[0].n === 0, r);
r = await as(U.owner, `select public.duplicate_menu('${hiddenMenu}') id`);
check('duplica menu (copia nascosta)', r.ok && !!r.rows[0].id && (await q1(`select is_public from public.menus where id='${r.rows[0].id}'`)).is_public === false, r);
r = await as(U.cust, `select public.duplicate_menu('${hiddenMenu}')`);
check('cliente NON duplica menu', !r.ok, r);
r = await as(U.owner, `select public.duplicate_menu_item('${itemT}') id`);
check('duplica piatto con varianti', r.ok && (await q1(`select count(*)::int n from public.menu_item_variants where menu_item_id='${r.rows[0].id}'`)).n === 1, r);
const cats = (await db.query(`select id from public.menu_categories where restaurant_id='${R1}' order by sort_order`)).rows.map((x) => x.id);
r = await as(U.owner, `select public.reorder_menu_rows('menu_categories', array['${[...cats].reverse().join("','")}']::uuid[])`);
check('riordino in un\'unica chiamata', r.ok && (await q1(`select sort_order from public.menu_categories where id='${cats[cats.length - 1]}'`)).sort_order === 0, r);
r = await as(U.cust, `select public.reorder_menu_rows('menu_categories', array['${cats[0]}']::uuid[])`);
check('cliente NON riordina', !r.ok, r);
r = await as(U.owner, `select public.import_menu('${R1}', '[{"menu":"Import test","category":"Nuovi","name":"Takoyaki","price":"6.5","allergens":["molluschi","glutine"],"variants":[{"name":"6 pz","price":6.5}]},{"menu":"Import test","category":"Nuovi","name":"Onigiri","price":3}]'::jsonb) res`);
check('import menu JSON (menu e categoria creati)', r.ok && r.rows[0].res.items === 2 && r.rows[0].res.menus === 1, r);
r = await as(U.owner, `select public.import_menu('${R1}', '[{"category":"X","name":"Ok","price":1},{"category":"X","name":"","price":1}]'::jsonb)`);
check('import con riga non valida: tutto annullato', !r.ok && (await q1(`select count(*)::int n from public.menu_items where restaurant_id='${R1}' and name='Ok'`)).n === 0, r);
await as(U.admin, `select public.admin_grant_plan('${R4}', 'business')`);
await as(U.admin, `update public.plan_features set limit_value=1 where plan_code='business' and feature_key='max_menu_items'`);
r = await as(U.owner, `select public.import_menu('${R4}', '[{"category":"X","name":"Troppi","price":1}]'::jsonb)`);
check('limite piatti del piano (PLAN_LIMIT)', !r.ok && /PLAN_LIMIT:max_menu_items/.test(r.err), r);
await as(U.admin, `update public.plan_features set limit_value=150 where plan_code='business' and feature_key='max_menu_items'`);
r = await as(U.owner, `insert into public.restaurant_images (restaurant_id, url, sort_order) values ('${R4}', 'https://x.it/a.jpg', 99)`);
check('Business: foto entro il limite', r.ok, r);

console.log('\n— Fase 4: offerte');
r = await as(U.owner, `insert into public.offers (restaurant_id, title, redemptions_count, is_featured) values ('${R4}', 'Promo 1', 50, true) returning redemptions_count, is_featured`);
check('Business: offerta creata, contatore e "in evidenza" protetti', r.ok && r.rows[0].redemptions_count === 0 && r.rows[0].is_featured === false, r);
r = await as(U.owner, `insert into public.offers (restaurant_id, title) values ('${R4}', 'Promo 2')`);
check('Business: seconda offerta attiva', r.ok, r);
r = await as(U.owner, `insert into public.offers (restaurant_id, title) values ('${R4}', 'Promo 3')`);
check('Business: terza offerta attiva oltre il limite (PLAN_LIMIT)', !r.ok && /PLAN_LIMIT:max_active_offers/.test(r.err), r);
r = await as(U.owner, `insert into public.offers (restaurant_id, title, is_active) values ('${R4}', 'Promo bozza', false)`);
check('offerta non attiva: non conta nel limite', r.ok, r);
r = await as(U.owner, `insert into public.offers (restaurant_id, title, is_featured) values ('${R1}', 'Top in evidenza', true) returning is_featured`);
check('Top: offerta in evidenza consentita', r.ok && r.rows[0].is_featured === true, r);
r = await as(null, `select count(*)::int n from public.offers where restaurant_id='${R4}'`);
check('anon vede le offerte del piano Business', r.ok && r.rows[0].n === 2, r);
await as(U.admin, `select public.admin_grant_plan('${R4}', 'free')`);
r = await as(null, `select count(*)::int n from public.offers where restaurant_id='${R4}'`);
check('downgrade a Free: offerte nascoste al pubblico', r.ok && r.rows[0].n === 0, r);
r = await as(U.owner, `insert into public.coupons (restaurant_id, code, title) values ('${R4}', 'FREE10', 'X')`);
check('Free: coupon bloccati (PLAN_FEATURE)', !r.ok && /PLAN_FEATURE:coupons_enabled/.test(r.err), r);

console.log('\n— Fase 4: coupon');
const CP1 = 'f1000000-0000-4000-8000-000000000001', CP2 = 'f1000000-0000-4000-8000-000000000002';
r = await as(null, `select public.claim_coupon('${CP1}') res`);
check('anon senza email: richiesta email', !r.ok && /email/i.test(r.err), r);
r = await as(null, `select public.claim_coupon('${CP1}', 'Ospite@Test.it') res`);
check('anon con email ottiene un codice univoco (PREFISSO-XXXX)', r.ok && /^KAIZEN10-[A-Z2-9]{4}$/.test(r.rows[0].res.claim_code), r);
const guestCode = r.rows?.[0]?.res?.claim_code;
r = await as(null, `select public.claim_coupon('${CP1}', 'ospite@test.it')`);
check('stessa email: niente secondo codice', !r.ok && /già ottenuto/.test(r.err), r);
r = await as(U.cust, `select public.claim_coupon('${CP1}') res`);
check('cliente registrato ottiene il coupon', r.ok && r.rows[0].res.already === false, r);
const custCode = r.rows?.[0]?.res?.claim_code;
r = await as(U.cust, `select public.claim_coupon('${CP1}') res`);
check('secondo tentativo: restituisce lo stesso codice', r.ok && r.rows[0].res.already === true && r.rows[0].res.claim_code === custCode, r);
r = await as(null, `insert into public.coupon_claims (coupon_id, restaurant_id, email, claim_code) values ('${CP1}', '${R1}', 'x@y.it', 'KAIZEN10-HACK')`);
check('nessun claim diretto (solo RPC)', !r.ok, r);
r = await as(null, `select count(*)::int n from public.coupon_claims`);
check('anon non legge i coupon ottenuti', !r.ok || r.rows[0].n === 0, r);
r = await as(U.cust, `select count(*)::int n from public.coupon_claims`);
check('cliente vede solo i propri coupon', r.ok && r.rows[0].n === 1, r);
r = await as(U.owner, `select count(*)::int n from public.coupon_claims where restaurant_id='${R1}'`);
check('ristoratore vede i coupon del proprio locale', r.ok && r.rows[0].n >= 3, r);
r = await as(U.owner, `select count(*)::int n from public.coupon_claims where restaurant_id='${R5}'`);
check('…ma non quelli di altri locali', r.ok && r.rows[0].n === 0, r);
r = await as(U.cust, `select public.redeem_coupon('${R1}', '${custCode}')`);
check('cliente NON valida coupon', !r.ok, r);
r = await as(U.owner, `select public.check_coupon_claim('${R1}', '${guestCode.toLowerCase()}') res`);
check('verifica codice (anche minuscolo)', r.ok && r.rows[0].res.found && r.rows[0].res.status === 'claimed', r);
r = await as(U.owner, `select public.redeem_coupon('${R1}', '${guestCode}') res`);
check('ristoratore segna il coupon come utilizzato', r.ok && r.rows[0].res.status === 'redeemed', r);
r = await as(U.owner, `select public.redeem_coupon('${R1}', '${guestCode}')`);
check('coupon già utilizzato: rifiutato', !r.ok && /già utilizzato/.test(r.err), r);
r = await as(U.owner, `select public.redeem_coupon('${R4}', '${custCode}')`);
check('codice di un altro locale: non trovato', !r.ok, r);
check('contatore utilizzi aggiornato', (await q1(`select redemptions_count from public.coupons where id='${CP1}'`)).redemptions_count >= 1);
await as(U.admin, `update public.coupons set max_redemptions = claims_count where id='${CP1}'`);
r = await as(null, `select public.claim_coupon('${CP1}', 'altro@test.it')`);
check('coupon esaurito (max_redemptions)', !r.ok && /esaurito/.test(r.err), r);
await as(U.admin, `update public.coupons set valid_until = now() - interval '1 minute' where id='${CP1}'`);
r = await as(U.owner, `select public.redeem_coupon('${R1}', '${custCode}')`);
const chk = await as(U.owner, `select public.check_coupon_claim('${R1}', '${custCode}') res`);
check('coupon scaduto: non validabile (stato "expired")', !r.ok && /scaduto/.test(r.err) && chk.rows?.[0]?.res.status === 'expired', { r, chk });
r = await as(U.owner, `update public.coupons set redemptions_count = 999 where id='${CP1}'`);
check('contatori non modificabili con UPDATE diretto', (await q1(`select redemptions_count from public.coupons where id='${CP1}'`)).redemptions_count < 999, r);
r = await as(null, `select public.claim_coupon('${CP2}', 'x@test.it')`);
check('coupon di locale Premium: ottenibile', r.ok, r);
await as(U.admin, `select public.admin_grant_plan('${R5}', 'business')`);
r = await as(null, `select public.claim_coupon('${CP2}', 'y@test.it')`);
check('piano senza coupon: non ottenibile', !r.ok, r);
await as(U.admin, `select public.admin_grant_plan('${R5}', 'premium')`);

console.log('\n— Fase 4: prenotazioni');
async function nextOpenDay(rid, from = 1) {
  for (let d = from; d < from + 10; d++) {
    const x = await as(null, `select public.get_reservation_availability('${rid}', current_date + ${d}, 2) a`);
    if (x.ok && x.rows[0].a.ok && x.rows[0].a.slots.some((s) => s.status === 'available')) return { d, slots: x.rows[0].a.slots };
  }
  return null;
}
const dayR5 = await nextOpenDay(R5, 2);
check('disponibilità pubblica per data e persone', !!dayR5 && dayR5.slots.length > 0, dayR5);
const t5 = dayR5.slots.find((s) => s.status === 'available').time;
const resSql = (rid, d, t, email, party = 2, extra = '') =>
  `select public.create_reservation('${rid}', current_date + ${d}, '${t}', ${party}, 'Mario', 'Rossi', '${email}', '+39 333 1234567'${extra}) res`;
r = await as(null, resSql(R5, dayR5.d, t5, 'mario@test.it'));
check('ospite prenota senza account → in attesa (auto_confirm off)', r.ok && r.rows[0].res.status === 'pending' && /^ASF-[A-Z2-9]{5}$/.test(r.rows[0].res.code), r);
const res1 = r.rows?.[0]?.res;
r = await as(null, resSql(R5, dayR5.d, t5, 'mario@test.it'));
check('stessa email, stesso giorno: niente doppione', !r.ok && /già una prenotazione/.test(r.err), r);
r = await as(null, resSql(R5, dayR5.d, t5, 'non-una-email'));
check('email non valida: rifiutata lato server', !r.ok && /email/.test(r.err), r);
r = await as(null, resSql(R5, dayR5.d, t5, 'big@test.it', 40));
check('gruppo oltre il massimo: rifiutato', !r.ok && /gruppi/.test(r.err), r);
r = await as(null, resSql(R5, -1, '20:00', 'past@test.it'));
check('data passata: rifiutata', !r.ok, r);
r = await as(null, resSql(R5, 400, '20:00', 'far@test.it'));
check('oltre i giorni di anticipo: rifiutata', !r.ok, r);
r = await as(null, resSql(R5, dayR5.d, '03:17', 'odd@test.it'));
check('orario fuori dalle fasce: rifiutato', !r.ok, r);
r = await as(null, `select public.get_reservation_availability('${R5}', current_date + 9, 2) a`);
check('chiusura straordinaria: data non prenotabile', r.ok && r.rows[0].a.ok === false && /chiuso/.test(r.rows[0].a.reason), r);
const dayR1 = await nextOpenDay(R1, 1);
r = await as(U.cust, resSql(R1, dayR1.d, dayR1.slots.find((s) => s.status === 'available').time, 'cliente@test.it'));
check('cliente registrato prenota → confermata (auto_confirm on)', r.ok && r.rows[0].res.status === 'confirmed', r);
const resCust = r.rows?.[0]?.res;
// Capienza: 1 prenotazione per orario su Hanami
await as(U.admin, `update public.reservation_slots set max_reservations = 1 where restaurant_id='${R8}'`);
const dayR8 = await nextOpenDay(R8, 1);
const t8 = dayR8.slots.find((s) => s.status === 'available').time;
r = await as(null, resSql(R8, dayR8.d, t8, 'a1@test.it'));
check('prenotazione su orario libero', r.ok, r);
r = await as(null, resSql(R8, dayR8.d, t8, 'a2@test.it'));
check('niente overbooking oltre la configurazione', !r.ok && /non è più disponibile/.test(r.err), r);
r = await as(null, `select public.get_reservation_availability('${R8}', current_date + ${dayR8.d}, 2) a`);
check('orario pieno segnato come "full"', r.ok && r.rows[0].a.slots.find((s) => s.time === t8).status === 'full', r);
await as(U.admin, `update public.reservation_slots set max_guests = 3, max_reservations = null where restaurant_id='${R8}'`);
r = await as(null, `select public.get_reservation_availability('${R8}', current_date + ${dayR8.d}, 2) a`);
check('limite coperti per fascia rispettato', r.ok && r.rows[0].a.slots.filter((s) => s.status === 'available').length < dayR8.slots.filter((s) => s.status === 'available').length, r);
r = await as(null, `select public.get_reservation_availability('${R4}', current_date + 1, 2) a`);
check('locale senza prenotazioni: messaggio chiaro', r.ok && r.rows[0].a.ok === false, r);
r = await as(U.owner, `insert into public.reservation_settings (restaurant_id, reservation_enabled) values ('${R4}', true)`);
check('Free: attivazione prenotazioni bloccata (PLAN_FEATURE)', !r.ok && /PLAN_FEATURE:reservations_enabled/.test(r.err), r);
r = await as(null, `insert into public.reservations (restaurant_id, guest_name, guest_surname, guest_email, guest_phone, reservation_date, reservation_time, party_size, confirmation_code) values ('${R5}', 'a','b','a@b.it','3331234567', current_date+1, '20:00', 2, 'ASF-HACK1')`);
check('nessun insert diretto di prenotazioni', !r.ok, r);
r = await as(null, `select count(*)::int n from public.reservations`);
check('pubblico NON enumera le prenotazioni', !r.ok || r.rows[0].n === 0, r);
r = await as(U.cust, `select count(*)::int n from public.reservations`);
check('cliente vede solo le proprie', r.ok && r.rows[0].n === 1, r);
r = await as(U.owner, `select count(*)::int n from public.reservations where restaurant_id='${R1}'`);
check('ristoratore vede le prenotazioni del proprio locale', r.ok && r.rows[0].n >= 3, r);
r = await as(U.owner, `select count(*)::int n from public.reservations where restaurant_id='${R5}'`);
check('…e non quelle degli altri', r.ok && r.rows[0].n === 0, r);
r = await as(U.owner, `update public.reservations set status='confirmed' where restaurant_id='${R1}'`);
check('nessun update diretto dello stato', !r.ok || r.affected === 0, r);
await as(U.admin, `select public.admin_set_member('${R5}', '${U.mgr}', 'manager')`);
r = await as(U.mgr, `select public.set_reservation_status('${res1.id}', 'confirmed')`);
check('gestore conferma la prenotazione', r.ok && (await q1(`select status, confirmed_at from public.reservations where id='${res1.id}'`)).confirmed_at !== null, r);
r = await as(U.mgr, `select public.set_reservation_status('${res1.id}', 'completed')`);
check('non si segna "completata" prima del giorno', !r.ok, r);
r = await as(U.mgr, `select public.set_reservation_status('${res1.id}', 'pending')`);
check('transizione di stato non valida rifiutata', !r.ok, r);
r = await as(U.cust, `select public.set_reservation_status('${resCust.id}', 'confirmed')`);
check('cliente NON conferma', !r.ok, r);
r = await as(U.cust, `select public.set_reservation_status('${resCust.id}', 'cancelled')`);
check('cliente cancella la propria prenotazione', r.ok, r);
r = await as(null, `select public.cancel_reservation_by_code('${res1.code}', 'sbagliata@test.it')`);
check('cancellazione ospite: serve l\'email giusta', !r.ok, r);
r = await as(null, `select public.cancel_reservation_by_code('${res1.code}', 'MARIO@test.it') res`);
check('cancellazione ospite con codice + email', r.ok && r.rows[0].res.status === 'cancelled', r);
const past = (await q1(`select id from public.reservations where restaurant_id='${R5}' and status='confirmed' and reservation_date = current_date limit 1`));
r = await as(U.mgr, `select public.set_reservation_status('${past.id}', 'no_show')`);
check('no show dal giorno della prenotazione', r.ok, r);
r = await as(U.mgr, `select public.create_reservation('${R5}', current_date, '23:59', 20, 'Tel', 'Efono', 'banco@test.it', '0991234567', null, 'restaurant') res`);
check('inserimento manuale dal gestionale (confermato)', r.ok && r.rows[0].res.status === 'confirmed', r);
r = await as(null, `select public.create_reservation('${R5}', current_date + ${dayR5.d}, '${t5}', 2, 'A', 'B', 'z@test.it', '3331234567', null, 'restaurant')`);
check('ospite NON può fingersi il ristorante', !r.ok, r);
await db.exec(`insert into public.reservations (restaurant_id, guest_name, guest_surname, guest_email, guest_phone, reservation_date, reservation_time, party_size, confirmation_code, status)
  select '${R1}', 'S', 'P', 'spam@test.it', '3331111111', current_date + 30 + g, '20:00', 2, 'ASF-SP00' || g, 'cancelled' from generate_series(1, 5) g`);
r = await as(null, resSql(R8, dayR8.d, t8, 'spam@test.it'));
check('anti-abuso: troppe richieste dalla stessa email', !r.ok && /Troppe richieste/.test(r.err), r);
r = await as(null, `select * from public.restaurants_available_on(current_date + ${dayR5.d}, 2, '00:00', 10)`);
check('"Prenota per stasera": solo locali con orari liberi reali', r.ok && r.rows.length > 0 && r.rows.every((x) => x.slots_count > 0), r);

console.log('\n— Fase 4: notifiche ed email');
r = await as(U.mgr, `select count(*)::int n from public.notifications where restaurant_id='${R5}'`);
check('gestore riceve la notifica di nuova prenotazione', r.ok && r.rows[0].n >= 1, r);
r = await as(U.cust, `select count(*)::int n from public.notifications where user_id='${U.mgr}'`);
check('le notifiche sono private', r.ok && r.rows[0].n === 0, r);
r = await as(U.mgr, `select public.mark_notifications_read()`);
check('segna notifiche come lette', r.ok && (await q1(`select count(*)::int n from public.notifications where user_id='${U.mgr}' and read_at is null`)).n === 0, r);
check('email in coda (nessun provider: prenotazione non bloccata)', (await q1(`select count(*)::int n from public.email_outbox where event_type like 'reservation_%'`)).n >= 3);
r = await as(U.owner, `select count(*)::int n from public.email_outbox`);
check('coda email riservata all\'Admin', !r.ok || r.rows[0].n === 0, r);

console.log('\n— Fase 4: analytics e piani');
r = await as(U.cust, `select public.track_event('${R3}', 'view', 's1', 'test')`);
const ev4 = await q1(`select event_type::text t, user_id from public.analytics_events order by id desc limit 1`);
check('nomi Fase 1 rimappati (view → restaurant_view), nessun user_id', r.ok && ev4.t === 'restaurant_view' && ev4.user_id === null, ev4);
r = await as(null, `select public.track_event('${R1}', 'coupon_redeem', 's1', 'hack')`);
check('conversioni non falsificabili dal client', r.ok && (await q1(`select count(*)::int n from public.analytics_events where source='hack'`)).n === 0, r);
r = await as(null, `select public.track_app_event('map_open', null, 's2', 'map')`);
check('map_open → analytics map_view', r.ok && (await q1(`select count(*)::int n from public.analytics_events where event_type='map_view'`)).n >= 1, r);
r = await as(U.owner, `select public.restaurant_analytics('${R1}', 30) a`);
check('statistiche del proprio locale (Top: avanzate)', r.ok && r.rows[0].a.advanced === true && r.rows[0].a.coupons.claimed >= 1 && r.rows[0].a.daily.length === 30, r);
r = await as(U.owner, `select public.restaurant_analytics('${R4}', 30)`);
check('Free: statistiche non incluse (PLAN_FEATURE)', !r.ok && /PLAN_FEATURE:analytics_enabled/.test(r.err), r);
r = await as(U.cust, `select public.restaurant_analytics('${R1}', 30)`);
check('cliente NON legge statistiche', !r.ok, r);
r = await as(U.owner, `insert into public.plan_upgrade_requests (restaurant_id, plan_code) values ('${R4}', 'premium')`);
check('lista d\'attesa upgrade (piano Premium)', r.ok, r);
r = await as(U.owner, `insert into public.plan_upgrade_requests (restaurant_id, plan_code) values ('${R4}', 'premium')`);
check('una sola richiesta aperta per piano', !r.ok, r);
r = await as(U.owner, `insert into public.plan_upgrade_requests (restaurant_id, plan_code) values ('${R2}', 'premium')`);
check('NON richiede upgrade per locali altrui', !r.ok, r);
r = await as(U.admin, `select count(*)::int n from public.notifications where type='plan_upgrade'`);
check('Admin notificato della richiesta', r.ok && r.rows[0].n >= 1, r);
r = await as(U.admin, `select public.admin_dashboard_stats() s`);
check('KPI Fase 4 (prenotazioni, coupon, upgrade)', r.ok && 'reservations_30d' in r.rows[0].s && 'coupons_redeemed_30d' in r.rows[0].s && r.rows[0].s.upgrade_requests_open >= 1, r);

// ════════════════════════════════════════════════════════════════════
//  FASE 5 — abbonamenti, Stripe, promozioni, sponsorizzazioni, ricavi
// ════════════════════════════════════════════════════════════════════
const svc = (sql, params = []) => as(null, sql, params, 'service_role');
const plan = async (rid) => (await q1(`select public.restaurant_effective_plan('${rid}') p, (select subscription_plan from public.restaurants where id='${rid}') c`));
const subPayload = (o) => JSON.stringify({
  stripe_subscription_id: 'sub_TestR4', restaurant_id: R4, customer_id: 'cus_TestOwner', status: 'trialing', price_id: 'price_PremiumMonth',
  interval: 'month', unit_amount: 5990, currency: 'EUR', trial_start: new Date().toISOString(),
  trial_end: new Date(Date.now() + 30 * 864e5).toISOString(), current_period_start: new Date().toISOString(),
  current_period_end: new Date(Date.now() + 30 * 864e5).toISOString(), cancel_at_period_end: false, environment: 'test',
  pm_brand: 'visa', pm_last4: '4242', ...o,
});
const upsert = (o) => svc(`select public.billing_upsert_subscription($1::jsonb) r`, [subPayload(o)]);
const activity = async (event) => (await q1(`select count(*)::int n from public.billing_activity where restaurant_id='${R4}' and event='${event}'`)).n;

console.log('\n— Fase 5: piani e RLS fatturazione');
await as(U.admin, `select public.admin_grant_plan('${R4}', 'free')`);
r = await as(U.admin, `insert into public.subscription_plans (code, name, monthly_price, is_active, sort_order) values ('legacy', 'Legacy', 10, false, 99)`);
r = await as(null, `select count(*)::int n from public.subscription_plans where code='legacy'`);
check('pubblico: solo piani attivi', r.ok && r.rows[0].n === 0, r);
r = await as(null, `select count(*)::int n from public.plans`);
check('vista plans leggibile (piani attivi)', r.ok && r.rows[0].n === 4, r);
await db.exec(`delete from public.subscription_plans where code='legacy'`);
r = await as(U.admin, `update public.subscription_plans set stripe_monthly_price_id='price_PremiumMonth', stripe_yearly_price_id='price_PremiumYear' where code='premium'`);
await as(U.admin, `update public.subscription_plans set stripe_monthly_price_id='price_BusinessMonth', stripe_yearly_price_id='price_BusinessYear' where code='business'`);
await as(U.admin, `update public.subscription_plans set stripe_monthly_price_id='price_TopMonth' where code='top'`);
check('Admin configura i Price ID nel DB', r.ok, r);
r = await as(U.admin, `update public.subscription_plans set stripe_monthly_price_id='sk_live_abc' where code='top'`);
check('Price ID con formato non valido rifiutato', !r.ok, r);
r = await as(U.admin, `update public.restaurants set subscription_plan='top' where id='${R4}'`);
check('piano non impostabile a mano nemmeno dall\'Admin (deriva dagli abbonamenti)', (await plan(R4)).c === 'free', r);
r = await as(U.owner, `insert into public.subscriptions (restaurant_id, plan_code, status, source) values ('${R4}', 'top', 'active', 'manual')`);
check('ristoratore NON crea abbonamenti', !r.ok, r);
r = await as(null, `select count(*)::int n from public.subscriptions`);
check('anon NON legge abbonamenti', !r.ok || r.rows[0].n === 0, r);
r = await as(U.cust, `select count(*)::int n from public.subscriptions`);
check('cliente NON legge abbonamenti altrui', r.ok && r.rows[0].n === 0, r);

r = await as(U.owner, `insert into public.billing_accounts (owner_user_id, business_name, vat_number, stripe_customer_id, billing_email) values ('${U.owner}', 'Ramen Srl', 'IT 01234567890', 'cus_Hacked', 'fatture@ramen.it') returning stripe_customer_id, vat_number`);
check('dati fatturazione: ID Stripe ignorato, P.IVA normalizzata', r.ok && r.rows[0].stripe_customer_id === null && r.rows[0].vat_number === 'IT01234567890', r);
r = await as(U.owner, `update public.billing_accounts set stripe_customer_id='cus_Hacked' where owner_user_id='${U.owner}'`);
check('ristoratore NON scrive lo Stripe customer ID', !r.ok, r);
r = await as(U.owner, `update public.billing_accounts set pec='ramen@pec.it', recipient_code='abc1234' where owner_user_id='${U.owner}' returning recipient_code`);
check('ristoratore aggiorna PEC e codice destinatario', r.ok && r.rows[0].recipient_code === 'ABC1234', r);
r = await as(U.cust, `select count(*)::int n from public.billing_accounts`);
check('dati fatturazione privati (cliente non li vede)', r.ok && r.rows[0].n === 0, r);
r = await as(null, `select count(*)::int n from public.billing_accounts`);
check('dati fatturazione privati (anon)', !r.ok || r.rows[0].n === 0, r);

console.log('\n— Fase 5: RPC server-side');
r = await as(U.owner, `select public.billing_upsert_subscription($1::jsonb)`, [subPayload({})]);
check('ristoratore NON chiama le RPC del backend (upsert)', !r.ok, r);
r = await as(U.owner, `select public.billing_checkout_context('${U.owner}', '${R4}', 'premium', 'month', 'test')`);
check('ristoratore NON chiama le RPC del backend (checkout)', !r.ok, r);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R4}', 'premium', 'month', 'test') c`);
const ck = r.rows?.[0]?.c;
check('checkout: prezzo dal DB, prova 30 giorni, account creato', r.ok && ck.ok && ck.plan.price_id === 'price_PremiumMonth' && ck.trial_days === 30 && !!ck.account.id, r);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R4}', 'top', 'year', 'test') c`);
check('checkout: prezzo non configurato → PRICE_NOT_CONFIGURED', r.rows?.[0]?.c.error === 'PRICE_NOT_CONFIGURED', r);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R4}', 'free', 'month', 'test') c`);
check('checkout: piano Free non acquistabile', r.rows?.[0]?.c.error === 'INVALID_PLAN', r);
r = await svc(`select public.billing_checkout_context('${U.cust}', '${R4}', 'premium', 'month', 'test') c`);
check('checkout: utente non titolare → FORBIDDEN', r.rows?.[0]?.c.error === 'FORBIDDEN', r);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R2}', 'premium', 'month', 'test') c`);
check('checkout: ristorante altrui → FORBIDDEN', r.rows?.[0]?.c.error === 'FORBIDDEN', r);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R4}', 'premium', 'week', 'test') c`);
check('checkout: intervallo non valido', r.rows?.[0]?.c.error === 'INVALID_INTERVAL', r);
r = await svc(`select public.billing_rate_check('${U.owner}', 'checkout', 2, 600) a, public.billing_rate_check('${U.owner}', 'checkout', 2, 600) b, public.billing_rate_check('${U.owner}', 'checkout', 2, 600) c`);
check('rate limit sulle azioni di fatturazione', r.ok && r.rows[0].a && r.rows[0].b && !r.rows[0].c, r);

console.log('\n— Fase 5: ciclo di vita abbonamento (webhook simulati)');
r = await upsert({});
check('trial Premium sincronizzato → piano Premium', r.ok && r.rows[0].r.ok && (await plan(R4)).p === 'premium' && (await plan(R4)).c === 'premium', r);
check('evento trial_started + registro prova', (await activity('trial_started')) === 1 && (await q1(`select count(*)::int n from public.billing_trials where restaurant_id='${R4}'`)).n === 1);
check('email "prova attivata" in coda (non bloccante)', (await q1(`select count(*)::int n from public.email_outbox where event_type='billing_trial_started'`)).n === 1);
r = await as(U.owner, `select count(*)::int n from public.notifications where type='billing'`);
check('titolare notificato', r.ok && r.rows[0].n >= 1, r);
await upsert({});
check('webhook ripetuto: nessun evento duplicato', (await activity('trial_started')) === 1);
r = await svc(`select public.billing_trial_eligible('${R4}', '${U.owner}') a, public.billing_trial_eligible('${R1}', '${U.owner}') b`);
check('una sola prova per locale e per utente', r.ok && !r.rows[0].a && !r.rows[0].b, r);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R4}', 'premium', 'month', 'test') c`);
check('nessun secondo checkout con abbonamento attivo', r.rows?.[0]?.c.error === 'ALREADY_SUBSCRIBED', r);
r = await as(U.owner, `select count(*)::int n from public.subscriptions where restaurant_id='${R4}' and source='stripe'`);
check('titolare legge il proprio abbonamento', r.ok && r.rows[0].n === 1, r);
r = await svc(`select public.billing_trial_expiring(null) n`);
const soon = new Date(Date.now() + 2 * 864e5).toISOString();
await upsert({ trial_end: soon });
r = await svc(`select public.billing_trial_expiring(null) n`);
check('avviso "prova in scadenza" una sola volta', r.ok && r.rows[0].n === 1 && (await activity('trial_expiring')) === 1 && (await svc(`select public.billing_trial_expiring(null) n`)).rows[0].n === 0, r);

await upsert({ status: 'active', trial_end: new Date(Date.now() - 1000).toISOString() });
check('fine prova → attivo (conversione registrata)', (await activity('subscription_started')) === 1 && !!(await q1(`select converted_at from public.billing_trials where restaurant_id='${R4}'`)).converted_at);
const inv = (o) => JSON.stringify({ id: 'in_Test1', subscription_id: 'sub_TestR4', customer_id: 'cus_TestOwner', number: 'AF-0001', status: 'paid', amount_due: 5990, amount_paid: 5990, currency: 'EUR', hosted_invoice_url: 'https://invoice.stripe.com/i/test', invoice_pdf: 'https://pay.stripe.com/invoice/test/pdf', environment: 'test', ...o });
r = await svc(`select public.billing_record_invoice($1::jsonb, 'invoice.paid') r`, [inv({})]);
check('fattura pagata registrata (link Stripe, nessun PDF salvato)', r.ok && (await q1(`select count(*)::int n from public.billing_invoices where restaurant_id='${R4}'`)).n === 1 && (await activity('payment_succeeded')) === 1, r);
await svc(`select public.billing_record_invoice($1::jsonb, 'invoice.paid') r`, [inv({})]);
check('fattura ripetuta: nessun doppio "pagamento riuscito"', (await activity('payment_succeeded')) === 1);
r = await as(U.owner, `select count(*)::int n from public.billing_invoices`);
check('titolare vede le proprie fatture', r.ok && r.rows[0].n === 1, r);
r = await as(U.cust, `select count(*)::int n from public.billing_invoices`);
check('cliente NON vede fatture', r.ok && r.rows[0].n === 0, r);

r = await as(U.admin, `select public.admin_revenue_stats() s`);
let revenue = r.rows?.[0]?.s;
check('MRR reale: solo Stripe, Premium mensile = 59,90 €', r.ok && revenue.mrr_cents === 5990 && revenue.arr_cents === 71880 && revenue.paying_customers === 1, revenue);
check('MRR: concessioni Admin/demo non conteggiate', r.ok && revenue.manual_active >= 1 && revenue.mrr_series.length === 12 && revenue.mrr_series[11].mrr_cents === 5990, revenue);
r = await as(U.owner, `select public.admin_revenue_stats()`);
check('ricavi riservati all\'Admin', !r.ok, r);

// Pagamento fallito → tolleranza → Free → recupero
await upsert({ status: 'past_due' });
await svc(`select public.billing_record_invoice($1::jsonb, 'invoice.payment_failed')`, [inv({ id: 'in_Test2', status: 'open', amount_paid: 0 })]);
check('pagamento fallito: funzioni mantenute nel periodo di tolleranza', (await plan(R4)).p === 'premium' && (await activity('payment_failed')) === 1);
check('email "pagamento non riuscito" in coda', (await q1(`select count(*)::int n from public.email_outbox where event_type='billing_payment_failed'`)).n === 1);
await db.exec(`update public.subscriptions set payment_failed_at = now() - interval '4 days' where stripe_subscription_id='sub_TestR4'`);
r = await as(U.owner, `select public.restaurant_has_feature('${R4}', 'reservations_enabled') f`);
check('dopo la tolleranza (3 giorni): funzioni del piano Free', (await plan(R4)).p === 'free' && r.rows[0].f === false, r);
await as(U.admin, `select public.billing_refresh_plans()`);
check('cron: cache del piano allineata (Free)', (await plan(R4)).c === 'free');
await upsert({ status: 'active' });
await svc(`select public.billing_record_invoice($1::jsonb, 'invoice.paid')`, [inv({ id: 'in_Test2' })]);
check('pagamento recuperato → Premium di nuovo', (await plan(R4)).c === 'premium' && (await activity('payment_recovered')) === 1);

// Downgrade programmato, cancellazione a fine periodo, riattivazione
r = await svc(`select public.billing_set_scheduled_change('sub_TestR4', 'sub_sched_1', 'price_BusinessMonth', now() + interval '30 days')`);
r = await q1(`select scheduled_plan_code, scheduled_interval from public.subscriptions where stripe_subscription_id='sub_TestR4'`);
check('downgrade a fine periodo registrato (Premium → Business)', r.scheduled_plan_code === 'business' && r.scheduled_interval === 'month', r);
await upsert({ status: 'active', price_id: 'price_BusinessMonth', unit_amount: 2990 });
check('downgrade applicato da Stripe → Business', (await plan(R4)).c === 'business' && (await activity('subscription_downgraded')) === 1);
await upsert({ status: 'active', price_id: 'price_PremiumYear', unit_amount: 59900, interval: 'year' });
check('upgrade annuale → Premium (MRR normalizzato /12)', (await plan(R4)).c === 'premium' && (await activity('subscription_upgraded')) === 1 &&
  (await as(U.admin, `select public.admin_revenue_stats() s`)).rows[0].s.mrr_cents === 4992);
await upsert({ status: 'active', price_id: 'price_PremiumYear', interval: 'year', unit_amount: 59900, cancel_at_period_end: true });
check('cancellazione a fine periodo: evento + email, accesso mantenuto', (await activity('subscription_cancelled')) === 1 && (await plan(R4)).p === 'premium' &&
  (await q1(`select count(*)::int n from public.email_outbox where event_type='billing_subscription_cancelled'`)).n === 1);
await upsert({ status: 'active', price_id: 'price_PremiumYear', interval: 'year', unit_amount: 59900, cancel_at_period_end: false });
check('riattivazione prima della scadenza', (await activity('subscription_resumed')) === 1);
await upsert({ status: 'canceled', price_id: 'price_PremiumYear', interval: 'year', unit_amount: 59900, canceled_at: new Date().toISOString(), ended_at: new Date().toISOString() });
check('cancellato con periodo ancora pagato: accesso fino a fine periodo', (await plan(R4)).p === 'premium' && (await activity('subscription_ended')) === 1);
await upsert({ status: 'canceled', price_id: 'price_PremiumYear', interval: 'year', unit_amount: 59900, current_period_end: new Date(Date.now() - 1000).toISOString(), ended_at: new Date().toISOString() });
check('alla scadenza del periodo → Free', (await plan(R4)).p === 'free' && (await plan(R4)).c === 'free');
r = await as(U.admin, `select public.admin_revenue_stats() s`);
revenue = r.rows[0].s;
check('churned MRR del mese calcolato, MRR attuale 0', revenue.mrr_cents === 0 && revenue.churned_mrr_cents === 4992 && revenue.cancelled_30d === 1, revenue);

console.log('\n— Fase 5: ambienti test/live, piani manuali');
await upsert({ stripe_subscription_id: 'sub_TestR4b', status: 'active', trial_start: null, trial_end: null });
check('nuovo abbonamento (senza prova) → Premium', (await plan(R4)).c === 'premium');
await svc(`select public.billing_set_environment('live')`);
check('passaggio a live: gli abbonamenti di test non contano', (await plan(R4)).p === 'free' && (await plan(R4)).c === 'free');
await svc(`select public.billing_set_environment('test')`);
check('ritorno a test', (await plan(R4)).c === 'premium');
r = await as(U.admin, `select public.admin_grant_plan('${R3}', 'top', now() + interval '10 days', 'manual', 'Accordo commerciale')`);
check('Admin concede piano manuale con scadenza (nessuna finta subscription Stripe)', r.ok && (await plan(R3)).c === 'top' &&
  (await q1(`select source, stripe_subscription_id from public.subscriptions where restaurant_id='${R3}' and revoked_at is null`)).stripe_subscription_id === null);
r = await as(U.admin, `select public.admin_grant_plan('${R3}', 'top', now() - interval '1 day')`);
check('scadenza nel passato rifiutata', !r.ok, r);
await db.exec(`update public.subscriptions set expires_at = now() - interval '1 minute' where restaurant_id='${R3}' and source='manual'`);
await as(U.admin, `select public.billing_refresh_plans()`);
check('piano manuale scaduto → Free (cron)', (await plan(R3)).c === 'free');
r = await as(U.owner, `select public.admin_grant_plan('${R4}', 'top')`);
check('ristoratore NON si concede piani', !r.ok, r);

console.log('\n— Fase 5: webhook idempotenti');
r = await svc(`select public.billing_event_begin('evt_Test1', 'invoice.paid', 'test', 'in_Test1') a`);
const first = r.rows[0].a;
r = await svc(`select public.billing_event_begin('evt_Test1', 'invoice.paid', 'test', 'in_Test1') a`);
check('evento in elaborazione non viene rieseguito in parallelo', first === 'process' && r.rows[0].a === 'in_progress', r);
await svc(`select public.billing_event_finish('evt_Test1', 'processed')`);
r = await svc(`select public.billing_event_begin('evt_Test1', 'invoice.paid', 'test', 'in_Test1') a`);
check('evento già elaborato → duplicato', r.rows[0].a === 'duplicate', r);
await svc(`select public.billing_event_begin('evt_Test2', 'customer.subscription.updated', 'test', 'sub_x')`);
await svc(`select public.billing_event_finish('evt_Test2', 'failed', 'errore di prova')`);
await db.exec(`update public.stripe_events set last_attempt_at = now() - interval '5 minutes' where stripe_event_id='evt_Test2'`);
r = await svc(`select public.billing_event_begin('evt_Test2', 'customer.subscription.updated', 'test', 'sub_x') a`);
check('evento fallito: ritentato da Stripe', r.rows[0].a === 'process', r);
r = await as(U.owner, `select count(*)::int n from public.stripe_events`);
check('log webhook riservato (titolare non lo vede)', r.ok && r.rows[0].n === 0, r);
r = await as(U.admin, `select count(*)::int n from public.stripe_events`);
check('Admin vede il log webhook', r.ok && r.rows[0].n === 2, r);

console.log('\n— Fase 5: promozioni B2B');
r = await as(U.admin, `insert into public.billing_promotions (code, description, discount_type, free_days, applicable_plans, max_redemptions) values ('asia30', '30 giorni gratis', 'free_days', 60, '{premium}', 10) returning code`);
check('Admin crea promozione (codice normalizzato)', r.ok && r.rows[0].code === 'ASIA30', r);
r = await as(U.owner, `select count(*)::int n from public.billing_promotions`);
check('codici promozionali non enumerabili dai ristoratori', r.ok && r.rows[0].n === 0, r);
await db.exec(`insert into public.restaurant_members (restaurant_id, user_id, role, status) values ('${R3}', '${U.owner}', 'owner', 'active') on conflict do nothing`);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R3}', 'premium', 'month', 'test', 'Asia30') c`);
check('promo free_days → giorni di prova dal server', r.ok && r.rows[0].c.ok && r.rows[0].c.trial_days === 60 && r.rows[0].c.promotion.code === 'ASIA30', r.rows?.[0]?.c);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R3}', 'business', 'month', 'test', 'ASIA30') c`);
check('promo non valida per il piano scelto', r.rows[0].c.error === 'PROMO_INVALID', r);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R3}', 'premium', 'month', 'test', 'NONESISTE') c`);
check('codice inesistente', r.rows[0].c.error === 'PROMO_INVALID', r);
const promoId = (await q1(`select id from public.billing_promotions where code='ASIA30'`)).id;
await svc(`select public.billing_redeem_promotion('${promoId}', '${R3}', '${U.owner}', 'sub_Promo')`);
await svc(`select public.billing_redeem_promotion('${promoId}', '${R3}', '${U.owner}', 'sub_Promo')`);
r = await svc(`select public.billing_checkout_context('${U.owner}', '${R3}', 'premium', 'month', 'test', 'ASIA30') c`);
check('promo usabile una volta per locale (contatore non duplicato)', r.rows[0].c.error === 'PROMO_INVALID' && (await q1(`select redemptions_count n from public.billing_promotions where id='${promoId}'`)).n === 1, r);

console.log('\n— Fase 5: sponsorizzazioni');
r = await as(null, `select restaurant_id, placement from public.sponsored_slots('home_featured')`);
check('slot home: campagna attiva del locale sponsorizzato', r.ok && r.rows.length === 1 && r.rows[0].restaurant_id === R1, r);
r = await as(null, `select count(*)::int n from public.sponsored_slots('category_top')`);
check('bozze e campagne concluse escluse dagli slot', r.ok && r.rows[0].n === 0, r);
r = await as(null, `select count(*)::int n from public.sponsored_slots('search_top', 'massafra')`);
check('targeting per comune rispettato', r.ok && r.rows[0].n === 0, r);
r = await as(null, `select count(*)::int n from public.sponsored_campaigns`);
check('budget e spesa delle campagne non pubblici', !r.ok || r.rows[0].n === 0, r);
r = await as(U.owner, `insert into public.sponsored_campaigns (restaurant_id, name, status) values ('${R1}', 'fai da te', 'active')`);
check('ristoratore NON crea campagne (gestione Admin)', !r.ok, r);
r = await as(U.admin, `insert into public.sponsored_campaigns (restaurant_id, name, status, placement, priority) values ('${R4}', 'Test Admin', 'active', 'city_top', 50) returning id`);
check('Admin crea campagna', r.ok, r);
const cid = (await q1(`select id from public.sponsored_campaigns where restaurant_id='${R1}' and placement='home_featured'`)).id;
r = await as(null, `select public.track_sponsored_event('${cid}', 'sponsored_impression', 'home_featured', 'sess_abc12345') a, public.track_sponsored_event('${cid}', 'sponsored_impression', 'home_featured', 'sess_abc12345') b`);
check('impression deduplicata per sessione (rerender)', r.ok && r.rows[0].a === true && r.rows[0].b === false, r);
r = await as(null, `select public.track_sponsored_event('${cid}', 'sponsored_click', 'home_featured', 'sess_abc12345') a, public.track_sponsored_event('${cid}', 'sponsored_impression', 'search_top', 'sess_zzz12345') b, public.track_sponsored_event('${cid}', 'sponsored_impression', 'home_featured', 'x') c`);
check('click registrato; placement errato o sessione non valida rifiutati', r.ok && r.rows[0].a === true && r.rows[0].b === false && r.rows[0].c === false, r);
r = await as(U.owner, `select impressions::int i, clicks::int c, ctr::float ctr from public.campaign_stats('${R1}', 30) where campaign_id='${cid}'`);
check('dashboard Ads (Top): impression, click e CTR reali', r.ok && r.rows[0].i === 1 && r.rows[0].c === 1 && r.rows[0].ctr === 100, r);
r = await as(U.owner, `select * from public.campaign_stats('${R4}', 30)`);
check('dashboard Ads non inclusa nel Premium (PLAN_FEATURE)', !r.ok && /PLAN_FEATURE:sponsored_ads/.test(r.err), r);
r = await as(U.cust, `select * from public.campaign_stats(null, 30)`);
check('statistiche campagne globali solo Admin', !r.ok, r);

console.log('\n— Fase 5: onboarding');
r = await as(U.owner, `select public.restaurant_profile_completion('${R4}') c`);
const comp = r.rows?.[0]?.c;
check('completamento profilo calcolato (non manuale)', r.ok && typeof comp.profile_completion_percentage === 'number' && comp.items.length === 11, comp);
r = await as(U.cust, `select public.restaurant_profile_completion('${R4}')`);
check('completamento profilo: solo gestori', !r.ok, r);
r = await as(U.owner, `select public.request_publication('${R4}') s`);
check('richiesta pubblicazione (locale già pubblico)', r.ok && r.rows[0].s === 'already_public', r);
r = await as(U.owner, `select public.complete_onboarding('${R4}')`);
check('onboarding completato', r.ok && !!(await q1(`select onboarding_completed_at from public.restaurants where id='${R4}'`)).onboarding_completed_at, r);
r = await as(U.owner, `select public.get_billing_overview('${R4}') o`);
check('vista fatturazione del titolare (piano, fatture, attività)', r.ok && r.rows[0].o.effective_plan === 'premium' && r.rows[0].o.can_manage_billing && r.rows[0].o.invoices.length === 2, r.rows?.[0]?.o?.effective_plan);
r = await as(U.cust, `select public.get_billing_overview('${R4}')`);
check('vista fatturazione negata ai non gestori', !r.ok, r);

console.log('\n— Fase 6: AI Assistant (funzioni deterministiche)');
// Kaizen (R1): venerdì 12–15 e 19–00:30 (orario notturno)
const at = (ts) => svc(`select public.restaurant_open_status('${R1}', '${ts}'::timestamptz) s`).then((x) => x.rows?.[0]?.s);
check('aperto ora: fascia serale del venerdì', (await at('2026-10-02 20:30+02')) === 'open');
check('aperto ora: orario spezzato (chiuso alle 16)', (await at('2026-10-02 16:00+02')) === 'closed');
check('aperto ora: dopo mezzanotte sul turno del venerdì (00:15 sabato)', (await at('2026-10-03 00:15+02')) === 'open');
check('aperto ora: chiuso dopo le 00:30', (await at('2026-10-03 01:00+02')) === 'closed');
await db.exec(`insert into public.restaurant_closures (restaurant_id, date) values ('${R1}', '2026-10-09')`);
check('chiusura straordinaria → chiuso', (await at('2026-10-09 20:30+02')) === 'closed');
r = await svc(`select public.restaurant_open_in_window('${R1}', '2026-10-02', '19:00', '23:00') a, public.restaurant_open_in_window('${R1}', '2026-10-09', '19:00', '23:00') b`);
check('finestra "stasera": aperto / chiuso per chiusura', r.ok && r.rows[0].a === 'open' && r.rows[0].b === 'closed', r);
await db.exec(`insert into public.restaurants (id, name, slug, city_id, is_active, average_price) values ('e0000000-0000-4000-8000-0000000000f1', 'Senza Orari', 'senza-orari-test', '${TARANTO}', true, null)`);
r = await as(null, `select public.restaurant_open_status('e0000000-0000-4000-8000-0000000000f1') s`);
check('senza orari → unknown (anche per anon)', r.ok && r.rows[0].s === 'unknown', r);

console.log('\n— Fase 6: strumenti di ricerca (solo backend)');
r = await as(null, `select public.ai_search_restaurants('{"city":"taranto"}'::jsonb)`);
check('ai_search_restaurants non eseguibile da anon', !r.ok, r);
r = await as(U.cust, `select public.ai_search_menu('{"terms":["salmon"]}'::jsonb)`);
check('ai_search_menu non eseguibile dagli utenti', !r.ok, r);
r = await as(U.cust, `select public.ai_session_open(repeat('a', 64), '${U.cust}', null)`);
check('ai_session_open non eseguibile dagli utenti', !r.ok, r);
r = await as(U.cust, `select public.ai_log_usage('{"status":"ok"}'::jsonb)`);
check('ai_log_usage non eseguibile dagli utenti (costi non falsificabili)', !r.ok, r);
r = await svc(`select public.ai_search_restaurants('{"city":"taranto","categories":["sushi"],"limit":5}'::jsonb) x`);
const sr = r.rows?.[0]?.x;
check('ricerca per città+categoria: solo locali pubblici corrispondenti', r.ok && sr.items.length > 0 && sr.items.every((i) => i.city_slug === 'taranto' && i.categories.includes('Sushi')), sr);
r = await svc(`select public.ai_search_restaurants('{"lat":40.4644,"lng":17.247,"radius_km":2,"sort":"distance"}'::jsonb) x`);
const near = r.rows?.[0]?.x;
check('ricerca geolocalizzata: raggio e ordinamento per distanza', r.ok && near.items.length > 0 && near.items.every((i, k, a) => i.distance_km <= 2 && (k === 0 || a[k - 1].distance_km <= i.distance_km)), near.items.map((i) => i.distance_km));
r = await svc(`select public.ai_search_restaurants('{"city":"taranto","max_price":25}'::jsonb) x`);
const pr = r.rows?.[0]?.x;
check('filtro prezzo: nessun prezzo stimato; i locali senza prezzo sono contati a parte', r.ok && pr.items.every((i) => i.price_per_person !== null && i.price_per_person <= 25) && pr.excluded_no_price >= 1, { ex: pr.excluded_no_price, items: pr.items.map((i) => [i.name, i.price_per_person]) });
r = await svc(`select public.ai_search_restaurants('{"text":"%","city":"taranto"}'::jsonb) x`);
check('testo con wildcard % trattato come carattere (nessuna espansione)', r.ok && r.rows[0].x.items.length === 0, r.rows?.[0]?.x?.items?.length);
r = await svc(`select public.ai_search_restaurants('{"city":"taranto","open_required":true,"open_at":"2026-10-02T18:30:00Z"}'::jsonb) x`);
const op = r.rows?.[0]?.x;
check('"aperto ora": solo aperti, senza orari contati come unknown', r.ok && op.items.every((i) => i.open_status === 'open') && op.unknown_hours >= 1, { u: op.unknown_hours });
r = await svc(`select public.ai_search_menu('{"terms":["salmon"],"city":"taranto","limit":5}'::jsonb) x`);
check('ricerca menu (ILIKE nome/descrizione/ingredienti)', r.ok && r.rows[0].x.length > 0 && r.rows[0].x.filter((i) => /salmon/i.test(i.name)).length >= 3, r.rows?.[0]?.x?.map((i) => i.name));
r = await svc(`select public.ai_search_menu('{"vegan":true,"limit":20}'::jsonb) x`);
check('ricerca menu con flag alimentare (solo flag dichiarati)', r.ok && (r.rows[0].x ?? []).every((i) => i.is_vegan), r);
r = await svc(`select public.ai_search_offers('{"date":"2026-10-06","city":"taranto"}'::jsonb) x`);
const of = r.rows?.[0]?.x;
check('offerte del martedì (giorni validi) + coupon attivi', r.ok && of.offers.some((o) => /Martedì AYCE/.test(o.title)) && of.coupons.length > 0, of.offers.map((o) => o.title));
r = await svc(`select public.ai_search_offers('{"date":"2026-10-02","city":"taranto"}'::jsonb) x`);
check('offerta del martedì esclusa il venerdì', r.ok && !r.rows[0].x.offers.some((o) => /Martedì AYCE/.test(o.title)), r.rows?.[0]?.x?.offers?.map((o) => o.title));
r = await svc(`select public.ai_restaurant_detail('${R1}') x`);
const det = r.rows?.[0]?.x;
check('scheda per l’assistente: orari, riepilogo menu, prenotazioni, nessun dato privato', r.ok && det.hours.length > 0 && det.menu_summary.items > 0 && typeof det.reservations_online === 'boolean' && !('owner_id' in det) && !('email' in det), det && Object.keys(det));

console.log('\n— Fase 6: sessioni, limiti, costi, cache');
const TH = (c) => c.repeat(64);
r = await svc(`select public.ai_session_open('${TH('a')}', '${U.cust}', null) x`);
const sessA = r.rows?.[0]?.x;
check('sessione aperta per utente', r.ok && sessA.ok && sessA.message_count === 0, r);
r = await svc(`select public.ai_session_open('${TH('a')}', '${U.other}', null) x`);
check('sessione di un altro utente → FORBIDDEN', r.ok && r.rows[0].x.ok === false && r.rows[0].x.error === 'FORBIDDEN', r);
r = await svc(`select public.ai_session_open('${TH('a')}', null, null) x`);
check('sessione di un utente non accessibile da ospite', r.rows[0].x.error === 'FORBIDDEN', r);
r = await svc(`select public.ai_session_open('non-un-hash', null, null) x`);
check('token di sessione non valido → BAD_SESSION', r.rows[0].x.error === 'BAD_SESSION', r);
await svc(`select public.ai_session_append('${sessA.id}', 'Sushi vicino a me', 'Ecco 3 ristoranti', '{"intent":"nearby_search","lat":40.1}'::jsonb, '{"categories":["sushi"],"near_me":true,"lat":40.46,"lng":17.24}'::jsonb)`);
const sRow = await q1(`select last_filters, message_count from public.ai_chat_sessions where id='${sessA.id}'`);
check('contesto salvato senza coordinate', !('lat' in sRow.last_filters) && !('lng' in sRow.last_filters) && sRow.message_count === 2, sRow);
const mRow = await q1(`select metadata from public.ai_chat_messages where chat_session_id='${sessA.id}' and role='assistant'`);
check('metadati senza coordinate', !('lat' in mRow.metadata), mRow);
r = await as(U.cust, `select count(*)::int n from public.ai_chat_messages`);
check('RLS: l’utente legge i propri messaggi', r.ok && r.rows[0].n === 2, r);
r = await as(U.other, `select count(*)::int n from public.ai_chat_messages`);
check('RLS: un altro utente non vede la conversazione', r.ok && r.rows[0].n === 0, r);
r = await as(null, `select count(*)::int n from public.ai_chat_sessions`);
check('RLS: anon non legge sessioni', !r.ok || r.rows[0].n === 0, r);
r = await as(U.cust, `insert into public.ai_chat_messages (chat_session_id, role, content) values ('${sessA.id}', 'assistant', 'falso')`);
check('RLS: l’utente non scrive messaggi dell’assistente', !r.ok, r);
r = await as(U.cust, `update public.ai_chat_sessions set user_id = '${U.other}'`);
check('RLS: l’utente non riassegna sessioni', !r.ok || r.affected === 0, r);
r = await as(U.other, `delete from public.ai_chat_sessions where id='${sessA.id}'`);
check('RLS: un altro utente non elimina la conversazione', (await q1(`select count(*)::int n from public.ai_chat_sessions where id='${sessA.id}'`)).n === 1, r);
r = await as(U.cust, `delete from public.ai_chat_sessions where id='${sessA.id}'`);
check('l’utente elimina la propria conversazione (messaggi a cascata)', r.ok && (await q1(`select count(*)::int n from public.ai_chat_messages where chat_session_id='${sessA.id}'`)).n === 0, r);

await db.exec(`update public.platform_settings set value='2' where key='ai_guest_limit_per_hour'`);
for (let i = 0; i < 2; i++) await svc(`select public.ai_log_usage('{"session_id":"guest-sess","status":"ok","input_tokens":100,"output_tokens":50}'::jsonb)`);
r = await svc(`select public.ai_rate_check(null, 'guest-sess', null) x`);
check('rate limit ospite dalla configurazione (2/h)', r.ok && r.rows[0].x.ok === false && r.rows[0].x.limit === 2, r);
r = await svc(`select public.ai_rate_check(null, 'altra-sess', null) x`);
check('rate limit per sessione, non globale', r.rows[0].x.ok === true, r);
await db.exec(`update public.platform_settings set value='10' where key='ai_guest_limit_per_hour'`);
const cost = await q1(`select estimated_cost::float c from public.ai_usage where session_id='guest-sess' limit 1`);
check('costo stimato dai prezzi configurati ((100×3 + 50×15)/1M)', Math.abs(cost.c - 0.00105) < 1e-9, cost);
r = await as(U.cust, `select count(*)::int n from public.ai_usage`);
check('RLS: utilizzo e costi non visibili agli utenti', r.ok && r.rows[0].n === 0, r);
r = await as(U.admin, `select count(*)::int n from public.ai_usage`);
check('Admin legge l’utilizzo', r.ok && r.rows[0].n >= 2, r);
await svc(`select public.ai_cache_put('${TH('c')}', '{"x":1}'::jsonb, 60)`);
r = await svc(`select public.ai_cache_get('${TH('c')}') x`);
check('cache: scrittura e lettura dal backend', r.ok && r.rows[0].x.x === 1, r);
r = await as(U.cust, `select count(*)::int n from public.ai_cache`);
check('RLS: cache non accessibile dal client', !r.ok, r);
await svc(`select public.ai_cache_put('${TH('d')}', '{"x":1}'::jsonb, 0)`);
check('cache con TTL 0 → non salvata', (await q1(`select count(*)::int n from public.ai_cache where key='${TH('d')}'`)).n === 0);

console.log('\n— Fase 6: preferenze, statistiche, attribuzione');
r = await as(U.cust, `insert into public.ai_user_preferences (user_id, dietary_preferences, favorite_cities) values ('${U.cust}', '{vegetarian}', '{taranto}') returning user_id`);
check('preferenze: l’utente salva le proprie', r.ok, r);
r = await as(U.cust, `insert into public.ai_user_preferences (user_id, dietary_preferences) values ('${U.other}', '{vegan}')`);
check('preferenze: non per conto di altri', !r.ok, r);
r = await as(U.cust, `update public.ai_user_preferences set dietary_preferences = '{sonnifero}' where user_id='${U.cust}'`);
check('preferenze: solo valori ammessi', !r.ok, r);
r = await as(U.other, `select count(*)::int n from public.ai_user_preferences`);
check('preferenze: non visibili ad altri', r.ok && r.rows[0].n === 0, r);
r = await svc(`select public.ai_user_context('${U.cust}') x`);
check('contesto utente per il backend (preferenze)', r.ok && r.rows[0].x.preferences.dietary_preferences[0] === 'vegetarian', r);
r = await as(U.cust, `select public.ai_user_context('${U.other}')`);
check('contesto utente non leggibile dai client', !r.ok, r);
r = await as(U.cust, `delete from public.ai_user_preferences where user_id='${U.cust}'`);
check('preferenze eliminabili', r.ok && r.affected === 1, r);

r = await as(U.cust, `select public.ai_admin_stats(30)`);
check('statistiche AI: solo Admin', !r.ok, r);
r = await as(U.admin, `select public.ai_admin_stats(30) x`);
check('statistiche AI Admin (richieste, costi, intenti, serie)', r.ok && r.rows[0].x.requests_period >= 2 && Array.isArray(r.rows[0].x.daily), r.rows?.[0]?.x && Object.keys(r.rows[0].x));
r = await as(null, `select public.track_event(null, 'ai_message_sent', 'sess_ai_1234', 'ai', '{"intent":"restaurant_search","message":"testo privato","lat":40.1}'::jsonb)`);
const aiEv = await q1(`select event_type, restaurant_id, metadata from public.analytics_events where event_type='ai_message_sent' order by created_at desc limit 1`);
check('evento ai_message_sent senza ristorante, senza testo né coordinate', r.ok && aiEv && aiEv.restaurant_id === null && !('message' in aiEv.metadata) && !('lat' in aiEv.metadata) && aiEv.metadata.intent === 'restaurant_search', aiEv);
r = await as(null, `select public.track_event('${R1}', 'ai_result_click', 'sess_ai_1234', 'ai', '{}'::jsonb), public.track_event('${R1}', 'view', 'sess_ai_1234', 'ai', '{}'::jsonb)`);
check('clic su risultato AI e visita con origine "ai"', r.ok && (await q1(`select count(*)::int n from public.analytics_events where restaurant_id='${R1}' and source='ai'`)).n >= 2);
r = await as(null, `select public.track_event('${R1}', 'sponsored_click', 'sess_ai_1234', 'ai', '{}'::jsonb)`);
check('eventi sponsorizzati non falsificabili dal client', (await q1(`select count(*)::int n from public.analytics_events where event_type='sponsored_click' and session_id='sess_ai_1234'`)).n === 0);
await db.exec(`insert into public.coupons (id, restaurant_id, title, description, discount_type, discount_value, valid_from, valid_until, is_active, code, max_redemptions_per_user) values ('f1000000-0000-4000-8000-0000000000a1', '${R1}', 'Coupon AI test', 'Test', 'percent', 10, now() - interval '1 day', now() + interval '30 days', true, 'AITEST10', 1)`);
const cpAi = 'f1000000-0000-4000-8000-0000000000a1';
r = await as(U.other, `select public.claim_coupon('${cpAi}', null, 'ai') x`);
const clAi = r.ok && await q1(`select source from public.coupon_claims where claim_code='${r.rows[0].x.claim_code}'`);
check('coupon ottenuto dall’assistente → source "ai"', r.ok && clAi.source === 'ai', { r, clAi });
r = await as(U.other, `select public.claim_coupon('${cpAi}', null, 'hacker') x`);
check('source non valida ignorata', r.ok);
let dstr = null, slot = null;
for (let k = 3; k < 20 && !slot; k++) {
  const d = (await q1(`select to_char((now() at time zone 'Europe/Rome')::date + ${k}, 'YYYY-MM-DD') d`)).d;
  r = await as(null, `select public.get_reservation_availability('${R1}', '${d}', 2) x`);
  const s0 = r.rows?.[0]?.x?.slots?.find((x) => x.status === 'available')?.time;
  if (s0) (dstr = d), (slot = s0);
}
r = await as(null, `select public.create_reservation('${R1}', '${dstr}', '${slot}', 2, 'Test', 'AI', 'ai@test.it', '+39 333 0000000', null, 'ai') x`);
check('prenotazione dal flusso standard con origine "ai"', r.ok && (await q1(`select source::text s from public.reservations where guest_email='ai@test.it'`)).s === 'ai', r);
r = await as(U.owner, `select public.restaurant_ai_stats('${R1}', 30) x`);
check('"Clienti arrivati dall’AI" per il titolare Top: clic, visite, prenotazioni, coupon', r.ok && r.rows[0].x.result_clicks >= 1 && r.rows[0].x.reservations >= 1 && r.rows[0].x.coupon_claims >= 1, r.rows?.[0]?.x);
const freeR = (await q1(`select r.id from public.restaurants r join public.restaurant_members m on m.restaurant_id = r.id where m.user_id='${U.owner}' and public.restaurant_effective_plan(r.id) in ('free','business') limit 1`))?.id;
if (freeR) {
  r = await as(U.owner, `select public.restaurant_ai_stats('${freeR}', 30)`);
  check('"Clienti arrivati dall’AI" non incluso nei piani base (PLAN_FEATURE)', !r.ok && /PLAN_FEATURE/.test(r.err), r);
}
r = await as(U.cust, `select public.restaurant_ai_stats('${R1}', 30)`);
check('statistiche AI del ristorante negate ai non gestori', !r.ok, r);
r = await as(U.admin, `select public.ai_purge() x`);
check('pulizia AI (Admin/cron)', r.ok && typeof r.rows[0].x.sessions === 'number', r);
r = await as(U.cust, `select public.ai_purge()`);
check('pulizia AI negata agli utenti', !r.ok, r);

console.log(`\n${pass} passati, ${fail} falliti`);
process.exit(fail ? 1 : 0);
