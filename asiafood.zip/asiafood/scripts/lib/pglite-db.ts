// Database Postgres in memoria (PGlite) con le VERE migrazioni e il seed: usato dai test server-side.
import { PGlite } from '@electric-sql/pglite';
import { pg_trgm } from '@electric-sql/pglite/contrib/pg_trgm';
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto';
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export async function createTestDb() {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '../../supabase');
  const db = new PGlite({ extensions: { pg_trgm, pgcrypto } });
  await db.exec(`
create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
create schema auth; create schema storage;
create table auth.users (id uuid primary key, email text, raw_user_meta_data jsonb default '{}', email_confirmed_at timestamptz);
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
create function auth.role() returns text language sql stable as $$ select nullif(current_setting('request.jwt.claim.role', true), '') $$;
create table storage.buckets (id text primary key, name text, public boolean, file_size_limit bigint, allowed_mime_types text[]);
create table storage.objects (id uuid primary key default gen_random_uuid(), bucket_id text, name text, owner uuid);
alter table storage.objects enable row level security;
create function storage.foldername(name text) returns text[] language sql immutable as $$ select (string_to_array(name, '/'))[1:array_length(string_to_array(name,'/'),1)-1] $$;
grant usage on schema public, auth, storage to anon, authenticated, service_role;
grant all on storage.objects to anon, authenticated;
grant execute on all functions in schema auth to anon, authenticated, service_role;
`);
  for (const f of readdirSync(`${root}/migrations`).sort()) await db.exec(readFileSync(`${root}/migrations/${f}`, 'utf8'));
  await db.exec(readFileSync(`${root}/seed.sql`, 'utf8'));
  await db.exec('grant all on all tables in schema public to service_role; grant usage on all sequences in schema public to service_role;');

  /** RPC eseguite come service_role (come le Netlify Functions). */
  const SETOF = new Set(['sponsored_slots', 'billing_stripe_subscription_ids', 'background_jobs_claim', 'restaurant_slug_redirects']);
  const store = {
    async rpc<T>(fn: string, args: Record<string, unknown>): Promise<T> {
      const keys = Object.keys(args);
      const call = `public.${fn}(${keys.map((k, i) => `${k} => $${i + 1}`).join(', ')})`;
      const sql = SETOF.has(fn) ? `select coalesce((select jsonb_agg(to_jsonb(x)) from ${call} x), '[]'::jsonb) as r` : `select ${call} as r`;
      const params = keys.map((k) => {
        const v = args[k];
        return v !== null && typeof v === 'object' ? JSON.stringify(v) : v;
      });
      await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', 'service_role', false); set role service_role;`);
      try {
        const res = await db.query<{ r: T }>(sql, params);
        return res.rows[0]!.r;
      } finally {
        await db.exec('reset role;');
      }
    },
  };
  return { db, store };
}
