/* eslint-disable @typescript-eslint/no-explicit-any */
// ─────────────────────────────────────────────────────────────
//  Stripe simulato (solo per i test): riproduce il sottoinsieme
//  di API usato dal backend AsiaFood con la forma degli oggetti
//  delle versioni API recenti (periodo corrente sugli item,
//  invoice.parent.subscription_details) e genera gli eventi
//  webhook firmati con la vera libreria Stripe.
// ─────────────────────────────────────────────────────────────
import Stripe from 'stripe';

type Obj = Record<string, any>;

const DAY = 86400;
let seq = 0;
const rid = (prefix: string) => `${prefix}_${Date.now().toString(36)}${(++seq).toString(36).padStart(6, '0')}`;

export class StripeTestError extends Error {
  constructor(
    readonly type: string,
    message: string,
    readonly code?: string,
    readonly statusCode = 400,
  ) {
    super(message);
  }
}
const missing = (what: string, id: string) => new StripeTestError('StripeInvalidRequestError', `No such ${what}: '${id}'`, 'resource_missing', 404);

export interface FakeEvent {
  id: string;
  type: string;
  livemode: boolean;
  created: number;
  data: { object: Obj };
  object: 'event';
  api_version: string;
}

export class FakeStripe {
  customers = new Map<string, Obj>();
  products = new Map<string, Obj>();
  prices = new Map<string, Obj>();
  coupons = new Map<string, Obj>();
  sessions = new Map<string, Obj>();
  subs = new Map<string, Obj>();
  schedules = new Map<string, Obj>();
  invoices = new Map<string, Obj>();
  paymentMethods = new Map<string, Obj>();
  intents = new Map<string, Obj>();
  refundsMap = new Map<string, Obj>();
  accountsMap = new Map<string, Obj>();
  events: FakeEvent[] = [];
  idem = new Map<string, Obj>();
  calls: { method: string; params: any }[] = [];
  /** Il prossimo addebito immediato viene rifiutato (carta declinata). */
  declineNext = false;
  /** Simula Stripe irraggiungibile. */
  down = false;
  private readonly real = new Stripe('sk_test_fake_for_signatures');
  readonly webhooks = this.real.webhooks;

  now = () => Math.floor(Date.now() / 1000);

  private guard(method: string, params?: any) {
    this.calls.push({ method, params });
    if (this.down) throw new StripeTestError('StripeConnectionError', 'An error occurred with our connection to Stripe', undefined, 500);
  }
  private idempotent<T extends Obj>(key: string | undefined, make: () => T): T {
    if (!key) return make();
    const hit = this.idem.get(key);
    if (hit) return hit as T;
    const v = make();
    this.idem.set(key, v);
    return v;
  }
  private emit(type: string, object: Obj) {
    this.events.push({ id: rid('evt'), type, livemode: false, created: this.now(), data: { object: structuredClone(object) }, object: 'event', api_version: '2026-08-26.dahlia' });
  }
  /** Eventi in attesa di consegna (svuota la coda). */
  drain(): FakeEvent[] {
    const out = this.events;
    this.events = [];
    return out;
  }

  // ─── Customers ───
  customersApi = {
    create: async (params: Obj, opts?: Obj) => {
      this.guard('customers.create', params);
      return this.idempotent(opts?.idempotencyKey, () => {
        const c = { id: rid('cus'), object: 'customer', email: params.email ?? null, name: params.name ?? null, metadata: params.metadata ?? {}, invoice_settings: { default_payment_method: null }, livemode: false };
        this.customers.set(c.id, c);
        return c;
      });
    },
    retrieve: async (id: string, opts?: Obj) => {
      this.guard('customers.retrieve', { id });
      const c = this.customers.get(id);
      if (!c) throw missing('customer', id);
      const out = structuredClone(c);
      if (opts?.expand?.includes('invoice_settings.default_payment_method') && out.invoice_settings.default_payment_method) {
        out.invoice_settings.default_payment_method = this.paymentMethods.get(out.invoice_settings.default_payment_method);
      }
      return out;
    },
    update: async (id: string, params: Obj) => {
      this.guard('customers.update', params);
      const c = this.customers.get(id);
      if (!c) throw missing('customer', id);
      Object.assign(c, { ...params, metadata: { ...c.metadata, ...(params.metadata ?? {}) } });
      return c;
    },
  };

  // ─── Catalogo ───
  productsApi = {
    create: async (params: Obj, opts?: Obj) => {
      this.guard('products.create', params);
      return this.idempotent(opts?.idempotencyKey, () => {
        const p = { id: rid('prod'), object: 'product', active: true, ...params };
        this.products.set(p.id, p);
        return p;
      });
    },
    retrieve: async (id: string) => {
      const p = this.products.get(id);
      if (!p) throw missing('product', id);
      return p;
    },
  };
  pricesApi = {
    create: async (params: Obj, opts?: Obj) => {
      this.guard('prices.create', params);
      return this.idempotent(opts?.idempotencyKey, () => {
        const p = { id: rid('price'), object: 'price', active: true, product: params.product, currency: params.currency, unit_amount: params.unit_amount, recurring: { interval: params.recurring.interval }, lookup_key: params.lookup_key, metadata: params.metadata ?? {} };
        this.prices.set(p.id, p);
        return p;
      });
    },
    retrieve: async (id: string) => {
      const p = this.prices.get(id);
      if (!p) throw missing('price', id);
      return p;
    },
  };
  couponsApi = {
    create: async (params: Obj, opts?: Obj) => {
      this.guard('coupons.create', params);
      return this.idempotent(opts?.idempotencyKey, () => {
        const c = { id: rid('coupon'), object: 'coupon', valid: true, ...params };
        this.coupons.set(c.id, c);
        return c;
      });
    },
  };

  // ─── Checkout ───
  checkoutApi = {
    sessions: {
      create: async (params: Obj, opts?: Obj) => {
        this.guard('checkout.sessions.create', params);
        return this.idempotent(opts?.idempotencyKey, () => {
          if (!this.customers.has(params.customer)) throw missing('customer', params.customer);
          const price = params.line_items?.[0]?.price;
          if (!this.prices.has(price)) throw missing('price', price);
          const id = `cs_test_${rid('x').slice(2)}${'a'.repeat(12)}`;
          const s = { id, object: 'checkout.session', mode: params.mode, url: `https://checkout.stripe.com/c/pay/${id}`, status: 'open', payment_status: 'unpaid', customer: params.customer, client_reference_id: params.client_reference_id, metadata: params.metadata ?? {}, subscription: null, livemode: false, _params: params };
          this.sessions.set(id, s);
          return s;
        });
      },
      retrieve: async (id: string) => {
        this.guard('checkout.sessions.retrieve', { id });
        const s = this.sessions.get(id);
        if (!s) throw missing('checkout session', id);
        const { _params, ...pub } = s;
        void _params;
        return structuredClone(pub);
      },
    },
  };

  billingPortalApi = {
    sessions: {
      create: async (params: Obj) => {
        this.guard('billingPortal.sessions.create', params);
        if (!this.customers.has(params.customer)) throw missing('customer', params.customer);
        return { id: rid('bps'), object: 'billing_portal.session', url: `https://billing.stripe.com/p/session/test_${rid('x')}`, return_url: params.return_url, flow: params.flow_data ?? null };
      },
    },
  };

  // ─── Subscriptions ───
  private subView(sub: Obj, expand: string[] = []) {
    const out = structuredClone(sub);
    if (expand.includes('default_payment_method') && out.default_payment_method) out.default_payment_method = this.paymentMethods.get(out.default_payment_method);
    if (expand.includes('latest_invoice') && out.latest_invoice) out.latest_invoice = structuredClone(this.invoices.get(out.latest_invoice));
    return out;
  }

  private makeInvoice(sub: Obj, amount: number, opts: { status?: 'paid' | 'open'; reason?: string; lines?: Obj[] } = {}) {
    const item = sub.items.data[0];
    const inv = {
      id: rid('in'),
      object: 'invoice',
      customer: sub.customer,
      number: `AF-TEST-${String(this.invoices.size + 1).padStart(4, '0')}`,
      status: opts.status ?? 'paid',
      amount_due: amount,
      amount_paid: opts.status === 'open' ? 0 : amount,
      currency: 'eur',
      hosted_invoice_url: `https://invoice.stripe.com/i/test_${rid('x')}`,
      invoice_pdf: `https://pay.stripe.com/invoice/test_${rid('x')}/pdf`,
      period_start: item.current_period_start,
      period_end: item.current_period_end,
      created: this.now(),
      livemode: false,
      billing_reason: opts.reason ?? 'subscription_cycle',
      parent: { type: 'subscription_details', subscription_details: { subscription: sub.id, metadata: sub.metadata } },
      lines: { object: 'list', data: opts.lines ?? [{ amount, parent: { subscription_item_details: { proration: false } } }] },
    };
    this.invoices.set(inv.id, inv);
    sub.latest_invoice = inv.id;
    return inv;
  }

  /** Aggiunge una carta di test (4242) al cliente. */
  attachCard(customerId: string, brand = 'visa', last4 = '4242') {
    const pm = { id: rid('pm'), object: 'payment_method', type: 'card', card: { brand, last4, exp_month: 12, exp_year: 2030 } };
    this.paymentMethods.set(pm.id, pm);
    const c = this.customers.get(customerId)!;
    c.invoice_settings.default_payment_method = pm.id;
    return pm.id;
  }

  subscriptionsApi = {
    retrieve: async (id: string, opts?: Obj) => {
      this.guard('subscriptions.retrieve', { id });
      const s = this.subs.get(id);
      if (!s) throw missing('subscription', id);
      return this.subView(s, opts?.expand ?? []);
    },
    update: async (id: string, params: Obj) => {
      this.guard('subscriptions.update', params);
      const sub = this.subs.get(id);
      if (!sub) throw missing('subscription', id);
      const item = sub.items.data[0];
      if (params.items?.[0]?.price && params.items[0].price !== item.price.id) {
        const newPrice = this.prices.get(params.items[0].price);
        if (!newPrice) throw missing('price', params.items[0].price);
        const oldPrice = item.price;
        const intervalChanges = newPrice.recurring.interval !== oldPrice.recurring.interval;
        const charge = sub.status !== 'trialing' && (params.proration_behavior === 'always_invoice' || intervalChanges) && params.proration_behavior !== 'none';
        let amount = 0;
        if (charge) {
          const now = this.now();
          const frac = Math.max(0, (item.current_period_end - now) / (item.current_period_end - item.current_period_start));
          amount = intervalChanges ? Math.max(0, newPrice.unit_amount - Math.round(oldPrice.unit_amount * frac)) : Math.round((newPrice.unit_amount - oldPrice.unit_amount) * frac);
          if (this.declineNext && params.payment_behavior === 'error_if_incomplete') {
            this.declineNext = false;
            throw new StripeTestError('StripeCardError', 'Your card was declined.', 'card_declined', 402);
          }
        }
        item.price = newPrice;
        if (intervalChanges && sub.status !== 'trialing') {
          item.current_period_start = this.now();
          item.current_period_end = this.now() + (newPrice.recurring.interval === 'year' ? 365 : 30) * DAY;
        }
        if (charge && amount > 0) {
          const inv = this.makeInvoice(sub, amount, { reason: 'subscription_update', lines: [{ amount, parent: { subscription_item_details: { proration: true } } }] });
          this.emit('invoice.paid', inv);
        }
      }
      if (params.cancel_at_period_end !== undefined) sub.cancel_at_period_end = params.cancel_at_period_end;
      if (params.trial_end !== undefined) sub.trial_end = params.trial_end;
      if (params.metadata) sub.metadata = { ...sub.metadata, ...params.metadata };
      this.emit('customer.subscription.updated', sub);
      return this.subView(sub);
    },
  };

  schedulesApi = {
    create: async (params: Obj) => {
      this.guard('subscriptionSchedules.create', params);
      const sub = this.subs.get(params.from_subscription);
      if (!sub) throw missing('subscription', params.from_subscription);
      if (sub.schedule) throw new StripeTestError('StripeInvalidRequestError', 'Subscription already has a schedule');
      const item = sub.items.data[0];
      const sched = { id: rid('sub_sched'), object: 'subscription_schedule', subscription: sub.id, status: 'active', end_behavior: 'release', phases: [{ start_date: item.current_period_start, end_date: item.current_period_end, items: [{ price: item.price.id, quantity: 1 }] }] };
      this.schedules.set(sched.id, sched);
      sub.schedule = sched.id;
      return sched;
    },
    update: async (id: string, params: Obj) => {
      this.guard('subscriptionSchedules.update', params);
      const sched = this.schedules.get(id);
      if (!sched) throw missing('subscription_schedule', id);
      if (params.phases?.[0]?.start_date !== sched.phases[0].start_date) throw new StripeTestError('StripeInvalidRequestError', 'You can not modify the start date of the current phase.');
      const phases = params.phases.map((p: Obj, i: number) => ({ ...p, start_date: p.start_date ?? params.phases[i - 1].end_date, items: p.items.map((x: Obj) => ({ ...x, price: this.prices.get(x.price) ?? x.price })) }));
      Object.assign(sched, { ...params, phases });
      const sub = this.subs.get(sched.subscription)!;
      this.emit('customer.subscription.updated', sub);
      return sched;
    },
    release: async (id: string) => {
      this.guard('subscriptionSchedules.release', { id });
      const sched = this.schedules.get(id);
      if (!sched) throw missing('subscription_schedule', id);
      sched.status = 'released';
      const sub = this.subs.get(sched.subscription);
      if (sub) {
        sub.schedule = null;
        this.emit('customer.subscription.updated', sub);
      }
      return sched;
    },
    retrieve: async (id: string) => {
      const sched = this.schedules.get(id);
      if (!sched) throw missing('subscription_schedule', id);
      return structuredClone(sched);
    },
  };

  invoicesApi = {
    createPreview: async (params: Obj) => {
      this.guard('invoices.createPreview', params);
      const sub = this.subs.get(params.subscription);
      if (!sub) throw missing('subscription', params.subscription);
      const item = sub.items.data[0];
      const newPrice = this.prices.get(params.subscription_details.items[0].price)!;
      const now = params.subscription_details.proration_date ?? this.now();
      const frac = Math.max(0, (item.current_period_end - now) / (item.current_period_end - item.current_period_start));
      const intervalChanges = newPrice.recurring.interval !== item.price.recurring.interval;
      const credit = -Math.round(item.price.unit_amount * frac);
      const lines = intervalChanges
        ? [{ amount: credit, parent: { subscription_item_details: { proration: true } } }, { amount: newPrice.unit_amount, parent: { subscription_item_details: { proration: false } } }]
        : [
            { amount: credit, parent: { subscription_item_details: { proration: true } } },
            { amount: Math.round(newPrice.unit_amount * frac), parent: { subscription_item_details: { proration: true } } },
            { amount: newPrice.unit_amount, parent: { subscription_item_details: { proration: false } } },
          ];
      const total = lines.reduce((a, l) => a + l.amount, 0);
      return { object: 'invoice', id: null, currency: 'eur', amount_due: Math.max(0, total), lines: { data: lines }, livemode: false };
    },
    list: async (params: Obj) => {
      this.guard('invoices.list', params);
      const data = [...this.invoices.values()].filter((i) => i.customer === params.customer).sort((a, b) => b.created - a.created).slice(0, params.limit ?? 10);
      return { object: 'list', data: structuredClone(data), has_more: false };
    },
  };

  // ─── Fase 8: pagamenti ordini, rimborsi, Connect ───
  paymentIntentsApi = {
    create: async (params: Obj, opts?: Obj) => {
      this.guard('paymentIntents.create', params);
      return structuredClone(this.idempotent(opts?.idempotencyKey, () => {
        const pi = { id: rid('pi'), object: 'payment_intent', amount: params.amount, amount_received: 0, currency: params.currency, status: 'requires_payment_method',
          client_secret: '', metadata: params.metadata ?? {}, transfer_data: params.transfer_data ?? null, application_fee_amount: params.application_fee_amount ?? null,
          latest_charge: null, last_payment_error: null, livemode: false, receipt_email: params.receipt_email ?? null };
        pi.client_secret = `${pi.id}_secret_test`;
        this.intents.set(pi.id, pi);
        return pi;
      }));
    },
    retrieve: async (id: string) => {
      this.guard('paymentIntents.retrieve', { id });
      const pi = this.intents.get(id);
      if (!pi) throw missing('payment_intent', id);
      return structuredClone(pi);
    },
    cancel: async (id: string, params?: Obj) => {
      this.guard('paymentIntents.cancel', { id, ...params });
      const pi = this.intents.get(id);
      if (!pi) throw missing('payment_intent', id);
      if (pi.status === 'succeeded') throw new StripeTestError('StripeInvalidRequestError', 'You cannot cancel this PaymentIntent because it has a status of succeeded.', 'payment_intent_unexpected_state');
      pi.status = 'canceled';
      this.emit('payment_intent.canceled', pi);
      return structuredClone(pi);
    },
  };
  refundsApi = {
    create: async (params: Obj, opts?: Obj) => {
      this.guard('refunds.create', params);
      if (this.declineNext) {
        this.declineNext = false;
        throw new StripeTestError('StripeInvalidRequestError', 'Charge has already been refunded.', 'charge_already_refunded');
      }
      return structuredClone(this.idempotent(opts?.idempotencyKey, () => {
        const pi = this.intents.get(params.payment_intent);
        if (!pi || pi.status !== 'succeeded') throw new StripeTestError('StripeInvalidRequestError', 'This PaymentIntent does not have a successful charge to refund.', 'charge_not_refundable');
        const already = [...this.refundsMap.values()].filter((r) => r.payment_intent === pi.id && r.status !== 'failed').reduce((a, r) => a + r.amount, 0);
        const amount = params.amount ?? pi.amount_received - already;
        if (amount + already > pi.amount_received) throw new StripeTestError('StripeInvalidRequestError', 'Refund amount is greater than unrefunded amount on charge.', 'amount_too_large');
        const r = { id: rid('re'), object: 'refund', amount, payment_intent: pi.id, charge: pi.latest_charge, status: 'succeeded', metadata: params.metadata ?? {},
          reverse_transfer: params.reverse_transfer ?? false, refund_application_fee: params.refund_application_fee ?? false, failure_reason: null };
        this.refundsMap.set(r.id, r);
        this.emit('charge.refunded', { id: pi.latest_charge, object: 'charge', payment_intent: pi.id, amount_refunded: already + amount });
        return r;
      }));
    },
    list: async (params: Obj) => {
      this.guard('refunds.list', params);
      return { object: 'list', data: structuredClone([...this.refundsMap.values()].filter((r) => r.payment_intent === params.payment_intent)), has_more: false };
    },
  };
  accountsApi = {
    create: async (params: Obj, opts?: Obj) => {
      this.guard('accounts.create', params);
      return structuredClone(this.idempotent(opts?.idempotencyKey, () => {
        const a = { id: rid('acct'), object: 'account', type: params.type, charges_enabled: false, payouts_enabled: false, details_submitted: false,
          requirements: { currently_due: ['external_account', 'representative.first_name'] }, metadata: params.metadata ?? {}, email: params.email ?? null };
        this.accountsMap.set(a.id, a);
        return a;
      }));
    },
    retrieve: async (id: string) => {
      this.guard('accounts.retrieve', { id });
      const a = this.accountsMap.get(id);
      if (!a) throw missing('account', id);
      return structuredClone(a);
    },
    createLoginLink: async (id: string) => {
      this.guard('accounts.createLoginLink', { id });
      if (!this.accountsMap.get(id)?.details_submitted) throw new StripeTestError('StripeInvalidRequestError', 'Cannot create a login link for an account that has not completed onboarding.');
      return { object: 'login_link', url: `https://connect.stripe.test/express/${id}` };
    },
  };
  accountLinksApi = {
    create: async (params: Obj) => {
      this.guard('accountLinks.create', params);
      if (!this.accountsMap.get(params.account)) throw missing('account', params.account);
      return { object: 'account_link', url: `https://connect.stripe.test/setup/${params.account}`, expires_at: this.now() + 300 };
    },
  };

  /** Il cliente paga (o la carta viene rifiutata) nel Payment Element. */
  payIntent(id: string, opts: { decline?: boolean; amount?: number } = {}) {
    const pi = this.intents.get(id)!;
    if (opts.decline) {
      pi.status = 'requires_payment_method';
      pi.last_payment_error = { code: 'card_declined', decline_code: 'generic_decline', message: 'Your card was declined.' };
      this.emit('payment_intent.payment_failed', pi);
      return;
    }
    pi.status = 'succeeded';
    pi.amount_received = opts.amount ?? pi.amount;
    pi.latest_charge = rid('ch');
    pi.last_payment_error = null;
    this.emit('payment_intent.succeeded', pi);
  }
  /** Il ristoratore completa l'onboarding Stripe Connect. */
  completeOnboarding(accountId: string) {
    const a = this.accountsMap.get(accountId)!;
    Object.assign(a, { charges_enabled: true, payouts_enabled: true, details_submitted: true, requirements: { currently_due: [] } });
    this.emit('account.updated', a);
  }
  disputeIntent(id: string) {
    const pi = this.intents.get(id)!;
    this.emit('charge.dispute.created', { id: rid('dp'), object: 'dispute', payment_intent: pi.id, charge: pi.latest_charge, reason: 'fraudulent', amount: pi.amount_received });
  }

  // Superficie compatibile con l'SDK (solo ciò che usa il backend)
  asStripe(): Stripe {
    return {
      customers: this.customersApi,
      products: this.productsApi,
      prices: this.pricesApi,
      coupons: this.couponsApi,
      checkout: this.checkoutApi,
      billingPortal: this.billingPortalApi,
      subscriptions: this.subscriptionsApi,
      subscriptionSchedules: this.schedulesApi,
      invoices: this.invoicesApi,
      webhooks: this.webhooks,
      paymentIntents: this.paymentIntentsApi,
      refunds: this.refundsApi,
      accounts: this.accountsApi,
      accountLinks: this.accountLinksApi,
    } as unknown as Stripe;
  }

  // ═══ Simulazione di ciò che fa Stripe fuori dalle API (utente, tempo, banca) ═══

  /** L'utente completa il checkout ospitato (con o senza carta). */
  completeCheckout(sessionId: string, opts: { card?: boolean } = {}) {
    const s = this.sessions.get(sessionId)!;
    const p = s._params;
    const price = this.prices.get(p.line_items[0].price)!;
    const trialDays = p.subscription_data?.trial_period_days ?? 0;
    if (opts.card === false && p.payment_method_collection !== 'if_required') throw new Error('Checkout richiede la carta');
    const pm = opts.card === false ? null : this.attachCard(s.customer);
    const now = this.now();
    const periodEnd = now + (trialDays ? trialDays : price.recurring.interval === 'year' ? 365 : 30) * DAY;
    const sub: Obj = {
      id: rid('sub'),
      object: 'subscription',
      customer: s.customer,
      status: trialDays ? 'trialing' : 'active',
      livemode: false,
      metadata: p.subscription_data?.metadata ?? {},
      items: { object: 'list', data: [{ id: rid('si'), object: 'subscription_item', price, quantity: 1, current_period_start: now, current_period_end: periodEnd }] },
      trial_start: trialDays ? now : null,
      trial_end: trialDays ? periodEnd : null,
      cancel_at_period_end: false,
      cancel_at: null,
      canceled_at: null,
      ended_at: null,
      default_payment_method: pm,
      latest_invoice: null,
      schedule: null,
      discounts: p.discounts ?? [],
    };
    this.subs.set(sub.id, sub);
    const inv = this.makeInvoice(sub, trialDays ? 0 : price.unit_amount, { reason: 'subscription_create' });
    Object.assign(s, { status: 'complete', payment_status: trialDays ? 'no_payment_required' : 'paid', subscription: sub.id });
    this.emit('customer.subscription.created', sub);
    this.emit('invoice.finalized', inv);
    this.emit('invoice.paid', inv);
    this.emit('checkout.session.completed', { ...s, _params: undefined });
    return sub.id as string;
  }

  /** Fine della prova: con carta → attivo e prima fattura; senza carta → cancellato. */
  endTrial(subId: string) {
    const sub = this.subs.get(subId)!;
    const item = sub.items.data[0];
    const now = this.now();
    sub.trial_end = now - 1;
    const pm = sub.default_payment_method ?? this.customers.get(sub.customer)?.invoice_settings.default_payment_method;
    if (!pm) {
      Object.assign(sub, { status: 'canceled', canceled_at: now, ended_at: now });
      item.current_period_end = now - 1;
      this.emit('customer.subscription.deleted', sub);
      return;
    }
    sub.status = 'active';
    item.current_period_start = now;
    item.current_period_end = now + (item.price.recurring.interval === 'year' ? 365 : 30) * DAY;
    const inv = this.makeInvoice(sub, item.price.unit_amount);
    this.emit('customer.subscription.updated', sub);
    this.emit('invoice.paid', inv);
  }

  /** Il rinnovo fallisce (carta scaduta, fondi insufficienti). */
  failRenewal(subId: string) {
    const sub = this.subs.get(subId)!;
    const inv = this.makeInvoice(sub, sub.items.data[0].price.unit_amount, { status: 'open' });
    sub.status = 'past_due';
    this.emit('invoice.payment_failed', inv);
    this.emit('customer.subscription.updated', sub);
    return inv.id as string;
  }

  /** Il cliente aggiorna la carta dal portale e la fattura viene pagata. */
  payOpenInvoice(subId: string) {
    const sub = this.subs.get(subId)!;
    const inv = this.invoices.get(sub.latest_invoice)!;
    Object.assign(inv, { status: 'paid', amount_paid: inv.amount_due });
    sub.status = 'active';
    this.emit('invoice.paid', inv);
    this.emit('customer.subscription.updated', sub);
  }

  /** Arriva la fine del periodo: applica cancellazione o cambio programmato. */
  reachPeriodEnd(subId: string) {
    const sub = this.subs.get(subId)!;
    const item = sub.items.data[0];
    const now = this.now();
    if (sub.cancel_at_period_end) {
      item.current_period_end = now - 1;
      Object.assign(sub, { status: 'canceled', canceled_at: now, ended_at: now });
      this.emit('customer.subscription.deleted', sub);
      return;
    }
    if (sub.schedule) {
      const sched = this.schedules.get(sub.schedule)!;
      const next = sched.phases[1];
      if (next) {
        item.price = typeof next.items[0].price === 'string' ? this.prices.get(next.items[0].price) : next.items[0].price;
        sub.metadata = { ...sub.metadata, ...(next.metadata ?? {}) };
      }
      sched.status = 'released';
      sub.schedule = null;
    }
    item.current_period_start = now;
    item.current_period_end = now + (item.price.recurring.interval === 'year' ? 365 : 30) * DAY;
    const inv = this.makeInvoice(sub, item.price.unit_amount);
    this.emit('customer.subscription.updated', sub);
    this.emit('invoice.paid', inv);
  }

  /** Evento firmato come lo invierebbe Stripe. */
  sign(event: FakeEvent, secret: string) {
    const payload = JSON.stringify(event);
    return { payload, header: this.real.webhooks.generateTestHeaderString({ payload, secret }) };
  }
}
