// ─────────────────────────────────────────────────────────────
//  npm run production-check [-- --env=production|staging] [--skip-tests] [--skip-build] [--online]
//
//  Controllo pre-lancio automatico: env (solo NOMI, mai valori), typecheck, lint, test, build,
//  segreti nel bundle, flag DEMO, sitemap, robots, manifest PWA, service worker, header di sicurezza.
//  --online: con SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY legge dal database (dati demo visibili,
//            launch checks di sistema) senza stampare alcun valore sensibile.
//  Uscita 1 se c'è almeno un controllo FAIL.
// ─────────────────────────────────────────────────────────────
import { execSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { loadEnv } from 'vite';

const root = resolve(import.meta.dirname, '..');
const args = new Set(process.argv.slice(2));
const argEnv = [...args].find((a) => a.startsWith('--env='))?.split('=')[1];
const fileEnv = loadEnv('production', root, '');
const env: Record<string, string | undefined> = { ...fileEnv, ...process.env };
const target = (argEnv || env.APP_ENV || 'production').toLowerCase();
process.env.APP_ENV = target;

type Status = 'PASS' | 'WARN' | 'FAIL' | 'SKIP';
const results: { area: string; check: string; status: Status; note: string }[] = [];
const add = (area: string, check: string, status: Status, note = '') => {
  results.push({ area, check, status, note });
  const icon = { PASS: '✓', WARN: '!', FAIL: '✗', SKIP: '-' }[status];
  console.log(`  ${icon} [${area}] ${check}${note ? ` — ${note}` : ''}`);
};
const run = (cmd: string) => {
  try {
    execSync(cmd, { cwd: root, stdio: 'pipe', env: { ...process.env }, maxBuffer: 64 * 1024 * 1024 });
    return { ok: true, out: '' };
  } catch (e) {
    const err = e as { stdout?: Buffer; stderr?: Buffer };
    return { ok: false, out: `${err.stdout?.toString() ?? ''}${err.stderr?.toString() ?? ''}`.split('\n').filter(Boolean).slice(-6).join(' | ') };
  }
};

console.log(`\nAsiaFood · production-check (ambiente: ${target})\n`);

// ─── 1. Variabili d'ambiente (solo nomi) ───
{
  const { validateEnv } = await import('../server/platform/env');
  const groups = target === 'production' ? (['core', 'stripe', 'orders'] as const) : (['core'] as const);
  for (const [k, v] of Object.entries(env)) if (v !== undefined) process.env[k] = v;
  const r = validateEnv([...groups]);
  add('ENV', `variabili obbligatorie (${groups.join(', ')})`, r.ok ? 'PASS' : target === 'production' ? 'FAIL' : 'WARN',
    r.ok ? 'presenti' : `mancanti/non valide: ${[...r.missing, ...r.invalid.map((i) => `${i.name} (${i.reason})`)].join(', ')}`);
  r.warnings.forEach((w) => add('ENV', 'coerenza', 'WARN', w));
  const frontend = ['VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY', 'VITE_SITE_URL', 'VITE_STRIPE_PUBLISHABLE_KEY'];
  const missingFront = frontend.filter((k) => !env[k]);
  add('ENV', 'variabili frontend', missingFront.length ? (target === 'production' ? 'FAIL' : 'WARN') : 'PASS', missingFront.length ? `mancanti: ${missingFront.join(', ')}` : 'presenti');
  const optional = ['TURNSTILE_SECRET_KEY', 'VITE_TURNSTILE_SITE_KEY', 'VITE_SENTRY_DSN', 'SENTRY_DSN', 'HEALTH_CHECK_TOKEN', 'VAPID_PRIVATE_KEY', 'AI_PROVIDER', 'IP_HASH_SALT'];
  add('ENV', 'variabili consigliate', 'WARN' as Status, `impostate: ${optional.filter((k) => env[k]).join(', ') || 'nessuna'}; mancanti: ${optional.filter((k) => !env[k]).join(', ') || 'nessuna'}`);
  if (target === 'production' && env.VITE_STRIPE_PUBLISHABLE_KEY?.startsWith('pk_test_')) add('ENV', 'Stripe frontend', 'WARN', 'chiave pubblicabile di TEST in produzione (ok solo in beta)');
  if (env.VITE_SITE_URL && !/^https:\/\//.test(env.VITE_SITE_URL)) add('ENV', 'VITE_SITE_URL', target === 'production' ? 'FAIL' : 'WARN', 'deve essere https');
  if (env.VITE_SITE_URL?.includes('.netlify.app') && target === 'production') add('ENV', 'dominio', 'WARN', 'dominio *.netlify.app: configura il dominio personalizzato');
}

// ─── 2. Flag DEMO ───
{
  const supabase = Boolean(env.VITE_SUPABASE_URL && env.VITE_SUPABASE_ANON_KEY);
  add('DEMO', 'build con Supabase (niente database DEMO nel browser)', supabase ? 'PASS' : target === 'production' ? 'FAIL' : 'WARN', supabase ? '' : 'senza VITE_SUPABASE_* l’app gira in modalità DEMO');
  add('DEMO', 'VITE_DEMO_FALLBACK disattivato', env.VITE_DEMO_FALLBACK === 'true' ? 'FAIL' : 'PASS');
}

// ─── 3. Typecheck, lint, test ───
if (!args.has('--skip-tests')) {
  for (const [name, cmd] of [['typecheck', 'npm run -s typecheck'], ['lint', 'npm run -s lint'], ['test:unit', 'npm run -s test:unit'], ['test:platform', 'npm run -s test:platform'],
    ['test:hardening', 'npm run -s test:hardening'], ['test:db', 'npm run -s test:db'], ['test:billing', 'npm run -s test:billing'], ['test:engagement', 'npm run -s test:engagement'],
    ['test:ai', 'npm run -s test:ai'], ['test:orders', 'npm run -s test:orders'], ['test:logistics', 'npm run -s test:logistics']] as const) {
    const r = run(cmd);
    add('QUALITÀ', name, r.ok ? 'PASS' : 'FAIL', r.ok ? '' : r.out.slice(0, 300));
  }
} else add('QUALITÀ', 'typecheck/lint/test', 'SKIP', '--skip-tests');

// ─── 4. Build + analisi del bundle ───
const dist = join(root, 'dist');
if (!args.has('--skip-build')) {
  const r = run('npm run -s build');
  add('BUILD', 'npm run build', r.ok ? 'PASS' : 'FAIL', r.ok ? '' : r.out.slice(0, 300));
}
if (existsSync(dist)) {
  const files: string[] = [];
  const walk = (d: string) => readdirSync(d).forEach((f) => (statSync(join(d, f)).isDirectory() ? walk(join(d, f)) : files.push(join(d, f))));
  walk(dist);
  const text = files.filter((f) => /\.(js|html|css|json|webmanifest|txt|xml)$/.test(f));
  // Pattern generici di segreti + valori effettivi delle variabili server (se presenti in questo ambiente)
  const patterns: [string, RegExp][] = [
    ['chiave Stripe segreta', /\b(sk|rk)_(live|test)_[A-Za-z0-9]{10,}/], ['webhook secret Stripe', /\bwhsec_[A-Za-z0-9]{10,}/],
    ['JWT service_role', /eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*c2VydmljZV9yb2xl[A-Za-z0-9_-]*\./], ['chiave privata PEM', /-----BEGIN (RSA |EC )?PRIVATE KEY-----/],
  ];
  const literal = ['SUPABASE_SERVICE_ROLE_KEY', 'STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET', 'STRIPE_CONNECT_WEBHOOK_SECRET', 'AI_API_KEY', 'VAPID_PRIVATE_KEY', 'ORDER_TOKEN_SECRET',
    'TURNSTILE_SECRET_KEY', 'MAPBOX_DIRECTIONS_TOKEN', 'MAPBOX_GEOCODING_TOKEN', 'HEALTH_CHECK_TOKEN', 'IP_HASH_SALT', 'AI_RATE_SALT', 'SENTRY_AUTH_TOKEN'];
  const leaks: string[] = [];
  for (const f of text) {
    const c = readFileSync(f, 'utf8');
    for (const [label, re] of patterns) if (re.test(c)) leaks.push(`${label} in ${f.replace(dist, 'dist')}`);
    for (const k of literal) {
      const v = env[k];
      if (v && v.length >= 12 && c.includes(v)) leaks.push(`valore di ${k} in ${f.replace(dist, 'dist')}`);
    }
  }
  add('SECRETS', 'nessun segreto nel bundle frontend', leaks.length ? 'FAIL' : 'PASS', leaks.length ? leaks.slice(0, 5).join('; ') : `${text.length} file analizzati`);
  const maps = files.filter((f) => f.endsWith('.map'));
  add('BUILD', 'nessuna source map pubblica', maps.length ? 'WARN' : 'PASS', maps.length ? `${maps.length} file .map (caricali su Sentry e non pubblicarli)` : '');
  // JS iniziale = script d'ingresso + modulepreload dichiarati in index.html (i chunk lazy non contano)
  const html = readFileSync(join(dist, 'index.html'), 'utf8');
  const initialRefs = [...html.matchAll(/(?:src|href)="\/(assets\/[^"]+\.js)"/g)].map((m) => join(dist, m[1]));
  const initialKb = initialRefs.reduce((s, f) => s + statSync(f).size, 0) / 1024;
  add('PERFORMANCE', 'bundle iniziale (JS in index.html, non compresso)', initialKb > 900 ? 'WARN' : 'PASS', `${Math.round(initialKb)} KB (budget 900 KB; la build DEMO include il database DEMO e supera il budget: in produzione ~714 KB)`);
  const demoInBundle = text.some((f) => readFileSync(f, 'utf8').includes('asiafood-demo-db'));
  if (env.VITE_SUPABASE_URL) add('DEMO', 'codice DEMO escluso dal bundle', demoInBundle ? 'FAIL' : 'PASS');

  // SEO
  const sm = existsSync(join(dist, 'sitemap.xml')) ? readFileSync(join(dist, 'sitemap.xml'), 'utf8') : '';
  add('SEO', 'sitemap index', sm.includes('<sitemapindex') ? 'PASS' : 'FAIL', sm ? `${(sm.match(/<sitemap>/g) ?? []).length} sitemap` : 'mancante');
  const allSm = files.filter((f) => /sitemap-.*\.xml$/.test(f)).map((f) => readFileSync(f, 'utf8')).join('');
  const privateInSm = ['/admin', '/dashboard', '/cart', '/checkout', '/orders/', '/assistant/session', '/rider/delivery', '/settings'].filter((p) => allSm.includes(`${p}`) && new RegExp(`<loc>[^<]*${p.replace('/', '\\/')}`).test(allSm));
  add('SEO', 'sitemap senza aree private', privateInSm.length ? 'FAIL' : 'PASS', privateInSm.join(', '));
  const robots = existsSync(join(dist, 'robots.txt')) ? readFileSync(join(dist, 'robots.txt'), 'utf8') : '';
  add('SEO', 'robots.txt', /Sitemap:\s*https:\/\//.test(robots) && /Disallow: \/admin/.test(robots) ? 'PASS' : target !== 'production' && /Disallow: \/$/m.test(robots) ? 'PASS' : 'FAIL',
    /Disallow: \/$/m.test(robots) ? 'staging: indicizzazione bloccata' : '');
  if (target === 'production' && /Disallow: \/$/m.test(robots)) add('SEO', 'robots in produzione', 'FAIL', 'robots.txt blocca tutto il sito');
  add('SEO', '_redirects (slug storici 301)', existsSync(join(dist, '_redirects')) ? 'PASS' : 'WARN');

  // PWA
  const mf = files.find((f) => f.endsWith('manifest.webmanifest'));
  if (mf) {
    const m = JSON.parse(readFileSync(mf, 'utf8')) as { name?: string; start_url?: string; display?: string; icons?: { sizes: string; purpose?: string }[]; theme_color?: string; lang?: string };
    const icons = m.icons ?? [];
    const ok = !!m.name && m.display === 'standalone' && !!m.start_url && icons.some((i) => i.sizes === '192x192') && icons.some((i) => i.sizes === '512x512') && icons.some((i) => i.purpose?.includes('maskable')) && !!m.theme_color;
    add('PWA', 'manifest (nome, icone 192/512/maskable, standalone, tema)', ok ? 'PASS' : 'FAIL');
    for (const i of icons) {
      const p = join(dist, (i as { src?: string }).src ?? '');
      if (!existsSync(p)) add('PWA', `icona ${(i as { src?: string }).src}`, 'FAIL', 'file mancante');
    }
  } else add('PWA', 'manifest', 'FAIL', 'manifest.webmanifest mancante');
  const sw = existsSync(join(dist, 'sw.js')) ? readFileSync(join(dist, 'sw.js'), 'utf8') : '';
  add('PWA', 'service worker', sw ? 'PASS' : 'FAIL');
  add('PWA', 'nessuna cache di API private nel service worker', sw && /NetworkOnly/.test(sw) ? 'PASS' : 'WARN');
}

// ─── 5. Header di sicurezza (netlify.toml) ───
{
  const toml = readFileSync(join(root, 'netlify.toml'), 'utf8');
  for (const h of ['Content-Security-Policy', 'Strict-Transport-Security', 'X-Content-Type-Options', 'Referrer-Policy', 'Permissions-Policy', "frame-ancestors 'none'"]) {
    add('HEADERS', h, toml.includes(h) ? 'PASS' : 'FAIL');
  }
  const cspValue = /Content-Security-Policy\s*=\s*"([^"]*)"/.exec(toml)?.[1] ?? '';
  add('HEADERS', "CSP senza 'unsafe-eval'", /unsafe-eval/.test(cspValue) ? 'FAIL' : 'PASS');
  const gi = readFileSync(join(root, '.gitignore'), 'utf8');
  add('GIT', '.env e credenziali ignorati da git', ['.env', '.env.local', '.env.production', '*.pem', 'service-account*.json'].every((p) => gi.includes(p)) ? 'PASS' : 'FAIL');
  add('GIT', '.env.example senza valori reali', /(sk_live_[A-Za-z0-9]{10}|sk_test_[A-Za-z0-9]{10}|rk_live_[A-Za-z0-9]{10}|whsec_[A-Za-z0-9]{8}|eyJ[A-Za-z0-9_-]{20})/.test(readFileSync(join(root, '.env.example'), 'utf8')) ? 'FAIL' : 'PASS');
}

// ─── 6. Controlli online (facoltativi) ───
if (args.has('--online')) {
  const url = env.SUPABASE_URL || env.VITE_SUPABASE_URL;
  const key = env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) add('ONLINE', 'database', 'SKIP', 'servono SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY');
  else {
    const h = { apikey: key, Authorization: `Bearer ${key}` };
    try {
      const s = (await (await fetch(`${url}/rest/v1/platform_settings?select=key,value&key=in.(show_demo_data,maintenance_mode,support_email,legal_company_name)`, { headers: h })).json()) as { key: string; value: unknown }[];
      const get = (k: string) => s.find((x) => x.key === k)?.value;
      add('ONLINE', 'dati DEMO nascosti (show_demo_data=false)', get('show_demo_data') === false ? 'PASS' : target === 'production' ? 'FAIL' : 'WARN');
      add('ONLINE', 'manutenzione disattiva', get('maintenance_mode') === true ? 'WARN' : 'PASS');
      add('ONLINE', 'email di supporto', get('support_email') ? 'PASS' : 'FAIL');
      add('ONLINE', 'ragione sociale nel footer', get('legal_company_name') ? 'PASS' : target === 'production' ? 'FAIL' : 'WARN');
      const demo = (await (await fetch(`${url}/rest/v1/restaurants?select=id&is_demo=eq.true&is_active=eq.true`, { headers: { ...h, Prefer: 'count=exact', Range: '0-0' } })).headers.get('content-range')) ?? '';
      const n = Number(demo.split('/')[1] ?? 0);
      add('ONLINE', 'locali DEMO attivi', n === 0 ? 'PASS' : target === 'production' ? 'FAIL' : 'WARN', `${n}`);
      const checks = (await (await fetch(`${url}/rest/v1/launch_checks?select=key,status,last_checked_at&source=eq.system`, { headers: h })).json()) as { key: string; status: string }[];
      add('ONLINE', 'controlli di sistema (cron)', checks.length ? (checks.some((c) => c.status === 'fail') ? 'FAIL' : 'PASS') : 'WARN',
        checks.length ? checks.filter((c) => c.status !== 'pass').map((c) => `${c.key}=${c.status}`).join(', ') || 'tutti OK' : 'il cron di sistema non ha ancora registrato controlli');
    } catch {
      add('ONLINE', 'database', 'FAIL', 'non raggiungibile');
    }
  }
}

const fails = results.filter((r) => r.status === 'FAIL').length;
const warns = results.filter((r) => r.status === 'WARN').length;
console.log(`\n${results.length} controlli · ${results.filter((r) => r.status === 'PASS').length} PASS · ${warns} WARN · ${fails} FAIL`);
console.log(fails ? '✗ NON pronto: risolvi i FAIL prima del deploy.\n' : warns ? '! Pronto con avvertenze.\n' : '✓ Pronto.\n');
process.exit(fails ? 1 : 0);
