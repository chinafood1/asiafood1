-- ─────────────────────────────────────────────────────────────
--  Piani di esecuzione delle query critiche — ESEGUIRE SOLO SU STAGING (dati realistici, mai su produzione).
--  psql "$STAGING_DATABASE_URL" -f scripts/ops/explain-critical.sql > explain-$(date +%F).txt
--  Cosa cercare: "Seq Scan" su tabelle grandi, "Rows Removed by Filter" elevati, tempi > 50 ms.
-- ─────────────────────────────────────────────────────────────
\set ON_ERROR_STOP on
begin;
set local statement_timeout = '15s';
set local role authenticated;
select set_config('request.jwt.claim.role', 'anon', true);

\echo '── 1. Ricerca ristoranti (testo + città)'
explain (analyze, buffers, format text)
select id, slug, name from public.restaurants
 where is_active and search_vector @@ plainto_tsquery('italian', 'sushi') and city_id = (select id from public.cities where slug = 'taranto')
 order by popularity_score desc limit 24;

\echo '── 2. Ricerca per nome (trigram)'
explain (analyze, buffers) select id from public.restaurants where is_active and name ilike '%ramen%' limit 24;

\echo '── 3. Mappa: bounding box'
explain (analyze, buffers)
select id, latitude, longitude from public.restaurants
 where is_active and latitude between 40.3 and 40.6 and longitude between 17.0 and 17.5 limit 500;

\echo '── 4. Vicino a te (nearby_restaurants)'
explain (analyze, buffers) select * from public.nearby_restaurants(40.4644, 17.247, 10, 50);

\echo '── 5. Menu di un locale'
explain (analyze, buffers)
select c.id, i.id from public.menu_categories c join public.menu_items i on i.menu_category_id = c.id
 where c.restaurant_id = (select id from public.restaurants where is_active limit 1) order by c.sort_order, i.sort_order;

\echo '── 6. Disponibilità prenotazioni'
explain (analyze, buffers)
select count(*) from public.reservations where restaurant_id = (select id from public.restaurants limit 1)
 and reservation_date = current_date and status in ('pending', 'confirmed');

\echo '── 7. Dashboard ordini del ristorante'
explain (analyze, buffers)
select id, status, total from public.orders where restaurant_id = (select id from public.restaurants limit 1)
 order by created_at desc limit 100;

\echo '── 8. Dispatch Rider: candidati online con posizione fresca'
explain (analyze, buffers)
select rider_id from public.rider_availability where is_online and accepting_orders and last_location_at > now() - interval '3 minutes';

\echo '── 9. Analytics: riepilogo 30 giorni per locale'
explain (analyze, buffers)
select event_type, count(*) from public.analytics_events
 where restaurant_id = (select id from public.restaurants limit 1) and created_at > now() - interval '30 days' group by 1;

\echo '── 10. CRM / lead: modulo non presente in questa versione (nessuna query)'
rollback;

\echo '── Indici mai usati (dopo almeno 1–2 settimane di traffico reale)'
select relname as tabella, indexrelname as indice, idx_scan, pg_size_pretty(pg_relation_size(indexrelid)) as dimensione
  from pg_stat_user_indexes where schemaname = 'public' and idx_scan = 0 order by pg_relation_size(indexrelid) desc limit 30;
\echo '── Tabelle con molte scansioni sequenziali'
select relname, seq_scan, idx_scan, n_live_tup from pg_stat_user_tables where schemaname = 'public' and seq_scan > idx_scan and n_live_tup > 1000 order by seq_scan desc limit 20;
