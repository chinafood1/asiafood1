#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  Backup manuale del database Postgres (Supabase) — complementare ai backup automatici della piattaforma.
#  Nessuna credenziale nello script: la connessione arriva da DATABASE_URL (Supabase → Project Settings →
#  Database → Connection string, modalità "Session"), da impostare solo nella shell corrente.
#
#  Uso:   DATABASE_URL='postgresql://…' ./scripts/ops/backup-db.sh [cartella]
#  Esito: <cartella>/asiafood-<env>-<data>.dump (formato custom, compresso) + checksum SHA-256
#  Il file contiene DATI PERSONALI: cifralo (es. age/gpg) prima di spostarlo fuori dal computer di lavoro.
# ─────────────────────────────────────────────────────────────
set -euo pipefail
: "${DATABASE_URL:?Imposta DATABASE_URL (solo nella shell, mai in un file versionato)}"
command -v pg_dump >/dev/null || { echo "pg_dump non trovato (installa PostgreSQL client ≥ 15)"; exit 1; }
OUT_DIR="${1:-./backups}"
ENV_NAME="${APP_ENV:-unknown}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$OUT_DIR"
chmod 700 "$OUT_DIR"
FILE="$OUT_DIR/asiafood-$ENV_NAME-$STAMP.dump"
echo "→ Dump schema public + auth + storage (metadati) in $FILE"
pg_dump "$DATABASE_URL" --format=custom --compress=9 --no-owner --no-privileges \
  --schema=public --schema=auth --schema=storage --file="$FILE"
chmod 600 "$FILE"
sha256sum "$FILE" > "$FILE.sha256"
echo "✓ Backup completato: $(du -h "$FILE" | cut -f1). Verifica il restore su STAGING: scripts/ops/restore-staging.sh"
