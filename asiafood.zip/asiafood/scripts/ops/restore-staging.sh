#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  Test di restore su STAGING (mai su produzione). "Un backup non testato non è un backup."
#  Uso:  STAGING_DATABASE_URL='postgresql://…staging…' ./scripts/ops/restore-staging.sh backups/asiafood-production-….dump
#  Safeguard: rifiuta URL che contengono il ref del progetto di produzione (PRODUCTION_PROJECT_REF) e chiede conferma.
# ─────────────────────────────────────────────────────────────
set -euo pipefail
DUMP="${1:?Indica il file .dump}"
: "${STAGING_DATABASE_URL:?Imposta STAGING_DATABASE_URL}"
if [[ -n "${PRODUCTION_PROJECT_REF:-}" && "$STAGING_DATABASE_URL" == *"$PRODUCTION_PROJECT_REF"* ]]; then
  echo "✗ STAGING_DATABASE_URL punta al progetto di PRODUZIONE: restore annullato."; exit 1
fi
[[ -f "$DUMP.sha256" ]] && sha256sum -c "$DUMP.sha256"
read -r -p "Il database di STAGING verrà sovrascritto (schema public). Scrivi RESTORE-STAGING per continuare: " OK
[[ "$OK" == "RESTORE-STAGING" ]] || { echo "Annullato."; exit 1; }
START=$(date +%s)
pg_restore --dbname="$STAGING_DATABASE_URL" --clean --if-exists --no-owner --no-privileges --schema=public "$DUMP"
END=$(date +%s)
echo "✓ Restore completato in $((END-START)) s."
echo "  Verifiche: psql \"\$STAGING_DATABASE_URL\" -c 'select count(*) from public.restaurants; select count(*) from public.orders;'"
echo "  Poi: npm run production-check -- --env=staging --online  e annota data/durata in /admin/launch-checklist (backup_restore_test)."
