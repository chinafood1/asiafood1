/* eslint-disable @typescript-eslint/no-explicit-any */
// ─────────────────────────────────────────────────────────────
//  Test della Fase 9 (logistica Rider) sulle VERE migrazioni (PGlite)
//  con i VERI handler ordini/webhook e uno Stripe simulato.
//  Uso: npm run test:logistics
// ─────────────────────────────────────────────────────────────
import { stripeWebhook } from '../server/billing/handlers';
import type { BillingDeps, HttpResponse } from '../server/billing/types';
import { logisticsAction, logisticsCron, type LogisticsDeps } from '../server/logistics/handlers';
import { createOrder } from '../server/orders/handlers';
import type { OrdersDeps } from '../server/orders/types';
import { FakeStripe, type FakeEvent } from './lib/fake-stripe';
import { createTestDb } from './lib/pglite-db';

const { db, store } = await createTestDb();
const stripe = new FakeStripe();
const WEBHOOK_SECRET = 'whsec_test_logistics';
const log = () => undefined;

let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) { pass++; console.log('  ✓', name); } else { fail++; console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 700) : ''); }
}
const section = (t: string) => console.log(`\n── ${t}`);

async function as(user: string | null, sql: string, params: unknown[] = []) {
  const r = user ? 'authenticated' : 'anon';
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${user ?? ''}', false); select set_config('request.jwt.claim.role', '${r}', false); set role ${r};`);
  try {
    const res = await db.query<any>(sql, params);
    return { ok: true as const, rows: res.rows, err: '' };
  } catch (e) {
    return { ok: false as const, rows: [] as any[], err: (e as Error).message };
  } finally {
    await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', '', false);`);
  }
}
const q1 = async (sql: string, params: unknown[] = []) => (await db.query<any>(sql, params)).rows[0];
const val = async (sql: string, params: unknown[] = []) => Object.values((await q1(sql, params)) ?? {})[0] as any;
const rpc1 = async (user: string | null, fn: string, args: unknown[] = []) => {
  const r = await as(user, `select public.${fn}(${args.map((_, i) => `$${i + 1}`).join(', ')}) as r`, args.map((a) => (a !== null && typeof a === 'object' ? JSON.stringify(a) : a)));
  return { ok: r.ok, r: r.rows[0]?.r, err: r.err };
};

const U = {
  admin: 'a1111111-1111-4111-8111-111111111111',
  owner: 'a2222222-2222-4222-8222-222222222222',
  alice: 'a3333333-3333-4333-8333-333333333333',
  bob: 'a4444444-4444-4444-8444-444444444444',
  r1: 'a5555555-5555-4555-8555-555555555555',
  r2: 'a6666666-6666-4666-8666-666666666666',
  r3: 'a7777777-7777-4777-8777-777777777777',
  intruder: 'a8888888-8888-4888-8888-888888888888',
  owner2: 'a9999999-9999-4999-8999-999999999999',
};
for (const [k, id] of Object.entries(U)) {
  await db.query(`insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values ($1, $2, $3, now())`, [id, `${k}@test.it`, JSON.stringify({ full_name: `${k} Test` })]);
}
await db.exec(`update public.profiles set role = 'admin' where id = '${U.admin}';`);
const R = (n: number) => `e0000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const SEOUL = R(5);
const KOEN = R(2);
await db.exec(`
insert into public.restaurant_members (restaurant_id, user_id, role, status) values ('${SEOUL}', '${U.owner}', 'owner', 'active'), ('${KOEN}', '${U.owner2}', 'owner', 'active');
delete from public.restaurant_hours where restaurant_id = '${SEOUL}';
insert into public.restaurant_hours (restaurant_id, day_of_week, opens_at, closes_at, is_closed) select '${SEOUL}', d, '00:00', '00:00', false from generate_series(1, 7) d;
update public.platform_settings set value = 'true' where key = 'marketplace_platform_collection_test';
`);
await store.rpc('billing_set_environment', { p_env: 'test' });

const ordersDeps: OrdersDeps = {
  stripe: stripe.asStripe(), store, config: { env: 'test', appUrl: 'https://asiafood.test', tokenSecret: 'secret-test' },
  verifyUser: async (t) => (t?.startsWith('tok-') ? t.slice(4) : null), log,
};
const billingDeps: BillingDeps = {
  stripe: stripe.asStripe(), store,
  config: { env: 'test', appUrl: 'https://asiafood.test', webhookSecret: WEBHOOK_SECRET, taxEnabled: false, portalConfigurationId: null, allowPromotionCodes: false },
  verifyUser: ordersDeps.verifyUser, log,
};
async function deliver(events: FakeEvent[] = stripe.drain()) {
  const out: HttpResponse[] = [];
  for (const e of events) {
    const { payload, header } = stripe.sign(e, WEBHOOK_SECRET);
    out.push(await stripeWebhook({ method: 'POST', header: (n) => (n === 'stripe-signature' ? header : null), body: payload }, billingDeps));
  }
  return out;
}

const rest = await q1(`select latitude, longitude from public.restaurants where id = $1`, [SEOUL]);
const at = (kmNorth: number, kmEast = 0) => ({ latitude: rest.latitude + kmNorth / 111.2, longitude: rest.longitude + kmEast / (111.2 * Math.cos((rest.latitude * Math.PI) / 180)) });
const URA = await q1(`select id from public.menu_items where restaurant_id = $1 and name = 'Uramaki salmone e avocado'`, [SEOUL]);
const V8 = await val(`select id from public.menu_item_variants where menu_item_id = $1 and name = '8 pezzi'`, [URA.id]);
let ipN = 0;
let seq = 0;
/** Ordine delivery pagato (cliente registrato o ospite). */
async function paidOrder(user: string | null = U.alice, km = 1.5) {
  const key = `lg-${Date.now()}-${++seq}`;
  const body = {
    restaurant_id: SEOUL, order_type: 'delivery', items: [{ menu_item_id: URA.id, variant_id: V8, quantity: 2 }], session_id: `s-${key}`, idempotency_key: key,
    address: { recipient_name: 'Alice Test', phone: '+39 333 1112223', address_line_1: 'Via Dante 10', address_line_2: 'Int. 4', city: 'Taranto', postal_code: '74121', ...at(km), geocode_source: 'geocoder', delivery_notes: 'Citofono Test' },
    contact: { name: 'Alice Rossi', email: `alice${seq}@test.it`, phone: '+39 333 1112223' },
  };
  const res = await createOrder({ method: 'POST', header: (n) => (n === 'authorization' && user ? `Bearer tok-${user}` : n === 'x-nf-client-connection-ip' ? `198.51.100.${++ipN}` : null), body: JSON.stringify(body) }, ordersDeps);
  const j = res.body as any;
  if (!j.ok) throw new Error(`createOrder: ${JSON.stringify(j)}`);
  const o = await q1(`select * from public.orders where id = $1`, [j.order_id]);
  stripe.payIntent(o.stripe_payment_intent_id);
  await deliver();
  return { id: j.order_id as string, number: j.order_number as string, token: j.access_token as string };
}
const accept = (orderId: string) => rpc1(U.owner, 'order_action', [orderId, 'accept', { preparation_minutes: 20 }]);
const jobOf = (orderId: string) => q1(`select * from public.delivery_jobs where order_id = $1`, [orderId]);
const riderId = (user: string) => val(`select id from public.rider_profiles where user_id = $1`, [user]);
/** Posizione del Rider (retrodata l'ultima per non incorrere nel limite di frequenza del test). */
async function loc(user: string, p: { latitude: number; longitude: number }, extra: Record<string, unknown> = {}) {
  await db.query(`update public.rider_availability set last_location_at = last_location_at - interval '5 minutes' where rider_id = (select id from public.rider_profiles where user_id = $1) and last_location_at is not null`, [user]);
  return rpc1(user, 'rider_location', [{ ...p, accuracy: 15, recorded_at: new Date().toISOString(), ...extra }]);
}
const offeredUser = (job: string) => val(`select r.user_id from public.delivery_assignments a join public.rider_profiles r on r.id = a.rider_id where a.delivery_job_id = $1 and a.status = 'offered'`, [job]);
const home = async (user: string) => (await rpc1(user, 'rider_home')).r;
const act = (user: string, job: string, action: string, p: Record<string, unknown> = {}) => rpc1(user, 'rider_job_action', [job, action, p]);

// ════════════════════════════════════════════════════════════════════
section('Ristorante: Rider AsiaFood solo se abilitato dall\'Admin');
let r = await as(U.owner, `update public.restaurant_order_settings set delivery_provider_type = 'asiafood' where restaurant_id = $1`, [SEOUL]);
check('owner non può scegliere "asiafood" se non abilitato', !r.ok && /non sono ancora attive/.test(r.err), r.err);
r = await as(U.owner, `update public.restaurant_order_settings set asiafood_delivery_enabled = true where restaurant_id = $1`, [SEOUL]);
check('owner non può abilitarsi da solo (campo protetto)', (await val(`select asiafood_delivery_enabled from public.restaurant_order_settings where restaurant_id = $1`, [SEOUL])) === false);
check('admin abilita i Rider AsiaFood per Seoul', (await rpc1(U.admin, 'admin_restaurant_logistics', [SEOUL, true])).ok);
r = await as(U.owner, `update public.restaurant_order_settings set delivery_provider_type = 'asiafood' where restaurant_id = $1`, [SEOUL]);
check('owner sceglie delivery_provider_type = asiafood', r.ok, r.err);
let q = (await as(null, `select public.order_quote($1::jsonb) q`, [JSON.stringify({ restaurant_id: SEOUL, order_type: 'delivery', items: [{ menu_item_id: URA.id, variant_id: V8, quantity: 2 }], address: { ...at(1.5) } })])).rows[0].q;
check('preventivo AsiaFood: indirizzo in zona servita → ok', q.ok, q.errors);
await db.exec(`update public.delivery_service_zones set is_active = false`);
q = (await as(null, `select public.order_quote($1::jsonb) q`, [JSON.stringify({ restaurant_id: SEOUL, order_type: 'delivery', items: [{ menu_item_id: URA.id, variant_id: V8, quantity: 2 }], address: { ...at(1.5) } })])).rows[0].q;
check('zona non servita → OUTSIDE_AREA con messaggio Rider', !q.ok && q.errors.some((e: any) => e.code === 'OUTSIDE_AREA' && e.provider === 'asiafood'), q.errors);
await db.exec(`update public.delivery_service_zones set is_active = true`);
await db.exec(`update public.platform_settings set value = 'false' where key = 'logistics_enabled'`);
q = (await as(null, `select public.order_quote($1::jsonb) q`, [JSON.stringify({ restaurant_id: SEOUL, order_type: 'delivery', items: [{ menu_item_id: URA.id, variant_id: V8, quantity: 2 }], address: { ...at(1.5) } })])).rows[0].q;
check('servizio Rider disattivato → consegna non disponibile (resta il ritiro)', !q.ok && JSON.stringify(q.errors).includes('Rider AsiaFood non sono disponibili'));
await db.exec(`update public.platform_settings set value = 'true' where key = 'logistics_enabled'`);

section('Candidatura Rider e approvazione Admin');
const apply = (user: string, extra: Record<string, unknown> = {}) => rpc1(user, 'rider_apply', [{ first_name: 'Marco', last_name: 'Bianchi', phone: '+39 320 1234567', city_slug: 'taranto', vehicle_type: 'scooter', terms_accepted: true, ...extra }]);
r = await as(U.r1, `insert into public.rider_profiles (user_id, status, first_name, last_name, phone, email, city, vehicle_type, terms_accepted_at) values ($1, 'active', 'X', 'Y', '3331234567', 'x@y.it', 'Taranto', 'car', now())`, [U.r1]);
check('nessuna scrittura diretta su rider_profiles dal browser', !r.ok);
let x = await apply(U.r1, { terms_accepted: false });
check('termini non accettati → rifiuto', !x.ok && /termini/.test(x.err));
x = await apply(U.r1);
check('candidatura inviata (pending, mai approvata automaticamente)', x.ok && x.r.status === 'pending', x.err);
check('ruolo NON cambiato alla candidatura', (await val(`select role from public.profiles where id = $1`, [U.r1])) === 'customer');
x = await apply(U.r1);
check('seconda candidatura bloccata', !x.ok && /già inviato/.test(x.err));
x = await rpc1(U.r1, 'rider_document_add', ['identity', `${U.r1}/doc-id.pdf`, null]);
check('documento registrato (path nella propria cartella privata)', x.ok, x.err);
x = await rpc1(U.r1, 'rider_document_add', ['identity', `${U.r2}/altrui.pdf`, null]);
check('documento in cartella altrui → rifiutato', !x.ok);
x = await rpc1(U.r1, 'rider_set_online', [true, true, true]);
check('Rider in attesa non può andare online', !x.ok && /non è attivo/.test(x.err));
x = await rpc1(U.r1, 'admin_rider_action', [await riderId(U.r1), 'approve', null]);
check('un Rider non può approvarsi da solo', !x.ok);
await as(U.r1, `update public.profiles set role = 'rider' where id = $1`, [U.r1]);
check('un utente non può assegnarsi il ruolo rider', (await val(`select role from public.profiles where id = $1`, [U.r1])) === 'customer');
for (const u of [U.r1, U.r2, U.r3]) {
  if (u !== U.r1) await apply(u, { first_name: u === U.r2 ? 'Luca' : 'Sara', vehicle_type: u === U.r2 ? 'e-bike' : 'car' });
  x = await rpc1(U.admin, 'admin_rider_action', [await riderId(u), 'approve', null]);
  if (!x.ok) console.log(x.err);
}
check('Admin approva: status approved + ruolo rider', (await val(`select status from public.rider_profiles where user_id = $1`, [U.r1])) === 'approved' && (await val(`select role from public.profiles where id = $1`, [U.r1])) === 'rider');
check('audit log dell\'approvazione', (await val(`select count(*)::int from public.admin_audit_logs where action = 'rider_approve'`)) === 3);
x = await rpc1(U.admin, 'admin_document_review', [await val(`select id from public.rider_documents limit 1`), 'approved', null]);
check('Admin approva un documento', x.ok);
const list = (await rpc1(U.admin, 'admin_riders', [{}])).r;
check('/admin/riders: elenco con documenti e stato', list.length === 3 && list.some((y: any) => y.documents === 1), list);
check('un Rider non vede l\'elenco Rider', !(await rpc1(U.r1, 'admin_riders', [{}])).ok);
x = await apply(U.intruder);
check('candidato non approvato (intruso) creato', x.ok);

section('Online, consenso posizione, tracking solo online');
x = await rpc1(U.r1, 'rider_set_online', [true, true, false]);
check('online senza consenso alla posizione → richiesto', !x.ok && /autorizzare/.test(x.err));
x = await rpc1(U.r1, 'rider_set_online', [true, true, true]);
check('online con consenso', x.ok && x.r.is_online, x.err);
check('status passa ad active al primo turno', (await val(`select status from public.rider_profiles where user_id = $1`, [U.r1])) === 'active');
x = await loc(U.r1, at(0.5));
check('posizione accettata mentre online', x.ok && x.r.accepted, x);
x = await rpc1(U.r1, 'rider_location', [{ ...at(0.5), accuracy: 10, recorded_at: new Date().toISOString() }]);
check('frequenza limitata: posizione troppo ravvicinata scartata', x.r?.accepted === false && x.r.reason === 'TOO_FREQUENT', x.r);
x = await loc(U.r1, at(0.5), { recorded_at: new Date(Date.now() - 10 * 60_000).toISOString() });
check('timestamp vecchio scartato', x.r?.accepted === false && x.r.reason === 'STALE');
x = await loc(U.r1, at(40, 40));
check('salto geografico impossibile → segnalato, non usato, nessuna sospensione', x.r?.accepted === false && x.r.reason === 'ANOMALY'
  && (await val(`select status from public.rider_profiles where user_id = $1`, [U.r1])) === 'active'
  && (await val(`select count(*)::int from public.logistics_alerts where alert_type = 'location_anomaly'`)) === 1, x.r);
x = await loc(U.r1, at(0.5), { accuracy: 800 });
check('precisione bassa → flag low_accuracy', x.r?.accepted && x.r.flags.includes('low_accuracy'));
await rpc1(U.r2, 'rider_set_online', [true, true, true]);
await loc(U.r2, at(2.5));
await rpc1(U.r3, 'rider_set_online', [true, true, true]);
await loc(U.r3, at(0, 7));
x = await rpc1(U.intruder, 'rider_location', [{ ...at(0.1), recorded_at: new Date().toISOString() }]);
check('utente non Rider non può inviare posizioni', !x.ok);
r = await as(U.r2, `select count(*)::int n from public.rider_locations`);
check('un Rider vede solo le proprie posizioni', r.rows[0].n === (await val(`select count(*)::int from public.rider_locations where rider_id = $1`, [await riderId(U.r2)])));
r = await as(U.alice, `select count(*)::int n from public.rider_availability`);
check('un cliente non vede posizioni/disponibilità dei Rider', r.rows[0].n === 0);
r = await as(null, `select count(*)::int n from public.rider_locations`);
check('anonimo: nessun accesso alle posizioni', !r.ok || r.rows[0].n === 0);

section('Ordine AsiaFood → delivery job → dispatch automatico (raggio 3 km)');
const o1 = await paidOrder(U.alice, 1.5);
check('ordine pagato, provider asiafood', (await val(`select delivery_provider_type from public.orders where id = $1`, [o1.id])) === 'asiafood');
check('nessun job prima dell\'accettazione', !(await jobOf(o1.id)));
x = await accept(o1.id);
check('ristorante accetta', x.ok, x.err);
let j1 = await jobOf(o1.id);
check('delivery job creato con codici e coordinate', j1 && /^\d{4}$/.test(j1.pickup_code) && j1.delivery_latitude != null && Number(j1.estimated_distance_km) > 1, j1);
check('dispatch: offerta al Rider più vicino (r1 a 0,5 km, raggio 3 km)', j1.status === 'offered' && j1.search_radius_km == 3
  && (await val(`select rider_id from public.delivery_assignments where delivery_job_id = $1 and status = 'offered'`, [j1.id])) === (await riderId(U.r1)));
let h = await home(U.r1);
check('Rider riceve l\'offerta con ristorante, zona, distanza, compenso stimato', h.offer && h.offer.restaurant.name === 'Seoul Grill House' && h.offer.delivery_area.includes('74121')
  && Number(h.offer.estimated_earning) > 0 && h.offer.order_number === o1.number, h.offer);
check('offerta: nessun indirizzo completo del cliente prima dell\'accettazione', !JSON.stringify(h.offer).includes('Via Dante') && !JSON.stringify(h.offer).includes('Citofono'));
check('notifica push/in-app al Rider', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Nuova consegna disponibile'`, [U.r1])) === 1);
check('evento analytics delivery_offer_sent', (await val(`select count(*)::int from public.analytics_events where event_type = 'delivery_offer_sent'`)) >= 1);
check('r2 non vede offerte altrui', (await home(U.r2)).offer === null);
r = await as(U.r2, `select count(*)::int n from public.delivery_jobs`);
check('Rider non legge direttamente i delivery job', r.rows[0].n === 0);
x = await rpc1(U.r2, 'rider_offer_respond', [h.offer.assignment_id, true, null]);
check('un altro Rider non può accettare un\'offerta non sua', !x.ok);

section('Offerta scaduta → secondo Rider; rifiuto → terzo');
await db.query(`update public.delivery_assignments set expires_at = now() - interval '1 second' where delivery_job_id = $1 and status = 'offered'`, [j1.id]);
h = await home(U.r1);
check('offerta scaduta non più visibile a r1', h.offer === null);
check('assignment r1 = expired', (await val(`select status from public.delivery_assignments where delivery_job_id = $1 and rider_id = $2`, [j1.id, await riderId(U.r1)])) === 'expired');
const h2 = await home(U.r2);
check('offerta passata a r2 (raggio 3 km)', h2.offer?.order_number === o1.number, h2.offer);
x = await rpc1(U.r2, 'rider_offer_respond', [h2.offer.assignment_id, false, 'too_far']);
check('r2 rifiuta (motivo: troppo lontano)', x.ok && x.r.status === 'rejected');
j1 = await jobOf(o1.id);
const h3 = await home(U.r3);
check('raggio esteso a 8 km: offerta a r3', j1.status === 'offered' && Number(j1.search_radius_km) === 8 && h3.offer?.order_number === o1.number, { st: j1.status, radius: j1.search_radius_km });
check('nessuna penalità automatica sul rifiuto', (await val(`select status from public.rider_profiles where user_id = $1`, [U.r2])) === 'active');

section('Accettazione concorrente: un solo Rider ottiene il job');
// Offerta "parallela" simulata anche a r1 (es. broadcast futuro): entrambi accettano
await db.query(`insert into public.delivery_assignments (delivery_job_id, rider_id, status, expires_at) values ($1, $2, 'offered', now() + interval '1 minute')`, [j1.id, await riderId(U.r1)]);
const a1 = await val(`select id from public.delivery_assignments where delivery_job_id = $1 and rider_id = $2 and status = 'offered'`, [j1.id, await riderId(U.r1)]);
const ra = await rpc1(U.r1, 'rider_offer_respond', [a1, true, null]);
const rb = await rpc1(U.r3, 'rider_offer_respond', [h3.offer.assignment_id, true, null]);
check('primo accetta, secondo riceve "già assegnata"', ra.ok && !rb.ok && /già stata assegnata|non è più disponibile/.test(rb.err), { ra: ra.err, rb: rb.err });
j1 = await jobOf(o1.id);
check('job assegnato a r1, status assigned', j1.status === 'assigned' && j1.rider_id === (await riderId(U.r1)));
check('una sola assegnazione accettata', (await val(`select count(*)::int from public.delivery_assignments where delivery_job_id = $1 and status = 'accepted'`, [j1.id])) === 1);
check('capacità r1 = 1 (max 1): nessuna nuova offerta a r1', (await val(`select current_capacity from public.rider_availability where rider_id = $1`, [await riderId(U.r1)])) === 1);

section('Cliente: Rider assegnato, niente posizione prima del ritiro');
let tr = (await rpc1(U.alice, 'order_delivery', [o1.number, null])).r;
check('cliente vede il Rider (nome + iniziale, veicolo), nessuna email/telefono', tr.job.rider?.name === 'Marco B.' && tr.job.rider.vehicle_type === 'scooter' && !JSON.stringify(tr).includes('@test.it') && !JSON.stringify(tr).includes('320'), tr.job.rider);
check('posizione Rider NON mostrata prima del ritiro', tr.job.rider_position === null);
check('ETA come intervallo', tr.job.eta_min_at && tr.job.eta_max_at && Date.parse(tr.job.eta_max_at) > Date.parse(tr.job.eta_min_at));
check('notifica rider_assigned al cliente', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Rider assegnato'`, [U.alice])) === 1);
tr = (await rpc1(U.bob, 'order_delivery', [o1.number, null])).r;
check('un altro cliente non vede la consegna (né il Rider)', tr === null);
tr = (await rpc1(null, 'order_delivery', [o1.number, 'token-sbagliato'])).r;
check('ospite con token errato: nessun dato', tr === null);
const rd = (await rpc1(U.owner, 'restaurant_deliveries', [SEOUL])).r;
check('ristorante vede nome Rider, arrivo stimato e codice di ritiro', rd[0].rider.name === 'Marco B.' && rd[0].eta_pickup_at && rd[0].pickup_code === j1.pickup_code, rd[0]);
check('ristorante non autorizzato non vede le consegne', !(await rpc1(U.owner2, 'restaurant_deliveries', [SEOUL])).ok);
r = await as(U.owner, `select public.order_action($1, 'out_for_delivery', '{}'::jsonb)`, [o1.id]);
check('ristorante NON può mettere "in consegna" un ordine AsiaFood', !r.ok && /Rider AsiaFood/.test(r.err), r.err);

section('Rider: navigazione, arrivo, ritiro (codice), consegna');
let rj = (await rpc1(U.r1, 'rider_job', [j1.id])).r;
check('dopo l\'accettazione il Rider vede indirizzo e telefono del cliente', rj.customer.address.address_line_1 === 'Via Dante 10' && rj.customer.phone && rj.pickup_code_required === true && !('pickup_code' in rj));
check('r2 non può leggere la consegna di r1', !(await rpc1(U.r2, 'rider_job', [j1.id])).ok);
check('r2 non può modificare la consegna di r1', !(await act(U.r2, j1.id, 'arrived_restaurant')).ok);
x = await act(U.r1, j1.id, 'picked_up', { pickup_code: j1.pickup_code });
check('macchina a stati: ritiro prima dell\'arrivo → bloccato', !x.ok && /arrivato/.test(x.err));
check('depart → rider_to_restaurant', (await act(U.r1, j1.id, 'depart')).r?.status === 'rider_to_restaurant');
x = await loc(U.r1, { latitude: rest.latitude + 0.0005, longitude: rest.longitude });
check('entro 100 m dal ristorante: arrivo solo SUGGERITO', x.r.hint === 'near_restaurant' && (await jobOf(o1.id)).status === 'rider_to_restaurant');
check('arrivato al ristorante (conferma manuale)', (await act(U.r1, j1.id, 'arrived_restaurant')).r?.status === 'arrived_restaurant');
check('ristorante notificato dell\'arrivo', (await val(`select count(*)::int from public.notifications where user_id = $1 and title like 'Rider arrivato%'`, [U.owner])) === 1);
x = await act(U.r1, j1.id, 'not_ready');
check('"Ordine non pronto" registrato', x.ok && (await val(`select count(*)::int from public.delivery_events where delivery_job_id = $1 and event_type = 'order_not_ready'`, [j1.id])) === 1);
x = await act(U.r1, j1.id, 'picked_up', { pickup_code: '0000' === j1.pickup_code ? '1111' : '0000' });
check('codice di ritiro errato → rifiutato', !x.ok && /Codice di ritiro/.test(x.err));
x = await act(U.r1, j1.id, 'picked_up', { pickup_code: j1.pickup_code });
check('ritiro con codice corretto → in viaggio verso il cliente', x.ok && x.r.status === 'rider_to_customer', x.err);
let o1row = await q1(`select * from public.orders where id = $1`, [o1.id]);
check('ordine sincronizzato: out_for_delivery / fulfillment out_for_delivery', o1row.status === 'out_for_delivery' && o1row.fulfillment_status === 'out_for_delivery');
check('notifica order_picked_up al cliente', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Ordine ritirato'`, [U.alice])) === 1);
x = await loc(U.r1, at(0.8));
tr = (await rpc1(U.alice, 'order_delivery', [o1.number, null])).r;
check('dopo il ritiro il cliente vede la posizione del Rider', tr.job.rider_position && Math.abs(tr.job.rider_position.latitude - at(0.8).latitude) < 0.001, tr.job.rider_position);
const etaBefore = (await jobOf(o1.id)).eta_delivery_max_at;
x = await loc(U.r1, at(1.3));
check('ETA aggiornata dopo spostamento significativo (> 250 m)', String((await jobOf(o1.id)).eta_delivery_max_at) !== String(etaBefore));
const guest = (await rpc1(null, 'order_track', [o1.number, null])).r;
check('senza token/login: tracking ordine negato', guest === null);
x = await loc(U.r1, at(1.48));
check('vicino al cliente: suggerimento arrivo + notifica "Rider vicino"', x.r.hint === 'near_customer' && (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Il Rider è vicino'`, [U.alice])) === 1, x.r);
x = await loc(U.r1, at(1.49));
check('"Rider vicino" inviato una sola volta', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Il Rider è vicino'`, [U.alice])) === 1);
check('arrivato dal cliente', (await act(U.r1, j1.id, 'arrived_customer')).r?.status === 'arrived_customer');
x = await rpc1(U.r1, 'rider_set_online', [false, false, false]);
check('offline bloccato con consegna attiva', !x.ok && /consegna in corso/.test(x.err));
x = await act(U.r1, j1.id, 'delivered', {});
check('consegna completata (prova: conferma Rider)', x.ok && x.r.status === 'delivered', x.err);
o1row = await q1(`select * from public.orders where id = $1`, [o1.id]);
check('ordine completato (delivered)', o1row.status === 'completed' && o1row.fulfillment_status === 'delivered');
check('notifica di consegna al cliente', (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Ordine consegnato'`, [U.alice])) === 1);
const earn = await q1(`select * from public.rider_earnings where delivery_job_id = $1`, [j1.id]);
check('compenso registrato (pending) dalla regola configurata', earn && earn.status === 'pending' && Number(earn.total) >= 4, earn);
check('AsiaPoints per ordine completato', (await val(`select count(*)::int from public.loyalty_transactions where user_id = $1 and source_type = 'order'`, [U.alice])) === 1);
x = await act(U.r1, j1.id, 'picked_up', { pickup_code: j1.pickup_code });
check('delivered → picked_up bloccato', !x.ok);
check('capacità liberata', (await val(`select current_capacity from public.rider_availability where rider_id = $1`, [await riderId(U.r1)])) === 0);
const summ = (await rpc1(U.r1, 'rider_earnings_summary')).r;
check('/rider/earnings: oggi/settimana/mese/da pagare', Number(summ.today) === Number(earn.total) && Number(summ.to_pay) === Number(earn.total) && Number(summ.paid) === 0, summ);
h = await home(U.r1);
check('statistiche Rider: consegne, completamento, tempo medio', h.stats.completed === 1 && h.stats.total_deliveries === 1 && h.stats.avg_delivery_minutes != null, h.stats);
r = await as(U.r1, `update public.rider_earnings set total = 999 where id = $1`, [earn.id]);
check('Rider non può modificare i compensi', (await val(`select total from public.rider_earnings where id = $1`, [earn.id])) == earn.total);
x = await rpc1(U.alice, 'delivery_rate', [o1.number, 5, 'Veloce e gentile']);
check('valutazione consegna (una sola)', x.ok && !(await rpc1(U.alice, 'delivery_rate', [o1.number, 4, null])).ok);
check('rating interno aggiornato, non pubblico', Number(await val(`select rating_internal from public.rider_profiles where user_id = $1`, [U.r1])) === 5 && !(await as(null, `select rating_internal from public.rider_profiles`)).rows.length);
const detail = (await rpc1(U.admin, 'admin_job_detail', [j1.id])).r;
const evs = detail.events.map((e: any) => e.type);
check('Admin: timeline completa della consegna', ['created', 'offer_sent', 'offer_expired', 'offer_rejected', 'assigned', 'rider_to_restaurant', 'arrived_restaurant', 'order_not_ready', 'picked_up', 'rider_to_customer', 'arrived_customer', 'delivered'].every((t) => evs.includes(t)), evs);
check('Admin: tentativi di assegnazione (scaduta, rifiutata, accettata)', ['expired', 'rejected', 'accepted'].every((s) => detail.assignments.some((a: any) => a.status === s)));
check('Admin: tempo di attesa al ristorante calcolato', detail.waiting_minutes != null);
x = await rpc1(U.admin, 'admin_earning_action', [earn.id, 'approve', null, null]);
x = await rpc1(U.admin, 'admin_earning_action', [earn.id, 'mark_paid', null, 'Bonifico manuale #1']);
check('Admin: approva e registra pagato (nessun trasferimento automatico)', x.ok && (await val(`select status from public.rider_earnings where id = $1`, [earn.id])) === 'paid');

section('Codice di consegna (OTP) e ospite');
await db.exec(`update public.platform_settings set value = 'true' where key = 'logistics_delivery_code_required'`);
const o2 = await paidOrder(null, 1.0);
await accept(o2.id);
const j2 = await jobOf(o2.id);
check('OTP generato per il job', j2.delivery_code_required && /^\d{4}$/.test(j2.delivery_code));
h = await home(U.r1);
check('r1 (più vicino, libero) riceve l\'offerta', h.offer?.order_number === o2.number, h.offer);
await rpc1(U.r1, 'rider_offer_respond', [h.offer.assignment_id, true, null]);
await act(U.r1, j2.id, 'arrived_restaurant');
await act(U.r1, j2.id, 'picked_up', { pickup_code: j2.pickup_code });
tr = (await rpc1(null, 'order_delivery', [o2.number, o2.token])).r;
check('ospite con token vede codice di consegna e Rider', tr.job.delivery_code === j2.delivery_code && tr.job.rider?.name, tr.job);
check('ospite non può valutare (serve account)', tr.job.can_rate === false);
rj = (await rpc1(U.r1, 'rider_job', [j2.id])).r;
check('il Rider NON vede il codice di consegna', !JSON.stringify(rj).includes(`"${j2.delivery_code}"`) && rj.delivery_code_required === true);
x = await act(U.r1, j2.id, 'delivered', { delivery_code: j2.delivery_code === '9999' ? '0000' : '9999' });
check('OTP errato → consegna non chiusa', !x.ok && /Codice di consegna/.test(x.err));
x = await act(U.r1, j2.id, 'delivered', { delivery_code: j2.delivery_code });
check('OTP corretto → consegnato', x.ok && x.r.status === 'delivered', x.err);
await db.exec(`update public.platform_settings set value = 'false' where key = 'logistics_delivery_code_required'`);

section('Annullamento del Rider prima del ritiro → riassegnazione');
const o3 = await paidOrder(U.alice, 2.0);
await accept(o3.id);
let j3 = await jobOf(o3.id);
const firstUser = await offeredUser(j3.id);
await rpc1(firstUser, 'rider_offer_respond', [await val(`select id from public.delivery_assignments where delivery_job_id = $1 and status = 'offered'`, [j3.id]), true, null]);
x = await act(firstUser, j3.id, 'cancel', { reason: 'vehicle_problem' });
j3 = await jobOf(o3.id);
if (!x.ok) console.log('    cancel err:', x.err);
check('job torna in assegnazione e parte un nuovo dispatch (a un altro Rider)', x.ok && j3.status === 'offered' && j3.rider_id === null && j3.reassignment_count === 1
  && (await offeredUser(j3.id)) !== firstUser, j3);
check('audit della riassegnazione', (await val(`select count(*)::int from public.admin_audit_logs where action = 'delivery_reassignment' and entity_id = $1`, [j3.id])) === 1);
const off3 = await val(`select a.id from public.delivery_assignments a where a.delivery_job_id = $1 and a.status = 'offered'`, [j3.id]);
const offUser = await val(`select r.user_id from public.delivery_assignments a join public.rider_profiles r on r.id = a.rider_id where a.id = $1`, [off3]);
await rpc1(offUser, 'rider_offer_respond', [off3, true, null]);
await act(offUser, j3.id, 'arrived_restaurant');
await act(offUser, j3.id, 'picked_up', { pickup_code: j3.pickup_code });
x = await act(offUser, j3.id, 'cancel', { reason: 'x' });
check('dopo il ritiro l\'annullamento richiede il supporto', !x.ok && /Ho un problema/.test(x.err));

section('Cliente non disponibile e consegna fallita');
x = await act(offUser, j3.id, 'customer_unavailable', { step: 'called' });
check('"Cliente non disponibile": attesa registrata, cliente avvisato', x.ok && x.r.customer_wait_started_at && x.r.status === 'arrived_customer');
x = await act(offUser, j3.id, 'fail', { reason: 'customer_unavailable' });
check('non si può chiudere prima del tempo di attesa', !x.ok && /Attendi/.test(x.err));
x = await act(offUser, j3.id, 'customer_unavailable', { step: 'support' });
check('richiesta supporto → avviso Admin', (await val(`select count(*)::int from public.logistics_alerts where alert_type = 'customer_unavailable' and delivery_job_id = $1`, [j3.id])) === 1);
await db.query(`update public.delivery_jobs set customer_wait_started_at = now() - interval '11 minutes' where id = $1`, [j3.id]);
x = await act(offUser, j3.id, 'fail', { reason: 'customer_unavailable', description: 'Nessuna risposta al citofono' });
check('consegna fallita dopo l\'attesa: issue + avviso, ordine NON completato automaticamente', x.ok && x.r.status === 'failed'
  && (await val(`select status from public.orders where id = $1`, [o3.id])) === 'out_for_delivery'
  && (await val(`select count(*)::int from public.delivery_issues where delivery_job_id = $1`, [j3.id])) === 1
  && (await val(`select count(*)::int from public.logistics_alerts where alert_type = 'delivery_failed' and delivery_job_id = $1`, [j3.id])) === 1);
check('nessun compenso automatico per la consegna fallita', (await val(`select count(*)::int from public.rider_earnings where delivery_job_id = $1`, [j3.id])) === 0);
x = await rpc1(U.admin, 'admin_earning_create', [j3.id, 3.5, 'Attesa al cliente riconosciuta']);
check('Admin registra un compenso esplicito (audit)', x.ok && (await val(`select count(*)::int from public.admin_audit_logs where action = 'earning_adjustment'`)) === 1);

section('Nessun Rider disponibile, dispatch manuale, sospensione');
for (const u of [U.r1, U.r2, U.r3]) await rpc1(u, 'rider_set_online', [false, false, false]);
check('offline: ultima posizione cancellata (tracking disattivato)', (await val(`select count(*)::int from public.rider_availability where last_latitude is not null`)) === 0);
x = await loc(U.r1, at(0.2));
check('Rider offline: posizione rifiutata', x.r?.accepted === false && x.r.reason === 'OFFLINE');
const o4 = await paidOrder(U.alice, 1.2);
await accept(o4.id);
let j4 = await jobOf(o4.id);
check('nessun Rider: job in attesa + avviso "no_rider"', j4.status === 'waiting_assignment' && (await val(`select count(*)::int from public.logistics_alerts where alert_type = 'no_rider' and delivery_job_id = $1`, [j4.id])) === 1);
check('evento delivery_assignment_failed', (await val(`select count(*)::int from public.analytics_events where event_type = 'delivery_assignment_failed'`)) >= 1);
tr = (await rpc1(U.owner, 'restaurant_deliveries', [SEOUL])).r.find((d: any) => d.order_id === o4.id);
check('ristorante: "Ricerca Rider in corso"', tr.status === 'waiting_assignment' && tr.searching_since && tr.rider === null);
await rpc1(U.r2, 'rider_set_online', [true, true, true]);
await loc(U.r2, at(9, 0));
const board = (await rpc1(U.admin, 'admin_dispatch_board')).r;
check('control center: consegne da assegnare + Rider online con posizione (solo Admin)', board.jobs.some((b: any) => b.id === j4.id) && board.riders.length === 1 && board.riders[0].latitude != null);
check('control center negato ai non Admin', !(await rpc1(U.r2, 'admin_dispatch_board')).ok && !(await rpc1(U.owner, 'admin_dispatch_board')).ok);
x = await rpc1(U.admin, 'admin_assign_job', [j4.id, await riderId(U.r2)]);
j4 = await jobOf(o4.id);
check('assegnazione manuale (fuori raggio automatico) + audit', x.ok && j4.status === 'assigned' && j4.rider_id === (await riderId(U.r2))
  && (await val(`select count(*)::int from public.admin_audit_logs where action = 'delivery_manual_assignment'`)) === 1, x.err);
check('avvisi "nessun Rider" risolti dopo l\'assegnazione', (await val(`select count(*)::int from public.logistics_alerts where delivery_job_id = $1 and status <> 'resolved' and alert_type = 'no_rider'`, [j4.id])) === 0);
x = await rpc1(U.admin, 'admin_rider_action', [await riderId(U.r2), 'suspend', 'Documenti scaduti']);
j4 = await jobOf(o4.id);
check('sospensione: Rider offline, job non ritirato torna in assegnazione, audit', x.ok && j4.rider_id === null && ['waiting_assignment', 'offered'].includes(j4.status)
  && (await val(`select is_online from public.rider_availability where rider_id = $1`, [await riderId(U.r2)])) === false
  && (await val(`select count(*)::int from public.admin_audit_logs where action = 'rider_suspend'`)) === 1, x.err);
x = await rpc1(U.r2, 'rider_set_online', [true, true, true]);
check('Rider sospeso non può andare online', !x.ok);
check('Rider sospeso non può leggere la vecchia consegna', !(await rpc1(U.r2, 'rider_job', [j4.id])).ok);
x = await rpc1(U.admin, 'admin_rider_action', [await riderId(U.r2), 'reactivate', null]);
check('riattivazione', x.ok && (await val(`select status from public.rider_profiles where user_id = $1`, [U.r2])) === 'approved');

section('Annullamento ordine con Rider in viaggio');
await rpc1(U.r1, 'rider_set_online', [true, true, true]);
await loc(U.r1, at(0.3));
x = await rpc1(U.admin, 'logistics_tick', [new Date().toISOString()]);
j4 = await jobOf(o4.id);
check('scheduler: dispatch dei job in attesa', x.ok && j4.status === 'offered', { tick: x.r, status: j4.status });
h = await home(U.r1);
await rpc1(U.r1, 'rider_offer_respond', [h.offer.assignment_id, true, null]);
await act(U.r1, j4.id, 'depart');
x = await rpc1(U.admin, 'order_action', [o4.id, 'cancel', { reason: 'Richiesta del cliente' }]);
j4 = await jobOf(o4.id);
check('ordine annullato: job cancellato, Rider avvisato, capacità liberata', x.ok && j4.status === 'cancelled'
  && (await val(`select count(*)::int from public.notifications where user_id = $1 and title = 'Consegna annullata'`, [U.r1])) === 1
  && (await val(`select current_capacity from public.rider_availability where rider_id = $1`, [await riderId(U.r1)])) === 0, x.err);
check('conseguenza economica registrata come avviso (nessun compenso improvvisato)', (await val(`select count(*)::int from public.logistics_alerts where alert_type = 'cancelled_with_rider' and delivery_job_id = $1`, [j4.id])) === 1
  && (await val(`select count(*)::int from public.rider_earnings where delivery_job_id = $1`, [j4.id])) === 0);

section('Scheduler: avvisi, retention, disconnessione Rider');
const o5 = await paidOrder(U.alice, 1.1);
await accept(o5.id);
const j5 = await jobOf(o5.id);
h = await home(U.r1);
await rpc1(U.r1, 'rider_offer_respond', [h.offer.assignment_id, true, null]);
await act(U.r1, j5.id, 'depart');
await db.query(`update public.rider_availability set last_location_at = now() - interval '9 minutes' where rider_id = $1`, [await riderId(U.r1)]);
await db.query(`update public.delivery_jobs set last_rider_update_at = now() - interval '9 minutes' where id = $1`, [j5.id]);
x = await rpc1(U.admin, 'logistics_tick', [new Date().toISOString()]);
check('Rider senza aggiornamenti: flag + avviso, nessuna cancellazione automatica', (await val(`select count(*)::int from public.logistics_alerts where alert_type = 'rider_stale' and delivery_job_id = $1`, [j5.id])) === 1
  && (await jobOf(o5.id)).status === 'rider_to_restaurant' && (await jobOf(o5.id)).flags.includes('rider_no_response'));
await db.exec(`update public.rider_locations set received_at = now() - interval '30 hours' where id in (select id from public.rider_locations order by id limit 3)`);
const before = await val(`select count(*)::int from public.rider_locations`);
x = await rpc1(U.admin, 'logistics_tick', [new Date().toISOString()]);
check('retention: posizioni oltre 24 h cancellate', x.r.locations_purged === 3 && (await val(`select count(*)::int from public.rider_locations`)) === before - 3, x.r);
check('scheduler non eseguibile dai Rider', !(await rpc1(U.r1, 'logistics_tick', [new Date().toISOString()])).ok);
const cronRes = await logisticsCron({ store, verifyUser: async () => null, log });
check('cron server (service) funzionante', typeof cronRes.expired_offers === 'number');

section('ETA con provider di percorsi (backend)');
const lgDeps: LogisticsDeps = { store, verifyUser: async (t) => (t?.startsWith('tok-') ? t.slice(4) : null), log, routing: async () => 11 };
const callLg = (user: string | null, body: unknown) => logisticsAction({ method: 'POST', header: (n) => (n === 'authorization' && user ? `Bearer tok-${user}` : null), body: JSON.stringify(body) }, lgDeps);
let res = await callLg(U.r1, { action: 'eta_refresh', job_id: j5.id });
check('Rider assegnato: ETA da routing', res.status === 200 && (res.body as any).source === 'routing' && (await jobOf(o5.id)).eta_source === 'routing', res.body);
res = await callLg(U.r3, { action: 'eta_refresh', job_id: j5.id });
check('altro Rider: 403', res.status === 403);
res = await callLg(null, { action: 'eta_refresh', job_id: j5.id });
check('anonimo: 401', res.status === 401);
const failing: LogisticsDeps = { ...lgDeps, routing: async () => { throw new Error('offline'); } };
res = await logisticsAction({ method: 'POST', header: (n) => (n === 'authorization' ? `Bearer tok-${U.r1}` : null), body: JSON.stringify({ action: 'eta_refresh', job_id: j5.id }) }, failing);
check('provider non raggiungibile → resta la stima (nessun errore)', res.status === 200 && (res.body as any).source === 'estimate');

section('Metriche Admin e RLS residue');
const st = (await rpc1(U.admin, 'logistics_stats', [30])).r;
check('/admin/logistics: consegne, tempi medi, on-time, utilizzo', st.delivered === 2 && st.failed === 1 && st.avg_delivery_minutes != null && st.avg_wait_minutes != null && st.riders_online >= 1 && st.on_time_rate != null, st);
check('metriche negate ai non Admin', !(await rpc1(U.owner, 'logistics_stats', [30])).ok);
r = await as(U.alice, `select count(*)::int n from public.delivery_events`);
check('cliente non legge la timeline interna', r.rows[0].n === 0);
r = await as(U.alice, `select count(*)::int n from public.delivery_realtime`);
check('canale realtime: il cliente vede solo le proprie consegne', r.rows[0].n === (await val(`select count(*)::int from public.delivery_realtime where user_id = $1`, [U.alice])));
r = await as(U.bob, `select count(*)::int n from public.delivery_realtime`);
check('canale realtime: nessuna riga per clienti estranei', r.rows[0].n === 0);
r = await as(U.intruder, `select public.rider_home() h`);
check('candidato non approvato: nessuna offerta/consegna', r.ok && r.rows[0].h.offer === null && r.rows[0].h.active.length === 0);
r = await as(U.intruder, `insert into public.delivery_assignments (delivery_job_id, rider_id, expires_at) values ($1, $2, now())`, [j5.id, await riderId(U.intruder)]);
check('nessuno può auto-assegnarsi un job', !r.ok);
r = await as(U.r1, `update public.delivery_jobs set status = 'delivered' where id = $1`, [j5.id]);
check('nessuna modifica diretta dello stato dei job', (await jobOf(o5.id)).status === 'rider_to_restaurant');
r = await as(U.alice, `select public.track_event($1, 'delivery_completed'::public.analytics_event_type, 's', 'x', '{}'::jsonb)`, [SEOUL]);
const before2 = await val(`select count(*)::int from public.analytics_events where event_type = 'delivery_completed'`);
check('eventi logistici non falsificabili dal client', before2 === 2);
check('storage privato per documenti e prove', (await val(`select count(*)::int from storage.buckets where id in ('rider-documents', 'delivery-proofs') and not public`)) === 2);

console.log(`\n${pass} passati, ${fail} falliti`);
process.exit(fail ? 1 : 0);
