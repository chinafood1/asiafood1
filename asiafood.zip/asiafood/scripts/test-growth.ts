/* eslint-disable @typescript-eslint/no-explicit-any -- righe SQL dinamiche nei test (come test-launch) */
// ─────────────────────────────────────────────────────────────
//  Test Fase 13 (Business Intelligence & Growth Automation) sul database reale (PGlite + migrazioni + seed):
//  tassonomia eventi, ricerche privacy-safe, aggregati idempotenti e backfill, command center, funnel,
//  retention/coorti, health score, churn/MRR, acquisizione/CAC, ricerca/zero risultati/supply gap,
//  engagement (AI, referral, loyalty), mercati/score/prossima città, alert/anomalie, automazioni
//  (kill switch, consenso, approvazione, deduplica), esperimenti, report, brief, costi, performance
//  ristoratore (isolamento), impostazioni, oblio, job, RLS e grant. Parità formule SQL ↔ shared/growth.ts.
//  npm run test:growth
// ─────────────────────────────────────────────────────────────
import { createTestDb } from './lib/pglite-db';
import {
  analystRoute, ANALYST_QUESTIONS, churnReason, copilotAnswer, copilotIntent, experimentVerdict, explainScore, forecast, funnelSteps, growthChannel, healthScore,
  marketScore, normalizeQuery, pctChange, pickWeighted, rangeDates, restaurantInsights, restaurantRecommendations, searchDemandScore, toCsv, type RestaurantPerformance,
} from '../shared/growth';

const { db, store } = await createTestDb();
let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) { pass++; console.log('  ✓', name); } else { fail++; console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 900) : ''); }
}
const section = (t: string) => console.log(`\n── ${t}`);

async function as(user: string | null, sql: string, params: unknown[] = []) {
  const r = user ? 'authenticated' : 'anon';
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${user ?? ''}', false); select set_config('request.jwt.claim.role', '${r}', false);
    select set_config('request.headers', '{}', false); set role ${r};`);
  try {
    const res = await db.query<any>(sql, params);
    return { ok: true as const, rows: res.rows, err: '' };
  } catch (e) {
    return { ok: false as const, rows: [] as any[], err: (e as Error).message };
  } finally {
    await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', '', false); select set_config('request.headers', '', false);`);
  }
}
const enc = (a: unknown) => (a !== null && typeof a === 'object' ? JSON.stringify(a) : a);
const rpc = async (user: string | null, fn: string, args: unknown[] = []) => {
  const r = await as(user, `select public.${fn}(${args.map((_, i) => `$${i + 1}`).join(', ')}) as r`, args.map(enc));
  return { ok: r.ok, r: r.rows[0]?.r, err: r.err };
};
const q1 = async (sql: string, params: unknown[] = []) => (await db.query<any>(sql, params)).rows[0];
const val = async (sql: string, params: unknown[] = []) => Object.values((await q1(sql, params)) ?? {})[0] as any;
const denied = (r: { ok: boolean; err: string }) => !r.ok && /permission denied|Non autorizzato|42501|Solo backend/i.test(r.err);
const setSetting = (k: string, v: unknown) => db.query(`insert into public.platform_settings (key, value) values ($1, $2::jsonb) on conflict (key) do update set value = excluded.value`, [k, JSON.stringify(v)]);
const today = await val(`select (now() at time zone 'Europe/Rome')::date::text`);
const dayAgo = (n: number) => val(`select ((now() at time zone 'Europe/Rome')::date - $1::int)::text`, [n]);

const U = {
  admin: 'c1111111-1111-4111-8111-111111111111',
  admin2: 'c1111111-1111-4111-8111-222222222222',
  owner: 'c2222222-2222-4222-8222-222222222222',
  owner2: 'c2222222-2222-4222-8222-333333333333',
  alice: 'c3333333-3333-4333-8333-333333333333',
  bob: 'c4444444-4444-4444-8444-444444444444',
  carol: 'c5555555-5555-4555-8555-555555555555',
};
for (const [k, id] of Object.entries(U)) {
  await db.query(`insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values ($1, $2, $3, now())`, [id, `${k}@test.it`, JSON.stringify({ full_name: `${k} Test` })]);
}
await db.exec(`update public.profiles set role = 'admin' where id in ('${U.admin}', '${U.admin2}');`);
const R = (n: number) => `e0000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const KAIZEN = R(1);
const KOEN = R(2);
const SEOUL = R(5);
const MASSAFRA_SUSHI = R(7);
const TARANTO = await val(`select id from public.markets where slug = 'taranto'`);

async function claim(user: string, restaurant: string) {
  const c = await as(user, `insert into public.restaurant_claims (restaurant_id, user_id, first_name, last_name, role, phone, business_email, verification_method)
    values ($1, $2, 'Titolare', 'Test', 'Titolare', '3330000000', 'titolare@test.it', 'phone') returning id`, [restaurant, user]);
  if (!c.ok) throw new Error('claim: ' + c.err);
  const a = await rpc(U.admin, 'approve_claim', [c.rows[0].id, null]);
  if (!a.ok) throw new Error('approve: ' + a.err);
}
await claim(U.owner, SEOUL);
await claim(U.owner2, KOEN);
await setSetting('billing_stripe_environment', 'test');

// ════════════════════════════════════════════════════════════
section('1. Tassonomia eventi (adattatore, nessuna rinomina distruttiva)');
{
  const tax = await db.query<any>(`select canonical, source, legacy_names from public.growth_event_taxonomy`);
  const names = tax.rows.map((r) => r.canonical);
  const required = ['session_started', 'search_performed', 'restaurant_viewed', 'menu_viewed', 'favorite_added', 'map_opened', 'directions_clicked', 'phone_clicked', 'whatsapp_clicked',
    'offer_viewed', 'coupon_claimed', 'coupon_redeemed', 'reservation_started', 'reservation_completed', 'cart_created', 'add_to_cart', 'checkout_started', 'payment_completed',
    'order_completed', 'review_created', 'referral_shared', 'referral_qualified', 'subscription_started', 'subscription_cancelled'];
  check('24 eventi canonici della specifica presenti', required.every((n) => names.includes(n)), required.filter((n) => !names.includes(n)));
  const byName = Object.fromEntries(tax.rows.map((r) => [r.canonical, r]));
  check('nomi storici mappati (restaurant_view, phone_click, click_phone → canonici)', byName.restaurant_viewed.legacy_names.includes('restaurant_view')
    && byName.phone_clicked.legacy_names.includes('click_phone') && byName.search_performed.legacy_names.includes('search'));
  check('conversioni e pagamenti hanno come fonte di verità le tabelle di dominio', ['reservation_completed', 'order_completed', 'payment_completed', 'coupon_redeemed'].every((n) => byName[n].source === 'domain'));
  check('nessun evento con PII (colonna pii = none per tutti)', (await val(`select count(*) from public.growth_event_taxonomy where pii <> 'none'`)) === 0);
  const s = await rpc(null, 'track_app_event', ['session_started', null, 'sess_abcdef12', 'direct', { device_type: 'mobile', utm_source: 'ig' }]);
  check('nuovo evento app "session_started" accettato (anonimo) con metadati standard', s.ok && (await val(`select count(*) from public.app_events where event_type = 'session_started' and metadata ->> 'device_type' = 'mobile'`)) === 1, s.err);
  await rpc(null, 'track_app_event', ['conversion', SEOUL, 'sess_abcdef12', 'web', { kind: 'hack', email: 'x@y.it' }]);
  await rpc(null, 'track_app_event', ['conversion', SEOUL, null, 'web', { kind: 'reservation_completed' }]);
  check('"conversion": tipi non ammessi o senza sessione scartati', (await val(`select count(*) from public.app_events where event_type = 'conversion'`)) === 0);
  await rpc(null, 'track_app_event', ['favorite_added', SEOUL, 'sess_abcdef12', 'web', { email: 'a@b.it', phone: '333', name: 'Mario' }]);
  check('metadati personali rimossi dagli eventi app (email/telefono/nome)', (await val(`select metadata::text from public.app_events where event_type = 'favorite_added'`)) === '{}');
  const v = await as(U.alice, `select count(*) from public.growth_events`);
  check('vista growth_events non leggibile dai client (solo backend)', !v.ok);
  check('vista growth_events mappa gli eventi storici sui canonici', (await val(`select count(*) from public.growth_events where canonical = 'session_started'`)) === 1);
}

// ════════════════════════════════════════════════════════════
section('2. Ricerche privacy-safe (testo normalizzato, niente dati personali, niente utente)');
{
  check('normalizzazione: "Ramen  Massafrà!" → "ramen massafra"', (await val(`select public.growth_normalize_query('Ramen  Massafrà!')`)) === 'ramen massafra');
  check('email, telefoni e link non vengono salvati', (await val(`select public.growth_normalize_query('mario@test.it')`)) === null
    && (await val(`select public.growth_normalize_query('chiamami 333 123 4567')`)) === null && (await val(`select public.growth_normalize_query('https://x.it')`)) === null);
  const r1 = await rpc(null, 'log_search', [{ query: 'Ramen', city_slug: 'massafra', category_slug: 'ramen', result_count: 0, result_ids: [], session_id: 'sess_search01' }]);
  check('ricerca anonima registrata', r1.ok && (await val(`select count(*) from public.search_events`)) === 1, r1.err);
  await rpc(null, 'log_search', [{ query: 'sushi', city_slug: 'citta-inventata', category_slug: 'categoria-x', result_count: 3, result_ids: [SEOUL, 'not-a-uuid', 'e0000000-0000-4000-8000-0000000000ff'] }]);
  const last = await q1(`select city_slug, category_slug, result_ids from public.search_events order by id desc limit 1`);
  check('slug inesistenti scartati; result_ids solo ristoranti reali', last.city_slug === null && last.category_slug === null && last.result_ids.length === 1 && last.result_ids[0] === SEOUL, last);
  check('search_events non ha colonne utente, IP o posizione', (await val(`select count(*) from information_schema.columns where table_name = 'search_events' and column_name ~ '(user|ip|lat|lng|email)'`)) === 0);
  check('ricerche non leggibili da utenti non Admin', (await as(U.alice, `select * from public.search_events`)).rows.length === 0);
  // AI: filtri strutturati → ricerche "ai" (alimentano il supply gap)
  await store.rpc('ai_log_usage', { p: { status: 'ok', intent: 'restaurant_search', result_count: 0, no_results: true, search_city: 'massafra', search_category: 'ramen', input_tokens: 1000, output_tokens: 200 } });
  check('ricerca AI con filtri → search_events (source ai)', (await val(`select count(*) from public.search_events where source = 'ai' and city_slug = 'massafra' and category_slug = 'ramen'`)) === 1);
  check('ai_log_usage resta solo backend', denied(await rpc(U.alice, 'ai_log_usage', [{ status: 'ok' }])));
  // Volume per il caso "Ramen Massafra — N ricerche — 0 risultati"
  await db.exec(`insert into public.search_events (source, query_norm, city_slug, category_slug, market_id, result_count, session_id, created_at)
    select 'explore', null, 'massafra', 'ramen', '${TARANTO}', 0, 'sess_rm' || lpad((g % 40)::text, 6, '0'), now() - make_interval(hours => g % 70) from generate_series(1, 85) g`);
  await db.exec(`insert into public.search_events (source, query_norm, city_slug, category_slug, market_id, result_count, result_ids, session_id, created_at)
    select 'explore', null, 'taranto', 'sushi', '${TARANTO}', 4, array['${KAIZEN}'::uuid, '${SEOUL}'::uuid], 'sess_ts' || lpad(g::text, 6, '0'), now() - make_interval(hours => g) from generate_series(1, 40) g`);
}

// ════════════════════════════════════════════════════════════
section('3. Aggregati giornalieri: idempotenza, backfill, permessi');
{
  // Eventi analytics e attività
  await db.exec(`
    insert into public.analytics_events (restaurant_id, event_type, session_id, source, created_at)
      select '${SEOUL}', 'restaurant_view', 'sess_ts' || lpad(g::text, 6, '0'), 'search', now() - make_interval(hours => g) + interval '5 minutes' from generate_series(1, 30) g;
    insert into public.analytics_events (restaurant_id, event_type, session_id, source, created_at)
      select '${SEOUL}', 'phone_click', 'sess_ts' || lpad(g::text, 6, '0'), 'restaurant', now() - make_interval(hours => g) + interval '6 minutes' from generate_series(1, 12) g;
    insert into public.analytics_events (restaurant_id, event_type, session_id, source, created_at)
      select '${SEOUL}', 'directions_click', 'sess_ts' || lpad(g::text, 6, '0'), 'restaurant', now() - make_interval(hours => g) + interval '7 minutes' from generate_series(1, 6) g;
    insert into public.acquisition_visits (market_id, channel, utm_source, utm_campaign, created_at)
      select '${TARANTO}', case when g % 3 = 0 then 'social' when g % 3 = 1 then 'organic_search' else 'qr' end, case when g % 3 = 0 then 'ig' end, case when g % 3 = 0 then 'lancio' end,
             now() - make_interval(hours => g) from generate_series(1, 60) g;`);
  for (const [i, s] of Array.from({ length: 5 }, (_, k) => k).entries()) {
    await rpc(null, 'track_app_event', ['conversion', SEOUL, 'sess_ts' + String(i + 1).padStart(6, '0'), 'web', { kind: 'reservation_completed' }]);
    void s;
  }
  const a = await store.rpc<any>('growth_compute_day', { p_day: today });
  const snap1 = await q1(`select to_jsonb(d) - 'computed_at' j from public.daily_platform_metrics d where date = $1`, [today]);
  await store.rpc('growth_compute_day', { p_day: today });
  const snap2 = await q1(`select to_jsonb(d) - 'computed_at' j from public.daily_platform_metrics d where date = $1`, [today]);
  check('ricalcolo dello stesso giorno idempotente (stessi numeri, nessun duplicato)', JSON.stringify(snap1.j) === JSON.stringify(snap2.j)
    && (await val(`select count(*) from public.daily_platform_metrics where date = $1`, [today])) === 1, [snap1, snap2]);
  check('giorno odierno marcato con MRR osservato', a.mrr_observed === true);
  check('aggregato piattaforma: visite, ricerche e zero risultati dai dati grezzi', snap1.j.visits >= 10 && snap1.j.searches >= 10 && snap1.j.zero_result_searches >= 1, snap1.j);
  check('aggregato ristorante: impression da search_events.result_ids', (await val(`select impressions from public.daily_restaurant_metrics where restaurant_id = $1 and date = $2`, [SEOUL, today])) >= 1);
  check('backfill: Admin sì, cliente no', denied(await rpc(U.alice, 'growth_backfill', [await dayAgo(3), today])));
  const bf = await rpc(U.admin, 'growth_backfill', [await dayAgo(70), today]);
  check('backfill 70 giorni eseguito e registrato', bf.ok && bf.r.days === 71 && (await val(`select count(*) from public.growth_computed_days`)) === 71, bf.err || bf.r);
  check('backfill oltre 400 giorni rifiutato', !(await rpc(U.admin, 'growth_backfill', ['2024-01-01', '2026-01-01'])).ok);
  check('giorni passati ricalcolati → MRR "ricostruito" (non osservato)', (await val(`select mrr_observed from public.growth_computed_days where day = $1`, [await dayAgo(30)])) === false);
  check('growth_compute_day non eseguibile dai client', denied(await rpc(U.admin, 'growth_compute_day', [today])));
  check('aggregati leggibili solo dall\'Admin', (await as(U.alice, `select * from public.daily_platform_metrics`)).rows.length === 0
    && (await as(U.admin, `select * from public.daily_platform_metrics`)).rows.length > 0);
}

// ════════════════════════════════════════════════════════════
section('4. Growth Command Center (periodi, confronto solo se valido, freschezza, qualità dati)');
{
  check('solo Admin', denied(await rpc(U.alice, 'admin_growth_overview', [await dayAgo(6), today, null])));
  const o = await rpc(U.admin, 'admin_growth_overview', [await dayAgo(6), today, null]);
  check('overview 7 giorni: totali, stato, serie, freschezza', o.ok && o.r.current.visits >= 50 && o.r.series.length === 7 && o.r.freshness.today_at, o.err || o.r);
  check('periodo precedente interamente aggregato → confronto disponibile', o.r.previous && o.r.previous.complete === true);
  const o2 = await rpc(U.admin, 'admin_growth_overview', [await dayAgo(89), today, null]);
  check('90 giorni con precedente NON aggregato → nessun confronto (null, mai un % falso)', o2.ok && o2.r.previous === null, o2.r?.previous);
  check('tasso di conversione mostrato solo sopra il campione minimo', o.r.conversion_rate === null || o.r.current.visits >= o.r.min_sample);
  check('qualità dati: avviso DEMO inclusi e giorni mancanti', o2.r.data_quality.some((d: any) => d.key === 'demo_included'));
  check('intervallo non valido rifiutato', !(await rpc(U.admin, 'admin_growth_overview', [today, await dayAgo(3), null])).ok);
  const om = await rpc(U.admin, 'admin_growth_overview', [await dayAgo(6), today, 'taranto']);
  check('filtro mercato: totali dal mercato, KPI dei soli ristoranti del mercato', om.ok && om.r.market === 'taranto' && om.r.current.searches >= 1, om.err);
  check('pctChange: null se precedente 0/incompleto', pctChange(10, 0) === null && pctChange(10, 5, false) === null && pctChange(15, 10) === 50);
  check('rangeDates: 7d = 7 giorni inclusivi', (() => { const r = rangeDates('7d', '2026-09-28'); return r.from === '2026-09-22' && r.to === '2026-09-28'; })());
}

// ════════════════════════════════════════════════════════════
section('5. Funnel consumer (sessioni con consenso) e B2B');
{
  const f = await rpc(U.admin, 'admin_growth_funnels', [await dayAgo(6), today, null]);
  const st = Object.fromEntries((f.r?.consumer ?? []).map((s: any) => [s.key, s.value]));
  check('fasi Visita → Ricerca → Scheda → Intenzione → Conversione', f.ok && ['visit', 'search', 'view', 'intent', 'conversion'].every((k) => k in st), f.err || f.r);
  check('funnel monotono sui dati di test (ricerca ≥ scheda ≥ intenzione ≥ conversione)', st.search >= st.view && st.view >= st.intent && st.intent >= st.conversion && st.conversion === 5, st);
  const fs = funnelSteps(f.r.consumer, 30);
  check('drop-off più grande mostrato solo con campione sufficiente', (st.visit >= 30) === fs.sufficient && (fs.sufficient ? fs.largestDrop !== null : fs.largestDrop === null), fs);
  check('funnelSteps con campione piccolo: nessun drop-off', funnelSteps([{ key: 'a', label: 'A', value: 5 }, { key: 'b', label: 'B', value: 1 }], 30).largestDrop === null);
  const b2b = Object.fromEntries(f.r.b2b.map((s: any) => [s.key, s.value]));
  check('funnel B2B: censiti → … → rivendicati (2 claim di test)', b2b.discovered >= 17 && b2b.claimed === 2 && 'trial' in b2b && 'retained' in b2b, b2b);
  check('velocità di vendita con numerosità n per ogni passaggio', ['lead_to_contact', 'lead_to_claim', 'claim_to_trial', 'trial_to_paid'].every((k) => typeof f.r.velocity[k].n === 'number'));
  check('definizioni esplicite (unità = sessioni con consenso)', /consenso/.test(f.r.definitions.unit));
}

// ════════════════════════════════════════════════════════════
section('6. Retention D1/D7/D30 e coorti');
{
  // alice: registrata 40 giorni fa, torna il giorno dopo e al giorno 5; bob: registrato 40 giorni fa, mai tornato
  await db.exec(`update public.profiles set created_at = now() - interval '40 days' where id in ('${U.alice}', '${U.bob}');
    insert into public.user_activity_days (user_id, day) values
      ('${U.alice}', ((now() - interval '40 days') at time zone 'Europe/Rome')::date + 1), ('${U.alice}', ((now() - interval '40 days') at time zone 'Europe/Rome')::date + 5),
      ('${U.alice}', (now() at time zone 'Europe/Rome')::date) on conflict do nothing;`);
  const r = await rpc(U.admin, 'admin_growth_retention', [8]);
  check('D1/D7/D30 con numerosità (eligible/returned)', r.ok && r.r.users.d1.eligible >= 2 && r.r.users.d1.returned >= 1 && r.r.users.d7.returned >= 1, r.err || r.r?.users);
  check('bob (mai tornato) non conta come ritorno', r.r.users.d30.returned < r.r.users.d30.eligible);
  check('coorti: 8 settimane × 5 colonne; settimane future = null', r.r.cohorts.length === 8 && r.r.cohorts.every((c: any) => c.weeks.length === 5) && r.r.cohorts[0].weeks[4] === null, r.r.cohorts[0]);
  check('retention ristoranti: trial→paid, M1→M2, M2→M3', 'trial_to_paid' in r.r.restaurants && 'paid_m1_m2' in r.r.restaurants && 'paid_m2_m3' in r.r.restaurants);
  check('definizione di "ritorno" documentata', /giorno di attività/.test(r.r.definitions.return));
}

// ════════════════════════════════════════════════════════════
section('7. Ristoranti: health score interno e segnali di rischio');
{
  const h = await val(`select public.growth_restaurant_health($1)`, [SEOUL]);
  check('health: punteggio 0–100, stato, componenti e segnali', typeof h.score === 'number' && ['healthy', 'needs_attention', 'at_risk'].includes(h.status) && h.components.completeness != null, h);
  check('segnale "nessun accesso" per il titolare mai attivo', h.signals.some((s: any) => s.key === 'no_login_30d'));
  check('locale non rivendicato: nessun punteggio (not_claimed)', (await val(`select public.growth_restaurant_health($1) ->> 'status'`, [KAIZEN])) === 'not_claimed');
  // Parità SQL ↔ TS su input casuali
  let same = true;
  for (let i = 0; i < 40; i++) {
    const c: Record<string, number> = {};
    for (const k of ['completeness', 'recent_login', 'menu_updated', 'reservation_response', 'order_acceptance', 'offers', 'customer_actions', 'subscription']) {
      if (Math.random() > 0.2) c[k] = Math.round(Math.random() * 100) / 100;
    }
    const sql = await val(`select public.growth_health_score($1::jsonb)`, [JSON.stringify(c)]);
    const ts = healthScore(c);
    if (sql.score !== ts.score || sql.status !== ts.status) { same = false; console.log(c, sql, ts); break; }
  }
  check('formula health identica in SQL e TypeScript (40 casi casuali)', same);
  const list = await rpc(U.admin, 'admin_growth_restaurants', [await dayAgo(6), today, 'taranto', null, null, 50, 0]);
  const seoul = list.r?.rows?.find((x: any) => x.id === SEOUL);
  check('lista ristoranti: metriche del periodo + conversione documentata', list.ok && seoul && seoul.views === 30 && seoul.calls === 12 && Number(seoul.conversion_rate) === Math.round(seoul.conversion_actions * 1000 / seoul.views) / 10, seoul ?? list.err);
  check('filtro per stato (at_risk)', (await rpc(U.admin, 'admin_growth_restaurants', [await dayAgo(6), today, null, 'at_risk', null, 50, 0])).r.rows.every((x: any) => x.health.status === 'at_risk'));
  check('solo Admin', denied(await rpc(U.owner, 'admin_growth_restaurants', [await dayAgo(6), today, null, null, null, 50, 0])));
  check('etichetta: "non è un giudizio sulla qualità"', /Non è un giudizio sulla qualità/.test(list.r.definitions.health));
}

// ════════════════════════════════════════════════════════════
section('8. Churn e MRR (base coerente, LTV solo con dati)');
{
  await db.exec(`
    insert into public.subscriptions (restaurant_id, plan_code, status, source, stripe_subscription_id, stripe_environment, unit_amount_cents, paid_started_at, billing_interval, created_at)
      values ('${SEOUL}', 'business', 'active', 'stripe', 'sub_G1', 'test', 1900, now() - interval '45 days', 'month', now() - interval '45 days');
    insert into public.subscriptions (restaurant_id, plan_code, status, source, stripe_subscription_id, stripe_environment, unit_amount_cents, paid_started_at, ended_at, billing_interval, created_at)
      values ('${KOEN}', 'premium', 'canceled', 'stripe', 'sub_G2', 'test', 4900, now() - interval '60 days', now() - interval '3 days', 'month', now() - interval '60 days');
    insert into public.product_feedback (restaurant_id, type, reason, created_at) values ('${KOEN}', 'cancellation', 'using_other', now() - interval '3 days'), ('${KOEN}', 'cancellation', null, now() - interval '2 days');`);
  const c = await rpc(U.admin, 'admin_growth_churn', [await dayAgo(29), today]);
  check('churn = persi / paganti a inizio periodo (2 → 1 = 50%)', c.ok && c.r.churn.base === 2 && c.r.churn.lost === 1 && Number(c.r.churn.rate) === 50, c.err || c.r?.churn);
  check('MRR perso = canone dell\'abbonamento terminato', Number(c.r.mrr.churned_mrr_cents) === 4900, c.r.mrr);
  check('espansione/contrazione: null senza fotografie osservate (mai stimate)', c.r.mrr.expansion_mrr_cents === null && c.r.mrr.expansion_available === false);
  check('motivi standardizzati (using_other → competitor, vuoto → unknown)', c.r.reasons.some((x: any) => x.reason === 'competitor') && c.r.reasons.some((x: any) => x.reason === 'unknown'), c.r.reasons);
  check('churnReason TS = growth_churn_reason SQL', (await Promise.all(['too_expensive', 'no_time', 'missing_features', 'closing', 'using_other', 'xyz', ''].map(async (x) =>
    (await val(`select public.growth_churn_reason($1)`, [x])) === churnReason(x || null)))).every(Boolean));
  check('liste: disdetti, disdetta programmata, insoluti, prove inattive, a rischio', ['cancelled', 'cancel_scheduled', 'past_due', 'inactive_trials', 'at_risk'].every((k) => Array.isArray(c.r.lists[k])));
  const rv = await rpc(U.admin, 'admin_growth_revenue', [await dayAgo(29), today]);
  check('MRR/ARR/ARPA sui soli paganti', rv.ok && Number(rv.r.mrr_cents) === 1900 && Number(rv.r.arr_cents) === 22800 && Number(rv.r.arpa_cents) === 1900, rv.err || rv.r);
  check('LTV: "Dati insufficienti" con meno di 3 mesi di storico', rv.r.ltv_cents === null && /insufficienti/.test(rv.r.ltv_reason));
  check('fonti di ricavo: abbonamenti / ordini / sponsorizzazioni / altro', rv.r.sources.map((s: any) => s.key).join() === 'subscriptions,orders,ads,other');
}

// ════════════════════════════════════════════════════════════
section('9. Acquisizione: canali, first/last touch, CAC solo con costi e volumi');
{
  check('growthChannel TS = growth_channel SQL', (await Promise.all([['social', 'ig'], ['social', 'facebook'], ['social', 'tt'], ['social', null], ['qr', null], ['organic_search', null],
    ['influencer', null], ['xyz', null], ['direct', 'ig']].map(async ([c, s]) => (await val(`select public.growth_channel($1, $2)`, [c, s])) === growthChannel(c, s)))).every(Boolean));
  // carol: iscritta oggi da Instagram (first) e QR (last)
  await db.exec(`update public.profiles set created_at = now() - interval '1 hour' where id = '${U.carol}'`);
  const at = await rpc(U.carol, 'attribute_my_signup', [{ channel: 'social', utm_source: 'ig', utm_campaign: 'lancio', last_channel: 'qr' }]);
  check('attribuzione first + last touch (solo propria iscrizione)', at.ok && at.r === true && (await val(`select last_channel from public.user_acquisition where user_id = $1`, [U.carol])) === 'qr', at.err);
  await store.rpc('growth_compute_day', { p_day: today });
  const a = await rpc(U.admin, 'admin_growth_acquisition', [await dayAgo(6), today]);
  const ig = a.r?.channels?.find((x: any) => x.channel === 'instagram');
  check('canale Instagram: visite e iscrizioni', a.ok && ig && ig.visits >= 1 && ig.signups === 1, a.err || a.r?.channels);
  check('CAC N/A senza costi registrati', ig.cac_cents === null && /nessun costo/.test(ig.cac_reason));
  await db.query(`insert into public.acquisition_costs (market_id, audience, category, channel, amount_cents, spent_on) values ($1, 'users', 'marketing', 'instagram', 5000, current_date)`, [TARANTO]);
  const a2 = await rpc(U.admin, 'admin_growth_acquisition', [await dayAgo(6), today]);
  const ig2 = a2.r.channels.find((x: any) => x.channel === 'instagram');
  check('CAC N/A con costi ma iscrizioni sotto la soglia (cac_min_conversions)', ig2.cost_cents === 5000 && ig2.cac_cents === null && /meno di 5/.test(ig2.cac_reason), ig2);
  check('last touch riportato separatamente (modello semplice dichiarato)', a2.r.last_touch.some((x: any) => x.channel === 'restaurant_qr') && /First touch/.test(a2.r.definitions.model));
  check('copertura: iscrizioni attribuite vs totali', a2.r.coverage.signups_attributed >= 1 && a2.r.coverage.signups_total >= a2.r.coverage.signups_attributed);
}

// ════════════════════════════════════════════════════════════
section('10. Ricerca, zero risultati, supply gap');
{
  const s = await rpc(U.admin, 'admin_growth_search', [await dayAgo(6), today, null]);
  const rm = s.r?.zero_results?.find((x: any) => x.city_slug === 'massafra' && x.category_slug === 'ramen');
  check('"Ramen · Massafra": ricerche con 0 risultati (ricerche anonime + AI)', s.ok && rm && rm.searches >= 86 && rm.zero_results >= 86 && rm.ai_searches === 1, s.err || rm);
  check('demand score 0–100 per combinazione', rm.demand_score >= 0 && rm.demand_score <= 100);
  const ts = s.r.top.find((x: any) => x.city_slug === 'taranto' && x.category_slug === 'sushi');
  check('ricerche convertite = seguite da una scheda nella stessa sessione (30 minuti)', ts && ts.converted === 30 && ts.with_session === 40, ts);
  const gap = s.r.supply_gap.find((x: any) => x.city_slug === 'massafra' && x.category_slug === 'ramen');
  check('supply gap: Massafra × Ramen con 0 locali e punteggio scomposto', gap && gap.supply === 0 && gap.zero_pct === 100 && gap.breakdown.low_supply === 20 && gap.score >= 60, gap);
  const tsGap = s.r.supply_gap.find((x: any) => x.city_slug === 'taranto' && x.category_slug === 'sushi');
  check('Taranto × Sushi: risultati presenti → 0% senza risultati, offerta contata', tsGap && tsGap.zero_pct === 0 && tsGap.supply >= 1 && tsGap.score < gap.score, tsGap);
  const low = await rpc(U.admin, 'admin_growth_search', [await dayAgo(6), today, 'taranto']);
  check('filtro mercato', low.ok && low.r.totals.searches >= 100);
  check('searchDemandScore TS = SQL', (await Promise.all([[10, 100, 0.5, 0.2, 0.3], [0, 10, 0, 0, 0], [100, 100, 1, 1, 1], [7, 50, null, null, 0.4]].map(async ([a, b, c, d, e]) =>
    (await val(`select public.growth_search_demand_score($1, $2, $3, $4, $5)`, [a, b, c, d, e])) === searchDemandScore(a as number, b as number, c, d, e)))).every(Boolean));
  check('normalizeQuery TS = SQL', (await Promise.all(['Ramen  Massafrà!', 'mario@test.it', 'tel 333 1234567', 'a', 'Sushi All You Can Eat Taranto Centro', 'uno due tre quattro cinque sei sette']
    .map(async (x) => (await val(`select public.growth_normalize_query($1)`, [x])) === normalizeQuery(x)))).every(Boolean));
}

// ════════════════════════════════════════════════════════════
section('11. Offerte, menu, AI, referral, loyalty, recensioni');
{
  const e = await rpc(U.admin, 'admin_growth_engagement', [await dayAgo(6), today]);
  check('sezioni presenti', e.ok && ['offers', 'menu', 'ai', 'referral', 'loyalty', 'reviews'].every((k) => k in e.r), e.err);
  check('AI: query, no-result per filtri, costo stimato', e.r.ai.queries >= 1 && e.r.ai.no_results >= 1 && e.r.ai.no_result_top.some((x: any) => x.city === 'massafra') && Number(e.r.ai.cost_cents) > 0, e.r.ai);
  check('AI: costo per conversione assistita null senza conversioni (nessun ROI inventato)', e.r.ai.cost_per_assisted_conversion_cents === null && /Non è un ROI/.test(e.r.ai.note));
  check('K-factor nascosto con dati insufficienti', e.r.referral.k_factor === null);
  check('recensioni: correlazione dichiarata non causale', /non un effetto causale/.test(e.r.reviews.note));
  const v = await rpc(U.admin, 'admin_growth_voice', [await dayAgo(29), today]);
  check('voce del cliente: feedback per categoria e sintesi deterministica', v.ok && Array.isArray(v.r.feedback.by_category) && /Nessun tema generato/.test(v.r.feedback.summary_basis), v.err);
  await db.exec(`insert into public.support_tickets (category, subject, description, created_at) select 'payments', 'Pagamento', 'Il pagamento non va a buon fine', now() - interval '1 day' from generate_series(1, 5)`);
  const v2 = await rpc(U.admin, 'admin_growth_voice', [await dayAgo(29), today]);
  check('supporto: ≥ 5 ticket della stessa categoria → insight di prodotto', v2.r.support.product_insights.some((x: any) => x.category === 'payments' && x.count === 5));
  const tid = await val(`select id from public.support_tickets limit 1`);
  await db.exec(`update public.support_tickets set status = 'resolved', resolved_at = now() where id = '${tid}'; update public.support_tickets set status = 'open' where id = '${tid}';`);
  check('riaperture dei ticket ora tracciate', (await val(`select reopened_count from public.support_tickets where id = $1`, [tid])) === 1);
  const seg = await rpc(U.admin, 'admin_growth_segments', []);
  check('segmenti clienti (9) e ristoranti (8), solo conteggi', seg.ok && seg.r.customers.length === 9 && seg.r.restaurants.length === 8 && seg.r.customers.every((x: any) => Object.keys(x).sort().join() === 'count,key,marketing_consent'), seg.err || seg.r);
}

// ════════════════════════════════════════════════════════════
section('12. Mercati, Market Opportunity Score, prossima città (solo analisi)');
{
  await db.exec(`insert into public.search_events (source, query_norm, result_count, created_at) select 'explore', 'sushi bari', 0, now() - interval '2 days' from generate_series(1, 12);
                 insert into public.search_events (source, query_norm, result_count, created_at) select 'explore', 'ramen lecce', 0, now() - interval '2 days' from generate_series(1, 4);`);
  const m = await rpc(U.admin, 'admin_growth_markets', []);
  check('mercati: metriche per mercato + readiness', m.ok && m.r.markets.some((x: any) => x.slug === 'taranto' && x.readiness && 'launch_ready' in x.readiness), m.err);
  const bari = m.r.candidates.find((x: any) => x.slug === 'bari');
  const lecce = m.r.candidates.find((x: any) => x.slug === 'lecce');
  check('candidate iniziali: Bari, Lecce, Brindisi, Matera, Foggia', ['bari', 'lecce', 'brindisi', 'matera', 'foggia'].every((s) => m.r.candidates.some((x: any) => x.slug === s)));
  check('domanda di ricerca per città (testo "sushi bari")', bari.inputs.search_demand === 12 && lecce.inputs.search_demand === 4, [bari.inputs, lecce.inputs]);
  check('punteggio trasparente: scomposizione per componente, nessuna black box', bari.score > lecce.score && bari.breakdown.search_demand > 0 && explainScore(bari.breakdown).startsWith('+'), bari);
  // Parità SQL ↔ TS
  const inputs = { search_demand: 12, supply_gap: 12, lead_availability: 0, organic_interest: 0, commercial_interest: 0 };
  const max = { search_demand: 12, supply_gap: 12, lead_availability: 0, organic_interest: 0, commercial_interest: 0 };
  const w = { search_demand: 30, supply_gap: 25, lead_availability: 20, organic_interest: 15, commercial_interest: 10 };
  const sqlScore = await val(`select public.growth_market_score($1::jsonb, $2::jsonb, $3::jsonb)`, [JSON.stringify(inputs), JSON.stringify(max), JSON.stringify(w)]);
  check('formula score identica in SQL e TypeScript', Object.entries(marketScore(inputs, max, w).breakdown).every(([k, v]) => sqlScore.breakdown[k] === v) && sqlScore.score === marketScore(inputs, max, w).score, [sqlScore, marketScore(inputs, max, w)]);
  // Pesi configurabili (validati)
  check('pesi: valori non validi rifiutati', !(await rpc(U.admin, 'admin_growth_setting_set', ['growth_market_weights', { search_demand: 500 }])).ok
    && !(await rpc(U.admin, 'admin_growth_setting_set', ['growth_market_weights', { hack: 1 }])).ok);
  check('pesi modificabili dall\'Admin', (await rpc(U.admin, 'admin_growth_setting_set', ['growth_market_weights', { search_demand: 0, supply_gap: 0, lead_availability: 100, organic_interest: 0, commercial_interest: 0 }])).ok);
  const m2 = await rpc(U.admin, 'admin_growth_markets', []);
  check('con i nuovi pesi la domanda di ricerca non conta più', m2.r.candidates.find((x: any) => x.slug === 'bari').breakdown.search_demand === 0);
  await rpc(U.admin, 'admin_growth_setting_set', ['growth_market_weights', w]);
  // Start Research
  check('Start Research: solo Admin', denied(await rpc(U.owner, 'admin_expansion_start_research', ['bari'])));
  const sr = await rpc(U.admin, 'admin_expansion_start_research', ['bari']);
  const mk = await q1(`select status, slug from public.markets where id = $1`, [sr.r?.market_id]);
  check('Start Research crea il mercato in stato "planned" (mai lanciato)', sr.ok && mk.status === 'planned' && mk.slug === 'bari', sr.err || mk);
  check('playbook (7 fasi) e task di ricerca creati', sr.r.playbook_items === 10 && sr.r.tasks === 5
    && (await val(`select count(distinct stage) from public.market_playbook_items where market_id = $1`, [sr.r.market_id])) === 7);
  check('task dichiarano che Discovery/Research Agent non sono disponibili', (await val(`select count(*) from public.growth_tasks where source = 'expansion' and description like '%non disponibile%'`)) === 2);
  const sr2 = await rpc(U.admin, 'admin_expansion_start_research', ['bari']);
  check('Start Research idempotente (nessun duplicato)', sr2.ok && sr2.r.tasks === 0 && sr2.r.playbook_items === 0 && (await val(`select count(*) from public.markets where slug = 'bari'`)) === 1);
  const mt = await rpc(U.admin, 'admin_expansion_start_research', ['matera']);
  check('Matera: provincia assente nei dati → errore chiaro, nessun mercato creato', !mt.ok && /provincia MT non è presente/.test(mt.err), mt.err);
  const pb = await rpc(U.admin, 'admin_market_playbook', ['bari']);
  check('playbook con readiness e knowledge loop (apprendimenti di altri mercati)', pb.ok && pb.r.items.length === 10 && 'learnings' in pb.r && pb.r.readiness.launch_ready.ok === false);
  await rpc(U.admin, 'admin_playbook_item_set', [pb.r.items[0].id, true]);
  check('checklist spuntabile', (await val(`select done_at is not null from public.market_playbook_items where id = $1`, [pb.r.items[0].id])) === true);
  const rev = await rpc(U.admin, 'admin_growth_market_review', ['taranto']);
  check('Taranto review: target vs actual con gap e dati correlati (non cause)', rev.ok && rev.r.goals.length >= 6 && rev.r.goals.every((g: any) => 'gap' in g) && /non indicano la causa/.test(rev.r.note), rev.err);
}

// ════════════════════════════════════════════════════════════
section('13. Alert e anomalie (soglie minime, chiusura automatica)');
{
  await db.exec(`insert into public.subscriptions (restaurant_id, plan_code, status, source, stripe_subscription_id, stripe_environment, unit_amount_cents, trial_start, trial_end, billing_interval)
                 values ('${KOEN}', 'business', 'trialing', 'stripe', 'sub_G3', 'test', 1900, now() - interval '12 days', now() + interval '2 days', 'month')`);
  await store.rpc('growth_compute_day', { p_day: today });
  const ref = await rpc(U.admin, 'admin_growth_alerts_refresh', []);
  const al = await rpc(U.admin, 'admin_growth_alerts', ['open']);
  const keys = (al.r ?? []).map((a: any) => a.key);
  check('alert zero risultati «Ramen · Massafra»', ref.ok && keys.some((k: string) => k.startsWith('zero:') && k.includes('massafra')) && al.r.some((a: any) => /Ramen · Massafra/.test(a.title)), ref.err || al.r?.map((a: any) => a.title));
  check('alert prova in scadenza entro 3 giorni', keys.includes(`trial:${KOEN}`));
  check('alert "non accede da N giorni" per ristoranti paganti/in prova', keys.includes(`nologin:${SEOUL}`));
  check('nessuna anomalia ordini con volumi sotto la soglia minima (niente reazioni eccessive)', !keys.some((k: string) => k.startsWith('anomaly:orders')));
  await db.exec(`insert into public.user_activity_days (user_id, day) values ('${U.owner}', (now() at time zone 'Europe/Rome')::date) on conflict do nothing`);
  await rpc(U.admin, 'admin_growth_alerts_refresh', []);
  check('alert chiuso automaticamente quando il problema non c\'è più', (await val(`select status from public.growth_alerts where key = $1`, [`nologin:${SEOUL}`])) === 'resolved');
  const id = await val(`select id from public.growth_alerts where key = $1`, [`trial:${KOEN}`]);
  await rpc(U.admin, 'admin_growth_alert_set', [id, 'acknowledged']);
  await rpc(U.admin, 'admin_growth_alerts_refresh', []);
  check('alert preso in carico resta tale (nessun reset)', (await val(`select status from public.growth_alerts where id = $1`, [id])) === 'acknowledged');
  // Anomalia ordini con baseline sufficiente
  await db.exec(`update public.daily_platform_metrics set orders = 20 where date between (now() at time zone 'Europe/Rome')::date - 8 and (now() at time zone 'Europe/Rome')::date - 2;
                 update public.daily_platform_metrics set orders = 2 where date = (now() at time zone 'Europe/Rome')::date - 1;`);
  await store.rpc('growth_alerts_refresh', {});
  check('calo ordini −90% con baseline ≥ 10/giorno → alert critico', (await val(`select severity from public.growth_alerts where key like 'anomaly:orders:%'`)) === 'critical');
  check('alert: solo Admin', denied(await rpc(U.owner, 'admin_growth_alerts', ['open'])));
}

// ════════════════════════════════════════════════════════════
section('14. Automazioni: controllabili, disattivabili, auditabili; bozze con consenso e approvazione');
{
  const rules = await rpc(U.admin, 'admin_automation_rules', []);
  const byKey = Object.fromEntries((rules.r?.rules ?? []).map((r: any) => [r.key, r]));
  check('regole predefinite con enabled/last_run/next_run/failure_count/owner', rules.ok && Object.keys(byKey).length === 11
    && ['enabled', 'last_run_at', 'next_run_at', 'failure_count', 'owner_id'].every((k) => k in byKey.sales_no_reply), rules.err);
  check('messaggi agli utenti: disattivati di default e con approvazione + consenso obbligatori', ['consumer_category_affinity', 'consumer_abandoned_cart', 'consumer_dormant_reactivation']
    .every((k) => !byKey[k].enabled && byKey[k].requires_approval && byKey[k].consent_required));
  check('vincolo DB: una bozza utente senza approvazione è impossibile', !(await as(null, `select 1`)).err
    && !(await db.query(`update public.automation_rules set requires_approval = false where key = 'consumer_abandoned_cart'`).then(() => true, () => false)));
  check('"prenotazione abbandonata" dichiarata non disponibile e non attivabile', byKey.consumer_abandoned_reservation.action === 'unavailable'
    && !(await rpc(U.admin, 'admin_automation_rule_update', [byKey.consumer_abandoned_reservation.id, { enabled: true }])).ok);
  // Task interno: profilo incompleto (le automazioni agiscono solo su locali reali, mai DEMO)
  await db.exec(`update public.restaurants set is_demo = false where id in ('${SEOUL}', '${KOEN}')`);
  check('locali DEMO esclusi dalle automazioni', (await val(`select count(*) from public.restaurants where is_demo = false`)) === 2);
  await rpc(U.admin, 'admin_automation_rule_update', [byKey.restaurant_incomplete_profile.id, { config: { threshold: 99 } }]);
  const dry = await rpc(U.admin, 'admin_automation_run_now', [byKey.restaurant_incomplete_profile.id, true]);
  check('dry-run: conta i candidati senza scrivere', dry.ok && dry.r.dry_run === true && (await val(`select count(*) from public.automation_items where rule_id = $1`, [byKey.restaurant_incomplete_profile.id])) === 0, dry.err || dry.r);
  const run = await rpc(U.admin, 'admin_automation_run_now', [byKey.restaurant_incomplete_profile.id, false]);
  const tasks1 = await val(`select count(*) from public.crm_tasks where reason = 'growth_incomplete'`);
  await rpc(U.admin, 'admin_automation_run_now', [byKey.restaurant_incomplete_profile.id, false]);
  check('esecuzione crea task CRM; ripeterla non duplica (deduplica)', run.ok && run.r.status === 'success' && tasks1 >= 1 && (await val(`select count(*) from public.crm_tasks where reason = 'growth_incomplete'`)) === tasks1, run.r);
  check('ogni esecuzione registrata in automation_runs', (await val(`select count(*) from public.automation_runs where rule_id = $1`, [byKey.restaurant_incomplete_profile.id])) === 3);
  // Kill switch
  await rpc(U.admin, 'admin_automation_kill_switch', [true]);
  const ks = await rpc(U.admin, 'admin_automation_run_now', [byKey.restaurant_incomplete_profile.id, false]);
  check('kill switch: nessuna esecuzione (skipped)', ks.r.status === 'skipped');
  check('automation_run_due con kill switch non esegue nulla', (await store.rpc<any>('automation_run_due', {})).kill_switch === true);
  await rpc(U.admin, 'admin_automation_kill_switch', [false]);
  // Bozza consumer con consenso
  const aff = byKey.consumer_category_affinity;
  await db.exec(`insert into public.favorites (user_id, restaurant_id) values ('${U.alice}', '${KAIZEN}'), ('${U.alice}', '${MASSAFRA_SUSHI}'), ('${U.alice}', '${R(8)}'),
                   ('${U.bob}', '${KAIZEN}'), ('${U.bob}', '${MASSAFRA_SUSHI}'), ('${U.bob}', '${R(8)}') on conflict do nothing;
                 update public.notification_preferences set marketing = true where user_id = '${U.alice}';
                 update public.notification_preferences set marketing = false where user_id = '${U.bob}';`);
  const hasOffer = await val(`select count(*) from public.offers o join public.restaurant_categories rc on rc.restaurant_id = o.restaurant_id join public.categories c on c.id = rc.category_id
                               where c.slug = 'sushi' and o.is_active and (o.ends_at is null or o.ends_at > now())`);
  const off = await rpc(U.admin, 'admin_automation_run_now', [aff.id, false]);
  check('regola disattivata → non eseguita', off.r.status === 'skipped');
  await rpc(U.admin, 'admin_automation_rule_update', [aff.id, { enabled: true, config: { min_favorites: 3, evil: 'x' } }]);
  check('config: solo chiavi previste (chiavi estranee ignorate)', !('evil' in (await val(`select config from public.automation_rules where id = $1`, [aff.id]))));
  await rpc(U.admin, 'admin_automation_run_now', [aff.id, false]);
  const items = await rpc(U.admin, 'admin_automation_items', ['pending_approval', 100]);
  const mine = items.r.filter((i: any) => i.rule_id === aff.id);
  check(`bozza solo per chi ha il consenso marketing (alice sì, bob no)${hasOffer ? '' : ' — nessuna offerta sushi: nessuna bozza'}`,
    hasOffer ? mine.length === 1 && (await val(`select target_user_id from public.automation_items where rule_id = $1`, [aff.id])) === U.alice : mine.length === 0, [hasOffer, mine]);
  check('coda approvazioni: nessun dato di contatto esposto (solo "has_recipient")', items.r.every((i: any) => !('target_user_id' in i) && !JSON.stringify(i).includes('@test.it')));
  if (hasOffer) {
    const notifBefore = await val(`select count(*) from public.notifications where user_id = $1`, [U.alice]);
    check('nessun invio prima dell\'approvazione', (await val(`select count(*) from public.notifications where user_id = $1 and type = 'marketing_campaign'`, [U.alice])) === 0);
    const dec = await rpc(U.admin, 'admin_automation_decide', [mine[0].id, true]);
    check('approvazione umana → notifica in-app inviata e registrata', dec.r === 'sent' && (await val(`select count(*) from public.notifications where user_id = $1`, [U.alice])) === notifBefore + 1, dec);
    // consenso revocato prima dell'approvazione → skipped
    await db.exec(`insert into public.automation_items (rule_id, dedupe_key, status, target_user_id, title) values ('${aff.id}', 'test:revoked', 'pending_approval', '${U.alice}', 'Test');
                   update public.notification_preferences set marketing = false where user_id = '${U.alice}';`);
    const it = await val(`select id from public.automation_items where dedupe_key = 'test:revoked'`);
    check('consenso revocato prima dell\'approvazione → non inviato', (await rpc(U.admin, 'admin_automation_decide', [it, true])).r === 'skipped_no_consent');
  }
  check('automazioni: solo Admin', denied(await rpc(U.owner, 'admin_automation_rules', [])) && denied(await rpc(U.owner, 'admin_automation_run_now', [aff.id, false])));
  check('runner interni non eseguibili dai client', denied(await rpc(U.admin, 'automation_run', [aff.id, 'manual'])) && denied(await rpc(U.admin, 'automation_run_due', [])));
  check('modifiche alle regole nell\'audit log', (await val(`select count(*) from public.admin_audit_logs where action in ('automation_rule_update', 'automation_kill_switch', 'automation_item_sent', 'automation_run_manual')`)) >= 3);
  // Errori ripetuti → disattivazione automatica
  await db.exec(`update public.automation_rules set config = config || '{"threshold": "non-numero"}'::jsonb where key = 'restaurant_incomplete_profile'`);
  for (let i = 0; i < 5; i++) await rpc(U.admin, 'admin_automation_run_now', [byKey.restaurant_incomplete_profile.id, false]);
  const failed = await q1(`select enabled, failure_count, last_error from public.automation_rules where key = 'restaurant_incomplete_profile'`);
  check('5 errori consecutivi → regola disattivata automaticamente (con errore registrato)', failed.enabled === false && failed.failure_count === 5 && failed.last_error, failed);
  await db.exec(`update public.automation_rules set config = '{"threshold": 99}' where key = 'restaurant_incomplete_profile'`);
  await rpc(U.admin, 'admin_automation_rule_update', [byKey.restaurant_incomplete_profile.id, { enabled: true }]);
  check('riattivazione azzera il contatore errori', (await val(`select failure_count from public.automation_rules where key = 'restaurant_incomplete_profile'`)) === 0);
}

// ════════════════════════════════════════════════════════════
section('15. Esperimenti: varianti, guardrail, assegnazioni, report senza falsi vincitori');
{
  const id = (await rpc(U.admin, 'admin_experiment_upsert', [{ key: 'cta_home', name: 'CTA home', primary_metric: 'reservation_completed', variants: [{ name: 'control', allocation: 50 }, { name: 'variant_b', allocation: 50 }] }])).r;
  check('varianti con allocazione in experiment_variants', (await val(`select sum(allocation_percentage) from public.experiment_variants where experiment_id = $1`, [id])) === 100);
  check('allocazioni che non sommano a 100 rifiutate', !(await rpc(U.admin, 'admin_experiment_upsert', [{ key: 'bad_alloc', name: 'Bad', variants: [{ name: 'a', allocation: 70 }, { name: 'b', allocation: 70 }] }])).ok);
  const pid = (await rpc(U.admin, 'admin_experiment_upsert', [{ key: 'price_test', name: 'Prezzo piano', guardrail_area: 'pricing', variants: ['control', 'variant_b'] }])).r;
  const st = await rpc(U.admin, 'admin_experiment_set_status', [pid, 'running']);
  check('esperimento su prezzi: avvio bloccato senza revisione', !st.ok && /revisione/.test(st.err), st.err);
  check('chi crea non può auto-approvarsi', !(await rpc(U.admin, 'admin_experiment_review', [pid, 'Revisionato da me stesso'])).ok);
  const rv = await rpc(U.admin2, 'admin_experiment_review', [pid, 'Verificato con legale e prodotto: nessun impatto sui prezzi pagati.']);
  check('revisione di un secondo Admin → avvio consentito', rv.ok && (await rpc(U.admin, 'admin_experiment_set_status', [pid, 'running'])).ok, rv.err);
  await rpc(U.admin, 'admin_experiment_set_status', [pid, 'stopped']);
  await rpc(U.admin, 'admin_experiment_set_status', [id, 'running']);
  const running = await rpc(null, 'running_experiments', []);
  check('running_experiments espone pesi e metrica (pubblico, nessun dato utente)', running.ok && running.r.some((e: any) => e.key === 'cta_home' && e.weights.join() === '50,50'));
  for (let i = 0; i < 6; i++) await rpc(null, 'experiment_assign', ['cta_home', i % 2 ? 'variant_b' : 'control', `anonexp${i}xx`]);
  await rpc(null, 'experiment_assign', ['cta_home', 'hacked', 'anonexp9xx']);
  await rpc(null, 'experiment_assign', ['cta_home', 'control', 'anonexp0xx']);
  check('assegnazioni idempotenti; varianti inesistenti ignorate', (await val(`select count(*) from public.experiment_assignments where experiment_id = $1`, [id])) === 6);
  await rpc(null, 'experiment_goal', ['reservation_completed', 'anonexp1xx']);
  await rpc(null, 'experiment_goal', ['order_completed', 'anonexp3xx']);
  check('conversione solo sulla metrica primaria', (await val(`select count(*) from public.experiment_assignments where experiment_id = $1 and converted_at is not null`, [id])) === 1);
  const rep = await rpc(U.admin, 'admin_experiment_report', [id]);
  const verdict = experimentVerdict(rep.r.variants, rep.r.min_sample);
  check('report: nessun vincitore con campione insufficiente', rep.ok && verdict.winner === null && /Campione insufficiente/.test(verdict.reason), verdict);
  const big = experimentVerdict([{ variant: 'control', users: 1000, conversions: 100 }, { variant: 'b', users: 1000, conversions: 140 }], 100);
  const flat = experimentVerdict([{ variant: 'control', users: 1000, conversions: 100 }, { variant: 'b', users: 1000, conversions: 104 }], 100);
  check('vincitore solo se significativo (|z| ≥ 1,96) con uplift riportato', big.winner === 'b' && big.rows[1]!.upliftPct === 40 && flat.winner === null, [big, flat]);
  check('assegnazione pesata stabile e compatibile', pickWeighted('k', ['a', 'b'], [50, 50], 'x') === pickWeighted('k', ['a', 'b'], [50, 50], 'x')
    && Array.from({ length: 400 }, (_, i) => pickWeighted('k', ['a', 'b'], [90, 10], `id${i}`)).filter((v) => v === 'a').length > 300);
}

// ════════════════════════════════════════════════════════════
section('16. Report settimanale, brief "Today", task da insight');
{
  const from = await dayAgo(13);
  const to = await dayAgo(7);
  const r1 = await rpc(U.admin, 'admin_growth_generate_report', ['weekly', from, to, null]);
  const r2 = await rpc(U.admin, 'admin_growth_generate_report', ['weekly', from, to, null]);
  check('report settimanale salvato in growth_reports; rigenerarlo non duplica', r1.ok && r1.r === r2.r && (await val(`select count(*) from public.growth_reports where report_type = 'weekly'`)) === 1, r1.err);
  const rep = await q1(`select summary, metrics_json from public.growth_reports where id = $1`, [r1.r]);
  check('sintesi costruita dai numeri: lo zero resta zero', /Ordini pagati: \d+/.test(rep.summary) && /Prenotazioni: \d+/.test(rep.summary) && rep.metrics_json.current, rep.summary);
  check('sezioni: utenti, ristoranti, vendite, ricavi, retention, ricerche, gap, rischi, prossime azioni',
    ['restaurants', 'sales', 'revenue', 'retention_d7', 'top_searches', 'supply_gaps', 'churn_risks', 'next_actions'].every((k) => k in rep.metrics_json));
  const t = await rpc(U.admin, 'admin_growth_today', []);
  check('brief "Today": massimo 10 priorità ordinate', t.ok && t.r.length <= 10 && t.r.length > 0 && t.r.every((x: any, i: number) => i === 0 || x.priority >= t.r[i - 1].priority), t.err || t.r);
  const tid = await rpc(U.admin, 'admin_growth_task_upsert', [{ title: 'Cercare ristoranti ramen a Massafra', source: 'insight', source_ref: 'gap:massafra:ramen', priority: 'high' }]);
  const tid2 = await rpc(U.admin, 'admin_growth_task_upsert', [{ title: 'Cercare ristoranti ramen a Massafra', source: 'insight', source_ref: 'gap:massafra:ramen' }]);
  check('task da insight: stesso insight → stesso task (nessun duplicato)', tid.ok && tid.r === tid2.r, [tid, tid2]);
  check('task: nessuna esecuzione automatica (solo stato open/done/dismissed)', (await rpc(U.admin, 'admin_growth_task_set_status', [tid.r, 'done'])).ok
    && !(await rpc(U.admin, 'admin_growth_task_set_status', [tid.r, 'execute'])).ok);
  const ev = await rpc(U.admin, 'admin_growth_learning_evidence', ['taranto']);
  check('knowledge base: evidenze calcolate con avviso "verificare prima di applicare"', ev.ok && /vanno verificate/.test(ev.r.note));
  const lid = await rpc(U.admin, 'admin_growth_learning_upsert', [{ market: 'taranto', category: 'outreach', title: 'WhatsApp risponde meglio', description: 'Osservato su 12 contatti.', evidence: ev.r.outreach, confidence: 'low' }]);
  check('growth_learnings: apprendimento con evidenze e confidenza', lid.ok && (await val(`select confidence from public.growth_learnings where id = $1`, [lid.r])) === 'low');
  check('confidenza non valida rifiutata', !(await rpc(U.admin, 'admin_growth_learning_upsert', [{ category: 'outreach', title: 'X x x', description: 'y', confidence: 'certissima' }])).ok);
}

// ════════════════════════════════════════════════════════════
section('17. Costi e unit economics (solo reali/configurati, ipotesi etichettate)');
{
  const add = await rpc(U.admin, 'admin_operating_cost_add', [{ category: 'infrastructure', amount_cents: 3000, period_start: await dayAgo(29), period_end: today }]);
  const c = await rpc(U.admin, 'admin_growth_costs', [await dayAgo(9), today]);
  const infra = c.r?.costs?.find((x: any) => x.key === 'infrastructure');
  check('costi manuali ripartiti per giorni (10/30 di 30 € = 10 €)', add.ok && Number(infra.cents) === 1000, c.err || infra);
  check('costo AI calcolato dal consumo (etichettato come stima)', Number(c.r.costs.find((x: any) => x.key === 'ai').cents) > 0 && /tariffe/.test(c.r.costs[0].label));
  check('costo di incasso stimato solo se ipotesi configurata', c.r.costs.find((x: any) => x.key === 'payment_processing_estimate').cents === null);
  check('unit economics con ipotesi dichiarate', c.r.unit.assumptions.some((a: string) => /APPROSSIMATO/.test(a ?? '')));
  check('costi: solo Admin', denied(await rpc(U.owner, 'admin_growth_costs', [await dayAgo(9), today])));
}

// ════════════════════════════════════════════════════════════
section('18. Performance ristoratore e Copilot: solo i dati del proprio locale');
{
  const p = await rpc(U.owner, 'restaurant_performance', [SEOUL]);
  check('titolare: performance del proprio locale (7/30 giorni + precedenti)', p.ok && p.r.periods['7'].current.views === 30 && 'previous' in p.r.periods['30'], p.err || p.r?.periods);
  check('titolare di un altro locale: accesso negato', denied(await rpc(U.owner2, 'restaurant_performance', [SEOUL])));
  check('cliente: accesso negato', denied(await rpc(U.alice, 'restaurant_performance', [SEOUL])));
  check('anonimo: non eseguibile', denied(await rpc(null, 'restaurant_performance', [SEOUL])));
  check('Admin: consentito', (await rpc(U.admin, 'restaurant_performance', [SEOUL])).ok);
  const rows = await as(U.owner2, `select restaurant_id from public.daily_restaurant_metrics`);
  check('RLS aggregati: il titolare vede solo le righe dei propri locali', rows.ok && rows.rows.every((x: any) => x.restaurant_id === KOEN));
  const perf = p.r as RestaurantPerformance;
  const ans = copilotAnswer('Quante prenotazioni ho ricevuto?', perf);
  check('Copilot: risposta dai dati autorizzati', ans.intent === 'bookings' && ans.sources.length > 0);
  check('Copilot: nessuna analisi dei concorrenti', copilotIntent('Come vanno i miei concorrenti?') === 'unknown' && /Non ho dati su altri ristoranti/.test(copilotAnswer('come vanno gli altri ristoranti vicino?', perf).answer));
  const perfAns = copilotAnswer('Come sta andando il mio profilo?', perf);
  check('Copilot: "come sta andando" cita solo numeri del payload', perfAns.answer.includes('30') && perfAns.answer.includes(perf.restaurant.name), perfAns.answer);
  const ins = restaurantInsights(perf);
  check('insight deterministici (es. "Non hai offerte attive")', perf.offers_active > 0 || ins.some((i) => i.key === 'no_offers'));
  check('raccomandazioni senza garanzie', restaurantRecommendations(perf).every((r) => !/garantit/i.test(r.title + r.why)));
}

// ════════════════════════════════════════════════════════════
section('19. Admin AI Analyst (strumenti controllati, niente SQL) e funzioni pure');
{
  check('le domande operative sono instradate agli strumenti previsti', ANALYST_QUESTIONS.every((x) => analystRoute(x.q) === x.tool), ANALYST_QUESTIONS.filter((x) => analystRoute(x.q) !== x.tool));
  check('richieste SQL rifiutate', analystRoute('select * from profiles') === null && analystRoute('drop table orders; --') === null);
  const csv = toCsv([{ a: '=HYPERLINK("x")', b: 'ok;semi', c: null }], [{ key: 'a', label: 'A' }, { key: 'b', label: 'B' }, { key: 'c', label: 'C' }]);
  check('CSV: protezione formula injection ed escaping', csv.split('\n')[1] === `"'=HYPERLINK(""x"")";"ok;semi";`, csv);
  const fc = forecast({ restaurants_contacted: 100, claim_rate: 0.3, trial_rate: 0.5, trial_to_paid: 0.4, arpa_cents: 2900 });
  check('forecast: scenario su ipotesi, sempre etichettato', fc.paying === 6 && fc.mrr_cents === 17400 && /ipotesi/.test(fc.label));
}

// ════════════════════════════════════════════════════════════
section('20. Impostazioni, oblio, job pianificati');
{
  check('impostazioni: chiavi non Growth rifiutate', !(await rpc(U.admin, 'admin_growth_setting_set', ['stripe_secret', 'x'])).ok);
  check('impostazioni: valori numerici validati', !(await rpc(U.admin, 'admin_growth_setting_set', ['growth_min_sample', -3])).ok && (await rpc(U.admin, 'admin_growth_setting_set', ['growth_min_sample', 30])).ok);
  check('impostazioni: solo Admin', denied(await rpc(U.owner, 'admin_growth_setting_set', ['growth_min_sample', 5])));
  // Oblio: bob con assegnazione ed eventuale bozza
  const eid = await val(`select id from public.experiments where key = 'cta_home'`);
  await db.exec(`update public.experiment_assignments set user_id = '${U.bob}' where anonymous_id = 'anonexp0xx';
    insert into public.automation_items (rule_id, dedupe_key, status, target_user_id, title) select id, 'forget:bob', 'pending_approval', '${U.bob}', 'x' from public.automation_rules where key = 'consumer_abandoned_cart';`);
  const del = await store.rpc<string>('account_anonymize', { p_user: U.bob });
  check('anonimizzazione account: bozze rimosse e assegnazioni scollegate', del === 'anonymized' && (await val(`select count(*) from public.automation_items where target_user_id = $1`, [U.bob])) === 0
    && (await val(`select count(*) from public.experiment_assignments where user_id = $1 and experiment_id = $2`, [U.bob, eid])) === 0, del);
  check('aggregati anonimi restano dopo la cancellazione', (await val(`select count(*) from public.daily_platform_metrics`)) > 0);
  // Job
  check('job orario/giornaliero solo backend', denied(await rpc(U.admin, 'growth_hourly', [])) && denied(await rpc(U.admin, 'growth_daily', [])));
  await db.exec(`insert into public.search_events (source, query_norm, result_count, created_at) values ('explore', 'vecchia ricerca', 1, now() - interval '200 days')`);
  const d = await store.rpc<any>('growth_daily', {});
  check('job giornaliero: pulizia ricerche oltre la conservazione + report settimanale', d.purged_searches >= 1 && d.weekly_report && (await val(`select count(*) from public.search_events where query_norm = 'vecchia ricerca'`)) === 0, d);
  const d2 = await store.rpc<any>('growth_daily', {});
  check('job giornaliero idempotente (stesso report)', d2.weekly_report === d.weekly_report);
  const h = await store.rpc<any>('growth_hourly', {});
  check('job orario: oggi + alert + automazioni dovute', h.alerts && h.automations && 'runs' in h.automations, h);
}

// ════════════════════════════════════════════════════════════
section('21. RLS e grant');
{
  const tables = ['growth_event_taxonomy', 'search_events', 'daily_platform_metrics', 'daily_market_metrics', 'daily_restaurant_metrics', 'daily_acquisition_metrics',
    'daily_search_metrics', 'growth_computed_days', 'growth_alerts', 'automation_rules', 'automation_runs', 'automation_items', 'experiment_variants', 'experiment_assignments',
    'growth_reports', 'growth_tasks', 'growth_learnings', 'expansion_candidates', 'market_playbook_items', 'operating_costs'];
  const noRls = await db.query<any>(`select relname from pg_class where relname = any($1) and relnamespace = 'public'::regnamespace and not relrowsecurity`, [tables]);
  check('RLS attiva su tutte le 20 nuove tabelle', noRls.rows.length === 0 && (await val(`select count(*) from pg_class where relname = any($1) and relnamespace = 'public'::regnamespace`, [tables])) === 20, noRls.rows);
  let leak = false;
  for (const t of tables) {
    const r = await as(U.owner, `select count(*) c from public.${t}`);
    if (t === 'daily_restaurant_metrics') continue;
    if (r.ok && Number(r.rows[0].c) > 0) { leak = true; console.log('leak', t); }
  }
  check('un ristoratore non legge nessuna tabella Growth (tranne le proprie metriche)', !leak);
  const anonAdmin = await db.query<any>(`select p.proname from pg_proc p where p.pronamespace = 'public'::regnamespace and (p.proname like 'admin\\_growth%' or p.proname like 'admin\\_automation%')
    and has_function_privilege('anon', p.oid, 'execute')`);
  check('nessuna funzione admin_growth/admin_automation eseguibile da anonimi', anonAdmin.rows.length === 0, anonAdmin.rows);
  const internal = await db.query<any>(`select p.proname from pg_proc p where p.pronamespace = 'public'::regnamespace and (p.proname like 'growth\\_%' or p.proname like 'automation\\_%')
    and p.proname <> 'growth_backfill' and p.prorettype <> 'trigger'::regtype and has_function_privilege('authenticated', p.oid, 'execute')`);
  check('funzioni interne growth_*/automation_* non eseguibili dai client', internal.rows.length === 0, internal.rows);
  check('scritture dirette sulle tabelle Growth negate ai client', !(await as(U.admin, `insert into public.growth_tasks (title) values ('diretto')`)).ok
    && !(await as(U.admin, `update public.automation_rules set enabled = true`)).ok || (await val(`select count(*) from public.growth_tasks where title = 'diretto'`)) === 0);
}

console.log(`\n${pass} superati, ${fail} falliti`);
process.exit(fail ? 1 : 0);
