/* eslint-disable @typescript-eslint/no-explicit-any */
// ─────────────────────────────────────────────────────────────
//  Test unitari (base della piramide): utility, denaro, distanze, orari, entitlements,
//  validazione (Zod), upload, redirect sicuri, ambienti. Nessun database, nessuna rete.
//  Uso: npm run test:unit
// ─────────────────────────────────────────────────────────────
import { lineTotal, percentOf, sumMoney, toCents, fromCents } from '../shared/money';
import { fieldErrors, signupSchema, supportSchema, reviewSchema, reservationSchema, riderLocationSchema, orderNumberSchema, passwordSchema } from '../shared/validation';
import { checkUpload, sniffMime, safeStorageName } from '../shared/uploads';
import { resolveAppEnv } from '../shared/platform/environment';
import { safeNext } from '../src/lib/safeRedirect';
import { haversineKm } from '../src/lib/geo';
import { openState, toMinutes } from '../src/lib/hours';
import { hasFeature, withinLimit, getFeatureLimit } from '../src/lib/entitlements';
import { slugify, formatDistance } from '../src/lib/format';
import { normalizeAllergens, isMenuPublicToday } from '../src/lib/menu';
import { isValidVat, isValidTaxCode } from '../src/lib/validation';
import { parseSearchQuery } from '../src/lib/searchQuery';
import { buildUtmUrl, classifyChannel, cleanUtmValue } from '../shared/utm';
import { pickVariant } from '../shared/experiment';
import { emailTemplate, phoneScript, whatsappMessage, OBJECTIONS } from '../src/lib/outreach';
import { pressRelease } from '../src/lib/launchTemplates';

let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) { pass++; console.log('  ✓', name); } else { fail++; console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 400) : ''); }
}
const section = (t: string) => console.log(`\n── ${t}`);

section('Denaro (centesimi interi, mai somme di float)');
check('0,1 + 0,2 = 0,3 esatto', sumMoney([0.1, 0.2]) === 0.3, sumMoney([0.1, 0.2]));
check('1,005 € → 101 centesimi (arrotondamento commerciale)', toCents(1.005) === 101, toCents(1.005));
check('stringhe numeric dal DB', toCents('12.90') === 1290 && fromCents(1290) === 12.9);
check('riga 3 × 12,90 = 38,70', lineTotal(12.9, 3) === 38.7);
check('quantità negativa/frazionaria non genera importi', lineTotal(5, -2) === 0 && lineTotal(5, 2.7) === 10);
check('commissione 10% su 11 € = 1,10', percentOf(11, 10) === 1.1);
check('importo non numerico → 0', toCents('abc') === 0 && toCents(null) === 0 && toCents(Infinity) === 0);
check('somma di 100 × 0,07 = 7,00', sumMoney(Array(100).fill(0.07)) === 7);

section('Distanze e orari');
const taranto = { lat: 40.4644, lng: 17.247 };
const massafra = { lat: 40.5875, lng: 17.1142 };
const d = haversineKm(taranto, massafra);
check('Taranto → Massafra ≈ 17,6 km', d > 17 && d < 18.5, d);
check('distanza nulla', haversineKm(taranto, taranto) === 0);
check('formato distanza (m sotto 1 km)', /m$/.test(formatDistance(0.45)) && /km$/.test(formatDistance(3.2)));
check('orario → minuti', toMinutes('19:30') === 1170 && toMinutes(null) === 0);
const hours: any[] = [{ day_of_week: 5, opens_at: '19:00', closes_at: '01:00', is_closed: false }, { day_of_week: 6, opens_at: '19:00', closes_at: '23:30', is_closed: false }];
// Venerdì 3 ottobre 2025 alle 23:45 e sabato 00:30 (ora di Roma)
const fri2345 = new Date('2025-10-03T21:45:00Z');
const sat0030 = new Date('2025-10-03T22:30:00Z');
const sat1200 = new Date('2025-10-04T10:00:00Z');
check('aperto venerdì 23:45 (fascia oltre mezzanotte)', openState(hours, 'Europe/Rome', fri2345).kind === 'open', openState(hours, 'Europe/Rome', fri2345));
check('ancora aperto sabato 00:30 (coda del venerdì)', openState(hours, 'Europe/Rome', sat0030).kind === 'open', openState(hours, 'Europe/Rome', sat0030));
check('chiuso sabato alle 12', openState(hours, 'Europe/Rome', sat1200).kind !== 'open');
check('orari senza fasce → stato non "aperto"', openState([], 'Europe/Rome', fri2345).kind !== 'open');
check('menu non ancora valido nascosto', !isMenuPublicToday({ is_active: true, is_public: true, valid_from: '2999-01-01', valid_until: null }));

section('Entitlements (piani)');
const pf = (feature_key: string, enabled: boolean, limit_value: number | null = null) => ({ feature_key, enabled, limit_value });
const plans: any[] = [
  { code: 'free', is_active: true, sort_order: 0, plan_features: [pf('max_images', true, 3), pf('offers_enabled', false)] },
  { code: 'premium', is_active: true, sort_order: 2, plan_features: [pf('max_images', true, 30), pf('offers_enabled', true), pf('max_menu_items', true, null)] },
];
check('free: niente offerte', !hasFeature(plans, 'free', 'offers_enabled'));
check('premium: offerte', hasFeature(plans, 'premium', 'offers_enabled'));
check('limite immagini free = 3', getFeatureLimit(plans, 'free', 'max_images') === 3, getFeatureLimit(plans, 'free', 'max_images'));
check('free con 3 immagini: limite raggiunto', !withinLimit(plans, 'free', 'max_images', 3));
check('piano sconosciuto: nessuna funzione', !hasFeature(plans, 'enterprise', 'offers_enabled'));
check('limite null = illimitato', withinLimit(plans, 'premium', 'max_menu_items', 10_000));

section('Utility di testo e dati');
check('slug SEO', slugify('Sushi & Ramen Kōen!') === 'sushi-ramen-koen', slugify('Sushi & Ramen Kōen!'));
check('slug senza caratteri pericolosi', /^[a-z0-9-]+$/.test(slugify('<script>alert(1)</script> ../..')));
check('allergeni normalizzati (numero UE e codici)', normalizeAllergens([1, 'crustaceans', 'xyz']).length === 2, normalizeAllergens([1, 'crustaceans', 'xyz']));
check('P.IVA: formato e check digit', isValidVat('00000000000') && !isValidVat('12345678901') && !isValidVat('123'));
check('codice fiscale persona/società', isValidTaxCode('RSSMRA80A01L049X') && isValidTaxCode('01234567890') && !isValidTaxCode('ABC'));
const cats = [{ id: '1', slug: 'sushi', name: 'Sushi' }];
const cities = [{ id: 'c', slug: 'taranto', name: 'Taranto' }];
const q = parseSearchQuery('sushi a taranto', cats as any, cities as any);
check('ricerca "sushi a taranto" → categoria + città', q.categorySlug === 'sushi' && q.citySlug === 'taranto', q);

section('Validazione centralizzata (Zod)');
const su = fieldErrors(signupSchema, { name: 'M', email: 'nope', password: 'abc', terms: false });
check('registrazione: errori per campo in italiano', !su.ok && 'email' in su.errors && 'password' in su.errors && 'terms' in su.errors && 'name' in su.errors, su);
check('password: lettere + numeri, 8–72', passwordSchema.safeParse('password1').success && !passwordSchema.safeParse('password').success && !passwordSchema.safeParse('a1'.repeat(40)).success);
const sup = supportSchema.safeParse({ category: 'order', subject: 'Ritardo', description: 'Ordine non arrivato da un\'ora.', order_number: 'af-261004-ab12' });
check('supporto: numero ordine normalizzato in maiuscolo', sup.success && sup.data.order_number === 'AF-261004-AB12', sup);
check('supporto: categoria arbitraria rifiutata', !supportSchema.safeParse({ category: 'hack', subject: 'abc', description: 'abcdefghijk' }).success);
check('numero ordine malformato rifiutato', !orderNumberSchema.safeParse("AF-1'; drop table orders;--").success);
check('recensione: voto 1–5 e testo minimo', !reviewSchema.safeParse({ rating_overall: 6, content: 'x'.repeat(30) }).success && !reviewSchema.safeParse({ rating_overall: 5, content: 'breve' }).success);
check('prenotazione: telefono e persone validati', !reservationSchema.safeParse({ guest_name: 'A', guest_surname: 'B', guest_phone: 'abc', party_size: 0, reservation_date: '2026-10-10', reservation_time: '20:00' }).success);
check('GPS Rider: coordinate fuori range rifiutate', !riderLocationSchema.safeParse({ latitude: 95, longitude: 17 }).success && riderLocationSchema.safeParse({ latitude: 40.4, longitude: 17.2, accuracy: 12 }).success);

section('Upload sicuri (firma reale del file)');
const JPG = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0]);
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
const PDF = new TextEncoder().encode('%PDF-1.7\n');
const EXE = new Uint8Array([0x4d, 0x5a, 0x90, 0]);
const SVG = new TextEncoder().encode('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');
const WEBP = new Uint8Array([0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x45, 0x42, 0x50]);
check('riconosce JPEG/PNG/WebP/PDF', sniffMime(JPG) === 'image/jpeg' && sniffMime(PNG) === 'image/png' && sniffMime(WEBP) === 'image/webp' && sniffMime(PDF) === 'application/pdf');
check('immagine valida accettata con MIME reale', checkUpload({ name: 'foto.JPG', type: 'image/jpeg', size: 200_000 }, JPG, 'image').mime === 'image/jpeg');
check('eseguibile rinominato .jpg rifiutato', !checkUpload({ name: 'foto.jpg', type: 'image/jpeg', size: 1000 }, EXE, 'image').ok);
check('SVG (script) rifiutato anche come immagine', !checkUpload({ name: 'logo.svg', type: 'image/svg+xml', size: 1000 }, SVG, 'image').ok);
check('HTML travestito da PDF rifiutato', !checkUpload({ name: 'doc.pdf', type: 'application/pdf', size: 1000 }, new TextEncoder().encode('<!doctype html><script>'), 'document').ok);
check('doppia estensione pericolosa rifiutata', !checkUpload({ name: 'doc.exe.pdf', type: 'application/pdf', size: 1000 }, PDF, 'document').ok);
check('oltre il limite di dimensione', !checkUpload({ name: 'foto.png', type: 'image/png', size: 6 * 1024 * 1024 }, PNG, 'image').ok);
check('limite configurabile', !checkUpload({ name: 'foto.png', type: 'image/png', size: 3 * 1024 * 1024 }, PNG, 'image', 2).ok);
check('PDF non ammesso come foto di consegna', !checkUpload({ name: 'x.pdf', type: 'application/pdf', size: 1000 }, PDF, 'proof').ok);
check('file vuoto rifiutato', !checkUpload({ name: 'x.png', type: 'image/png', size: 0 }, PNG, 'image').ok);
check('nome di storage casuale (niente dati personali nel percorso)', /^[0-9a-f-]{36}\.webp$/.test(safeStorageName('webp')) && safeStorageName('../../etc') .endsWith('.etc'));

section('Redirect sicuri e ambienti');
check('percorso interno consentito', safeNext('/orders/AF-1?t=x') === '/orders/AF-1?t=x');
for (const bad of ['//evil.com', '/\\evil.com', '/%5Cevil.com', '/%2F%2Fevil.com', 'https://evil.com', 'javascript:alert(1)', '/\tjavascript:x', '/%0d%0aSet-Cookie:x', '']) {
  check(`open redirect bloccato: ${JSON.stringify(bad)}`, safeNext(bad) === '/profilo');
}
check('ambiente da CONTEXT Netlify', resolveAppEnv('', 'production') === 'production' && resolveAppEnv(null, 'branch-deploy') === 'staging' && resolveAppEnv('weird', null) === 'development');

// ─── Fase 12 · go-to-market ───
check('UTM: valori normalizzati (minuscolo, niente caratteri pericolosi)', cleanUtmValue('Taranto Launch<script>') === 'taranto_launchscript');
check('UTM: link relativo con parametri', buildUtmUrl('/taranto', { source: 'restaurant_qr', medium: 'offline', campaign: 'taranto_launch' }) === '/taranto?utm_source=restaurant_qr&utm_medium=offline&utm_campaign=taranto_launch');
check('UTM: sostituisce parametri esistenti, conserva gli altri', buildUtmUrl('https://x.it/a?utm_source=old&k=1', { source: 'new', medium: 'm', campaign: 'c' }) === 'https://x.it/a?utm_source=new&k=1&utm_medium=m&utm_campaign=c');
check('canale: QR dal percorso /r/…', classifyChannel({ path: '/r/kaizen/menu' }) === 'qr');
check('canale: invito', classifyChannel({ path: '/invite/ABCD-1234' }) === 'referral');
check('canale: ricerca organica da Google', classifyChannel({ referrer: 'https://www.google.it/', ownHost: 'asiafood.it' }) === 'organic_search');
check('canale: social da Instagram', classifyChannel({ referrer: 'https://l.instagram.com/', ownHost: 'asiafood.it' }) === 'social');
check('canale: navigazione interna = diretto', classifyChannel({ referrer: 'https://asiafood.it/map', ownHost: 'asiafood.it' }) === 'direct');
check('canale: UTM prevale sul referrer', classifyChannel({ utm_source: 'creator', utm_medium: 'influencer', referrer: 'https://google.com' }) === 'influencer');
check('esperimenti: variante stabile per lo stesso id', pickVariant('hero_cta', ['control', 'variant_b'], 'abc') === pickVariant('hero_cta', ['control', 'variant_b'], 'abc'));
const spread = new Set(Array.from({ length: 50 }, (_, i) => pickVariant('hero_cta', ['control', 'variant_b'], `id${i}`)));
check('esperimenti: entrambe le varianti assegnate su 50 id', spread.size === 2);
const noProfile = whatsappMessage({ business: 'Sakura', profileUrl: null });
check('outreach: “già presente” solo se la scheda esiste davvero', !/già presente/.test(noProfile) && /già presente/.test(whatsappMessage({ business: 'Sakura', profileUrl: 'https://x/r' })));
check('outreach: CTA singola "Ti mando il link della vostra scheda?" con scheda', whatsappMessage({ business: 'Sakura', profileUrl: 'https://x/r' }).trim().endsWith('Ti mando il link della vostra scheda?'));
check('outreach: offerta Fondatori solo se posti disponibili', !emailTemplate({ business: 'S', founding: { enabled: true, name: 'PF', plan: 'premium', days: 30, slotsLeft: 0 } }).body.includes('PF')
  && emailTemplate({ business: 'S', founding: { enabled: true, name: 'PF', plan: 'premium', days: 30, slotsLeft: 3 } }).body.includes('nessun rinnovo automatico'));
check('outreach: telefonata senza "profilo già presente" se non esiste', !phoneScript({ business: 'S', profileUrl: null }).some((s) => s.step.startsWith('Profilo')));
check('obiezioni: 6 risposte, nessuna denigra i concorrenti', OBJECTIONS.length === 6 && OBJECTIONS.every((o) => !/pessim|scadent|peggior|truff/i.test(o.a)));
const pr = pressRelease({ app: 'AsiaFood', restaurants: 12, cities: 3, features: { orders: false, ai: true, reviews: true, loyalty: false, reservations: true, delivery: false } });
check('comunicato stampa: solo funzioni attive (niente ordini se disattivati)', !/ordinare/.test(pr) && /assistente AI/.test(pr) && /12 locali in 3 comuni/.test(pr));

console.log(`\n${pass} passati, ${fail} falliti`);
process.exit(fail ? 1 : 0);
