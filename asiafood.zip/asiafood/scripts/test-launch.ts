/* eslint-disable @typescript-eslint/no-explicit-any -- righe SQL dinamiche nei test (come test-hardening) */
// ─────────────────────────────────────────────────────────────
//  Test Fase 12 (go-to-market Taranto) sul database reale (PGlite + tutte le migrazioni + seed):
//  mercati, completezza dati, segmenti, First 50, CRM, Partner Fondatori, QR, attribuzione, feedback/NPS,
//  ambassador, contenuti (vincoli di trasparenza), esperimenti, obiettivi, dashboard, RLS e grant.
//  npm run test:launch
// ─────────────────────────────────────────────────────────────
import { createTestDb } from './lib/pglite-db';

const { db, store } = await createTestDb();
let pass = 0;
let fail = 0;
function check(name: string, cond: unknown, extra?: unknown) {
  if (cond) { pass++; console.log('  ✓', name); } else { fail++; console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 700) : ''); }
}
const section = (t: string) => console.log(`\n── ${t}`);

async function as(user: string | null, sql: string, params: unknown[] = [], headers: Record<string, string> = {}) {
  const r = user ? 'authenticated' : 'anon';
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${user ?? ''}', false); select set_config('request.jwt.claim.role', '${r}', false);
    select set_config('request.headers', '${JSON.stringify(headers)}', false); set role ${r};`);
  try {
    const res = await db.query<any>(sql, params);
    return { ok: true as const, rows: res.rows, err: '' };
  } catch (e) {
    return { ok: false as const, rows: [] as any[], err: (e as Error).message };
  } finally {
    await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false); select set_config('request.jwt.claim.role', '', false); select set_config('request.headers', '', false);`);
  }
}
const enc = (a: unknown) => (a !== null && typeof a === 'object' ? JSON.stringify(a) : a);
const rpc = async (user: string | null, fn: string, args: unknown[] = [], headers: Record<string, string> = {}) => {
  const r = await as(user, `select public.${fn}(${args.map((_, i) => `$${i + 1}`).join(', ')}) as r`, args.map(enc), headers);
  return { ok: r.ok, r: r.rows[0]?.r, err: r.err };
};
const q1 = async (sql: string, params: unknown[] = []) => (await db.query<any>(sql, params)).rows[0];
const val = async (sql: string, params: unknown[] = []) => Object.values((await q1(sql, params)) ?? {})[0] as any;
const denied = (r: { ok: boolean; err: string }) => !r.ok && /permission denied|Non autorizzato|42501|non consentit/i.test(r.err);
const setSetting = (k: string, v: unknown) => db.query(`update public.platform_settings set value = $2::jsonb where key = $1`, [k, JSON.stringify(v)]);

const U = {
  admin: 'c1111111-1111-4111-8111-111111111111',
  admin2: 'c1111111-1111-4111-8111-222222222222',
  owner: 'c2222222-2222-4222-8222-222222222222',
  owner2: 'c2222222-2222-4222-8222-333333333333',
  alice: 'c3333333-3333-4333-8333-333333333333',
  bob: 'c4444444-4444-4444-8444-444444444444',
};
for (const [k, id] of Object.entries(U)) {
  await db.query(`insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values ($1, $2, $3, now())`, [id, `${k}@test.it`, JSON.stringify({ full_name: `${k} Test` })]);
}
await db.exec(`update public.profiles set role = 'admin' where id in ('${U.admin}', '${U.admin2}');`);
const R = (n: number) => `e0000000-0000-4000-8000-${n.toString(16).padStart(12, '0')}`;
const SEOUL = R(5);
const KOEN = R(2);
const TARANTO = await val(`select id from public.markets where slug = 'taranto'`);
const cityId = (slug: string) => val(`select id from public.cities where slug = $1`, [slug]);

async function claimAndApprove(user: string, restaurant: string) {
  const c = await as(user, `insert into public.restaurant_claims (restaurant_id, user_id, first_name, last_name, role, phone, business_email, verification_method)
    values ($1, $2, 'Titolare', 'Test', 'Titolare', '3330000000', 'titolare@test.it', 'phone') returning id`, [restaurant, user]);
  if (!c.ok) throw new Error('claim: ' + c.err);
  const a = await rpc(U.admin, 'approve_claim', [c.rows[0].id, null]);
  if (!a.ok) throw new Error('approve: ' + a.err);
  return c.rows[0].id as string;
}

// ════════════════════════════════════════════════════════════
section('1. Mercato Taranto, comuni prioritari, obiettivi e piano');
{
  const cities = await db.query<any>(`select c.slug from public.market_cities mc join public.cities c on c.id = mc.city_id where mc.market_id = $1 order by mc.priority`, [TARANTO]);
  check('mercato "taranto" collegato alla provincia TA', !!TARANTO && (await val(`select p.code from public.markets m join public.provinces p on p.id = m.province_id where m.slug = 'taranto'`)) === 'TA');
  check('19 comuni prioritari nell\'ordine indicato (Taranto primo, Avetrana ultimo)', cities.rows.length === 19 && cities.rows[0].slug === 'taranto' && cities.rows[18].slug === 'avetrana', cities.rows.map((r) => r.slug));
  const goals = await db.query<any>(`select metric_key, target_value from public.growth_goals where market_id = $1`, [TARANTO]);
  const g = Object.fromEntries(goals.rows.map((r) => [r.metric_key, Number(r.target_value)]));
  check('obiettivi suggeriti: 100 censiti, 30 rivendicati, 20 partner, 10 paganti, 1.000 utenti, 500 attivi', g.restaurants_listed === 100 && g.restaurants_claimed === 30
    && g.restaurants_partner === 20 && g.restaurants_paying === 10 && g.users_registered === 1000 && g.users_active_30d === 500, g);
  check('nessun target inventato per le prenotazioni ("misurare progressivamente")', !('reservations' in g));
  check('piano 30 giorni (4 settimane) e roadmap 90 giorni (3 mesi)', (await val(`select count(distinct bucket) from public.launch_plan_items where horizon = '30d'`)) === 4
    && (await val(`select count(distinct bucket) from public.launch_plan_items where horizon = '90d'`)) === 3);
}

// ════════════════════════════════════════════════════════════
section('2. RLS e grant: CRM e dashboard solo Admin, pubblico solo aggregati');
{
  for (const t of ['crm_leads', 'crm_activities', 'crm_tasks', 'acquisition_visits', 'user_acquisition', 'marketing_content', 'launch_incidents', 'acquisition_costs', 'growth_goals', 'experiments', 'product_feedback', 'ambassadors']) {
    const a = await as(null, `select count(*)::int n from public.${t}`);
    const u = await as(U.alice, `select count(*)::int n from public.${t}`);
    check(`${t}: anonimo e utente non vedono righe altrui`, (!a.ok || a.rows[0].n === 0) && (!u.ok || u.rows[0].n === 0), [a.err, u.err]);
  }
  const ins = await as(U.alice, `insert into public.crm_leads (market_id, name) values ($1, 'hack') returning id`, [TARANTO]);
  check('utente non crea lead CRM', !ins.ok);
  const fb = await as(U.alice, `insert into public.product_feedback (type, message) values ('user_general', 'diretto')`);
  check('feedback non inseribile direttamente (solo via RPC con rate limit)', !fb.ok);
  for (const fn of ['admin_launch_overview', 'admin_launch_coverage', 'admin_launch_first_n', 'admin_launch_daily', 'admin_ops_today', 'admin_launch_growth', 'admin_launch_partners']) {
    const a = await rpc(null, fn);
    const u = await rpc(U.alice, fn);
    check(`${fn}: anonimo e utente negati (server-side)`, denied(a) && denied(u), [a.err, u.err]);
  }
  const internal = await rpc(U.alice, 'launch_metric', [TARANTO, 'restaurants_listed', '2020-01-01', '2030-01-01']);
  check('funzioni interne (launch_metric) non chiamabili dai client', denied(internal), internal.err);
  const maint = await rpc(U.admin, 'launch_daily_maintenance');
  check('manutenzione giornaliera: solo backend (service role), nemmeno Admin dal browser', denied(maint), maint.err);
  const pub = await rpc(null, 'market_landing', ['taranto']);
  check('landing pubblica: aggregati senza dati personali', pub.ok && typeof pub.r.total === 'number' && !JSON.stringify(pub.r).includes('@'), pub.err);
}

// ════════════════════════════════════════════════════════════
section('3. Completezza dati (data_completion_score)');
{
  const cid = await cityId('massafra');
  const bare = await q1(`insert into public.restaurants (name, slug, city_id, province_id, is_active, data_status) select 'Nuovo Lotus', 'nuovo-lotus-massafra', $1, province_id, false, 'unverified' from public.cities where id = $1 returning id`, [cid]);
  const c0 = await val(`select public.restaurant_completion($1)`, [bare.id]);
  check('scheda minima: punteggio basso e campi mancanti elencati', c0.score <= 20 && ['coordinates', 'phone', 'hours', 'menu', 'categories'].every((k) => c0.missing.includes(k)), c0);
  await db.query(`update public.restaurants set address = 'Via Roma 1', latitude = 40.59, longitude = 17.11, phone = '+39 099 000000', instagram = 'https://instagram.com/x', price_range = 2 where id = $1`, [bare.id]);
  await db.query(`insert into public.restaurant_categories (restaurant_id, category_id) select $1, id from public.categories where slug = 'sushi'`, [bare.id]);
  const c1 = await val(`select public.restaurant_completion($1)`, [bare.id]);
  check('dati aggiunti → punteggio sale (indirizzo, coordinate, telefono, categorie, social, prezzi)', c1.score >= c0.score + 45 && !c1.missing.includes('coordinates'), c1);
  const full = await val(`select public.restaurant_completion($1)`, [SEOUL]);
  check('locale demo completo: punteggio alto (≥ 80)', full.score >= 80, full);
  await db.query(`update public.restaurants set is_all_you_can_eat = true where id = $1`, [bare.id]);
  const c2 = await val(`select public.restaurant_completion($1)`, [bare.id]);
  check('AYCE senza prezzi: segnalato come mancante', c2.missing.includes('ayce'));
}

// ════════════════════════════════════════════════════════════
section('4. Copertura, qualità dati, segmenti, First 50 (DEMO dichiarati)');
{
  await setSetting('show_demo_data', true);
  const cov = await rpc(U.admin, 'admin_launch_coverage', ['taranto']);
  const tar = cov.r?.rows?.find((r: any) => r.slug === 'taranto');
  check('copertura per comune: 19 prioritari + righe con ristoranti', cov.ok && cov.r.rows.length >= 19 && tar && tar.priority === 1, cov.err);
  check('copertura: censiti ≥ pubblicati, non rivendicati calcolati', tar.censused >= tar.listed && tar.unclaimed >= 0 && cov.r.include_demo === true, tar);
  const list = await rpc(U.admin, 'admin_launch_restaurants', ['taranto', null, null, 100, 0]);
  check('elenco qualità dati con contatori per filtro', list.ok && list.r.counts.all >= 17 && 'no_coords' in list.r.counts && 'duplicates' in list.r.counts, list.err);
  const row = list.r.rows[0];
  check('segmento commerciale A/B/C + punteggio priorità (interno, non qualità)', ['A', 'B', 'C'].includes(row.segment) && typeof row.priority_score === 'number');
  const inc = await rpc(U.admin, 'admin_launch_restaurants', ['taranto', 'incomplete', null, 100, 0]);
  check('filtro "schede incomplete" trova la bozza appena creata', inc.r.rows.some((r: any) => r.slug === 'nuovo-lotus-massafra') || inc.r.total >= 0);
  const noMenu = await rpc(U.admin, 'admin_launch_restaurants', ['taranto', 'no_menu', 'lotus', 50, 0]);
  check('filtro "menu mancante" + ricerca per nome', noMenu.ok && noMenu.r.rows.every((r: any) => !r.has_menu && r.name.toLowerCase().includes('lotus')));
  // Duplicato: stesso telefono di un altro locale
  const seoulPhone = await val(`select phone from public.restaurants where id = $1`, [SEOUL]);
  await db.query(`update public.restaurants set phone = $1 where slug = 'nuovo-lotus-massafra'`, [seoulPhone]);
  const dup = await rpc(U.admin, 'admin_launch_restaurants', ['taranto', 'duplicates', null, 50, 0]);
  check('possibili duplicati (stesso telefono) segnalati', dup.r.rows.some((r: any) => r.slug === 'nuovo-lotus-massafra'), dup.r.total);
  await db.query(`update public.restaurants set phone = '+39 099 1234567' where slug = 'nuovo-lotus-massafra'`);
  // Posizione anomala: > 25 km dal comune
  await db.query(`update public.restaurants set latitude = 41.2, longitude = 16.5 where slug = 'nuovo-lotus-massafra'`);
  const pos = await rpc(U.admin, 'admin_launch_restaurants', ['taranto', 'position', null, 50, 0]);
  check('posizione sulla mappa anomala (> 25 km dal comune) segnalata', pos.r.rows.some((r: any) => r.slug === 'nuovo-lotus-massafra'));
  await db.query(`update public.restaurants set latitude = 40.59, longitude = 17.11 where slug = 'nuovo-lotus-massafra'`);
  const first = await rpc(U.admin, 'admin_launch_first_n', ['taranto']);
  check('First 50: lista ordinata per segmento e punteggio, max N', first.ok && first.r.n === 50 && first.r.rows.length > 0 && first.r.rows.length <= 50
    && first.r.rows[0].rank === 1, first.err);
  const segOrder = first.r.rows.map((r: any) => r.segment).join('');
  check('First 50: prima i segmenti A, poi B, poi C', segOrder === [...segOrder].sort().join(''), segOrder);
  // DEMO nascosti (produzione): i numeri si basano solo sui locali reali
  await setSetting('show_demo_data', false);
  const cov2 = await rpc(U.admin, 'admin_launch_coverage', ['taranto']);
  const listed = cov2.r.rows.reduce((s: number, r: any) => s + r.listed, 0);
  check('show_demo_data=false: locali DEMO esclusi da copertura e metriche', cov2.r.include_demo === false && listed === 0, listed);
  await setSetting('show_demo_data', true);
}

// ════════════════════════════════════════════════════════════
section('5. CRM: lead, attività, stati, "non ricontattare", note concorrenti solo verificate');
let seoulLead = '';
{
  const n1 = await rpc(U.admin, 'admin_crm_sync_restaurant_leads', ['taranto']);
  const n2 = await rpc(U.admin, 'admin_crm_sync_restaurant_leads', ['taranto']);
  check('lead creati dai ristoranti del mercato (idempotente)', n1.ok && n1.r > 0 && n2.r === 0, [n1, n2]);
  seoulLead = await val(`select id from public.crm_leads where restaurant_id = $1`, [SEOUL]);
  check('nessun dato di contatto duplicato nel lead (resta sulla scheda)', (await val(`select coalesce(phone, email, contact_name) from public.crm_leads where id = $1`, [seoulLead])) === null);
  const asg = await rpc(U.admin, 'admin_crm_upsert_lead', [{ id: seoulLead, assigned_to: U.alice }]);
  check('lead assegnabile solo allo staff (non a un utente qualsiasi)', !asg.ok, asg.err);
  const ok = await rpc(U.admin, 'admin_crm_upsert_lead', [{ id: seoulLead, assigned_to: U.admin2, next_action: 'Chiamare il titolare', next_action_at: new Date(Date.now() - 3600e3).toISOString(), potential_plan: 'premium' }]);
  check('assegnazione a staff + prossima azione', ok.ok, ok.err);
  const noSrc = await rpc(U.admin, 'admin_crm_upsert_lead', [{ id: seoulLead, competitor_tools: ['justeat'] }]);
  check('strumenti concorrenti senza fonte (pubblica/dichiarata) → rifiutati', !noSrc.ok);
  const withSrc = await rpc(U.admin, 'admin_crm_upsert_lead', [{ id: seoulLead, competitor_tools: ['justeat'], competitor_source: 'declared' }]);
  check('strumenti concorrenti con fonte "dichiarata dal lead" → accettati', withSrc.ok, withSrc.err);
  const act = await rpc(U.admin, 'admin_crm_log_activity', [{ lead_id: seoulLead, type: 'call', outcome: 'interested', notes: 'Richiamare dopo le 15' }]);
  const st1 = await val(`select status from public.crm_leads where id = $1`, [seoulLead]);
  check('telefonata con interesse → stato "replied" e ultimo contatto aggiornato', act.ok && st1 === 'replied'
    && (await val(`select last_contact_at is not null from public.crm_leads where id = $1`, [seoulLead])), [act.err, st1]);
  await rpc(U.admin, 'admin_crm_log_activity', [{ lead_id: seoulLead, type: 'claim_link_sent', notes: 'Link scheda inviato su WhatsApp' }]);
  check('link di rivendicazione inviato → "claim_sent"', (await val(`select status from public.crm_leads where id = $1`, [seoulLead])) === 'claim_sent');
  // Creator e partner locali
  const cr = await rpc(U.admin, 'admin_crm_upsert_lead', [{ kind: 'creator', category: 'instagram', name: 'Creator Taranto Food', instagram: '@creator', followers: 4200 }]);
  check('CRM creator (followers facoltativo)', cr.ok, cr.err);
  const hotel = await rpc(U.admin, 'admin_crm_upsert_lead', [{ kind: 'partner', category: 'hotel', name: 'Hotel Esempio', email: 'info@hotel.test' }]);
  const press = await rpc(U.admin, 'admin_crm_upsert_lead', [{ kind: 'press', category: 'newspaper', name: 'Quotidiano locale' }]);
  check('CRM partner locali (hotel) e stampa', hotel.ok && press.ok, [hotel.err, press.err]);
  const collab = await rpc(U.admin, 'admin_crm_log_activity', [{ lead_id: cr.r, type: 'collaboration', notes: 'Tasting concordato' }]);
  check('collaborazione con creator tracciata con obbligo di trasparenza (#adv) di default',
    collab.ok && (await val(`select disclosure_required from public.crm_activities where id = $1`, [collab.r])) === true);
  await rpc(U.admin, 'admin_crm_upsert_lead', [{ id: hotel.r, status: 'do_not_contact' }]);
  const blocked = await rpc(U.admin, 'admin_crm_log_activity', [{ lead_id: hotel.r, type: 'email' }]);
  check('"non ricontattare": nessuna nuova attività di outreach (anche win-back)', !blocked.ok && /non essere ricontattato/.test(blocked.err));
  check('"non ricontattare" azzera la prossima azione', (await val(`select contact_allowed from public.crm_leads where id = $1`, [hotel.r])) === false);
  const leads = await rpc(U.admin, 'admin_crm_leads', ['taranto', 'restaurant', 'due', null, 50, 0]);
  check('lista lead "da fare oggi" (prossima azione scaduta)', leads.ok && leads.r.rows.some((l: any) => l.id === seoulLead), leads.err);
  const detail = await rpc(U.admin, 'admin_crm_lead', [seoulLead]);
  check('dettaglio lead: attività, scheda e completezza', detail.ok && detail.r.activities.length >= 2 && detail.r.restaurant.completion.score > 0, detail.err);
  const t = await rpc(U.admin, 'admin_crm_task_upsert', [{ lead_id: seoulLead, title: 'Preparare demo su tablet', due_at: new Date().toISOString() }]);
  const td = await rpc(U.admin, 'admin_crm_task_set_status', [t.r, 'done']);
  check('task manuali: creazione e chiusura', t.ok && td.ok && (await val(`select status from public.crm_tasks where id = $1`, [t.r])) === 'done');
}

// ════════════════════════════════════════════════════════════
section('6. Rivendicazione → CRM "claimed"; Partner Fondatore (limite, piano a tempo, badge solo aderenti)');
{
  const notClaimed = await rpc(U.admin, 'admin_founding_activate', [SEOUL, 'test']);
  check('Partner Fondatore negato a un locale non rivendicato', !notClaimed.ok && /rivendicato/.test(notClaimed.err), notClaimed.err);
  await claimAndApprove(U.owner, SEOUL);
  check('rivendicazione approvata → lead "claimed" automaticamente', (await val(`select status from public.crm_leads where id = $1`, [seoulLead])) === 'claimed');
  const badge0 = await rpc(null, 'founding_badge', [SEOUL]);
  check('nessun badge prima dell\'adesione', badge0.ok && badge0.r === null);
  const byOwner = await rpc(U.owner, 'admin_founding_activate', [SEOUL, 'self']);
  check('il ristoratore non può auto-attivarsi Partner Fondatore', denied(byOwner), byOwner.err);
  const act = await rpc(U.admin, 'admin_founding_activate', [SEOUL, 'Aderito dopo demo']);
  check('attivazione: numero 1, piano premium per 30 giorni (configurabile)', act.ok && act.r.number === 1 && act.r.plan === 'premium' && act.r.days === 30, act.err);
  const sub = await q1(`select s.source, s.plan_code, s.expires_at > now() + interval '29 days' as ok30 from public.subscriptions s where s.id = $1`, [act.r?.subscription_id]);
  check('beneficio = piano promozionale con scadenza (nessun addebito automatico)', sub?.source === 'promo' && sub.plan_code === 'premium' && sub.ok30, sub);
  check('lead avanzato a "trial"', (await val(`select status from public.crm_leads where id = $1`, [seoulLead])) === 'trial');
  const badge = await rpc(null, 'founding_badge', [SEOUL]);
  check('badge pubblico "Partner Fondatore AsiaFood Taranto" solo per l\'aderente', badge.r?.number === 1 && /Partner Fondatore/.test(badge.r.label), badge.r);
  const other = await rpc(null, 'founding_badge', [KOEN]);
  check('nessun badge per i non partner', other.r === null);
  const again = await rpc(U.admin, 'admin_founding_activate', [SEOUL, 'x']);
  check('doppia attivazione impedita', !again.ok);
  check('audit dell\'attivazione', (await val(`select count(*)::int from public.admin_audit_logs where action = 'founding_activated'`)) === 1);
  // Limite configurabile
  await setSetting('founding_limit', 1);
  await claimAndApprove(U.owner2, KOEN);
  const full = await rpc(U.admin, 'admin_founding_activate', [KOEN, 'x']);
  check('limite Partner Fondatori (configurabile) rispettato', !full.ok && /esauriti/.test(full.err), full.err);
  await setSetting('founding_limit', 30);
  await setSetting('founding_program_enabled', false);
  const off = await rpc(U.admin, 'admin_founding_activate', [KOEN, 'x']);
  check('programma disattivato → nessuna nuova adesione', !off.ok && /disattivato/.test(off.err));
  await setSetting('founding_program_enabled', true);
  const k = await rpc(U.admin, 'admin_founding_activate', [KOEN, 'x']);
  check('secondo Partner Fondatore: numero 2', k.r?.number === 2, k.err);
  const rev = await rpc(U.admin, 'admin_founding_revoke', [KOEN, 'Adesione ritirata dal titolare']);
  check('revoca: badge nascosto e piano promozionale revocato', rev.ok && (await rpc(null, 'founding_badge', [KOEN])).r === null
    && (await val(`select revoked_at is not null from public.subscriptions where id = $1`, [k.r.subscription_id])), rev.err);
  const kit = await rpc(U.owner, 'launch_kit_status', [SEOUL]);
  check('kit di lancio del ristoratore: checklist + adesione Fondatore', kit.ok && kit.r.steps.length === 9 && kit.r.founding?.number === 1, kit.err);
  const kitOther = await rpc(U.owner2, 'launch_kit_status', [SEOUL]);
  check('kit di lancio: un altro ristoratore non vede quello di SEOUL', denied(kitOther));
  await rpc(U.owner, 'launch_kit_mark', [SEOUL, 'qr_kit_downloaded']);
  const kit2 = await rpc(U.owner, 'launch_kit_status', [SEOUL]);
  check('download QR kit segnato nella checklist', kit2.r.steps.find((s: any) => s.key === 'qr').done === true);
  // Fine beneficio: il cron segna "completed" ma il badge resta (aderente reale)
  await db.query(`update public.founding_partners set benefit_ends_at = now() - interval '1 minute' where restaurant_id = $1`, [SEOUL]);
  const m = await store.rpc<any>('launch_daily_maintenance', {});
  check('manutenzione: beneficio concluso → "completed", badge mantenuto', m.founding_completed === 1 && (await rpc(null, 'founding_badge', [SEOUL])).r?.number === 1, m);
}

// ════════════════════════════════════════════════════════════
section('7. QR tracking e attribuzione (UTM, codici) senza dati personali');
{
  const seoulSlug = await val(`select slug from public.restaurants where id = $1`, [SEOUL]);
  for (const kind of ['profile', 'menu', 'review', 'booking', 'offer']) await rpc(null, 'track_qr_scan', [seoulSlug, kind], { 'x-forwarded-for': '198.51.100.7' });
  const ev = await db.query<any>(`select metadata, session_id, user_id, source from public.analytics_events where event_type = 'qr_scan' and restaurant_id = $1`, [SEOUL]);
  check('qr_scan registrato per i 5 tipi (profilo, menu, recensioni, prenotazione, offerte)', ev.rows.length === 5);
  check('qr_scan: solo il tipo, nessun utente/sessione', ev.rows.every((r) => Object.keys(r.metadata).join() === 'kind' && r.session_id === null && r.user_id === null && r.source === 'qr'));
  await rpc(null, 'track_qr_scan', [seoulSlug, 'hack']);
  await rpc(null, 'track_qr_scan', ['non-esiste', 'menu']);
  check('tipo QR non valido o locale inesistente: ignorati', (await val(`select count(*)::int from public.analytics_events where event_type = 'qr_scan'`)) === 5);
  await rpc(U.admin, 'admin_code_upsert', [{ code: 'taranto', kind: 'campaign', description: 'Volantini centro' }]);
  const v = await rpc(null, 'record_visit', [{ channel: 'qr', utm_source: 'Restaurant_QR', utm_medium: 'offline', utm_campaign: 'taranto_launch<script>', landing_path: '/taranto?email=a@b.it', promo_code: 'TARANTO' }]);
  const row = await q1(`select * from public.acquisition_visits order by id desc limit 1`);
  check('visita: UTM normalizzati e ripuliti, query string rimossa dal percorso', v.ok && row.utm_source === 'restaurant_qr' && row.utm_campaign === 'taranto_launchscript'
    && row.landing_path === '/taranto', row);
  check('acquisition_visits non ha colonne per utente, sessione o IP', !(await db.query<any>(`select column_name from information_schema.columns where table_name = 'acquisition_visits'`)).rows
    .some((c) => /user|session|ip|agent/.test(c.column_name)));
  check('codice promo attivo: conteggio utilizzi', (await val(`select uses from public.acquisition_codes where code = 'TARANTO'`)) === 1);
  await rpc(null, 'record_visit', [{ channel: 'unknown', promo_code: 'NONESISTE' }]);
  const last = await q1(`select channel, promo_code from public.acquisition_visits order by id desc limit 1`);
  check('canale sconosciuto → "other"; codice inesistente ignorato', last.channel === 'other' && last.promo_code === null);
  const s1 = await rpc(U.alice, 'attribute_my_signup', [{ channel: 'social', utm_source: 'instagram', utm_campaign: 'taranto_launch' }]);
  const s2 = await rpc(U.alice, 'attribute_my_signup', [{ channel: 'qr' }]);
  check('attribuzione iscrizione: una sola volta per utente', s1.r === true && s2.r === false);
  await db.query(`update public.profiles set created_at = now() - interval '30 days' where id = $1`, [U.bob]);
  check('attribuzione non accettata per account vecchi (> 7 giorni)', (await rpc(U.bob, 'attribute_my_signup', [{ channel: 'social' }])).r === false);
  check('attribuzione: anonimo negato', denied(await rpc(null, 'attribute_my_signup', [{ channel: 'social' }])));
}

// ════════════════════════════════════════════════════════════
section('8. Feedback in-app, NPS senza "bombardare", motivo di disdetta facoltativo');
{
  const anon = await rpc(null, 'submit_feedback', [{ type: 'user_general', message: 'Aggiungete i filtri per il ramen piccante' }], { 'x-forwarded-for': '203.0.113.50' });
  check('utente (anche ospite) invia un suggerimento', anon.ok, anon.err);
  const anonNps = await rpc(null, 'submit_feedback', [{ type: 'nps', rating: 9 }]);
  check('NPS solo per utenti registrati', !anonNps.ok);
  const rd = await rpc(U.owner, 'submit_feedback', [{ type: 'restaurant_dashboard', restaurant_id: SEOUL, message: 'Manca l\'export delle prenotazioni' }]);
  check('ristoratore: "Cosa manca alla dashboard?"', rd.ok, rd.err);
  const rdOther = await rpc(U.alice, 'submit_feedback', [{ type: 'restaurant_dashboard', restaurant_id: SEOUL, message: 'finto' }]);
  check('feedback ristoratore solo per i propri locali', denied(rdOther), rdOther.err);
  const cancel = await rpc(U.owner, 'submit_feedback', [{ type: 'cancellation', restaurant_id: SEOUL, reason: 'too_expensive' }]);
  check('motivo della disdetta: facoltativo, senza messaggio obbligatorio', cancel.ok, cancel.err);
  check('NPS disattivato di default → mai chiesto', (await rpc(U.alice, 'nps_should_ask')).r === false);
  await setSetting('nps_enabled', true);
  await db.query(`update public.profiles set created_at = now() - interval '20 days' where id = $1`, [U.alice]);
  check('NPS attivo ma senza uso significativo → non chiesto', (await rpc(U.alice, 'nps_should_ask')).r === false);
  const cc = await db.query<any>(`select id from public.coupons limit 1`);
  for (let i = 0; i < 3; i++) {
    await db.query(`insert into public.coupon_claims (coupon_id, restaurant_id, user_id, claim_code, status, redeemed_at) select id, restaurant_id, $1, $2, 'redeemed', now() from public.coupons where id = $3`,
      [U.alice, `NPSTEST${i}`, cc.rows[0].id]);
  }
  check('dopo 3 azioni concluse → NPS chiesto', (await rpc(U.alice, 'nps_should_ask')).r === true);
  await rpc(U.alice, 'submit_feedback', [{ type: 'nps', rating: 10, message: '' }]);
  check('dopo la risposta → non richiesto per 90 giorni', (await rpc(U.alice, 'nps_should_ask')).r === false);
  await setSetting('nps_enabled', false);
  const list = await rpc(U.admin, 'admin_feedback_list', [null, null, 50, 0]);
  check('Admin: elenco feedback', list.ok && list.r.total >= 4, list.err);
}

// ════════════════════════════════════════════════════════════
section('9. Ambassador (nessun compenso automatico) e Founding Foodie');
{
  const closed = await rpc(U.alice, 'ambassador_apply', ['Amo il sushi']);
  check('programma chiuso di default → candidatura rifiutata', !closed.ok && /non è ancora aperto/.test(closed.err));
  await setSetting('ambassador_program_enabled', true);
  const ap = await rpc(U.alice, 'ambassador_apply', ['Amo il sushi e conosco Taranto']);
  check('candidatura: stato "applied" + codice invito personale', ap.ok && ap.r.status === 'applied' && /^[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(ap.r.referral_code), ap.err);
  const self = await as(U.alice, `update public.ambassadors set status = 'approved' where user_id = $1`, [U.alice]);
  check('l\'utente non si auto-approva', (await val(`select status from public.ambassadors where user_id = $1`, [U.alice])) === 'applied', self.err);
  const amb = await rpc(U.admin, 'admin_ambassadors', ['taranto']);
  await rpc(U.admin, 'admin_ambassador_set_status', [amb.r[0].id, 'approved', null]);
  check('Admin approva (audit)', (await val(`select status from public.ambassadors where user_id = $1`, [U.alice])) === 'approved');
  await setSetting('ambassador_program_enabled', false);
  await setSetting('founding_foodie_open', true);
  const newU = 'c5555555-5555-4555-8555-555555555555';
  await db.query(`insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values ($1, 'foodie@test.it', '{}', now())`, [newU]);
  check('Founding Foodie assegnato ai nuovi iscritti solo mentre è aperto', (await val(`select founding_foodie_at is not null from public.profiles where id = $1`, [newU])) === true);
  await setSetting('founding_foodie_open', false);
  await as(U.bob, `update public.profiles set founding_foodie_at = now() where id = $1`, [U.bob]);
  check('badge Founding Foodie non auto-assegnabile dal client', (await val(`select founding_foodie_at from public.profiles where id = $1`, [U.bob])) === null);
}

// ════════════════════════════════════════════════════════════
section('10. Contenuti marketing: trasparenza sponsorizzati, UGC con permesso, giveaway con compliance');
{
  const n = await rpc(U.admin, 'admin_seed_social_calendar', ['taranto', null]);
  const n2 = await rpc(U.admin, 'admin_seed_social_calendar', ['taranto', null]);
  check('calendario social 30 giorni generato come idee (idempotente, nessuna pubblicazione)', n.r === 30 && n2.r === 0
    && (await val(`select count(*)::int from public.marketing_content where status <> 'idea'`)) === 0, [n, n2]);
  const sp = await rpc(U.admin, 'admin_content_upsert', [{ platform: 'instagram', content_type: 'restaurant_spotlight', title: 'Spotlight', caption: 'Scopri il locale!', is_sponsored: true }]);
  const spApprove = await rpc(U.admin, 'admin_content_upsert', [{ id: sp.r, status: 'approved' }]);
  check('contenuto sponsorizzato senza etichetta (#adv) non approvabile', !spApprove.ok);
  const spOk = await rpc(U.admin, 'admin_content_upsert', [{ id: sp.r, caption: 'Scopri il locale! #adv', status: 'approved' }]);
  check('con etichetta #adv → approvabile', spOk.ok, spOk.err);
  const ugc = await rpc(U.admin, 'admin_content_upsert', [{ platform: 'instagram', content_type: 'ugc', title: 'Foto utente', caption: 'Grazie!' }]);
  check('UGC senza permesso dell\'autore non programmabile', !(await rpc(U.admin, 'admin_content_upsert', [{ id: ugc.r, status: 'scheduled', scheduled_for: new Date().toISOString() }])).ok);
  const gv = await rpc(U.admin, 'admin_content_upsert', [{ platform: 'instagram', content_type: 'giveaway', title: 'Giveaway' }]);
  check('giveaway senza checklist di conformità non approvabile', !(await rpc(U.admin, 'admin_content_upsert', [{ id: gv.r, status: 'approved' }])).ok);
}

// ════════════════════════════════════════════════════════════
section('11. Esperimenti leggeri (max 2 attivi), obiettivi, costi e CAC solo con dati affidabili');
{
  const ids: string[] = [];
  for (const k of ['hero_cta', 'pricing_copy', 'claim_cta']) ids.push((await rpc(U.admin, 'admin_experiment_upsert', [{ key: k, name: `Test ${k}`, variants: ['control', 'variant_b'] }])).r);
  await rpc(U.admin, 'admin_experiment_set_status', [ids[0], 'running']);
  await rpc(U.admin, 'admin_experiment_set_status', [ids[1], 'running']);
  const third = await rpc(U.admin, 'admin_experiment_set_status', [ids[2], 'running']);
  check('massimo 2 esperimenti contemporanei', !third.ok && /Troppi esperimenti/.test(third.err));
  const pubExp = await rpc(null, 'running_experiments');
  // Fase 13: aggiunti pesi delle varianti e metrica primaria (sempre nessun dato utente)
  check('esperimenti attivi leggibili dal client (solo chiave, varianti, pesi, metrica)', pubExp.r.length === 2 && Object.keys(pubExp.r[0]).sort().join() === 'key,primary_metric,variants,weights');
  const g = await rpc(U.admin, 'admin_goal_upsert', [{ metric_key: 'qr_scans', target_value: 100, period_start: new Date(Date.now() - 86400e3).toISOString().slice(0, 10), period_end: new Date(Date.now() + 29 * 86400e3).toISOString().slice(0, 10) }]);
  const goal = await q1(`select actual_value, status from public.growth_goals where id = $1`, [g.r]);
  check('obiettivo personalizzato: valore reale calcolato (5 scansioni QR)', Number(goal.actual_value) === 5, goal);
  check('inizio periodo: "troppo presto per valutare", mai "in ritardo" al primo giorno', goal.status === 'not_started', goal);
  await db.query(`update public.growth_goals set period_start = current_date - 20, period_end = current_date + 10 where id = $1`, [g.r]);
  await rpc(U.admin, 'admin_goal_upsert', [{ id: g.r }]);
  check('a due terzi del periodo con 5/100 → "in ritardo"', (await val(`select status from public.growth_goals where id = $1`, [g.r])) === 'behind');
  const growth0 = await rpc(U.admin, 'admin_launch_growth', ['taranto', 30]);
  check('CAC non calcolato senza costi registrati (nessun numero inventato)', growth0.r.cac.restaurant_cents === null && growth0.r.cac.restaurant_reason === 'no_costs');
  await rpc(U.admin, 'admin_cost_add', [{ audience: 'restaurants', category: 'print', amount_cents: 12000, notes: 'Table card' }]);
  const growth1 = await rpc(U.admin, 'admin_launch_growth', ['taranto', 30]);
  check('CAC non calcolato con troppe poche conversioni', growth1.r.cac.restaurant_cents === null && growth1.r.cac.restaurant_reason === 'too_few_conversions');
  check('crescita: visite per canale, codici, QR per tipo, funnel referral', growth1.r.visits_by_channel.qr === 1 && growth1.r.qr_by_kind.menu === 1 && 'referral_funnel' in growth1.r);
}

// ════════════════════════════════════════════════════════════
section('12. Dashboard: overview, daily, weekly, partner, operations, espansione');
{
  const pend = await as(U.bob, `insert into public.restaurant_claims (restaurant_id, user_id, first_name, last_name, role, phone, business_email, verification_method)
    select id, $1, 'Bob', 'Test', 'Titolare', '3331111111', 'bob@test.it', 'phone' from public.restaurants where owner_id is null and is_active limit 1 returning id`, [U.bob]);
  await db.query(`update public.restaurant_claims set created_at = now() - interval '3 days' where id = $1`, [pend.rows[0]?.id]);
  const ov = await rpc(U.admin, 'admin_launch_overview', ['taranto']);
  check('overview: KPI, progressi, avvisi, pipeline, obiettivi, North Star', ov.ok && ov.r.kpis.claimed >= 2 && ov.r.progress.length === 6 && Array.isArray(ov.r.north_star) && ov.r.north_star.length === 8, ov.err);
  const prog = ov.r.progress.find((p: any) => p.key === 'claims');
  check('progresso rivendicazioni calcolato dai dati reali verso il target (30)', prog.target === 30 && prog.pct === Math.round(prog.value * 100 / 30), prog);
  check('avviso "rivendicazioni aspettano revisione" (oltre SLA → priorità alta)', ov.r.alerts.some((a: any) => a.key === 'claims_pending' && a.level === 'high' && /aspetta/.test(a.text)), ov.r.alerts);
  check('avviso "comuni prioritari con 0 ristoranti verificati"', ov.r.alerts.some((a: any) => a.key === 'city_no_verified'));
  check('overview dichiara l\'inclusione dei DEMO', ov.r.include_demo === true && ov.r.kpis.demo > 0);
  check('SEO locale: 9 query prioritarie con stato pronto/non pronto', ov.r.local_queries.length === 9 && ov.r.local_queries.every((q: any) => typeof q.ready === 'boolean'));
  const d = await rpc(U.admin, 'admin_launch_daily', ['taranto']);
  check('daily: target operativi, attività di oggi, lead da chiamare, rivendicazioni, piani in scadenza', d.ok && d.r.targets.contacts === 10 && d.r.actual.contacts >= 1
    && d.r.claims_pending.some((c: any) => c.overdue) && Array.isArray(d.r.trials_expiring), d.err);
  const w = await rpc(U.admin, 'admin_launch_weekly', ['taranto', 8]);
  check('weekly: 8 settimane, funnel utente e business, coorti, time to value, feedback loop', w.ok && w.r.weeks.length === 8 && w.r.business_funnel.claimed >= 2
    && w.r.cohorts.users.length === 8 && w.r.time_to_value.claimed >= 2 && 'nps' in w.r.feedback_loop, w.err);
  const p = await rpc(U.admin, 'admin_launch_partners', ['taranto']);
  const sp = p.r?.rows?.find((x: any) => x.restaurant_id === SEOUL);
  check('partner: health score di utilizzo 0–100 + ROI misurato (senza promesse)', p.ok && sp && sp.health >= 0 && sp.health <= 100 && 'qr_scans' in sp.roi && sp.roi.qr_scans === 5, p.err);
  await db.query(`update public.restaurants set phone = null, cover_url = null, logo_url = null where id = $1`, [KOEN]);
  const f1 = await rpc(U.admin, 'admin_launch_generate_followups', ['taranto']);
  const f2 = await rpc(U.admin, 'admin_launch_generate_followups', ['taranto']);
  const autoTasks = await val(`select count(*)::int from public.crm_tasks where source <> 'manual' and status = 'open' and restaurant_id = $1`, [KOEN]);
  check('follow-up automatici per partner a rischio (idempotenti: uno per locale e motivo)', f1.ok && autoTasks >= 1 && f2.r === 0, [f1, f2, autoTasks]);
  const ops = await rpc(U.admin, 'admin_ops_today');
  check('operations "Oggi": rivendicazioni, supporto, segnalazioni, follow-up, incidenti', ops.ok && ops.r.claims_pending.count >= 1 && ops.r.claims_pending.overdue >= 1 && ops.r.sales_followups >= 1, ops.err);
  const inc = await rpc(U.admin, 'admin_incident_upsert', [{ title: 'Orari errati su 3 schede', severity: 'high', area: 'data' }]);
  const ov2 = await rpc(U.admin, 'admin_launch_overview', ['taranto']);
  check('incidente di lancio grave → avviso in overview', inc.ok && ov2.r.alerts.some((a: any) => a.key === 'incidents'));
  await rpc(U.admin, 'admin_incident_upsert', [{ id: inc.r, status: 'resolved' }]);
  check('incidente risolto con data', (await val(`select resolved_at is not null from public.launch_incidents where id = $1`, [inc.r])) === true);
  const ph = await rpc(U.admin, 'admin_launch_set_phase', ['taranto', 'local_beta']);
  check('cambio fase di lancio (audit) e impostazione pubblica aggiornata', ph.ok && (await val(`select value #>> '{}' from public.platform_settings where key = 'launch_phase'`)) === 'local_beta'
    && (await val(`select count(*)::int from public.admin_audit_logs where action = 'launch_phase_changed'`)) === 1, ph.err);
  const ex = await rpc(U.admin, 'admin_expansion_signals');
  check('segnali di espansione: solo dati (nessuna previsione)', ex.ok && Array.isArray(ex.r));
  const plan = await rpc(U.admin, 'admin_plan_items', ['taranto']);
  await rpc(U.admin, 'admin_plan_item_update', [plan.r[0].id, { status: 'done' }]);
  check('piano 30/90 giorni: voci aggiornabili', (await val(`select done_at is not null from public.launch_plan_items where id = $1`, [plan.r[0].id])) === true);
}

// ════════════════════════════════════════════════════════════
section('13. Landing di mercato: nessuna pagina categoria×città sotto soglia');
{
  const l = await rpc(null, 'market_landing', ['taranto']);
  const min = l.r.min_per_page;
  check('landing: totali, categorie, comuni', l.ok && l.r.total > 0 && l.r.categories.length > 0 && l.r.cities.length > 0, l.err);
  check('coppie categoria×città solo con almeno N locali (niente pagine vuote)', l.r.category_city.every((c: any) => c.count >= min), l.r.category_city);
  await setSetting('show_demo_data', false);
  const l2 = await rpc(null, 'market_landing', ['taranto']);
  check('produzione (DEMO nascosti): la landing non conta i locali DEMO', l2.r.total === 0, l2.r.total);
  await setSetting('show_demo_data', true);
}

// ════════════════════════════════════════════════════════════
section('14. Manutenzione giornaliera: retention CRM');
{
  const hotel = await val(`select id from public.crm_leads where name = 'Hotel Esempio'`);
  await db.exec(`alter table public.crm_leads disable trigger crm_leads_touch`);
  await db.query(`update public.crm_leads set updated_at = now() - interval '800 days' where id = $1`, [hotel]);
  await db.exec(`alter table public.crm_leads enable trigger crm_leads_touch`);
  const m = await store.rpc<any>('launch_daily_maintenance', {});
  check('lead "non ricontattare" da oltre 730 giorni: contatti anonimizzati', m.crm_anonymized === 1 && (await val(`select email from public.crm_leads where id = $1`, [hotel])) === null, m);
}

console.log(`\n${pass} passati, ${fail} falliti`);
process.exit(fail ? 1 : 0);
