/**
 * Import di ristoranti da CSV/JSON — stesso motore della pagina /admin/import.
 *
 * Uso:
 *   npm run import -- <file.csv|file.json> [opzioni]
 *
 * Opzioni:
 *   --apply                     Scrive nel database (senza: solo simulazione + report)
 *   --offline                   Nessuna connessione: confronta con i dati locali (reference + demo)
 *   --on-duplicate=<azione>     skip (default) | merge | update | create
 *   --publish                   Pubblica subito i nuovi locali (default: bozza da verificare)
 *   --default-status=<stato>    unverified (default) | partially_verified | verified
 *   --report=<file.json>        Salva il report completo
 *
 * Variabili ambiente (per --apply o confronto con il DB reale):
 *   VITE_SUPABASE_URL (o SUPABASE_URL) e SUPABASE_SERVICE_ROLE_KEY
 *   La service role key NON deve mai finire nel frontend: usala solo qui, in locale o in CI.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { basename, resolve } from 'node:path';
import { createClient } from '@supabase/supabase-js';
import { loadEnv } from 'vite';
import { cities as refCities, categories as refCategories, provinces as refProvinces } from '../src/data/reference';
import { demoRestaurantCategories, demoRestaurants } from '../src/data/demo';
import {
  analyzeRows, buildOperation, detectFormat, emptySummary, parseFile,
  type ExistingRestaurant, type ImportDecision, type ImportOptions,
} from '../src/lib/import/index';
import type { DataStatus } from '../src/types/domain';

const root = resolve(import.meta.dirname, '..');
const env = { ...loadEnv('production', root, ''), ...process.env } as Record<string, string | undefined>;
const args = process.argv.slice(2);
const flag = (name: string) => args.includes(`--${name}`);
const opt = (name: string) => args.find((a) => a.startsWith(`--${name}=`))?.split('=').slice(1).join('=');
const file = args.find((a) => !a.startsWith('--'));

if (!file) {
  console.error('Uso: npm run import -- <file.csv|file.json> [--apply] [--offline] [--on-duplicate=skip|merge|update|create] [--publish] [--default-status=unverified] [--report=report.json]');
  process.exit(1);
}

const onDuplicate = (opt('on-duplicate') ?? 'skip') as 'skip' | 'merge' | 'update' | 'create';
if (!['skip', 'merge', 'update', 'create'].includes(onDuplicate)) throw new Error(`--on-duplicate non valido: ${onDuplicate}`);
const options: ImportOptions = {
  publish: flag('publish'),
  defaultStatus: (opt('default-status') ?? 'unverified') as DataStatus,
};
const apply = flag('apply');
const url = env.SUPABASE_URL || env.VITE_SUPABASE_URL;
const key = env.SUPABASE_SERVICE_ROLE_KEY;
const offline = flag('offline') || !url || !key;
if (apply && offline) {
  console.error('✗ --apply richiede VITE_SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY (e non --offline).');
  process.exit(1);
}
const sb = offline ? null : createClient(url!, key!, { auth: { persistSession: false } });

async function context() {
  if (!sb) {
    return { cities: refCities, categories: refCategories, provinces: refProvinces };
  }
  const [c, k, p] = await Promise.all([
    sb.from('cities').select('id,name,slug,province_id,latitude,longitude').eq('is_active', true),
    sb.from('categories').select('id,name,slug').eq('is_active', true),
    sb.from('provinces').select('id,name,code'),
  ]);
  for (const r of [c, k, p]) if (r.error) throw new Error(r.error.message);
  return { cities: c.data!, categories: k.data!, provinces: p.data! };
}

async function existingFor(cityIds: string[]): Promise<ExistingRestaurant[]> {
  if (!sb) {
    return demoRestaurants
      .filter((r) => cityIds.includes(r.city_id))
      .map((r) => ({
        ...(r as unknown as ExistingRestaurant),
        category_slugs: demoRestaurantCategories.filter((x) => x.restaurant_id === r.id).map((x) => refCategories.find((c) => c.id === x.category_id)!.slug),
      }));
  }
  if (!cityIds.length) return [];
  const { data, error } = await sb.from('restaurants').select('*, restaurant_categories(category:categories(slug))').in('city_id', cityIds).limit(10000);
  if (error) throw new Error(error.message);
  return (data as (Record<string, unknown> & { restaurant_categories: { category: { slug: string } | null }[] })[]).map(({ restaurant_categories, ...r }) => ({
    ...(r as unknown as ExistingRestaurant),
    category_slugs: restaurant_categories.map((x) => x.category?.slug).filter((s): s is string => !!s),
  }));
}

async function main() {
  const text = readFileSync(resolve(process.cwd(), file!), 'utf8');
  const format = detectFormat(file!, text);
  const raw = parseFile(text, format);
  const ctx = await context();
  const first = analyzeRows(raw, [], ctx);
  const cityIds = Array.from(new Set(first.map((r) => r.record?.city_id).filter((x): x is string => !!x)));
  const existing = await existingFor(cityIds);
  const rows = analyzeRows(raw, existing, ctx);

  // Politica per i duplicati (mai creazione automatica, salvo --on-duplicate=create)
  const dupDecision: ImportDecision = onDuplicate === 'create' ? 'create_anyway' : onDuplicate;
  for (const r of rows) if (r.record && (r.matches.length || r.duplicateOfRow)) r.decision = r.matches.length ? dupDecision : onDuplicate === 'create' ? 'create_anyway' : 'skip';

  console.log(`\n${basename(file!)} · ${format.toUpperCase()} · ${rows.length} righe · ${offline ? 'OFFLINE (dati locali)' : `Supabase ${new URL(url!).host}`}`);
  console.log(`Modalità: ${apply ? 'SCRITTURA' : 'simulazione (usa --apply per scrivere)'} · duplicati: ${onDuplicate} · nuovi locali: ${options.publish ? 'pubblicati' : 'bozza'}\n`);
  for (const r of rows) {
    const name = r.record?.name ?? String(r.raw.name ?? r.raw.nome ?? '?');
    const tag = !r.record ? '✗ ERRORE ' : r.matches.length ? '≈ DUPLIC.' : r.duplicateOfRow ? '≈ DOPPIO ' : '+ NUOVO  ';
    console.log(`${String(r.index).padStart(4)} ${tag} ${name}${r.record ? ` (${r.record.city_name})` : ''} → ${r.decision}`);
    r.errors.forEach((e) => console.log(`            ✗ ${e}`));
    r.matches.slice(0, 1).forEach((m) => console.log(`            ≈ ${m.candidate.name} [${m.score}] ${m.reasons.join(', ')}`));
    r.warnings.forEach((w) => console.log(`            ⚠ ${w}`));
  }

  const summary = emptySummary(rows.length);
  let batchId: string | null = null;
  if (apply && sb) {
    const { data } = await sb.from('import_batches').insert({ file_name: basename(file!), format, total_rows: rows.length, options: { ...options, onDuplicate, source: 'cli' } }).select('id').single();
    batchId = (data as { id: string } | null)?.id ?? null;
  }
  for (const r of rows) {
    if (!r.record) {
      summary.skipped += 1;
      summary.errors.push({ row: r.index, message: r.errors.join('; ') });
      continue;
    }
    const op = buildOperation(r, existing.find((e) => e.id === r.targetId), options);
    if (!op) {
      summary.skipped += 1;
      continue;
    }
    if (!apply || !sb) {
      if (op.restaurantId) summary[r.decision === 'merge' ? 'merged' : 'updated'] += 1;
      else summary.created += 1;
      continue;
    }
    const { error } = await sb.rpc('admin_import_restaurant', {
      p_restaurant_id: op.restaurantId,
      p_data: op.data,
      p_category_slugs: op.categorySlugs,
      p_replace_categories: op.replaceCategories,
      p_source: op.source,
      p_batch_id: batchId,
    });
    if (error) summary.errors.push({ row: r.index, name: r.record.name, message: error.message });
    else if (!op.restaurantId) summary.created += 1;
    else if (r.decision === 'merge' || op.notes.length) summary.merged += 1;
    else summary.updated += 1;
  }
  if (batchId && sb) {
    await sb.from('import_batches').update({
      created_count: summary.created, updated_count: summary.updated, merged_count: summary.merged,
      skipped_count: summary.skipped, error_count: summary.errors.length, errors: summary.errors.slice(0, 500),
    }).eq('id', batchId);
  }

  console.log(`\n${apply ? 'Risultato' : 'Simulazione'}: ${summary.created} creati · ${summary.updated} aggiornati · ${summary.merged} uniti · ${summary.skipped} ignorati · ${summary.errors.length} errori`);
  const reportPath = opt('report');
  if (reportPath) {
    writeFileSync(resolve(process.cwd(), reportPath), JSON.stringify({ file: basename(file!), apply, options, onDuplicate, summary, rows: rows.map(({ raw: _raw, ...r }) => r) }, null, 2));
    console.log(`Report salvato in ${reportPath}`);
  }
  process.exit(summary.errors.some((e) => !e.message.includes('mancante') && !e.message.includes('non gestito')) && apply ? 2 : 0);
}

main().catch((e) => {
  console.error('✗', (e as Error).message);
  process.exit(1);
});
