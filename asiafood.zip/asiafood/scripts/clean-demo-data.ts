// ─────────────────────────────────────────────────────────────
//  Rimozione dei dati DEMO dal database (locali di fantasia, Rider demo) + show_demo_data=false.
//  Safeguard: dry-run di default; per eseguire servono TUTTI:
//    CLEAN_DEMO_DATA_ALLOWED=true  e  --confirm=DELETE-DEMO-DATA  e conferma interattiva del ref del progetto.
//  Uso: SUPABASE_URL=… SUPABASE_SERVICE_ROLE_KEY=… npm run clean-demo-data [-- --confirm=DELETE-DEMO-DATA]
// ─────────────────────────────────────────────────────────────
import { createInterface } from 'node:readline/promises';

const url = (process.env.SUPABASE_URL ?? '').trim();
const key = (process.env.SUPABASE_SERVICE_ROLE_KEY ?? '').trim();
if (!url || !key) {
  console.error('Imposta SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY (solo nella shell).');
  process.exit(1);
}
const confirm = process.argv.find((a) => a.startsWith('--confirm='))?.split('=')[1] ?? null;
const execute = confirm === 'DELETE-DEMO-DATA';
if (execute && process.env.CLEAN_DEMO_DATA_ALLOWED !== 'true') {
  console.error('✗ Esecuzione bloccata: imposta anche CLEAN_DEMO_DATA_ALLOWED=true (protezione contro esecuzioni accidentali).');
  process.exit(1);
}
const ref = new URL(url).hostname.split('.')[0];
if (execute) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const typed = await rl.question(`Progetto Supabase "${ref}" (${process.env.APP_ENV ?? 'ambiente?'}). Riscrivi il ref per confermare: `);
  rl.close();
  if (typed.trim() !== ref) {
    console.error('Annullato.');
    process.exit(1);
  }
}
const res = await fetch(`${url}/rest/v1/rpc/clean_demo_data`, {
  method: 'POST',
  headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
  body: JSON.stringify({ p_confirm: execute ? 'DELETE-DEMO-DATA' : null }),
});
if (!res.ok) {
  console.error(`✗ Errore ${res.status}`);
  process.exit(1);
}
console.log(execute ? '✓ Pulizia eseguita:' : 'Dry-run (nessuna modifica):', await res.json());
