/**
 * Genera public/sitemap.xml e aggiorna la riga Sitemap di public/robots.txt.
 * Eseguito automaticamente prima di ogni build (npm run build).
 *
 * Sorgente dati:
 *  - Supabase (se VITE_SUPABASE_URL + VITE_SUPABASE_ANON_KEY sono presenti): legge con la
 *    chiave PUBBLICA, quindi le RLS garantiscono che entrino solo i locali pubblicati
 *    (niente bozze, niente demo se nascosti). I locali chiusi definitivamente sono esclusi.
 *  - altrimenti i dati locali (reference + demo)
 *
 * Non indicizzati (vedi anche robots.txt e meta noindex): dashboard, admin, login, claim, profili.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { loadEnv } from 'vite';
import { categories as refCategories, cities as refCities } from '../src/data/reference';
import { demoRestaurantCategories, demoRestaurants } from '../src/data/demo';

const root = resolve(import.meta.dirname, '..');
const env = { ...loadEnv(process.env.NODE_ENV ?? 'production', root, ''), ...process.env };
const SITE = (env.VITE_SITE_URL || 'https://asiafood.netlify.app').replace(/\/$/, '');
const SB_URL = env.VITE_SUPABASE_URL;
// Volutamente la chiave anonima: la sitemap deve vedere esattamente ciò che vede il pubblico.
const SB_KEY = env.VITE_SUPABASE_ANON_KEY;

interface Entry {
  loc: string;
  lastmod?: string;
  priority: number;
  changefreq: 'daily' | 'weekly' | 'monthly';
}

async function fromSupabase() {
  const get = async <T,>(path: string): Promise<T> => {
    const res = await fetch(`${SB_URL}/rest/v1/${path}`, { headers: { apikey: SB_KEY!, Authorization: `Bearer ${SB_KEY}` } });
    if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
    return res.json() as Promise<T>;
  };
  const [restaurants, cities, categories, links] = await Promise.all([
    get<{ slug: string; updated_at: string; city_id: string }[]>('restaurants?select=slug,updated_at,city_id&is_active=eq.true&is_permanently_closed=eq.false&limit=50000'),
    get<{ id: string; slug: string }[]>('cities?select=id,slug&is_active=eq.true'),
    get<{ id: string; slug: string }[]>('categories?select=id,slug&is_active=eq.true'),
    get<{ category_id: string; restaurant: { city_id: string } }[]>('restaurant_categories?select=category_id,restaurant:restaurants!inner(city_id,is_active,is_permanently_closed)&restaurant.is_active=eq.true&restaurant.is_permanently_closed=eq.false&limit=100000'),
  ]);
  return { restaurants, cities, categories, links: links.map((l) => ({ category_id: l.category_id, city_id: l.restaurant.city_id })) };
}

function fromLocal() {
  return {
    restaurants: demoRestaurants.map((r) => ({ slug: r.slug, updated_at: r.updated_at, city_id: r.city_id })),
    cities: refCities.map((c) => ({ id: c.id, slug: c.slug })),
    categories: refCategories.map((c) => ({ id: c.id, slug: c.slug })),
    links: demoRestaurantCategories.map((l) => ({ category_id: l.category_id, city_id: demoRestaurants.find((r) => r.id === l.restaurant_id)!.city_id })),
  };
}

/** Soglia di qualità: pagine categoria×comune indicizzate solo con almeno N locali (come seo_min_restaurants_category_city). */
const MIN_COMBO = Number(env.SEO_MIN_RESTAURANTS_CATEGORY_CITY || 2);
const MAX_PER_FILE = 10_000; // limite prudente (il protocollo ne consente 50.000)
const APP_ENV = (env.APP_ENV || env.VITE_APP_ENV || (env.CONTEXT === 'production' ? 'production' : env.CONTEXT ? 'staging' : 'development')).toLowerCase();

const urlset = (entries: Entry[], today: string) =>
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
  entries.map((e) => `  <url><loc>${SITE}${e.loc}</loc><lastmod>${e.lastmod ?? today}</lastmod><changefreq>${e.changefreq}</changefreq><priority>${e.priority.toFixed(1)}</priority></url>`).join('\n') +
  `\n</urlset>\n`;

async function slugRedirects(): Promise<{ old_slug: string; new_slug: string }[]> {
  if (!SB_URL || !SB_KEY) return [];
  try {
    const res = await fetch(`${SB_URL}/rest/v1/rpc/restaurant_slug_redirects`, { method: 'POST', headers: { apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}`, 'Content-Type': 'application/json' }, body: '{}' });
    return res.ok ? ((await res.json()) as { old_slug: string; new_slug: string }[]) : [];
  } catch {
    return [];
  }
}

async function main() {
  let data: ReturnType<typeof fromLocal>;
  let source = 'dati locali';
  if (SB_URL && SB_KEY) {
    try {
      data = await fromSupabase();
      source = 'Supabase';
    } catch (e) {
      console.warn(`⚠ Sitemap: Supabase non raggiungibile (${(e as Error).message}), uso i dati locali`);
      data = fromLocal();
    }
  } else {
    data = fromLocal();
  }

  const today = new Date().toISOString().slice(0, 10);
  const citiesWithRestaurants = new Set(data.restaurants.map((r) => r.city_id));
  const pages: Entry[] = [
    { loc: '/', priority: 1, changefreq: 'daily' },
    { loc: '/restaurants', priority: 0.8, changefreq: 'daily' },
    { loc: '/ristoranti', priority: 0.7, changefreq: 'weekly' },
    { loc: '/map', priority: 0.6, changefreq: 'weekly' },
    { loc: '/per-ristoratori', priority: 0.5, changefreq: 'monthly' },
    { loc: '/business/pricing', priority: 0.5, changefreq: 'monthly' },
    { loc: '/support', priority: 0.3, changefreq: 'monthly' },
    { loc: '/app', priority: 0.3, changefreq: 'monthly' },
    { loc: '/press', priority: 0.2, changefreq: 'monthly' },
    // Fase 12: landing di lancio solo se ci sono abbastanza locali pubblici (niente pagine vuote)
    ...(data.restaurants.length >= 3 ? [{ loc: '/taranto', priority: 0.9, changefreq: 'daily' as const }] : []),
  ];
  const offers: Entry[] = [{ loc: '/offers', priority: 0.7, changefreq: 'daily' }];
  const cities: Entry[] = data.cities.filter((c) => citiesWithRestaurants.has(c.id)).map((c) => ({ loc: `/ristoranti/${c.slug}`, priority: 0.8, changefreq: 'weekly' as const }));
  const categoriesWithRestaurants = new Set(data.links.map((l) => l.category_id));
  const categories: Entry[] = data.categories.filter((c) => categoriesWithRestaurants.has(c.id)).map((cat) => ({ loc: `/${cat.slug}`, priority: 0.7, changefreq: 'weekly' as const }));
  // Categoria × comune: solo combinazioni sopra la soglia di qualità (niente pagine sottili o duplicate)
  const comboCount = new Map<string, number>();
  data.links.forEach((l) => comboCount.set(`${l.category_id}|${l.city_id}`, (comboCount.get(`${l.category_id}|${l.city_id}`) ?? 0) + 1));
  data.categories.forEach((cat) =>
    data.cities.forEach((c) => {
      if ((comboCount.get(`${cat.id}|${c.id}`) ?? 0) >= MIN_COMBO) categories.push({ loc: `/${cat.slug}/${c.slug}`, priority: 0.6, changefreq: 'weekly' });
    }),
  );
  const restaurants: Entry[] = data.restaurants.map((r) => ({ loc: `/ristorante/${r.slug}`, lastmod: r.updated_at?.slice(0, 10) ?? today, priority: 0.9, changefreq: 'weekly' as const }));

  // Sitemap index scalabile: un file per tipo, i ristoranti divisi in blocchi
  const files: [string, Entry[]][] = [['sitemap-pages.xml', pages], ['sitemap-cities.xml', cities], ['sitemap-categories.xml', categories], ['sitemap-offers.xml', offers]];
  for (let i = 0; i < Math.max(1, Math.ceil(restaurants.length / MAX_PER_FILE)); i++) files.push([`sitemap-restaurants-${i + 1}.xml`, restaurants.slice(i * MAX_PER_FILE, (i + 1) * MAX_PER_FILE)]);
  for (const [name, entries] of files) writeFileSync(resolve(root, 'public', name), urlset(entries, today));
  const index = `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
    files.map(([name]) => `  <sitemap><loc>${SITE}/${name}</loc><lastmod>${today}</lastmod></sitemap>`).join('\n') + `\n</sitemapindex>\n`;
  writeFileSync(resolve(root, 'public/sitemap.xml'), index);

  // robots.txt: aree private bloccate (non è una misura di sicurezza: l'accesso è protetto da RLS/ruoli);
  // fuori da production (staging, anteprime) il sito intero non è indicizzabile.
  const robotsPath = resolve(root, 'public/robots.txt');
  // Sorgente: scripts/robots.base.txt (public/robots.txt è generato)
  let robots = readFileSync(resolve(root, 'scripts/robots.base.txt'), 'utf8').replace(/^Sitemap:.*$/m, `Sitemap: ${SITE}/sitemap.xml`);
  if (APP_ENV !== 'production' && (env.CONTEXT || env.APP_ENV)) robots = `# STAGING (${APP_ENV}): non indicizzare\nUser-agent: *\nDisallow: /\n`;
  writeFileSync(robotsPath, robots);

  // Redirect 301 dagli slug storici (Netlify _redirects, processato prima del fallback SPA)
  const redirects = await slugRedirects();
  writeFileSync(resolve(root, 'public/_redirects'), `# Generato da scripts/generate-sitemap.ts — redirect permanenti degli slug ristorante cambiati\n` +
    redirects.map((r) => `/ristorante/${r.old_slug}  /ristorante/${r.new_slug}  301!`).join('\n') + '\n');

  const total = files.reduce((n, [, e]) => n + e.length, 0);
  console.log(`✓ sitemap index: ${files.length} file, ${total} URL (${source}) → ${SITE} · redirect slug: ${redirects.length} · robots: ${APP_ENV}`);
}

main();
