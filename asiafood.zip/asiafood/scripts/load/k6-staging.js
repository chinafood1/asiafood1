// ─────────────────────────────────────────────────────────────
//  Test di carico AsiaFood — SOLO STAGING (mai produzione).
//  k6 run -e BASE=https://staging.asiafood.it -e SB_URL=https://<staging>.supabase.co -e SB_ANON=<anon key staging> \
//         -e RIDER_TOKENS=<jwt1,jwt2,…> scripts/load/k6-staging.js
//  Scenari (in parallelo): 100 ricerche concorrenti · 50 richieste AI · 100 watcher di ordini (polling realtime-like)
//  · 50 Rider che inviano posizioni. Soglie = obiettivi (non bloccano il deploy: servono a trovare i colli di bottiglia).
// ─────────────────────────────────────────────────────────────
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE = __ENV.BASE;
const SB = __ENV.SB_URL;
const ANON = __ENV.SB_ANON;
const RIDERS = (__ENV.RIDER_TOKENS || '').split(',').filter(Boolean);
if (!BASE || !SB || !ANON) throw new Error('Imposta BASE, SB_URL, SB_ANON (staging)');
if (/asiafood\.(it|com)$/.test(new URL(BASE).hostname) && !/staging/.test(BASE)) throw new Error('Solo staging!');

const sb = { apikey: ANON, Authorization: `Bearer ${ANON}`, 'Content-Type': 'application/json' };
export const options = {
  scenarios: {
    search: { executor: 'constant-vus', vus: 100, duration: '3m', exec: 'search' },
    ai: { executor: 'constant-vus', vus: 50, duration: '3m', exec: 'ai', startTime: '10s' },
    watchers: { executor: 'constant-vus', vus: 100, duration: '3m', exec: 'watch', startTime: '20s' },
    riders: { executor: 'constant-vus', vus: RIDERS.length ? 50 : 0, duration: '3m', exec: 'rider', startTime: '30s' },
  },
  thresholds: {
    'http_req_duration{scenario:search}': ['p(95)<800'],
    'http_req_duration{scenario:ai}': ['p(95)<6000'],
    'http_req_duration{scenario:watchers}': ['p(95)<500'],
    'http_req_duration{scenario:riders}': ['p(95)<500'],
    http_req_failed: ['rate<0.02'],
  },
};
const Q = ['sushi', 'ramen', 'poke', 'thai', 'cinese', 'all you can eat'];
export function search() {
  const q = Q[Math.floor(Math.random() * Q.length)];
  const r = http.get(`${SB}/rest/v1/restaurants?select=id,slug,name,latitude,longitude&is_active=eq.true&name=ilike.*${encodeURIComponent(q.split(' ')[0])}*&limit=24`, { headers: sb, tags: { scenario: 'search' } });
  check(r, { 'search 200': (x) => x.status === 200 });
  const n = http.post(`${SB}/rest/v1/rpc/nearby_restaurants`, JSON.stringify({ p_lat: 40.4644, p_lng: 17.247, p_radius_km: 10, p_limit: 24 }), { headers: sb, tags: { scenario: 'search' } });
  check(n, { 'nearby ok': (x) => x.status === 200 || x.status === 404 });
  sleep(1);
}
export function ai() {
  const r = http.post(`${BASE}/api/ai/chat`, JSON.stringify({ message: 'sushi economico a Taranto stasera', session_id: `k6-${__VU}` }), { headers: { 'Content-Type': 'application/json' }, tags: { scenario: 'ai' }, timeout: '20s' });
  check(r, { 'ai 200/429': (x) => x.status === 200 || x.status === 429 });
  sleep(3);
}
export function watch() {
  // Il client rilegge lo stato ordine a ogni evento realtime; qui simuliamo la lettura (ordine di prova su staging)
  const r = http.post(`${SB}/rest/v1/rpc/order_track`, JSON.stringify({ p_number: __ENV.ORDER_NUMBER || 'AF-000000-TEST', p_token: __ENV.ORDER_TOKEN || 'x' }), { headers: sb, tags: { scenario: 'watchers' } });
  check(r, { 'track risponde': (x) => x.status < 500 });
  sleep(5);
}
export function rider() {
  const tok = RIDERS[__VU % RIDERS.length];
  const p = { latitude: 40.46 + Math.random() / 100, longitude: 17.24 + Math.random() / 100, accuracy: 12, recorded_at: new Date().toISOString() };
  const r = http.post(`${SB}/rest/v1/rpc/rider_location`, JSON.stringify({ p }), { headers: { ...sb, Authorization: `Bearer ${tok}` }, tags: { scenario: 'riders' } });
  check(r, { 'rider ok': (x) => x.status === 200 });
  sleep(15);
}
