/**
 * Genera i file SQL a partire dalla fonte unica in src/data:
 *   - supabase/migrations/20260926000009_reference_phase2.sql (produzione; la 0005 della
 *     Fase 1 è congelata perché già applicata: inserimenti idempotenti "on conflict do nothing")
 *   - supabase/seed.sql                                       (dati DEMO)
 *
 * Uso: npm run db:seed-sql
 */
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { categories, cities, provinces, regions, subscriptionPlans } from '../src/data/reference';
import { fixedId } from '../src/data/ids';
import {
  demoClosures,
  demoCouponClaims,
  demoMenuItemAddons,
  demoMenuItemVariants,
  demoReservationSeeds,
  demoReservationSettings,
  demoReservationSlots,
  demoCoupons,
  demoHours,
  demoImages,
  demoMenuCategories,
  demoMenuItems,
  demoMenus,
  demoOffers,
  demoRestaurantCategories,
  demoRestaurants,
  demoCampaigns,
  demoSubscriptions,
  demoOptionGroups,
  demoOrderSettings,
  demoDeliveryZones,
} from '../src/data/demo';

type Row = Record<string, unknown>;

function lit(v: unknown): string {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'number') return Number.isFinite(v) ? String(v) : 'null';
  if (Array.isArray(v)) {
    if (v.length === 0) return `'{}'`;
    const inner = v.map((x) => (typeof x === 'number' ? String(x) : `"${String(x).replace(/(["\\])/g, '\\$1')}"`)).join(',');
    return `'{${inner.replace(/'/g, "''")}}'`;
  }
  if (typeof v === 'object') return `'${JSON.stringify(v).replace(/'/g, "''")}'::jsonb`;
  return `'${String(v).replace(/'/g, "''")}'`;
}

function insert(table: string, rows: Row[], columns: string[], conflict = 'do nothing'): string {
  if (!rows.length) return '';
  const values = rows.map((r) => `  (${columns.map((c) => lit(r[c])).join(', ')})`).join(',\n');
  return `insert into public.${table} (${columns.join(', ')}) values\n${values}\non conflict ${conflict};\n\n`;
}

const cols = <T extends object>(sample: T, omit: string[] = []) =>
  Object.keys(sample).filter((k) => !omit.includes(k));

// ─── Reference data (migrazione) ─────────────────────────────
let ref = `-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — 0009 · Dati di riferimento Fase 2 (GENERATO da scripts/generate-seed-sql.ts)
--  Stato completo: regioni, province pugliesi, 29 comuni della provincia
--  di Taranto, categorie (incl. Bubble Tea, Asian Bakery, Asian Grocery), piani.
--  Idempotente (on conflict do nothing): aggiunge solo le righe mancanti.
-- ════════════════════════════════════════════════════════════════════\n\n`;
ref += insert('regions', regions as unknown as Row[], cols(regions[0]), '(id) do nothing');
ref += insert('provinces', provinces as unknown as Row[], cols(provinces[0]), '(id) do nothing');
ref += insert('cities', cities as unknown as Row[], cols(cities[0]), '(id) do nothing');
ref += insert('categories', categories as unknown as Row[], cols(categories[0]), '(id) do nothing');
ref += insert('subscription_plans', subscriptionPlans as unknown as Row[], cols(subscriptionPlans[0], ['id']), '(code) do nothing');

// ─── Seed DEMO ───────────────────────────────────────────────
let seed = `-- ════════════════════════════════════════════════════════════════════
--  AsiaFood — DATI DEMO (GENERATO da scripts/generate-seed-sql.ts)
--  ATTENZIONE: locali di fantasia, is_demo = true. Non sono attività reali.
--  Rimozione completa:  delete from public.restaurants where is_demo;
-- ════════════════════════════════════════════════════════════════════\n\n`;
seed += insert('restaurants', demoRestaurants as unknown as Row[], cols(demoRestaurants[0]), '(id) do nothing');
seed += insert('restaurant_categories', demoRestaurantCategories as unknown as Row[], cols(demoRestaurantCategories[0]), '(restaurant_id, category_id) do nothing');
seed += insert('restaurant_images', demoImages as unknown as Row[], cols(demoImages[0]), '(id) do nothing');
seed += insert('restaurant_hours', demoHours as unknown as Row[], cols(demoHours[0]), '(id) do nothing');
seed += insert('menus', demoMenus as unknown as Row[], cols(demoMenus[0]), '(id) do nothing');
seed += insert('menu_categories', demoMenuCategories as unknown as Row[], cols(demoMenuCategories[0]), '(id) do nothing');
seed += insert('menu_items', demoMenuItems as unknown as Row[], cols(demoMenuItems[0]), '(id) do nothing');
seed += insert('offers', demoOffers as unknown as Row[], cols(demoOffers[0]), '(id) do nothing');
seed += insert('coupons', demoCoupons as unknown as Row[], cols(demoCoupons[0]), '(id) do nothing');
// ─── Fase 5: campagne sponsorizzate e piani DEMO (concessioni Admin, nessun finto abbonamento Stripe) ───
seed += insert('sponsored_campaigns', demoCampaigns as unknown as Row[], cols(demoCampaigns[0]!, ['created_at', 'updated_at']), '(id) do nothing');
seed += insert(
  'subscriptions',
  demoSubscriptions as unknown as Row[],
  ['id', 'restaurant_id', 'plan_code', 'status', 'source', 'billing_interval', 'current_period_start', 'notes'],
  '(id) do nothing',
);
// ─── Fase 4: varianti, extra, prenotazioni, coupon ottenuti ───
seed += insert('menu_item_variants', demoMenuItemVariants as unknown as Row[], cols(demoMenuItemVariants[0]!), '(id) do nothing');
seed += insert('menu_item_addons', demoMenuItemAddons as unknown as Row[], cols(demoMenuItemAddons[0]!), '(id) do nothing');
const rid = (n: number) => fixedId('restaurant', n);
seed += insert(
  'reservation_settings',
  demoReservationSettings.map((x) => ({
    restaurant_id: rid(x.restaurant), reservation_enabled: true, min_party_size: 1, max_party_size: x.max_party, slot_duration_minutes: 90,
    booking_notice_minutes: x.notice, max_advance_days: 60, auto_confirm: x.auto_confirm, guest_message: x.message,
  })),
  ['restaurant_id', 'reservation_enabled', 'min_party_size', 'max_party_size', 'slot_duration_minutes', 'booking_notice_minutes', 'max_advance_days', 'auto_confirm', 'guest_message'],
  '(restaurant_id) do nothing',
);
seed += insert(
  'reservation_slots',
  demoReservationSlots.map((x, i) => ({
    id: fixedId('slot', i + 1), restaurant_id: rid(x.restaurant), day_of_week: x.day, start_time: x.start, end_time: x.end,
    slot_interval_minutes: x.interval, max_reservations: x.maxRes, max_guests: x.maxGuests, is_active: true, label: x.label,
  })),
  ['id', 'restaurant_id', 'day_of_week', 'start_time', 'end_time', 'slot_interval_minutes', 'max_reservations', 'max_guests', 'is_active', 'label'],
  '(id) do nothing',
);
// Date relative al giorno in cui si esegue il seed
const q = (v: unknown) => (v === null || v === undefined ? 'null' : `'${String(v).replace(/'/g, "''")}'`);
seed += `insert into public.restaurant_closures (id, restaurant_id, date, start_time, end_time, reason) values\n${demoClosures
  .map((c, i) => `  (${q(fixedId('closure', i + 1))}, ${q(rid(c.restaurant))}, current_date + ${c.dayOffset}, ${q(c.start)}, ${q(c.end)}, ${q(c.reason)})`)
  .join(',\n')}\non conflict (id) do nothing;\n\n`;
seed += `insert into public.reservations (id, restaurant_id, guest_name, guest_surname, guest_email, guest_phone, reservation_date, reservation_time, party_size, notes, status, source, confirmation_code, confirmed_at, cancelled_at) values\n${demoReservationSeeds
  .map((x, i) => {
    const email = x.customer ? 'cliente@demo.local' : `${x.name}.${x.surname}@example.com`.toLowerCase();
    const confirmed = ['confirmed', 'completed', 'no_show'].includes(x.status) ? 'now()' : 'null';
    const cancelled = ['cancelled', 'rejected'].includes(x.status) ? 'now()' : 'null';
    return `  (${q(fixedId('reservation', i + 1))}, ${q(rid(x.restaurant))}, ${q(x.name)}, ${q(x.surname)}, ${q(email)}, ${q(`+39 000 111 ${String(1000 + i)}`)}, current_date + ${x.dayOffset}, ${q(x.time)}, ${x.party}, ${q(x.notes ?? null)}, ${q(x.status)}, ${q(x.source ?? 'web')}, ${q(x.code)}, ${confirmed}, ${cancelled})`;
  })
  .join(',\n')}\non conflict (id) do nothing;\n\n`;
seed += `insert into public.coupon_claims (id, coupon_id, restaurant_id, email, claim_code, status, claimed_at, redeemed_at) values\n${demoCouponClaims
  .map((c, i) => {
    const coupon = demoCoupons.find((x) => x.id === fixedId('coupon', c.coupon))!;
    const email = c.customer ? 'cliente@demo.local' : c.email!;
    const redeemed = c.redeemedDaysAgo !== undefined;
    return `  (${q(fixedId('couponClaim', i + 1))}, ${q(coupon.id)}, ${q(coupon.restaurant_id)}, ${q(email)}, ${q(c.code)}, '${redeemed ? 'redeemed' : 'claimed'}', now() - interval '${c.claimedDaysAgo} days', ${redeemed ? `now() - interval '${c.redeemedDaysAgo} days'` : 'null'})`;
  })
  .join(',\n')}\non conflict (id) do nothing;\n`;
seed += `update public.coupons c set claims_count = (select count(*) from public.coupon_claims x where x.coupon_id = c.id),
  redemptions_count = (select count(*) from public.coupon_claims x where x.coupon_id = c.id and x.status = 'redeemed')
  where c.id in (${demoCoupons.map((c) => q(c.id)).join(', ')});\n`;

// ─── Fase 8: ordini online DEMO (configurazione, zone di consegna, scelte strutturate) ───
seed += `\n`;
seed += insert('menu_option_groups', demoOptionGroups.map(({ options: _o, ...g }) => g) as unknown as Row[],
  ['id', 'menu_item_id', 'restaurant_id', 'name', 'min_select', 'max_select', 'required', 'display_order', 'is_active'], '(id) do nothing');
seed += insert('menu_options', demoOptionGroups.flatMap((g) => g.options) as unknown as Row[],
  ['id', 'option_group_id', 'restaurant_id', 'name', 'price', 'is_available', 'display_order'], '(id) do nothing');
seed += insert('restaurant_order_settings', demoOrderSettings as unknown as Row[],
  cols(demoOrderSettings[0]!, ['created_at', 'updated_at']), '(restaurant_id) do nothing');
seed += insert('delivery_zones', demoDeliveryZones as unknown as Row[], cols(demoDeliveryZones[0]!, ['polygon']), '(id) do nothing');

const root = resolve(import.meta.dirname, '..');
// La migrazione 0009 è già applicata: si rigenera solo su richiesta esplicita (--reference)
if (process.argv.includes('--reference')) {
  writeFileSync(resolve(root, 'supabase/migrations/20260926000009_reference_phase2.sql'), ref);
  console.log(`✓ reference_data.sql (${regions.length} regioni, ${provinces.length} province, ${cities.length} comuni, ${categories.length} categorie)`);
}
writeFileSync(resolve(root, 'supabase/seed.sql'), seed);
console.log(`✓ seed.sql (${demoRestaurants.length} ristoranti DEMO, ${demoMenuItems.length} piatti, ${demoOffers.length} offerte)`);
