// ─────────────────────────────────────────────────────────────
//  Genera docs/RLS_MATRIX.md dal database REALE (tutte le migrazioni, PGlite):
//  per ogni tabella e operazione (SELECT/INSERT/UPDATE/DELETE) chi può accedere, dedotto da
//  GRANT + policy RLS. Uso: npm run docs:rls
//  Legenda: ✓ tutte le righe consentite dalla policy · own = solo righe proprie · pub = solo contenuti pubblicati
//           — = negato · rpc = solo tramite funzioni (SECURITY DEFINER) con controlli interni
// ─────────────────────────────────────────────────────────────
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createTestDb } from './lib/pglite-db';

const { db } = await createTestDb();
type Pol = { tablename: string; policyname: string; cmd: string; roles: string; qual: string | null; with_check: string | null };
const tables = (await db.query<{ relname: string; rls: boolean }>(`select c.relname, c.relrowsecurity rls from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind = 'r' order by 1`)).rows;
const pols = (await db.query<Pol>(`select tablename, policyname, cmd, roles::text, qual, with_check from pg_policies where schemaname = 'public'`)).rows;
const grant = async (role: string, t: string, priv: string) =>
  (await db.query<{ ok: boolean }>(`select has_table_privilege($1, 'public.' || quote_ident($2), $3) ok`, [role, t, priv])).rows[0]!.ok;

const CMDS = ['SELECT', 'INSERT', 'UPDATE', 'DELETE'] as const;
const ACTORS = ['PUBLIC (anon)', 'AUTH USER', 'RESTAURANT OWNER', 'RIDER', 'SALES', 'ADMIN', 'SERVICE ROLE'] as const;

function classify(expr: string): Set<string> {
  const e = expr.toLowerCase();
  const out = new Set<string>();
  if (/^\(?true\)?$/.test(e.trim())) out.add('all');
  if (/is_admin\(\)/.test(e)) out.add('admin');
  if (/can_manage_restaurant|owns_restaurant|can_view_orders|can_refund_orders|order_member_role/.test(e)) out.add('owner');
  if (/is_rider|lg_rider_of|rider_id/.test(e)) out.add('rider');
  if (/auth\.uid\(\)|user_id =|referrer_user_id|reporter_user_id/.test(e)) out.add('own');
  if (/restaurant_is_public|is_active|status = 'published'|menu_is_public|menu_category_is_public|is_public|demo_data_visible|is_current/.test(e)) out.add('pub');
  if (!out.size) out.add('cond');
  return out;
}

const lines: string[] = [];
lines.push('# Matrice RLS (generata)', '', `Generata da \`scripts/generate-rls-matrix.ts\` sulle migrazioni attuali (${new Date().toISOString().slice(0, 10)}). Non modificare a mano: \`npm run docs:rls\`.`, '',
  'Legenda: **✓** tutte le righe · **own** solo righe proprie (auth.uid) · **pub** solo contenuti pubblicati/attivi · **mgr** solo locali gestiti (titolare/staff) · **rider** solo dati propri del Rider · **cond** condizione specifica · **rpc** nessun accesso diretto (solo funzioni con controlli) · **—** negato.',
  'SALES: il ruolo Sales/CRM non esiste in questa versione (nessun accesso). SERVICE ROLE: bypassa RLS (solo backend, mai nel browser).', '',
  `| Tabella | RLS | Op | ${ACTORS.join(' | ')} |`, `|---|---|---|${ACTORS.map(() => '---').join('|')}|`);
let noRls = 0;
for (const t of tables) {
  if (!t.rls) noRls++;
  for (const cmd of CMDS) {
    const tp = pols.filter((p) => p.tablename === t.relname && (p.cmd === cmd || p.cmd === 'ALL'));
    const cell = async (role: 'anon' | 'authenticated', who: 'anon' | 'user' | 'owner' | 'rider' | 'admin') => {
      if (!(await grant(role, t.relname, cmd))) return tp.length || cmd === 'SELECT' ? 'rpc' : '—';
      const applicable = tp.filter((p) => p.roles.includes('public') || p.roles.includes(role));
      if (!applicable.length) return '—';
      const kinds = new Set<string>();
      for (const p of applicable) for (const k of classify(`${p.qual ?? ''} ${p.with_check ?? ''}`.trim() || 'true')) kinds.add(k);
      if (kinds.has('all')) return '✓';
      const parts: string[] = [];
      if (who === 'admin' && kinds.has('admin')) return '✓';
      if (kinds.has('pub')) parts.push('pub');
      if (who !== 'anon' && kinds.has('own')) parts.push('own');
      if ((who === 'owner' || who === 'admin') && kinds.has('owner')) parts.push('mgr');
      if ((who === 'rider' || who === 'admin') && kinds.has('rider')) parts.push('rider');
      if (kinds.has('cond') && !parts.length) parts.push('cond');
      return parts.length ? parts.join('+') : '—';
    };
    const row = [
      await cell('anon', 'anon'), await cell('authenticated', 'user'), await cell('authenticated', 'owner'), await cell('authenticated', 'rider'), '—',
      await cell('authenticated', 'admin'), '✓ (bypass RLS)',
    ];
    lines.push(`| ${cmd === 'SELECT' ? `\`${t.relname}\`` : ''} | ${cmd === 'SELECT' ? (t.rls ? 'on' : '**OFF**') : ''} | ${cmd} | ${row.join(' | ')} |`);
  }
}
lines.push('', `Tabelle: ${tables.length} · senza RLS: ${noRls}. Le policy complete (nome, espressione) sono nelle migrazioni; i test concreti di accesso sono in \`scripts/test-hardening.ts\` e \`scripts/test-rls.mjs\`.`);
writeFileSync(resolve(import.meta.dirname, '../docs/RLS_MATRIX.md'), `${lines.join('\n')}\n`);
console.log(`✓ docs/RLS_MATRIX.md: ${tables.length} tabelle, ${noRls} senza RLS`);
